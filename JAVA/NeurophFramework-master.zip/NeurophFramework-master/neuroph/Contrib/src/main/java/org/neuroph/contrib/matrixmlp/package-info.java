/**
 * Provides matrix and layer based implementation for Multi Layer Perceptron
 * and Backpropagation. This was experiment used to optimize Neuroph performance.
 */

package org.neuroph.contrib.matrixmlp;
