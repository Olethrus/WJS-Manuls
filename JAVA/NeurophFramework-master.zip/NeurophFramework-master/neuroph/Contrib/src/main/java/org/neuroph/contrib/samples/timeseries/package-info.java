/**
 * Provides data set generators used in time series prediction tutorial.
 */

package org.neuroph.contrib.samples.timeseries;