/**
 * Provides error functions for learning rules
 */
package org.neuroph.core.learning.error;
