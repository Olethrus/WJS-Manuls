/**
 * Provides various specific neuron types
 */

package org.neuroph.nnet.comp.neuron;
