package org.neuroph.core.input;

public class DoubleArray {

	private double[] array;

	public DoubleArray(double[] array) {
		this.array = array;
	}

	public double[] getArray() {
		return array;
	}

}
