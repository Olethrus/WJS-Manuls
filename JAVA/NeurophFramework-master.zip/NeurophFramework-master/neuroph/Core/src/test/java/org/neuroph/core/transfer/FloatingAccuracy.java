/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.neuroph.core.transfer;

class FloatingAccuracy {
    
    public static final double ACCURACY = 0.00000000000001;
}
