/**
 * Provides image abstraction to support the image recognition on J2SE and Android platform.
 */
package org.neuroph.imgrec.image;
