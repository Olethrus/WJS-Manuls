/**
 * Provides classes for Optical Character Recognition with neural networks.
 */

package org.neuroph.ocr;