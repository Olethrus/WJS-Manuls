/*
 * Helper classes for running MNIST standalone tests
 */
package org.neuroph.samples.mnist;
