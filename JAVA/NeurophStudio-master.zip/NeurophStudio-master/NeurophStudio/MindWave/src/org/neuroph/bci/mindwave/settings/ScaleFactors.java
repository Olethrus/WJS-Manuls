package org.neuroph.bci.mindwave.settings;

/**
 *
 * @author zoran
 */
public class ScaleFactors {
    public static double attention=1, meditation=1, delta=0.5, theta=1, lowAlpha=10, highAlpha=10, lowBeta=1, highBeta=1, lowGamma=1, highGamma=1, 
                        samplingMarker=1000000;
}
