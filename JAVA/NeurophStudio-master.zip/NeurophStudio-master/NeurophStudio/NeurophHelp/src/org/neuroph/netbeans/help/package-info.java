@HelpSetRegistration(helpSet = "ide-hs.xml", position = 3766)
package org.neuroph.netbeans.help;

import org.netbeans.api.javahelp.HelpSetRegistration;
