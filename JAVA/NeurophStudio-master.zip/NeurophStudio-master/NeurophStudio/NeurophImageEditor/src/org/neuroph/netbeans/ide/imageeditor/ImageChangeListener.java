package org.neuroph.netbeans.ide.imageeditor;

/**
 *
 * @author zoran
 */
public interface ImageChangeListener {
    public void imageChanged();
}
