Generalization
==============

References
----------

-   <http://www.deeplearningbook.org/contents/regularization.html>
-   <https://d396qusza40orc.cloudfront.net/neuralnets/lecture_slides/lec9.pdf>
-   <https://d396qusza40orc.cloudfront.net/neuralnets/lecture_slides/lec10.pdf>
-   <http://blog.cambridgecoding.com/2016/03/24/misleading-modelling-overfitting-cross-validation-and-the-bias-variance-trade-off/>

