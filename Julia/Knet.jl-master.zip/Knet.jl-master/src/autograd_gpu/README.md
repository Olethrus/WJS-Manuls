# Knet.AutoGrad_gpu: implementations of AutoGrad functions for GPU arrays

This module does not export any functions of its own but extends existing AutoGrad functions
and some Base functions used by AutoGrad for GPU arrays.
