# Knet.CuArrays: implementations of Base functions for CuArrays

This module does not export any new functions, but replaces some Base functions for CuArrays with faster implementations.
