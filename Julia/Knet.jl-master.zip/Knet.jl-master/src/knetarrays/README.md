# Knet.KnetArrays: A GPU array structure and its Base function implementations

This module exports KnetArray, KnetMatrix, KnetVector, KnetVecOrMat, and DevArray
(Union{KnetArray,CuArray}) and implements associated Base functions.
