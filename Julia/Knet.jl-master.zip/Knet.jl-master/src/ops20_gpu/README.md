# Knet.Ops20_gpu: implementations of Ops20 operators for GPU arrays

This module does not export any new functions, just provides implementations for Ops20
operators for KnetArrays and CuArrays.
