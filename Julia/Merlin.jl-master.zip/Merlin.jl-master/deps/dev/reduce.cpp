template<typename T>
void reduce(T *x, T *y, int *shape, int *stride) {
  
}
