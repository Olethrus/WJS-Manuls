# Interop with Caffe
To be written...

<!--
First, generate caffe.jl and caffe_pb.jl from caffe.proto using ProtoBuf.jl.

- [VGG_ILSVR_19_layers.caffemodel](http://www.robots.ox.ac.uk/~vgg/software/very_deep/caffe/VGG_ILSVRC_19_layers.caffemodel)

```
git clone caffe
```
-->
