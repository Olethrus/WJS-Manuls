# Merlin.jl
`Merlin` is a flexible deep learning framework written in [Julia](http://julialang.org/).
It aims to provide a fast, flexible and compact deep learning library for machine learning.

See [Github](https://github.com/hshindo/Merlin.jl) for requirements and installation.
