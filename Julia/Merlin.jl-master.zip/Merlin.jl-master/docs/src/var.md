# Var
`Var` is a type of variable for keeping gradients and a history of function calls.

```@autodocs
Modules = [Merlin]
Pages = ["var.jl"]
```
