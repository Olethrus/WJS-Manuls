# MNIST
MNIST classification with neural networks.

## Run
```
julia main.jl config.json
```
