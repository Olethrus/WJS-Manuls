module Datasets

include("io.jl")
include("MNIST.jl")
include("CIFAR10.jl")
include("CIFAR100.jl")
include("PTBLM.jl")

end
