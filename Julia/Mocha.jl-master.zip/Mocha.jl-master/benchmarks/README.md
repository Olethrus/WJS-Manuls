This folder contains some benchmarks I did for deciding the implementation of some components in Mocha, **not** benchmarks of the performance across different deep learning frameworks.
