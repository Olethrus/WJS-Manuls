include("solvers/adam.jl")
include("solvers/sgd.jl")
include("solvers/nesterov.jl")
