export SGD, Nesterov

export LearningRatePolicy, MomentumPolicy

@compat abstract type LearningRatePolicy end
@compat abstract type MomentumPolicy end
