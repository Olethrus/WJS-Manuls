v 0.0.3
-------

- Added DataFrame support
- Wrote RandomizedSearchCV

v 0.0.4
-------

- Python is now an optional dependency
