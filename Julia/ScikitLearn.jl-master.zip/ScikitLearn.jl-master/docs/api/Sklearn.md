# Sklearn

## Internal

---

<a id="macro___reexportsk.1" class="lexicon_definition"></a>
#### @reexportsk(identifiers...) [¶](#macro___reexportsk.1)
    reexportsk(identifiers...)
is equivalent to
    using Skcore.identifiers...
    export identifiers...


*source:*
[/Users/cedric/Programa/Sklearn/src/Sklearn.jl:38](https://github.com/cstjean/scikit-learn.jl/tree/81d6f1b0418104e79dbec21c96619d1998b13bba/src/Sklearn.jl#L38)

