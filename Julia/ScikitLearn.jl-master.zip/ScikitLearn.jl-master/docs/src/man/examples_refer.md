Examples
----

[See here](https://github.com/cstjean/ScikitLearn.jl/blob/master/docs/src/man/examples.md)
