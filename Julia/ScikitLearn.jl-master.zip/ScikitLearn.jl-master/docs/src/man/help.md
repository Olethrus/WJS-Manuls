Getting help
------

[Discourse](https://discourse.julialang.org) is a nice place to ask questions
about ScikitLearn.jl. Please [file an
issue](https://github.com/cstjean/ScikitLearn.jl/issues) for any problem you encounter
related to the Julia interface.
If your question is about the behaviour of a model that was imported through
`@sk_import`, or about machine learning in general, consider [posting on Stack
Overflow](http://stackoverflow.com/questions/tagged/scikit-learn)