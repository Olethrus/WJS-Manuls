using Autoreload

arequire("Skcore")
using Skcore

include("../src/Ndgrid.jl")

using PyCall
using PyPlot
