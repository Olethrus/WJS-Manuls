This folder implements the interface to some Julia models. Ideally, we
would like this code to be inside the library rather than here. See
[CONTRIBUTING.md](../../CONTRIBUTING.md)
