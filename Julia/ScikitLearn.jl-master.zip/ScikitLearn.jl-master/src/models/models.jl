using ScikitLearnBase

include("linear_regression.jl")
include("constant_model.jl")
include("nolearning.jl")
