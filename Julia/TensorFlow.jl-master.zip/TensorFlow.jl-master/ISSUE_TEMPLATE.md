If you are making a bug report, please copy and paste the output of the following Julia snippit into the issue:

```
using TensorFlow
tf_versioninfo()
```
