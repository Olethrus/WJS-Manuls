# Summary reference

## Writing event files
```@docs
TensorFlow.summary.FileWriter
```

## Summary operations
```@docs
TensorFlow.summary.scalar
TensorFlow.summary.histogram
TensorFlow.summary.image
TensorFlow.summary.merge_all
```
