using TensorFlow
using Test

@testset "Tensorboard" begin
    TensorFlow.get_tensorboard()
end
