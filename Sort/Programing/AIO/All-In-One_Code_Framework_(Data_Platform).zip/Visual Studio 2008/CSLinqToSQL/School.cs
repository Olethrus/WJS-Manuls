namespace CSLinqToSQL.Designer
{
    partial class SchoolDataContext
    {
    }
}
