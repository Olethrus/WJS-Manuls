﻿
GRANT CONNECT TO [HelloWorld]
GO
GRANT CONNECT TO [HelloWorld]

GO
