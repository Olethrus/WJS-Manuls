﻿
EXEC sp_addrolemember N'db_owner', N'HelloWorld'

GO
