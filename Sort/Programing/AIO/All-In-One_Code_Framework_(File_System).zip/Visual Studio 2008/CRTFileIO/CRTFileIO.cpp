// - to be finished.
//

#include <stdio.h>
#include <tchar.h>


int _tmain(int argc, _TCHAR* argv[])
{
	return 0;
}

