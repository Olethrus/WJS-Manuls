﻿using System;

namespace AllInOne.CSVSPackage
{
    static class GuidList
    {
        public const string guidCSVSPackagePkgString = "56cd6b04-e515-4bb9-a6a5-32867de05cf5";
        public const string guidCSVSPackageCmdSetString = "ab80cb4b-c3ae-4c3b-b2e6-942964532d1d";

        public static readonly Guid guidCSVSPackageCmdSet = new Guid(guidCSVSPackageCmdSetString);
    };
}