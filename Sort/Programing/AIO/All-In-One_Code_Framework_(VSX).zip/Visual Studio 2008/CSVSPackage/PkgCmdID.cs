﻿using System;

namespace AllInOne.CSVSPackage
{
    static class PkgCmdIDList
    {
        public const uint cmdidCSVSPackageDemo =        0x100;


    };
}