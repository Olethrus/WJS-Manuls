﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace Microsoft.CSVSPackageCloseOpenedDocument
{
    static class PkgCmdIDList
    {
        public const uint cmdidCSVSPackageCloseOpenedDocument =        0x100;


    };
}