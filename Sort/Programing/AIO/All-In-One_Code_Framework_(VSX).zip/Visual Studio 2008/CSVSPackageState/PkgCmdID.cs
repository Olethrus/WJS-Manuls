﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace AllInOne.CSVSPackageState
{
    static class PkgCmdIDList
    {

        public const uint cmdidAllInOneTool = 0x101;

    };
}