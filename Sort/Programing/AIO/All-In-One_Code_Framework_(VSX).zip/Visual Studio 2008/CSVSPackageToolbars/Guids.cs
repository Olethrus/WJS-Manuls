﻿using System;

namespace Company.CSVSToolbars
{
    static class GuidList
    {
        public const string guidCSVSToolbarsPkgString = "458b5bfb-6797-48a7-94f6-b55ecfdd98a5";
        public const string guidCSVSToolbarsCmdSetString = "fbac7588-62c3-4385-bcc4-ebc3ee62c711";

        public static readonly Guid guidCSVSToolbarsCmdSet = new Guid(guidCSVSToolbarsCmdSetString);
    };
}