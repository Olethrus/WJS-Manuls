﻿using System;

namespace Company.CSVSToolbars
{
    static class PkgCmdIDList
    {
        public const uint cmdidMyCommand =        0x100;

        public const int cmdidMCItem1 = 0x130;
        public const int cmdidMCItem2 = 0x131;
        public const int cmdidMCItem3 = 0x132;

    };
}