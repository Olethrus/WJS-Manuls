﻿using System;

namespace MyCompany.CSVSToolbox
{
    static class GuidList
    {
        public const string guidCSVSToolboxPkgString = "88ded7d5-5160-4e96-83e1-c205615e3768";
        public const string guidCSVSToolboxCmdSetString = "ecbc79a1-8b5b-42c7-9a83-6ad72ba92a00";

        public static readonly Guid guidCSVSToolboxCmdSet = new Guid(guidCSVSToolboxCmdSetString);
    };
}