﻿using System;

namespace MyCompany.CSVSToolbox
{
    static class PkgCmdIDList
    {
        public const uint cmdidInitializeToolbox =        0x100;


    };
}