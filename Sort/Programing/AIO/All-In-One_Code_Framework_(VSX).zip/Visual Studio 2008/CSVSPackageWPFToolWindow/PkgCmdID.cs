﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace Company.VSPackageWPFToolWindow
{
    static class PkgCmdIDList
    {

        public const uint cmdidWPFToolWindow =    0x101;

    };
}