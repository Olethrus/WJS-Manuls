﻿// PkgCmdID.cs
// MUST match PkgCmdID.h
using System;

namespace VSX.CSVSService
{
    static class PkgCmdIDList
    {
        public const uint cmdidCallLocalService  = 0x100;
        public const uint cmdidCallGlobalService = 0x101;
    };
}