﻿using System;

namespace AllInOne.CSVSToolWindow
{
    static class PkgCmdIDList
    {
        public const uint cmdidToolWindow =        0x100;
        public const uint cmdidMyTool =    0x101;

        public const int cmdidWindowsMediaOpen = 0x132;
        public const int ToolbarID = 0x1000;
    };
}