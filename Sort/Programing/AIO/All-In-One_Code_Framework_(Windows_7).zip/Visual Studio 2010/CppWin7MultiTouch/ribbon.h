// *****************************************************************************
// * This is an automatically generated header file for UI Element definition  *
// * resource symbols and values. Please do not modify manually.               *
// *****************************************************************************

#pragma once

#define cmdHome 2 
#define cmdHome_LabelTitle_RESID 60001
#define cmdOpenImage 3 
#define cmdOpenImage_LabelTitle_RESID 60002
#define cmdFile 4 
#define cmdFile_LabelTitle_RESID 60003
#define cmdMouseSimulation 5 
#define cmdMouseSimulation_LabelTitle_RESID 60004
#define cmdTranslateLeft 6 
#define cmdTranslateLeft_LabelTitle_RESID 60005
#define cmdTranslateRight 7 
#define cmdTranslateRight_LabelTitle_RESID 60006
#define cmdTranslateUp 8 
#define cmdTranslateUp_LabelTitle_RESID 60007
#define cmdTranslateDown 9 
#define cmdTranslateDown_LabelTitle_RESID 60008
#define cmdScaleDown 10 
#define cmdScaleDown_LabelTitle_RESID 60009
#define cmdScaleUp 11 
#define cmdScaleUp_LabelTitle_RESID 60010
#define cmdRotateLeft 12 
#define cmdRotateLeft_LabelTitle_RESID 60011
#define cmdRotateRight 13 
#define cmdRotateRight_LabelTitle_RESID 60012
#define InternalCmd2_LabelTitle_RESID 60013
