﻿================================================================================
       WINDOWS FORMS APPLICATION : CSWinFormDataGridView Project Overview
       
                   DataGridViewPaging Sample
                        
===============================================================================

/////////////////////////////////////////////////////////////////////////////
Use:

 This sample demonstrates how to page data in the  DataGridView control;


/////////////////////////////////////////////////////////////////////////////
Code Logic:

1. Get total count of the rows in the table;

2. Calculate total count of pages;

3. Load each page on demand; 


/////////////////////////////////////////////////////////////////////////////
References:

1. DataGridView Custom Column Sample
   http://msdn.microsoft.com/en-us/library/ms180996.aspx


/////////////////////////////////////////////////////////////////////////////