﻿================================================================================
       WINDOWS FORMS APPLICATION : CSWinFormPrinting Project Overview
       
                        Printing Sample
                        
===============================================================================

/////////////////////////////////////////////////////////////////////////////
Use:

The Printing sample demonstrates how to do standard print job in Windows Forms 
application.
   

/////////////////////////////////////////////////////////////////////////////
Code Logic:

Create a print job

   1. Add a PrintDocument component to your form.
   2. Right-click your form and choose View Code.
   3. Write code to handle the PrintPage event. 


/////////////////////////////////////////////////////////////////////////////
References:

1. Creating Standard Windows Forms Print Jobs
   http://msdn.microsoft.com/en-us/library/aa984337(VS.71).aspx
   
2. Windows Forms General FAQ.
   http://social.msdn.microsoft.com/Forums/en-US/winforms/thread/77a66f05-804e-4d58-8214-0c32d8f43191
   

/////////////////////////////////////////////////////////////////////////////
