﻿Public Class EnableDesignTimeFuncForChildCtrl

End Class