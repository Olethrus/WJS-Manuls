// dllmain.h : Declaration of module class.

class CATLShellExtIconOverlayHandlerModule : public CAtlDllModuleT< CATLShellExtIconOverlayHandlerModule >
{
public :
	DECLARE_LIBID(LIBID_ATLShellExtIconOverlayHandlerLib)
};

extern class CATLShellExtIconOverlayHandlerModule _AtlModule;
