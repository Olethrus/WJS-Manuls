﻿========================================================================
    WINFORMS APPLICATION : CSShellCommonFileDialog Project Overview
========================================================================

/////////////////////////////////////////////////////////////////////////////
Summary:

- To be finished


/////////////////////////////////////////////////////////////////////////////
References:

MSDN: Common Item Dialog
http://msdn.microsoft.com/en-us/library/bb776913(VS.85).aspx

Customize Your Open File Dialog
http://msdn.microsoft.com/en-us/magazine/cc300434.aspx

Extend OpenFileDialog and SaveFileDialog the easy way
http://www.codeproject.com/KB/dialog/CustomizeFileDialog.aspx


/////////////////////////////////////////////////////////////////////////////