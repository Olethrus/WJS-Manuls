﻿'****************************** Module Header ******************************'
' Module Name:  CFDInCodePackForm.vb
' Project:      VBShellCommonFileDialog
' Copyright (c) Microsoft Corporation.
' 
' 
' 
' This source is subject to the Microsoft Public License.
' See http://www.microsoft.com/opensource/licenses.mspx#Ms-PL.
' All other rights reserved.
' 
' THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
' WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
'***************************************************************************'


Public Class CFDInCodePackForm

#Region "Common Open File Dialogs"

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnOpenAFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenAFile.Click

    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnOpenFiles_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenFiles.Click

    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnOpenAFolder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnOpenAFolder.Click

    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnAddCustomControls_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddCustomControls.Click

    End Sub


    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnAddCommonPlaces_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddCommonPlaces.Click

    End Sub

#End Region


#Region "Common Save File Dialogs"

    ''' <summary>
    ''' 
    ''' </summary>
    ''' <param name="sender"></param>
    ''' <param name="e"></param>
    ''' <remarks></remarks>
    Private Sub btnSaveAFile_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveAFile.Click

    End Sub

#End Region

End Class