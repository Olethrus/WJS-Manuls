﻿=============================================================================
         CLASS LIBRARY : CSShellExtInfotipHandler Project Overview
=============================================================================

/////////////////////////////////////////////////////////////////////////////
Summary:

The C# code sample demonstrates creating a Shell infotip handler with .NET 
Framework 4.

An infotip handler is a shell extension handler that provides pop-up text 
when the user hovers the mouse pointer over the object. It is the most 
flexible way to customize infotips. The alternative way is to specify either 
a fixed string or a list of certain file properties to be displayed (See the 
Infotip Customization section in 
http://msdn.microsoft.com/en-us/library/cc144067.aspx)

Prior to .NET Framework 4, the development of in-process shell extensions 
using managed code is not officially supported because of the CLR limitation 
allowing only one .NET runtime per process. Jesse Kaplan, one of the CLR 
program managers, explains it in this MSDN forum thread: 
http://social.msdn.microsoft.com/forums/en-US/netfxbcl/thread/1428326d-7950-42b4-ad94-8e962124043e.

In .NET 4, with the ability to have multiple runtimes in process with any 
other runtime, Microsoft can now offer general support for writing managed 
shell extensions—even those that run in-process with arbitrary applications 
on the machine. CSShellExtInfotipHandler is such a managed shell extension 
code example. However, please note that you still cannot write shell 
extensions using any version earlier than .NET Framework 4 because those 
versions of the runtime do not load in-process with one another and will 
cause failures in many cases.

The example infotip handler has the class ID (CLSID): 
    {B8D98AB4-376B-45D0-9CF6-8BF22A588989}

It customizes the infotips of .cs file objects. When you hover your mouse 
pointer over a .cs file object in the Windows Explorer, you will see an 
infotip with the text:

    File: <File path, e.g. D:\Test.cs>
    Lines: <Line number, e.g. 123 or N/A>
    - Infotip displayed by CSShellExtInfotipHandler


/////////////////////////////////////////////////////////////////////////////
Setup and Removal:

A. Setup

Run 'Visual Studio Command Prompt (2010)' (or 'Visual Studio x64 Win64 
Command Prompt (2010)' if you are on a x64 operating system) in the Microsoft 
Visual Studio 2010 \ Visual Studio Tools menu as administrator. Navigate to 
the folder that contains the build result CSShellExtInfotipHandler.dll 
and enter the command:

    Regasm.exe CSShellExtInfotipHandler.dll /codebase

The infotip handler is registered successfully if the command prints:

    "Types registered successfully"

B. Removal

Run 'Visual Studio Command Prompt (2010)' (or 'Visual Studio x64 Win64 
Command Prompt (2010)' if you are on a x64 operating system) in the Microsoft 
Visual Studio 2010 \ Visual Studio Tools menu as administrator. Navigate to 
the folder that contains the build result CSShellExtInfotipHandler.dll 
and enter the command:

    Regasm.exe CSShellExtInfotipHandler.dll /unregister

The infotip handler is unregistered successfully if the command prints:

    "Types un-registered successfully"


/////////////////////////////////////////////////////////////////////////////
Demo:

The following steps walk through a demonstration of the infotip handler code 
sample.

Step1. After you successfully build the sample project in Visual Studio 2010, 
you will get a DLL: CSShellExtInfotipHandler.dll. Run 'Visual Studio Command 
Prompt (2010)' (or 'Visual Studio x64 Win64 Command Prompt (2010)' if you are 
on a x64 operating system) in the Microsoft Visual Studio 2010 \ Visual 
Studio Tools menu as administrator. Navigate to the folder that contains the 
build result CSShellExtInfotipHandler.dll and enter the command:

    Regasm.exe CSShellExtInfotipHandler.dll /codebase

The infotip handler is registered successfully if the command prints:

    "Types registered successfully"

Steps. Find a .cs file in the Windows Explorer (e.g. FileInfotipExt.cs in 
the sample folder), and hover the mouse pointer over it. you will see an 
infotip with the text:

    File: <File path, e.g. D:\CSShellExtInfotipHandler\FileInfotipExt.cs>
    Lines: <Line number, e.g. 123 or N/A>
    - Infotip displayed by CSShellExtInfotipHandler

Step3. In the same Visual Studio command prompt, run the command 

    Regasm.exe CSShellExtInfotipHandler.dll /unregister

to unregister the Shell infotip handler.


/////////////////////////////////////////////////////////////////////////////
Implementation:

A. Creating and configuring the project

In Visual Studio 2010, create a Visual C# / Windows / Class Library project 
named "CSShellExtInfotipHandler". Open the project properties, and in the 
Signing page, sign the assembly with a strong name key file. 

-----------------------------------------------------------------------------

B. Implementing a basic Component Object Model (COM) DLL

Shell extension handlers are all in-process COM objects implemented as DLLs. 
Making a basic .NET COM component is very straightforward. You just need to 
define a 'public' class with ComVisible(true), use the Guid attribute to 
specify its CLSID, and explicitly implements certain COM interfaces. For 
example, 

    [ClassInterface(ClassInterfaceType.None)]
    [Guid("B8D98AB4-376B-45D0-9CF6-8BF22A588989"), ComVisible(true)]
    public class SimpleObject : ISimpleObject
    {
        ... // Implements the interface
    }

You even do not need to implement IUnknown and class factory by yourself 
because .NET Framework handles them for you.

-----------------------------------------------------------------------------

C. Implementing the infotip handler and registering it for a certain file 
class

-----------
Implementing the infotip handler:

The FileInfotipExt.cs file defines an infotip handler. The infotip handler 
must implement the IQueryInfo interface to create text for the tooltip, and 
implement the IPersistFile interface for initialization.

    [ComImport(), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    [Guid("00021500-0000-0000-c000-000000000046")]
    internal interface IQueryInfo
    {
        // The original signature of GetInfoTip is 
        // HRESULT GetInfoTip(DWORD dwFlags, [out] PWSTR *ppwszTip);
        // According to the documentation, applications that implement this method 
        // must allocate memory for ppwszTip by calling CoTaskMemAlloc. Calling 
        // applications (the Shell in this case) calls CoTaskMemFree to free the 
        // memory when it is no longer needed. Here, we set PreserveSig to false 
        // (the default value in COM) to make the output parameter 'ppwszTip' the 
        // return value. We also marshal the string return value as LPWStr. The 
        // interop layer in CLR will call CoTaskMemAlloc to allocate memory and 
        // marshal the .NET string to the memory. 
        [return: MarshalAs(UnmanagedType.LPWStr)]
        string GetInfoTip(uint dwFlags);

        int GetInfoFlags();
    }

The IPersistFile interface is available in the 
System.Runtime.InteropServices.ComTypes namespace. 
http://msdn.microsoft.com/en-us/library/system.runtime.interopservices.comtypes.ipersistfile.aspx
	
    [ClassInterface(ClassInterfaceType.None)]
    [Guid("B8D98AB4-376B-45D0-9CF6-8BF22A588989"), ComVisible(true)]
    public class FileInfotipExt : IPersistFile, IQueryInfo
    {
        #region IPersistFile Members

        public void GetClassID(out Guid pClassID)
        {
            ...
        }

        public void GetCurFile(out string ppszFileName)
        {
            ...
        }

        public int IsDirty()
        {
            ...
        }

        public void Load(string pszFileName, int dwMode)
        {
            ...
        }

        public void Save(string pszFileName, bool fRemember)
        {
            ...
        }

        public void SaveCompleted(string pszFileName)
        {
            ...
        }

        #endregion   


        #region IQueryInfo Members

        public string GetInfoTip(uint dwFlags)
        {
            ...
        }

        public int GetInfoFlags()
        {
            ...
        }

        #endregion
    }

When you write your own handler, you must create a new CLSID by using the 
"Create GUID" tool in the Tools menu for the shell extension class, and 
specify the value in the Guid attribute. 

    ...
    [Guid("B8D98AB4-376B-45D0-9CF6-8BF22A588989"), ComVisible(true)]
    public class FileInfotipExt : ...


  1. Implementing IPersistFile

  The Shell queries the extension for IPersistFile and calls its Load method 
  passing the file name of the item over which mouse is placed. 
  IPersistFile.Load opens the specified file and initializes the wanted data. 
  In this code sample, we save the absolute path of the file.

    public void Load(string pszFileName, int dwMode)
    {
        // pszFileName contains the absolute path of the file to be opened.
        this.selectedFile = pszFileName;
    }

  The rest methods of IPersistFile are not used by the Shell for infotip 
  handlers, so we can simply make them blank or throw a NotImplementedException 
  exception.

  2. Implementing IQueryInfo

  After IPersistFile is queried, the Shell queries the IQueryInfo interface 
  and the GetInfoTip method is called. GetInfoTip returns a string containing 
  the tip to display.

  In this code sample, the example infotip is composed of the file path and 
  the count of text lines.

    // Prepare the text of the infotip. The example infotip is composed of 
    // the file path and the count of code lines.
    int lineNum = 0;
    using (StreamReader reader = File.OpenText(this.selectedFile))
    {
        while (reader.ReadLine() != null)
        {
            lineNum++;
        }
    }

    return string.Format("File: {0}\nLines: {1}\n" +
        "- Infotip displayed by CSShellExtInfotipHandler",
        this.selectedFile, lineNum.ToString());

The IQueryInfo.GetInfoFlags method is not currently used. We simply throw  
a NotImplementedException exception in the method.

-----------
Registering the handler for a certain file class:

Infotip handlers can be associated with a file class. The handlers are 
registered by setting the default value of the following registry key to be 
the CLSID the handler class. 

    HKEY_CLASSES_ROOT\<File Type>\shellex\{00021500-0000-0000-C000-000000000046}

The registration of the infotip handler is implemented in the Register 
method of FileInfotipExt. The ComRegisterFunction attribute attached to 
the method enables the execution of user-written code other than the basic 
registration of the COM class. Register calls the 
ShellExtReg.RegisterShellExtInfotipHandler method in ShellExtLib.cs to 
associate the handler with a certain file type. If the file type starts with 
'.', it tries to read the default value of the HKCR\<File Type> key which may 
contain the Program ID to which the file type is linked. If the default value 
is not empty, use the Program ID as the file type to proceed the registration. 

For example, this code sample associates the handler with '.cs' files. 
HKCR\.cs has the default value 'VisualStudio.cs.10.0' by default when 
Visual Studio 2010 is installed, so we proceed to register the handler under 
HKCR\VisualStudio.cs.10.0\ instead of under HKCR\.cs. The following keys 
and values are added in the registration process of the sample handler. 

    HKCR
    {
        NoRemove .cs = s 'VisualStudio.cs.10.0'
        NoRemove VisualStudio.cs.10.0
        {
            NoRemove shellex
            {
                {00021500-0000-0000-C000-000000000046} = 
                    s '{B8D98AB4-376B-45D0-9CF6-8BF22A588989}'
            }
        }
    }

The unregistration is implemented in the Unregister method of 
FileInfotipExt. Similar to the Register method, the ComUnregisterFunction 
attribute attached to the method enables the execution of user-written code 
during the unregistration process. It removes the registry key:
HKCR\<File Type>\shellex\{00021500-0000-0000-C000-000000000046}.


/////////////////////////////////////////////////////////////////////////////
References:

MSDN: Initializing Shell Extensions
http://msdn.microsoft.com/en-us/library/cc144105.aspx

MSDN: IQueryInfo Interface
http://msdn.microsoft.com/en-us/library/bb761359.aspx

The Complete Idiot's Guide to Writing Shell Extensions - Part III
http://www.codeproject.com/KB/shell/ShellExtGuide3.aspx


/////////////////////////////////////////////////////////////////////////////