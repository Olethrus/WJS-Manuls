$type = Date;
$type.__typeName = 'Date';
$type.__class = true;
