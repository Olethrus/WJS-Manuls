$type = Number;
$type.__typeName = 'Number';
$type.__class = true;
