$type = RegExp;
$type.__typeName = 'RegExp';
$type.__class = true;
