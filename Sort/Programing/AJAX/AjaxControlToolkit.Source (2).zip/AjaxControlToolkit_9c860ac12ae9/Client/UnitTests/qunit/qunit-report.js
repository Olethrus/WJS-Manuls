﻿/*
Sends test results to the server
*/

(function(window) {

window.onerror = function() {
}

})(this);
