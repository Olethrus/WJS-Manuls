﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page {
    protected void Page_Load(object sender, EventArgs e) {
        if (!IsPostBack)
            FormView1.Visible = false;

    }

    void rebind() {
        DropDownList1.Items.Clear();
        DropDownList1.DataBind();
    }

    protected void FormView1_ItemInserted(object sender, FormViewInsertedEventArgs e) {
        rebind();
    }
    protected void FormView1_ItemDeleted(object sender, FormViewDeletedEventArgs e) {
        rebind();
    }
    protected void FormView1_ItemUpdated(object sender, FormViewUpdatedEventArgs e) {
        rebind();
    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e) {
        if (DropDownList1.Items[0].Text == "(Select)") 
            DropDownList1.Items.RemoveAt(0);
        FormView1.Visible = true;

    }
}
