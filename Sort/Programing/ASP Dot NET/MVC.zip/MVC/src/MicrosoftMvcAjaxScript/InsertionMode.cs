namespace Sys.Mvc {
    public enum InsertionMode {
        Replace = 0,
        InsertBefore = 1,
        InsertAfter = 2
    }
}
