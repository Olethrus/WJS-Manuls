﻿namespace Microsoft.Web.Mvc.Controls {

    public class Hidden : MvcInputControl {
        public Hidden() :
            base("hidden") {
        }
    }
}
