﻿namespace Microsoft.Web.Mvc {

    public interface IAsyncManagerContainer {

        AsyncManager AsyncManager {
            get;
        }

    }
}
