﻿namespace Microsoft.Web.Mvc {
    using System.Web;
    
    public delegate string MvcSubstitutionCallback(HttpContextBase httpContext);
}
