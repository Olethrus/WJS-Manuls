﻿namespace System.Web.Mvc {

    public abstract class ActionResult {

        public abstract void ExecuteResult(ControllerContext context);

    }

}
