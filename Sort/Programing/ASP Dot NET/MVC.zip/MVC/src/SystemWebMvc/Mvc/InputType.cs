﻿namespace System.Web.Mvc {
    public enum InputType {
        CheckBox,
        Hidden,
        Password,
        Radio,
        Text
    }
}
