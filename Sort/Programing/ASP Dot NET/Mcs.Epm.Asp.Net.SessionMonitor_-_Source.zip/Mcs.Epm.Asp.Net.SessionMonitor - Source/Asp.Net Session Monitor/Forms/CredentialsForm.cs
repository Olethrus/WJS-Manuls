﻿using System;
using System.Collections.Specialized;
using System.Diagnostics;
using System.DirectoryServices;
using System.Windows.Forms;
using Mcs.Epm.Asp.Net.Properties;

namespace Mcs.Epm.Asp.Net.Forms
{
    /// <summary>
    /// Implements a simple dialog for collection credentials
    /// </summary>
    public partial class CredentialsForm : Form
    {
        #region Constructors

        public CredentialsForm()
        {
            InitializeComponent();

            domainList.Text = Settings.Default.LastDomain;
            userNameTextBox.Text = Settings.Default.LastUserName;

            if (string.IsNullOrEmpty(domainList.Text))
            {
                domainList.Select();
                
            }
            else
            {
                if (string.IsNullOrEmpty(userNameTextBox.Text))
                {
                    userNameTextBox.Select();
                }
                else
                {
                    passwordTextBox.Select();
                }
            }
        }

        #endregion

        #region Public Properties

        public string Password
        {
            get
            {
                return passwordTextBox.Text;
            }
        }

        public string Domain
        {
            get
            {
                return domainList.Text;
            }
        }

        public string UserName
        {
            get
            {
                return userNameTextBox.Text;
            }
        }

        #endregion

        #region Private Methods

        /// <summary>
        /// Thanks to http://www.netomatix.com/ListOfDomains.aspx
        /// </summary>
        /// <returns></returns>
        private static StringCollection GetDomainList()
        {
            StringCollection domainList = new StringCollection();

            try
            {
                using (DirectoryEntry en = new DirectoryEntry("LDAP://"))
                using (DirectorySearcher directorySearcher = new DirectorySearcher(en, "objectCategory=Domain"))
                using (SearchResultCollection resultCollection = directorySearcher.FindAll())
                {
                    // Enumerate over each returned domain.
                    foreach (SearchResult result in resultCollection)
                    {
                        ResultPropertyCollection resultPropColl = result.Properties;

                        foreach (object domainName in resultPropColl["name"])
                        {
                            domainList.Add(domainName.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Trace.Write(ex.Message);
            }
            return domainList;
        }

        #endregion

        #region Event Handlers

        private void CredentialsForm_Shown(object sender, EventArgs e)
        {
            Application.DoEvents();
            StringCollection domains = GetDomainList();

            foreach (string domain in domains)
            {
                domainList.Items.Add(domain);
            }
        }

        private void userNameTextBox_TextChanged(object sender, EventArgs e)
        {
            okButton.Enabled = !string.IsNullOrEmpty(userNameTextBox.Text);
        }

        private void okButton_Click(object sender, EventArgs e)
        {
            Settings.Default.LastDomain = domainList.Text;
            Settings.Default.LastUserName = userNameTextBox.Text;
            Settings.Default.Save();

            Close();
        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void useCurrentCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (useCurrentCheckBox.Checked)
            {
                DialogResult = DialogResult.Ignore;
                Close();
            }
        }

        #endregion
    }
}
