﻿namespace Mcs.Epm.Asp.Net.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.databaseServerToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.serverToolStripComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.databasesToolStripComboBox = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.optionsToolStripDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.intervalToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.monitorToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.sessionListView = new System.Windows.Forms.ListView();
            this.sessionIdcolumnHeader = new System.Windows.Forms.ColumnHeader();
            this.createdColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.expiresColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.timeoutColumnHeader = new System.Windows.Forms.ColumnHeader();
            this.sessionsLabel = new System.Windows.Forms.Label();
            this.sessionDataSplitContainer = new System.Windows.Forms.SplitContainer();
            this.treeView = new System.Windows.Forms.TreeView();
            this.sessionDataDataGridView = new System.Windows.Forms.DataGridView();
            this.valueColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.viewerColumn = new System.Windows.Forms.DataGridViewLinkColumn();
            this.sessionDataLabel = new System.Windows.Forms.Label();
            this.toolStrip1.SuspendLayout();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.sessionDataSplitContainer.Panel1.SuspendLayout();
            this.sessionDataSplitContainer.Panel2.SuspendLayout();
            this.sessionDataSplitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sessionDataDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.databaseServerToolStripLabel,
            this.serverToolStripComboBox,
            this.databasesToolStripComboBox,
            this.toolStripSeparator1,
            this.optionsToolStripDropDownButton,
            this.toolStripSeparator2,
            this.monitorToolStripButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(809, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // databaseServerToolStripLabel
            // 
            this.databaseServerToolStripLabel.Name = "databaseServerToolStripLabel";
            this.databaseServerToolStripLabel.Size = new System.Drawing.Size(194, 22);
            this.databaseServerToolStripLabel.Text = "Microsoft SQL Server 2005 Instance ";
            // 
            // serverToolStripComboBox
            // 
            this.serverToolStripComboBox.Name = "serverToolStripComboBox";
            this.serverToolStripComboBox.Size = new System.Drawing.Size(200, 25);
            this.serverToolStripComboBox.DropDown += new System.EventHandler(this.serverToolStripComboBox_DropDown);
            this.serverToolStripComboBox.TextChanged += new System.EventHandler(this.serverToolStripComboBox_TextChanged);
            // 
            // databasesToolStripComboBox
            // 
            this.databasesToolStripComboBox.Enabled = false;
            this.databasesToolStripComboBox.Name = "databasesToolStripComboBox";
            this.databasesToolStripComboBox.Size = new System.Drawing.Size(121, 25);
            this.databasesToolStripComboBox.DropDown += new System.EventHandler(this.databasesToolStripComboBox_DropDown);
            this.databasesToolStripComboBox.TextChanged += new System.EventHandler(this.databasesToolStripComboBox_TextChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // optionsToolStripDropDownButton
            // 
            this.optionsToolStripDropDownButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.optionsToolStripDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1});
            this.optionsToolStripDropDownButton.Image = ((System.Drawing.Image)(resources.GetObject("optionsToolStripDropDownButton.Image")));
            this.optionsToolStripDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.optionsToolStripDropDownButton.Name = "optionsToolStripDropDownButton";
            this.optionsToolStripDropDownButton.Size = new System.Drawing.Size(62, 22);
            this.optionsToolStripDropDownButton.Text = "&Options";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.intervalToolStripTextBox});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(153, 22);
            this.toolStripMenuItem1.Text = "Polling Interval";
            // 
            // intervalToolStripTextBox
            // 
            this.intervalToolStripTextBox.Name = "intervalToolStripTextBox";
            this.intervalToolStripTextBox.Size = new System.Drawing.Size(100, 23);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // monitorToolStripButton
            // 
            this.monitorToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.monitorToolStripButton.Enabled = false;
            this.monitorToolStripButton.Image = global::Mcs.Epm.Asp.Net.Properties.Resources.bullet_green;
            this.monitorToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.monitorToolStripButton.Name = "monitorToolStripButton";
            this.monitorToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.monitorToolStripButton.Text = "&Monitor";
            this.monitorToolStripButton.Click += new System.EventHandler(this.monitorToolStripButton_Click);
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 25);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.BackColor = System.Drawing.Color.White;
            this.splitContainer.Panel1.Controls.Add(this.sessionListView);
            this.splitContainer.Panel1.Controls.Add(this.sessionsLabel);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.BackColor = System.Drawing.Color.White;
            this.splitContainer.Panel2.Controls.Add(this.sessionDataSplitContainer);
            this.splitContainer.Panel2.Controls.Add(this.sessionDataLabel);
            this.splitContainer.Size = new System.Drawing.Size(809, 495);
            this.splitContainer.SplitterDistance = 269;
            this.splitContainer.TabIndex = 1;
            // 
            // sessionListView
            // 
            this.sessionListView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.sessionIdcolumnHeader,
            this.createdColumnHeader,
            this.expiresColumnHeader,
            this.timeoutColumnHeader});
            this.sessionListView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sessionListView.HideSelection = false;
            this.sessionListView.Location = new System.Drawing.Point(0, 23);
            this.sessionListView.MultiSelect = false;
            this.sessionListView.Name = "sessionListView";
            this.sessionListView.Size = new System.Drawing.Size(269, 472);
            this.sessionListView.TabIndex = 1;
            this.sessionListView.UseCompatibleStateImageBehavior = false;
            this.sessionListView.View = System.Windows.Forms.View.Details;
            this.sessionListView.SelectedIndexChanged += new System.EventHandler(this.sessionListView_SelectedIndexChanged);
            // 
            // sessionIdcolumnHeader
            // 
            this.sessionIdcolumnHeader.Text = "Session ID";
            // 
            // createdColumnHeader
            // 
            this.createdColumnHeader.Text = "Created";
            // 
            // expiresColumnHeader
            // 
            this.expiresColumnHeader.Text = "Expires";
            // 
            // timeoutColumnHeader
            // 
            this.timeoutColumnHeader.Text = "Timeout";
            // 
            // sessionsLabel
            // 
            this.sessionsLabel.BackColor = System.Drawing.Color.Gainsboro;
            this.sessionsLabel.Dock = System.Windows.Forms.DockStyle.Top;
            this.sessionsLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sessionsLabel.Location = new System.Drawing.Point(0, 0);
            this.sessionsLabel.Name = "sessionsLabel";
            this.sessionsLabel.Size = new System.Drawing.Size(269, 23);
            this.sessionsLabel.TabIndex = 0;
            this.sessionsLabel.Text = "Sessions";
            this.sessionsLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // sessionDataSplitContainer
            // 
            this.sessionDataSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sessionDataSplitContainer.Location = new System.Drawing.Point(0, 23);
            this.sessionDataSplitContainer.Name = "sessionDataSplitContainer";
            // 
            // sessionDataSplitContainer.Panel1
            // 
            this.sessionDataSplitContainer.Panel1.Controls.Add(this.treeView);
            // 
            // sessionDataSplitContainer.Panel2
            // 
            this.sessionDataSplitContainer.Panel2.Controls.Add(this.sessionDataDataGridView);
            this.sessionDataSplitContainer.Size = new System.Drawing.Size(536, 472);
            this.sessionDataSplitContainer.SplitterDistance = 178;
            this.sessionDataSplitContainer.TabIndex = 2;
            // 
            // treeView
            // 
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.HideSelection = false;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(178, 472);
            this.treeView.TabIndex = 0;
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            // 
            // sessionDataDataGridView
            // 
            this.sessionDataDataGridView.AllowUserToAddRows = false;
            this.sessionDataDataGridView.AllowUserToDeleteRows = false;
            this.sessionDataDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.sessionDataDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.valueColumn,
            this.viewerColumn});
            this.sessionDataDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.sessionDataDataGridView.Location = new System.Drawing.Point(0, 0);
            this.sessionDataDataGridView.Name = "sessionDataDataGridView";
            this.sessionDataDataGridView.ReadOnly = true;
            this.sessionDataDataGridView.RowHeadersVisible = false;
            this.sessionDataDataGridView.Size = new System.Drawing.Size(354, 472);
            this.sessionDataDataGridView.TabIndex = 0;
            this.sessionDataDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.sessionDataDataGridView_CellContentClick);
            // 
            // valueColumn
            // 
            this.valueColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.valueColumn.HeaderText = "Value";
            this.valueColumn.Name = "valueColumn";
            this.valueColumn.ReadOnly = true;
            this.valueColumn.Width = 59;
            // 
            // viewerColumn
            // 
            this.viewerColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.viewerColumn.HeaderText = "View";
            this.viewerColumn.Name = "viewerColumn";
            this.viewerColumn.ReadOnly = true;
            // 
            // sessionDataLabel
            // 
            this.sessionDataLabel.BackColor = System.Drawing.Color.Gainsboro;
            this.sessionDataLabel.Dock = System.Windows.Forms.DockStyle.Top;
            this.sessionDataLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sessionDataLabel.Location = new System.Drawing.Point(0, 0);
            this.sessionDataLabel.Name = "sessionDataLabel";
            this.sessionDataLabel.Size = new System.Drawing.Size(536, 23);
            this.sessionDataLabel.TabIndex = 1;
            this.sessionDataLabel.Text = "Session Data";
            this.sessionDataLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(809, 520);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "ASP.NET Session Monitor";
            this.Shown += new System.EventHandler(this.MainForm_Shown);
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.MainForm_FormClosed);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.ResumeLayout(false);
            this.sessionDataSplitContainer.Panel1.ResumeLayout(false);
            this.sessionDataSplitContainer.Panel2.ResumeLayout(false);
            this.sessionDataSplitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.sessionDataDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel databaseServerToolStripLabel;
        private System.Windows.Forms.ToolStripComboBox databasesToolStripComboBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripDropDownButton optionsToolStripDropDownButton;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripTextBox intervalToolStripTextBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton monitorToolStripButton;
        private System.Windows.Forms.ToolStripComboBox serverToolStripComboBox;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label sessionsLabel;
        private System.Windows.Forms.Label sessionDataLabel;
        private System.Windows.Forms.ListView sessionListView;
        private System.Windows.Forms.ColumnHeader createdColumnHeader;
        private System.Windows.Forms.ColumnHeader expiresColumnHeader;
        private System.Windows.Forms.ColumnHeader timeoutColumnHeader;
        private System.Windows.Forms.ColumnHeader sessionIdcolumnHeader;
        private System.Windows.Forms.SplitContainer sessionDataSplitContainer;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.DataGridView sessionDataDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueColumn;
        private System.Windows.Forms.DataGridViewLinkColumn viewerColumn;
    }
}