﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Security.Principal;
using System.Windows.Forms;
using Mcs.Epm.Asp.Net.Properties;
using Microsoft.SqlServer.Management.Smo;
using Settings=Mcs.Epm.Asp.Net.Properties.Settings;

namespace Mcs.Epm.Asp.Net.Forms
{
    /// <summary>
    /// Implements a simple user interface for consuming SessionMonitor
    /// </summary>
    public partial class MainForm : Form
    {
        #region Instance Data

        private WindowsImpersonationContext _ImpersonationContext;
        private WindowsIdentity _Identity;
        private IntPtr _Token;
        private string _LastServerExamined;
        private SessionMonitor _SessionMonitor;

        #endregion

        #region Constructors

        public MainForm()
        {
            InitializeComponent();

            serverToolStripComboBox.Text = Settings.Default.LastSqlServer;
            databasesToolStripComboBox.Text = Settings.Default.LastDatabase;
        }

        #endregion

        #region Private Methods

        private bool Login()
        {
            using (CredentialsForm credentialsForm = new CredentialsForm())
            {
                DialogResult result = credentialsForm.ShowDialog(this);

                switch (result)
                {
                    case DialogResult.OK:
                        return Impersonate(credentialsForm.UserName, credentialsForm.Domain, credentialsForm.Password);
                    case DialogResult.Ignore:
                        //  Use current credentials
                        return true;
                    case DialogResult.Cancel:
                        Close();
                        break;
                    default:
                        throw new ArgumentOutOfRangeException();
                }
            }
            return false;
        }

        private bool Impersonate(string userName, string domain, string password)
        {
            try
            {
                if (Win32Impersonation.LogonUser(userName,
                                                 domain,
                                                 password,
                                                 out _Token))
                {
                    _Identity = new WindowsIdentity(_Token);
                    _ImpersonationContext = _Identity.Impersonate();

                    return true;
                }

                if (MessageBox.Show(this,
                                    Resources.LoginFailed,
                                    Resources.AppTitle,
                                    MessageBoxButtons.OKCancel,
                                    MessageBoxIcon.Exclamation) == DialogResult.Cancel)
                {
                    return false;
                }

                return Login();
            }
            catch (Exception)
            {
                UndoImpersonation();
                return false;
            }
        }

        private void UndoImpersonation()
        {
            if (_ImpersonationContext != null)
            {
                _ImpersonationContext.Undo();
                _ImpersonationContext.Dispose();
            }

            if (_Identity != null)
            {
                _Identity.Dispose();
            }

            if (_Token != IntPtr.Zero)
            {
                Win32Impersonation.CloseHandle(_Token);
            }
        }

        private void PopuluateSqlServers()
        {
            serverToolStripComboBox.Items.Clear();

            try
            {
                DataTable sqlServer = SmoApplication.EnumAvailableSqlServers(false);

                foreach (DataRow row in sqlServer.Rows)
                {
                    serverToolStripComboBox.Items.Add(row["Name"]);
                }

            }
            catch (Exception exception)
            {
                MessageBox.Show(this, 
                                exception.Message, 
                                Resources.AppTitle, 
                                MessageBoxButtons.OK, 
                                MessageBoxIcon.Error);
            }
        }

        private void LoadDatabaseList()
        {
            databasesToolStripComboBox.Items.Clear();

            try
            {
                Server server = new Server(serverToolStripComboBox.Text);

                foreach (Database database in server.Databases)
                {
                    databasesToolStripComboBox.Items.Add(database.Name);
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(this,
                                exception.Message,
                                Resources.AppTitle,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
            }

        }

        private void BeginMonitor()
        {
            EndMonitor();

            sessionListView.Items.Clear();

            try
            {
                _SessionMonitor = new SessionMonitor(serverToolStripComboBox.Text,
                                                     databasesToolStripComboBox.Text,
                                                     Convert.ToInt32(intervalToolStripTextBox.Text));

                _SessionMonitor.OnNewSession += _SessionMonitor_OnNewSession;
                _SessionMonitor.OnSessionRemoved += _SessionMonitor_OnSessionRemoved;
                _SessionMonitor.OnNewItem += _SessionMonitor_OnNewItem;
                _SessionMonitor.OnItemUpdated += _SessionMonitor_OnItemUpdated;
                _SessionMonitor.OnItemRemoved += _SessionMonitor_OnItemRemoved;
                _SessionMonitor.OnExceptionThrown += _SessionMonitor_OnExceptionThrown;

                _SessionMonitor.BeginMonitor();
            }
            catch (Exception exception)
            {
                MessageBox.Show(this, 
                                exception.Message,
                                Resources.AppTitle,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);                

            }
        }

        void OnExceptionThrown(object sender, Exception exception)
        {
            MessageBox.Show(this,
                            exception.Message,
                            Resources.AppTitle,
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Error);

            EndMonitor();
            monitorToolStripButton.Image = Resources.bullet_green;
        }

        void _SessionMonitor_OnExceptionThrown(object sender, Exception exception)
        {
            Invoke(new SessionMonitor.OnExceptionThrownEventHandler(OnExceptionThrown), new[] {sender, exception});
        }

        private void EndMonitor()
        {
            try
            {
                sessionListView.Items.Clear();
                treeView.Nodes.Clear();
                sessionDataDataGridView.Rows.Clear();

                if (_SessionMonitor != null)
                {
                    _SessionMonitor.OnNewSession -= _SessionMonitor_OnNewSession;
                    _SessionMonitor.OnSessionRemoved -= _SessionMonitor_OnSessionRemoved;
                    _SessionMonitor.OnNewItem -= _SessionMonitor_OnNewItem;
                    _SessionMonitor.OnItemUpdated -= _SessionMonitor_OnItemUpdated;
                    _SessionMonitor.OnItemRemoved -= _SessionMonitor_OnItemRemoved;

                    _SessionMonitor.EndMonitor();
                    _SessionMonitor.Dispose();
                    _SessionMonitor = null;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(this,
                                exception.Message,
                                Resources.AppTitle,
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);                
            }


        }

        private void UpdateSessionDataFromId(string sessionId)
        {
            if (sessionListView.SelectedItems.Count != 1)
            {
                return;
            }

            if (sessionListView.SelectedItems[0].Text.Equals(sessionId, StringComparison.CurrentCultureIgnoreCase))
            {
                LoadSessionData(sessionId);
            }
        }

        private void SetMonitorButtonEnabledState()
        {
            monitorToolStripButton.Enabled = !string.IsNullOrEmpty(databasesToolStripComboBox.Text) &&
                                             !string.IsNullOrEmpty(serverToolStripComboBox.Text);
        }

        private void LoadSessionData(string sessionId)
        {
            Dictionary<string, ArrayList> sessionData = _SessionMonitor.GetSessionDetails(sessionId);

            if (sessionData == null)
            {
                return;
            }

            foreach (KeyValuePair<string, ArrayList> pair in sessionData)
            {
                TreeNode valueRoot = null;

                foreach (TreeNode treeNode in treeView.Nodes)
                {
                    if (treeNode.Text.Equals(pair.Key, StringComparison.CurrentCultureIgnoreCase))
                    {
                        valueRoot = treeNode;
                        break;
                    }
                }
                if (valueRoot == null)
                {
                    valueRoot = treeView.Nodes.Add(pair.Key);
                }

                valueRoot.Tag = pair.Value;
            }

            if (treeView.SelectedNode != null)
            {
                ArrayList values = treeView.SelectedNode.Tag as ArrayList;

                UpdateValues(values);
            }

        }

        private void UpdateValues(ArrayList values)
        {
            sessionDataDataGridView.Rows.Clear();

            if (values == null)
            {
                return;
            }

            foreach (object value in values)
            {
                Type type = value.GetType();

                if (type.IsPrimitive || type.Name.Equals("string", StringComparison.CurrentCultureIgnoreCase))
                {
                    sessionDataDataGridView.Rows.Add(value.ToString(), "");
                }
                else
                {
                    int index = sessionDataDataGridView.Rows.Add(type.Name, "View");
                    sessionDataDataGridView.Rows[index].Tag = value;
                }
            }
        }

        private void ShowViewer(object value)
        {
            using (PropertyBrowserForm propertyBrowserForm = new PropertyBrowserForm(value))
            {
                propertyBrowserForm.ShowDialog(this);
            }
        }

        #endregion

        #region Event Handlers

        private void MainForm_Shown(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;

            if (!Login())
            {
                Close();
            }

            Cursor = Cursors.Default;
        }

        private void MainForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            EndMonitor();
            UndoImpersonation();

            Settings.Default.LastSqlServer = serverToolStripComboBox.Text;
            Settings.Default.LastDatabase = databasesToolStripComboBox.Text;
            Settings.Default.Save();
        }

        private void databasesToolStripComboBox_DropDown(object sender, EventArgs e)
        {
            if (!serverToolStripComboBox.Text.Equals(_LastServerExamined, StringComparison.CurrentCultureIgnoreCase))
            {
                Cursor = Cursors.WaitCursor;
                LoadDatabaseList();
                Cursor = Cursors.Default;
                _LastServerExamined = serverToolStripComboBox.Text;
            }
        }

        private void serverToolStripComboBox_TextChanged(object sender, EventArgs e)
        {
            databasesToolStripComboBox.Enabled = !string.IsNullOrEmpty(serverToolStripComboBox.Text);
        }

        private void databasesToolStripComboBox_TextChanged(object sender, EventArgs e)
        {
            SetMonitorButtonEnabledState();
        }

        private void monitorToolStripButton_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(intervalToolStripTextBox.Text))
            {
                intervalToolStripTextBox.Text = "0";
            }

            if (_SessionMonitor == null)
            {
                BeginMonitor();
                monitorToolStripButton.Image = Resources.bullet_red;
            }
            else
            {
                EndMonitor();
                monitorToolStripButton.Image = Resources.bullet_green;
            }
        }

        void OnNewSession(object sender, string sessionId, DateTime created, DateTime expires, int timeOut)
        {
            ListViewItem item = new ListViewItem();

            item.Text = sessionId;
            item.SubItems.Add(created.ToString());
            item.SubItems.Add(expires.ToString());
            item.SubItems.Add(timeOut.ToString());

            sessionListView.Items.Add(item);        
        }

        void OnSessionRemoved(object sender, string sessionId)
        {
            for (int i = sessionListView.Items.Count - 1; i >= 0; i--)
            {
                ListViewItem item = sessionListView.Items[i];

                if (item.Text.Equals(sessionId, StringComparison.CurrentCultureIgnoreCase))
                {
                    sessionListView.Items.RemoveAt(i);
                    break;
                }
            }

            UpdateSessionDataFromId(sessionId);
        }

        void OnNewItem(object sender, string sessionId, string name, object item)
        {
            UpdateSessionDataFromId(sessionId);
        }

        void OnItemUpdated(object sender, string sessionId, string name, object value)
        {
            UpdateSessionDataFromId(sessionId);
        }
        
        void OnItemRemoved(object sender, string sessionId, string name)
        {
            RemoveSessionValueFromId(sessionId, name);
        }

        private void RemoveSessionValueFromId(string sessionId, string name)
        {
            if (sessionListView.SelectedItems.Count != 1)
            {
                return;
            }

            if (sessionListView.SelectedItems[0].Text.Equals(sessionId, StringComparison.CurrentCultureIgnoreCase))
            {
                for (int i = treeView.Nodes.Count - 1; i >= 0 ; i--)
                {
                    TreeNode node = treeView.Nodes[i];

                    if (node.Text.Equals(name, StringComparison.CurrentCultureIgnoreCase))
                    {
                        if (node.IsSelected)
                        {
                            sessionDataDataGridView.Rows.Clear();
                        }

                        treeView.Nodes.RemoveAt(i);
                    }
                }
            }
        }

        void _SessionMonitor_OnNewSession(object sender, string sessionId, DateTime created, DateTime expires, int timeOut)
        {
            Invoke(new SessionMonitor.OnNewSessionEventHandler(OnNewSession), new[] {sender, sessionId, created, expires, timeOut});
        }

        void _SessionMonitor_OnSessionRemoved(object sender, string sessionId)
        {
            Invoke(new SessionMonitor.OnSessionRemovedEventHandler(OnSessionRemoved), new[] { sender, sessionId });
        }

        void _SessionMonitor_OnNewItem(object sender, string sessionId, string name, object item)
        {
            Invoke(new SessionMonitor.OnNewItemEventHandler(OnNewItem), new[] { sender, sessionId, name, item });
        }

        void _SessionMonitor_OnItemUpdated(object sender, string sessionId, string name, object value)
        {
            Invoke(new SessionMonitor.OnItemUpdatedEventHandler(OnItemUpdated), new[] { sender, sessionId, name, value });
        }

        void _SessionMonitor_OnItemRemoved(object sender, string sessionId, string name)
        {
            Invoke(new SessionMonitor.OnItemRemovedEventHandler(OnItemRemoved), new[] { sender, sessionId, name });
        }

        private void serverToolStripComboBox_DropDown(object sender, EventArgs e)
        {
            Cursor = Cursors.WaitCursor;
            PopuluateSqlServers();
            Cursor = Cursors.Default;
        }

        private void sessionListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (sessionListView.SelectedItems.Count == 1)
            {
                LoadSessionData(sessionListView.SelectedItems[0].Text);
            }
            else
            {
                treeView.Nodes.Clear();
                sessionDataDataGridView.Rows.Clear();
            }
        }

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            ArrayList values = e.Node.Tag as ArrayList;

            UpdateValues(values);
        }

        private void sessionDataDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 1)  // 1 = "View" column
            {
                ShowViewer(sessionDataDataGridView.Rows[e.RowIndex].Tag);
            }
        }

        #endregion


        
    }
}