﻿using System.Windows.Forms;

namespace Mcs.Epm.Asp.Net.Forms
{
    /// <summary>
    /// Implements a simple property browser for session items
    /// </summary>
    public partial class PropertyBrowserForm : Form
    {
        #region Instance Data

        private readonly object _Value;
        private readonly PropertyGrid _PropertyGrid;

        #endregion

        #region Constructors

        public PropertyBrowserForm(object value)
        {
            InitializeComponent();
            _Value = value;

            _PropertyGrid = new PropertyGrid();

            _PropertyGrid.Dock = DockStyle.Fill;
            _PropertyGrid.SelectedObject = _Value;
            _PropertyGrid.Text = "Session Item Browser";
            
                Controls.Add(_PropertyGrid);

        }

        #endregion

    }
}
