﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Data.SqlClient;
using System.IO;
using System.Security.Principal;
using System.Threading;
using System.Web;
using System.Web.SessionState;

namespace Mcs.Epm.Asp.Net
{
    /// <summary>
    /// Implements session monitoring for ASP.NET session state stored in SQL Server 2005
    /// </summary>
    public class SessionMonitor : IDisposable
    {
        #region Public Delegates

        public delegate void OnNewItemEventHandler(object sender, string sessionId, string name, object item);
        public delegate void OnItemUpdatedEventHandler(object sender, string sessionId, string name, object value);
        public delegate void OnItemRemovedEventHandler(object sender, string sessionId, string name);
        public delegate void OnNewSessionEventHandler(object sender, string sessionId, DateTime created, DateTime expires, int timeOut);
        public delegate void OnSessionRemovedEventHandler(object sender, string sessionId);
        public delegate void OnExceptionThrownEventHandler(object sender, Exception exception);

        #endregion

        #region Instance Data

        private bool _Disposed;
        private readonly object _SimpleLock = new object();

        private readonly int _PollInterval;
        private readonly string _Database;
        private readonly string _Server;

        private readonly ManualResetEvent _StopRequestEvent = new ManualResetEvent(false);
        private readonly ManualResetEvent _StoppedEvent = new ManualResetEvent(false);

        private SqlCommand _SqlCommand;
        private SqlConnection _SqlConnection;

        private Dictionary<string, Dictionary<string, ArrayList>> _Sessions;
        private Thread _WorkerThread;
        private WindowsIdentity _Identity;
        private WindowsImpersonationContext _WindowsImpersonationContext;

        #endregion

        #region Constructor

        /// <summary>
        /// Construct an instance of SessionMonitor
        /// </summary>
        /// <param name="server">The SQL Server</param>
        /// <param name="database">The state database</param>
        /// <param name="pollInterval">The interval for which to poll</param>
        public SessionMonitor(string server,
                              string database,
                              int pollInterval)
        {
            _Server = server;
            _Database = database;
            _PollInterval = pollInterval;
        }

        #endregion

        #region Public Events

        public event OnNewSessionEventHandler OnNewSession;
        public event OnSessionRemovedEventHandler OnSessionRemoved;
        public event OnNewItemEventHandler OnNewItem;
        public event OnItemUpdatedEventHandler OnItemUpdated;
        public event OnItemRemovedEventHandler OnItemRemoved;
        public event OnExceptionThrownEventHandler OnExceptionThrown;
        #endregion

        #region Public Methods

        /// <summary>
        /// Begin monitoring
        /// </summary>
        public void BeginMonitor()
        {
            EndMonitor();

            _Sessions = new Dictionary<string, Dictionary<string, ArrayList>>();
            _Identity = WindowsIdentity.GetCurrent();

            _WorkerThread = new Thread(MonitorThread);
            _WorkerThread.Start();

        }

        public void MonitorThread()
        {
            try
            {
                _WindowsImpersonationContext = _Identity.Impersonate();

                const string connection = "data source={0}; trusted_connection=true;Asynchronous Processing=true;initial catalog={1}";

                _SqlConnection = new SqlConnection(string.Format(connection, _Server, _Database));

                _SqlConnection.Open();

                _SqlCommand = new SqlCommand("SELECT Locked, SessionID, SessionItemShort, SessionItemLong, Created, Expires FROM ASPStateTempSessions", _SqlConnection);

                _SqlCommand.BeginExecuteReader(ReadSessionData, _SqlCommand);

                _StoppedEvent.WaitOne();
            }
            catch (Exception exception)
            {
                _StoppedEvent.Set();
                if (OnExceptionThrown != null)
                {
                    OnExceptionThrown(this, exception);
                }
            }
            finally
            {
                _WindowsImpersonationContext.Undo();
            }
        }

        /// <summary>
        /// End monitoring
        /// </summary>
        public void EndMonitor()
        {
            if (_WorkerThread != null && _WorkerThread.IsAlive)
            {
                _StopRequestEvent.Set();

                while (!_StoppedEvent.WaitOne(0)) { }
            }

            if (_SqlCommand != null)
            {
                _SqlCommand.Dispose();
                _SqlCommand = null;
            }

            if (_SqlConnection != null)
            {
                _SqlConnection.Close();
                _SqlConnection.Dispose();
                _SqlConnection = null;
            }
        }

        /// <summary>
        /// Return a dictionary of session IDs and an array list of values
        /// </summary>
        /// <param name="sessionID">The session (ASP.NET Session) ID</param>
        /// <returns></returns>
        public Dictionary<string, ArrayList> GetSessionDetails(string sessionID)
        {
            if (Sessions.ContainsKey(sessionID))
            {
                return Sessions[sessionID];
            }
            return null;
        }

        #endregion

        #region Private Properties

        private Dictionary<string, Dictionary<string, ArrayList>> Sessions
        {
            get
            {
                lock (_SimpleLock)
                {
                    return _Sessions;
                }
            }
        }

        #endregion

        #region Private Static Methods

        private static void GetSessionItemCollections(byte[] bytes,
                                                      out SessionStateItemCollection items,
                                                      out HttpStaticObjectsCollection objects)
        {
            using (MemoryStream memoryStream = new MemoryStream(bytes))
            {
                BinaryReader binaryReader = new BinaryReader(memoryStream);

                binaryReader.ReadInt32();

                bool hasItems = binaryReader.ReadBoolean();
                bool hasStaticObjects = binaryReader.ReadBoolean();

                items = hasItems ? SessionStateItemCollection.Deserialize(binaryReader) : null;

                objects = hasStaticObjects ? HttpStaticObjectsCollection.Deserialize(binaryReader) : null;
            }
        }

        private static int GetSessionTimeOut(byte[] bytes)
        {
            using (MemoryStream memoryStream = new MemoryStream(bytes))
            {
                BinaryReader binaryReader = new BinaryReader(memoryStream);

                return binaryReader.ReadInt32();
            }
        }

        #endregion

        #region Private Methods

        private void ReadSessionData(IAsyncResult result)
        {
            if (_SqlCommand == null)
            {
                return;
            }
            if (_StopRequestEvent.WaitOne(0))
            {
                _SqlCommand.EndExecuteReader(result).Dispose();
                _StoppedEvent.Set();
                return;
            }

            using (SqlCommand asynchCommand = result.AsyncState as SqlCommand)
            {
                if (asynchCommand == null)
                {
                    return;
                }

                List<string> currentSessions = new List<string>();

                using (SqlDataReader reader = _SqlCommand.EndExecuteReader(result))
                {
                    while (reader.Read())
                    {
                        string sessionId = (string)reader["SessionID"];

                        currentSessions.Add(sessionId);

                        if (!Sessions.ContainsKey(sessionId))
                        {
                            Sessions.Add(sessionId, new Dictionary<string, ArrayList>());

                            int timeOut = -1;

                            if (reader["SessionItemShort"] != DBNull.Value)
                            {
                                timeOut = GetSessionTimeOut((byte[])reader["SessionItemShort"]);
                            }

                            if (OnNewSession != null)
                            {
                                OnNewSession(this,
                                             sessionId,
                                             DateTime.Parse(reader["Created"].ToString()),
                                             DateTime.Parse(reader["Expires"].ToString()),
                                             timeOut);
                            }
                        }

                        SessionStateItemCollection sessionItems;
                        HttpStaticObjectsCollection staticObjects;

                        if (reader["SessionItemShort"] != DBNull.Value)
                        {
                            GetSessionItemCollections((byte[])reader["SessionItemShort"],
                                                      out sessionItems,
                                                      out staticObjects);

                            SynchCollections(sessionId, sessionItems);
                        }

                        if (reader["SessionItemLong"] != DBNull.Value)
                        {
                            GetSessionItemCollections((byte[])reader["SessionItemLong"],
                                                      out sessionItems,
                                                      out staticObjects);
                            SynchCollections(sessionId, sessionItems);
                        }

                        if (_StopRequestEvent.WaitOne(0))
                        {
                            break;
                        }
                    }

                    reader.Close();

                    SynchSession(currentSessions);

                    Thread.Sleep(_PollInterval);

                    try
                    {
                        _SqlCommand.BeginExecuteReader(ReadSessionData, _SqlCommand);
                    }
                    catch (Exception exception)
                    {
                        _StoppedEvent.Set();

                        if (OnExceptionThrown != null)
                        {
                            OnExceptionThrown(this, exception);
                        }
                    }
                    finally
                    {
                        _WindowsImpersonationContext.Undo();
                    }
                }
            }
        }

        private void SynchSession(ICollection<string> currentSessions)
        {
            List<string> deletedSessions = new List<string>();

            foreach (string key in Sessions.Keys)
            {
                if (!currentSessions.Contains(key))
                {
                    deletedSessions.Add(key);
                }
            }

            foreach (string session in deletedSessions)
            {
                Sessions.Remove(session);

                if (OnSessionRemoved != null)
                {
                    OnSessionRemoved(this, session);
                }
            }
        }

        private void SynchCollections(string sessionId, SessionStateItemCollection sessionItems)
        {
            if (sessionItems != null)
            {
                SynchUpdateCollection(sessionItems, sessionId);
                SynchDeleteCollection(sessionItems, sessionId);
            }
            else
            {
                SynchClearCollection(sessionId);
            }
        }

        private void SynchClearCollection(string sessionId)
        {
            Dictionary<string, ArrayList>.KeyCollection currentKeys = Sessions[sessionId].Keys;

            if (currentKeys.Count == 0)
            {
                return;
            }

            if (OnItemRemoved != null)
            {
                foreach (string key in currentKeys)
                {
                    OnItemRemoved(this, sessionId, key);
                }
            }

            Sessions[sessionId].Clear();
        }

        private void SynchDeleteCollection(NameObjectCollectionBase sessionItems, string sessionId)
        {
            Dictionary<string, ArrayList>.KeyCollection currentKeys = Sessions[sessionId].Keys;
            List<string> _deletedKeys = new List<string>();
            bool delete = true;

            foreach (string key in currentKeys)
            {
                foreach (string sessionKey in sessionItems.Keys)
                {
                    if (sessionKey == key)
                    {
                        delete = false;
                        break;
                    }
                }

                if (delete)
                {
                    _deletedKeys.Add(key);
                }

                delete = true;
            }

            foreach (string key in _deletedKeys)
            {
                Sessions[sessionId].Remove(key);

                OnItemRemoved(this, sessionId, key);
            }
        }

        private void SynchUpdateCollection(ISessionStateItemCollection sessionItems, string sessionId)
        {
            foreach (string key in sessionItems.Keys)
            {
                // New name/value pair
                if (!Sessions[sessionId].ContainsKey(key))
                {
                    Sessions[sessionId].Add(key, new ArrayList());
                }

                // Handle primitives + strings only (Boolean, Byte, SByte, Int16, UInt16, Int32, UInt32, Int64, UInt64, IntPtr, Char, Double, and Single.)
                if (sessionItems[key] != null)
                {
                    if (Sessions[sessionId][key].Count > 0) // See if the name/value pair exists
                    {
                        // Yes, check the last value to see if it matches the current value
                        if (Convert.ToString(Sessions[sessionId][key][Sessions[sessionId][key].Count - 1]) != Convert.ToString(sessionItems[key]))
                        {
                            //  Nope, item has changed.
                            Sessions[sessionId][key].Add(sessionItems[key]);
                            if (OnItemUpdated != null)
                            {
                                OnItemUpdated(this, sessionId, key, sessionItems[key]);
                            }
                        }
                    }
                    else
                    {
                        //  The name value/pair doesn't exist, add it 
                        if (OnNewItem != null)
                        {
                            OnNewItem(this, sessionId, key, sessionItems[key]);
                        }

                        Sessions[sessionId][key].Add(sessionItems[key]);
                    }
                }
            }
        }

        #endregion

        #region IDisposable Members

        private void Dispose(bool disposing)
        {
            if (!_Disposed)
            {
                if (disposing)
                {
                    EndMonitor();
                }

                _Disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        ~SessionMonitor()
        {
            Dispose(false);
        }

        #endregion
    }
}