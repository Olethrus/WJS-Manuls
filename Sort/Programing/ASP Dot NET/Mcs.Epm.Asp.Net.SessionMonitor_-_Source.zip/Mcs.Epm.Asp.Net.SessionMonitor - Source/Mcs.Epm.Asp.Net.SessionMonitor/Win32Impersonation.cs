﻿using System;
using System.Runtime.InteropServices;

namespace Mcs.Epm.Asp.Net
{
    /// <summary>
    /// Implements Win32 logon for use with impersonation
    /// </summary>
    public class Win32Impersonation
    {
        #region PInvoke 

        [DllImport("advapi32.dll", SetLastError = true)]
        private static extern bool LogonUser(string principal,
                                             string authority,
                                             string password,
                                             LogonSessionType logonType,
                                             LogonProvider logonProvider,
                                             out IntPtr token);

        [DllImport("kernel32.dll", SetLastError = true)]
        public static extern bool CloseHandle(IntPtr handle);

        #endregion

        #region Public Methods

        public static bool LogonUser(string userName,
                                     string domainName,
                                     string password,
                                     out IntPtr userToken)
        {
            return LogonUser(userName, domainName, password, LogonSessionType.Interactive, LogonProvider.WinNT50, out userToken);
        }

        public static int GetLastError()
        {
            return Marshal.GetLastWin32Error();
        }

        #endregion

        #region Nested type: LogonProvider

        private enum LogonProvider : uint
        {
            WinNT50 // negotiates Kerb or NTLM
        }

        #endregion

        #region Nested type: LogonSessionType

        private enum LogonSessionType : uint
        {
            Interactive = 2,
            Network,
            Batch,
            Service,
            NetworkCleartext = 8,
            NewCredentials
        }

        #endregion
    }
}