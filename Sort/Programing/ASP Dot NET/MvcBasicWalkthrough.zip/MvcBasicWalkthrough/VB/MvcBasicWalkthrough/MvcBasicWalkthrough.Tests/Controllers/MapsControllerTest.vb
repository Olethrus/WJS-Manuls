﻿Imports System
Imports System.Collections.Generic
Imports System.Text
Imports System.Web.Mvc
Imports Microsoft.VisualStudio.TestTools.UnitTesting
Imports MvcBasicWalkthrough

<TestClass()> _
Public Class MapsControllerTest

    <TestMethod()> _
    Public Sub ViewMaps()
        ' Arrange
        Dim controller As MvcBasicWalkthrough.MapsController = New MvcBasicWalkthrough.MapsController()

        ' Act
        Dim result As ViewResult = CType(controller.ViewMaps(), ViewResult)

        ' Assert
        Assert.IsNotNull(result)
    End Sub

End Class
