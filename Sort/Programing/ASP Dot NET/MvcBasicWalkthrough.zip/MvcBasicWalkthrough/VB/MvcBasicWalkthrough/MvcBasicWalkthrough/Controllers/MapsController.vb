Namespace MvcBasicWalkthrough
    Public Class MapsController
        Inherits System.Web.Mvc.Controller

        Function ViewMaps() As ActionResult
            Return View()
        End Function

    End Class
End Namespace
