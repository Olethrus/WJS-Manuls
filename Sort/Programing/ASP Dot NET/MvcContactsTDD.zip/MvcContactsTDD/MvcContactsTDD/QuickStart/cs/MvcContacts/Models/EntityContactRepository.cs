﻿using System.Collections.Generic;
using System.Linq;

namespace MvcContacts.Models {
    public class EF_ContactRepository : MvcContacts.Models.IContactRepository {

        private ContactEntities _db = new ContactEntities();

        public Contact GetContact(int id) {
            return _db.Contacts.FirstOrDefault(d => d.Id == id);
        }

        public IEnumerable<Contact> ListContacts() {
            return _db.Contacts.ToList();
        }

        public Contact CreateContact(Contact contactToCreate) {
            _db.AddToContacts(contactToCreate);
            _db.SaveChanges();
            return contactToCreate;
        }

        public int SaveChanges() {
            return _db.SaveChanges();
        }

        public void DeleteContact(int id) {
            var conToDel = GetContact(id);
            _db.Contacts.DeleteObject(conToDel);
            _db.SaveChanges();
        }

    }
} 

