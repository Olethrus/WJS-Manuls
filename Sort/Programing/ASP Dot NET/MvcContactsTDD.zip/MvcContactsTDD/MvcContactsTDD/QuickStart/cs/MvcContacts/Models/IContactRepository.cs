﻿using System;
using System.Collections.Generic;

namespace MvcContacts.Models {
    public interface IContactRepository {
        Contact CreateContact(Contact contactToCreate);
        void DeleteContact(int id);
        Contact GetContact(int id);
        IEnumerable<Contact> ListContacts();
        int SaveChanges();

    }
} 

