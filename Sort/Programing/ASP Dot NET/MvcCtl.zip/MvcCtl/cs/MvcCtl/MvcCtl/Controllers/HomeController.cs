﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcCtl.Controllers {

    class FileDetail {

        public byte[] fileBytes;
        public string mimeType { get; set; }
        public System.IO.FileStream _fs;
    }

    [HandleError]
    public class HomeController : Controller {

        [ValidateInput(false)]
        public ActionResult TestContent(bool id, string sMsg) {
            if (id == true)
                return Content(Server.HtmlEncode((sMsg.ToLower())));
            else
                return Content(Server.HtmlEncode(sMsg));
        }

        public ActionResult TstContent(bool id, string sMsg) {

            if (id == true)
                return Content(Server.HtmlEncode(
                    Server.UrlDecode(sMsg.ToLower())));
            else
                return Content(Server.HtmlEncode(
                    Server.UrlDecode(sMsg)));
        }


        [ValidateInput(false)]
        public ActionResult TstContentConType(bool id, string sMsg) {
            string contentType = "text/plain";
            if (id == false)
                contentType = "text/html";

            return Content(Server.HtmlEncode(sMsg), contentType);
        }

        [ValidateInput(false)]
        public ActionResult TstContentTypeEncoding(bool id, string sMsg) {
            string contentType = "text/plain";
            if (id == false)
                contentType = "text/html";

            return Content(Server.HtmlEncode(sMsg),
                           contentType, System.Text.Encoding.UTF8);
        }

        public ActionResult Index() {
            ViewData["Message"] = "Welcome to ASP.NET MVC!";

            return View();
        }


        string getImgPath(string fileNm) {
            if (fileNm.Contains(".."))
                return "";
            return Server.MapPath("~/Content/img/" + fileNm);
        }

        byte[] getFile(string s) {

            System.IO.FileStream fs = System.IO.File.OpenRead(s);
            byte[] data = new byte[fs.Length];
            int br = fs.Read(data, 0, data.Length);
            if (br != fs.Length)
                throw new System.IO.IOException(s);

            return data;
        }

        FileDetail GetFileDetails(int id) {
            string fileNm;
            switch (id) {
                case 0:
                    fileNm = "cnt.gif";
                    break;
                case 1:
                    fileNm = "FK_Mr_Ms.png";
                    break;
                case 2:
                    fileNm = "favicon.ico";
                    break;
                default:
                    return null;
            }
            return GetFileDetails(fileNm);
        }

       
        FileDetail GetFileDetailsStrm(string fileNm) {

            FileDetail fd = new FileDetail();
            fd.mimeType = Utilities.MimeType(fileNm);

            fd._fs = System.IO.File.OpenRead(getImgPath(fileNm));
            return fd;
        }

        FileDetail GetFileDetails(string fileNm) {

            FileDetail fd = new FileDetail();
            fd.mimeType = Utilities.MimeType(fileNm);

            fd.fileBytes = getFile(getImgPath(fileNm));
            return fd;

        }

        public ActionResult ShowFileId(int id) {

            FileDetail fd = GetFileDetails(id);
            if (fd == null) {
                ViewData["notFoundKey"] = "The requested file ID " + id.ToString() + "was not found";
                return View("NotFound");
            }
            return File(fd.fileBytes, fd.mimeType);
        }

        public ActionResult ShowFileNm(string id) {

            if (id.Contains(".."))
                return View();   // to return error

            string mimeType = Utilities.MimeType(id);
            string sFile = getFileLoc(id);
            if (string.IsNullOrEmpty(sFile))
                return View();
            string fp = Server.MapPath("~/Content/img/" + sFile);
            return File(fp, mimeType);
        }

        string getFileLoc(string id) {
            if (id.Contains("..") || id.Contains('~'))
                return null;
            return id;
        }

        public ActionResult ShowFileFN(string id) {
            string sFile = getFileLoc(id);
            if (string.IsNullOrEmpty(sFile))
                return View();

            string mp = Server.MapPath("~/Content/" + sFile);
            return File(mp, "text/html");
        }



        public ActionResult ShowFileFNdlNm(string id) {
            string sFile = getFileLoc(id);
            if (string.IsNullOrEmpty(sFile))
                return View();

            string mp = Server.MapPath("~/Content/" + sFile);
            return File(mp, "text/plain", id);
        }


        public ActionResult ShowFile(string id) {

            FileDetail fd = GetFileDetails(id);
            return File(fd.fileBytes, fd.mimeType);
        }

        public ActionResult ShowFileDLN(string id) {

            FileDetail fd = GetFileDetails(id);
            return File(fd.fileBytes, fd.mimeType, id);
        }

        public ActionResult ShowFileDLNStrm(string id) {
            FileDetail fd = GetFileDetailsStrm(id);
            return File(fd._fs, fd.mimeType, id);
        }

        protected override void HandleUnknownAction(string actionName) {
            try {
                this.View(actionName).ExecuteResult(this.ControllerContext);
            } catch (InvalidOperationException ieox) {
                ViewData["UA_error"] = "Unknown Action: \"" +
                    Server.HtmlEncode(actionName) + "\"";
                ViewData["exMessage"] = ieox.Message;
                this.View("UA_Error").ExecuteResult(this.ControllerContext);
            }
        }

        public ActionResult TestJavaScript() {
            string s = "$('#divResultText').html('JavaScript Passed');";
            return JavaScript(s);
        }

        public ActionResult About() {
            return View();
        }
    }
}
