﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MvcDA.Controllers {
    [HandleError]
    public class HomeController : Controller {
        AdventureWorksLT2008_DataEntities _db = new AdventureWorksLT2008_DataEntities();


        public Product GetProduct(int id) {
            return _db.Product.FirstOrDefault(d => d.ProductID == id);
        }

        // Allow Null ID
        public Product GetProductN(int? id) {

            if (id.HasValue)
                GetProduct((int)id);

            var dn = _db.Product
                .Where(c => c.ProductID > 0)
                .First();

            return dn;
        }

        public ActionResult Edit(int id) {

            Product prd = GetProduct(id);

            if (prd == null) {
                ViewData["BogusProductID"] = id.ToString();
                return View("NotFound");
            }

            return View(prd);
        }

        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Edit(int id, FormCollection collection) {

            Product prd = GetProduct(id);

            if (!TryUpdateModel(prd)) {
                return View(prd);
            }


            // Persist changes back to database
            _db.SaveChanges();

            // Perform HTTP redirect to details page for the saved Dinner
            return RedirectToAction("Details", new { id = prd.ProductID });


        }

        public ActionResult Details(int? id) {

            if (!id.HasValue)
                ViewData["Null_ID"] = "No ID passed, using first ID found";

            Product prd = GetProductN(id);

            if (prd == null) {
                ViewData["BogusProductID"] = id.ToString();
                return View("NotFound");
            }

            return View(prd);
        }  // End of Details

        public ActionResult Index() {

            var dn = _db.Product
                             .Where(c => c.ProductID < 715 || c.ProductID > 999);

            return View(dn);
        }

        public ActionResult About() {
            return View();
        }
    }
}
