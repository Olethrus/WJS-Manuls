﻿Imports System.ComponentModel.DataAnnotations
' add ref to System.ComponentModel.DataAnnotations.DLL 
'Namespace MvcDA

<MetadataType(GetType(AddressMD))> _
Partial Public Class Address
End Class

Public Class AddressMD

    Private _AddressLine1 As Object
    <StringLength(60)> _
    <Required()> _
    Public Property AddressLine1() As Object
        Get
            Return _AddressLine1
        End Get
        Set(ByVal value As Object)
            _AddressLine1 = value
        End Set
    End Property
    Private _AddressLine2 As Object
    <StringLength(60)> _
    Public Property AddressLine2() As Object
        Get
            Return _AddressLine2
        End Get
        Set(ByVal value As Object)
            _AddressLine2 = value
        End Set
    End Property
    Private _StateProvince As Object
    <Required(), StringLength(50)> _
    Public Property StateProvince() As Object
        Get
            Return _StateProvince
        End Get
        Set(ByVal value As Object)
            _StateProvince = value
        End Set
    End Property
    Private _City As Object
    <Required(), StringLength(30)> _
    Public Property City() As Object
        Get
            Return _City
        End Get
        Set(ByVal value As Object)
            _City = value
        End Set
    End Property
    Private _CountryRegion As Object
    <Required(), StringLength(50)> _
    Public Property CountryRegion() As Object
        Get
            Return _CountryRegion
        End Get
        Set(ByVal value As Object)
            _CountryRegion = value
        End Set
    End Property
    Private _PostalCode As Object
    <Required(), StringLength(15)> _
    Public Property PostalCode() As Object
        Get
            Return _PostalCode
        End Get
        Set(ByVal value As Object)
            _PostalCode = value
        End Set
    End Property

End Class

'End Namespace
