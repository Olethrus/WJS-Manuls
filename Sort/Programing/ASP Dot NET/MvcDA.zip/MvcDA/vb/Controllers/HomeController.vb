﻿

<HandleError()> _
Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Dim _db As New AdventureWorksLT2008_DataEntities()

    Public Function GetAddress(ByVal id As System.Nullable(Of Integer)) As Address
        If id.HasValue Then
            Return _db.Address.First(Function(d) d.AddressID = id)
        Else
            Dim dn = _db.Address.Where(Function(c) c.AddressID > 0).First()

            Return dn

        End If
    End Function


    Function Index() As ActionResult
        Return View(_db.Address)
    End Function

    Public Function Edit(ByVal id As System.Nullable(Of Integer)) As ActionResult

        Dim adr As Address = GetAddress(id)

        If adr Is Nothing Then
            ViewData("BogusAddressID") = id.ToString()
            Return View("NotFound")
        End If

        Return View(adr)
    End Function

    <AcceptVerbs(HttpVerbs.Post)> _
    Public Function Edit(ByVal id As Integer, ByVal collection As FormCollection) As ActionResult

        Dim adr As Address = GetAddress(id)

        If Not TryUpdateModel(adr) Then
            Return View(adr)
        End If

        _db.SaveChanges()

        Return RedirectToAction("Details", New With {.id = adr.AddressID})
    End Function

    Public Function Details(ByVal id As System.Nullable(Of Integer)) As ActionResult

        If Not id.HasValue Then
            ViewData("Null_ID") = "No ID passed, using first ID found"
        End If


        Dim adr As Address = GetAddress(id)

        If adr Is Nothing Then
            ViewData("BogusAddressID") = id.ToString()
            Return View("NotFound")
        End If

        Return View(adr)
    End Function
    ' End of Details 

    Function About() As ActionResult
        Return View()
    End Function
End Class
