﻿Namespace MvcDataViews
    Public Class PersonController
        Inherits System.Web.Mvc.Controller

        Shared people As New List(Of Person)()

        '
        ' GET: /Person

        Function Index() As ActionResult
            Return View(people)
        End Function

        '
        ' GET: /Person/Details/5

        Function Details(ByVal p As Person) As ActionResult
            Return View(p)
        End Function

        '
        ' GET: /Person/Create

        Function Create() As ActionResult
            Return View()
        End Function

        '
        ' POST: /Person/Create

        <HttpPost()> _
        Function Create(ByVal p As Person) As ActionResult
            If Not ModelState.IsValid Then
                Return View("Create", p)
            End If

            people.Add(p)

            Return RedirectToAction("Index")
        End Function

        '
        ' GET: /Person/Delete/5

        Function Delete(ByVal id As Integer) As ActionResult
            Dim p As New Person()
            For Each pn As Person In people
                If pn.Id = id Then
                    p.Name = pn.Name
                    p.Age = pn.Age
                    p.Id = pn.Id
                    p.Phone = pn.Phone
                    p.Email = pn.Email
                End If
            Next

            Return View(p)
        End Function

        '
        ' POST: /Person/Delete/5

        <HttpPost()> _
        Function Delete(ByVal p As Person) As ActionResult
            For Each pn As Person In people
                If (pn.Id = p.Id) Then
                    people.Remove(pn)
                    Exit For
                End If
            Next

            Return RedirectToAction("Index")
        End Function

        '
        ' GET: /Person/Edit/5

        Function Edit(ByVal id As Integer) As ActionResult
            Dim p As New Person()
            For Each pn As Person In people
                If pn.Id = id Then
                    p.Name = pn.Name
                    p.Age = pn.Age
                    p.Id = pn.Id
                    p.Phone = pn.Phone
                    p.Email = pn.Email
                End If
            Next

            Return View(p)
        End Function

        '
        ' POST: /Person/Edit/5

        <HttpPost()> _
        Function Edit(ByVal p As Person) As ActionResult
            If Not ModelState.IsValid Then
                Return View("Edit", p)
            End If

            For Each pn As Person In people
                If pn.Id = p.Id Then
                    pn.Name = p.Name
                    pn.Age = p.Age
                    pn.Id = p.Id
                    pn.Phone = p.Phone
                    pn.Email = p.Email
                End If
            Next

            Return RedirectToAction("Index")
        End Function
    End Class
End Namespace