﻿Imports System.Web.DynamicData
Imports System.ComponentModel.DataAnnotations

Public Class Person
    <Required(ErrorMessage:="The ID is required.")> _
    Private _Id As Integer
    Public Property Id() As Integer
        Get
            Return _Id
        End Get
        Set(ByVal value As Integer)
            _Id = value
        End Set
    End Property

    <Required(ErrorMessage:="The name is required.")> _
    Private _Name As String
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(ByVal value As String)
            _Name = value
        End Set
    End Property

    <Range(1, 200, ErrorMessage:="A number between 1 and 200.")> _
    Private _Age As Integer
    Public Property Age() As Integer
        Get
            Return _Age
        End Get
        Set(ByVal value As Integer)
            _Age = value
        End Set
    End Property

    <RegularExpression("((\(\d{3}\) ?)|(\d{3}-))?\d{3}-\d{4}", _
            ErrorMessage:="Invalid phone number.")> _
    Private _Phone As String
    Public Property Phone() As String
        Get
            Return _Phone
        End Get
        Set(ByVal value As String)
            _Phone = value
        End Set
    End Property

    <RegularExpression("^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$", _
            ErrorMessage:="Invalid email address.")> _
    Private _Email As String
    Public Property Email() As String
        Get
            Return _Email
        End Get
        Set(ByVal value As String)
            _Email = value
        End Set
    End Property
End Class
