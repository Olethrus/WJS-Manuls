﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Globalization;
using System.Web.UI;

using MvcRemoteValCS.Models;

namespace MvcRemoteValCS.Controllers {
    [HandleError]
    public class HomeController : Controller {
        // <snippet6>

        public ActionResult Index() {
            return View(UsrLstContainer.getUsrLst());
        }

        public ActionResult About() {
            return View();
        }

        public ViewResult Details(string id) {
            return View(GetUser(id));
        }

        public ActionResult Edit(string id) {
            return View(GetUser(id));
        }

        [HttpPost]
        public ActionResult Edit(UserModel um) {
            if (!TryUpdateModel(um))
                return View(um);

            // ToDo: add persistent to DB.
            UsrLstContainer.getUsrLstContainer().Update(um);
            return View("Details", um);
        }

        public ViewResult Create() {
            return View(new UserModel());
        }

        [HttpPost]
        public ActionResult Create(UserModel um) {
            if (!TryUpdateModel(um) ||
                !UserNameHelper.IsAvailable(um.UserName))
                return View(um);

            // ToDo: add persistent to DB.
            UsrLstContainer.getUsrLst().Add(um);
            return View("Details", um);
        }

        UserModel GetUser(string uid) {
            UserModel usrMdl = null;

            foreach (UserModel um in UsrLstContainer.getUsrLst())
                if (um.UserName == uid)
                    usrMdl = um;

            return usrMdl;
        }
        
        // </snippet6>
    }

    // <snippet7>
    public static class UsrLstContainer {
        static UserList _usrLst2 = new UserList();
        public static List<UserModel> getUsrLst() {
            return _usrLst2._usrList;
        }
        public static UserList getUsrLstContainer() {
            return _usrLst2;
        }
    } 
    // </snippet7>

}
