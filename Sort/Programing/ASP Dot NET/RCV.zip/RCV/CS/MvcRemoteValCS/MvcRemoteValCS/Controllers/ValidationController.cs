﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Globalization;
using System.Web.UI;

using MvcRemoteValCS.Models;

namespace MvcRemoteValCS.Controllers {
    public class ValidationController : Controller {
        [OutputCache(Location = OutputCacheLocation.None, NoStore = true)]

        // <snippet8>
        public string IsUID_Available(string candidate) {

            if (UserNameHelper.IsAvailable(candidate))
                return "OK";

            for (int i = 1; i < 10; i++) {
                string altCandidate = candidate + i.ToString();
                if (UserNameHelper.IsAvailable(altCandidate))
                    return String.Format(CultureInfo.InvariantCulture,
                   "{0} is not available. Try {1}.", candidate, altCandidate);
            }
            return String.Format(CultureInfo.InvariantCulture,
                "{0} is not available.", candidate);
        } 
        // </snippet8>

    }
}
