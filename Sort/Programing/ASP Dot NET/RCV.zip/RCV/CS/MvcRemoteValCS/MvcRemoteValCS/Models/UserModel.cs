﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

using MvcRemoteValCS.Validation;

namespace MvcRemoteValCS.Models {

    public class UserModel {
        // <snippet4>
        [Required()]
        [DisplayName("User Name")]
        [RegularExpression(@"(\S)+", ErrorMessage= "White space is not allowed")]
        [RemoteUID_(Controller = "Validation", Action = "IsUID_Available", ParameterName = "candidate")]
        [ScaffoldColumn(false)]
        public string UserName { get; set; }
        // </snippet4>

        [Required()]
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [Required()]
        [DisplayName("Last Name")]
        public string LastName { get; set; }
        public string City { get; set; }
  //      [Range(16,120)]
  //      public int Age { get; set; }
    } 


    public class UserList {

        public  UserList() {
            _usrList.Add(new UserModel
            {
                UserName = "Ben",
                FirstName = "Ben",
                LastName = "Miller",
     //           Age = 33,
                City = "Seattle"
            });
            _usrList.Add(new UserModel
            {
                UserName = "Ann",
                FirstName = "Ann",
                LastName = "Beebe",
//                Age = 43,
                City = "Boston"
            });
        }


        public List<UserModel> _usrList = new List<UserModel>();

        public void Update(UserModel umToUpdate) {

            foreach (UserModel um in _usrList) {
                if (um.UserName == umToUpdate.UserName) {
                    _usrList.Remove(um);
                    _usrList.Add(umToUpdate);
                    break;
                }
            }
        }
    }

}
