﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using  MvcRemoteValCS.Controllers ;
using MvcRemoteValCS.Models;

namespace MvcRemoteValCS {
    internal static class UserNameHelper {
        private static List<string> _userNames = new List<string>();

        public static bool IsAvailable(string candidate) {

            foreach (UserModel um in UsrLstContainer.getUsrLst()) {
                if (string.Equals(um.UserName, candidate, StringComparison.OrdinalIgnoreCase))
                    return false;
            }

            return true;
        }
    } 
}

