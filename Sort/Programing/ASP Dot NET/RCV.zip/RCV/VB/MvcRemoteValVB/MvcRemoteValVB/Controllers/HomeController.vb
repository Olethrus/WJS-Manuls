﻿Imports MvcRemoteValVB.UserModel
Imports System.Globalization

<HandleError()> _
Public Class HomeController
    Inherits System.Web.Mvc.Controller

    ' <snippet6>
    Function Index() As ActionResult
        Return View(UsrLstContainer.getUsrLst())
    End Function

    Public Function Details(ByVal id As String) As ViewResult
        Return View(GetUser(id))
    End Function

    Function About() As ActionResult
        Return View()
    End Function

    Public Function Edit(ByVal id As String) As ActionResult
        Return View(GetUser(id))
    End Function

    <HttpPost()> _
    Public Function Edit(ByVal um As UserModel) As ActionResult
        If Not TryUpdateModel(um) Then
            Return View(um)
        End If

        ' ToDo: add persistent to DB.
        UsrLstContainer.getUsrLstContainer().Update(um)
        Return View("Details", um)
    End Function

    Public Function Create() As ViewResult
        Return View(New UserModel())
    End Function

    <HttpPost()> _
    Public Function Create(ByVal um As UserModel) As ActionResult
        If Not TryUpdateModel(um) OrElse Not UserNameHelper.IsAvailable(um.UserName) Then
            Return View(um)
        End If

        UsrLstContainer.getUsrLst().Add(um)
        Return View("Details", um)
    End Function

    Private Function GetUser(ByVal uid As String) As UserModel
        Dim usrMdl As UserModel = Nothing

        For Each um As UserModel In UsrLstContainer.getUsrLst()
            If um.UserName = uid Then
                usrMdl = um
            End If
        Next

        Return usrMdl
    End Function

    ' </snippet6>
End Class

' <snippet7>
Public Module UsrLstContainer

    Private _usrLst2 As New UserList()
    Public Function getUsrLst() As List(Of UserModel)
        Return _usrLst2._usrList
    End Function
    Public Function getUsrLstContainer() As UserList
        Return _usrLst2
    End Function
End Module
' </snippet7>