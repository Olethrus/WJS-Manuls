﻿Imports MvcRemoteValVB
Imports System.Globalization

Namespace MvcRemoteValVB
    Public Class ValidationController
        Inherits System.Web.Mvc.Controller
        ' <snippet8>
        Public Function IsUID_Available(ByVal candidate As String) As String

            If UserNameHelper.IsAvailable(candidate) Then
                Return "OK"
            End If

            For i As Integer = 1 To 9
                Dim altCandidate As String = candidate + i.ToString()
                If UserNameHelper.IsAvailable(altCandidate) Then
                    Return [String].Format(CultureInfo.InvariantCulture, "{0} is not available. Try {1}.", candidate, altCandidate)
                End If
            Next
            Return [String].Format(CultureInfo.InvariantCulture, "{0} is not available.", candidate)
        End Function
        ' </snippet8>

    End Class
End Namespace