﻿Imports System.ComponentModel
Imports System.ComponentModel.DataAnnotations


Public Class UserModel
    ' </snippet4>
    Private _UserName As String
    <RemoteUID_(Controller:="Validation", Action:="IsUID_Available", ParameterName:="candidate")> _
   <Required()> _
   <DisplayName("User Name")> _
   <RegularExpression("(\S)+")> _
   <ScaffoldColumn(False)> _
   Public Property UserName() As String
        Get
            Return _UserName
        End Get
        Set(ByVal value As String)
            _UserName = value
        End Set
    End Property
    ' </snippet4>

    Private _FirstName As String
    <Required()> _
    <DisplayName("First Name")> _
    Public Property FirstName() As String
        Get
            Return _FirstName
        End Get
        Set(ByVal value As String)
            _FirstName = value
        End Set
    End Property
    Private _LastName As String
    <Required()> _
    <DisplayName("Last Name")> _
    Public Property LastName() As String
        Get
            Return _LastName
        End Get
        Set(ByVal value As String)
            _LastName = value
        End Set
    End Property
    Private _City As String
    Public Property City() As String
        Get
            Return _City
        End Get
        Set(ByVal value As String)
            _City = value
        End Set
    End Property


End Class

Public Class UserList

    Public Sub New()
        Dim um As New UserModel()
        um.UserName = "Ben"
        um.FirstName = "Ben"
        um.LastName = "Miller"
        um.City = "Seattle"
        _usrList.Add(um)
        Dim um2 As New UserModel()
        um2.UserName = "Ann"
        um2.FirstName = "Ann"
        um2.LastName = "Beebe"
        um2.City = "Boston"
        _usrList.Add(um2)
    End Sub


    Public _usrList As New List(Of UserModel)()

    Public Sub Update(ByVal umToUpdate As UserModel)

        For Each um As UserModel In _usrList
            If um.UserName = umToUpdate.UserName Then
                _usrList.Remove(um)
                _usrList.Add(umToUpdate)
                Exit For
            End If
        Next
    End Sub
End Class

