﻿

Friend Module UserNameHelper
    Private _userNames As New List(Of String)()

    Public Function IsAvailable(ByVal candidate As String) As Boolean

        For Each um As UserModel In UsrLstContainer.getUsrLst()
            If String.Equals(um.UserName, candidate, StringComparison.OrdinalIgnoreCase) Then
                Return False
            End If
        Next

        Return True
    End Function
End Module

