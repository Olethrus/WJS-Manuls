﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.ComponentModel.DataAnnotations

Imports MvcRemoteValVB

' <snippet2>
Public NotInheritable Class RemoteUID_Attribute
    Inherits ValidationAttribute
    Private _Action As String
    Public Property Action() As String
        Get
            Return _Action
        End Get
        Set(ByVal value As String)
            _Action = value
        End Set
    End Property
    Private _Controller As String
    Public Property Controller() As String
        Get
            Return _Controller
        End Get
        Set(ByVal value As String)
            _Controller = value
        End Set
    End Property
    Private _ParameterName As String
    Public Property ParameterName() As String
        Get
            Return _ParameterName
        End Get
        Set(ByVal value As String)
            _ParameterName = value
        End Set
    End Property
    Private _RouteName As String
    Public Property RouteName() As String
        Get
            Return _RouteName
        End Get
        Set(ByVal value As String)
            _RouteName = value
        End Set
    End Property

    Public Overloads Overrides Function IsValid(ByVal value As Object) As Boolean
        Return True
    End Function
End Class
' </snippet2>