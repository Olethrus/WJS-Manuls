﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations
Imports System.Linq
Imports System.Web
Imports System.Web.Mvc
Imports System.Web.Routing

' <snippet1>
Public Class RemoteValidator
    Inherits DataAnnotationsModelValidator(Of RemoteUID_Attribute)

    Public Sub New(ByVal metadata As ModelMetadata, ByVal context As ControllerContext, ByVal attribute As RemoteUID_Attribute)
        MyBase.New(metadata, context, attribute)
    End Sub

    Public Overloads Overrides Function GetClientValidationRules() As IEnumerable(Of ModelClientValidationRule)
        Dim rule As New ModelClientValidationRule()
        rule.ErrorMessage = ErrorMessage
        rule.ValidationType = "remoteVal"
        rule.ValidationParameters("url") = GetUrl()
        rule.ValidationParameters("parameterName") = Attribute.ParameterName
        Return New ModelClientValidationRule() {rule}
    End Function

    Private Function GetUrl() As String
        Dim rvd As New RouteValueDictionary()
        rvd.Add("controller", Attribute.Controller)
        rvd.Add("action", Attribute.Action)

        Dim virtualPath = RouteTable.Routes.GetVirtualPath(ControllerContext.RequestContext, Attribute.RouteName, rvd)
        If virtualPath Is Nothing Then
            Throw New InvalidOperationException("No route matched!")
        End If

        Return virtualPath.VirtualPath
    End Function

End Class
' </snippet1>