using System;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using System.Xml.Serialization;
using System.ComponentModel;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

using ASPNETLibrary.SharePoint.WebParts;

namespace MyCompany.MyProject.WebParts
{
    [XmlRoot(Namespace = "MyCompany.MyProject.WebParts")]
    [GuidAttribute("f0bb74d4-940f-4386-bf70-b5daebf0b719")]
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:SampleWebPart runat=server></{0}:SampleWebPart>")]
    public partial class SampleWebPart : BaseSkinnedWebPart
    {
        #region [Methods]

        protected override void Initialize(Control skin)
        {
            //TODO: add any extra initialization here (like attaching to Button.Click events,
            //setting the initial data to server controls, etc)
        }

        #endregion [Methods]

        public SampleWebPart()
        {
            this.ExportMode = WebPartExportMode.All;
        }
    }
}