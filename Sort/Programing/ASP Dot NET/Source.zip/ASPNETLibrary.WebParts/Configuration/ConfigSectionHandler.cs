using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace ASPNETLibrary.WebParts.Configuration
{
    /// <summary>
    /// This class will read the configuration section for 
    /// web parts configuration provider that should be used.
    /// </summary>
    public class ConfigSectionHandler : IConfigurationSectionHandler
    {
        #region IConfigurationSectionHandler Members

        public object Create(object parent, object configContext, System.Xml.XmlNode section)
        {
            ProvidersConfiguration providersConfig = new ProvidersConfiguration();
            providersConfig.ProviderName = section.SelectSingleNode("providerName").InnerText;
            providersConfig.CustomData = section.SelectSingleNode("customData").InnerText;

            return providersConfig;
        }

        #endregion
    }
}
