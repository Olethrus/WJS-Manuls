﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using MvcTmpHlprs.Models; 

namespace MvcTmpHlprs.Controllers {
    [HandleError]
    public class HomeController : Controller {

        PalsLst _palsLst;
      
        public ActionResult DetailsHN() {

            Person p = new Person("Smith", 3457);
            
            return View(p);
        }

        [HttpPost]
        public String EditHN(Street pas, Street ps) {
            return "you entered the Person.Address.Street value: " + pas.num
                + " Person.Street value: " + ps.num; 
        }

        public ActionResult EditHN() {
            return View();
        }

        public ActionResult NonMdlVal() {
           
            return View();
        }


        public ActionResult IndexPals() {

          //  PalsLst pl = new PalsLst();

            return View(_palsLst._PalsLst);
        }

         public ActionResult DetailsPals(int id) {
            return View(GetPal(id)); 
        }

         public ActionResult DetailsPalsSame(int id) {
             return View(GetPal(id));
         }

        public ActionResult DetailsPalsMdl(int id) {
            return View(GetPal(id));
        }

        public ActionResult DetailsPalsMdlTmplt(int id) {
            return View(GetPal(id));
        }

        public ActionResult CreatePals() {
            Pals p = new Pals();
            return View(p);
        }

        [HttpPost]
        public ActionResult CreatePals(Pals pal) {

            try {
                UpdateModel(pal);

                _palsLst.Add(pal);
                return RedirectToAction("IndexPals");
            } catch (Exception ex) {   // For Demo purpose only
                // Production apps should not display exception data.
#if DEBUG
                ViewData["EditError"] = ex.Message;
#endif
                foreach (var modelState in ModelState.Values) {
                    foreach (var error in modelState.Errors) {
                        if (error.Exception != null) {
                            throw modelState.Errors[0].Exception;
                        }
                    }
                }
            }

            return View(pal);

        }

        // Html.EditorFor(Pals => Pals)
        public ActionResult EditPals(int id) {
            return View(GetPal(id));
        }

        [HttpPost]
        public ActionResult EditPals(Pals pal) {
  //          string[] x = { "ID" };
            if (!TryUpdateModel(pal))   
                return View(pal);

            _palsLst.Update(pal);
            return View("DetailsPals", pal);
        }

        // Html.EditorForModel()
        public ActionResult EditPalsMdl(int id) {
            return View(GetPal(id));
        }

        [HttpPost]
        public ActionResult EditPalsMdl(Pals pal) {
            if (!TryUpdateModel(pal))
                return View(pal);

            _palsLst.Update(pal);
            return View("DetailsPals", pal);
        }

        // Html.EditorForModel("Template")
        public ActionResult EditPalsMdlTmplt(int id) {
            return View(GetPal(id));
        }

        [HttpPost]
        public ActionResult EditPalsMdlTmplt(Pals pal) {
            if (!TryUpdateModel(pal))
                return View(pal);

            _palsLst.Update(pal);
            return View("DetailsPals", pal);
        }

        Pals GetPal(int id) {

            Pals pal = null;

            foreach (Pals p in _palsLst._PalsLst)
                if (p.ID == id)
                    pal = p;
            return pal;

        }

      

        // Html.LabelFor(Pals => Pals.Height), Html.EditorFor(Pals => Pals.Height
        // Lists each property
        public ActionResult EditPals2(int id) {
            return View(GetPal(id)); 
        }


        [HttpPost]
        public ActionResult EditPals2(Pals pal) {
            if (!TryUpdateModel(pal))
                return View(pal);

            _palsLst.Update(pal);
            return View("DetailsPals", pal);
        }

        public ActionResult About() {
            return View();
        }


        // Persist Pals via Session - For Demo Only

        protected override void OnActionExecuting(ActionExecutingContext filterContext) {
            if (Session["data"] == null) {
                _palsLst = new PalsLst();
            } else {
                _palsLst = (PalsLst)Session["data"];
            }
            base.OnActionExecuting(filterContext);

        }

        protected override void OnActionExecuted(ActionExecutedContext filterContext) {
            Session["data"] = _palsLst;
            base.OnActionExecuted(filterContext);
        }

    }  // End of controller.



}
