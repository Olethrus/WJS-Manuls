﻿using System.ComponentModel.DataAnnotations;

namespace MvcTmpHlprs.Models {
    [MetadataType(typeof(ProductMD))]
    public partial class Product {
        public class ProductMD {

            [ScaffoldColumn(false)]
            public object ProductID { get; set; }

            [ScaffoldColumn(false)]
            public object ProductCategoryID { get; set; }

            [ScaffoldColumn(false)]
            public object ProductModelID { get; set; }

            // Date template applied in Html.DisplayFor overload
            public object SellStartDate { get; set; }

            //[DataType("rbDate")]   // alternate approach to specify rbDate.ascx
            [UIHint("rbDate")]
            public object SellEndDate { get; set; }
            [DataType(DataType.Date)]
            public object DiscontinuedDate { get; set; }

            
            public object Color { get; set; }
            [DataType(DataType.Currency)]
            public object StandardCost { get; set; }

            [DataType(DataType.Currency)]
            public object ListPrice { get; set; }

            [ScaffoldColumn(false)]
            public object ModifiedDate { get; set; }
            [ScaffoldColumn(false)]
            public object rowguid { get; set; }
             [ScaffoldColumn(false)]
            public object ThumbNailPhoto { get; set; }
            
            [ScaffoldColumn(false)]
            public object ThumbnailPhotoFileName { get; set; }
        }
    }
}
