﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace MvcTmpHlprs.Models {

    public class Person {
        public Person(string sn, int n) {
            addr = new Address();
            addr.streetName = sn;
            addr.street.num = n;
        }
        public Address addr { get; set; }
        public Street street { get; set; }
    }
    public class Address {
        public Address() {
            street = new Street();
            streetName = "Elm";
            street.num = 1234;
        }
        public Street street { get; set; }
        public string streetName { get; set; }
    }


    public class Street {
        public int num { get; set; }
    }

    public class Pet {
        public Pet(Pet p) {
            Weight = p.Weight;
            Fname = p.Fname;
        }
        public Pet(float w, string nm) {
            Weight = w;
            Fname = nm;
        }

        public float Weight { get; set; }
        public string Fname { get; set; }
    }

    public class Pals {
        [Range(33, 99)]
        public float Height { get; set; }
        [Required()]
        [StringLength(17)]
        public string Name { get; set; }
       [ScaffoldColumn(false)]
        public int ID { get; set; }
        public bool cool { get; set; }
        [DataType(DataType.EmailAddress)]
        [RegularExpression(@"^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$")]
        public string email { get; set; }
        [ScaffoldColumn(false)]
        [DataType(DataType.MultilineText)]
        public string Bio { get; set; }
    }
        

    public class PalsLst {

        public PalsLst() {
            _PalsLst.Add(new Pals
            {
                ID = 1,
                Name = "Rick",
                Height =  68.25F,
                cool = false,
                email = "a.b.com",
                Bio = "Born in the USA. \n Graduated in top 90%."
            });
            _PalsLst.Add(new Pals
            {
                ID = 2,
                Name = "Brad",
                Height = 77.0F,
                cool = true,
                email = "Brad.com",
                Bio = "Born in Japan. \n Graduated in top 5%."
            });
        }

        public List<Pals> _PalsLst = new List<Pals>();

        public void Update(Pals palToUpdate) {

            foreach (Pals pal in _PalsLst) {
                if (pal.ID == palToUpdate.ID) {
                    _PalsLst.Remove(pal);
                    _PalsLst.Add(palToUpdate);
                    break;
                }
            }
        }

        public int NextPalID() {
            int mxID = 0;
            foreach (Pals pal in _PalsLst) {
                if (pal.ID > mxID)
                    mxID = pal.ID;
            }
            mxID++;
            return mxID;
        }

        public void Add(Pals palToAdd) {

            palToAdd.ID = NextPalID();
            _PalsLst.Add(palToAdd);

        }
    }             // end of     public class PalsLst {


}
