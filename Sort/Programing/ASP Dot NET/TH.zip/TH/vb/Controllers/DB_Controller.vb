Public Class DB_Controller
    Inherits System.Web.Mvc.Controller

    Dim _db As AdventureWorksLT2008Entities = New AdventureWorksLT2008Entities

    'Function Index() As ActionResult
    '    Dim dn = _db.Product _
    '.Where(Function(c) c.ProductID < 715)
    '    Return View(dn)
    'End Function

    Function About() As ActionResult
        Return View()
    End Function

    Public Function GetProduct(ByVal id As Integer) As Product
        Return _db.Product.FirstOrDefault(Function(d) d.ProductID = id)
    End Function

    ' Allow Null ID
    Public Function GetProductN(ByVal id As System.Nullable(Of Integer)) As Product

        If id.HasValue Then
            GetProduct(CInt(id))
        End If

        Dim dn = _db.Product.Where(Function(c) c.ProductID > 0).First()

        Return dn
    End Function

    Public Function Edit(ByVal id As Integer) As ActionResult

        Dim prd As Product = GetProduct(id)

        If prd Is Nothing Then
            ViewData("BogusID") = id.ToString()
            Return View("NotFound")
        End If

        Return View(prd)
    End Function

    <HttpPost()> _
    Public Function Edit(ByVal id As Integer, ByVal collection As FormCollection) As ActionResult

        Dim prd As Product = GetProduct(id)

        Try
            If TryUpdateModel(prd) Then
                _db.SaveChanges()

                Return RedirectToAction("Details", New With {.id = prd.ProductID})
            End If
        Catch ex As Exception
            ' For Demo purpose only
            ' Production apps should not display exception data.
#If DEBUG Then
#End If
            ViewData("EditError") = ex.InnerException
        End Try

        ' For security reasons, only throw model errors in debug/development.
        ' To test this, remove comments from <%= Html.Hidden("ProductID", Model.ProductID)%>
        ' in ProdUsrCtl.ascx
#If DEBUG Then
        For Each modelState__1 In ModelState.Values
            For Each [error] In modelState__1.Errors
                If [error].Exception IsNot Nothing Then
                    Throw modelState__1.Errors(0).Exception
                End If
            Next
        Next
#End If

        Return View(prd)
    End Function

    Public Function Create() As ActionResult

        Dim prd As New Product()
        prd.SellEndDate = DateTime.Now
        prd.SellStartDate = DateTime.Now
        prd.DiscontinuedDate = DateTime.Now
        prd.ProductNumber = "Test Prod #" & DateTime.Now.Second.ToString()


        Return View(prd)
    End Function
    ' Notes Edit the .edmx file and add
    ' StoreGeneratedPattern="Computed" in the <!-- SSDL content -->
    ' to rowguid and ModifiedDate

    <HttpPost()> _
    Public Function Create(ByVal prd As Product) As ActionResult

        Try
            If TryUpdateModel(prd) Then
                prd.ProductCategoryID = 6
                ' hardcode required fields for demo only
                prd.ProductModelID = 27

                _db.AddToProduct(prd)
                _db.SaveChanges()

                Return RedirectToAction("Index")
            End If
        Catch ex As Exception
            ' For Demo purpose only
            ' Production apps should not display exception data.
            ViewData("EditError") = ex.InnerException
        End Try

        Return View(prd)
    End Function

    Public Function Index() As ActionResult
        Dim dn = _db.Product.Where(Function(c) c.ProductID < 715 OrElse c.ProductID > 999)

        Return View(dn)
    End Function

    Public Function Details(ByVal id As Integer) As ActionResult

        Dim prd As Product = GetProduct(id)

        If prd Is Nothing Then
            ViewData("BogusID") = id.ToString()
            Return View("NotFound")
        End If

        Return View(prd)
    End Function

    Public Function DetailsEF(ByVal id As Integer) As ActionResult

        Dim prd As Product = GetProduct(id)

        If prd Is Nothing Then
            ViewData("BogusID") = id.ToString()
            Return View("NotFound")
        End If

        Return View(prd)
    End Function
End Class

'Notes:  Edit the .edmx file and add
'  StoreGeneratedPattern="Computed" in the <!-- SSDL content -->
'to rowguid and ModifiedDate

