﻿
'Notes:  Edit the .edmx file and add
'  StoreGeneratedPattern="Computed" in the <!-- SSDL content -->
'to rowguid and ModifiedDate
<HandleError()> _
Public Class HomeController
    Inherits Controller

    Private _palsLst As PalsLst

    Public Function DetailsHN() As ActionResult

        Dim p As New Person("Smith", 3457)

        Return View(p)
    End Function

    <HttpPost()> _
    Public Function EditHN(ByVal pas As Street, ByVal ps As Street) As String
        Dim s As String = "you entered the Person.Address.Street value: " _
        & pas.num.ToString() & " Person.Street value: " + ps.num.ToString()
        Return (s)
    End Function

    Public Function NonMdlVal() As ActionResult
        Return View()
    End Function

    Public Function EditHN() As ActionResult
        Return View()
    End Function

    Public Function IndexPals() As ActionResult


        Return View(_palsLst._PalsLst.ToList())
    End Function

    Public Function DetailsPalsSame(ByVal id As Integer) As ActionResult
        Return View(GetPal(id))
    End Function

    Public Function DetailsPals(ByVal id As Integer) As ActionResult
        Return View(GetPal(id))
    End Function

    Public Function DetailsPalsMdl(ByVal id As Integer) As ActionResult
        Return View(GetPal(id))
    End Function

    Public Function DetailsPalsMdlTmplt(ByVal id As Integer) As ActionResult
        Return View(GetPal(id))
    End Function

    Public Function CreatePals() As ActionResult
        Dim p As New Pals()
        Return View(p)
    End Function

    <HttpPost()> _
    Public Function CreatePals(ByVal pal As Pals) As ActionResult

        Try
            UpdateModel(pal)

            _palsLst.Add(pal)
            Return RedirectToAction("IndexPals")
        Catch ex As Exception
            ' For Demo purpose only
            ' Production apps should not display exception data.
#If DEBUG Then
            ViewData("EditError") = ex.Message
#End If
            For Each modelState__1 In ModelState.Values
                For Each [error] In modelState__1.Errors
                    If [error].Exception IsNot Nothing Then
                        Throw modelState__1.Errors(0).Exception
                    End If
                Next
            Next
        End Try


        Return View(pal)
    End Function

    ' Html.EditorFor(Pals => Pals)
    Public Function EditPals(ByVal id As Integer) As ActionResult
        Return View(GetPal(id))
    End Function

    <HttpPost()> _
    Public Function EditPals(ByVal pal As Pals) As ActionResult
        If Not TryUpdateModel(pal) Then
            Return View(pal)
        End If

        _palsLst.Update(pal)
        Return View("DetailsPals", pal)
    End Function

    ' Html.EditorForModel()
    Public Function EditPalsMdl(ByVal id As Integer) As ActionResult
        Return View(GetPal(id))
    End Function

    <HttpPost()> _
    Public Function EditPalsMdl(ByVal pal As Pals) As ActionResult
        If Not TryUpdateModel(pal) Then
            Return View(pal)
        End If

        _palsLst.Update(pal)
        Return View("DetailsPals", pal)
    End Function

    ' Html.EditorForModel("Template")
    Public Function EditPalsMdlTmplt(ByVal id As Integer) As ActionResult
        Return View(GetPal(id))
    End Function

    <HttpPost()> _
    Public Function EditPalsMdlTmplt(ByVal pal As Pals) As ActionResult
        If Not TryUpdateModel(pal) Then
            Return View(pal)
        End If

        _palsLst.Update(pal)
        Return View("DetailsPals", pal)
    End Function

    Private Function GetPal(ByVal id As Integer) As Pals

        Dim pal As Pals = Nothing

        For Each p As Pals In _palsLst._PalsLst
            If p.ID = id Then
                pal = p
            End If
        Next

        Return pal
    End Function



    ' Html.LabelFor(Pals => Pals.Height), Html.EditorFor(Pals => Pals.Height
    ' Lists each property
    Public Function EditPals2(ByVal id As Integer) As ActionResult
        Return View(GetPal(id))
    End Function


    <HttpPost()> _
    Public Function EditPals2(ByVal pal As Pals) As ActionResult
        If Not TryUpdateModel(pal) Then
            Return View(pal)
        End If

        _palsLst.Update(pal)
        Return View("DetailsPals", pal)
    End Function

    Public Function About() As ActionResult
        Return View()
    End Function


    ' Persist Pals via Session - For Demo Only

    Protected Overloads Overrides Sub OnActionExecuting(ByVal filterContext As ActionExecutingContext)
        If Session("data") Is Nothing Then
            _palsLst = New PalsLst()
        Else
            _palsLst = DirectCast(Session("data"), PalsLst)
        End If

        MyBase.OnActionExecuting(filterContext)
    End Sub

    Protected Overloads Overrides Sub OnActionExecuted(ByVal filterContext As ActionExecutedContext)
        Session("data") = _palsLst
        MyBase.OnActionExecuted(filterContext)
    End Sub

End Class
' End of controller.