﻿Imports System.ComponentModel.DataAnnotations

<MetadataType(GetType(ProductMD))> _
Partial Public Class Product
End Class

Public Class ProductMD


    'Private _ProductID As Object
    'Public Property ProductID() As Object
    '    Get
    '        Return _ProductID
    '    End Get
    '    Set(ByVal value As Object)
    '        _ProductID = value
    '    End Set
    'End Property

    Private _ProductID As Object
    <ScaffoldColumn(False)> _
    Public Property ProductID() As Object
        Get
            Return _ProductID
        End Get
        Set(ByVal value As Object)
            _ProductID = value
        End Set
    End Property


    Private _SellStartDate As Object
    Public Property SellStartDate() As Object
        Get
            Return _SellStartDate
        End Get
        Set(ByVal value As Object)
            _SellStartDate = value
        End Set
    End Property
    Private _SellEndDate As Object
    <UIHint("rbDate")> _
    Public Property SellEndDate() As Object
        Get
            Return _SellEndDate
        End Get
        Set(ByVal value As Object)
            _SellEndDate = value
        End Set
    End Property
    Private _DiscontinuedDate As Object
    <DataType(DataType.Date)> _
    Public Property DiscontinuedDate() As Object
        Get
            Return _DiscontinuedDate
        End Get
        Set(ByVal value As Object)
            _DiscontinuedDate = value
        End Set
    End Property
    Private _ModifiedDate As Object
    <ScaffoldColumn(False)> _
    Public Property ModifiedDate() As Object
        Get
            Return _ModifiedDate
        End Get
        Set(ByVal value As Object)
            _ModifiedDate = value
        End Set
    End Property
    Private _rowguid As Object
    <ScaffoldColumn(False)> _
    Public Property rowguid() As Object
        Get
            Return _rowguid
        End Get
        Set(ByVal value As Object)
            _rowguid = value
        End Set
    End Property
    Private _ThumbnailPhotoFileName As Object
    <ScaffoldColumn(False)> _
    Public Property ThumbnailPhotoFileName() As Object
        Get
            Return _ThumbnailPhotoFileName
        End Get
        Set(ByVal value As Object)
            _ThumbnailPhotoFileName = value
        End Set
    End Property

End Class