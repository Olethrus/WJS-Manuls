﻿Imports System.Collections.Generic
Imports System.ComponentModel.DataAnnotations


Public Class Person
    Public Sub New(ByVal sn As String, ByVal n As Integer)
        addr = New Address()
        addr.streetName = sn
        addr.street.num = n
    End Sub
    Private _addr As Address
    Public Property addr() As Address
        Get
            Return _addr
        End Get
        Set(ByVal value As Address)
            _addr = value
        End Set
    End Property
    Private _street As Street
    Public Property street() As Street
        Get
            Return _street
        End Get
        Set(ByVal value As Street)
            _street = value
        End Set
    End Property
End Class
Public Class Address
    Public Sub New()
        street = New Street()
        streetName = "Elm"
        street.num = 1234
    End Sub
    Private _street As Street
    Public Property street() As Street
        Get
            Return _street
        End Get
        Set(ByVal value As Street)
            _street = value
        End Set
    End Property
    Private _streetName As String
    Public Property streetName() As String
        Get
            Return _streetName
        End Get
        Set(ByVal value As String)
            _streetName = value
        End Set
    End Property
End Class


Public Class Street
    Private _num As Integer
    Public Property num() As Integer
        Get
            Return _num
        End Get
        Set(ByVal value As Integer)
            _num = value
        End Set
    End Property
End Class


Public Class Pals
    Private _Height As Single
    <Required()> _
    <Range(33, 99)> _
    Public Property Height() As Single
        Get
            Return _Height
        End Get
        Set(ByVal value As Single)
            _Height = value
        End Set
    End Property
    Private _Name As String
    <Required()> _
    <StringLength(7)> _
    Public Property Name() As String
        Get
            Return _Name
        End Get
        Set(ByVal value As String)
            _Name = value
        End Set
    End Property
    Private _ID As Integer
    <ScaffoldColumn(False)> _
    Public Property ID() As Integer
        Get
            Return _ID
        End Get
        Set(ByVal value As Integer)
            _ID = value
        End Set
    End Property
    Private _cool As Boolean
    Public Property cool() As Boolean
        Get
            Return _cool
        End Get
        Set(ByVal value As Boolean)
            _cool = value
        End Set
    End Property
    Private _email As String
    <DataType(DataType.EmailAddress)> _
    <RegularExpression("^([0-9a-zA-Z]([-.\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\w]*[0-9a-zA-Z]\.)+[a-zA-Z]{2,9})$")> _
    Public Property email() As String
        Get
            Return _email
        End Get
        Set(ByVal value As String)
            _email = value
        End Set
    End Property
    Private _Bio As String
    <DataType(DataType.MultilineText)> _
    Public Property Bio() As String
        Get
            Return _Bio
        End Get
        Set(ByVal value As String)
            _Bio = value
        End Set
    End Property
End Class

Public Class Pet
    Public Sub New(ByVal p As Pet)
        Weight = p.Weight
        Fname = p.Fname
    End Sub
    Public Sub New(ByVal w As Single, ByVal nm As String)
        Weight = w
        Fname = nm
    End Sub

    Private _Weight As Single
    Public Property Weight() As Single
        Get
            Return _Weight
        End Get
        Set(ByVal value As Single)
            _Weight = value
        End Set
    End Property
    Private _Fname As String
    Public Property Fname() As String
        Get
            Return _Fname
        End Get
        Set(ByVal value As String)
            _Fname = value
        End Set
    End Property
End Class

Public Class PalsLst

    Public Sub New()
        Dim p As Pals = New Pals
        p.ID = 1
        p.Height = 66
        p.Name = "Rick"
        p.cool = False
        p.email = "a.b.com"
        p.Bio = "Born in the USA. \n Graduated in top 90%."
        _PalsLst.Add(p)

        Dim q As Pals = New Pals
        q.ID = 2
        q.Name = "Brad"
        q.Height = 77.0
        q.cool = True
        q.email = "Brad.com"
        q.Bio = "Born in Japan. \n Graduated in top 5%."
        _PalsLst.Add(q)
    End Sub

    Public _PalsLst As New List(Of Pals)()

    Public Sub Update(ByVal palToUpdate As Pals)

        For Each pal As Pals In _PalsLst
            If pal.ID = palToUpdate.ID Then
                _PalsLst.Remove(pal)
                _PalsLst.Add(palToUpdate)
                Exit For
            End If
        Next
    End Sub

    Public Function NextPalID() As Integer
        Dim mxID As Integer = 0
        For Each pal As Pals In _PalsLst
            If pal.ID > mxID Then
                mxID = pal.ID
            End If
        Next
        mxID += 1
        Return mxID
    End Function

    Public Sub Add(ByVal palToAdd As Pals)

        palToAdd.ID = NextPalID()

        _PalsLst.Add(palToAdd)
    End Sub
End Class
' end of public class PalsLst {


