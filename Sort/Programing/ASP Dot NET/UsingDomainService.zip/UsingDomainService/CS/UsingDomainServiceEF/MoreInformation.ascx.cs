﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;

namespace UsingDomainService
{
    // Perform all the operations to access the file that contains more information to display.
    // Display or hide the information.
    public partial class MoreInformation : System.Web.UI.UserControl
    {
      
        private string _filePath;

        // Phisical path of the application of the file 
        // to read.  This file contains more information to display.
        public string FilePath
        {
            get { return _filePath; }
            set { _filePath = value; }
        }


        // Read the additional information to display. 
        protected void Page_Init(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {

                // Get the physical path of the current application.
                string appPath = HttpRuntime.AppDomainAppPath;
                // Get the complete physical path of the file to read.
                string file = appPath + FilePath;
                StringBuilder buffer = new StringBuilder();

                try
                {
                    // Create an instance of StreamReader to read from the file.
                    // The using statement also closes the StreamReader.
                    using (StreamReader sr = new StreamReader(file))
                    {
                        string line;
                        // Read and buffer lines from the file until the end of 
                        // the file is reached.
                        while ((line = sr.ReadLine()) != null)
                        {
                            buffer.AppendLine(line);
                        }
                    }
                    // Write the file content to the page.
                   
                    ReadID.InnerHtml = buffer.ToString();
                }
                catch (Exception error)
                {
                    // Let the user know what went wrong.
                    buffer.AppendLine(error.Message);
                    ReadID.InnerHtml = buffer.ToString();
                }
            }

        }

        // Display or hide information.
        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            // Toggle visibility of the page element that
            // contains the information.
            ReadID.Visible = !ReadID.Visible;

            // Toggle the link button text accordingly.
            if (ReadID.Visible == true)
                LinkButton1.Text = "Hide...";
            else
                LinkButton1.Text = "Read...";
        }

    }
}