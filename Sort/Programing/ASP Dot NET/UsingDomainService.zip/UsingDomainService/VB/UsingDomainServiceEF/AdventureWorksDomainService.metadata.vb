﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.ComponentModel.DataAnnotations
Imports System.Data.Objects.DataClasses
Imports System.Linq
Imports System.ServiceModel.DomainServices.Hosting
Imports System.ServiceModel.DomainServices.Server

Namespace UsingDomainServiceEF


	' The MetadataTypeAttribute identifies ProductMetadata as the class
	' that carries additional metadata for the Product class.
	<MetadataTypeAttribute(GetType(Product.ProductMetadata))> _
	Partial Public Class Product

		' This class allows you to attach custom attributes to properties
		' of the Product class.
		'
		' For example, the following marks the Xyz property as a
		' required property and specifies the format for valid values:
		'    [Required]
		'    [RegularExpression("[A-Z][A-Za-z0-9]*")]
		'    [StringLength(32)]
		'    public string Xyz { get; set; }
		Friend NotInheritable Class ProductMetadata

			' Metadata classes are not meant to be instantiated.
			Private Sub New()
			End Sub

			' Custom logic: require Color field.
			Private privateColor As String
			<Required(AllowEmptyStrings := False, ErrorMessage := "Color is required")> _
			Public Property Color() As String
				Get
					Return privateColor
				End Get
				Set(ByVal value As String)
					privateColor = value
				End Set
			End Property

			Private privateDiscontinuedDate? As DateTime
			Public Property DiscontinuedDate() As DateTime?
				Get
					Return privateDiscontinuedDate
				End Get
				Set(ByVal value? As DateTime)
					privateDiscontinuedDate = value
				End Set
			End Property

			Private privateListPrice As Decimal
			Public Property ListPrice() As Decimal
				Get
					Return privateListPrice
				End Get
				Set(ByVal value As Decimal)
					privateListPrice = value
				End Set
			End Property

			' Custom logic: require that  
			' the date format does not show
			' current time.
			Private privateModifiedDate As DateTime
			<DataType(DataType.Date)> _
			Public Property ModifiedDate() As DateTime
				Get
					Return privateModifiedDate
				End Get
				Set(ByVal value As DateTime)
					privateModifiedDate = value
				End Set
			End Property

			Private privateName As String
			Public Property Name() As String
				Get
					Return privateName
				End Get
				Set(ByVal value As String)
					privateName = value
				End Set
			End Property

			Private privateProductCategory As ProductCategory
			Public Property ProductCategory() As ProductCategory
				Get
					Return privateProductCategory
				End Get
				Set(ByVal value As ProductCategory)
					privateProductCategory = value
				End Set
			End Property

			Private privateProductCategoryID? As Integer
			Public Property ProductCategoryID() As Integer?
				Get
					Return privateProductCategoryID
				End Get
				Set(ByVal value? As Integer)
					privateProductCategoryID = value
				End Set
			End Property

			Private privateProductID As Integer
			Public Property ProductID() As Integer
				Get
					Return privateProductID
				End Get
				Set(ByVal value As Integer)
					privateProductID = value
				End Set
			End Property

			Private privateProductModel As ProductModel
			Public Property ProductModel() As ProductModel
				Get
					Return privateProductModel
				End Get
				Set(ByVal value As ProductModel)
					privateProductModel = value
				End Set
			End Property

			Private privateProductModelID? As Integer
			Public Property ProductModelID() As Integer?
				Get
					Return privateProductModelID
				End Get
				Set(ByVal value? As Integer)
					privateProductModelID = value
				End Set
			End Property

			Private privateProductNumber As String
			Public Property ProductNumber() As String
				Get
					Return privateProductNumber
				End Get
				Set(ByVal value As String)
					privateProductNumber = value
				End Set
			End Property

			Private privaterowguid As Guid
			Public Property rowguid() As Guid
				Get
					Return privaterowguid
				End Get
				Set(ByVal value As Guid)
					privaterowguid = value
				End Set
			End Property

			Private privateSalesOrderDetails As EntityCollection(Of SalesOrderDetail)
			Public Property SalesOrderDetails() As EntityCollection(Of SalesOrderDetail)
				Get
					Return privateSalesOrderDetails
				End Get
				Set(ByVal value As EntityCollection(Of SalesOrderDetail))
					privateSalesOrderDetails = value
				End Set
			End Property

			Private privateSellEndDate? As DateTime
			Public Property SellEndDate() As DateTime?
				Get
					Return privateSellEndDate
				End Get
				Set(ByVal value? As DateTime)
					privateSellEndDate = value
				End Set
			End Property

			Private privateSellStartDate As DateTime
			Public Property SellStartDate() As DateTime
				Get
					Return privateSellStartDate
				End Get
				Set(ByVal value As DateTime)
					privateSellStartDate = value
				End Set
			End Property

			Private privateSize As String
			Public Property Size() As String
				Get
					Return privateSize
				End Get
				Set(ByVal value As String)
					privateSize = value
				End Set
			End Property

			Private privateStandardCost As Decimal
			Public Property StandardCost() As Decimal
				Get
					Return privateStandardCost
				End Get
				Set(ByVal value As Decimal)
					privateStandardCost = value
				End Set
			End Property

			Private privateThumbNailPhoto As Byte()
			Public Property ThumbNailPhoto() As Byte()
				Get
					Return privateThumbNailPhoto
				End Get
				Set(ByVal value As Byte())
					privateThumbNailPhoto = value
				End Set
			End Property

			Private privateThumbnailPhotoFileName As String
			Public Property ThumbnailPhotoFileName() As String
				Get
					Return privateThumbnailPhotoFileName
				End Get
				Set(ByVal value As String)
					privateThumbnailPhotoFileName = value
				End Set
			End Property

			Private privateWeight? As Decimal
			Public Property Weight() As Decimal?
				Get
					Return privateWeight
				End Get
				Set(ByVal value? As Decimal)
					privateWeight = value
				End Set
			End Property
		End Class
	End Class
End Namespace
