﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.ComponentModel.DataAnnotations
Imports System.Data
Imports System.Linq
Imports System.ServiceModel.DomainServices.EntityFramework
Imports System.ServiceModel.DomainServices.Hosting
Imports System.ServiceModel.DomainServices.Server

Namespace UsingDomainServiceEF


	' Implements application logic using the AdventureWorksLT_DataEntities context.
	' TODO: Add your application logic to these methods or in additional methods.
	' TODO: Wire up authentication (Windows/ASP.NET Forms) and uncomment the following to disable anonymous access
	' Also consider adding roles to restrict access as appropriate.
	' [RequiresAuthentication]
	<EnableClientAccess()> _
	Public Class AdventureWorksDomainService
		Inherits LinqToEntitiesDomainService(Of AdventureWorksLT_DataEntities1)

		' TODO: Consider
		' 1. Adding parameters to this method and constraining returned results, and/or
		' 2. Adding query methods taking different parameters.
		Public Function GetProducts() As IQueryable(Of Product)
			Return Me.ObjectContext.Products.OrderBy(Function(p) p.ProductID)
		End Function

		Public Sub InsertProduct(ByVal product As Product)
			If (product.EntityState <> EntityState.Detached) Then
				Me.ObjectContext.ObjectStateManager.ChangeObjectState(product, EntityState.Added)
			Else
				Me.ObjectContext.Products.AddObject(product)
			End If
		End Sub


		Public Sub UpdateProduct(ByVal currentProduct As Product)
			If (currentProduct.EntityState = EntityState.Detached) Then
				' Custom logic: set a lower limit for the price.
				If currentProduct.ListPrice < 5 Then
					Throw New ValidationException("The list price must be >= 5.")
				End If
				Me.ObjectContext.Products.AttachAsModified(currentProduct, Me.ChangeSet.GetOriginal(currentProduct))
				' Custom logic: set the date to the current value.
				currentProduct.ModifiedDate = DateTime.Today
			End If
		End Sub

		Public Sub DeleteProduct(ByVal product As Product)
			If (product.EntityState = EntityState.Detached) Then
				Me.ObjectContext.Products.Attach(product)
			End If
			Me.ObjectContext.Products.DeleteObject(product)
		End Sub
	End Class
End Namespace


