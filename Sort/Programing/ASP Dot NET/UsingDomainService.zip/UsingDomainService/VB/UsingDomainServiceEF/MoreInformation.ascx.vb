﻿Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.IO
Imports System.Text

Namespace UsingDomainService
	' Perform all the operations to access the file that contains more information to display.
	' Display or hide the information.
	Partial Public Class MoreInformation
		Inherits System.Web.UI.UserControl

		Private _filePath As String

		' Phisical path of the application of the file 
		' to read.  This file contains more information to display.
		Public Property FilePath() As String
			Get
				Return _filePath
			End Get
			Set(ByVal value As String)
				_filePath = value
			End Set
		End Property


		' Read the additional information to display. 
		Protected Sub Page_Init(ByVal sender As Object, ByVal e As EventArgs)
			If Not Page.IsPostBack Then

				' Get the physical path of the current application.
				Dim appPath As String = HttpRuntime.AppDomainAppPath
				' Get the complete physical path of the file to read.
				Dim file As String = appPath & FilePath
				Dim buffer As New StringBuilder()

				Try
					' Create an instance of StreamReader to read from the file.
					' The using statement also closes the StreamReader.
					Using sr As New StreamReader(file)
						Dim line As String
						' Read and buffer lines from the file until the end of 
						' the file is reached.
						line = sr.ReadLine()
						Do While line IsNot Nothing
							buffer.AppendLine(line)
							line = sr.ReadLine()
						Loop
					End Using
					' Write the file content to the page.

					ReadID.InnerHtml = buffer.ToString()
				Catch [error] As Exception
					' Let the user know what went wrong.
					buffer.AppendLine([error].Message)
					ReadID.InnerHtml = buffer.ToString()
				End Try
			End If

		End Sub

		' Display or hide information.
		Protected Sub LinkButton1_Click(ByVal sender As Object, ByVal e As EventArgs)
			' Toggle visibility of the page element that
			' contains the information.
			ReadID.Visible = Not ReadID.Visible

			' Toggle the link button text accordingly.
			If ReadID.Visible = True Then
				LinkButton1.Text = "Hide..."
			Else
				LinkButton1.Text = "Read..."
			End If
		End Sub

	End Class
End Namespace