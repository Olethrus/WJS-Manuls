using System;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Collections.Generic;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

namespace ASPNETLibrary.SharePoint.WebControls.Tests
{
    [XmlRoot(Namespace = "ASPNETLibrary.SharePoint.WebControls.Tests")]
    [Guid("b77c52fb-880b-4cff-a14b-c9e94d35260f")]
    [ToolboxData("<{0}:SPPagedGridViewTestWebPart runat=server></{0}:SPPagedGridViewTestWebPart>")]
    [Description("This web part will demonstrate the usage of SPPagedGridView control.")]
    public class SPPagedGridViewTestWebPart : Microsoft.SharePoint.WebPartPages.WebPart
    {
        #region Members
        private SPPagedGridView _usersGridView;
        #endregion Members

        #region Private constants

        /// <summary>
        /// This constant defines the number of users that will be shown
        /// per page (page size).
        /// </summary>
        private const int UsersCountPerPage = 10;
        private const string UsersGridViewID = "UsersGridView";
        #endregion Private constants

        public SPPagedGridViewTestWebPart()
        {
            this.ExportMode = WebPartExportMode.All;
        }

        #region Overrides
        protected override void CreateChildControls()
        {
            this._usersGridView = new SPPagedGridView();
            this._usersGridView.ID = SPPagedGridViewTestWebPart.UsersGridViewID;
            this._usersGridView.PageSize = SPPagedGridViewTestWebPart.UsersCountPerPage;
            if (!this.Page.IsPostBack)
            {
                //Current page index will be set to when page is opened for the
                //first time.
                this.SetDataGridSource(0);
            }
            this._usersGridView.AutoGenerateColumns = false;
            this._usersGridView.EnableTheming = true;
            this._usersGridView.AllowPaging = true;
            this._usersGridView.AllowSorting = false;
            this._usersGridView.EnableTheming = true;
            this._usersGridView.PageIndexChanging += new System.Web.UI.WebControls.GridViewPageEventHandler(_usersGridView_PageIndexChanging);

            this.InitializeGridColumns();
            this.Controls.Add(this._usersGridView);

            //PagerTemplate must be set to null after Controls.Add(this._usersGridView) and before DataBind()
            this._usersGridView.PagerTemplate = null;

            this._usersGridView.DataBind();

            base.CreateChildControls();
        }
        #endregion Overrides

        #region Event Handlers
        void _usersGridView_PageIndexChanging(object sender, System.Web.UI.WebControls.GridViewPageEventArgs e)
        {
            this._usersGridView.PageIndex = e.NewPageIndex;
            this.SetDataGridSource(this._usersGridView.PageIndex);
            this._usersGridView.DataBind();
        }
        #endregion Event Handlers

        #region Private methods
        private void InitializeGridColumns()
        {
            BoundField colUserID = new BoundField();
            colUserID.DataField = "UserID";
            colUserID.HeaderText = "UserID";
            this._usersGridView.Columns.Add(colUserID);

            BoundField colUsername = new BoundField();
            colUsername.DataField = "Username";
            colUsername.HeaderText = "Username";
            this._usersGridView.Columns.Add(colUsername);

            BoundField colFirstName = new BoundField();
            colFirstName.DataField = "FirstName";
            colFirstName.HeaderText = "First name";
            this._usersGridView.Columns.Add(colFirstName);

            BoundField colLastName = new BoundField();
            colLastName.DataField = "LastName";
            colLastName.HeaderText = "Last name";
            this._usersGridView.Columns.Add(colLastName);
        }

        private void SetDataGridSource(int currentPageIndex)
        {
            UsersHandler usersHandler = new UsersHandler();
            int pageSize = SPPagedGridViewTestWebPart.UsersCountPerPage;

            int totalUsers;
            List<User> users = usersHandler.GetUsersPaged(currentPageIndex, pageSize, out totalUsers);
            this._usersGridView.VirtualItemCount = totalUsers;
            this._usersGridView.DataSource = users;
        }
        #endregion Private methods
    }
}
