Test web part uses connection string from configuration file (web.config).
If there is no <connectionStrings> section in web.config file then it should be added. The resulting
section should look like this:
  <connectionStrings>
    <add name="ASPNETLibraryTestsConnectionString"
        connectionString="Data Source=.\SQLEXPRESS;Initial Catalog=ASPNETLibraryTest;Integrated Security=True;User Instance=True"
        providerName="System.Data.SqlClient" />
  </connectionStrings>

Where "Data Source" should be replaced with the name of SQL Server on a concrete server and if needed
"Integrated Security" should be replaced with "User ID=XXX;Password=YYY" where XXX stands for username and
YYY stands for password of an account with sufficient access rights to test database.
