using System;
using System.Collections.Generic;
using System.Text;

namespace ASPNETLibrary.SharePoint.WebControls.Tests
{
    internal class User
    {
        #region Private members
        private int _userID;
        private string _username;
        private string _firstName;
        private string _lastName;
        #endregion Private members

        #region Public properties
        public int UserID
        {
            get
            {
                return this._userID;
            }
            set
            {
                this._userID = value;
            }
        }

        public string Username
        {
            get
            {
                return this._username;
            }
            set
            {
                this._username = value;
            }
        }

        public string FirstName
        {
            get
            {
                return this._firstName;
            }
            set
            {
                this._firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return this._lastName;
            }
            set
            {
                this._lastName = value;
            }
        }

        #endregion Public properties
    }
}
