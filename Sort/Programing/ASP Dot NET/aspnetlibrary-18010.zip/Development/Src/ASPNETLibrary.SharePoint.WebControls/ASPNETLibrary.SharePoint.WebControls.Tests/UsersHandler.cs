using System;
using System.Collections.Generic;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace ASPNETLibrary.SharePoint.WebControls.Tests
{
    /// <summary>
    /// This is a sample class that will provide paged data for test
    /// web parts.
    /// </summary>
    internal class UsersHandler
    {
        private const string ConnectionString = "ASPNETLibraryTestsConnectionString";

        /// <summary>
        /// Returns a list of users for the specified page index.
        /// </summary>
        /// <param name="currentPageIndex">Index of page for which users should be
        /// retrieved.</param>
        /// <param name="pageSize">Number of items that are visible per page.</param>
        /// <param name="totalUsers">Output parameter that will be set to total
        /// number of found users or to zero in case there are no users in database.</param>
        /// <returns>Returns a list of User instances representing found users.</returns>
        public List<User> GetUsersPaged(int currentPageIndex, int pageSize, out int totalUsers)
        {
            List<User> retVal = null;
            totalUsers = 0;

            string connectionString = ConfigurationManager.ConnectionStrings[UsersHandler.ConnectionString].ConnectionString;
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = (SqlCommand)connection.CreateCommand();
                command.CommandType = CommandType.StoredProcedure;
                command.CommandText = "GetUsersPaged";

                command.Parameters.Add("PageIndex", System.Data.SqlDbType.Int).Value = currentPageIndex;
                command.Parameters.Add("PageSize", System.Data.SqlDbType.Int).Value = pageSize;

                connection.Open();

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    //First read all rows from database
                    retVal = this.GetCollection(reader);

                    //Now read total number of users
                    if (reader.NextResult())
                    {
                        if (reader.Read())
                        {
                            totalUsers = reader.GetInt32(0);
                        }
                    }

                    reader.Close();
                }
                connection.Close();
            }

            return retVal;
        }

        #region Private members
        /// <summary>
        ///  This method is used to get all user entries from provided data reader
        /// </summary>
        /// <param name="reader">The SQLDataReader used to read the User entries from data reader</param>
        /// <returns>Returns a list of User objects retrieved from the database</returns>
        private List<User> GetCollection(SqlDataReader reader)
        {
            List<User> retVal = new List<User>();
            while (reader.Read())
            {
                User user = new User();

                user.UserID = (int)reader["UserID"];
                user.Username = (string)reader["Username"];
                user.FirstName = (string)reader["FirstName"];
                user.LastName = (string)reader["LastName"];

                retVal.Add(user);
            }
            return retVal;
        }
        #endregion Private members
    }
}
