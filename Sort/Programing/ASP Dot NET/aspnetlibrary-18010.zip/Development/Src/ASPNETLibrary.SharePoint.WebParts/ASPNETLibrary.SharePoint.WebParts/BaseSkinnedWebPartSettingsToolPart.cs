using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebPartPages;

using ASPNETLibrary.SharePoint.WebParts.Resources;
using ASPNETLibrary.SharePoint.WebParts.Configuration;

namespace ASPNETLibrary.SharePoint.WebParts
{
    /// <summary>
    /// Implementation of a custom tool part that display a 
    /// customized user interface for defining the properties 
    /// of a Skinned Web Part inside of the tool pane.
    /// </summary>
    public class BaseSkinnedWebPartSettingsToolPart : ToolPart
    {
        #region [Constants]

        /// <summary>
        /// Name of MOSS document library that will hold web part skins.
        /// The folder strcuture should be like this:
        ///     - Themes
        ///         - Theme1Folder
        ///             - Skin1.ascx
        ///             - Skin2.ascx
        ///         - Theme2Folder
        ///             - Skin1.ascx
        ///             - Skin2.ascx
        /// </summary>
        internal const string ThemesDocLib = "Themes";

        #endregion [Constants]

        #region [Member variables]

        /// <summary>
        /// Will be filled-in with all themes from the themes root folder.
        /// </summary>
        private DropDownList _themeList;

        /// <summary>
        /// Will be filled-in with all skins in selected theme folder.
        /// </summary>
        private DropDownList _skinList;

        #endregion [Member variables]

        #region [Methods]

        public BaseSkinnedWebPartSettingsToolPart()
        {
            this.Title = BaseSkinnedWebPartResources.ToolPartTitle;
        }

        public override void ApplyChanges()
        {
            this.EnsureChildControls();

            BaseSkinnedWebPart baseSkinnedWebPart = (BaseSkinnedWebPart)base.ParentToolPane.SelectedWebPart;
            baseSkinnedWebPart.SkinName = this._skinList.SelectedValue;
            baseSkinnedWebPart.ThemeName = this._themeList.SelectedValue;
        }

        public override void CancelChanges()
        {
            this.LoadThemeList();
            this.LoadSkinList();
        }

        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            this._themeList = new DropDownList();
            this._themeList.AutoPostBack = true;
            this._themeList.SelectedIndexChanged += new EventHandler(this.ThemeList_SelectedIndexChanged);
            this.Controls.Add(this._themeList);

            this._skinList = new DropDownList();
            this.Controls.Add(this._skinList);
        }

        private void LoadSkinList()
        {
            string currentValue;
            BaseSkinnedWebPart skinnedWebPart = (BaseSkinnedWebPart)base.ParentToolPane.SelectedWebPart;
            if (this._skinList.Items.Count == 0)
            {
                currentValue = skinnedWebPart.SkinName;
            }
            else
            {
                currentValue = this._skinList.SelectedValue;
                this._skinList.Items.Clear();
            }

            string themeName = this._themeList.SelectedValue;
            try
            {
                WebPartSkin[] skins = ConfigHandler.Instance.GetSkins(themeName);
                if (skins != null)
                {
                    //Go through the skins and populate the
                    //skins list with names of skins
                    foreach (WebPartSkin skin in skins)
                    {
                        this._skinList.Items.Add(skin.Name);
                    }

                    //Set previously selected skin as selected item in drop down list
                    ListItem listItem = this._skinList.Items.FindByValue(currentValue);
                    if (listItem != null)
                    {
                        listItem.Selected = true;
                    }
                }
                else
                {
                    this._skinList.Items.Add(BaseSkinnedWebPartResources.SkinsCouldntBeLoaded);
                    skinnedWebPart.SkinName = null;
                }
            }
            catch (ArgumentException)
            {
                this._skinList.Items.Add(BaseSkinnedWebPartResources.SkinsCouldntBeLoaded);
                skinnedWebPart.SkinName = null;
            }
        }

        private void LoadThemeList()
        {
            this._themeList.Items.Clear();

            BaseSkinnedWebPart skinnedWebPart = (BaseSkinnedWebPart)base.ParentToolPane.SelectedWebPart;

            try
            {
                WebPartTheme[] themes = ConfigHandler.Instance.GetAllThemes();
                if (themes != null && themes.Length > 0)
                {
                    foreach (WebPartTheme theme in themes)
                    {
                        this._themeList.Items.Add(theme.Name);
                    }
                }
                else
                {
                    this._themeList.Items.Add(BaseSkinnedWebPartResources.ThemesDocumentLibraryNotPresent);
                    skinnedWebPart.ThemeName = null;
                }
            }
            catch (ArgumentException)
            {
                this._themeList.Items.Add(BaseSkinnedWebPartResources.ThemesDocumentLibraryNotPresent);
                skinnedWebPart.ThemeName = null;
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            if (this._themeList.Items.Count == 0)
            {
                this.LoadThemeList();
                this.LoadSkinList();
            }
            base.OnPreRender(e);
        }

        protected override void RenderToolPart(HtmlTextWriter output)
        {
            output.Write(BaseSkinnedWebPartResources.ThemeListCaption);
            this._themeList.RenderControl(output);

            output.WriteBreak();

            output.Write(BaseSkinnedWebPartResources.SkinListCaption);
            this._skinList.RenderControl(output);
        }

        public override void SyncChanges()
        {
        }

        private void ThemeList_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.LoadSkinList();
        }

        #endregion [Methods]
    }
}