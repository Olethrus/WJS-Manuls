using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace ASPNETLibrary.SharePoint.WebParts.Configuration
{
    /// <summary>
    /// A singleton class that handles configuration for 
    /// skinned web parts.
    /// </summary>
    public sealed class ConfigHandler
    {
        #region [Private members]
        private static ConfigHandler _instance = new ConfigHandler();
        private IConfigProvider _configProvider;
        #endregion [Private members]

        #region [Properties]
        /// <summary>
        /// Returns single instance of this class.
        /// </summary>
        public static ConfigHandler Instance
        {
            get
            {
                return ConfigHandler._instance;
            }
        }
        #endregion [Properties]

        #region [Constructors]
        private ConfigHandler()
        {
            //Get Configuration Provider based on value specified in configuration file
            //under the "webPartsConfiguration" section
            ProvidersConfiguration providersConfig = 
                (ProvidersConfiguration)ConfigurationManager.GetSection("webPartsConfiguration");

            if (providersConfig != null)
            {
                Type configProviderType = Type.GetType(providersConfig.ProviderName);
                this._configProvider = (IConfigProvider)Activator.CreateInstance(configProviderType, providersConfig.CustomData);
            }
            else
            {
                //If configuration provider is not specified we will use the default
                //configuration provider that works with SharePoint document library
                this._configProvider = new SPDocLibConfigProvider();
            }
        }
        #endregion [Constructors]

        #region [Public methods]
        /// <summary>
        /// This method gets a theme with the 
        /// specified name
        /// </summary>
        /// <param name="themeName">Name of a theme to be found</param>
        /// <returns>Returns a found theme
        /// or null if theme was not found.</returns>
        public WebPartTheme GetTheme(string themeName)
        {
            return this._configProvider.GetTheme(themeName);
        }

        /// <summary>
        /// This method will return all themes
        /// </summary>
        /// <returns>Returns an array of themes or null
        /// if there are no themes</returns>
        public WebPartTheme[] GetAllThemes()
        {
            return this._configProvider.GetAllThemes();
        }

        /// <summary>
        /// This method will return all skins for specified
        /// theme
        /// </summary>
        /// <param name="themeName">Name of a theme whose
        /// skins should be returned</param>
        /// <returns>Returns an array of found skins or null if 
        /// there are no skins for the theme with specified name
        /// </returns>
        public WebPartSkin[] GetSkins(string themeName)
        {
            return this._configProvider.GetSkins(themeName);
        }

        /// <summary>
        /// This method returns a skin for specified
        /// theme with the specified name
        /// </summary>
        /// <param name="themeName">Name of a theme where skin should
        /// be located</param>
        /// <param name="skinName">Name of a skin to search for</param>
        /// <returns>Returns found skin or null
        /// if skin was not found</returns>
        public WebPartSkin GetSkin(string themeName, string skinName)
        {
            return this._configProvider.GetSkin(themeName, skinName);
        }

        /// <summary>
        /// This method checks if a skin with specified path
        /// exists in data store for the concrete <see cref="IConfigProvider"/> implementation.
        /// </summary>
        /// <param name="skinPath">A path to a skin.</param>
        /// <returns>Returns true if skin exists and false if there is no
        /// sking at specified location.</returns>
        public bool SkinExists(string skinPath)
        {
            return this._configProvider.SkinExists(skinPath);
        }
        #endregion [Public methods]
    }
}
