using System;
using System.Collections.Generic;
using System.Text;

namespace ASPNETLibrary.SharePoint.WebParts.Configuration
{
    /// <summary>
    /// This interface declares methods that should
    /// retrieve themes and skins from a persistent storage
    /// (like Xml files, Database, etc).
    /// </summary>
    public interface IConfigProvider
    {
        /// <summary>
        /// This method should get a theme with the 
        /// specified name
        /// </summary>
        /// <param name="themeName">Name of a theme to be found</param>
        /// <returns>This method should return a found theme
        /// or null if theme was not found.</returns>
        WebPartTheme GetTheme(string themeName);

        /// <summary>
        /// This method should return all themes
        /// </summary>
        /// <returns>This method should return an array of themes or null
        /// if there are no themes</returns>
        WebPartTheme[] GetAllThemes();

        /// <summary>
        /// This method should return all skins for specified
        /// theme
        /// </summary>
        /// <param name="themeName">Name of a theme whose
        /// skins should be returned</param>
        /// <returns>This method should return an array of found
        /// skins or null if there are no skins for the theme
        /// with specified name</returns>
        WebPartSkin[] GetSkins(string themeName);

        /// <summary>
        /// This method should return a skin for specified
        /// theme with the specified name
        /// </summary>
        /// <param name="themeName">Name of a theme where skin should
        /// be located</param>
        /// <param name="skinName">Name of a skin to search for</param>
        /// <returns>This method should return found skin or null
        /// if skin was not found</returns>
        WebPartSkin GetSkin(string themeName, string skinName);

        /// <summary>
        /// This method should check if a skin with 
        /// specified path exists in data store.
        /// </summary>
        /// <param name="skinPath">A path to a skin.</param>
        /// <returns>Returns true if skin exists and false if there is no
        /// sking at specified location.</returns>
        bool SkinExists(string skinPath);
    }
}
