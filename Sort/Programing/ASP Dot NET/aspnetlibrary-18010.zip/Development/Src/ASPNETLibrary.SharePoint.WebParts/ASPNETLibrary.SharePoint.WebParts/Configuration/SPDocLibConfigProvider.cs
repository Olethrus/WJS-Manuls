using System;
using System.Collections.Generic;
using System.Text;
using System.Web.Hosting;

using Microsoft.SharePoint;
using System.Globalization;

namespace ASPNETLibrary.SharePoint.WebParts.Configuration
{
    /// <summary>
    /// This class is an implementation of <see cref="IConfigProvider"/> interface
    /// that uses SharePoint document library as data store.
    /// </summary>
    internal class SPDocLibConfigProvider : IConfigProvider
    {
        #region IConfigProvider Members

        public WebPartTheme GetTheme(string themeName)
        {
            WebPartTheme retVal = null;

            SPList themesList = 
                    SPContext.Current.Site.RootWeb.Lists[BaseSkinnedWebPartSettingsToolPart.ThemesDocLib];

            if (themesList != null)
            {
                SPListItemCollection themesFolders = themesList.Folders;
                if (themesFolders != null && themesFolders.Count > 0)
                {
                    //Iterate through themes folders until selected theme folder
                    //is found.
                    foreach (SPListItem item in themesFolders)
                    {
                        if (item.DisplayName == themeName)
                        {
                            retVal = this.GetWebPartTheme(item);

                            break;
                        }
                    }
                }
            }
            return retVal;
        }

        private WebPartTheme GetWebPartTheme(SPListItem webPartThemeListItem)
        {
            WebPartTheme retVal = new WebPartTheme();
            retVal.Name = webPartThemeListItem.DisplayName;

            List<WebPartSkin> skins = new List<WebPartSkin>();
            //Go through the files in theme folder and populate the
            //skins list with names of files
            foreach (SPFile file in webPartThemeListItem.Folder.Files)
            {
                WebPartSkin skin = new WebPartSkin();
                skin.Name = file.Name;
                skin.Path = String.Format(
                    CultureInfo.InvariantCulture, "/{0}/{1}/{2}",
                    BaseSkinnedWebPartSettingsToolPart.ThemesDocLib,
                    retVal.Name,
                    skin.Name);
                skins.Add(skin);
            }
            if (skins.Count > 0)
            {
                WebPartSkin[] skinsArray = new WebPartSkin[skins.Count];
                skins.CopyTo(skinsArray);
                retVal.Skins = skinsArray;
            }
            return retVal;
        }

        public WebPartTheme[] GetAllThemes()
        {
            WebPartTheme[] retVal = null;

            SPList themesList = 
                    SPContext.Current.Site.RootWeb.Lists[BaseSkinnedWebPartSettingsToolPart.ThemesDocLib];

            if (themesList != null)
            {
                SPListItemCollection themesFolders = themesList.Folders;
                if (themesFolders != null && themesFolders.Count > 0)
                {
                    retVal = new WebPartTheme[themesFolders.Count];
                    //Iterate through themes folders and collect the themes
                    int currentThemeIndex = 0;
                    foreach (SPListItem item in themesFolders)
                    {
                        WebPartTheme theme = this.GetWebPartTheme(item);
                        retVal[currentThemeIndex] = theme;
                        currentThemeIndex++;
                    }
                }
            }

            return retVal;
        }

        public WebPartSkin[] GetSkins(string themeName)
        {
            WebPartSkin[] retVal = null;

            WebPartTheme theme = this.GetTheme(themeName);
            if (theme != null)
            {
                retVal = theme.Skins;
            }
            return retVal;
        }

        public WebPartSkin GetSkin(string themeName, string skinName)
        {
            WebPartSkin retVal = null;

            WebPartTheme theme = this.GetTheme(themeName);
            if (theme != null)
            {
                retVal = theme.GetSkin(skinName);
            }

            return retVal;
        }

        /// <summary>
        /// This method checks if a skin with 
        /// specified path exists in prefered document library.
        /// </summary>
        /// <param name="skinPath">A path to a skin.</param>
        /// <returns>Returns true if skin exists and false if there is no
        /// sking at specified location.</returns>
        public bool SkinExists(string skinPath)
        {
            return HostingEnvironment.VirtualPathProvider.FileExists(skinPath);
        }
        #endregion
    }
}
