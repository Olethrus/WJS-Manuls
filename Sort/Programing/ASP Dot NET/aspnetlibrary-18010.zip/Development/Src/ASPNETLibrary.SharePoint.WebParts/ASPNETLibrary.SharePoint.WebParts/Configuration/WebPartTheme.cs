using System;
using System.Collections.Generic;
using System.Text;

namespace ASPNETLibrary.SharePoint.WebParts.Configuration
{
    /// <summary>
    /// A class that represents a theme for
    /// skinned web parts. A theme is a collection
    /// of skins.
    /// </summary>
    public class WebPartTheme
    {
        #region [Private members]
        private string _name;
        private Dictionary<string, WebPartSkin> _skins;
        #endregion [Private members]

        #region [Public properties]
        /// <summary>
        /// Name of a theme
        /// </summary>
        public string Name
        {
            get
            {
                return this._name;
            }
            set
            {
                this._name = value;
            }
        }

        /// <summary>
        /// A collection of skins from this web part
        /// </summary>
        public WebPartSkin[] Skins
        {
            get
            {
                WebPartSkin[] retVal = null;

                if (this._skins.Count > 0)
                {
                    retVal = new WebPartSkin[this._skins.Count];
                    this._skins.Values.CopyTo(retVal, 0);
                }
                return retVal;
            }
            set
            {
                this._skins.Clear();
                if (value != null && value.Length > 0)
                {
                    foreach (WebPartSkin skin in value)
                    {
                        this._skins.Add(skin.Name, skin);
                    }
                }
            }
        }
        #endregion [Public properties]

        #region [Constructors]
        /// <summary>
        /// Default constructor
        /// </summary>
        public WebPartTheme()
        {
            this._skins = new Dictionary<string, WebPartSkin>();
        }
        #endregion [Constructors]

        #region [GetSkin]
        /// <summary>
        /// This method will try to find and return a skin
        /// with specified name.
        /// </summary>
        /// <param name="skinName">Name of a skin to be found and returned</param>
        /// <returns>Returns found skin or null if skin with specified
        /// name was not found</returns>
        public WebPartSkin GetSkin(string skinName)
        {
            WebPartSkin retVal = null;

            if (!this._skins.TryGetValue(skinName, out retVal))
            {
                retVal = null;
            }
            return retVal;
        }
        #endregion [GetSkin]
    }
}
