using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Globalization;

namespace ASPNETLibrary.SharePoint.WebParts
{
    //TODO: move this class to a separate assembly

    /// <summary>
    /// This class validates input parameters of protected and public methods.
    /// </summary>
    public static class InputParametersValidator
    {
        private const string NotInitializedParameterMessage = "Parameter {0} must be initalized (not null)!";
        private const string NullStringParameterMessage = "String parameter {0} must be initialized (not null)!";
        private const string EmptyStringParameterMessage = "String parameter {0} must not be empty!";
        /// <summary>
        /// Checks if the input parameter (<paramref name="objectToValidate"/>is initialized (not null)
        /// and throws an ArgumentNullException if it is not initialized.
        /// </summary>
        /// <param name="parameterToValidate">The parameter that will be validated</param>
        /// <param name="parameterName">The name of parameter that will be validated</param>
        /// <seealso cref="ArgumentNullException"/>
        public static void ValidateObjectParameter(object parameterToValidate, string parameterName)
        {
            InputParametersValidator.ValidateStringNotEmpty(parameterName, "parameterName");

            if (parameterToValidate == null)
            {
                string errorMessage = String.Format(CultureInfo.InvariantCulture, InputParametersValidator.NotInitializedParameterMessage, parameterName);
                throw new ArgumentNullException(errorMessage);
            }
        }

        /// <summary>
        /// Checks if <paramref name="stringToValidate"/> is null or empty and throw an
        /// ArgumentNullException in case the string is null or ArgumeException in case the string is empty.
        /// </summary>
        /// <param name="parameterToValidate">The string parameter that will be validated</param>
        /// <param name="parameterName">The name of parameter that will be validated</param>
        /// <seealso cref="ArgumentNullException"/>
        /// <seealso cref="ArgumentException"/>
        public static void ValidateStringNotEmpty(string parameterToValidate, string parameterName)
        {
            if (String.IsNullOrEmpty(parameterName))
            {
                throw new ArgumentException("ValidateStringNotEmpty method requires name of parameter to be set!");
            }

            if (String.IsNullOrEmpty(parameterToValidate))
            {
                string errorMessage;
                if (parameterToValidate == null)
                {
                    errorMessage = String.Format(CultureInfo.InvariantCulture, InputParametersValidator.NullStringParameterMessage, parameterName);
                    throw new ArgumentNullException(errorMessage);
                }
                else
                {
                    errorMessage = String.Format(CultureInfo.InvariantCulture, InputParametersValidator.EmptyStringParameterMessage, parameterName);
                    throw new ArgumentException(errorMessage);
                }
            }
        }
    }
}
