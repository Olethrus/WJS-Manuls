using System;
using System.Collections.Generic;
using System.Text;

using ASPNETLibrary.SharePoint.WebParts.GeneratorEngine;

namespace ASPNETLibrary.SharePoint.WebParts.Generator
{
    class Program
    {
        static void Main(string[] args)
        {
            SkinnedWebPartsGenerator generator = new SkinnedWebPartsGenerator(Console.Out);

            //TODO: implement better input parameters parsing and print the usage info
            if (generator.GenerateSkinnedWebPart(args[0], args[1]))
            {

            }
            else
            {

            }
        }
    }
}
