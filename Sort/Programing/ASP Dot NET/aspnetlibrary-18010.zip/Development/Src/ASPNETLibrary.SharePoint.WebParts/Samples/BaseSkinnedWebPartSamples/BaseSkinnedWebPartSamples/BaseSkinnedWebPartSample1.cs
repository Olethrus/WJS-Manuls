using System;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Serialization;
using System.Web.UI.WebControls;
using System.ComponentModel;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

namespace ASPNETLibrary.SharePoint.WebParts.Samples.BaseSkinnedWebPartSamples
{
    [XmlRoot(Namespace = "ASPNETLibrary.SharePoint.WebParts.Samples.BaseSkinnedWebPartSamples")]
    [GuidAttribute("48ad5a3c-e2ac-4499-b040-4fc24cab71e8")]
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:BaseSkinnedWebPartSample1 runat=server></{0}:BaseSkinnedWebPartSample1>")]
    public partial class BaseSkinnedWebPartSample1 : BaseSkinnedWebPart
    {
        #region [Methods]

        protected override void Initialize(Control skin)
        {
            //TODO: add any extra initialization here (like attaching to Button.Click events,
            //setting the initial data to server controls, etc)

            this._submit.Click += new EventHandler(SubmitClick);
        }

        void SubmitClick(object sender, EventArgs e)
        {
            
        }

        #endregion [Methods]

        public BaseSkinnedWebPartSample1()
        {
            this.ExportMode = WebPartExportMode.All;
        }
    }
}
