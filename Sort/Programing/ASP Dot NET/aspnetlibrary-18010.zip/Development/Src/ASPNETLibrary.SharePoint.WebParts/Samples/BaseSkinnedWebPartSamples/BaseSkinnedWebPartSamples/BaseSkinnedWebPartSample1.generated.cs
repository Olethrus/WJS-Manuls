using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace ASPNETLibrary.SharePoint.WebParts.Samples.BaseSkinnedWebPartSamples
{
    public partial class BaseSkinnedWebPartSample1
    {
        #region [Member variables]

        private TextBox _username;
        private Button _submit;

        #endregion [Member variables]

        #region [Constants]

        private const string UsernameID = "Username";
        private const string SubmitID = "Submit";

        #endregion [Constants]

        #region [Methods]

        #region [AttachChildControls]
        protected override void AttachBaseSetOfChildControls(Control skin)
        {
            this._username = (TextBox)skin.FindControl(BaseSkinnedWebPartSample1.UsernameID);
            this._submit = (Button)skin.FindControl(BaseSkinnedWebPartSample1.SubmitID);
        }
        #endregion [AttachChildControls]

        #region [AddRequiredControls]
        protected override void AddBaseSetOfRequiredControls()
        {
            this.AddRequiredControl(this._username, BaseSkinnedWebPartSample1.UsernameID);
            this.AddRequiredControl(this._submit, BaseSkinnedWebPartSample1.SubmitID);
        }
        #endregion [AddRequiredControls]

        #endregion [Methods]
    }
}
