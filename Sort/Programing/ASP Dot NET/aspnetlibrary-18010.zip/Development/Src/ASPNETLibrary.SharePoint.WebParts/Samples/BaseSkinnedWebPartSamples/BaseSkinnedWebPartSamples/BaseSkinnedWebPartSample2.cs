using System;
using System.Runtime.InteropServices;
using System.Web.UI;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;
using System.Xml.Serialization;
using System.ComponentModel;

using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.WebPartPages;

using ASPNETLibrary.SharePoint.WebParts;

namespace ASPNETLibrary.SharePoint.WebParts.Samples.BaseSkinnedWebPartSamples
{
    [XmlRoot(Namespace = "MyNamespace")]
    [GuidAttribute("a2c73734-b78d-4428-90d7-ce6cad0a65a9")]
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:BaseSkinnedWebPartSample2 runat=server></{0}:BaseSkinnedWebPartSample2>")]
    public partial class BaseSkinnedWebPartSample2 : BaseSkinnedWebPart
    {
        #region [Methods]

        protected override void Initialize(Control skin)
        {
            this._newQuestion.Click += new EventHandler(NewQuestionClick);
            this._submit.Click += new EventHandler(SubmitClick);

            this._statusMessagePanel.Visible = false;
        }

        void SubmitClick(object sender, EventArgs e)
        {
            this._statusMessagePanel.Visible = true;
            this._submitQuestionPanel.Visible = false;
            this._status.Text = "Your question was successfully submit.";
        }

        void NewQuestionClick(object sender, EventArgs e)
        {
            this._submitQuestionPanel.Visible = true;
            this._statusMessagePanel.Visible = false;
        }

        #endregion [Methods]

        public BaseSkinnedWebPartSample2()
        {
            this.ExportMode = WebPartExportMode.All;
        }
    }
}