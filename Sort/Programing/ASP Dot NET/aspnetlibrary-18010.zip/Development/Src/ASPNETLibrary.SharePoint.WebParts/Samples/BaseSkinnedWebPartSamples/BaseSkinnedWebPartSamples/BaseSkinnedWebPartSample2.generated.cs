using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ASPNETLibrary.SharePoint.WebParts.Samples.BaseSkinnedWebPartSamples
{
    public partial class BaseSkinnedWebPartSample2
    {
        #region [Member variables]

        private Panel _submitQuestionPanel;
        private Label _nameCaption;
        private TextBox _name;
        private Label _emailCaption;
        private TextBox _email;
        private Label _questionCaption;
        private TextBox _question;
        private Button _submit;
        private Panel _statusMessagePanel;
        private Label _status;
        private Button _newQuestion;

		
        #endregion [Member variables]

        #region [Constants]

        private const string SubmitQuestionPanelID = "SubmitQuestionPanel";
        private const string NameCaptionID = "NameCaption";
        private const string NameID = "Name";
        private const string EmailCaptionID = "EmailCaption";
        private const string EmailID = "Email";
        private const string QuestionCaptionID = "QuestionCaption";
        private const string QuestionID = "Question";
        private const string SubmitID = "Submit";
        private const string StatusMessagePanelID = "StatusMessagePanel";
        private const string StatusID = "Status";
        private const string NewQuestionID = "NewQuestion";

		
        #endregion [Constants]

        #region [Methods]

        #region [AttachBaseSetOfChildControls]
        protected override void AttachBaseSetOfChildControls(Control skin)
        {
            this._submitQuestionPanel = (Panel)skin.FindControl(BaseSkinnedWebPartSample2.SubmitQuestionPanelID);
            this._nameCaption = (Label)skin.FindControl(BaseSkinnedWebPartSample2.NameCaptionID);
            this._name = (TextBox)skin.FindControl(BaseSkinnedWebPartSample2.NameID);
            this._emailCaption = (Label)skin.FindControl(BaseSkinnedWebPartSample2.EmailCaptionID);
            this._email = (TextBox)skin.FindControl(BaseSkinnedWebPartSample2.EmailID);
            this._questionCaption = (Label)skin.FindControl(BaseSkinnedWebPartSample2.QuestionCaptionID);
            this._question = (TextBox)skin.FindControl(BaseSkinnedWebPartSample2.QuestionID);
            this._submit = (Button)skin.FindControl(BaseSkinnedWebPartSample2.SubmitID);
            this._statusMessagePanel = (Panel)skin.FindControl(BaseSkinnedWebPartSample2.StatusMessagePanelID);
            this._status = (Label)skin.FindControl(BaseSkinnedWebPartSample2.StatusID);
            this._newQuestion = (Button)skin.FindControl(BaseSkinnedWebPartSample2.NewQuestionID);

        }
        #endregion [AttachBaseSetOfChildControls]

        #region [AddBaseSetOfRequiredControls]
        protected override void AddBaseSetOfRequiredControls()
        {
            this.AddRequiredControl(this._submitQuestionPanel, BaseSkinnedWebPartSample2.SubmitQuestionPanelID);
            this.AddRequiredControl(this._nameCaption, BaseSkinnedWebPartSample2.NameCaptionID);
            this.AddRequiredControl(this._name, BaseSkinnedWebPartSample2.NameID);
            this.AddRequiredControl(this._emailCaption, BaseSkinnedWebPartSample2.EmailCaptionID);
            this.AddRequiredControl(this._email, BaseSkinnedWebPartSample2.EmailID);
            this.AddRequiredControl(this._questionCaption, BaseSkinnedWebPartSample2.QuestionCaptionID);
            this.AddRequiredControl(this._question, BaseSkinnedWebPartSample2.QuestionID);
            this.AddRequiredControl(this._submit, BaseSkinnedWebPartSample2.SubmitID);
            this.AddRequiredControl(this._statusMessagePanel, BaseSkinnedWebPartSample2.StatusMessagePanelID);
            this.AddRequiredControl(this._status, BaseSkinnedWebPartSample2.StatusID);
            this.AddRequiredControl(this._newQuestion, BaseSkinnedWebPartSample2.NewQuestionID);

        }
        #endregion [AddBaseSetOfRequiredControls]

        #endregion [Methods]
    }
}