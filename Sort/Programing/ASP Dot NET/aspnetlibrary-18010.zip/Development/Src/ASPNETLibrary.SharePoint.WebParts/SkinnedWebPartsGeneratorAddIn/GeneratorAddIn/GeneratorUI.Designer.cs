namespace ASPNETLibrary.SharePoint.WebParts.GeneratorAddIn
{
    partial class GeneratorUI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnGenerate = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.edtASCXInput = new System.Windows.Forms.TextBox();
            this.btnWebPartChoose = new System.Windows.Forms.Button();
            this.edtWebPartOutputFile = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.sfdWebPartFile = new System.Windows.Forms.SaveFileDialog();
            this.epGenerator = new System.Windows.Forms.ErrorProvider(this.components);
            this.edtNamespace = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.cbOverwrite = new System.Windows.Forms.CheckBox();
            ((System.ComponentModel.ISupportInitialize)(this.epGenerator)).BeginInit();
            this.SuspendLayout();
            // 
            // btnGenerate
            // 
            this.btnGenerate.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnGenerate.Location = new System.Drawing.Point(296, 121);
            this.btnGenerate.Name = "btnGenerate";
            this.btnGenerate.Size = new System.Drawing.Size(75, 23);
            this.btnGenerate.TabIndex = 8;
            this.btnGenerate.Text = "Generate";
            this.btnGenerate.UseVisualStyleBackColor = true;
            this.btnGenerate.Click += new System.EventHandler(this.btnGenerate_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(376, 121);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 9;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // edtASCXInput
            // 
            this.edtASCXInput.Location = new System.Drawing.Point(142, 18);
            this.edtASCXInput.Name = "edtASCXInput";
            this.edtASCXInput.ReadOnly = true;
            this.edtASCXInput.Size = new System.Drawing.Size(257, 20);
            this.edtASCXInput.TabIndex = 1;
            // 
            // btnWebPartChoose
            // 
            this.epGenerator.SetIconPadding(this.btnWebPartChoose, 3);
            this.btnWebPartChoose.Location = new System.Drawing.Point(403, 43);
            this.btnWebPartChoose.Name = "btnWebPartChoose";
            this.btnWebPartChoose.Size = new System.Drawing.Size(32, 22);
            this.btnWebPartChoose.TabIndex = 4;
            this.btnWebPartChoose.Text = "...";
            this.btnWebPartChoose.UseVisualStyleBackColor = true;
            this.btnWebPartChoose.Click += new System.EventHandler(this.btnWebPartChoose_Click);
            // 
            // edtWebPartOutputFile
            // 
            this.edtWebPartOutputFile.Location = new System.Drawing.Point(142, 44);
            this.edtWebPartOutputFile.Name = "edtWebPartOutputFile";
            this.edtWebPartOutputFile.ReadOnly = true;
            this.edtWebPartOutputFile.Size = new System.Drawing.Size(257, 20);
            this.edtWebPartOutputFile.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 47);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(106, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Output WebPart File:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Input ASCX Control (Skin):";
            // 
            // sfdWebPartFile
            // 
            this.sfdWebPartFile.DefaultExt = "cs";
            this.sfdWebPartFile.Filter = "C# files|*.cs";
            this.sfdWebPartFile.Title = "Save Output WebPart File";
            // 
            // epGenerator
            // 
            this.epGenerator.BlinkStyle = System.Windows.Forms.ErrorBlinkStyle.NeverBlink;
            this.epGenerator.ContainerControl = this;
            // 
            // edtNamespace
            // 
            this.edtNamespace.Location = new System.Drawing.Point(142, 70);
            this.edtNamespace.Name = "edtNamespace";
            this.edtNamespace.Size = new System.Drawing.Size(257, 20);
            this.edtNamespace.TabIndex = 6;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 73);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Namespace:";
            // 
            // cbOverwrite
            // 
            this.cbOverwrite.AutoSize = true;
            this.cbOverwrite.Location = new System.Drawing.Point(120, 96);
            this.cbOverwrite.Name = "cbOverwrite";
            this.cbOverwrite.Size = new System.Drawing.Size(125, 17);
            this.cbOverwrite.TabIndex = 7;
            this.cbOverwrite.Text = "Overwrite existing file";
            this.cbOverwrite.UseVisualStyleBackColor = true;
            // 
            // GeneratorUI
            // 
            this.AcceptButton = this.btnGenerate;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(463, 156);
            this.Controls.Add(this.cbOverwrite);
            this.Controls.Add(this.edtNamespace);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnGenerate);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.edtASCXInput);
            this.Controls.Add(this.btnWebPartChoose);
            this.Controls.Add(this.edtWebPartOutputFile);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GeneratorUI";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Skinned WebParts Generator";
            this.Load += new System.EventHandler(this.GeneratorUI_Load);
            ((System.ComponentModel.ISupportInitialize)(this.epGenerator)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnGenerate;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox edtASCXInput;
        private System.Windows.Forms.Button btnWebPartChoose;
        private System.Windows.Forms.TextBox edtWebPartOutputFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.SaveFileDialog sfdWebPartFile;
        private System.Windows.Forms.ErrorProvider epGenerator;
        private System.Windows.Forms.TextBox edtNamespace;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox cbOverwrite;
    }
}