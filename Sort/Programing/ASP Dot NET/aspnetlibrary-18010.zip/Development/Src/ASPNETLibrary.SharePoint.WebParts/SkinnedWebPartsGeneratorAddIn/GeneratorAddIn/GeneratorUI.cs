using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Text.RegularExpressions;

namespace ASPNETLibrary.SharePoint.WebParts.GeneratorAddIn
{
    public partial class GeneratorUI : Form
    {
        #region [Variables]
        private string _outputWebPartFile;
        private string _webPartNamespace;
        private bool _overwriteWebPart = false;
        #endregion

        #region [Properties]
        public string OutputWebPartFile
        {
            get
            {
                return this._outputWebPartFile;
            }
        }

        public string WebPartNamespace
        {
            get
            {
                return this._webPartNamespace;
            }
        }

        public bool OverwriteWebPart
        {
            get
            {
                return this._overwriteWebPart;
            }
        }
        #endregion

        #region [Contructor]
        /// <summary>
        /// Default contructor sets ASCX file name and location into edit control.
        /// </summary>
        /// <param name="inputFile">ASCX file name and location.</param>
        public GeneratorUI(string inputFile)
        {
            InitializeComponent();
            edtASCXInput.Text = inputFile;
        }
        #endregion

        #region [Control Events]
        private void btnWebPartChoose_Click(object sender, EventArgs e)
        {
            this.sfdWebPartFile.CheckFileExists = false;
            this.sfdWebPartFile.CheckPathExists = true;
            this.sfdWebPartFile.FileName = this.edtWebPartOutputFile.Text;

            if (sfdWebPartFile.ShowDialog() == DialogResult.OK)
            {
                edtWebPartOutputFile.Text = sfdWebPartFile.FileName;
            }
        }

        private void btnGenerate_Click(object sender, EventArgs e)
        {
            if (!String.IsNullOrEmpty(edtWebPartOutputFile.Text))
            {
                if (edtWebPartOutputFile.Text.EndsWith(".cs"))
                {
                    if (!String.IsNullOrEmpty(this.edtNamespace.Text))
                    {
                        FileInfo info = new FileInfo(edtWebPartOutputFile.Text);
                        if (!info.Directory.Exists || String.IsNullOrEmpty(info.Name))
                        {
                            epGenerator.SetError(btnWebPartChoose, "Output WebPart File path is not valid.");
                            DialogResult = DialogResult.None;
                        }
                        else
                        {
                            this._outputWebPartFile = info.FullName;
                            this._webPartNamespace = edtNamespace.Text;
                            this._overwriteWebPart = cbOverwrite.Checked;
                            epGenerator.SetError(btnWebPartChoose, "");
                            DialogResult = DialogResult.OK;
                        }
                    }
                    else
                    {
                        epGenerator.SetError(this.edtNamespace, "Namespace for web part must be set.");
                        DialogResult = DialogResult.None;
                    }
                }
                else
                {
                    epGenerator.SetError(btnWebPartChoose, "Output WebPart File is not in valid format. An example of a valid format is: 'C:\\SkinnedWebPart\\File1.cs'");
                    DialogResult = DialogResult.None;
                }
            }
            else
            {
                epGenerator.SetError(btnWebPartChoose, "Output WebPart File must be provided.");
                DialogResult = DialogResult.None;
            }
        }
        #endregion

        private void GeneratorUI_Load(object sender, EventArgs e)
        {
            //Propose filename and path for file that should be generated
            string controlFilenamePath = this.edtASCXInput.Text;
            string proposedWebPartFilenamePath = controlFilenamePath.Replace(".ascx", ".cs");

            this.edtWebPartOutputFile.Text = proposedWebPartFilenamePath;
        }
    }
}