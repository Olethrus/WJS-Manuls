using System;
using System.Collections.Generic;
using System.Text;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.WebControls;

using ASPNETLibrary.WebParts.Resources;
using ASPNETLibrary.WebParts.Configuration;

namespace ASPNETLibrary.WebParts
{
    /// <summary>
    /// Implementation of a custom editor web part that displays a 
    /// customized user interface for defining the properties 
    /// of a Skinned Web Part inside of the editor pane.
    /// </summary>
    public class BaseSkinnedWebPartSettingsEditorPart : EditorPart
    {
        #region [Member variables]

        /// <summary>
        /// Will be filled-in with all themes.
        /// </summary>
        private DropDownList _themeList;

        /// <summary>
        /// Will be filled-in with all skins for selected theme.
        /// </summary>
        private DropDownList _skinList;
        #endregion [Member variables]

        #region [Constructors]

        public BaseSkinnedWebPartSettingsEditorPart()
        {
            this.Title = BaseSkinnedWebPartResources.EditorPartTitle;
        }
        #endregion [Constructors]

        #region [Overrides]
        protected override void CreateChildControls()
        {
            base.CreateChildControls();

            this._themeList = new DropDownList();
            this._themeList.AutoPostBack = true;
            this._themeList.SelectedIndexChanged += new EventHandler(this.ThemeListSelectedIndexChanged);
            this.Controls.Add(this._themeList);

            this._skinList = new DropDownList();
            this.Controls.Add(this._skinList);
        }

        public override void SyncChanges()
        {

        }

        protected override void Render(System.Web.UI.HtmlTextWriter output)
        {
            output.Write(BaseSkinnedWebPartResources.ThemeListCaption);
            this._themeList.RenderControl(output);

            output.WriteBreak();

            output.Write(BaseSkinnedWebPartResources.SkinListCaption);
            this._skinList.RenderControl(output);
        }

        public override bool ApplyChanges()
        {
            this.EnsureChildControls();

            BaseSkinnedWebPart baseSkinnedWebPart = (BaseSkinnedWebPart)base.WebPartToEdit;
            baseSkinnedWebPart.SkinName = this._skinList.SelectedValue;
            baseSkinnedWebPart.ThemeName = this._themeList.SelectedValue;

            return true;
        }

        protected override void OnPreRender(EventArgs e)
        {
            if (this._themeList.Items.Count == 0)
            {
                this.LoadThemeList();
                this.LoadSkinList();
            }
            base.OnPreRender(e);
        }        
        #endregion [Overrides]

        #region [Private methods]
        private void LoadSkinList()
        {
            string currentValue;
            BaseSkinnedWebPart skinnedWebPart = (BaseSkinnedWebPart)base.WebPartToEdit;
            if (this._skinList.Items.Count == 0)
            {
                currentValue = skinnedWebPart.SkinName;
            }
            else
            {
                currentValue = this._skinList.SelectedValue;
                this._skinList.Items.Clear();
            }

            string themeName = this._themeList.SelectedValue;
            WebPartSkin[] skins = ConfigHandler.Instance.GetSkins(themeName);
            if (skins != null)
            {
                //Go through the skins and populate the
                //skins list with names of skins
                foreach (WebPartSkin skin in skins)
                {
                    this._skinList.Items.Add(skin.Name);
                }

                //Set previously selected skin as selected item in drop down list
                ListItem listItem = this._skinList.Items.FindByValue(currentValue);
                if (listItem != null)
                {
                    listItem.Selected = true;
                }
            }
            else
            {
                this._skinList.Items.Add(BaseSkinnedWebPartResources.SkinsCouldntBeLoaded);
                skinnedWebPart.SkinName = null;
            }
        }

        private void LoadThemeList()
        {
            BaseSkinnedWebPart skinnedWebPart = (BaseSkinnedWebPart)base.WebPartToEdit;

            string currentValue;
            if (this._themeList.Items.Count == 0)
            {
                currentValue = skinnedWebPart.ThemeName;
            }
            else
            {
                currentValue = this._themeList.SelectedValue;
                this._themeList.Items.Clear();
            }

            WebPartTheme[] themes = ConfigHandler.Instance.GetAllThemes();
            if (themes != null && themes.Length > 0)
            {
                foreach (WebPartTheme theme in themes)
                {
                    this._themeList.Items.Add(theme.Name);
                }
                //Set previously selected theme as selected item in drop down list
                ListItem listItem = this._themeList.Items.FindByValue(currentValue);
                if (listItem != null)
                {
                    listItem.Selected = true;
                }
            }
            else
            {
                this._themeList.Items.Add(BaseSkinnedWebPartResources.ThemesCouldntBeLoaded);
                skinnedWebPart.ThemeName = null;
            }
        }

        private void ThemeListSelectedIndexChanged(object sender, EventArgs e)
        {
            this.LoadSkinList();
        }
        #endregion [Private methods]
    }
}
