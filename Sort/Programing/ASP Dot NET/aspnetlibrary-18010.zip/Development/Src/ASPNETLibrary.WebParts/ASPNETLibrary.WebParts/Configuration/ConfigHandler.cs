using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace ASPNETLibrary.WebParts.Configuration
{
    /// <summary>
    /// A singleton class that handles configuration for 
    /// skinned web parts.
    /// </summary>
    public sealed class ConfigHandler
    {
        #region [Private members]
        private static ConfigHandler _instance = new ConfigHandler();
        private IConfigProvider _configProvider;
        #endregion [Private members]

        #region [Properties]
        /// <summary>
        /// Returns single instance of this class.
        /// </summary>
        public static ConfigHandler Instance
        {
            get
            {
                return ConfigHandler._instance;
            }
        }
        #endregion [Properties]

        #region [Constructors]
        private ConfigHandler()
        {
            //Get Configuration Provider based on value specified in configuration file
            //under the "webPartsConfiguration" section
            ProvidersConfiguration providersConfig = 
                (ProvidersConfiguration)ConfigurationManager.GetSection("webPartsConfiguration");
            
            Type configProviderType = Type.GetType(providersConfig.ProviderName);
            this._configProvider = (IConfigProvider)Activator.CreateInstance(configProviderType, providersConfig.CustomData);
        }
        #endregion [Constructors]

        #region [Public methods]
        /// <summary>
        /// This method gets a theme with the 
        /// specified name
        /// </summary>
        /// <param name="themeName">Name of a theme to be found</param>
        /// <returns>Returns a found theme
        /// or null if theme was not found.</returns>
        public WebPartTheme GetTheme(string themeName)
        {
            return this._configProvider.GetTheme(themeName);
        }

        /// <summary>
        /// This method will return all themes
        /// </summary>
        /// <returns>Returns an array of themes or null
        /// if there are no themes</returns>
        public WebPartTheme[] GetAllThemes()
        {
            return this._configProvider.GetAllThemes();
        }

        /// <summary>
        /// This method will return all skins for specified
        /// theme
        /// </summary>
        /// <param name="themeName">Name of a theme whose
        /// skins should be returned</param>
        /// <returns>Returns an array of found skins or null if 
        /// there are no skins for the theme with specified name
        /// </returns>
        public WebPartSkin[] GetSkins(string themeName)
        {
            return this._configProvider.GetSkins(themeName);
        }

        /// <summary>
        /// This method returns a skin for specified
        /// theme with the specified name
        /// </summary>
        /// <param name="themeName">Name of a theme where skin should
        /// be located</param>
        /// <param name="skinName">Name of a skin to search for</param>
        /// <returns>Returns found skin or null
        /// if skin was not found</returns>
        public WebPartSkin GetSkin(string themeName, string skinName)
        {
            return this._configProvider.GetSkin(themeName, skinName);
        }
        #endregion [Public methods]
    }
}
