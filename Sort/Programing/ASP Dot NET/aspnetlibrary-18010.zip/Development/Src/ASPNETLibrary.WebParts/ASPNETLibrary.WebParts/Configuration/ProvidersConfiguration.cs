using System;
using System.Collections.Generic;
using System.Text;

namespace ASPNETLibrary.WebParts.Configuration
{
    /// <summary>
    /// A class that holds configuration for
    /// Web Parts providers.
    /// </summary>
    public class ProvidersConfiguration
    {
        #region [Private members]
        private string _providerName;
        private string _customData;
        #endregion [Private members]

        #region [Public properties]
        /// <summary>
        /// Full name of configuration provider class
        /// </summary>
        public string ProviderName
        {
            get
            {
                return this._providerName;
            }
            set
            {
                this._providerName = value;
            }
        }

        /// <summary>
        /// Additional configuration specific for
        /// a concrete configuration provider
        /// </summary>
        public string CustomData
        {
            get
            {
                return this._customData;
            }
            set
            {
                this._customData = value;
            }
        }
        #endregion [Public properties]
    }
}
