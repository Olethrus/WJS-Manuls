using System;
using System.Collections.Generic;
using System.Text;

namespace ASPNETLibrary.WebParts.Configuration
{
    /// <summary>
    /// A class that represents a skin for skinned web parts.
    /// A skin is an ASCX control that defines layout and
    /// controls of a web part.
    /// </summary>
    public class WebPartSkin
    {
        #region [Private members]
        private string _name;
        private string _path;
        #endregion [Private members]

        #region [Public properties]
        /// <summary>
        /// Name of a skin
        /// </summary>
        public string Name
        {
            get
            {
                return this._name;
            }
            set
            {
                this._name = value;
            }
        }

        /// <summary>
        /// Path to skin file
        /// </summary>
        public string Path
        {
            get
            {
                return this._path;
            }
            set
            {
                this._path = value;
            }
        }
        #endregion [Public properties]

        #region [Constructors]
        /// <summary>
        /// Default constructor
        /// </summary>
        public WebPartSkin()
        {
        }
        #endregion [Constructors]
    }
}
