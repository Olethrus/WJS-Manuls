using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Serialization;
using System.Runtime.InteropServices;
using System.ComponentModel;

using ASPNETLibrary.WebParts;

namespace BaseSkinnedWebPartSamples
{
    [XmlRoot(Namespace = "BaseSkinnedWebPartSamples")]
    [GuidAttribute("6B393E7E-1C03-11DD-BCA8-BE7156D89593")]
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:BaseSkinnedWebPartSample1 runat=server></{0}:BaseSkinnedWebPartSample1>")]
    public partial class BaseSkinnedWebPartSample1 : BaseSkinnedWebPart
    {
        #region [Methods]

        protected override void Initialize(Control skin)
        {
            //TODO: add any extra initialization here (like attaching to Button.Click events,
            //setting the initial data to server controls, etc)

            this._submit.Click += new EventHandler(SubmitClick);
        }

        void SubmitClick(object sender, EventArgs e)
        {

        }

        #endregion [Methods]

        public BaseSkinnedWebPartSample1()
        {
            this.ExportMode = WebPartExportMode.All;
        }

        #region [Member variables]

        private TextBox _username;
        private Button _submit;

        #endregion [Member variables]

        #region [Constants]

        private const string UsernameID = "Username";
        private const string SubmitID = "Submit";

        #endregion [Constants]

        #region [Methods]

        #region [AttachChildControls]
        protected override void AttachBaseSetOfChildControls(Control skin)
        {
            this._username = (TextBox)skin.FindControl(BaseSkinnedWebPartSample1.UsernameID);
            this._submit = (Button)skin.FindControl(BaseSkinnedWebPartSample1.SubmitID);
        }
        #endregion [AttachChildControls]

        #region [AddRequiredControls]
        protected override void AddBaseSetOfRequiredControls()
        {
            this.AddRequiredControl(this._username, BaseSkinnedWebPartSample1.UsernameID);
            this.AddRequiredControl(this._submit, BaseSkinnedWebPartSample1.SubmitID);
        }
        #endregion [AddRequiredControls]

        #endregion [Methods]

    }
}
