using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

using ASPNETLibrary.WebParts.Configuration;

namespace BaseSkinnedWebPartSamples
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Allow users to modify web part
            if (this.WebPartManager1.Personalization.Scope == PersonalizationScope.User
                && this.WebPartManager1.Personalization.CanEnterSharedScope)
            {
                this.WebPartManager1.Personalization.ToggleScope();
            }
        }

        protected void EditClick(object sender, EventArgs e)
        {
            this.WebPartManager1.DisplayMode = WebPartManager.EditDisplayMode;
        }

        protected void BrowseClick(object sender, EventArgs e)
        {
            this.WebPartManager1.DisplayMode = WebPartManager.BrowseDisplayMode;
        }
    }
}
