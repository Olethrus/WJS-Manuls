﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.ACSCalculator.Client
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.ServiceModel;
    using System.ServiceModel.Description;
    using System.ServiceModel.Security;
    using System.ServiceModel.Web;
    using System.Text;
    using System.Web;

    class Program
    {
        static string serviceNamespace;
        static string issuerKey;

        const string acsHostName = "accesscontrol.windows.net";
        const string issuerName = "acscalculator";

        static void Main()
        {
            Console.WriteLine("Enter your service namespace, then press <ENTER>");
            serviceNamespace = Console.ReadLine();

            Console.WriteLine();
            Console.WriteLine("Enter your issuer key, then press <ENTER>");
            issuerKey = Console.ReadLine();

            // create a token with a group=user claim
            string userToken = GetUserToken();

            // send the token to ACS
            string acsIssuedToken = SendSWTToACS(userToken, "http://localhost/acscalculator");

            // perform the calculator operations
            Console.WriteLine();
            Console.WriteLine("Calling calculator with 'group=user' claim");
            DoCalculatorOperations(acsIssuedToken);

            // create a token with a group=user,executive claim
            string executiveToken = GetUserExecutiveToken();

            // send the token to ACS
            acsIssuedToken = SendSWTToACS(executiveToken, "http://localhost/acscalculator");

            // perform the calculator operations
            Console.WriteLine();
            Console.WriteLine("Calling calculator with 'group=user,executive' claim");
            DoCalculatorOperations(acsIssuedToken);

            Console.WriteLine();
            Console.WriteLine("Done. Press <ENTER> to end");
            Console.ReadLine();
        }

        private static void DoCalculatorOperations(string userToken)
        {
            WebHttpBinding binding = new WebHttpBinding();
            Uri address = new Uri("http://localhost/acscalculator");

            WebChannelFactory<ICalculator> factory = new WebChannelFactory<ICalculator>(binding, address);
            factory.Endpoint.Behaviors.Add(new WebHttpBehavior());

            ICalculator proxy = factory.CreateChannel();

            using (new OperationContextScope((IClientChannel)proxy))
            {
                WebOperationContext.Current.OutgoingRequest.Headers.Add(HttpRequestHeader.Authorization, userToken);

                try
                {
                    Console.Write("\tCalling add: ");
                    int result = proxy.Add(2, 2);
                    Console.WriteLine("2 + 2 = {0}", result);

                    Console.Write("\tCalling subtract: ");
                    result = proxy.Subtract(2, 2);
                    Console.WriteLine("2 - 2 = {0}", result);

                    Console.Write("\tCalling divide: ");
                    result = proxy.Divide(2, 2);
                    Console.WriteLine("2 / 2 = {0}", result);

                    Console.Write("\tCalling multiply: ");
                    result = proxy.Multiply(2, 2);
                    Console.WriteLine("2 * 2 = {0}", result);
                }
                catch (MessageSecurityException ex)
                {
                    if (ex.InnerException != null && ex.InnerException.GetType() == typeof(WebException))
                    {
                        Console.WriteLine(ex.InnerException.Message);
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            ((IClientChannel)proxy).Close();
        }

        static string GetUserExecutiveToken()
        {
            Dictionary<string, string> claims = new Dictionary<string, string>();
            claims.Add("group", "user,executive");

            TokenFactory factory = new TokenFactory(acsHostName, serviceNamespace, issuerName, issuerKey);
            return factory.CreateToken(claims);
        }

        static string GetUserToken()
        {
            Dictionary<string, string> claims = new Dictionary<string, string>();
            claims.Add("group", "user");

            TokenFactory factory = new TokenFactory(acsHostName, serviceNamespace, issuerName, issuerKey);
            return factory.CreateToken(claims);
        }

        static string SendSWTToACS(string swt, string appliesTo)
        {
            // request a token from ACS
            WebClient client = new WebClient();
            client.BaseAddress = string.Format(@"https://{0}.{1}/", serviceNamespace, acsHostName);

            NameValueCollection values = new NameValueCollection();
            values.Add("wrap_assertion_format", "SWT");
            values.Add("wrap_assertion", swt);
            values.Add("wrap_scope", appliesTo);

            string response = null;

            byte[] responseBytes = client.UploadValues("WRAPv0.9/", values);
            response = Encoding.UTF8.GetString(responseBytes);
            return HttpUtility.UrlDecode(response
                .Split('&')
                .Single(value => value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase))
                .Split('=')[1]);
        }
    }
}


