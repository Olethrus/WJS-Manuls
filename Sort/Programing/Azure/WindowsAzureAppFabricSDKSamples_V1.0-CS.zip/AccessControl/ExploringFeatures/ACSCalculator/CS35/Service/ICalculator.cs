﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.ACSCalculator.Service
{
    using System;
    using System.Collections.Generic;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using System.Text;

    [ServiceContract]
    public interface ICalculator
    {
        [OperationContract]
        [WebGet(UriTemplate = "add?a={a}&b={b}")]
        int Add(int a, int b);

        [OperationContract]
        [WebGet(UriTemplate = "subtract?a={a}&b={b}")]
        int Subtract(int a, int b);

        [OperationContract]
        [WebGet(UriTemplate = "multiply?a={a}&b={b}")]
        int Multiply(int a, int b);

        [OperationContract]
        [WebGet(UriTemplate = "divide?a={a}&b={b}")]
        int Divide(int a, int b);
    }
}

