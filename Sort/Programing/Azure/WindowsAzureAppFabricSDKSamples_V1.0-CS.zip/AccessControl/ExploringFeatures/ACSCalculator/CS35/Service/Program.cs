﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.ACSCalculator.Service
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using System.Text;
    using Microsoft.AccessControl.SDK.ACSCalculator.AuthorizationManager;

    class Program
    {
        const string serviceNamespace = "updateToServiceNamespace";
        const string trustedTokenPolicyKey = "updateToTokenPolicyKey";

        const string acsHostName = "accesscontrol.windows.net";
        const string trustedAudience = "http://localhost/acscalculator";
        const string requiredClaimType = "action";

        static void Main()
        {
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.None);

            Uri address = new Uri(trustedAudience);

            WebServiceHost host = new WebServiceHost(typeof(Calculator));
            host.AddServiceEndpoint(typeof(ICalculator), binding, address);

            host.Authorization.ServiceAuthorizationManager = new ACSAuthorizationManager(
                acsHostName,
                serviceNamespace,
                trustedAudience,
                Convert.FromBase64String(trustedTokenPolicyKey),
                requiredClaimType);

            host.Open();

            Console.WriteLine("The Calculator Service is listening");
            Console.WriteLine("Press <ENTER> to exit");
            Console.ReadLine();

            host.Close();
        }
    }
}

