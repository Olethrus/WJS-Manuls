﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.ASPNET
{
    using System;
    using System.Configuration;
    using System.Net;
    using System.Security;
    using System.Security.Principal;
    using System.Text;
    using System.Web;
    using System.Web.Configuration;
    using System.Web.Security;

    // see http://go.microsoft.com/?linkid=8101007 for IIS setup
    public class AuthModule : IHttpModule
    {
        const string serviceNamespace = "updateToServiceNamespace";
        const string signingKey = "updateToTokenPolicyKey";

        const string acsHostName = "accesscontrol.windows.net";

        const string trustedAudience = "http://localhost/ASPNETUrlAuthorization";

        private static bool SetUnauthorized()
        {
            HttpContext.Current.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
            HttpContext.Current.Response.End();
            return false;
        }

        private void OnAuthenticateRequest(object sender, EventArgs e)
        {
            bool isAuthorized = false;

            // store the context locally
            HttpContext context = HttpContext.Current;

            // get the authorization information for the requested URI
            string url = context.Request.Url.LocalPath;
            AuthorizationManager authMgr = AuthorizationManager.CreateAuthorizationManager(url);

            // Check to see if we need authentication
            if (authMgr.RequiresAuthorization)
            {
                // Look for the authorization header
                string authHeader = context.Request.Headers["Authorization"];

                // check that the authorization header is present
                if (!string.IsNullOrEmpty(authHeader))
                {
                    // check that it starts with 'WRAP'
                    if (!authHeader.StartsWith("WRAP "))
                    {
                        isAuthorized = SetUnauthorized();
                    }

                    string[] tokenNameValue = authHeader.Substring("WRAP ".Length).Split(new char[] { '=' }, 2);

                    // check that the token is of the form 'access_token="{token}"'
                    if (tokenNameValue.Length != 2 ||
                        tokenNameValue[0] != "access_token" ||
                        !tokenNameValue[1].StartsWith("\"") ||
                        !tokenNameValue[1].EndsWith("\""))
                    {
                        isAuthorized = SetUnauthorized();
                    }

                    // trim off the leading and trailing double-quotes
                    string token = tokenNameValue[1].Substring(1, tokenNameValue[1].Length - 2);

                    TokenValidator validator = new TokenValidator(
                        acsHostName,
                        serviceNamespace,
                        trustedAudience,
                        signingKey);

                    // validate the token
                    if (!validator.Validate(token))
                    {
                        isAuthorized = SetUnauthorized();
                    }

                    // create the user
                    context.User = new ServiceUser(token, validator);

                    // check if the user is authorized based on config settings
                    if (authMgr.VerifyAuthorization(context.User))
                    {
                        isAuthorized = true;
                    }
                    else
                    {
                        isAuthorized = SetUnauthorized();
                    }
                }
            }

            // Check for authentication and return HTTP 401 if none
            if (!isAuthorized)
            {
                // Assign the status code
                context.Response.StatusCode = (int)HttpStatusCode.Unauthorized;

                // Calculate the realm
                string realm = string.Format("ACSrealm=\"{0}\"", context.Request.Url.GetLeftPart(UriPartial.Path));

                // Add the authentication header
                context.Response.AddHeader("WWW-Authenticate", realm);

                // End the request
                context.Response.End();
            }
        }

        public void Dispose()
        {
        }

        public void Init(HttpApplication context)
        {
            context.AuthenticateRequest += new EventHandler(this.OnAuthenticateRequest);
        }
    }
}

