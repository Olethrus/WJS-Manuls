﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.ASPNET
{
    using System;
    using System.Collections.Specialized;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Web;

    class Program
    {
        static string serviceNamespace;
        static string issuerKey;
        static string acsHostName = "accesscontrol.windows.net";

        static void Main(string[] args)
        {
            Console.WriteLine("Enter your service namespace, then press <ENTER>");
            serviceNamespace = Console.ReadLine();

            Console.WriteLine("\nEnter your issuer key, then press <ENTER>");
            issuerKey = Console.ReadLine();

            string token = GetTokenFromACS();

            Console.WriteLine("\nreceived token from ACS: {0}\n", token);

            string response = GetDataFromService(token);

            Console.WriteLine("Service responded with: {0}\n", response);

            Console.WriteLine("Press <ENTER> to exit");

            Console.ReadLine();
        }

        private static string GetDataFromService(string token)
        {
            WebClient client = new WebClient();
            client.BaseAddress = "http://localhost/aspneturlauthorization/Default.aspx";
            client.Headers.Add("Authorization", string.Format("WRAP access_token=\"{0}\"", HttpUtility.UrlDecode(token)));

            Byte[] byteResponse = client.DownloadData(string.Empty);
            return Encoding.UTF8.GetString(byteResponse);
        }

        private static string GetTokenFromACS()
        {
            // request a token from ACS
            WebClient client = new WebClient();
            client.BaseAddress = string.Format("https://{0}.{1}", serviceNamespace, acsHostName);

            NameValueCollection values = new NameValueCollection();
            values.Add("wrap_name", "aspneturlauthorization");
            values.Add("wrap_password", issuerKey);
            values.Add("wrap_scope", "http://localhost/ASPNETUrlAuthorization");

            byte[] responseBytes = client.UploadValues("WRAPv0.9/", "POST", values);

            string response = Encoding.UTF8.GetString(responseBytes);

            return response
                .Split('&')
                .Single(value => value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase))
                .Split('=')[1];
        }
    }
}

