﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using AccessControl.TokenService;

    public class Constants
    {
        public static readonly string AccessControlBaseAddress = Utilities.ReadFromConfig("AccessControlBaseAddress", "accesscontrol.windows.net");
        public const string ServiceNamespaceIssuer = "ACS";

        internal const string ResourceNamespace = "http://schemas.microsoft.com/ws/2009/06/acs/rest/resources";
        internal const string TrackingIdHeader = "x-ms-request-id";
        internal const string MgmtIssuer = "owner";
        
        internal const string EnumerateQuery = "mode=NameIdOnly";
        internal static readonly Claim EnumerateClaim = new Claim("Action", "ReadNameIdOnly");
        internal static readonly Claim ReadClaim = new Claim("Action", "ReadAll");
    }
}
