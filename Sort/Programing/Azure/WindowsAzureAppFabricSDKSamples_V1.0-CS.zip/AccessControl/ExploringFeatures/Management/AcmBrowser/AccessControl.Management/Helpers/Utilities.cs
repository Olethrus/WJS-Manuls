﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System;
    using System.Configuration;
    using System.Security.Cryptography;

    public static class Utilities
    {
        private const string DomainUriFormat = "https://{0}.{1}/mgmt/{2}";
        private const string MgmtTokenServiceUriFormat = "https://{0}-mgmt.{1}/WRAPv0.9/";
        private const string ResourceUriFormat = "https://{0}.{1}/mgmt/{2}/{3}";

        private static RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();

        public static string GenerateKey()
        {
            byte[] keyBytes = new byte[32];
            rng.GetBytes(keyBytes);
            return Convert.ToBase64String(keyBytes);
        }

        public static Uri MgmtTokenServiceUri(string serviceNamespace)
        {
            return new Uri(string.Format(MgmtTokenServiceUriFormat, serviceNamespace, Constants.AccessControlBaseAddress));
        }

        public static Uri DomainUri(string serviceNamespace, IResource resource)
        {
            return new Uri(string.Format(DomainUriFormat, serviceNamespace, Constants.AccessControlBaseAddress, resource.Domain));
        }

        public static Uri ResourceUri(string serviceName, Resource resource)
        {
            return new Uri(string.Format(ResourceUriFormat, serviceName, Constants.AccessControlBaseAddress, resource.Domain, resource.Id));
        }

        internal static string ReadFromConfig(string key, string defaultValue)
        {
            string value;

            try
            {
                value = ConfigurationManager.AppSettings[key];
            }
            catch (ConfigurationErrorsException)
            {
                throw new ConfigurationException(string.Format("could not load configuration for the key {0}", key));
            }

            return value ?? defaultValue;
        }
    }
}

