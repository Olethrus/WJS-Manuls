﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System;
    using AccessControl.TokenService;

    public class ManagementClient
    {
        private string serviceNamespace;
        private TokenCache cache;

        public ManagementClient(string serviceNamespace, string managementKey)
        {
            if (string.IsNullOrEmpty(serviceNamespace))
            {
                throw new ManagementException("Missing service namespace.");
            }

            if (string.IsNullOrEmpty(managementKey))
            {
                throw new ManagementException("Missing management key.");
            }

            SimpleWebToken credentials = new SimpleWebToken();
            credentials.Issuer = Constants.MgmtIssuer;
            credentials.Key = managementKey;

            this.cache = new TokenCache(Utilities.MgmtTokenServiceUri(serviceNamespace), credentials);
            this.serviceNamespace = serviceNamespace;
        }

        public string Create(Resource resource)
        {
            AcsToken authToken = GetToken(resource);
            resource.CreateInService(this.serviceNamespace, authToken);

            return resource.Id;
        }

        public TokenPolicy Enumerate(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentException("id may not be null or empty");
            }

            TokenPolicy tokenPolicy = new TokenPolicy();
            tokenPolicy.Id = id;
            AcsToken authToken = GetToken(tokenPolicy);
            tokenPolicy.EnumerateFromService(this.serviceNamespace, authToken);

            return tokenPolicy;
        }

        public TokenPolicyCollection EnumerateAll()
        {
            TokenPolicyCollection tokenPolicies = new TokenPolicyCollection();
            AcsToken authToken = GetToken(tokenPolicies);
            tokenPolicies.EnumerateFromService(this.serviceNamespace, authToken);

            return tokenPolicies;
        }

        public TResource Get<TResource>(string id) where TResource : Resource, new()
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentException("id may not be null or empty");
            }

            TResource resource = new TResource();
            resource.Id = id;
            AcsToken authToken = GetToken(resource);
            resource.GetFromService(this.serviceNamespace, authToken);

            return resource;
        }

        public Rule Get(string ruleSetId, string ruleId)
        {
            if (string.IsNullOrEmpty(ruleSetId))
            {
                throw new ArgumentException("ruleSetId may not be null or empty");
            }

            if (string.IsNullOrEmpty(ruleId))
            {
                throw new ArgumentException("ruleId may not be null or empty");
            }

            Rule rule = new Rule(ruleSetId);
            rule.Id = ruleId;
            AcsToken authToken = GetToken(rule);
            rule.GetFromService(this.serviceNamespace, authToken);

            return rule;
        }

        public TResourceCollection GetAll<TResourceCollection>() where TResourceCollection : ResourceCollection, new()
        {
            TResourceCollection resources = new TResourceCollection();
            AcsToken authToken = GetToken(resources);
            resources.GetFromService(this.serviceNamespace, authToken);

            return resources;
        }

        public RuleCollection GetAll(string ruleSetId)
        {
            if (string.IsNullOrEmpty(ruleSetId))
            {
                throw new ArgumentException("ruleSetId may not be null or empty");
            }

            RuleCollection rules = new RuleCollection(ruleSetId);
            AcsToken authToken = GetToken(rules);
            rules.GetFromService(this.serviceNamespace, authToken);

            return rules;
        }

        public void Update(Resource resource)
        {
            if (string.IsNullOrEmpty(resource.Id))
            {
                throw new ArgumentException("resource.Id may not be null or empty");
            }

            AcsToken authToken = GetToken(resource);
            resource.UpdateInService(this.serviceNamespace, authToken);
        }

        public void Delete<TResource>(string id) where TResource : Resource, new()
        {
            if (string.IsNullOrEmpty(id))
            {
                throw new ArgumentException("resource.Id may not be null or empty");
            }

            TResource resource = new TResource();
            resource.Id = id;
            AcsToken authToken = GetToken(resource);
            resource.DeleteFromService(this.serviceNamespace, authToken);
        }

        private AcsToken GetToken(IResource resource)
        {
            Uri domainUri = SetPortToDefault(Utilities.DomainUri(this.serviceNamespace, resource));
            return this.cache.GetToken(domainUri);
        }

        private static Uri SetPortToDefault(Uri uri)
        {
            UriBuilder builder = new UriBuilder(uri);
            builder.Port = -1;
            return builder.Uri;
        }
    }
}
