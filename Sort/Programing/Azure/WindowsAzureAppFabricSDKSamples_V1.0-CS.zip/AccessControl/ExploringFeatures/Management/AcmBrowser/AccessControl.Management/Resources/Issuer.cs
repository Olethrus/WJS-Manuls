﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System.Xml.Serialization;

    [XmlRoot(Namespace = Constants.ResourceNamespace)]
    public class Issuer : Resource
    {
        public override string Domain
        {
            get { return "issuers"; }
        }

        public string IssuerName { get; set; }
        public string FederationMetadata200706 { get; set; }
        public Security Security { get; set; }

        internal override void CopyFrom(Resource that)
        {
            Issuer thatIssuer = that as Issuer;

            if (thatIssuer != null)
            {
                base.CopyFrom(that);
                this.IssuerName = thatIssuer.IssuerName;
                this.Security = new Security();
                this.Security.Algorithm = thatIssuer.Security.Algorithm;
                this.Security.CurrentKey = thatIssuer.Security.CurrentKey;
                this.Security.PreviousKey = thatIssuer.Security.PreviousKey;
                this.FederationMetadata200706 = thatIssuer.FederationMetadata200706;
            }
        }
    }

    public class Security
    {
        public string Algorithm { get; set; }
        public string CurrentKey { get; set; }
        public string PreviousKey { get; set; }
    }
}
