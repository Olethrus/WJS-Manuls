﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System.IO;
    using System.Xml;
    using System.Xml.Serialization;

    [XmlRoot(Namespace = Constants.ResourceNamespace)]
    public abstract class Resource : IResource
    {
        [XmlElement(IsNullable = true)]
        public string DisplayName { get; set; }

        [XmlElement(IsNullable = true)]
        public string Id { get; set; }

        [XmlIgnore]
        public abstract string Domain { get; }

        public void Serialize(Stream stream)
        {
            XmlSerializer serializer = new XmlSerializer(this.GetType());
            serializer.Serialize(stream, this);
        }

        internal virtual void CopyFrom(Resource that)
        {
            this.DisplayName = that.DisplayName;
            this.Id = that.Id;
        }
    }
}
