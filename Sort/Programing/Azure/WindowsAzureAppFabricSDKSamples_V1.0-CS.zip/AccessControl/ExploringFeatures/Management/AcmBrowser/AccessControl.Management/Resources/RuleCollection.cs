﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System.Xml.Serialization;

    [XmlRoot(Namespace = Constants.ResourceNamespace, ElementName = "Rules")]
    public class RuleCollection : ResourceCollection
    {
        public override string Domain
        {
            get { return string.Format("rulesets/{0}/rules", RuleSetId); }
        }

        [XmlIgnore]
        public string RuleSetId { get; set; }

        private RuleCollection()
        {
        }

        public RuleCollection(string ruleSetId)
        {
            this.RuleSetId = ruleSetId;
        }

        [XmlArrayItem("Rule")]
        public new Rule this[int index]
        {
            get
            {
                return base[index] as Rule;
            }
            set
            {
                base[index] = value;
            }
        }
    }
}
