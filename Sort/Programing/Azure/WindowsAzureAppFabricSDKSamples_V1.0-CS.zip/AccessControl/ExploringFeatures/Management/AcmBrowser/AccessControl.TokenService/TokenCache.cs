﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;
    using System.Collections.Generic;
    using System.Threading;

    public class TokenCache
    {
        private static readonly TimeSpan DefaultLockTimeout = TimeSpan.FromSeconds(1);

        private Dictionary<Uri, AcsToken> cache;
        private TimeSpan lockTimeout;
        private ReaderWriterLock theLock;

        public Credentials Credentials { get; private set; }
        public Uri TokenServiceUri { get; private set; }

        public TokenCache(Uri tokenServiceUri, Credentials credentials)
            : this(tokenServiceUri, credentials, DefaultLockTimeout)
        {
        }

        public TokenCache(Uri tokenServiceUri, Credentials credentials, TimeSpan lockTimeout)
        {
            this.cache = new Dictionary<Uri, AcsToken>();
            this.lockTimeout = lockTimeout;
            this.theLock = new ReaderWriterLock();
            this.Credentials = credentials.Clone() as Credentials;
            this.TokenServiceUri = tokenServiceUri;
        }

        public void Clear()
        {
            cache.Clear();
        }

        public void Clear(Uri appliesTo)
        {
            cache.Remove(appliesTo);
        }

        public AcsToken GetToken(Uri appliesTo)
        {
            AcsToken token;
            bool isCached = false;

            try
            {
                this.theLock.AcquireReaderLock(this.lockTimeout);
                isCached = cache.TryGetValue(appliesTo, out token);
            }
            finally
            {
                this.theLock.ReleaseReaderLock();
            }

            if (!isCached)
            {
                token = RequestToken(appliesTo);
            }
            else if (token.ExpiresOn < DateTime.UtcNow)
            {
                // if the cached token is expired, let's get a new one
                token = RequestToken(appliesTo);
            }

            return token;
        }

        private AcsToken RequestToken(Uri appliesTo)
        {
            this.Credentials.AppliesTo = appliesTo;
            TokenRequest request = new TokenRequest(this.TokenServiceUri, this.Credentials);
            AcsToken token = request.GetResponse().Token;

            try
            {
                this.theLock.AcquireWriterLock(this.lockTimeout);
                this.cache[appliesTo] = token;
            }
            finally
            {
                this.theLock.ReleaseWriterLock();
            }

            return token;
        }
    }
}
