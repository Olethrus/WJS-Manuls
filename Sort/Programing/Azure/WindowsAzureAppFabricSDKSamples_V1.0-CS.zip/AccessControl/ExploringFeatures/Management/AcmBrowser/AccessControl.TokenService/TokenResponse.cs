﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System.Net;

    public class TokenResponse
    {
        public AcsToken Token { get; private set; }
        public string TrackingId { get; private set; }

        public TokenResponse(HttpWebRequest webRequest)
        {
            InitializeFromWebRequest(webRequest);
        }

        private void InitializeFromWebRequest(HttpWebRequest webRequest)
        {
            try
            {
                HttpWebResponse webResponse = (HttpWebResponse)webRequest.GetResponse();
                if (webResponse.StatusCode == HttpStatusCode.OK)
                {
                    this.Token = new AcsToken();
                    this.Token.Decode(webResponse.GetResponseStream());
                    this.TrackingId = webResponse.Headers[Constants.TrackingIdHeader];
                }
            }
            catch (WebException e)
            {
                TokenServiceException.Throw(e);
            }
        }
    }
}
