﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System.Collections.Generic;

    public class SharedSecretToken : Credentials
    {
        public string Name { get; set; }
        public string Password { get; set; }

        public SharedSecretToken()
        {
        }

        private SharedSecretToken(SharedSecretToken toCopy)
        {
            this.Name = toCopy.Name;
            this.Password = toCopy.Password;
            this.AppliesTo = toCopy.AppliesTo;
            this.Claims = toCopy.Claims.Clone() as ClaimSet;
        }

        public override object Clone()
        {
            return new SharedSecretToken(this);
        }

        internal override string Encode()
        {
            this.Validate();

            Dictionary<string, string> parameterDictionary = new Dictionary<string, string>();
            parameterDictionary[Constants.WRAP_Name] = this.Name;
            parameterDictionary[Constants.WRAP_Password] = this.Password;
            parameterDictionary[Constants.WRAP_AppliesTo] = this.AppliesTo.AbsoluteUri;

            foreach (Claim claim in this.Claims)
            {
                string value = claim.Value;
                if (parameterDictionary.TryGetValue(claim.Type, out value))
                {
                    value = value + "," + claim.Value;
                }
                parameterDictionary[claim.Type] = value;
            }

            return Helper.UrlEncode(parameterDictionary);
        }

        internal override void Validate()
        {
            Helper.ThrowIfNull(this.AppliesTo, "AppliesTo");
            Helper.ThrowIfNullOrEmpty(this.Name, "Name");
            Helper.ThrowIfNotValidKey(this.Password, "Password");
        }
    }
}
