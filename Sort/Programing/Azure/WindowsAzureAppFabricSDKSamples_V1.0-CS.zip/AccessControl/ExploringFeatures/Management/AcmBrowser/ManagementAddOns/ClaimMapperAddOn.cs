﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Linq;
    using AccessControl.Management;
    using ManagementAddOns.UI;
    using AcmBrowser;
    using AcmBrowser.Model;

    public class ClaimMapperAddOn : AddOn
    {
        private ClaimMapperWindow window;

        public override string Title
        {
            get { return "Claim Mapper"; }
        }

        public override Icon Icon
        {
            get { return ManagementAddOns.Properties.Resources.ClaimMapper; }
        }

        public override bool RefreshTree
        {
            get { return false; }
        }

        public ClaimMapperAddOn(Browser browser)
            : base(browser)
        {
        }

        protected override void OnInvoke()
        {
            this.window = new ClaimMapperWindow();
            this.window.Icon = Icon.ToWindowIcon();
            this.window.MapClaims += MapClaims;
            this.window.Show();
        }

        private void MapClaims(List<RuleXml> rules)
        {
            List<Claim> inputClaims = this.window.InputClaims;
            HashSet<Claim> outputClaims = new HashSet<Claim>();
            List<Claim> producedClaims = new List<Claim>();

            // create dictionaries for the quick lookup of rules by input claim
            Dictionary<Claim, List<RuleXml>> passThroughRulesByClaim;
            Dictionary<Claim, List<RuleXml>> rulesByClaim;
            CreateRuleDictionaries(rules, out rulesByClaim, out passThroughRulesByClaim);

            do
            {
                producedClaims = new List<Claim>();

                foreach (Claim claim in inputClaims)
                {
                    List<RuleXml> matchingRules = new List<RuleXml>();
                    List<RuleXml> nonPassThroughRules, passThroughRules;

                    // find the matching pass-through rules for each claim
                    if (passThroughRulesByClaim.TryGetValue(claim, out passThroughRules))
                    {
                        matchingRules.AddRange(passThroughRules);
                    }

                    // find the matching non-pass-through rules for each claim
                    if (rulesByClaim.TryGetValue(claim, out nonPassThroughRules))
                    {
                        matchingRules.AddRange(nonPassThroughRules);
                    }

                    foreach (RuleXml matchingRule in matchingRules)
                    {
                        // produce the new claim (with the passed-through value, if necessary)
                        Claim producedClaim =
                            new Claim(Constants.ServiceNamespaceIssuer, matchingRule.OutputClaimType, matchingRule.OutputClaimValue);
                        if (string.Equals(matchingRule.Type, "PassThrough", StringComparison.OrdinalIgnoreCase))
                        {
                            producedClaim = new Claim(producedClaim.Issuer, producedClaim.Type, claim.Value);
                        }

                        // if we haven't produced this claim yet
                        if (!outputClaims.Contains(producedClaim))
                        {
                            producedClaims.Add(producedClaim);
                        }
                    }
                }

                if (producedClaims.Count > 0)
                {
                    outputClaims.UnionWith(producedClaims);
                    inputClaims = producedClaims;
                }
            }
            while (producedClaims.Count > 0);

            this.window.OutputClaims = outputClaims.Distinct().ToList();
        }

        private void CreateRuleDictionaries(List<RuleXml> rules, out Dictionary<Claim, List<RuleXml>> rulesByClaim, out Dictionary<Claim, List<RuleXml>> passThroughRulesByClaim)
        {
            passThroughRulesByClaim =
                new Dictionary<Claim, List<RuleXml>>(new PassThroughClaimComparer());
            rulesByClaim = new Dictionary<Claim, List<RuleXml>>();

            foreach (RuleXml rule in rules)
            {
                Dictionary<Claim, List<RuleXml>> rulesDictionary =
                    string.Equals(rule.Type, "PassThrough", StringComparison.OrdinalIgnoreCase) ? passThroughRulesByClaim : rulesByClaim;

                List<RuleXml> rulesWithCommonInputClaim;
                Claim inputClaim = new Claim(rule.InputClaimIssuerHandle, rule.InputClaimType, rule.InputClaimValue);
                if (!rulesDictionary.TryGetValue(inputClaim, out rulesWithCommonInputClaim))
                {
                    rulesWithCommonInputClaim = new List<RuleXml>();
                    rulesDictionary.Add(inputClaim, rulesWithCommonInputClaim);
                }
                rulesWithCommonInputClaim.Add(rule);
            }
        }
    }

    public class Claim
    {
        public string Issuer { get; set; }
        public string Type { get; set; }
        public string Value { get; set; }

        public Claim(string issuer, string type, string value)
        {
            this.Issuer = issuer;
            this.Type = type;
            this.Value = value;
        }

        public override bool Equals(object obj)
        {
            Claim that = obj as Claim;

            return (that != null &&
                    this.Issuer == that.Issuer &&
                    this.Type == that.Type &&
                    this.Value == that.Value);
        }

        public override int GetHashCode()
        {
            return (this.Issuer + this.Type + this.Value).GetHashCode();
        }

        public override string ToString()
        {
            return string.Format("Type: {0}, Value: {1}", this.Type, this.Value);
        }
    }

    public class PassThroughClaimComparer : EqualityComparer<Claim>
    {
        public override bool Equals(Claim x, Claim y)
        {
            if (x == y)
                return true;
            else if (x == null || y == null)
                return false;
            else
                return (x.Issuer == y.Issuer && x.Type == y.Type);
        }

        public override int GetHashCode(Claim obj)
        {
            return (obj.Issuer + obj.Type).GetHashCode();
        }
    }

}
