﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns.Helpers
{
    using System.IO;
    using System.Net;
    using AccessControl.Management;
    using AcmBrowser.Model;

    public static class ConversionHelper
    {
        public static Issuer ToIssuer(this IssuerXml issuerXml)
        {
            Issuer issuer = new Issuer();
            issuer.InitializeResource(issuerXml);

            if (string.IsNullOrEmpty(issuerXml.FedMetadataUri))
            {
                issuer.IssuerName = issuerXml.IssuerName;

                Security security = new Security();
                security.Algorithm = issuerXml.Algorithm;
                security.CurrentKey = issuerXml.CurrentKey;
                security.PreviousKey = issuerXml.PreviousKey;
                issuer.Security = security;
            }
            else
            {
                // the IssuerName and Security fields cannot be specified along with FedMetadata
                issuer.IssuerName = null;
                issuer.Security = null;
            }

            issuer.FederationMetadata200706 = FederationMetadata(issuerXml.FedMetadataUri);
            
            return issuer;
        }

        private static string FederationMetadata(string uri)
        {
            string fedMetadata = null;
            if (!string.IsNullOrEmpty(uri))
            {
                WebRequest request = WebRequest.Create(uri);
                WebResponse response = request.GetResponse();

                using (Stream stream = response.GetResponseStream())
                {
                    using (StreamReader reader = new StreamReader(stream))
                    {
                        fedMetadata = reader.ReadToEnd();
                    }
                }
            }
            return fedMetadata;
        }

        public static IssuerXml ToIssuerXml(this Issuer issuer)
        {
            IssuerXml issuerXml = new IssuerXml();
            issuerXml.InitializeResource(issuer);

            issuerXml.IssuerName = issuer.IssuerName;
            issuerXml.Algorithm = issuer.Security.Algorithm;
            issuerXml.CurrentKey = issuer.Security.CurrentKey;
            issuerXml.PreviousKey = issuer.Security.PreviousKey;
            issuerXml.FedMetadataUri = string.Empty;

            return issuerXml;
        }

        public static Rule ToRule(this RuleXml ruleXml)
        {
            Rule rule = new Rule(string.Empty);
            rule.InitializeResource(ruleXml);

            rule.Type = ruleXml.Type;

            InputClaim inputClaim = new InputClaim();
            inputClaim.Type = ruleXml.InputClaimType;
            inputClaim.Value = ruleXml.InputClaimValue;
            rule.InputClaim = inputClaim;

            OutputClaim outputClaim = new OutputClaim();
            outputClaim.Type = ruleXml.OutputClaimType;
            outputClaim.Value = ruleXml.OutputClaimValue;
            rule.OutputClaim = outputClaim;

            return rule;
        }

        public static RuleXml ToRuleXml(this Rule rule)
        {
            RuleXml ruleXml = new RuleXml();
            ruleXml.InitializeResource(rule);

            ruleXml.Type = rule.Type;

            ruleXml.InputClaimType = rule.InputClaim.Type;
            ruleXml.InputClaimValue = rule.InputClaim.Value;

            ruleXml.OutputClaimType = rule.OutputClaim.Type;
            ruleXml.OutputClaimValue = rule.OutputClaim.Value;

            return ruleXml;
        }

        public static Scope ToScope(this ScopeXml scopeXml)
        {
            Scope scope = new Scope();
            scope.InitializeResource(scopeXml);

            scope.AppliesTo = scopeXml.AppliesTo;

            return scope;
        }

        public static ScopeXml ToScopeXml(this Scope scope)
        {
            ScopeXml scopeXml = new ScopeXml();
            scopeXml.InitializeResource(scope);

            scopeXml.AppliesTo = scope.AppliesTo;

            return scopeXml;
        }

        public static TokenPolicy ToTokenPolicy(this TokenPolicyXml tokenPolicyXml)
        {
            TokenPolicy tokenPolicy = new TokenPolicy();
            tokenPolicy.InitializeResource(tokenPolicyXml);

            tokenPolicy.DefaultTokenLifetimeInSeconds = tokenPolicyXml.TokenLifetime;
            tokenPolicy.SigningKey = tokenPolicyXml.SigningKey;

            return tokenPolicy;
        }

        public static TokenPolicyXml ToTokenPolicyXml(this TokenPolicy tokenPolicy)
        {
            TokenPolicyXml tokenPolicyXml = new TokenPolicyXml();
            tokenPolicyXml.InitializeResource(tokenPolicy);

            tokenPolicyXml.TokenLifetime = string.IsNullOrEmpty(tokenPolicy.DefaultTokenLifetimeInSeconds) ? "(hidden)" : tokenPolicy.DefaultTokenLifetimeInSeconds;
            tokenPolicyXml.SigningKey = string.IsNullOrEmpty(tokenPolicy.SigningKey) ? "(hidden)" : tokenPolicy.SigningKey;

            return tokenPolicyXml;
        }

        private static void InitializeResource(this Resource resource, ResourceXml resourceXml)
        {
            resource.DisplayName = resourceXml.Handle;
        }

        private static void InitializeResource(this ResourceXml resourceXml, Resource resource)
        {
            // what we get from the service may not have a name
            resourceXml.Handle = string.IsNullOrEmpty(resource.DisplayName) ? "(no name)" : resource.DisplayName;
        }
    }
}
