﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns.Helpers
{
    using System.Linq;
    using AccessControl.Management;

    public static class ResolutionHelper
    {
        public static string ResolveIssuerHandle(this IssuerCollection issuers, string handle)
        {
            return (handle == "ACS") ? "ACS" : issuers.First((issuer) => issuer.DisplayName == handle).Id;
        }

        public static string ResolveIssuerId(this IssuerCollection issuers, string id)
        {
            return (id == "ACS") ? "ACS" : issuers.First((issuer) => issuer.Id == id).DisplayName;
        }

        public static string ResolveTokenPolicyHandle(this TokenPolicyCollection tokenPolicies, string handle)
        {
            return tokenPolicies.First((tokenPolicy) => tokenPolicy.DisplayName == handle).Id;
        }

        public static string ResolveTokenPolicyId(this TokenPolicyCollection tokenPolicies, string id)
        {
            return tokenPolicies.First((tokenPolicy) => tokenPolicy.Id == id).DisplayName;
        }
    }
}
