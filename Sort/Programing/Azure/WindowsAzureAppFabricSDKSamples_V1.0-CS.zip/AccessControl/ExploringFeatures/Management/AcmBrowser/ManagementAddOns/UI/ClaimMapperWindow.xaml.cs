﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns.UI
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using AcmBrowser.Model;

    /// <summary>
    /// Interaction logic for ClaimMapperWindow.xaml
    /// </summary>
    public partial class ClaimMapperWindow : Window
    {
        public List<Claim> InputClaims { get; set; }
        public List<Claim> OutputClaims { get; set; }

        public delegate void ClaimMapper(List<RuleXml> rules);
        public ClaimMapper MapClaims { get; set; }

        public ClaimMapperWindow()
        {
            InitializeComponent();
            InitializeScopesBox();
            InitializeIssuersBox();
            this.InputClaims = new List<Claim>();
            this.OutputClaims = new List<Claim>();
        }

        private void InitializeScopesBox()
        {
            foreach (ScopeXml scope in ServiceNamespace.Instance.Scopes)
            {
                ComboBoxItem item = new ComboBoxItem();
                item.Content = scope.Handle;
                this.scopesBox.Items.Add(item);
            }
        }

        private void InitializeIssuersBox()
        {
            foreach (IssuerXml issuer in ServiceNamespace.Instance.Issuers)
            {
                ComboBoxItem item = new ComboBoxItem();
                item.Content = issuer.Handle;
                this.issuersBox.Items.Add(item);
            }
            this.issuersBox.SelectionChanged += new SelectionChangedEventHandler(UpdateClaimTypesBox);
        }

        private void UpdateClaimTypesBox(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem issuerItem = this.issuersBox.SelectedItem as ComboBoxItem;
            string issuerHandle = (string)issuerItem.Content;
            ScopeXml scope = GetSelectedScope();

            IEnumerable<RuleXml> rules = scope.Rules.Where((rule) => rule.InputClaimIssuerHandle == issuerHandle);
            IEnumerable<string> claimTypes = rules.Select((rule) => rule.InputClaimType).Distinct();

            foreach (string claimType in claimTypes)
            {
                ComboBoxItem item = new ComboBoxItem();
                item.Content = claimType;
                this.claimTypesBox.Items.Add(item);
            }
        }

        private void AddInputClaim(object sender, RoutedEventArgs e)
        {
            ComboBoxItem issuerItem = this.issuersBox.SelectedItem as ComboBoxItem;
            string claimType = this.claimTypesBox.Text;
            string claimValue = this.claimValue.Text;
            string claimIssuer = (string)issuerItem.Content;
            Claim claim = new Claim(claimIssuer, claimType, claimValue);
            this.InputClaims.Add(claim);

            ListBoxItem item = new ListBoxItem();
            item.Content = claim.ToString();
            this.inputClaimsBox.Items.Add(item);
        }

        private void MapClaimsClicked(object sender, RoutedEventArgs e)
        {
            List<RuleXml> rules = GetSelectedScope().Rules;
            MapClaims(rules);

            this.outputClaimsBox.Items.Clear();
            foreach (Claim outputClaim in this.OutputClaims)
            {
                ListBoxItem item = new ListBoxItem();
                item.Content = outputClaim.ToString();
                this.outputClaimsBox.Items.Add(item);
            }
        }

        private ScopeXml GetSelectedScope()
        {
            ComboBoxItem scopeItem = this.scopesBox.SelectedItem as ComboBoxItem;
            string scopeHandle = (string)scopeItem.Content;

            return ServiceNamespace.Instance.Scopes.First((s) => s.Handle == scopeHandle);
        }

        private void ClearInputClaims(object sender, RoutedEventArgs e)
        {
            this.InputClaims.Clear();
            this.inputClaimsBox.Items.Clear();
        }
    }
}
