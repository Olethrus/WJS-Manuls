﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser
{
    using System;
    using System.Drawing;
    using AccessControl.Management;
    using AccessControl.TokenService;

    public abstract class AddOn
    {
        public Browser ParentBrowser { get; private set; }

        public abstract string Title { get; }
        public abstract Icon Icon { get; }
        public abstract bool RefreshTree { get; }

        public delegate void InvokeHandler(AddOn addOn);
        public InvokeHandler OnBegin { get; set; }
        public InvokeHandler OnEnd { get; set; }

        public delegate void UpdateProgress(double fractionComplete);
        public UpdateProgress ProgressUpdate { get; set; }

        public delegate void UpdateStatus(string status);
        public UpdateStatus StatusUpdate { get; set; }

        public delegate void ExceptionHandler(AddOnException e);
        public ExceptionHandler OnException { get; set; }

        public AddOn(Browser parentBrowser)
        {
            this.ParentBrowser = parentBrowser;
        }

        public virtual void Invoke()
        {
            try
            {
                OnBeginInvoke();
                OnInvoke();
                OnEndInvoke();
            }
            catch (Exception e)
            {
                HandleException(e);
            }
        }

        protected virtual void HandleException(Exception e)
        {
            AddOnException exception;

            if (e is TokenException)
            {
                exception = new AddOnException("An error occurred authorizing your request." +
                                               "\nPlease verify that your service namespace and management key are correct and try again." +
                                               "\nDetails: " + e.Message, e);
            }
            else if (e is ManagementException)
            {
                exception = new AddOnException("An error occurred processing your request with the management service." +
                                               "\nPlease address the issue below." +
                                               "\nNOTE: your service namespace may be in an inconsistent state." +
                                               "\nPlease clear your service namespace and try again." +
                                               "\nDetails: " + e.Message, e);
            }
            else
            {
                exception = new AddOnException("An error occurred while invoking an add on." +
                                               "\nDetails: " + e.Message, e);
            }

            if (OnException != null)
                OnException(exception);
        }

        protected virtual void OnBeginInvoke()
        {
            if (OnBegin != null)
                OnBegin(this);
        }

        protected virtual void OnEndInvoke()
        {
            if (OnEnd != null)
                OnEnd(this);
        }

        protected abstract void OnInvoke();
    }
}
