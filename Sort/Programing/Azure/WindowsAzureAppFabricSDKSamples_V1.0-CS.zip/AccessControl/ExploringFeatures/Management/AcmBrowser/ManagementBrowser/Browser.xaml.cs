﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Threading;
    using AccessControl.Management;
    using AcmBrowser.Model;
    using AcmBrowser.UI;

    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Browser : Window
    {
        private ResourceTree resourceTree;
        private Grid contentFrame;

        public string Namespace { get; set; }
        public string ManagementKey { get; set; }

        public Browser()
        {
            InitializeComponent();
            this.Icon = AcmBrowser.Properties.Resources.NetServices.ToWindowIcon();

            this.serviceLabel.Content = string.Format("Connected to {0}.",  Constants.AccessControlBaseAddress);

            this.resourceTree = new ResourceTree();
            this.resourceTree.Width = 200;
            DockPanel.SetDock(this.resourceTree, Dock.Left);
            this.Frame.Children.Add(this.resourceTree);
            this.resourceTree.SelectedResourceChanged += DisplaySelectedItem;

            this.contentFrame = new Grid();
            DockPanel.SetDock(this.contentFrame, Dock.Right);
            this.Frame.Children.Add(this.contentFrame);

            LoadAddOns();
        }

        public bool IsServiceBusServiceNamespace()
        {
            return this.Namespace.EndsWith("-sb", StringComparison.OrdinalIgnoreCase);
        }

        private void AddOnButtonClicked(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            string name = button.ToolTip.ToString();
            AddOnManager.Invoke(name);
        }

        private void AddOnDone(AddOn addOn)
        {
            if (addOn.RefreshTree)
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    (SendOrPostCallback)delegate 
                    { 
                        this.resourceTree.LoadServiceNamespace();
                        DisplayPanel(new UserControl());
                    }, null);
            }
        }

        private void DisplaySelectedItem(ResourceXml resource)
        {
            DisplayPanel(resource.GetResourcePanel());
        }

        private void DisplayPanel(UserControl control)
        {
            this.contentFrame.Children.Clear();
            this.contentFrame.Children.Add(control);
        }

        private void LoadAddOns()
        {
            IOrderedEnumerable<KeyValuePair<string, AddOn>> addOns = AddOnManager.LoadAddOns(this, Environment.CurrentDirectory).OrderBy((pair) => pair.Key);

            foreach (KeyValuePair<string, AddOn> addOnPair in addOns)
            {
                AddOn addOn = addOnPair.Value;
                addOn.OnEnd += AddOnDone;
                addOn.ProgressUpdate += UpdateProgressBar;
                addOn.StatusUpdate += UpdateStatus;
                addOn.OnException += OnException;
                Button button = new Button();
                button.Content = addOn.Icon.ToImage();
                button.ToolTip = addOn.Title;
                button.Click += new RoutedEventHandler(AddOnButtonClicked);
                this.addOnMenu.Items.Add(button);
            }
        }

        private void OnException(Exception e)
        {
            UpdateProgressBar(0);
            UpdateStatus("Ready");

            if (e is AddOnException)
            {
                MessageBox.Show(e.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            else
            {
                MessageBox.Show("There was an unexpected error. The program is halting." +
                                "\nDetails: " + e.Message, "Unexpected Error", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    (SendOrPostCallback)delegate
                    {
                        this.Close();
                    }, null);
            }
        }

        private void UpdateProgressBar(double progress)
        {
            if (progress == 1.0)
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    (SendOrPostCallback)delegate 
                    { 
                        this.progressBar.Value = 0;
                    }, null);
            }
            else
            {
                Dispatcher.BeginInvoke(DispatcherPriority.Background,
                    (SendOrPostCallback)delegate 
                    { 
                        this.progressBar.Value = progress; 
                    }, null);
            }
        }

        private void UpdateStatus(string status)
        {
            Dispatcher.BeginInvoke(DispatcherPriority.Background,
                (SendOrPostCallback)delegate
                {
                    this.statusLabel.Content = status;
                }, null);
        }

        private void ManagementKeyChanged(object sender, RoutedEventArgs e)
        {
            this.ManagementKey = this.keyBox.Password;
        }

        private void NamespaceChanged(object sender, TextChangedEventArgs e)
        {
            this.Namespace = this.nameBox.Text;
        }
    }
}
