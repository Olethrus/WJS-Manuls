﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System.Windows;
    using System.Windows.Controls;
    using AccessControl.Management;
    using AcmBrowser.Model;

    /// <summary>
    /// Interaction logic for TokenPolicyPanel.xaml
    /// </summary>
    public partial class TokenPolicyPanel : UserControl
    {
        public TokenPolicyPanel(TokenPolicyXml tokenPolicy)
        {
            InitializeComponent();
            this.form.DataContext = tokenPolicy;
        }

        private void GenerateSigningKey(object sender, RoutedEventArgs e)
        {
            this.signingKey.Text = Utilities.GenerateKey();
        }
    }
}
