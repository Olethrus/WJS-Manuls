﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System.Windows;
    using System.Windows.Controls;

    public class ResourceNode : TreeViewItem
    {
        public delegate void CreateClickedHandler(ResourceNode sourceNode);
        public CreateClickedHandler CreateClicked { get; set; }

        public ResourceNode(string header)
        {
            this.Header = header;
            this.FontWeight = FontWeights.Bold;

            MenuItem menuItem = new MenuItem();
            menuItem.Header = "Create...";
            menuItem.Click += new RoutedEventHandler(CreateMenuItemClicked);
            this.ContextMenu = new ContextMenu();
            this.ContextMenu.Items.Add(menuItem);
        }

        private void CreateMenuItemClicked(object sender, RoutedEventArgs e)
        {
            this.CreateClicked(this);
        }
    }
}
