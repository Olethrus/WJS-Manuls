﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.Samples.AcmTool
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;
    using System.Security;
    using System.Security.Permissions;
    using System.Text;

    internal enum PrintFormat
    {
        Error,
        Warning,
        Header,
        SubHeader,
        Message,
        Success
    }

    internal class ConsoleUtil
    {
        internal static void WriteMessage()
        {
            WriteMessage(PrintFormat.Message, String.Empty);
        }

        internal static void WriteMessage(string format, params object[] args)
        {
            WriteMessage(PrintFormat.Message, format, args);
        }

        internal static void WriteMessage(PrintFormat printFormat, string format, params object[] args)
        {
            switch (printFormat)
            {
                case PrintFormat.Error:
                    Write(ConsoleColor.Red, true, format, args);
                    break;
                case PrintFormat.Header:
                    Write(ConsoleColor.Cyan, false, format, args);
                    break;
                case PrintFormat.Message:
                    Write(ConsoleColor.Gray, false, format, args);
                    break;
                case PrintFormat.SubHeader:
                    Write(ConsoleColor.White, false, format, args);
                    break;
                case PrintFormat.Success:
                    Write(ConsoleColor.Green, false, format, args);
                    break;
                case PrintFormat.Warning:
                    Write(ConsoleColor.Yellow, true, format, args);
                    break;
            }
        }

        private static void Write(ConsoleColor foregroundColor, bool isError, string format, params object[] args)
        {
            ConsoleColor beforeColor = Console.ForegroundColor;
            Console.ForegroundColor = foregroundColor;

            if (!isError)
            {
                Console.WriteLine(format, args);
            }
            else
            {
                Console.Error.WriteLine(format, args);
            }

            Console.ForegroundColor = beforeColor;
        }
    }
}
