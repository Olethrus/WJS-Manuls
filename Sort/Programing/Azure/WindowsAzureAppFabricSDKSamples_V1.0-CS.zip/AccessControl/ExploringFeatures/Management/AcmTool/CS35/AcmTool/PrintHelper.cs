﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------
namespace Microsoft.AccessControl.Samples.AcmTool
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;
    using System.Text;
    using AcmTool.Commands;

    internal static class PrintHelper
    {
        // set of required options to create scope
        private static string[] requiredOptionCreateScope = new string[]
        {
            Constants.OptionGeneralName,
            Constants.OptionScopeAppliesTo,
            Constants.OptionScopeTokenPolicyId,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey,
            Constants.OptionSimpleOut
        };

        // set of required options to update scope
        private static string[] requiredOptionUpdateScope = new string[]
        {
            Constants.OptionGeneralId,
            Constants.OptionGeneralName,
            Constants.OptionScopeAppliesTo,
            Constants.OptionScopeTokenPolicyId,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey
        };

        // set of required options to create tokenpolicy
        private static string[] requiredOptionCreateTokenPolicy = new string[]
        {
            Constants.OptionGeneralName,
            Constants.OptionGeneralKey,
            Constants.OptionTokenPolicyDefaultTimeOut,
            Constants.OptionAutoGenerate,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey,
            Constants.OptionSimpleOut
        };

        // set of required options to update tokenpolicy
        private static string[] requiredOptionUpdateTokenPolicy = new string[]
        {
            Constants.OptionGeneralId,
            Constants.OptionGeneralName,
            Constants.OptionGeneralKey,
            Constants.OptionTokenPolicyDefaultTimeOut,
            Constants.OptionAutoGenerate,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey
        };

        // set required options to create issuer
        private static string[] requiredOptionCreateIssuer = new string[]
        {
            Constants.OptionGeneralName,
            Constants.OptionIssuerName,
            Constants.OptionIssuerAlgorithm,
            Constants.OptionGeneralKey,
            Constants.OptionIssuerPreviousKey,
            Constants.OptionIssuerCert,
            Constants.OptionAutoGenerate,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey,
            Constants.OptionSimpleOut
        };

        // set of required options to update issuer
        private static string[] requiredOptionUpdateIssuer = new string[]
        {
            Constants.OptionGeneralId,
            Constants.OptionGeneralName,
            Constants.OptionIssuerName,
            Constants.OptionIssuerAlgorithm,
            Constants.OptionGeneralKey,
            Constants.OptionIssuerPreviousKey,
            Constants.OptionIssuerCert,
            Constants.OptionAutoGenerate,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey
        };

        // set of required options to create rule
        private static string[] requiredOptionCreateRule = new string[]
        {
            Constants.OptionGeneralName,
            Constants.OptionRuleScopeId,
            Constants.OptionRuleInputClaimIssuerId,
            Constants.OptionRuleInputClaimType,
            Constants.OptionRuleInputClaimValue,
            Constants.OptionRuleOutputClaimType,
            Constants.OptionRuleOutputClaimValue,
            Constants.OptionRuleIsPassthrough,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey,
            Constants.OptionSimpleOut
        };

        // set of required options to update rule
        private static string[] requiredOptionUpdateRule = new string[]
        {
            Constants.OptionGeneralId,
            Constants.OptionGeneralName,
            Constants.OptionRuleScopeId,
            Constants.OptionRuleInputClaimIssuerId,
            Constants.OptionRuleInputClaimType,
            Constants.OptionRuleInputClaimValue,
            Constants.OptionRuleOutputClaimType,
            Constants.OptionRuleOutputClaimValue,
            Constants.OptionRuleIsPassthrough,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey
        };

        // set of required options to get/delete rule
        private static string[] requiredOptionRuleSingle = new string[]
        {
            Constants.OptionGeneralId,
            Constants.OptionRuleScopeId,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey
        };

        // set of required options to getall rule
        private static string[] requiredOptionRuleMultiple = new string[]
        {
            Constants.OptionRuleScopeId,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey
        };

        // set of required options to delete resource (except rule)
        private static string[] requiredOptionDelete = new string[]
        {
            Constants.OptionGeneralId,
            Constants.OptionGeneralName,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey,
        };

        // set of required options to delete rule
        private static string[] requiredOptionDeleteRule = new string[]
        {
            Constants.OptionGeneralId,
            Constants.OptionGeneralName,
            Constants.OptionRuleScopeId,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey,
        };

        // set of required options to get a resource (except rule)
        private static string[] requiredOptionGet = new string[]
        { 
            Constants.OptionGeneralId,
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey
        };

        // set of required options to getall resource (except rule)
        private static string[] requiredOptionGetAll = new string[]
        { 
            Constants.OptionServiceName,
            Constants.OptionHost,
            Constants.OptionManagementKey
        };

        internal static void PrintException(Exception ex)
        {
            ConsoleUtil.WriteMessage(PrintFormat.Error, ex.Message);
        }

        internal static void PrintResponseMessage(ResponseMessage response)
        {
            if (response.Status == OperationStatus.Failure)
            {
                ConsoleUtil.WriteMessage(PrintFormat.Error, response.Message);
            }
            else if (response.Status == OperationStatus.Success)
            {
                ConsoleUtil.WriteMessage(PrintFormat.Success, response.Message);
            }
            else
            {
                ConsoleUtil.WriteMessage(response.Message);
            }
        }

        internal static void PrintHelp(CommandLineArguments commandLineArgs)
        {
            PrintHeader();

            if (!commandLineArgs.HasCommand())
            {
                PrintGeneralHelp();
            }
            else
            {
                switch (commandLineArgs.Command)
                {
                    case CommandType.Create:
                        if (commandLineArgs.HasResource())
                        {
                            switch (commandLineArgs.Resource)
                            {
                                case ResourceType.Scope:
                                    PrintOptionHelp("create scope -name:<name> -tokenpolicyid:<tokenpolicyid> -appliesto:<appliesto> [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>] [-simpleout]", requiredOptionCreateScope);
                                    break;
                                case ResourceType.TokenPolicy:
                                    PrintOptionHelp("create tokenpolicy -name:<name> [-timeout:<timeout>] (-key:<key> | -autogeneratekey) [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>] [-simpleout]", requiredOptionCreateTokenPolicy);
                                    break;
                                case ResourceType.Issuer:
                                    PrintOptionHelp("create issuer -name:<name> -issuername:<issuername> (-key:<key> | -certfile | -autogeneratekey) [-previouskey:<previouskey>] [-algorithm:<Symmetric256BitKey|X509>] [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>] [-simpleout]", requiredOptionCreateIssuer);
                                    break;
                                case ResourceType.Rule:
                                    PrintOptionHelp("create rule -scopeid:<scopeid> -inclaimissuerid:<inclaimissuerid> -inclaimtype:<inclaimtype> -inclaimvalue:<inclaimvalue> -outclaimtype:<outclaimtype> -outclaimvalue:<outclaimvalue> [-passthrough] [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]  [-simpleout]", requiredOptionCreateRule);
                                    break;
                            }
                        }
                        else
                        {
                            PrintGeneralHelp();
                        }

                        break;
                    case CommandType.Update:
                        if (commandLineArgs.HasResource())
                        {
                            switch (commandLineArgs.Resource)
                            {
                                case ResourceType.Scope:
                                    PrintOptionHelp("update scope -id:<id> -name:<name> -tokenpolicyid:<tokenpolicyid> -appliesto:<appliesto> [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionUpdateScope);
                                    break;
                                case ResourceType.TokenPolicy:
                                    PrintOptionHelp("update tokenpolicy -id:<id> -name:<name> [-timeout:<timeout>] (-key:<key> | -autogeneratekey) [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionUpdateTokenPolicy);
                                    break;
                                case ResourceType.Issuer:
                                    PrintOptionHelp("update issuer -id:<id> -name:<name> -issuername:<issuername> (-key:<key> | -certfile:<certfile> | -autogeneratekey) [-previouskey:<previouskey>] [-algorithm:<Symmetric256BitKey|X509>] [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionUpdateIssuer);
                                    break;
                                case ResourceType.Rule:
                                    PrintOptionHelp("update rule -id:<id> -name:<name> -scopeid:<scopeid> -inclaimissuerid:<inclaimissuerid> -inclaimtype:<inclaimtype> -inclaimvalue:<inclaimvalue> -outclaimtype:<outclaimtype> -outclaimvalue:<outclaimvalue> [-passthrough] [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionUpdateRule);
                                    break;
                            }
                        }
                        else
                        {
                            PrintGeneralHelp();
                        }

                        break;
                    case CommandType.Delete:
                        if (commandLineArgs.Resource == ResourceType.Rule)
                        {
                            PrintOptionHelp("delete rule -id:<id>|-name:<name> -scopeid:<scopeid>  [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionDeleteRule);
                        }
                        else if (commandLineArgs.HasResource())
                        {
                            PrintOptionHelp("delete " + commandLineArgs.Resource + " -id:<id>|-name:<name> [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionDelete);
                        }
                        else
                        {
                            PrintGeneralHelp();
                        }

                        break;
                    case CommandType.Get:
                        if (commandLineArgs.Resource == ResourceType.Rule)
                        {
                            PrintOptionHelp("get rule -id:<id> -scopeid:<scopeid> [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionRuleSingle);
                        }
                        else if (commandLineArgs.HasResource())
                        {
                            PrintOptionHelp("get " + commandLineArgs.Resource + " -id:<id> [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionGet);
                        }
                        else
                        {
                            PrintGeneralHelp();
                        }

                        break;
                    case CommandType.GetAll:
                        if (commandLineArgs.Resource == ResourceType.Rule)
                        {
                            PrintOptionHelp("getall rule -scopeid:<scopid> [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionRuleMultiple);
                        }
                        else if (commandLineArgs.HasResource())
                        {
                            PrintOptionHelp("getall " + commandLineArgs.Resource + " [-service:<service>] [-host:<host>] [-mgmtkey:<mgmtkey>]", requiredOptionGetAll);
                        }
                        else
                        {
                            PrintGeneralHelp();
                        }

                        break;
                    default:
                        PrintGeneralHelp();
                        break;
                }
            }
        }

        internal static string FormatKeyValue(string key, string value)
        {
            return String.Format(CultureInfo.InvariantCulture, "{0,18}: {1}", key, value);
        }

        // Prints formatted text related to the Arguments specified in input
        private static void PrintArgumentOptions(string[] arguments)
        {
            Dictionary<string, string> parameterHelpInfo = new Dictionary<string, string>();

            // Commands
            parameterHelpInfo[CommandType.Create.ToString()] = "Create a scope, rule, issuer, or token policy";
            parameterHelpInfo[CommandType.Delete.ToString()] = "Delete a scope, rule, issuer, or token policy by ID or Name";
            parameterHelpInfo[CommandType.Get.ToString()] = "Get a scope, rule, issuer, or token policy by ID";
            parameterHelpInfo[CommandType.GetAll.ToString()] = "Get all scopes, rules, issuers, or token policies";
            parameterHelpInfo[CommandType.Update.ToString()] = "Update properties on scopes, issuers, and token policies";

            // Resources
            parameterHelpInfo[ResourceType.Scope.ToString()] = "Scope that identifies the relying party to protect";
            parameterHelpInfo[ResourceType.TokenPolicy.ToString()] = "Token Policy defines the security for the Scope";
            parameterHelpInfo[ResourceType.Issuer.ToString()] = "Issuers that can request tokens from ACS STS";
            parameterHelpInfo[ResourceType.Rule.ToString()] = "Rules to parse incoming claims to outgoing claims";
            
            // Options - Management - General
            parameterHelpInfo[Constants.OptionGeneralId] = "The ID of object that was returned when object was created";
            parameterHelpInfo[Constants.OptionGeneralName] = "Friendly name of the resource";
            parameterHelpInfo[Constants.OptionAutoGenerate] = "Autogenerates a signing key";
            parameterHelpInfo[Constants.OptionSimpleOut] = "Displays only the ID, not the full message, when creating";
            parameterHelpInfo[Constants.OptionGeneralKey] = "The current key";

            // Options - Management - Scope
            parameterHelpInfo[Constants.OptionScopeAppliesTo] = "The URI of the Relying Party you are protecting";
            parameterHelpInfo[Constants.OptionScopeTokenPolicyId] = "The Token Policy Id";

            // Options - Management - TokenPolicy
            parameterHelpInfo[Constants.OptionTokenPolicyDefaultTimeOut] = "Default time out in seconds";

            // Options - Management - Issuer
            parameterHelpInfo[Constants.OptionIssuerName] = "The Issuer Name as passed in the token (not the display name)";
            parameterHelpInfo[Constants.OptionIssuerAlgorithm] = "Symmetric256BitKey or X509 (default: Symmetric256BitKey)";
            parameterHelpInfo[Constants.OptionIssuerCert] = "File location of the X509 (.cer) file";
            parameterHelpInfo[Constants.OptionIssuerPreviousKey] = "Previous Issuer key";

            // Options - Management - Rule
            parameterHelpInfo[Constants.OptionRuleScopeId] = "Scope ID of designated scope for rule";
            parameterHelpInfo[Constants.OptionRuleInputClaimIssuerId] = "Input claim issuer ID (must be a valid Issuer)";
            parameterHelpInfo[Constants.OptionRuleInputClaimType] = "Input claim type";
            parameterHelpInfo[Constants.OptionRuleInputClaimValue] = "Input claim value";
            parameterHelpInfo[Constants.OptionRuleOutputClaimType] = "Output claim type";
            parameterHelpInfo[Constants.OptionRuleOutputClaimValue] = "Output claim value";
            parameterHelpInfo[Constants.OptionRuleIsPassthrough] = "Pass-through rule";

            // Options - General
            parameterHelpInfo[Constants.OptionHelp1] = "Prints this help info";
            parameterHelpInfo[Constants.OptionHelp2] = "Same as 'help'";
            parameterHelpInfo[Constants.OptionManagementKey] = "Key used to authenticate with Managment Service";
            parameterHelpInfo[Constants.OptionHost] = "Host of the management service";
            parameterHelpInfo[Constants.OptionServiceName] = "Service namespace";

            foreach (string argument in arguments)
            {
                ConsoleUtil.WriteMessage(FormatKeyValue(argument, parameterHelpInfo[argument]));
            }
        }

        private static void PrintOptionHelp(string usageString, string[] validOptions)
        {
            ConsoleUtil.WriteMessage(PrintFormat.SubHeader, usageString);
            PrintArgumentOptions(validOptions);
        }

        private static void PrintGeneralHelp()
        {
            ConsoleUtil.WriteMessage("ACM Tool is a general purpose tool for managing Azure AppFabric ACS entities");
            ConsoleUtil.WriteMessage("More info at http://msdn.microsoft.com/en-us/library/ee706706.aspx");
            ConsoleUtil.WriteMessage();

            ConsoleUtil.WriteMessage(PrintFormat.SubHeader, "Usage: {0} <Command> <Resource> [ -<option>:<option_value> ]", Environment.GetCommandLineArgs()[0]);
            ConsoleUtil.WriteMessage();

            ConsoleUtil.WriteMessage(PrintFormat.SubHeader, "Commands:");
            PrintArgumentOptions(new string[]
            {
                CommandType.Create.ToString(),
                CommandType.Update.ToString(),
                CommandType.Get.ToString(),
                CommandType.GetAll.ToString(),
                CommandType.Delete.ToString(),
            });

            ConsoleUtil.WriteMessage();

            ConsoleUtil.WriteMessage(PrintFormat.SubHeader, "Resources:");
            PrintArgumentOptions(new string[]
            {
                ResourceType.Scope.ToString(),
                ResourceType.Rule.ToString(),
                ResourceType.Issuer.ToString(),
                ResourceType.TokenPolicy.ToString(),
            });

            ConsoleUtil.WriteMessage();
            ConsoleUtil.WriteMessage(PrintFormat.SubHeader, "Command Specific Options:");
            ConsoleUtil.WriteMessage("The arguments are dependent on the Command and Resource. To see help specific to a command use 'acm.exe <command> <resource> /?'.");

            ConsoleUtil.WriteMessage();

            ConsoleUtil.WriteMessage(PrintFormat.SubHeader, "General Options:");
            ConsoleUtil.WriteMessage("The options are used to define parameters needed to connect to the service or to get help information about a particular command or resource");
            PrintArgumentOptions(new string[]
            { 
                Constants.OptionHelp1,
                Constants.OptionHelp2,
                Constants.OptionServiceName,
                Constants.OptionHost,
                Constants.OptionManagementKey
            });
        }

        private static void PrintHeader()
        {
            ConsoleUtil.WriteMessage(PrintFormat.Header, "ACM Tool - Microsoft Access Control Service Tool");
            ConsoleUtil.WriteMessage("Copyright (c) Microsoft Corporation. All Rights Reserved");
            ConsoleUtil.WriteMessage();
        }
    }
}
