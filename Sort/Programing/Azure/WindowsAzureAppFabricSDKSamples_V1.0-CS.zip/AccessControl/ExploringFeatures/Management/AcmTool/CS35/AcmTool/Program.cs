﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.Samples.AcmTool
{
    using System;
    using AcmTool.Commands;
    using AcmTool.Resources;

    internal class Acm
    {
        internal static int Main(string[] args)
        {
            int returnCode = 0;
            CommandLineArguments commandLineArgs = new CommandLineArguments();

            bool parseSuccess = true;
            try
            {
                commandLineArgs.Parse(args);
            }
            catch (ArgumentException argException)
            {
                PrintHelper.PrintException(argException);
                parseSuccess = false;
                returnCode = 1;
            }

            if (parseSuccess)
            {
                if (commandLineArgs.IsHelpRequest)
                {
                    PrintHelper.PrintHelp(commandLineArgs);
                }
                else
                {
                    try
                    {
                        ResponseMessage responseMessage;
                        commandLineArgs.Validate();
                        Command command = commandLineArgs.CreateCommand();
                        command.Parse();
                        command.Validate();
                        responseMessage = command.Execute();
                        PrintHelper.PrintResponseMessage(responseMessage);
                    }
                    catch (ArgumentException argException)
                    {
                        PrintHelper.PrintException(argException);
                        returnCode = 1;
                    }
                }
            }

            return returnCode;
        }
    }
}
