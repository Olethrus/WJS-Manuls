﻿//------------------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
// <owner current="true" primary="true">sskier</owner>
//------------------------------------------------------------------------------

using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Acm")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCulture("")]

[assembly: InternalsVisibleTo("AcmToolTests, PublicKey=00240000048000009400000006020000002400005253413100040000010001003BCE5DA0FF7E3BC57BDCA12BAD0A8B5E262C5ED7A5357016554687C0E4A319D2AAEC47A037F782C0EA2FDB83B501622C9104CD907170249F4CD877EE3C150A6EEC99FE6BDBA7E37282B26F95D9EA712FCCEE5B30B0216B6E3D25646C8CD85B11BED329B92B72B7D2EE4477B3AF19C12960D4A0AD67B2834381D4B7FEBB0661A9")]

