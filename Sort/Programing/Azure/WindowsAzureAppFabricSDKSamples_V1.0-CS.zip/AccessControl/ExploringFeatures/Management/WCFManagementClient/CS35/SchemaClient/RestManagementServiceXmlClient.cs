﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.SchemaClient
{
    using System.ServiceModel;
    using System.ServiceModel.Description;

    public interface IRestManagementServiceXmlChannel : IRestManagementServiceXml, IClientChannel
    {
    }

    public partial class RestManagementServiceXmlClient : ClientBase<IRestManagementServiceXml>, IRestManagementServiceXml
    {

        public RestManagementServiceXmlClient()
        {
            this.AddWebHttpBehavior();
        }

        public RestManagementServiceXmlClient(string endpointConfigurationName) :
            base(endpointConfigurationName)
        {
            this.AddWebHttpBehavior();
        }

        public RestManagementServiceXmlClient(string endpointConfigurationName, string remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
            this.AddWebHttpBehavior();
        }

        public RestManagementServiceXmlClient(string endpointConfigurationName, System.ServiceModel.EndpointAddress remoteAddress) :
            base(endpointConfigurationName, remoteAddress)
        {
            this.AddWebHttpBehavior();
        }

        public RestManagementServiceXmlClient(System.ServiceModel.Channels.Binding binding, System.ServiceModel.EndpointAddress remoteAddress) :
            base(binding, remoteAddress)
        {
            this.AddWebHttpBehavior();
        }

        private void AddWebHttpBehavior()
        {
            this.Endpoint.Behaviors.Add(new WebHttpBehavior());
        }

        public Issuer CreateIssuerXml(Issuer issuer)
        {
            return base.Channel.CreateIssuerXml(issuer);
        }

        public Rule CreateRuleXml(string ruleSetId, Rule rule)
        {
            return base.Channel.CreateRuleXml(ruleSetId, rule);
        }

        public Scope CreateScopeXml(Scope scope)
        {
            return base.Channel.CreateScopeXml(scope);
        }

        public TokenPolicy CreateTokenPolicyXml(TokenPolicy tokenPolicy)
        {
            return base.Channel.CreateTokenPolicyXml(tokenPolicy);
        }

        public void DeleteIssuerXml(string id)
        {
            base.Channel.DeleteIssuerXml(id);
        }

        public void DeleteRuleXml(string ruleSetId, string id)
        {
            base.Channel.DeleteRuleXml(ruleSetId, id);
        }

        public void DeleteScopeXml(string id)
        {
            base.Channel.DeleteScopeXml(id);
        }

        public void DeleteTokenPolicyXml(string id)
        {
            base.Channel.DeleteTokenPolicyXml(id);
        }

        public Issuers GetIssuersXml()
        {
            return base.Channel.GetIssuersXml();
        }

        public Rules GetRulesXml(string ruleSetId)
        {
            return base.Channel.GetRulesXml(ruleSetId);
        }

        public Scopes GetScopesXml()
        {
            return base.Channel.GetScopesXml();
        }

        public TokenPolicies GetTokenPoliciesXml()
        {
            return base.Channel.GetTokenPoliciesXml();
        }

        public TokenPolicies GetTokenPoliciesWithModeXml(string mode)
        {
            return base.Channel.GetTokenPoliciesWithModeXml(mode);
        }

        public Issuer GetIssuerXml(string id)
        {
            return base.Channel.GetIssuerXml(id);
        }

        public Rule GetRuleXml(string ruleSetId, string id)
        {
            return base.Channel.GetRuleXml(ruleSetId, id);
        }

        public Scope GetScopeXml(string id)
        {
            return base.Channel.GetScopeXml(id);
        }

        public TokenPolicy GetTokenPolicyXml(string id)
        {
            return base.Channel.GetTokenPolicyXml(id);
        }

        public TokenPolicy GetTokenPolicyWithModeXml(string id, string mode)
        {
            return base.Channel.GetTokenPolicyWithModeXml(id, mode);
        }

        public void UpdateIssuerXml(string id, Issuer issuer)
        {
            base.Channel.UpdateIssuerXml(id, issuer);
        }

        public void UpdateScopeXml(string id, Scope scope)
        {
            base.Channel.UpdateScopeXml(id, scope);
        }

        public void UpdateTokenPolicyXml(string id, TokenPolicy tokenPolicy)
        {
            base.Channel.UpdateTokenPolicyXml(id, tokenPolicy);
        }
    }
}