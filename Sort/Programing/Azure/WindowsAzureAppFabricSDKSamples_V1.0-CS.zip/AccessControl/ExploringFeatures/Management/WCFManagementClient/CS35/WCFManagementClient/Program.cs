﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.ManagmentClientSample
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Security.Cryptography;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using System.Text;
    using System.Web;
    using Microsoft.AccessControl.SDK.SchemaClient;

    class Program
    {
        static string serviceNamespace = "updateToServiceNamespace";
        static string managementKey = "updateToManagementKey";

        static string acsBaseAddress = "accesscontrol.windows.net";

        static string acsMgmtSvcAddress = string.Format("https://{0}.{1}/mgmt", serviceNamespace, acsBaseAddress);
        static string acsMgmtSvcStsAddress = string.Format("https://{0}-mgmt.{1}/WRAPv0.9/", serviceNamespace, acsBaseAddress);

        static string acsMgmtSvcAppliesToTemplate = acsMgmtSvcAddress + "/{0}";
        
        static void Main()
        {
            // create an issuer
            Issuer issuer = CreateNewIssuer();
            Console.WriteLine("created issuer id={0}", issuer.Id);

            // create a token policy
            TokenPolicy tokenPolicy = CreateNewTokenPolicy();
            Console.WriteLine("created token policy id={0}", tokenPolicy.Id);

            // create a new scope
            // requires the tokenpolicy id
            Scope scope = CreateNewScope(tokenPolicy);
            Console.WriteLine("created scope id={0}", scope.Id);

            // create a new rule
            Rule rule = CreateNewRule(issuer, scope);
            Console.WriteLine("created rule id={0}", rule.Id);
            Console.WriteLine();

            // update the issuer key
            issuer.Security.CurrentKey = GetRandom256BitKey();
            UpdateIssuer(issuer);
            Console.WriteLine("updated the issuer key");

            // update the policy key
            tokenPolicy.SigningKey = GetRandom256BitKey();
            UpdateTokenPolicy(tokenPolicy);
            Console.WriteLine("updated the token policy key");
            Console.WriteLine();

            // get all the tokenpolicy ids
            TokenPolicies policies = GetTokenPolicyIds();
            Console.WriteLine("retrieved token policy ids:");
            policies.ForEach(policy => Console.WriteLine("\t{0}", policy.Id));
            Console.WriteLine();

            // delete the rule
            DeleteRule(scope, rule);
            Console.WriteLine("deleted rule id={0}", rule.Id);

            // delete the issuer
            DeleteIssuer(issuer.Id);
            Console.WriteLine("deleted issuer id={0}", issuer.Id);

            // delete the scope
            DeleteScope(scope);
            Console.WriteLine("deleted scope id={0}", scope.Id);

            // delete the token policy
            DeleteTokenPolicy(tokenPolicy);
            Console.WriteLine("deleted the token policy id={0}", tokenPolicy.Id);

            Console.WriteLine("");
            Console.WriteLine("Press [Enter] to end ...");
            Console.ReadLine();  
        }

        #region Create Operations

        private static Scope CreateNewScope(TokenPolicy tokenPolicy)
        {
            // get a token to allow scope operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "scopes");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            Scope scope = new Scope()
            {
                AppliesTo = "http://foobar.com",
                TokenPolicyId = tokenPolicy.Id
            };

            Scope newScope = null;

            // set the authorization header and create the scope
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                newScope = client.CreateScopeXml(scope);
            }

            client.Close();

            return newScope;
        }

        private static Issuer CreateNewIssuer()
        {
            // get a token to allow issuer operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "issuers");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // create a new key for the issuer
            string key = GetRandom256BitKey();

            // create an Issuer locally
            Issuer issuer = new Issuer()
            {
                DisplayName = "myIssuer",
                IssuerName = "myIssuer",
                Security = new SecurityProperty()
                {
                    Algorithm = "Symmetric256BitKey",
                    CurrentKey = key,
                    PreviousKey = key
                }
            };

            Issuer createdIssuer = null;

            // set the authorization header and create the issuer
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                createdIssuer = client.CreateIssuerXml(issuer);
            }

            client.Close();

            return createdIssuer;
        }

        private static Rule CreateNewRule(Issuer newIssuer, Scope scope)
        {
            // get a token to allow rule operations
            string path = string.Format("rulesets/{0}/rules", scope.Id);
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, path);
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // create a rule
            Rule rule = new Rule()
            {
                DisplayName = "myRule",
                InputClaim = new InputClaim()
                {
                    IssuerId = newIssuer.Id,
                    Type = "Issuer",
                    Value = newIssuer.IssuerName
                },
                OutputClaim = new OutputClaim()
                {
                    Type = "action",
                    Value = "calculate"
                },
                Type = "Simple"
            };

            Rule newRule = null;

            // set the authorization header and create the rule
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                newRule = client.CreateRuleXml(scope.Id, rule);
            }

            client.Close();

            return newRule;
        }

        private static TokenPolicy CreateNewTokenPolicy()
        {
            // get a token to allow tokenpolicy operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "tokenpolicies");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // create the token policy locally
            TokenPolicy policy = new TokenPolicy()
            {
                DisplayName = "myTokenPolicy",
                SigningKey = GetRandom256BitKey(),
                DefaultTokenLifetimeInSeconds = "3600"
            };

            TokenPolicy newPolicy = null;

            // set the authorization header and create the token policy
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                newPolicy = client.CreateTokenPolicyXml(policy);
            }

            client.Close();

            return newPolicy;
        }

#endregion

        #region ID Get Operation

        private static TokenPolicies GetTokenPolicyIds()
        {
            // get a token to allow tokenpolicy operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "tokenpolicies");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            TokenPolicies policies = null;

            // set the authorization header and get the tokenpolicy ids
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                policies = client.GetTokenPoliciesWithModeXml("NameIdOnly");
            }

            return policies;
        }

        #endregion

        #region Update Operations

        private static void UpdateTokenPolicy(TokenPolicy tokenPolicy)
        {
            // get a token to allow tokenpolicy operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "tokenpolicies");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // set the authorization header and update the token policy
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                client.UpdateTokenPolicyXml(tokenPolicy.Id, tokenPolicy);
            }

            client.Close();
        }

        private static void UpdateIssuer(Issuer issuer)
        {
            // get a token to allow issuer operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "issuers");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // set the authorization header and update the issuer
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                client.UpdateIssuerXml(issuer.Id, issuer);
            }

            client.Close();
        }

        #endregion

        #region Delete Operations

        private static void DeleteRule(Scope scope, Rule rule)
        {
            // get a token to allow rule operations
            string path = string.Format("rulesets/{0}/rules", scope.Id);
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, path);
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // set the authorization header and delete the rule
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                client.DeleteRuleXml(scope.Id, rule.Id);
            }

            client.Close();
        }

        private static void DeleteScope(Scope scope)
        {
            // get a token to allow scope operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "scopes");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // set the authorization header and delete the scope
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                client.DeleteScopeXml(scope.Id);
            }

            client.Close();
        }

        private static void DeleteTokenPolicy(TokenPolicy tokenPolicy)
        {
            // get a token to allow tokenpolicy operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "tokenpolicies");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // set the authorization header and delete the token policy
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                client.DeleteTokenPolicyXml(tokenPolicy.Id);
            }

            client.Close();
        }

        private static void DeleteIssuer(string issuerId)
        {
            // get a token to allow issuer operations
            string appliesTo = string.Format(acsMgmtSvcAppliesToTemplate, "issuers");
            string issuerToken = GetMgmtToken(appliesTo);

            // create an EndpointAddress that points to the mgmt service
            EndpointAddress address = new EndpointAddress(acsMgmtSvcAddress);

            // create a WCF client proxy
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            RestManagementServiceXmlClient client = new RestManagementServiceXmlClient(binding, address);

            // set the authorization header and delete the issuer
            using (new OperationContextScope(client.InnerChannel))
            {
                WebOperationContext.Current.OutgoingRequest.Headers[HttpRequestHeader.Authorization] = string.Format("WRAP access_token=\"{0}\"", issuerToken);
                client.DeleteIssuerXml(issuerId);
            }

            client.Close();
        }

        #endregion

        #region Helper Methods

        private static string GetMgmtToken(string appliesTo)
        {
            // use the URI for the management STS
            Uri mgmtStsaddress = new Uri(acsMgmtSvcStsAddress);

            WebHttpBinding acsBinding = new WebHttpBinding(WebHttpSecurityMode.Transport);
            WebChannelFactory<ITokenService> acsChannelFactory = new WebChannelFactory<ITokenService>(acsBinding, mgmtStsaddress);
            ITokenService acsTokenServiceProxy = acsChannelFactory.CreateChannel();

            string tokenRequestBody = string.Format(
                "wrap_name={0}&wrap_password={1}&wrap_scope={2}",
                HttpUtility.UrlEncode("owner"),
                HttpUtility.UrlEncode(managementKey),
                HttpUtility.UrlEncode(appliesTo));

            byte[] tokenRequestBodyInBytes = Encoding.UTF8.GetBytes(tokenRequestBody);

            string response;

            string token = null;

            using (new OperationContextScope(acsTokenServiceProxy as IContextChannel))
            {
                using (MemoryStream tokenRequest = new MemoryStream(tokenRequestBodyInBytes))
                {
                    WebOperationContext.Current.OutgoingRequest.ContentType = "application/x-www-form-urlencoded";
                    using (StreamReader tokenResponse = new StreamReader(acsTokenServiceProxy.RequestAccessToken(tokenRequest)))
                    {
                        response = tokenResponse.ReadLine();
                    }
                }
            }

            ((IClientChannel)acsTokenServiceProxy).Close();

            token = response.Split('&')
                            .Single(value => value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase))
                            .Split('=')[1];

            return HttpUtility.UrlDecode(token);
        }

        private static string GetRandom256BitKey()
        {
            byte[] key = new byte[32];
            RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
            rng.GetBytes(key);
            return Convert.ToBase64String(key);
        }

        #endregion
    }
}

