﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.WCF
{
    using System;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Linq;
    using System.Net;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using System.Text;
    using System.Web;

    class Client
    {
        static string serviceNamespace;
        static string issuerKey;
        static string acsBaseAddress = "accesscontrol.windows.net";

        static void Main(string[] args)
        {
            Console.WriteLine("Enter your service namespace, then press <ENTER>");
            serviceNamespace = Console.ReadLine();

            Console.WriteLine("\nEnter your issuer key, then press <ENTER>");
            issuerKey = Console.ReadLine();

            Console.WriteLine("\nEnter a number to send to the Fibonacci Calculator, then press <ENTER>");
            int valueToCalculate = Convert.ToInt32(Console.ReadLine());

            string token = GetTokenFromACS();

            string response = SendMessageToService(token, valueToCalculate);

            Console.WriteLine("the Fibonacci service returned: {0}", response);
            Console.WriteLine("Press <ENTER> to exit");
            Console.ReadLine();
        }

        private static string SendMessageToService(string token, int valueToCalculate)
        {
            int fibNumber;

            // create the binding and address to communicate with the service
            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.None);
            Uri address = new Uri(@"http://localhost/Fibonacci");

            WebChannelFactory<IFibonacci> channelFactory = new WebChannelFactory<IFibonacci>(binding, address);

            IFibonacci proxy = channelFactory.CreateChannel();

            // add the token to the proxy
            using (new OperationContextScope(proxy as IContextChannel))
            {
                string authHeaderValue = string.Format("WRAP access_token=\"{0}\"", HttpUtility.UrlDecode(token));

                WebOperationContext.Current.OutgoingRequest.Headers.Add("authorization", authHeaderValue);

                // call the service and get a response
                fibNumber = proxy.Calculate(valueToCalculate);
            }

            ((IClientChannel)proxy).Close();

            channelFactory.Close();

            return fibNumber.ToString();
        }

        private static string GetTokenFromACS()
        {
            // request a token from ACS
            WebClient client = new WebClient();
            client.BaseAddress = string.Format("https://{0}.{1}", serviceNamespace, acsBaseAddress);

            NameValueCollection values = new NameValueCollection();
            values.Add("wrap_name", "wcfauthmanager");
            values.Add("wrap_password", issuerKey);
            values.Add("wrap_scope", "http://localhost/Fibonacci/");

            byte[] responseBytes = client.UploadValues("WRAPv0.9/", "POST", values);

            string response = Encoding.UTF8.GetString(responseBytes);

            Console.WriteLine("\nreceived token from ACS: {0}\n", response);

            return response
                .Split('&')
                .Single(value => value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase))
                .Split('=')[1];
        }
    }
}

