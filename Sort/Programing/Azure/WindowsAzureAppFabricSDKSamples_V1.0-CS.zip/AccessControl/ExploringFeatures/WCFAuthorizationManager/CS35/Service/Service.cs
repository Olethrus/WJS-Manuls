﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.WCF
{
    using System;
    using System.Collections.Generic;
    using System.ServiceModel;
    using System.ServiceModel.Web;
    using System.Text;

    class Service
    {
        static void Main(string[] args)
        {
            string serviceNamespace = "updateToServiceNamespace";
            string trustedTokenPolicyKey = "updateToTokenPolicyKey";

            string acsHostName = "accesscontrol.windows.net";

            string trustedAudience = "http://localhost/Fibonacci";
            string requiredClaimType = "action";
            string requiredClaimValue = "calculate";

            WebHttpBinding binding = new WebHttpBinding(WebHttpSecurityMode.None);
            
            Uri address = new Uri("http://localhost/Fibonacci");

            WebServiceHost host = new WebServiceHost(typeof(Fibonacci));
            host.AddServiceEndpoint(typeof(IFibonacci), binding, address);

            host.Authorization.ServiceAuthorizationManager = new ACSAuthorizationManager(
                acsHostName,
                serviceNamespace, 
                trustedAudience, 
                Convert.FromBase64String(trustedTokenPolicyKey),
                requiredClaimType,
                requiredClaimValue);

            host.Open();

            Console.WriteLine("The Fibonacci Service is listening");
            Console.WriteLine("Press <ENTER> to exit");
            Console.ReadLine();
        }
    }
}
