﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.GettingStarted.Client
{
    using System;
    using System.Collections.Specialized;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Text;
    using System.Web;

    class Program
    {
        static string serviceNamespace;
        static string issuerKey;
        static string acsHostName = "accesscontrol.windows.net";

        static void Main(string[] args)
        {
            Console.WriteLine("Enter your Service Namespace, then press <ENTER>");
            serviceNamespace = Console.ReadLine();

            Console.WriteLine("\nEnter your client issuer key, then press <ENTER>");
            issuerKey = Console.ReadLine();
            
            Console.WriteLine("\nEnter a string to reverse, then press <ENTER>");
            string valueToReverse = Console.ReadLine();

            string token = GetTokenFromACS();

            string serviceResponse = SendMessageToService(token, valueToReverse);

            Console.WriteLine("Service responded with: {0}\n", serviceResponse);

            Console.WriteLine("Press <ENTER> to exit");

            Console.ReadLine();
        }

        private static string SendMessageToService(string token, string valueToReverse)
        {
            WebClient client = new WebClient();
            client.BaseAddress = "http://localhost/ACSGettingStarted/Default.aspx";

            string headerValue = string.Format("WRAP access_token=\"{0}\"", HttpUtility.UrlDecode(token)); 
            
            client.Headers.Add("Authorization", headerValue);

            NameValueCollection values = new NameValueCollection();
            values = new NameValueCollection();
            values.Add("string_to_reverse", valueToReverse);

            byte[] serviceResponseBytes = client.UploadValues(string.Empty, values);
            
            return Encoding.UTF8.GetString(serviceResponseBytes);
        }

        private static string GetTokenFromACS()
        {
            // request a token from ACS
            WebClient client = new WebClient();
            client.BaseAddress = string.Format("https://{0}.{1}", serviceNamespace, acsHostName);

            NameValueCollection values = new NameValueCollection();
            values.Add("wrap_name", "gettingstarted");
            values.Add("wrap_password", issuerKey);
            values.Add("wrap_scope", "http://localhost/ACSGettingStarted");

            byte[] responseBytes = client.UploadValues("WRAPv0.9/", "POST", values);

            string response = Encoding.UTF8.GetString(responseBytes);

            Console.WriteLine("\nreceived token from ACS: {0}\n", response);

            return response
                .Split('&')
                .Single(value => value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase))
                .Split('=')[1];
        }
    }
}

