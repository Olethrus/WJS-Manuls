﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.AccessControl.SDK.GettingStarted.Service
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    public partial class _Default : System.Web.UI.Page
    {
        string serviceNamespace = "updateToServiceNamespace";
        string trustedTokenPolicyKey = "updateToTokenPolicyKey";

        string acsHostName = "accesscontrol.windows.net";

        string trustedAudience = "http://localhost/ACSGettingStarted";
        string requiredClaimType = "action";
        string requiredClaimValue = "reverse";

        protected void Page_Load(object sender, EventArgs e)
        {
            // get the authorization header
            string headerValue = Request.Headers.Get("Authorization");

            // check that a value is there
            if (string.IsNullOrEmpty(headerValue))
            {
                this.ReturnUnauthorized();
                return;
            }

            // check that it starts with 'WRAP'
            if (!headerValue.StartsWith("WRAP "))
            {
                this.ReturnUnauthorized();
                return;
            }

            string[] nameValuePair = headerValue.Substring("WRAP ".Length).Split(new char[] { '=' }, 2);

            if (nameValuePair.Length != 2 ||
                nameValuePair[0] != "access_token" ||
                !nameValuePair[1].StartsWith("\"") ||
                !nameValuePair[1].EndsWith("\""))
            {
                this.ReturnUnauthorized();
                return;
            }

            // trim off the leading and trailing double-quotes
            string token = nameValuePair[1].Substring(1, nameValuePair[1].Length - 2);

            // create a token validator
            TokenValidator validator = new TokenValidator(
                this.acsHostName,
                this.serviceNamespace,
                this.trustedAudience,
                this.trustedTokenPolicyKey);

            // validate the token
            if (!validator.Validate(token))
            {
                this.ReturnUnauthorized();
                return;
            }

            // check for an action claim
            Dictionary<string, string> claims = validator.GetNameValues(token);

            string actionClaimValue;
            if (!claims.TryGetValue(this.requiredClaimType, out actionClaimValue))
            {
                this.ReturnUnauthorized();
                return;
            }

            // check for the correct action claim value
            if (!actionClaimValue.Equals(this.requiredClaimValue))
            {
                this.ReturnUnauthorized();
                return;
            }

            // reverse the string and return to caller
            string stringToReverse = Request.Form["string_to_reverse"];
            char[] chars = stringToReverse.ToCharArray();
            Array.Reverse(chars);

            Response.Write(new string(chars));
            Response.End();
        }

        private void ReturnUnauthorized()
        {
            Response.StatusCode = 401;
            Response.End();
        }
    }
}