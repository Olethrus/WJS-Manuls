﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.ServiceBus.Samples
{
    using System;
    using System.ServiceModel.Channels;

    using Microsoft.ServiceBus;

    internal class Consumer
    {
        private MessageBufferClient client;
        private MessageBufferPolicy policy;
        private TransportClientEndpointBehavior credential;
        private Uri uri;

        public Consumer()
        {
            Console.Write("Your Service Namespace: ");
            string serviceNamespace = Console.ReadLine();
            Console.Write("Your Issuer Name: ");
            string issuerName = Console.ReadLine();
            Console.Write("Your Issuer Secret: ");
            string issuerSecret = Console.ReadLine();

            // create the policy for the message buffer
            this.policy = new MessageBufferPolicy();
            this.policy.Authorization = AuthorizationPolicy.Required;
            this.policy.MaxMessageCount = 10;
            this.policy.ExpiresAfter = TimeSpan.FromMinutes(5); // messages in the message buffer expire after 5 mins
            this.policy.TransportProtection = TransportProtectionPolicy.AllPaths;
            
            // create the credentials object for the endpoint
            this.credential = new TransportClientEndpointBehavior();
            this.credential.CredentialType = TransportClientCredentialType.SharedSecret;
            this.credential.Credentials.SharedSecret.IssuerName = issuerName;
            this.credential.Credentials.SharedSecret.IssuerSecret = issuerSecret;

            // create the URI for the message buffer
            this.uri = ServiceBusEnvironment.CreateServiceUri("https", serviceNamespace, "MessageBuffer");           
        }

        public void CreateMessageBuffer()
        {
            Console.Write("Press [Enter] to create the message buffer: ");
            Console.ReadLine();

            // create the client for the message buffer
            this.client = MessageBufferClient.CreateMessageBuffer(this.credential, this.uri, this.policy);
            Console.WriteLine("Message buffer created at '{0}'.", this.client.MessageBufferUri);
        }

        public void ProcessMessages()
        {
            Message retrievedMessage;

            // retrieve the first two message from the message buffer
            Console.Write("Press [Enter] to retrieve the first message in the message buffer: ");
            Console.ReadLine();

            retrievedMessage = this.client.Retrieve();
            Console.WriteLine("Retrieved message with body '{0}'.", retrievedMessage.GetBody<string>());
            retrievedMessage.Close();
        
            Console.Write("Press [Enter] to retrieve the next message from the message buffer: ");
            Console.ReadLine();
            retrievedMessage = this.client.Retrieve();
            Console.WriteLine("Retrieved message with body '{0}'.", retrievedMessage.GetBody<string>());
            retrievedMessage.Close();

            // lock and peek at the next message; then delete it
            Console.Write("Press [Enter] to lock, peek, and delete the next message from the message buffer: ");
            Console.ReadLine();
            Message lockedMessage = this.client.PeekLock();
            this.client.DeleteLockedMessage(lockedMessage);
            Console.WriteLine("Message with body '{0}' locked, peeked, and then deleted.", lockedMessage.GetBody<string>());
            lockedMessage.Close();
        }

        public void DeleteMessageBuffer()
        {
            Console.Write("Press [Enter] to delete the message buffer: ");
            Console.ReadLine();

            // delete the message buffer
            this.client.DeleteMessageBuffer();
            Console.WriteLine("Message buffer at {0} was deleted.", this.client.MessageBufferUri);

            Console.WriteLine("Press any key to continue . . .");
            Console.ReadKey();
        }
    }
}
