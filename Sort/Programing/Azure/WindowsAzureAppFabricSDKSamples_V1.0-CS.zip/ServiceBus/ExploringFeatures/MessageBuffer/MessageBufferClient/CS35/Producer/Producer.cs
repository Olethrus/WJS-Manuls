﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace Microsoft.ServiceBus.Samples
{
    using System;
    using System.ServiceModel.Channels;

    using Microsoft.ServiceBus;

    internal class Producer
    {
        private MessageBufferClient client;
        private TransportClientEndpointBehavior credential;
        private Uri uri;

        public Producer()
        {
            Console.Write("Your Service Namespace: ");
            string serviceNamespace = Console.ReadLine();
            Console.Write("Your Issuer Name: ");
            string issuerName = Console.ReadLine();
            Console.Write("Your Issuer Secret: ");
            string issuerSecret = Console.ReadLine();

            // create the credentials object for the endpoint
            this.credential = new TransportClientEndpointBehavior();
            this.credential.CredentialType = TransportClientCredentialType.SharedSecret;
            this.credential.Credentials.SharedSecret.IssuerName = issuerName;
            this.credential.Credentials.SharedSecret.IssuerSecret = issuerSecret;

            // create the URI for the message buffer
            this.uri = ServiceBusEnvironment.CreateServiceUri("https", serviceNamespace, "MessageBuffer");
        }

        public void ProduceMessages()
        {
            Console.Write("Press [Enter] to connect to the message buffer: ");
            Console.ReadLine();

            // create the client for the message buffer
            this.client = MessageBufferClient.GetMessageBuffer(this.credential, this.uri);
            Console.WriteLine("Connected to the message buffer at '{0}'.", this.client.MessageBufferUri);

            Console.Write("Press [Enter] to send messages to the message buffer: ");
            Console.ReadLine();

            // send three messages to the message buffer
            for (int i = 1; i <= 3; ++i)
            {
                Message message = Message.CreateMessage(MessageVersion.Default, string.Empty, string.Format("<<MESSAGE {0}>>", i));
                this.client.Send(message);
                Console.WriteLine("Sent message with body '<<MESSAGE {0}>>' to the message buffer.", i);
                message.Close();
            }

            Console.WriteLine("Press any key to continue . . .");
            Console.ReadKey();
        }
    }
}