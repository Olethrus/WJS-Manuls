﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Net
Imports System.ServiceModel
Imports System.ServiceModel.Web

Namespace Microsoft.AccessControl.SDK.ACSCalculator.AuthorizationManager

	Public Class ACSAuthorizationManager
		Inherits ServiceAuthorizationManager
		Private validator As TokenValidator
		Private requiredClaimType As String

		Public Sub New(ByVal acsHostName As String, ByVal trustedSolution As String, ByVal trustedAudienceValue As String, ByVal trustedSigningKey() As Byte, ByVal requiredClaimType As String)
			Me.validator = New TokenValidator(acsHostName, trustedSolution, trustedAudienceValue, trustedSigningKey)
			Me.requiredClaimType = requiredClaimType
		End Sub

		Protected Overrides Function CheckAccessCore(ByVal operationContext As OperationContext) As Boolean
			' get the authorization header
			Dim authorizationHeader As String = WebOperationContext.Current.IncomingRequest.Headers(HttpRequestHeader.Authorization)

			If String.IsNullOrEmpty(authorizationHeader) Then
				WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Unauthorized
				Return False
			End If

			' validate the token
			If Not Me.validator.Validate(authorizationHeader) Then
				WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Unauthorized
				Return False
			End If

			' check for an action claim and get the value
			Dim claims As Dictionary(Of String, String) = Me.validator.GetNameValues(authorizationHeader)

			' use the operation name to determine the requried action value
			Dim requiredActionClaimValue As String = WebOperationContext.Current.IncomingRequest.UriTemplateMatch.RelativePathSegments.First()

            Dim actionClaimValue As String = String.Empty
			If Not claims.TryGetValue(Me.requiredClaimType, actionClaimValue) Then
				WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Unauthorized
				Return False
			End If

			' check for "," delimited values
			Dim actionClaimValues() As String = actionClaimValue.Split(","c)

			' check for the correct action claim value
			If Not actionClaimValues.Contains(requiredActionClaimValue) Then
				WebOperationContext.Current.OutgoingResponse.StatusCode = HttpStatusCode.Unauthorized
				Return False
			End If

			Return True
		End Function
	End Class
End Namespace
