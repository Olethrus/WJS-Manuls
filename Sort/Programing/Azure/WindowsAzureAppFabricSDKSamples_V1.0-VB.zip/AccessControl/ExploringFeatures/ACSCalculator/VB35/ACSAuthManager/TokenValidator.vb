﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Security.Cryptography
Imports System.Text
Imports System.Web
Imports System.Globalization

Namespace Microsoft.AccessControl.SDK.ACSCalculator.AuthorizationManager

	Public Class TokenValidator
		Private Const issuerLabel As String = "Issuer"
		Private Const expiresLabel As String = "ExpiresOn"
		Private Const audienceLabel As String = "Audience"
		Private Const hmacSHA256Label As String = "HMACSHA256"

		Private acsHostName As String

		Private trustedSigningKey() As Byte
        Private trustedTokenIssuer As String
        Private trustedAudienceValue As Uri

		Public Sub New(ByVal acsHostName As String, ByVal trustedSolution As String, ByVal trustedAudienceValue As String, ByVal trustedSigningKey() As Byte)
			Me.acsHostName = acsHostName
			Me.trustedSigningKey = trustedSigningKey

            Me.trustedTokenIssuer = String.Format(CultureInfo.InvariantCulture, "https://{0}.accesscontrol.windows.net/", trustedSolution.ToLowerInvariant())

            Me.trustedAudienceValue = New Uri(trustedAudienceValue)
		End Sub

		Public Function Validate(ByVal token As String) As Boolean
			If Not Me.IsHMACValid(token, Me.trustedSigningKey) Then
				Return False
			End If

			If Me.IsExpired(token) Then
				Return False
			End If

			If Not Me.IsIssuerTrusted(token) Then
				Return False
			End If

			If Not Me.IsAudienceTrusted(token) Then
				Return False
			End If

			Return True
		End Function

		Public Function GetNameValues(ByVal token As String) As Dictionary(Of String, String)
			If String.IsNullOrEmpty(token) Then
				Throw New ArgumentException()
			End If

			Return token.Split("&"c).Aggregate(New Dictionary(Of String, String)(), Function(dict, rawNameValue) AnonymousMethod1(dict, rawNameValue))
		End Function
		
		'INSTANT VB TODO TASK: The return type of this anonymous method could not be determined by Instant VB:
		Private Function AnonymousMethod1(ByVal dict As Object, ByVal rawNameValue As Object) As Object
			If rawNameValue Is String.Empty Then
				Return dict
			End If
			Dim nameValue() As String = rawNameValue.Split("="c)
			If nameValue.Length <> 2 Then
				Throw New ArgumentException("Invalid formEncodedstring - contains a name/value pair missing an = character", "token")
			End If
			If dict.ContainsKey(nameValue(0)) = True Then
				Throw New ArgumentException("Repeated name/value pair in form", "token")
			End If
			dict.Add(HttpUtility.UrlDecode(nameValue(0)), HttpUtility.UrlDecode(nameValue(1)))
			Return dict
		End Function

		Private Shared Function GenerateTimeStamp() As ULong
			' Default implementation of epoch time
			Dim ts As TimeSpan = Date.UtcNow - New Date(1970, 1, 1, 0, 0, 0, 0)
			Return Convert.ToUInt64(ts.TotalSeconds)
		End Function

		Private Function IsAudienceTrusted(ByVal token As String) As Boolean
			Dim tokenValues As Dictionary(Of String, String) = Me.GetNameValues(token)

            Dim audienceValue As String = String.Empty

			tokenValues.TryGetValue(audienceLabel, audienceValue)

            If Not String.IsNullOrEmpty(audienceValue) Then
                Dim audienceValueUri As Uri = New Uri(audienceValue)
                If audienceValueUri.Equals(Me.trustedAudienceValue) Then
                    Return True
                End If
            End If

			Return False
		End Function

		Private Function IsIssuerTrusted(ByVal token As String) As Boolean
			Dim tokenValues As Dictionary(Of String, String) = Me.GetNameValues(token)

            Dim issuerName As String = String.Empty

			tokenValues.TryGetValue(issuerLabel, issuerName)

            If Not String.IsNullOrEmpty(issuerName) Then
                If issuerName.Equals(Me.trustedTokenIssuer) Then
                    Return True
                End If
            End If

			Return False
		End Function

		Private Function IsHMACValid(ByVal swt As String, ByVal sha256HMACKey() As Byte) As Boolean
			Dim swtWithSignature() As String = swt.Split(New String() { "&" & hmacSHA256Label & "=" }, StringSplitOptions.None)

			If (swtWithSignature Is Nothing) OrElse (swtWithSignature.Length <> 2) Then
				Return False
			End If

			Dim hmac As New HMACSHA256(sha256HMACKey)

			Dim locallyGeneratedSignatureInBytes() As Byte = hmac.ComputeHash(Encoding.ASCII.GetBytes(swtWithSignature(0)))

			Dim locallyGeneratedSignature As String = HttpUtility.UrlEncode(Convert.ToBase64String(locallyGeneratedSignatureInBytes))

			Return locallyGeneratedSignature = swtWithSignature(1)
		End Function

		Private Function IsExpired(ByVal swt As String) As Boolean
			Try
				Dim nameValues As Dictionary(Of String, String) = Me.GetNameValues(swt)
				Dim expiresOnValue As String = nameValues(expiresLabel)
				Dim expiresOn As ULong = Convert.ToUInt64(expiresOnValue)
				Dim currentTime As ULong = Convert.ToUInt64(GenerateTimeStamp())

				If currentTime > expiresOn Then
					Return True
				End If

				Return False
			Catch e1 As KeyNotFoundException
				Throw New ArgumentException()
			End Try
		End Function
	End Class
End Namespace

