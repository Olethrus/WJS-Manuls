﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ServiceModel
Imports System.ServiceModel.Web
Imports System.Text

Namespace Microsoft.AccessControl.SDK.ACSCalculator.Client

	<ServiceContract> _
	Public Interface ICalculator
		<OperationContract, WebGet(UriTemplate := "add?a={a}&b={b}")> _
		Function Add(ByVal a As Integer, ByVal b As Integer) As Integer

		<OperationContract, WebGet(UriTemplate := "subtract?a={a}&b={b}")> _
		Function Subtract(ByVal a As Integer, ByVal b As Integer) As Integer

		<OperationContract, WebGet(UriTemplate := "multiply?a={a}&b={b}")> _
		Function Multiply(ByVal a As Integer, ByVal b As Integer) As Integer

		<OperationContract, WebGet(UriTemplate := "divide?a={a}&b={b}")> _
		Function Divide(ByVal a As Integer, ByVal b As Integer) As Integer
	End Interface
End Namespace
