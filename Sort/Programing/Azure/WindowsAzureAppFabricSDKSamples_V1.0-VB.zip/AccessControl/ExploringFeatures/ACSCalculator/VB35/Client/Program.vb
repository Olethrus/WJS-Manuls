﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Collections.Specialized
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.ServiceModel
Imports System.ServiceModel.Description
Imports System.ServiceModel.Security
Imports System.ServiceModel.Web
Imports System.Text
Imports System.Web

Namespace Microsoft.AccessControl.SDK.ACSCalculator.Client

	Friend Class Program
        Private Shared serviceNamespace As String
        Private Shared issuerKey As String

        Private Const acsHostName As String = "accesscontrol.windows.net"
        Private Const issuerName As String = "acscalculator"

        Shared Sub Main()
            Console.WriteLine("Enter your solution name, then press <ENTER>")
            serviceNamespace = Console.ReadLine()

            Console.WriteLine()
            Console.WriteLine("Enter your issuer key, then press <ENTER>")
            issuerKey = Console.ReadLine()

            ' create a token with a group=user claim
            Dim userToken As String = GetUserToken()

            ' send the token to ACS
            Dim acsIssuedToken As String = SendSWTToACS(userToken, "http://localhost/acscalculator")

            ' perform the calculator operations
            Console.WriteLine()
            Console.WriteLine("Calling calculator with 'group=user' claim")
            DoCalculatorOperations(acsIssuedToken)

            ' create a token with a group=user,executive claim
            Dim executiveToken As String = GetUserExecutiveToken()

            ' send the token to ACS
            acsIssuedToken = SendSWTToACS(executiveToken, "http://localhost/acscalculator")

            ' perform the calculator operations
            Console.WriteLine()
            Console.WriteLine("Calling calculator with 'group=user,executive' claim")
            DoCalculatorOperations(acsIssuedToken)

            Console.WriteLine()
            Console.WriteLine("Done. Press <ENTER> to end")
            Console.ReadLine()
        End Sub

        Private Shared Sub DoCalculatorOperations(ByVal userToken As String)
            Dim binding As New WebHttpBinding()
            Dim address As New Uri("http://localhost/acscalculator")

            Dim factory As New WebChannelFactory(Of ICalculator)(binding, address)
            factory.Endpoint.Behaviors.Add(New WebHttpBehavior())

            Dim proxy As ICalculator = factory.CreateChannel()

            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(CType(proxy, IClientChannel))
                WebOperationContext.Current.OutgoingRequest.Headers.Add(HttpRequestHeader.Authorization, userToken)

                Try
                    Console.Write(vbTab & "Calling add: ")
                    Dim result As Integer = proxy.Add(2, 2)
                    Console.WriteLine("2 + 2 = {0}", result)

                    Console.Write(vbTab & "Calling subtract: ")
                    result = proxy.Subtract(2, 2)
                    Console.WriteLine("2 - 2 = {0}", result)

                    Console.Write(vbTab & "Calling divide: ")
                    result = proxy.Divide(2, 2)
                    Console.WriteLine("2 / 2 = {0}", result)

                    Console.Write(vbTab & "Calling multiply: ")
                    result = proxy.Multiply(2, 2)
                    Console.WriteLine("2 * 2 = {0}", result)
                Catch ex As MessageSecurityException
                    If ex.InnerException IsNot Nothing AndAlso ex.InnerException.GetType() Is GetType(WebException) Then
                        Console.WriteLine(ex.InnerException.Message)
                    Else
                        Throw

                    End If
                End Try
            End Using

            CType(proxy, IClientChannel).Close()
        End Sub

        Private Shared Function GetUserExecutiveToken() As String
            Dim claims As New Dictionary(Of String, String)()
            claims.Add("group", "user,executive")

            Dim factory As New TokenFactory(acsHostName, serviceNamespace, issuerName, issuerKey)
            Return factory.CreateToken(claims)
        End Function

        Private Shared Function GetUserToken() As String
            Dim claims As New Dictionary(Of String, String)()
            claims.Add("group", "user")

            Dim factory As New TokenFactory(acsHostName, serviceNamespace, issuerName, issuerKey)
            Return factory.CreateToken(claims)
        End Function

        Private Shared Function SendSWTToACS(ByVal swt As String, ByVal appliesTo As String) As String
            ' request a token from ACS
            Dim client As New WebClient()
            client.BaseAddress = String.Format("https://{0}.{1}/", serviceNamespace, acsHostName)

            Dim values As New NameValueCollection()
            values.Add("wrap_assertion_format", "SWT")
            values.Add("wrap_assertion", swt)
            values.Add("wrap_scope", appliesTo)

            Dim response As String = Nothing

            Dim responseBytes() As Byte = client.UploadValues("WRAPv0.9/", values)
            response = Encoding.UTF8.GetString(responseBytes)

            Return HttpUtility.UrlDecode(response.Split("&"c).Single(Function(value) value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase)).Split("="c)(1))
        End Function
	End Class
End Namespace

