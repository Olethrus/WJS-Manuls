﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Security.Cryptography
Imports System.Text
Imports System.Web

Namespace Microsoft.AccessControl.SDK.ACSCalculator.Client

	Public Class TokenFactory
		Private acsHost As String
		Private solutionName As String
		Private issuerName As String
		Private signingKey As String

		Public Sub New(ByVal acsHost As String, ByVal solutionName As String, ByVal issuerName As String, ByVal signingKey As String)
			Me.acsHost = acsHost
			Me.solutionName = solutionName
			Me.issuerName = issuerName
			Me.signingKey = signingKey
		End Sub

		Public Function CreateToken(ByVal claims As Dictionary(Of String, String)) As String
			' check for dup claimtypes
			Dim claimList As Dictionary(Of String, String) = Me.RemoveDuplicateClaimTypes(claims)

			' build the claims string
			Dim builder As New StringBuilder()
			For Each entry As KeyValuePair(Of String, String) In claimList
				builder.Append(entry.Key)
				builder.Append("="c)
				builder.Append(entry.Value)
				builder.Append("&"c)
			Next entry

			' add the issuer name
			builder.Append("Issuer=")
			builder.Append(Me.issuerName)
			builder.Append("&"c)

			' add the Audience
			builder.Append("Audience=")
            builder.Append(String.Format("https://{0}.{1}/WRAPv0.9/&", Me.solutionName, Me.acsHost))

			' add the expires on date
			builder.Append("ExpiresOn=")
			builder.Append(GetExpiresOn(20))

			Dim signature As String = Me.GenerateSignature(builder.ToString(), Me.signingKey)
			builder.Append("&HMACSHA256=")
			builder.Append(signature)

			Return builder.ToString()
		End Function

		Private Function GenerateSignature(ByVal unsignedToken As String, ByVal signingKey As String) As String
			Dim hmac As New HMACSHA256(Convert.FromBase64String(signingKey))

			Dim locallyGeneratedSignatureInBytes() As Byte = hmac.ComputeHash(Encoding.ASCII.GetBytes(unsignedToken))

			Dim locallyGeneratedSignature As String = HttpUtility.UrlEncode(Convert.ToBase64String(locallyGeneratedSignatureInBytes))

			Return locallyGeneratedSignature
		End Function

		Private Shared Function GetExpiresOn(ByVal minutesFromNow As Double) As ULong
			Dim expiresOnTimeSpan As TimeSpan = TimeSpan.FromMinutes(minutesFromNow)

			Dim expiresDate As Date = Date.UtcNow.Add(expiresOnTimeSpan)

			Dim ts As TimeSpan = expiresDate.Subtract(New Date(1970, 1, 1, 0, 0, 0, 0))

			Return Convert.ToUInt64(ts.TotalSeconds)
		End Function

		Private Function RemoveDuplicateClaimTypes(ByVal claims As Dictionary(Of String, String)) As Dictionary(Of String, String)
			Dim newClaims As New Dictionary(Of String, String)()

			For Each entry As KeyValuePair(Of String, String) In claims
                Dim value As String = String.Empty

				If newClaims.TryGetValue(entry.Key, value) Then
					newClaims(entry.Key) = value & "," & entry.Value
				Else
					newClaims.Add(entry.Key, entry.Value)
				End If
			Next entry

			Return newClaims
		End Function
	End Class
End Namespace

