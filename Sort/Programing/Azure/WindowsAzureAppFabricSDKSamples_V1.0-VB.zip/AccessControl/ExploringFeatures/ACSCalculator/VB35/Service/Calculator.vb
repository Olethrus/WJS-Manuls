﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System

Namespace Microsoft.AccessControl.SDK.ACSCalculator.Service

	Friend Class Calculator
		Implements ICalculator
		Public Function Add(ByVal a As Integer, ByVal b As Integer) As Integer Implements ICalculator.Add
			Return a + b
		End Function

		Public Function Subtract(ByVal a As Integer, ByVal b As Integer) As Integer Implements ICalculator.Subtract
			Return a - b
		End Function

		Public Function Multiply(ByVal a As Integer, ByVal b As Integer) As Integer Implements ICalculator.Multiply
			Return a * b
		End Function

		Public Function Divide(ByVal a As Integer, ByVal b As Integer) As Integer Implements ICalculator.Divide
			Return a \ b
		End Function
	End Class
End Namespace
