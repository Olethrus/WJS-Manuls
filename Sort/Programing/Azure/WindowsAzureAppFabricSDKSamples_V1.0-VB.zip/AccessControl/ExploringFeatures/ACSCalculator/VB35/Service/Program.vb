﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.ServiceModel
Imports System.ServiceModel.Web
Imports System.Text
Imports Microsoft.AccessControl.SDK.ACSCalculator.AuthorizationManager

Namespace Microsoft.AccessControl.SDK.ACSCalculator.Service

	Friend Class Program
        Private Const serviceNamespace As String = "updateToServiceNamespace"
        Private Const trustedTokenPolicyKey As String = "updateToTokenPolicyKey"

        Private Const acsHostName As String = "accesscontrol.windows.net"
        Private Const trustedAudience As String = "http://localhost/acscalculator"
        Private Const requiredClaimType As String = "action"

        Shared Sub Main()
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.None)

            Dim address As New Uri(trustedAudience)

            Dim host As New WebServiceHost(GetType(Calculator))
            host.AddServiceEndpoint(GetType(ICalculator), binding, address)

            host.Authorization.ServiceAuthorizationManager = New ACSAuthorizationManager(acsHostName, serviceNamespace, trustedAudience, Convert.FromBase64String(trustedTokenPolicyKey), requiredClaimType)

            host.Open()

            Console.WriteLine("The Calculator Service is listening")
            Console.WriteLine("Press <ENTER> to exit")
            Console.ReadLine()

            host.Close()
        End Sub
	End Class
End Namespace
