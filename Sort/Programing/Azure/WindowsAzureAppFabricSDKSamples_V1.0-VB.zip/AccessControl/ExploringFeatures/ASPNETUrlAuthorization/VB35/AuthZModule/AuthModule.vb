﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Configuration
Imports System.Net
Imports System.Security
Imports System.Security.Principal
Imports System.Text
Imports System.Web
Imports System.Web.Configuration
Imports System.Web.Security
Imports Microsoft.VisualBasic

Namespace Microsoft.AccessControl.ASPNET

    ' see http://go.microsoft.com/?linkid=8101007 for IIS setup
    Public Class AuthModule
        Implements IHttpModule
        Private Const serviceNamespace As String = "updateToServiceNamespace"
        Private Const signingKey As String = "updateToTokenPolicyKey"

        Private Const acsHostName As String = "accesscontrol.windows.net"

        Private Const trustedAudience As String = "http://localhost/ASPNETUrlAuthorization"

        Private Shared Function SetUnauthorized() As Boolean
            HttpContext.Current.Response.StatusCode = CInt(HttpStatusCode.Unauthorized)
            HttpContext.Current.Response.End()
            Return False
        End Function

        Private Sub OnAuthenticateRequest(ByVal sender As Object, ByVal e As EventArgs)
            Dim isAuthorized As Boolean = False

            ' store the context locally
            Dim context As HttpContext = HttpContext.Current

            ' get the authorization information for the requested URI
            Dim url As String = context.Request.Url.LocalPath
            Dim authMgr As AuthorizationManager = AuthorizationManager.CreateAuthorizationManager(url)

            ' Check to see if we need authentication
            If authMgr.RequiresAuthorization Then
                ' Look for the authorization header
                Dim authHeader As String = context.Request.Headers("Authorization")

                ' check that the authorization header is present
                If Not String.IsNullOrEmpty(authHeader) Then
                    ' check that it starts with 'WRAP'
                    If Not authHeader.StartsWith("WRAP ") Then
                        isAuthorized = SetUnauthorized()
                    End If

                    Dim tokenNameValue() As String = authHeader.Substring("WRAP ".Length).Split(New [Char]() {"="c}, 2)

                    ' check that the token is of the form 'access_token="{token}"'
                    If tokenNameValue.Length <> 2 Or _
                       tokenNameValue(0) <> "access_token" Or _
                       Not tokenNameValue(1).StartsWith("""") Or _
                       Not tokenNameValue(1).EndsWith("""") Then
                        isAuthorized = SetUnauthorized()
                    End If

                    ' trim off the leading and trailing double-quotes
                    Dim token As String = tokenNameValue(1).Substring(1, tokenNameValue(1).Length - 2)

                    Dim validator As New TokenValidator(acsHostName, serviceNamespace, trustedAudience, signingKey)

                    ' validate the token
                    If Not validator.Validate(token) Then
                        isAuthorized = SetUnauthorized()
                    End If

                    ' create the user
                    context.User = New ServiceUser(token, validator)

                    ' check if the user is authorized based on config settings
                    If authMgr.VerifyAuthorization(context.User) Then
                        isAuthorized = True
                    Else
                        isAuthorized = SetUnauthorized()
                    End If
                End If
            End If

            ' Check for authentication and return HTTP 401 if none
            If Not isAuthorized Then
                ' Assign the status code
                context.Response.StatusCode = CInt(HttpStatusCode.Unauthorized)

                ' Calculate the realm
                Dim realm As String = String.Format("ACSrealm=""{0}""", context.Request.Url.GetLeftPart(UriPartial.Path))

                ' Add the authentication header
                context.Response.AddHeader("WWW-Authenticate", realm)

                ' End the request
                context.Response.End()
            End If
        End Sub

        Public Sub Dispose() Implements IHttpModule.Dispose
        End Sub

        Public Sub Init(ByVal context As HttpApplication) Implements IHttpModule.Init
            AddHandler context.AuthenticateRequest, AddressOf OnAuthenticateRequest
        End Sub
    End Class
End Namespace