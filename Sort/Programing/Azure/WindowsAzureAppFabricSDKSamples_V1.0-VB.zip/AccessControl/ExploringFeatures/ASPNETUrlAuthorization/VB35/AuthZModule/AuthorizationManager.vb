﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Linq
Imports System.Security.Principal
Imports System.Text
Imports System.Web.Configuration

Namespace Microsoft.AccessControl.ASPNET

    Public Class AuthorizationManager
        'INSTANT VB NOTE: The variable allowedRoles was renamed since Visual Basic does not allow class members with the same name:
        Private allowedRoles_Renamed As New CommaDelimitedStringCollection()
        'INSTANT VB NOTE: The variable deniedRoles was renamed since Visual Basic does not allow class members with the same name:
        Private deniedRoles_Renamed As New CommaDelimitedStringCollection()
        'INSTANT VB NOTE: The variable allowedUsers was renamed since Visual Basic does not allow class members with the same name:
        Private allowedUsers_Renamed As New CommaDelimitedStringCollection()
        'INSTANT VB NOTE: The variable deniedUsers was renamed since Visual Basic does not allow class members with the same name:
        Private deniedUsers_Renamed As New CommaDelimitedStringCollection()

        Private Sub New()
        End Sub

        Public ReadOnly Property AllowedRoles() As CommaDelimitedStringCollection
            Get
                Return Me.allowedRoles_Renamed
            End Get
        End Property

        Public ReadOnly Property DeniedRoles() As CommaDelimitedStringCollection
            Get
                Return Me.deniedRoles_Renamed
            End Get
        End Property

        Public ReadOnly Property AllowedUsers() As CommaDelimitedStringCollection
            Get
                Return Me.allowedUsers_Renamed
            End Get
        End Property

        Public ReadOnly Property DeniedUsers() As CommaDelimitedStringCollection
            Get
                Return Me.deniedUsers_Renamed
            End Get
        End Property

        Public ReadOnly Property HasRoles() As Boolean
            Get
                Return Me.AllowedRoles.Count > 0 OrElse Me.DeniedRoles.Count > 0
            End Get
        End Property

        Public ReadOnly Property HasExplicitUsers() As Boolean
            Get
                Dim hasUsers As Boolean = False

                If Me.AllowedUsers.Count = 1 AndAlso Me.AllowedUsers.Contains("*") AndAlso Me.AllowedRoles.Count = 0 Then
                    ' all users are implicitly allowed (*)
                Else
                    If (Me.AllowedUsers.Count > 0) OrElse (Me.DeniedUsers.Count > 0) Then
                        hasUsers = True
                    End If
                End If

                Return hasUsers
            End Get
        End Property

        Public ReadOnly Property RequiresAuthorization() As Boolean
            Get
                Return Me.HasRoles OrElse Me.HasExplicitUsers
            End Get
        End Property

        Public Shared Function CreateAuthorizationManager(ByVal url As String) As AuthorizationManager
            Dim config As Configuration = WebConfigurationManager.OpenWebConfiguration(url)

            Dim configSection As AuthorizationSection = CType(config.GetSection("system.web/authorization"), AuthorizationSection)

            Dim rules As AuthorizationRuleCollection = configSection.Rules

            Dim authManager As New AuthorizationManager()

            For i As Integer = 0 To rules.Count - 1
                If rules(i).Roles.Count > 0 Then
                    If rules(i).Action.ToString() = "Allow" Then
                        authManager.AllowedRoles.AddRange(rules(i).Roles.ToString().Split(","c))
                    ElseIf rules(i).Action.ToString() = "Deny" Then
                        authManager.DeniedRoles.AddRange(rules(i).Roles.ToString().Split(","c))
                    End If
                End If

                If rules(i).Users.Count > 0 Then
                    If rules(i).Action.ToString() = "Allow" Then
                        authManager.AllowedUsers.AddRange(rules(i).Users.ToString().Split(","c))
                    ElseIf rules(i).Action.ToString() = "Deny" Then
                        authManager.DeniedUsers.AddRange(rules(i).Users.ToString().Split(","c))
                    End If
                End If
            Next i

            Return authManager
        End Function

        Public Function VerifyAuthorization(ByVal user As IPrincipal) As Boolean
            ' if the user is explicitly denied access, return false
            If Me.DeniedUsers.Contains(user.Identity.Name) Then
                Return False
            End If

            ' if the user is explicitly allowed access, return true
            If Me.AllowedUsers.Contains(user.Identity.Name) Then
                Return True
            End If

            ' check if user is denied by role
            Dim userDeniedByRole As Boolean = False
            For Each role As String In Me.DeniedRoles
                If user.IsInRole(role) Then
                    userDeniedByRole = True
                    Exit For
                End If
            Next role

            ' if the user is denied explicitly by role, return false
            If userDeniedByRole Then
                Return False
            End If

            ' check if the user is allowed by role
            Dim userAllowedByRole As Boolean = False
            For Each role As String In Me.AllowedRoles
                If user.IsInRole(role) Then
                    userAllowedByRole = True
                    Exit For
                End If
            Next role

            ' if the user is allowed by role, return true
            If userAllowedByRole Then
                Return True
            End If

            ' if all users are denied, return false
            If Me.DeniedUsers.Contains("*") Then
                Return False
            End If

            ' if all roles are denied, return false
            If Me.DeniedRoles.Contains("*") Then
                Return False
            End If

            ' otherwise, return false
            Return False
        End Function
    End Class
End Namespace