﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.Collections.Specialized
Imports System.Linq
Imports System.Security.Principal
Imports System.Text

Namespace Microsoft.AccessControl.ASPNET

	Public NotInheritable Class ServiceIdentity
		Implements IIdentity
		Private authenticationTypeString As String = "ACSToken"
'INSTANT VB NOTE: The variable isAuthenticated was renamed since Visual Basic does not allow class members with the same name:
		Private isAuthenticated_Renamed As Boolean = False
'INSTANT VB NOTE: The variable claims was renamed since Visual Basic does not allow class members with the same name:
		Private claims_Renamed As Dictionary(Of String, String)

		Private username As String

		Friend Sub New(ByVal token As String, ByVal validator As TokenValidator)
			' if the token is valid, they are authenticated
			Me.isAuthenticated_Renamed = False

			Me.claims_Renamed = validator.GetNameValues(token)

			If Me.claims_Renamed.TryGetValue("name", Me.username) Then
				Me.isAuthenticated_Renamed = True
			End If
		End Sub

		Public ReadOnly Property AuthenticationType() As String Implements IIdentity.AuthenticationType
			Get
				Return Me.authenticationTypeString
			End Get
		End Property

		Public ReadOnly Property IsAuthenticated() As Boolean Implements IIdentity.IsAuthenticated
			Get
				Return Me.isAuthenticated_Renamed
			End Get
		End Property

		Public ReadOnly Property Name() As String Implements IIdentity.Name
			Get
				Return Me.username
			End Get
		End Property

		Public ReadOnly Property Claims() As Dictionary(Of String, String)
			Get
				Return Me.claims_Renamed
			End Get
		End Property
	End Class
End Namespace
