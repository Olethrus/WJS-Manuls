﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.Security
Imports System.Security.Principal
Imports System.Web
Imports System.Web.Security

Namespace Microsoft.AccessControl.ASPNET

	Public Class ServiceUser
		Implements IPrincipal
'INSTANT VB NOTE: The variable identity was renamed since Visual Basic does not allow class members with the same name:
		Private identity_Renamed As IIdentity = Nothing
		Private roles() As String

		Friend Sub New(ByVal token As String, ByVal validator As TokenValidator)
			If token Is Nothing Then
				Throw New ArgumentNullException("token")
			End If

			' set the identity field
			Dim identity As New ServiceIdentity(token, validator)

			Dim roleClaims As New List(Of String)()

			For Each claim As KeyValuePair(Of String, String) In identity.Claims
				If claim.Key.Equals("role", StringComparison.OrdinalIgnoreCase) Then
					roleClaims.Add(claim.Value)
				End If
			Next claim

			Me.roles = roleClaims.ToArray()

			Me.identity_Renamed = TryCast(identity, IIdentity)
		End Sub

		Public ReadOnly Property Identity() As IIdentity Implements IPrincipal.Identity
			Get
				Return Me.identity_Renamed
			End Get
		End Property

		Public Function IsInRole(ByVal role As String) As Boolean Implements IPrincipal.IsInRole
			' Look up role
			For Each testRole As String In Me.roles
				If role.Equals(testRole, StringComparison.OrdinalIgnoreCase) Then
					Return True
				End If
			Next testRole

			Return False
		End Function
	End Class
End Namespace
