﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Specialized
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Text
Imports System.Web

Namespace Microsoft.AccessControl.SDK.ASPNET

	Friend Class Program
		Private Shared serviceNamspace As String
		Private Shared issuerKey As String
        Private Shared acsHostName As String = "accesscontrol.windows.net"

		Shared Sub Main(ByVal args() As String)
			Console.WriteLine("Enter your service namespace, then press <ENTER>")
			serviceNamspace = Console.ReadLine()

			Console.WriteLine(vbLf & "Enter your issuer key, then press <ENTER>")
            issuerKey = Console.ReadLine()

			Dim token As String = GetTokenFromACS()

			Console.WriteLine(vbLf & "received token from ACS: {0}" & vbLf, token)

			Dim response As String = GetDataFromService(token)

			Console.WriteLine("Service responded with: {0}" & vbLf, response)

			Console.WriteLine("Press <ENTER> to exit")

			Console.ReadLine()
		End Sub

		Private Shared Function GetDataFromService(ByVal token As String) As String
			Dim client As New WebClient()
            client.BaseAddress = "http://localhost/aspneturlauthorization/Default.aspx"

            Dim headerValue As String = String.Format("WRAP access_token=""{0}""", HttpUtility.UrlDecode(token))

            client.Headers.Add("Authorization", headerValue)

			Dim byteResponse() As Byte = client.DownloadData(String.Empty)
			Return Encoding.UTF8.GetString(byteResponse)
		End Function

		Private Shared Function GetTokenFromACS() As String
			' request a token from ACS
			Dim client As New WebClient()
            client.BaseAddress = String.Format("https://{0}.{1}", serviceNamspace, acsHostName)

			Dim values As New NameValueCollection()
            values.Add("wrap_name", "aspneturlauthorization")
            values.Add("wrap_password", issuerKey)
            values.Add("wrap_scope", "http://localhost/ASPNETUrlAuthorization")

            Dim responseBytes() As Byte = client.UploadValues("WRAPv0.9/", "POST", values)

            Dim response As String = Encoding.UTF8.GetString(responseBytes)

            Return response.Split("&"c).Single(Function(value) value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase)).Split("="c)(1)
		End Function
	End Class
End Namespace

