﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System.IO;
    using System.Net;
    using System.Xml.Serialization;
    using System;

    public class ManagementServiceException : ManagementException
    {
        public HttpStatusCode StatusCode { get; private set; }
        public string TrackingId { get; private set; }

        private ManagementServiceException(string message, HttpStatusCode statusCode, int subCode, string trackingId)
            : base(message)
        {
            this.StatusCode = statusCode;
            this.TrackingId = trackingId;
        }

        public static void Throw(WebException webException)
        {
            HttpWebResponse response = webException.Response as HttpWebResponse;
            ErrorDetail errorDetail;

            try
            {
                XmlSerializer serializer = new XmlSerializer(typeof(ErrorDetail));
                using (Stream stream = response.GetResponseStream())
                {
                    errorDetail = (ErrorDetail)serializer.Deserialize(stream);
                }
            }
            catch
            {
                throw webException;
            }

            int subCode = int.Parse(errorDetail.SubCode.Substring(1));
            string trackingId = response.Headers[Constants.TrackingIdHeader];
            throw new ManagementServiceException(errorDetail.Detail, response.StatusCode, subCode, trackingId);
        }

        [XmlRoot(ElementName = "Error")]
        public class ErrorDetail
        {
            public string Code { get; set; }
            public string SubCode { get; set; }
            public string Detail { get; set; }
        }
    }
}
