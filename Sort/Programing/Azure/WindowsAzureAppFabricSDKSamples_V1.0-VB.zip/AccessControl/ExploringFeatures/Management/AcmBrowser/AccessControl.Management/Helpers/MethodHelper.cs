﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System;
    using System.IO;
    using System.Net;
    using System.Xml.Serialization;
    using AccessControl.TokenService;

    internal static class MethodHelper
    {
        public static void CreateInService(this Resource resource, string serviceNamespace, AcsToken authToken)
        {
            Uri requestUri = Utilities.DomainUri(serviceNamespace, resource);

            HttpWebRequest request = NewRequest("POST", requestUri, authToken);
            request.AddResourceToRequest(resource);

            HttpWebResponse response = GetResponse(request);
            DeserializeInto(ref resource, response);
        }

        public static void DeleteFromService(this Resource resource, string serviceNamespace, AcsToken authToken)
        {
            Uri requestUri = Utilities.ResourceUri(serviceNamespace, resource);

            HttpWebRequest request = NewRequest("DELETE", requestUri, authToken);
            GetResponse(request);
        }

        public static void EnumerateFromService(this Resource resource, string serviceNamespace, AcsToken authToken)
        {
            // add the Enumerate query to the end of the request URI
            UriBuilder builder = new UriBuilder(Utilities.ResourceUri(serviceNamespace, resource));
            builder.Query = Constants.EnumerateQuery;
            Uri requestUri = builder.Uri;

            HttpWebRequest request = NewRequest("GET", requestUri, authToken);

            HttpWebResponse response = GetResponse(request);
            DeserializeInto(ref resource, response);
        }

        public static void EnumerateFromService(this ResourceCollection resources, string serviceNamespace, AcsToken authToken)
        {
            // add the Enumerate query to the end of the request URI
            UriBuilder builder = new UriBuilder(Utilities.DomainUri(serviceNamespace, resources));
            builder.Query = Constants.EnumerateQuery;
            Uri requestUri = builder.Uri;

            HttpWebRequest request = NewRequest("GET", requestUri, authToken);

            HttpWebResponse response = GetResponse(request);
            DeserializeInto(ref resources, response);
        }

        public static void GetFromService(this Resource resource, string serviceNamespace, AcsToken authToken)
        {
            Uri requestUri = Utilities.ResourceUri(serviceNamespace, resource);

            HttpWebRequest request = NewRequest("GET", requestUri, authToken);

            HttpWebResponse response = GetResponse(request);
            DeserializeInto(ref resource, response);
        }

        public static void GetFromService(this ResourceCollection resources, string serviceNamespace, AcsToken authToken)
        {
            Uri requestUri = Utilities.DomainUri(serviceNamespace, resources);

            HttpWebRequest request = NewRequest("GET", requestUri, authToken);

            HttpWebResponse response = GetResponse(request);
            DeserializeInto(ref resources, response);
        }

        public static void UpdateInService(this Resource resource, string serviceNamespace, AcsToken authToken)
        {
            Uri requestUri = Utilities.ResourceUri(serviceNamespace, resource);

            HttpWebRequest request = NewRequest("PUT", requestUri, authToken);
            GetResponse(request);
        }

        private static void AddResourceToRequest(this HttpWebRequest request, Resource resource)
        {
            using (Stream stream = request.GetRequestStream())
            {
                resource.Serialize(stream);
            }
        }

        public static void DeserializeInto(ref Resource resource, HttpWebResponse response)
        {
            using (Stream stream = response.GetResponseStream())
            {
                XmlSerializer serializer = new XmlSerializer(resource.GetType());
                Resource deserializedResource = (Resource)serializer.Deserialize(stream);
                resource.CopyFrom(deserializedResource);
            }
        }

        public static void DeserializeInto(ref ResourceCollection resources, HttpWebResponse response)
        {
            using (Stream stream = response.GetResponseStream())
            {
                XmlSerializer serializer = new XmlSerializer(resources.GetType());
                ResourceCollection deserializedResources = (ResourceCollection)serializer.Deserialize(stream);
                resources.CopyFrom(deserializedResources);
            }
        }

        private static HttpWebResponse GetResponse(HttpWebRequest request)
        {
            HttpWebResponse response = null;
            
            try
            {
                response = (HttpWebResponse)request.GetResponse();
            }
            catch (WebException we)
            {
                ManagementServiceException.Throw(we);
            }

            return response;
        }

        private static HttpWebRequest NewRequest(string method, Uri requestUri, AcsToken authToken)
        {
            HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(requestUri);
            request.ContentType = "application/xml";
            request.Method = method;
            request.AddAuthorizationHeader(authToken);
            
            return request;
        }
    }
}
