﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System.Xml.Serialization;

    [XmlRoot(Namespace = Constants.ResourceNamespace)]
    public class Rule : Resource
    {
        public override string Domain
        {
            get { return string.Format("rulesets/{0}/rules", RuleSetId); }
        }

        [XmlIgnore]
        public string RuleSetId { get; set; }

        public InputClaim InputClaim { get; set; }
        public OutputClaim OutputClaim { get; set; }
        public string Type { get; set; }

        private Rule()
        {
        }

        public Rule(string ruleSetId)
        {
            this.RuleSetId = ruleSetId;
        }

        internal override void CopyFrom(Resource that)
        {
            Rule thatRule = that as Rule;

            if (thatRule != null)
            {
                base.CopyFrom(that);

                this.InputClaim = new InputClaim();
                this.InputClaim.IssuerId = thatRule.InputClaim.IssuerId;
                this.InputClaim.Type = thatRule.InputClaim.Type;
                this.InputClaim.Value = thatRule.InputClaim.Value;

                this.OutputClaim = new OutputClaim();
                this.OutputClaim.Type = thatRule.OutputClaim.Type;
                this.OutputClaim.Value = thatRule.OutputClaim.Value;

                this.Type = thatRule.Type;
            }
        }
    }

    public class InputClaim
    {
        public string IssuerId { get; set; }
        public string Type { get; set; }

        [XmlElementAttribute(IsNullable = false)]
        public string Value { get; set; }
    }

    public class OutputClaim
    {
        public string Type { get; set; }

        [XmlElementAttribute(IsNullable = false)]
        public string Value { get; set; }
    }
}