﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System.Xml.Serialization;

    [XmlRoot(Namespace = Constants.ResourceNamespace)]
    public class Scope : Resource
    {
        public override string Domain
        {
            get { return "scopes"; }
        }

        public string AppliesTo { get; set; }

        [XmlArray(IsNullable = true)]
        [XmlArrayItem(ElementName = "Id")]
        public string[] RuleSets { get; set; }

        public string TokenPolicyId { get; set; }

        internal override void CopyFrom(Resource that)
        {
            Scope thatScope = that as Scope;

            if (thatScope != null)
            {
                base.CopyFrom(that);

                this.AppliesTo = thatScope.AppliesTo;
                this.RuleSets = new string[1];
                this.RuleSets[0] = thatScope.RuleSets[0];
                this.TokenPolicyId = thatScope.TokenPolicyId;
            }
        }
    }
}
