﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.Management
{
    using System.Xml.Serialization;

    [XmlRoot(Namespace = Constants.ResourceNamespace)]
    public class TokenPolicy : Resource
    {
        public override string Domain
        {
            get { return "tokenpolicies"; }
        }

        public string DefaultTokenLifetimeInSeconds { get; set; }
        public string SigningKey { get; set; }

        internal override void CopyFrom(Resource that)
        {
            TokenPolicy thatTokenPolicy = that as TokenPolicy;

            if (thatTokenPolicy != null)
            {
                base.CopyFrom(that);

                this.DefaultTokenLifetimeInSeconds = thatTokenPolicy.DefaultTokenLifetimeInSeconds;
                this.SigningKey = thatTokenPolicy.SigningKey;
            }
        }
    }
}
