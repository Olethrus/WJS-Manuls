﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;
    using System.Linq;

    public static class AccessControl
    {
        public static void Authorize(string authorizationHeader, string expectedIssuer, string signingKey, Uri expectedAudience, ClaimSet expectedClaims)
        {
            AcsToken token = Helper.ParseAndValidateAuthorizationHeader(authorizationHeader, signingKey);

            if (token.ExpiresOn < DateTime.UtcNow)
            {
                throw new TokenException("The token is expired.");
            }

            if (expectedAudience != token.Audience)
            {
                throw new TokenException("The token does not have the correct audience.");
            }

            if (expectedIssuer != token.Issuer)
            {
                throw new TokenException("The token does not have the correct issuer.");
            }

            foreach (Claim claim in expectedClaims)
            {
                if (!token.Claims.Contains(claim))
                {
                    throw new TokenException("The token does not contain the expected claims.");
                }
            }
        }
    }
}
