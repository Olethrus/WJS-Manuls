﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;

    public class Claim
    {
        public string Type { get; private set; }

        public string Value { get; private set; }

        public Claim(string type, string value)
        {
            if (null == type)
            {
                throw new TokenException("The claim type cannot be null.");
            }

            if (null == value)
            {
                throw new TokenException("The claim value cannot be null.");
            }

            this.Type = type;
            this.Value = value;
        }

        public override bool Equals(object obj)
        {
            Claim that = obj as Claim;

            return (that != null && this.Type == that.Type && this.Value == that.Value);
        }

        public override int GetHashCode()
        {
            return (this.Type + this.Value).GetHashCode();
        }
    }
}
