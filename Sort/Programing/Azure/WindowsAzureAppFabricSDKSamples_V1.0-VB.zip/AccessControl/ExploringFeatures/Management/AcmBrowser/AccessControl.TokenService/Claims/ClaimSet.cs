﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;

    public class ClaimSet : IEnumerable<Claim>, ICloneable
    {
        private Collection<Claim> claims;

        public ClaimSet()
        {
            this.claims = new Collection<Claim>();
        }

        private ClaimSet(ClaimSet claimSet)
            : this()
        {
            foreach (Claim claim in claimSet)
            {
                this.Add(claim);
            }
        }

        public void Add(Claim claim)
        {
            if (null == claim)
            {
                throw new TokenException("The claim cannot be null.");
            }

            this.claims.Add(claim);
        }

        public object Clone()
        {
            return new ClaimSet(this);
        }

        public bool Contains(Claim claim)
        {
            return this.claims.Contains(claim);
        }

        public IEnumerator<Claim> GetEnumerator()
        {
            return this.claims.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.claims.GetEnumerator();
        }
    }
}
