﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System.IO;
    using System.Net;
    using System;

    public class TokenServiceException : TokenException
    {
        public HttpStatusCode StatusCode { get; private set; }
        public int SubCode { get; private set; }
        public string TrackingId { get; private set; }

        private TokenServiceException(string message, HttpStatusCode statusCode, int subCode, string trackingId)
            : base(message)
        {
            this.StatusCode = statusCode;
            this.SubCode = subCode;
            this.TrackingId = trackingId;
        }

        internal static void Throw(WebException webException)
        {
            HttpWebResponse response = webException.Response as HttpWebResponse;
            string body;

            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                body = reader.ReadToEnd();
            }

            // error detail format: Error:Code:{0}:SubCode:T{1}:Detail:{2}
            string[] bodyParts = body.Split(new char[] { ':' }, 7);
            if (bodyParts.Length != 7 || bodyParts[0] != "Error")
            {
                // the body does not contain error detail information
                throw webException;
            }
            else
            {
                HttpStatusCode statusCode = (HttpStatusCode)int.Parse(bodyParts[2]);
                int subCode = int.Parse(bodyParts[4].Substring(1));
                string message = bodyParts[6];
                string trackingId = response.Headers[Constants.TrackingIdHeader];

                throw new TokenServiceException(message, statusCode, subCode, trackingId);
            }
        }
    }
}
