﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;

    internal static class Constants
    {
        public const string SWT_Audience = "Audience";
        public const string SWT_ExpiresOn = "ExpiresOn";
        public const string SWT_HMACSHA256 = "HMACSHA256";
        public const string SWT_Issuer = "Issuer";

        public const string WRAP_Header = "WRAP";
        public const string WRAP_Header_Token = "access_token";

        public const string WRAP_Token = "wrap_access_token";
        public const string WRAP_ExpiresIn = "wrap_access_token_expires_in";

        public const string WRAP_Assertion = "wrap_assertion";
        public const string WRAP_Format = "wrap_assertion_format";
        public const string WRAP_Format_SWT = "SWT";

        public const string WRAP_Name = "wrap_name";
        public const string WRAP_Password = "wrap_password";

        public const string WRAP_AppliesTo = "wrap_scope";

        public const int KeyLength = 32;
        public const string TrackingIdHeader = "x-ms-request-id";

        public static readonly DateTime Epoch = new DateTime(1970, 1, 1);
    }
}
