﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Linq;
    using System.Net;
    using System.Security.Cryptography;
    using System.Text;
    using System.Web;

    public static class Helper
    {
        public static void AddAuthorizationHeader(this HttpWebRequest request, AcsToken token)
        {
            request.Headers[HttpRequestHeader.Authorization] = token.AsAuthorizationHeader();
        }

        internal static AcsToken ParseAndValidateAuthorizationHeader(string authorizationHeader, string key)
        {
            // remove authorization scheme
            string tokenString = authorizationHeader.Substring(Constants.WRAP_Header.Length).Trim();
            AcsToken token = new AcsToken(tokenString);

            // verify signature
            int indexOfLastAmpersand = tokenString.LastIndexOf('&');
            string unsignedToken = tokenString.Substring(0, indexOfLastAmpersand);

            if (GetSignature(unsignedToken, key) != token.Signature)
            {
                throw new TokenException("The token does not have a valid signature.");
            }

            return token;
        }

        internal static void ThrowIfNotValidKey(string key, string parameterName)
        {
            ThrowIfNullOrEmpty(key, parameterName);

            byte[] keyBytes;
            if (TryParseKey(key, out keyBytes))
            {
                if (keyBytes.Length != Constants.KeyLength)
                {
                    throw new TokenException(string.Format("The {0} is not of the appropriate length.", parameterName));
                }
            }
            else
            {
                throw new TokenException(string.Format("The {0} is not a valid Base64-encoded value.", parameterName));
            }
        }

        internal static void ThrowIfNull(object value, string parameterName)
        {
            if (null == value)
            {
                throw new TokenException(string.Format("The {0} is null.", parameterName));
            }
        }

        internal static void ThrowIfNullOrEmpty(string value, string parameterName)
        {
            if (string.IsNullOrEmpty(value))
            {
                throw new TokenException(string.Format("The {0} is null or empty.", parameterName));
            }
        }

        internal static DateTime FromSecondsSinceEpoch(int seconds)
        {
            return Constants.Epoch.AddSeconds(seconds);
        }

        internal static int ToSecondsSinceEpoch(this DateTime dateTime)
        {
            return (int)((dateTime - Constants.Epoch).TotalSeconds);
        }

        internal static Dictionary<string, string> CreateParameterDictionary(string urlEncodedString)
        {
            Dictionary<string, string> parameterDictionary = new Dictionary<string, string>();
            foreach (string pair in urlEncodedString.Split('&'))
            {
                KeyValuePair<string, string> nameValuePair = ParseNameValuePair(pair);
                parameterDictionary.Add(nameValuePair.Key, nameValuePair.Value);
            }

            return parameterDictionary;
        }

        internal static KeyValuePair<string, string> ParseNameValuePair(string nameValuePair)
        {
            string[] typeValuePair = nameValuePair.Split('=');
            KeyValuePair<string, string> pair = new KeyValuePair<string, string>();

            if (typeValuePair.Length == 2)
            {
                pair = new KeyValuePair<string, string>(HttpUtility.UrlDecode(typeValuePair[0]), HttpUtility.UrlDecode(typeValuePair[1]));
            }

            return pair;
        }

        internal static string GetSignature(string toSign, string signingKey)
        {
            byte[] key = Convert.FromBase64String(signingKey);
            byte[] toSignInBytes = Encoding.UTF8.GetBytes(toSign);
            byte[] signature;

            using (HMACSHA256 sha256 = new HMACSHA256(key))
            {
                signature = sha256.ComputeHash(toSignInBytes);
            }

            return Convert.ToBase64String(signature);
        }

        internal static string UrlEncode(string name, string value)
        {
            return string.Format(CultureInfo.InvariantCulture, "{0}={1}", HttpUtility.UrlEncode(name), HttpUtility.UrlEncode(value));
        }

        internal static string UrlEncode(Dictionary<string, string> paramaterDictionary)
        {
            string[] nameValuePairs = paramaterDictionary.Keys.Select<string, string>((name) => UrlEncode(name, paramaterDictionary[name])).ToArray();

            return string.Join("&", nameValuePairs);
        }

        private static bool TryParseKey(string key, out byte[] keyBytes)
        {
            bool success = true;

            try
            {
                keyBytes = Convert.FromBase64String(key);
            }
            catch
            {
                keyBytes = null;
                success = false;
            }

            return success;
        }
    }
}
