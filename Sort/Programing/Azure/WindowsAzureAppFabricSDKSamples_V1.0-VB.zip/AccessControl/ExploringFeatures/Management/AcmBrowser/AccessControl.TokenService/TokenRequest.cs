﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;
    using System.IO;
    using System.Net;

    public class TokenRequest
    {
        private Uri requestUri;

        public Credentials Credentials { get; private set; }

        public TokenRequest(string tokenServiceUri, Credentials credentials)
            : this(new Uri(tokenServiceUri), credentials)
        {
        }

        public TokenRequest(Uri tokenServiceUri, Credentials credentials)
        {
            this.requestUri = tokenServiceUri;
            this.Credentials = credentials;
        }

        public HttpWebRequest GetRequest()
        {
            HttpWebRequest tokenRequest = (HttpWebRequest)HttpWebRequest.Create(requestUri);
            tokenRequest.ContentType = "application/x-www-form-urlencoded";
            tokenRequest.Method = "POST";

            using (Stream stream = tokenRequest.GetRequestStream())
            {
                using (StreamWriter writer = new StreamWriter(stream))
                {
                    writer.Write(this.Credentials.Encode());
                }
            }
            return tokenRequest;
        }

        public TokenResponse GetResponse()
        {
            HttpWebRequest tokenRequest = GetRequest();

            return new TokenResponse(tokenRequest);
        }
    }
}
