﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class AcsToken : Token
    {
        private Dictionary<string, string> tokenDictionary;

        public Uri Audience { get; set; }
        public DateTime? ExpiresOn { get; set; }
        public string Issuer { get; set; }
        public string Signature { get; set; }

        public AcsToken()
        {
            this.tokenDictionary = new Dictionary<string, string>();
        }

        internal AcsToken(string token)
        {
            this.DecodeFromSimpleApiToken(token);
        }

        public string AsAuthorizationHeader()
        {
            return string.Format("{0} {1}=\"{2}\"", Constants.WRAP_Header, Constants.WRAP_Header_Token, this.tokenDictionary[Constants.WRAP_Token]);
        }

        internal void Decode(Stream stream)
        {
            string token;
            using (StreamReader reader = new StreamReader(stream))
            {
                token = reader.ReadToEnd();
            }

            this.tokenDictionary = Helper.CreateParameterDictionary(token);
            this.DecodeFromSimpleApiToken(this.tokenDictionary[Constants.WRAP_Token]);
        }

        private void AddClaim(string type, string value)
        {
            string[] claimValues = value.Split(',');
            foreach (string claimValue in claimValues)
            {
                this.Claims.Add(new Claim(type, claimValue));
            }
        }

        private void DecodeFromSimpleApiToken(string token)
        {
            Dictionary<string, string> claims = Helper.CreateParameterDictionary(token);

            foreach (string claimType in claims.Keys)
            {
                string claimValue = claims[claimType];
                switch (claimType)
                {
                    case Constants.SWT_Audience:
                        this.Audience = new Uri(claimValue);
                        break;
                    case Constants.SWT_Issuer:
                        this.Issuer = claimValue;
                        break;
                    case Constants.SWT_ExpiresOn:
                        this.ExpiresOn = Helper.FromSecondsSinceEpoch(int.Parse(claimValue));
                        break;
                    case Constants.SWT_HMACSHA256:
                        this.Signature = claimValue;
                        break;
                    default:
                        this.AddClaim(claimType, claimValue);
                        break;
                }
            }
        }
    }
}
