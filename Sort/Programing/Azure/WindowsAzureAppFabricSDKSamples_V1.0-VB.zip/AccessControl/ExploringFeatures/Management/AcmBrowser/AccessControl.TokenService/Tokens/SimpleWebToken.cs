﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AccessControl.TokenService
{
    using System;
    using System.Collections.Generic;

    public class SimpleWebToken : Credentials
    {
        public Uri Audience { get; set; }
        public DateTime? ExpiresOn { get; set; }
        public string Issuer { get; set; }
        public string Key { get; set; }

        public SimpleWebToken()
        {
        }

        public SimpleWebToken(SimpleWebToken toCopy)
        {
            this.AppliesTo = toCopy.AppliesTo;
            this.Audience = toCopy.Audience;
            this.ExpiresOn = toCopy.ExpiresOn;
            this.Issuer = toCopy.Issuer;
            this.Key = toCopy.Key;
            this.Claims = toCopy.Claims.Clone() as ClaimSet;
        }

        public override object Clone()
        {
            return new SimpleWebToken(this);
        }

        internal override string Encode()
        {
            this.Validate();

            Dictionary<string, string> parameterDictionary = new Dictionary<string, string>();
            string swt = ConstructSWT();

            parameterDictionary[Constants.WRAP_Format] = Constants.WRAP_Format_SWT;
            parameterDictionary[Constants.WRAP_Assertion] = swt;
            parameterDictionary[Constants.WRAP_AppliesTo] = this.AppliesTo.AbsoluteUri;

            return Helper.UrlEncode(parameterDictionary);
        }

        internal override void Validate()
        {
            Helper.ThrowIfNull(this.AppliesTo, "AppliesTo");
            Helper.ThrowIfNullOrEmpty(this.Issuer, "Issuer");
            Helper.ThrowIfNotValidKey(this.Key, "Key");
        }

        private string ConstructSWT()
        {
            Dictionary<string, string> parameterDictionary = new Dictionary<string, string>();

            parameterDictionary[Constants.SWT_Issuer] = this.Issuer;

            if (this.ExpiresOn != null)
            {
                DateTime expiresOn = (DateTime)this.ExpiresOn;
                parameterDictionary[Constants.SWT_ExpiresOn] = expiresOn.ToSecondsSinceEpoch().ToString();
            }

            if (this.Audience != null)
            {
                parameterDictionary[Constants.SWT_Audience] = this.Audience.AbsoluteUri;
            }

            foreach (Claim claim in this.Claims)
            {
                string value = claim.Value;
                if (parameterDictionary.TryGetValue(claim.Type, out value))
                {
                    value = value + "," + claim.Value;
                }
                parameterDictionary[claim.Type] = value;
            }

            string unsignedToken = Helper.UrlEncode(parameterDictionary);
            string signature = Helper.GetSignature(unsignedToken, this.Key);

            parameterDictionary[Constants.SWT_HMACSHA256] = signature;

            return Helper.UrlEncode(parameterDictionary);
        }
    }
}
