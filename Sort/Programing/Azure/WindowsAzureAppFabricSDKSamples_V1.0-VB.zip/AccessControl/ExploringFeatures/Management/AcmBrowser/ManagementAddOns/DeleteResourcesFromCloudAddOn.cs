﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns
{
    using System;
    using System.Drawing;
    using System.Windows;
    using AccessControl.Management;
    using AcmBrowser;
    using AcmBrowser.Model;

    public class DeleteResourcesFromCloudAddOn : AddOn
    {
        private delegate void Delete();

        public override string Title
        {
            get { return "Clear Service Namespace in Cloud"; }
        }

        public override Icon Icon
        {
            get { return ManagementAddOns.Properties.Resources.DeleteResourcesFromCloud; }
        }

        public override bool RefreshTree
        {
            get { return false; }
        }

        public DeleteResourcesFromCloudAddOn(Browser parentBrowser)
            : base(parentBrowser)
        {
        }

        public override void Invoke()
        {
            try
            {
                OnBeginInvoke();
                OnInvoke();
            }
            catch (Exception e)
            {
                HandleException(e);
            }
        }

        protected override void OnInvoke()
        {
            string warning = string.Format("Are you sure you want to delete ALL the resources in the '{0}' Service Namespace?", ParentBrowser.Namespace);
            MessageBoxResult warningResult = MessageBox.Show(warning, "Delete all?", MessageBoxButton.YesNo, MessageBoxImage.Warning);

            if (warningResult == MessageBoxResult.Yes)
            {
                Delete DeleteServiceNamespace = ClearInCloud;
                DeleteServiceNamespace.BeginInvoke(OnEndDelete, DeleteServiceNamespace);
            }
        }

        public void OnEndDelete(IAsyncResult result)
        {
            Delete DeleteServiceNamespace = (Delete)result.AsyncState;

            try
            {
                DeleteServiceNamespace.EndInvoke(result);
                MessageBox.Show("The deletion process has completed successfully.", "Success", MessageBoxButton.OK);
                OnEndInvoke();
            }
            catch (Exception e)
            {
                HandleException(e);
            }
        }

        private void ClearInCloud()
        {
            ManagementClient client = new ManagementClient(ParentBrowser.Namespace, ParentBrowser.ManagementKey);

            ProgressUpdate(0.1);
            StatusUpdate("Clearing...");

            IssuerCollection issuers = client.GetAll<IssuerCollection>();
            ProgressUpdate(0.16);
            ScopeCollection scopes = client.GetAll<ScopeCollection>();
            ProgressUpdate(0.32);
            TokenPolicyCollection tokenPolicies;
            if (!ParentBrowser.IsServiceBusServiceNamespace())
            {
                tokenPolicies = client.GetAll<TokenPolicyCollection>();
            }
            else
            {
                // token policies are inaccessible in Service Bus namespaces
                tokenPolicies = new TokenPolicyCollection();
            }
            ProgressUpdate(0.48);

            foreach (Issuer issuer in issuers)
            {
                client.Delete<Issuer>(issuer.Id);
            }
            ProgressUpdate(0.64);

            foreach (Scope scope in scopes)
            {
                client.Delete<Scope>(scope.Id);
            }
            ProgressUpdate(0.80);

            foreach (TokenPolicy tokenPolicy in tokenPolicies)
            {
                client.Delete<TokenPolicy>(tokenPolicy.Id);
            }
            ProgressUpdate(1);
            StatusUpdate("Ready");
        }
    }
}
