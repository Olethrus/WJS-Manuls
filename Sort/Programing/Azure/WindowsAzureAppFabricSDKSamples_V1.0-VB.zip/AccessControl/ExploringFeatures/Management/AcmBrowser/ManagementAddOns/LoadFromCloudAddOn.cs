﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Linq;
    using System.Windows;
    using AccessControl.Management;
    using AcmBrowser;
    using AcmBrowser.Model;
    using ManagementAddOns.Helpers;

    public class LoadFromCloudAddOn : AddOn
    {
        private delegate void Load();
        private bool refresh = true;

        public override string Title
        {
            get { return "Load from Cloud"; }
        }

        public override Icon Icon
        {
            get { return ManagementAddOns.Properties.Resources.LoadFromCloud; }
        }

        public override bool RefreshTree
        {
            get { return this.refresh; }
        }

        public LoadFromCloudAddOn(Browser parentBrowser)
            : base(parentBrowser)
        {
        }

        public override void Invoke()
        {
            try
            {
                OnBeginInvoke();
                OnInvoke();
            }
            catch (Exception e)
            {
                HandleException(e);
            }
        }

        protected override void OnInvoke()
        {
            Load LoadNamespace = LoadServiceNamespace;
            LoadNamespace.BeginInvoke(OnEndLoad, LoadNamespace);
        }

        public void OnEndLoad(IAsyncResult result)
        {
            Load LoadNamespace = (Load)result.AsyncState;

            try
            {
                LoadNamespace.EndInvoke(result);
                MessageBox.Show("The loading process has completed successfully.", "Success", MessageBoxButton.OK);
                OnEndInvoke();
            }
            catch (Exception e)
            {
                HandleException(e);
            }
        }

        private void LoadServiceNamespace()
        {
            ProgressUpdate(0.1);
            StatusUpdate("Loading...");
            ServiceNamespace.Instance.Clear();
            ManagementClient client = new ManagementClient(ParentBrowser.Namespace, ParentBrowser.ManagementKey);

            IssuerCollection issuers = client.GetAll<IssuerCollection>();
            ProgressUpdate(0.25);
            ScopeCollection scopes = client.GetAll<ScopeCollection>();
            ProgressUpdate(0.50);
            // we can only enumerate Service Bus token policies
            TokenPolicyCollection tokenPolicies = ParentBrowser.IsServiceBusServiceNamespace() ?
                client.EnumerateAll() :
                client.GetAll<TokenPolicyCollection>();
            ProgressUpdate(0.75);

            ServiceNamespace.Instance.Scopes = new List<ScopeXml>();
            foreach (Scope scope in scopes)
            {
                ScopeXml scopeXml = scope.ToScopeXml();
                scopeXml.TokenPolicyHandle = tokenPolicies.ResolveTokenPolicyId(scope.TokenPolicyId);
                ServiceNamespace.Instance.Scopes.Add(scopeXml);

                RuleCollection rules = client.GetAll(scope.RuleSets.First());

                scopeXml.Rules = new List<RuleXml>();
                foreach (Rule rule in rules)
                {
                    RuleXml ruleXml = rule.ToRuleXml();
                    ruleXml.InputClaimIssuerHandle = issuers.ResolveIssuerId(rule.InputClaim.IssuerId);
                    scopeXml.Rules.Add(ruleXml);

                }
            }
            ProgressUpdate(0.99);

            ServiceNamespace.Instance.TokenPolicies = new List<TokenPolicyXml>();
            foreach (TokenPolicy tokenPolicy in tokenPolicies)
            {
                ServiceNamespace.Instance.TokenPolicies.Add(tokenPolicy.ToTokenPolicyXml());
            }

            ServiceNamespace.Instance.Issuers = new List<IssuerXml>();
            foreach (Issuer issuer in issuers)
            {
                ServiceNamespace.Instance.Issuers.Add(issuer.ToIssuerXml());
            }
            ProgressUpdate(1);
            StatusUpdate("Ready");
        }
    }
}
