﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns
{
    using System.Drawing;
    using AcmBrowser;
    using AcmBrowser.Model;
    using Microsoft.Win32;

    public class LoadFromDiskAddOn : AddOn
    {
        private bool refresh = true;

        public override string Title
        {
            get { return "Load"; }
        }

        public override Icon Icon
        {
            get { return ManagementAddOns.Properties.Resources.LoadFromDisk; }
        }

        public override bool RefreshTree
        {
            get { return this.refresh; }
        }

        public LoadFromDiskAddOn(Browser browser)
            : base(browser)
        {
        }

        protected override void OnInvoke()
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.DefaultExt = ".xml";
            dialog.Filter = "XML Documents (.xml)|*.xml";
            bool? result = dialog.ShowDialog();
            if (result == true)
            {
                ServiceNamespace.LoadServiceNamespace(dialog.FileName);
            }
            else
            {
                this.refresh = false;
            }
        }
    }
}
