﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns
{
    using AcmBrowser;
    using AcmBrowser.Model;

    public class NewServiceNamespaceAddOn : AddOn
    {
        public override string Title
        {
            get { return "Clear Service Namespace"; }
        }

        public override System.Drawing.Icon Icon
        {
            get { return ManagementAddOns.Properties.Resources.NewServiceNamespace; }
        }

        public override bool RefreshTree
        {
            get { return true; }
        }

        public NewServiceNamespaceAddOn(Browser browser)
            : base(browser)
        {
        }

        protected override void OnInvoke()
        {
            ServiceNamespace.Instance.Clear();
        }
    }
}
