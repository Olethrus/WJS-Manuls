﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Linq;
    using AccessControl.Management;
    using ManagementAddOns.Helpers;
    using AcmBrowser;
    using AcmBrowser.Model;
    using System.Windows;

    public class SaveToCloudAddOn : AddOn
    {
        private delegate void Save();

        public override string Title
        {
            get { return "Save to Cloud"; }
        }

        public override Icon Icon
        {
            get { return ManagementAddOns.Properties.Resources.SaveToCloud; }
        }

        public override bool RefreshTree
        {
            get { return false; }
        }

        public SaveToCloudAddOn(Browser browser)
            : base(browser)
        {
        }

        public override void Invoke()
        {
            try
            {
                OnBeginInvoke();
                OnInvoke();
            }
            catch (Exception e)
            {
                HandleException(e);
            }
        }

        protected override void OnInvoke()
        {
            Save SaveToCloud = Sync;
            SaveToCloud.BeginInvoke(OnEndSave, SaveToCloud);
        }

        public void OnEndSave(IAsyncResult result)
        {
            Save SaveToCloud = (Save)result.AsyncState;

            try
            {
                SaveToCloud.EndInvoke(result);
                MessageBox.Show("The saving process has completed successfully.", "Success", MessageBoxButton.OK);
                OnEndInvoke();
            }
            catch (Exception e)
            {
                HandleException(e);
            }
        }

        public void Sync()
        {
            Validate();
            IssuerCollection issuers = new IssuerCollection();
            TokenPolicyCollection tokenPolicies = new TokenPolicyCollection();
            double totalSavesToDo = ServiceNamespace.Instance.Issuers.Count +
                                    ServiceNamespace.Instance.Scopes.Count +
                                    ServiceNamespace.Instance.TokenPolicies.Count +
                                    ServiceNamespace.Instance.Scopes.Sum((scope) => scope.Rules.Count);
            double totalSavesDone = 0;
            ManagementClient client = new ManagementClient(ParentBrowser.Namespace, ParentBrowser.ManagementKey);

            ProgressUpdate(0.1);
            StatusUpdate("Saving...");
            foreach (IssuerXml issuerXml in ServiceNamespace.Instance.Issuers)
            {
                Issuer issuer = issuerXml.ToIssuer();
                issuer.Id = client.Create(issuer);
                issuers.Add(issuer);
                totalSavesDone++;
                ProgressUpdate(totalSavesDone / totalSavesToDo);
            }

            if (!ParentBrowser.IsServiceBusServiceNamespace())
            {
                foreach (TokenPolicyXml tokenPolicyXml in ServiceNamespace.Instance.TokenPolicies)
                {
                    TokenPolicy tokenPolicy = tokenPolicyXml.ToTokenPolicy();
                    tokenPolicy.Id = client.Create(tokenPolicy);
                    tokenPolicies.Add(tokenPolicy);
                    totalSavesDone++;
                    ProgressUpdate(totalSavesDone / totalSavesToDo);
                }
            }
            else
            {
                // we can't create any token policies in a Service Bus namespace, so we just enumerate what is there
                tokenPolicies = client.EnumerateAll();
            }

            foreach (ScopeXml scopeXml in ServiceNamespace.Instance.Scopes)
            {
                Scope scope = scopeXml.ToScope();
                scope.TokenPolicyId = tokenPolicies.ResolveTokenPolicyHandle(scopeXml.TokenPolicyHandle);
                scope.Id = client.Create(scope);
                totalSavesDone++;
                ProgressUpdate(totalSavesDone / totalSavesToDo);

                foreach (RuleXml ruleXml in scopeXml.Rules)
                {
                    Rule rule = ruleXml.ToRule();
                    rule.RuleSetId = scope.Id;
                    rule.InputClaim.IssuerId = issuers.ResolveIssuerHandle(ruleXml.InputClaimIssuerHandle);
                    rule.Id = client.Create(rule);
                    totalSavesDone++;
                    ProgressUpdate(totalSavesDone / totalSavesToDo);
                }
            }

            ProgressUpdate(1);
            StatusUpdate("Ready");
        }

        private void Validate()
        {
            AssertDistinct(ServiceNamespace.Instance.Issuers);
            AssertDistinct(ServiceNamespace.Instance.Scopes);
            AssertDistinct(ServiceNamespace.Instance.TokenPolicies);

            if (ParentBrowser.IsServiceBusServiceNamespace() &&
                ServiceNamespace.Instance.TokenPolicies.Count > 1)
            {
                throw new InvalidOperationException("You may not create, update or delete any token policies in the Service Bus namespace.");
            }
        }

        private static void AssertDistinct<TResourceXml>(List<TResourceXml> resources) where TResourceXml : ResourceXml
        {
            int numResources = resources.Count();
            int numDistinctResources = resources.Distinct(new HandleEqualityComparer<TResourceXml>()).Count();

            if (numResources != numDistinctResources)
            {
                throw new InvalidOperationException("Each resource must have a unique name.");
            }
        }

        private class HandleEqualityComparer<TResourceXml> : IEqualityComparer<TResourceXml> where TResourceXml : ResourceXml
        {
            public bool Equals(TResourceXml x, TResourceXml y)
            {
                bool areEqual = false;

                if (x == null && y == null)
                {
                    areEqual = true;
                }
                else if (x != null && y != null)
                {
                    areEqual = (x.Handle == y.Handle);
                }

                return areEqual;
            }

            public int GetHashCode(TResourceXml obj)
            {
                return obj.Handle.GetHashCode();
            }
        }
    }
}
