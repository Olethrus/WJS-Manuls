﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace ManagementAddOns
{
    using System.Drawing;
    using AcmBrowser;
    using AcmBrowser.Model;
    using Microsoft.Win32;

    public class SaveToDiskAddOn : AddOn
    {
        public override string Title
        {
            get { return "Save"; }
        }

        public override Icon Icon
        {
            get { return ManagementAddOns.Properties.Resources.SaveToDisk; }
        }

        public override bool RefreshTree
        {
            get { return false; }
        }

        public SaveToDiskAddOn(Browser browser)
            : base(browser)
        {
        }

        protected override void OnInvoke()
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.DefaultExt = ".xml";
            dialog.Filter = "XML Documents (.xml)|*.xml";
            bool? result = dialog.ShowDialog();
            if (result == true)
            {
                ServiceNamespace.SaveServiceNamespace(dialog.FileName);
            }
        }
    }
}
