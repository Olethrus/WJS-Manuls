﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;

    public static class AddOnManager
    {
        private static Dictionary<string, AddOn> AddOns { get; set; }

        static AddOnManager()
        {
            AddOns = new Dictionary<string, AddOn>();
        }

        public static Dictionary<string, AddOn> LoadAddOns(Browser browser, string addonPath)
        {
            // Create a directory info object for the path
            DirectoryInfo dInfo = new DirectoryInfo(addonPath);
            if (!dInfo.Exists)
                return AddOns;

            FileInfo[] fInfos = dInfo.GetFiles();

            // enumerate the files trying to create an addon for each one
            foreach (FileInfo fInfo in fInfos)
            {
                try
                {
                    Assembly loadedAssembly = Assembly.LoadFile(fInfo.FullName);

                    // Get all the types, and try to construct an addon from each one
                    Type[] types = loadedAssembly.GetExportedTypes();

                    foreach (Type t in types)
                    {
                        if (t.BaseType == typeof(AddOn))
                        {
                            AddOn addOn = (AddOn)loadedAssembly.CreateInstance(
                                t.FullName, false, BindingFlags.ExactBinding, null, new Object[] { browser }, null, null);
                            if (addOn != null)
                            {
                                AddOns.Add(addOn.Title, addOn);
                            }
                        }
                    }
                }
                catch (FileLoadException flex)
                {
                    // File Load Exception
                    // Swallow the exception and continue
                    Console.WriteLine(flex.Message);
                }
                catch (BadImageFormatException bifex)
                {
                    // bad image file exception
                    // Swallow the exception and continue
                    Console.WriteLine(bifex.Message);
                }
            }

            return AddOns;
        }

        public static AddOn GetAddon(string name)
        {
            AddOn addOn;

            if (AddOns.TryGetValue(name, out addOn))
                return addOn;

            return null;
        }

        public static void Invoke(string name)
        {
            AddOn addOn = GetAddon(name);
            if (addOn != null)
                addOn.Invoke();
        }
    }
}
