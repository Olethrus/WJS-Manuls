﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser
{
    using System;
    using System.Drawing;
    using System.IO;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Interop;
    using System.Windows.Media.Imaging;
    using AcmBrowser.Model;
    using AcmBrowser.UI;

    public static class UIHelper
    {
        public static System.Windows.Controls.Image ToImage(this Icon icon)
        {
            BitmapSource bitmapSourceInstance = Imaging.CreateBitmapSourceFromHIcon(icon.Handle, Int32Rect.Empty, BitmapSizeOptions.FromEmptyOptions());
            System.Windows.Controls.Image image = new System.Windows.Controls.Image();
            image.Source = bitmapSourceInstance;
            image.MaxHeight = 32;
            image.MinHeight = 32;
            return image;
        }

        public static System.Windows.Media.ImageSource ToWindowIcon(this Icon icon)
        {
            MemoryStream memStream = new MemoryStream();
            icon.Save(memStream);
            memStream.Seek(0, SeekOrigin.Begin);
            return BitmapFrame.Create(memStream);
        }

        public static UserControl GetResourcePanel(this ResourceXml resource)
        {
            UserControl control = null;

            Type resourceType = resource.GetType();
            if (resourceType == typeof(IssuerXml))
            {
                control = new IssuerPanel((IssuerXml)resource);
            }
            else if (resourceType == typeof(ScopeXml))
            {
                control = new ScopePanel((ScopeXml)resource);
            }
            else if (resourceType == typeof(RuleXml))
            {
                control = new RulePanel((RuleXml)resource);
            }
            else if (resourceType == typeof(TokenPolicyXml))
            {
                control = new TokenPolicyPanel((TokenPolicyXml)resource);
            }

            return control;
        }
    }
}
