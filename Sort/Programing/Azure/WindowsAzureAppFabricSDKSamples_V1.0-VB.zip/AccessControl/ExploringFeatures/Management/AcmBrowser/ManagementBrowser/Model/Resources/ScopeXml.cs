﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.Model
{
    using System.Collections.Generic;
    using System.Xml.Serialization;

    public class ScopeXml : ResourceXml
    {
        public string AppliesTo { get; set; }
        public string TokenPolicyHandle { get; set; }

        [XmlArray(ElementName = "Rules")]
        [XmlArrayItem(ElementName = "Rule")]
        public List<RuleXml> Rules { get; set; }

        internal override string ResourceType
        {
            get { return "Scope"; }
        }

        public ScopeXml()
        {
            this.Rules = new List<RuleXml>();
        }
    }
}
