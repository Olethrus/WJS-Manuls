﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.Model
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Xml;
    using System.Xml.Serialization;

    [XmlRoot(Namespace = "")]
    public class ServiceNamespace
    {
        [XmlArray(ElementName = "Issuers")]
        [XmlArrayItem(ElementName = "Issuer")]
        public List<IssuerXml> Issuers; 

        [XmlArray(ElementName = "Scopes")]
        [XmlArrayItem(ElementName = "Scope")]
        public List<ScopeXml> Scopes; 
        
        [XmlArray(ElementName = "TokenPolicies")]
        [XmlArrayItem(ElementName = "TokenPolicy")]
        public List<TokenPolicyXml> TokenPolicies;

        private static ServiceNamespace instance = null;

        private ServiceNamespace()
        {
            Clear();
        }

        public void Clear()
        {
            Issuers = new List<IssuerXml>();
            Scopes = new List<ScopeXml>();
            TokenPolicies = new List<TokenPolicyXml>();
        }

        public static ServiceNamespace Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ServiceNamespace();
                }
                return instance;
            }
        }

        public static void LoadServiceNamespace(string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ServiceNamespace));
            using (FileStream file = new FileStream(fileName, FileMode.Open))
            {
                instance = (ServiceNamespace)serializer.Deserialize(file);
            }
        }

        public static void SaveServiceNamespace(string fileName)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(ServiceNamespace));
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "  ";
            settings.OmitXmlDeclaration = true;

            using (XmlWriter writer = XmlWriter.Create(fileName, settings))
            {
                serializer.Serialize(writer, instance);
            }
        }
    }
}
