﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System.Windows.Controls;
    using AcmBrowser.Model;

    /// <summary>
    /// Interaction logic for IssuerPanel.xaml
    /// </summary>
    public partial class IssuerPanel : UserControl
    {
        private IssuerXml issuer;
        private UserControl lastPanel;

        public IssuerPanel(IssuerXml issuer)
        {
            InitializeComponent();
            this.form.DataContext = issuer;
            this.issuer = issuer;
        }

        private void AlgorithmChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem selectedItem = (ComboBoxItem)this.algorithm.SelectedItem;
            string algorithm = selectedItem.Content.ToString();

            UserControl panel;
            switch (algorithm)
            {
                case "Symmetric256BitKey":
                    panel = new SymmetricKeyIssuerPanel(this.issuer);
                    break;
                case "X509":
                    panel = new X509IssuerPanel(this.issuer);
                    break;
                case "FedMetadata":
                    panel = new FedMetadataIssuerPanel(this.issuer);
                    break;
                default:
                    panel = null;
                    break;
            }
            this.form.Children.Remove(this.lastPanel);
            Grid.SetColumnSpan(panel, 2);
            Grid.SetRow(panel, 1);
            this.form.Children.Add(panel);
            this.lastPanel = panel;
        }
    }
}
