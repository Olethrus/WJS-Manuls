﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System.Collections.Generic;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using AcmBrowser.Model;

    /// <summary>
    /// Interaction logic for ResourcePanel.xaml
    /// </summary>
    public partial class ResourceDialog : Window
    {
        private List<ResourceXml> resources;
        private ResourceXml resource;

        public ResourceDialog(List<ResourceXml> resources, ResourceXml resource)
        {
            InitializeComponent();
            this.resources = resources;
            this.resource = resource;
            this.DataContext = resource;
            this.Title = string.Format("Create New {0}", resource.ResourceType);
            UserControl resourcePanel = resource.GetResourcePanel();
            DockPanel.SetDock(resourcePanel, Dock.Top);
            this.Frame.Children.Add(resourcePanel);
            this.Loaded += new RoutedEventHandler(ResourceDialogLoaded);
        }

        private void OkClicked(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(resource.Handle))
            {
                MessageBox.Show("Please specify a Display Name for the resource and try again.", 
                                "Missing Display Name", 
                                MessageBoxButton.OK, 
                                MessageBoxImage.Warning);
            }
            else if (resources.Find((r) => r.Handle == resource.Handle) == null)
            {
                DialogResult = true;
            }
            else
            {
                MessageBox.Show("There is already a resource with this Display Name." +
                                "\nPlease change the Nname and try again.", 
                                "Duplicate Display Name", 
                                MessageBoxButton.OK, 
                                MessageBoxImage.Warning);
            }
        }

        private void ResourceDialogLoaded(object sender, RoutedEventArgs e)
        {
            Keyboard.Focus(this.handleBox);
        }
    }
}
