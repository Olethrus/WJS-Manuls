﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using AccessControl.Management;
    using AcmBrowser.Model;

    /// <summary>
    /// Interaction logic for RulePanel.xaml
    /// </summary>
    public partial class RulePanel : UserControl
    {
        public RulePanel(RuleXml rule)
        {
            InitializeComponent();
            this.form.DataContext = rule;

            ComboBoxItem acsIssuerItem = new ComboBoxItem();
            acsIssuerItem.Content = Constants.ServiceNamespaceIssuer;
            this.issuersBox.Items.Add(acsIssuerItem);
            foreach (IssuerXml issuerXml in ServiceNamespace.Instance.Issuers)
            {
                ComboBoxItem comboBoxItem = new ComboBoxItem();
                comboBoxItem.Content = issuerXml.Handle;
                this.issuersBox.Items.Add(comboBoxItem);
            }
            this.issuersBox.SelectionChanged += new SelectionChangedEventHandler(issuersBoxSelectionChanged);

            UpdateInputClaimTypes();
            UpdateOutputClaimTypes();
        }

        private static IEnumerable<string> GetClaimTypes(string issuerHandle)
        {
            List<string> claimTypes = new List<string>();

            foreach (ScopeXml scope in ServiceNamespace.Instance.Scopes)
            {
                foreach (RuleXml rule in scope.Rules)
                {
                    if (issuerHandle == rule.InputClaimIssuerHandle)
                    {
                        claimTypes.Add(rule.InputClaimType);
                    }

                    if (issuerHandle == Constants.ServiceNamespaceIssuer)
                    {
                        claimTypes.Add(rule.OutputClaimType);
                    }
                }
            }

            return claimTypes.Distinct();
        }

        private void issuersBoxSelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateInputClaimTypes();
        }

        private void UpdateInputClaimTypes()
        {
            ComboBoxItem selectedItem = (ComboBoxItem)this.issuersBox.SelectedValue;
            // selectedItem is null if the customer has not selected a value
            if (selectedItem != null)
            {
                string inputIssuerHandle = (string)selectedItem.Content;
                this.inTypesBox.Items.Clear();
                foreach (string claimType in GetClaimTypes(inputIssuerHandle))
                {
                    ComboBoxItem claimTypeItem = new ComboBoxItem();
                    claimTypeItem.Content = claimType;
                    this.inTypesBox.Items.Add(claimTypeItem);
                }
            }
        }

        private void UpdateOutputClaimTypes()
        {
            this.outTypesBox.Items.Clear();
            foreach (string claimType in GetClaimTypes(Constants.ServiceNamespaceIssuer))
            {
                ComboBoxItem claimTypeItem = new ComboBoxItem();
                claimTypeItem.Content = claimType;
                this.outTypesBox.Items.Add(claimTypeItem);
            }
        }

        private void RuleTypeChanged(object sender, SelectionChangedEventArgs e)
        {
            ComboBoxItem selectedItem = (ComboBoxItem)this.ruleTypeBox.SelectedItem;
            string ruleType = selectedItem.Content.ToString();

            switch (ruleType)
            {
                case "Simple":
                    this.inValue.IsEnabled = true;
                    this.outValue.IsEnabled = true;
                    break;
                case "PassThrough":
                    this.inValue.Text = string.Empty;
                    this.inValue.IsEnabled = false;
                    this.outValue.Text = string.Empty;
                    this.outValue.IsEnabled = false;
                    break;
            }
        }
    }
}
