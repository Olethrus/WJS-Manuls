﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System.Windows.Controls;
    using AcmBrowser.Model;

    /// <summary>
    /// Interaction logic for ScopePanel.xaml
    /// </summary>
    public partial class ScopePanel : UserControl
    {
        public ScopePanel(ScopeXml scope)
        {
            InitializeComponent();
            this.form.DataContext = scope;

            foreach (TokenPolicyXml tokenPolicyXml in ServiceNamespace.Instance.TokenPolicies)
            {
                ComboBoxItem comboBoxItem = new ComboBoxItem();
                comboBoxItem.Content = tokenPolicyXml.Handle;
                this.tokenPolicyBox.Items.Add(comboBoxItem);
            }
        }
    }
}
