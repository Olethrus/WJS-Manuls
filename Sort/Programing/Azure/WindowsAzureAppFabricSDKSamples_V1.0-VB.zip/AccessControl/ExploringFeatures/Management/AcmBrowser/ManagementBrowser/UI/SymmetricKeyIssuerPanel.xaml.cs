﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System.Windows;
    using System.Windows.Controls;
    using AccessControl.Management;
    using AcmBrowser.Model;

    /// <summary>
    /// Interaction logic for SymmetricKeyIssuer.xaml
    /// </summary>
    public partial class SymmetricKeyIssuerPanel : UserControl
    {

        public SymmetricKeyIssuerPanel(IssuerXml issuer)
        {
            InitializeComponent();
            this.DataContext = issuer;
            issuer.FedMetadataUri = null;
        }

        private void GenerateCurrentKey(object sender, RoutedEventArgs e)
        {
            this.currentKey.Text = Utilities.GenerateKey();
        }

        private void GeneratePreviousKey(object sender, RoutedEventArgs e)
        {
            this.previousKey.Text = Utilities.GenerateKey();
        }
    }
}
