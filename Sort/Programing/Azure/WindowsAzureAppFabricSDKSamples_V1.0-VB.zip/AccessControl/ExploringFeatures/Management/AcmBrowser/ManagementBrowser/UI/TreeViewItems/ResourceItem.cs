﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System.Windows;
    using System.Windows.Controls;
    using AcmBrowser.Model;

    public class ResourceItem : TreeViewItem
    {
        public ResourceXml Resource { get; private set; }

        public delegate void DeleteClickedHandler(ResourceItem sourceNode);
        public DeleteClickedHandler DeleteClicked { get; set; }

        public ResourceItem(ResourceXml resource)
        {
            this.Resource = resource;
            this.Header = resource.Handle;
            this.FontWeight = FontWeights.Normal;

            MenuItem menuItem = new MenuItem();
            menuItem.Header = "Delete...";
            menuItem.Click += new RoutedEventHandler(DeleteMenuItemClicked);
            this.ContextMenu = new ContextMenu();
            this.ContextMenu.Items.Add(menuItem);
        }

        private void DeleteMenuItemClicked(object sender, RoutedEventArgs e)
        {
            this.DeleteClicked(this);
        }
    }
}
