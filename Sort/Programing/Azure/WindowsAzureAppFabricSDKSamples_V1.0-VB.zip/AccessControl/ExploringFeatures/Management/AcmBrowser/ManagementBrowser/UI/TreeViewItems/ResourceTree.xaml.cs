﻿//---------------------------------------------------------------------------------
// Microsoft (R)  Windows Azure Platform AppFabric SDK
// Software Development Kit
// 
// Copyright (c) Microsoft Corporation. All rights reserved.  
//
// THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
// EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
// OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
//---------------------------------------------------------------------------------

namespace AcmBrowser.UI
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Documents;
    using AcmBrowser.Model;

    /// <summary>
    /// Interaction logic for ResourceTree.xaml
    /// </summary>
    public partial class ResourceTree : UserControl
    {
        private ResourceNode issuersNode;
        private ResourceNode scopesNode;
        private ResourceNode tokenPoliciesNode;

        public delegate void ResourceSelectedHandler(ResourceXml resource);
        public ResourceSelectedHandler SelectedResourceChanged { get; set; }

        public ResourceTree()
        {
            InitializeComponent();
            this.issuersNode = new ResourceNode("Issuers");
            this.issuersNode.CreateClicked += CreateResourceClicked;
            this.scopesNode = new ResourceNode("Scopes");
            this.scopesNode.CreateClicked += CreateResourceClicked;
            this.tokenPoliciesNode = new ResourceNode("Token Policies");
            this.tokenPoliciesNode.CreateClicked += CreateResourceClicked;
            this.tree.Items.Add(this.issuersNode);
            this.tree.Items.Add(this.scopesNode);
            this.tree.Items.Add(this.tokenPoliciesNode);
            this.tree.SelectedItemChanged += new RoutedPropertyChangedEventHandler<object>(ResourceItemSelected);
        }

        public void LoadServiceNamespace()
        {
            this.issuersNode.Items.Clear();
            foreach (IssuerXml issuer in ServiceNamespace.Instance.Issuers)
            {
                ResourceItem item = new ResourceItem(issuer);
                item.DeleteClicked += DeleteResourceClicked;
                this.issuersNode.Items.Add(item);
            }

            this.scopesNode.Items.Clear();
            foreach (ScopeXml scope in ServiceNamespace.Instance.Scopes)
            {
                ResourceItem scopeItem = new ResourceItem(scope);
                scopeItem.DeleteClicked += DeleteResourceClicked;
                this.scopesNode.Items.Add(scopeItem);

                ResourceNode rulesNode = new ResourceNode("Rules");
                rulesNode.CreateClicked += CreateResourceClicked;
                scopeItem.Items.Add(rulesNode);

                foreach (RuleXml rule in scope.Rules)
                {
                    ResourceItem ruleItem = new ResourceItem(rule);
                    ruleItem.DeleteClicked += DeleteResourceClicked;
                    rulesNode.Items.Add(ruleItem);
                }
            }

            this.tokenPoliciesNode.Items.Clear();
            foreach (TokenPolicyXml tokenPolicy in ServiceNamespace.Instance.TokenPolicies)
            {
                ResourceItem item = new ResourceItem(tokenPolicy);
                item.DeleteClicked += DeleteResourceClicked;
                this.tokenPoliciesNode.Items.Add(item);
            }

            CollapseAll();
        }

        private void CollapseAll()
        {
            Stack<TreeViewItem> nodesToCollapse = new Stack<TreeViewItem>();
            nodesToCollapse.Push(this.issuersNode);
            nodesToCollapse.Push(this.scopesNode);
            nodesToCollapse.Push(this.tokenPoliciesNode);

            while (nodesToCollapse.Count != 0)
            {
                TreeViewItem currentNode = nodesToCollapse.Pop();
                currentNode.IsExpanded = false;
                foreach (TreeViewItem childNode in currentNode.Items)
                {
                    nodesToCollapse.Push(childNode);
                }
            }
        }

        private void CreateResourceClicked(ResourceNode sourceNode)
        {
            bool? result;
    
            if (sourceNode == this.issuersNode)
            {
                IssuerXml issuer = new IssuerXml();
                List<ResourceXml> resources = ServiceNamespace.Instance.Issuers.Cast<ResourceXml>().ToList();
                ResourceDialog dialog = new ResourceDialog(resources, issuer);

                result = dialog.ShowDialog();
                if (result == true)
                {
                    ServiceNamespace.Instance.Issuers.Add(issuer);
                }
            }
            else if (sourceNode == this.scopesNode)
            {
                ScopeXml scope = new ScopeXml();
                List<ResourceXml> resources = ServiceNamespace.Instance.Scopes.Cast<ResourceXml>().ToList();
                ResourceDialog dialog = new ResourceDialog(resources, scope);

                result = dialog.ShowDialog();
                if (result == true)
                {
                    ServiceNamespace.Instance.Scopes.Add(scope);
                }
            }
            else if (sourceNode == this.tokenPoliciesNode)
            {
                TokenPolicyXml tokenPolicy = new TokenPolicyXml();
                List<ResourceXml> resources = ServiceNamespace.Instance.TokenPolicies.Cast<ResourceXml>().ToList();
                ResourceDialog dialog = new ResourceDialog(resources, tokenPolicy);

                result = dialog.ShowDialog();
                if (result == true)
                {
                    ServiceNamespace.Instance.TokenPolicies.Add(tokenPolicy);
                }
            }
            else
            {
                // we're creating a rule, so let's get the parent scope
                ResourceItem scopeItem = sourceNode.Parent as ResourceItem;
                ScopeXml scope = ServiceNamespace.Instance.Scopes.First((scopeXml) => scopeXml.Handle == scopeItem.Resource.Handle);
                RuleXml rule = new RuleXml();

                List<ResourceXml> resources = scope.Rules.Cast<ResourceXml>().ToList();
                ResourceDialog dialog = new ResourceDialog(resources, rule);
                result = dialog.ShowDialog();
                if (result == true)
                {
                    scope.Rules.Add(rule);
                }
            }

            if (result == true)
            {
                LoadServiceNamespace();
            }
        }

        private void DeleteResourceClicked(ResourceItem resourceItem)
        {
            ResourceXml resource = resourceItem.Resource;
            Type resourceType = resource.GetType();

            if (resourceType == typeof(IssuerXml))
            {
                ServiceNamespace.Instance.Issuers.Remove((IssuerXml)resource);
            }
            else if (resourceType == typeof(ScopeXml))
            {
                ServiceNamespace.Instance.Scopes.Remove((ScopeXml)resource);
            }
            else if (resourceType == typeof(TokenPolicyXml))
            {
                ServiceNamespace.Instance.TokenPolicies.Remove((TokenPolicyXml)resource);
            }
            else
            {
                ResourceNode rulesNode = resourceItem.Parent as ResourceNode;
                ResourceItem scopeItem = rulesNode.Parent as ResourceItem;
                ScopeXml scope = scopeItem.Resource as ScopeXml;
                scope.Rules.Remove((RuleXml)resource);
            }

            LoadServiceNamespace();
        }

        private void ResourceItemSelected(object sender, RoutedPropertyChangedEventArgs<object> args)
        {
            ResourceItem item = args.NewValue as ResourceItem;
            if (item != null)
            {
                this.SelectedResourceChanged(item.Resource);
            }
        }
    }
}
