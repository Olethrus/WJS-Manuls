﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System.CodeDom.Compiler
Imports System.ServiceModel
Imports System.ServiceModel.Web

Namespace Microsoft.AccessControl.SDK.SchemaClient

	<ServiceContract(Namespace := "http://schemas.microsoft.com/ws/2009/06/acs/rest", ConfigurationName := "IRestManagementServiceXml")> _
	Public Interface IRestManagementServiceXml
		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/CreateIssuerXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/CreateIssuerXmlResponse"), WebInvoke(Method := "POST", UriTemplate := "issuers", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function CreateIssuerXml(ByVal issuer As Issuer) As Issuer

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/CreateRuleXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/CreateRuleXmlResponse"), WebInvoke(Method := "POST", UriTemplate := "rulesets/{ruleSetId}/rules", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function CreateRuleXml(ByVal ruleSetId As String, ByVal rule As Rule) As Rule

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/CreateScopeXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/CreateScopeXmlResponse"), WebInvoke(Method := "POST", UriTemplate := "scopes", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function CreateScopeXml(ByVal scope As Scope) As Scope

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/CreateTokenPolicyXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/CreateTokenPolicyXmlResponse"), WebInvoke(Method := "POST", UriTemplate := "tokenpolicies", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function CreateTokenPolicyXml(ByVal tokenPolicy As TokenPolicy) As TokenPolicy

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/DeleteIssuerXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/DeleteIssuerXmlResponse"), WebInvoke(Method := "DELETE", UriTemplate := "issuers/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Sub DeleteIssuerXml(ByVal id As String)

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/DeleteRuleXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/DeleteRuleXmlResponse"), WebInvoke(Method := "DELETE", UriTemplate := "rulesets/{ruleSetId}/rules/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Sub DeleteRuleXml(ByVal ruleSetId As String, ByVal id As String)

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/DeleteScopeXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/DeleteScopeXmlResponse"), WebInvoke(Method := "DELETE", UriTemplate := "scopes/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Sub DeleteScopeXml(ByVal id As String)

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/DeleteTokenPolicyXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/DeleteTokenPolicyXmlResponse"), WebInvoke(Method := "DELETE", UriTemplate := "tokenpolicies/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Sub DeleteTokenPolicyXml(ByVal id As String)

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetIssuersXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetIssuersXmlResponse"), WebGet(UriTemplate := "issuers", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetIssuersXml() As Issuers

        <OperationContract(Action:="http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetRulesXml", ReplyAction:="http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetRulesXmlResponse"), WebGet(UriTemplate:="rulesets/{ruleSetId}/rules", RequestFormat:=WebMessageFormat.Xml, ResponseFormat:=WebMessageFormat.Xml)> _
  Function GetRulesXml(ByVal ruleSetId As String) As Rules

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetScopesXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetScopesXmlResponse"), WebGet(UriTemplate := "scopes", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetScopesXml() As Scopes

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetTokenPoliciesXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetTokenPoliciesXmlResponse"), WebGet(UriTemplate := "tokenpolicies", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetTokenPoliciesXml() As TokenPolicies

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetTokenPoliciesWithModeXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetTokenPoliciesWithModeXmlResponse"), WebGet(UriTemplate := "tokenpolicies?mode={mode}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetTokenPoliciesWithModeXml(ByVal mode As String) As TokenPolicies

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetIssuerXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetIssuerXmlResponse"), WebGet(UriTemplate := "issuers/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetIssuerXml(ByVal id As String) As Issuer

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetRuleXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetRuleXmlResponse"), WebGet(UriTemplate := "rulesets/{ruleSetId}/rules/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetRuleXml(ByVal ruleSetId As String, ByVal id As String) As Rule

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetScopeXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetScopeXmlResponse"), WebGet(UriTemplate := "scopes/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetScopeXml(ByVal id As String) As Scope

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetTokenPolicyXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetTokenPolicyXmlResponse"), WebGet(UriTemplate := "tokenpolicies/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetTokenPolicyXml(ByVal id As String) As TokenPolicy

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetTokenPolicyWithModeXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/GetTokenPolicyWithModeXmlResponse"), WebGet(UriTemplate := "tokenpolicies/{id}?mode={mode}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Function GetTokenPolicyWithModeXml(ByVal id As String, ByVal mode As String) As TokenPolicy

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/UpdateIssuerXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/UpdateIssuerXmlResponse"), WebInvoke(Method := "PUT", UriTemplate := "issuers/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Sub UpdateIssuerXml(ByVal id As String, ByVal issuer As Issuer)

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/UpdateScopeXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/UpdateScopeXmlResponse"), WebInvoke(Method := "PUT", UriTemplate := "scopes/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Sub UpdateScopeXml(ByVal id As String, ByVal scope As Scope)

		<OperationContract(Action := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/UpdateTokenPolicyXml", ReplyAction := "http://schemas.microsoft.com/ws/2009/06/acs/rest/IRestManagementServiceXml/UpdateTokenPolicyXmlResponse"), WebInvoke(Method := "PUT", UriTemplate := "tokenpolicies/{id}", RequestFormat := WebMessageFormat.Xml, ResponseFormat := WebMessageFormat.Xml)> _
		Sub UpdateTokenPolicyXml(ByVal id As String, ByVal tokenPolicy As TokenPolicy)
	End Interface
End Namespace

