﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System.IO
Imports System.ServiceModel
Imports System.ServiceModel.Web

Namespace Microsoft.AccessControl.SDK.SchemaClient

    <ServiceContract(Namespace:="http://schemas.microsoft.com/ws/2009/05/acs/WRAP")> _
 Public Interface ITokenService
        <OperationContract(), WebInvoke(Method:="POST", UriTemplate:="")> _
  Function RequestAccessToken(ByVal request As Stream) As Stream
    End Interface
End Namespace
