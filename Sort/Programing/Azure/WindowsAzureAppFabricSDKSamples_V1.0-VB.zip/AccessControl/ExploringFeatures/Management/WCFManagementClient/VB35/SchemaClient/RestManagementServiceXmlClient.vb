﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System.ServiceModel
Imports System.ServiceModel.Description

Namespace Microsoft.AccessControl.SDK.SchemaClient

	Public Interface IRestManagementServiceXmlChannel
		Inherits IRestManagementServiceXml, IClientChannel
	End Interface

	Partial Public Class RestManagementServiceXmlClient
		Inherits ClientBase(Of IRestManagementServiceXml)
		Implements IRestManagementServiceXml

		Public Sub New()
			Me.AddWebHttpBehavior()
		End Sub

		Public Sub New(ByVal endpointConfigurationName As String)
			MyBase.New(endpointConfigurationName)
			Me.AddWebHttpBehavior()
		End Sub

		Public Sub New(ByVal endpointConfigurationName As String, ByVal remoteAddress As String)
			MyBase.New(endpointConfigurationName, remoteAddress)
			Me.AddWebHttpBehavior()
		End Sub

		Public Sub New(ByVal endpointConfigurationName As String, ByVal remoteAddress As System.ServiceModel.EndpointAddress)
			MyBase.New(endpointConfigurationName, remoteAddress)
			Me.AddWebHttpBehavior()
		End Sub

		Public Sub New(ByVal binding As System.ServiceModel.Channels.Binding, ByVal remoteAddress As System.ServiceModel.EndpointAddress)
			MyBase.New(binding, remoteAddress)
			Me.AddWebHttpBehavior()
		End Sub

		Private Sub AddWebHttpBehavior()
			Me.Endpoint.Behaviors.Add(New WebHttpBehavior())
		End Sub

		Public Function CreateIssuerXml(ByVal issuer As Issuer) As Issuer Implements IRestManagementServiceXml.CreateIssuerXml
			Return MyBase.Channel.CreateIssuerXml(issuer)
		End Function

		Public Function CreateRuleXml(ByVal ruleSetId As String, ByVal rule As Rule) As Rule Implements IRestManagementServiceXml.CreateRuleXml
			Return MyBase.Channel.CreateRuleXml(ruleSetId, rule)
		End Function

		Public Function CreateScopeXml(ByVal scope As Scope) As Scope Implements IRestManagementServiceXml.CreateScopeXml
			Return MyBase.Channel.CreateScopeXml(scope)
		End Function

		Public Function CreateTokenPolicyXml(ByVal tokenPolicy As TokenPolicy) As TokenPolicy Implements IRestManagementServiceXml.CreateTokenPolicyXml
			Return MyBase.Channel.CreateTokenPolicyXml(tokenPolicy)
		End Function

		Public Sub DeleteIssuerXml(ByVal id As String) Implements IRestManagementServiceXml.DeleteIssuerXml
			MyBase.Channel.DeleteIssuerXml(id)
		End Sub

		Public Sub DeleteRuleXml(ByVal ruleSetId As String, ByVal id As String) Implements IRestManagementServiceXml.DeleteRuleXml
			MyBase.Channel.DeleteRuleXml(ruleSetId, id)
		End Sub

		Public Sub DeleteScopeXml(ByVal id As String) Implements IRestManagementServiceXml.DeleteScopeXml
			MyBase.Channel.DeleteScopeXml(id)
		End Sub

		Public Sub DeleteTokenPolicyXml(ByVal id As String) Implements IRestManagementServiceXml.DeleteTokenPolicyXml
			MyBase.Channel.DeleteTokenPolicyXml(id)
		End Sub

		Public Function GetIssuersXml() As Issuers Implements IRestManagementServiceXml.GetIssuersXml
			Return MyBase.Channel.GetIssuersXml()
		End Function

		Public Function GetRulesXml(ByVal ruleSetId As String) As Rules Implements IRestManagementServiceXml.GetRulesXml
			Return MyBase.Channel.GetRulesXml(ruleSetId)
		End Function

		Public Function GetScopesXml() As Scopes Implements IRestManagementServiceXml.GetScopesXml
			Return MyBase.Channel.GetScopesXml()
		End Function

		Public Function GetTokenPoliciesXml() As TokenPolicies Implements IRestManagementServiceXml.GetTokenPoliciesXml
			Return MyBase.Channel.GetTokenPoliciesXml()
		End Function

		Public Function GetTokenPoliciesWithModeXml(ByVal mode As String) As TokenPolicies Implements IRestManagementServiceXml.GetTokenPoliciesWithModeXml
			Return MyBase.Channel.GetTokenPoliciesWithModeXml(mode)
		End Function

		Public Function GetIssuerXml(ByVal id As String) As Issuer Implements IRestManagementServiceXml.GetIssuerXml
			Return MyBase.Channel.GetIssuerXml(id)
		End Function

		Public Function GetRuleXml(ByVal ruleSetId As String, ByVal id As String) As Rule Implements IRestManagementServiceXml.GetRuleXml
			Return MyBase.Channel.GetRuleXml(ruleSetId, id)
		End Function

		Public Function GetScopeXml(ByVal id As String) As Scope Implements IRestManagementServiceXml.GetScopeXml
			Return MyBase.Channel.GetScopeXml(id)
		End Function

		Public Function GetTokenPolicyXml(ByVal id As String) As TokenPolicy Implements IRestManagementServiceXml.GetTokenPolicyXml
			Return MyBase.Channel.GetTokenPolicyXml(id)
		End Function

		Public Function GetTokenPolicyWithModeXml(ByVal id As String, ByVal mode As String) As TokenPolicy Implements IRestManagementServiceXml.GetTokenPolicyWithModeXml
			Return MyBase.Channel.GetTokenPolicyWithModeXml(id, mode)
		End Function

		Public Sub UpdateIssuerXml(ByVal id As String, ByVal issuer As Issuer) Implements IRestManagementServiceXml.UpdateIssuerXml
			MyBase.Channel.UpdateIssuerXml(id, issuer)
		End Sub

		Public Sub UpdateScopeXml(ByVal id As String, ByVal scope As Scope) Implements IRestManagementServiceXml.UpdateScopeXml
			MyBase.Channel.UpdateScopeXml(id, scope)
		End Sub

		Public Sub UpdateTokenPolicyXml(ByVal id As String, ByVal tokenPolicy As TokenPolicy) Implements IRestManagementServiceXml.UpdateTokenPolicyXml
			MyBase.Channel.UpdateTokenPolicyXml(id, tokenPolicy)
		End Sub
	End Class
End Namespace