﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Security.Cryptography
Imports System.ServiceModel
Imports System.ServiceModel.Web
Imports System.Text
Imports System.Web
Imports Microsoft.VisualBasic
Imports Microsoft.AccessControl.SDK.SchemaClient

Namespace Microsoft.AccessControl.SDK.ManagmentClientSample

    Friend Class Program
        Private Shared serviceNamespace As String = "updateToServiceNamespace"
        Private Shared managementKey As String = "updateToManagementKey"

        Private Shared acsBaseAddress As String = "accesscontrol.windows.net"

        Private Shared acsMgmtSvcAddress As String = String.Format("https://{0}.{1}/mgmt", serviceNamespace, acsBaseAddress)
        Private Shared acsMgmtSvcStsAddress As String = String.Format("https://{0}-mgmt.{1}/WRAPv0.9/", serviceNamespace, acsBaseAddress)

        Private Shared acsMgmtSvcAppliesToTemplate As String = acsMgmtSvcAddress & "/{0}"

        Shared Sub Main()
            ' create an issuer
            Dim issuer As Issuer = CreateNewIssuer()
            Console.WriteLine("created issuer id={0}", issuer.Id)

            ' create a token policy
            Dim tokenPolicy As TokenPolicy = CreateNewTokenPolicy()
            Console.WriteLine("created token policy id={0}", tokenPolicy.Id)

            ' create a new scope
            ' requires the tokenpolicy id
            Dim scope As Scope = CreateNewScope(tokenPolicy)
            Console.WriteLine("created scope id={0}", scope.Id)

            ' create a new rule
            Dim rule As Rule = CreateNewRule(issuer, scope)
            Console.WriteLine("created rule id={0}", rule.Id)
            Console.WriteLine()

            ' update the issuer key
            issuer.Security.CurrentKey = GetRandom256BitKey()
            UpdateIssuer(issuer)
            Console.WriteLine("updated the issuer key")

            ' update the policy key
            tokenPolicy.SigningKey = GetRandom256BitKey()
            UpdateTokenPolicy(tokenPolicy)
            Console.WriteLine("updated the token policy key")
            Console.WriteLine()

            ' get all the tokenpolicy ids
            Dim policies As TokenPolicies = GetTokenPolicyIds()
            Console.WriteLine("retrieved token policy ids:")

            For Each policy As TokenPolicy In policies
                Console.WriteLine(vbTab & "{0}", policy.Id)
            Next

            Console.WriteLine()

            ' delete the rule
            DeleteRule(scope, rule)
            Console.WriteLine("deleted rule id={0}", rule.Id)

            ' delete the issuer
            DeleteIssuer(issuer.Id)
            Console.WriteLine("deleted issuer id={0}", issuer.Id)

            ' delete the scope
            DeleteScope(scope)
            Console.WriteLine("deleted scope id={0}", scope.Id)

            ' delete the token policy
            DeleteTokenPolicy(tokenPolicy)
            Console.WriteLine("deleted the token policy id={0}", tokenPolicy.Id)

            Console.WriteLine("")
            Console.WriteLine("Press [Enter] to end ...")
            Console.ReadLine()
        End Sub

#Region "Create Operations"

        Private Shared Function CreateNewScope(ByVal tokenPolicy As TokenPolicy) As Scope
            ' get a token to allow scope operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "scopes")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            Dim scope As New Scope() With {.AppliesTo = "http://foobar.com", .TokenPolicyId = tokenPolicy.Id}

            Dim newScope As Scope = Nothing

            ' set the authorization header and create the scope
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                newScope = client.CreateScopeXml(scope)
            End Using

            client.Close()

            Return newScope
        End Function

        Private Shared Function CreateNewIssuer() As Issuer
            ' get a token to allow issuer operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "issuers")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' create a new key for the issuer
            Dim key As String = GetRandom256BitKey()

            ' create an Issuer locally
            Dim issuer As New Issuer() With {.DisplayName = "myIssuer", .IssuerName = "myIssuer", .Security = New SecurityProperty() With {.Algorithm = "Symmetric256BitKey", .CurrentKey = key, .PreviousKey = key}}

            Dim createdIssuer As Issuer = Nothing

            ' set the authorization header and create the issuer
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                createdIssuer = client.CreateIssuerXml(issuer)
            End Using

            client.Close()

            Return createdIssuer
        End Function

        Private Shared Function CreateNewRule(ByVal newIssuer As Issuer, ByVal scope As Scope) As Rule
            ' get a token to allow rule operations
            Dim path As String = String.Format("rulesets/{0}/rules", scope.Id)
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, path)
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' create a rule
            Dim rule As New Rule() With {.DisplayName = "myRule", .InputClaim = New InputClaim() With {.IssuerId = newIssuer.Id, .Type = "Issuer", .Value = newIssuer.IssuerName}, .OutputClaim = New OutputClaim() With {.Type = "action", .Value = "calculate"}, .Type = "Simple"}

            Dim newRule As Rule = Nothing

            ' set the authorization header and create the rule
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                newRule = client.CreateRuleXml(scope.Id, rule)
            End Using

            client.Close()

            Return newRule
        End Function

        Private Shared Function CreateNewTokenPolicy() As TokenPolicy
            ' get a token to allow tokenpolicy operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "tokenpolicies")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' create the token policy locally
            Dim policy As New TokenPolicy() With {.DisplayName = "myTokenPolicy", .SigningKey = GetRandom256BitKey(), .DefaultTokenLifetimeInSeconds = "3600"}

            Dim newPolicy As TokenPolicy = Nothing

            ' set the authorization header and create the token policy
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                newPolicy = client.CreateTokenPolicyXml(policy)
            End Using

            client.Close()

            Return newPolicy
        End Function

#End Region

#Region "ID Get Operation"

        Private Shared Function GetTokenPolicyIds() As TokenPolicies
            ' get a token to allow tokenpolicy operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "tokenpolicies")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            Dim policies As TokenPolicies = Nothing

            ' set the authorization header and get the tokenpolicy ids
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                policies = client.GetTokenPoliciesWithModeXml("NameIdOnly")
            End Using

            Return policies
        End Function

#End Region

#Region "Update Operations"

        Private Shared Sub UpdateTokenPolicy(ByVal tokenPolicy As TokenPolicy)
            ' get a token to allow tokenpolicy operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "tokenpolicies")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' set the authorization header and update the token policy
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                client.UpdateTokenPolicyXml(tokenPolicy.Id, tokenPolicy)
            End Using

            client.Close()
        End Sub

        Private Shared Sub UpdateIssuer(ByVal issuer As Issuer)
            ' get a token to allow issuer operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "issuers")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' set the authorization header and update the issuer
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                client.UpdateIssuerXml(issuer.Id, issuer)
            End Using

            client.Close()
        End Sub

#End Region

#Region "Delete Operations"

        Private Shared Sub DeleteRule(ByVal scope As Scope, ByVal rule As Rule)
            ' get a token to allow rule operations
            Dim path As String = String.Format("rulesets/{0}/rules", scope.Id)
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, path)
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' set the authorization header and delete the rule
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                client.DeleteRuleXml(scope.Id, rule.Id)
            End Using

            client.Close()
        End Sub

        Private Shared Sub DeleteScope(ByVal scope As Scope)
            ' get a token to allow scope operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "scopes")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' set the authorization header and delete the scope
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                client.DeleteScopeXml(scope.Id)
            End Using

            client.Close()
        End Sub

        Private Shared Sub DeleteTokenPolicy(ByVal tokenPolicy As TokenPolicy)
            ' get a token to allow tokenpolicy operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "tokenpolicies")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' set the authorization header and delete the token policy
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                client.DeleteTokenPolicyXml(tokenPolicy.Id)
            End Using

            client.Close()
        End Sub

        Private Shared Sub DeleteIssuer(ByVal issuerId As String)
            ' get a token to allow issuer operations
            Dim appliesTo As String = String.Format(acsMgmtSvcAppliesToTemplate, "issuers")
            Dim issuerToken As String = GetMgmtToken(appliesTo)

            ' create an EndpointAddress that points to the mgmt service
            Dim address As New EndpointAddress(acsMgmtSvcAddress)

            ' create a WCF client proxy
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim client As New RestManagementServiceXmlClient(binding, address)

            ' set the authorization header and delete the issuer
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(client.InnerChannel)
                WebOperationContext.Current.OutgoingRequest.Headers(HttpRequestHeader.Authorization) = String.Format("WRAP access_token=""{0}""", issuerToken)
                client.DeleteIssuerXml(issuerId)
            End Using

            client.Close()
        End Sub

#End Region

#Region "Helper Methods"

        Private Shared Function GetMgmtToken(ByVal appliesTo As String) As String
            ' use the URI for the management STS
            Dim mgmtStsaddress As New Uri(acsMgmtSvcStsAddress)

            Dim acsBinding As New WebHttpBinding(WebHttpSecurityMode.Transport)
            Dim acsChannelFactory As New WebChannelFactory(Of ITokenService)(acsBinding, mgmtStsaddress)
            Dim acsTokenServiceProxy As ITokenService = acsChannelFactory.CreateChannel()

            Dim tokenRequestBody As String = String.Format("wrap_name={0}&wrap_password={1}&wrap_scope={2}", HttpUtility.UrlEncode("owner"), HttpUtility.UrlEncode(managementKey), HttpUtility.UrlEncode(appliesTo))

            Dim tokenRequestBodyInBytes() As Byte = Encoding.UTF8.GetBytes(tokenRequestBody)

            Dim response As String

            Dim token As String = Nothing

            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(TryCast(acsTokenServiceProxy, IContextChannel))
                Using tokenRequest As New MemoryStream(tokenRequestBodyInBytes)
                    WebOperationContext.Current.OutgoingRequest.ContentType = "application/x-www-form-urlencoded"
                    Using tokenResponse As New StreamReader(acsTokenServiceProxy.RequestAccessToken(tokenRequest))
                        response = tokenResponse.ReadLine()
                    End Using
                End Using
            End Using

            CType(acsTokenServiceProxy, IClientChannel).Close()

            token = response.Split("&"c).Single(Function(value) value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase)).Split("="c)(1)

            Return HttpUtility.UrlDecode(token)
        End Function

        Private Shared Function GetRandom256BitKey() As String
            Dim key(31) As Byte
            Dim rng As New RNGCryptoServiceProvider()
            rng.GetBytes(key)
            Return Convert.ToBase64String(key)
        End Function

#End Region
    End Class
End Namespace
