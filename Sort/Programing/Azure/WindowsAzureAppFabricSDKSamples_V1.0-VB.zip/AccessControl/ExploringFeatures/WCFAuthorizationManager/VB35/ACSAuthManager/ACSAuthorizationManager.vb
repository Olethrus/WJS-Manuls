﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Net
Imports System.ServiceModel
Imports System.ServiceModel.Web
Imports Microsoft.VisualBasic

Namespace Microsoft.AccessControl.SDK.WCF

    Public Class ACSAuthorizationManager
        Inherits ServiceAuthorizationManager
        Private validator As TokenValidator
        Private requiredClaimType As String
        Private requiredClaimValue As String

        Public Sub New(ByVal acsHostName As String, ByVal trustedSolution As String, ByVal trustedAudienceValue As String, ByVal trustedSigningKey() As Byte, ByVal requiredClaimType As String, ByVal requiredClaimValue As String)
            Me.validator = New TokenValidator(acsHostName, trustedSolution, trustedAudienceValue, trustedSigningKey)
            Me.requiredClaimType = requiredClaimType
            Me.requiredClaimValue = requiredClaimValue
        End Sub

        Protected Overrides Function CheckAccessCore(ByVal operationContext As OperationContext) As Boolean
            ' get the authorization header
            Dim authorizationHeader As String = WebOperationContext.Current.IncomingRequest.Headers(HttpRequestHeader.Authorization)

            If String.IsNullOrEmpty(authorizationHeader) Then
                Return False
            End If

            ' check that it starts with 'WRAP'
            If Not authorizationHeader.StartsWith("WRAP") Then
                Return False
            End If

            Dim nameValuePair() As String = authorizationHeader.Substring("WRAP ".Length).Split(New [Char]() {"="c}, 2)

            If nameValuePair.Length <> 2 Or _
               nameValuePair(0) <> "access_token" Or _
               nameValuePair(1).StartsWith("""") = False Or _
               nameValuePair(1).EndsWith("""") = False Then
                Return False
            End If

            ' trim the leading and trailing double-quotes
            Dim token As String = nameValuePair(1).Substring(1, nameValuePair(1).Length - 2)

            ' validate the token
            If Not Me.validator.Validate(token) Then
                Return False
            End If

            ' check for an action claim and get the value
            Dim claims As Dictionary(Of String, String) = Me.validator.GetNameValues(token)

            Dim actionClaimValue As String = String.Empty
            If Not claims.TryGetValue(Me.requiredClaimType, actionClaimValue) Then
                Return False
            End If

            ' check for the correct action claim value
            If Not actionClaimValue.Equals(Me.requiredClaimValue) Then
                Return False
            End If

            Return True
        End Function
    End Class
End Namespace