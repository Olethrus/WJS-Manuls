﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Collections.Generic
Imports System.Collections.Specialized
Imports System.Linq
Imports System.Net
Imports System.ServiceModel
Imports System.ServiceModel.Web
Imports System.Text
Imports System.Web
Imports Microsoft.VisualBasic

Namespace Microsoft.AccessControl.SDK.WCF

    Friend Class Client
        Private Shared serviceNamespace As String
        Private Shared issuerKey As String
        Private Shared acsBaseAddress As String = "accesscontrol.windows.net"

        Shared Sub Main(ByVal args() As String)
            Console.WriteLine("Enter your service namespace, then press <ENTER>")
            serviceNamespace = Console.ReadLine()

            Console.WriteLine(vbLf & "Enter your issuer key, then press <ENTER>")
            issuerKey = Console.ReadLine()

            Console.WriteLine(vbLf & "Enter a number to send to the Fibonacci Calculator, then press <ENTER>")
            Dim valueToCalculate As Integer = Convert.ToInt32(Console.ReadLine())

            Dim token As String = GetTokenFromACS()

            Dim response As String = SendMessageToService(token, valueToCalculate)

            Console.WriteLine("the Fibonacci service returned: {0}", response)
            Console.WriteLine("Press <ENTER> to exit")
            Console.ReadLine()
        End Sub

        Private Shared Function SendMessageToService(ByVal token As String, ByVal valueToCalculate As Integer) As String
            Dim fibNumber As Integer

            ' create the binding and address to communicate with the service
            Dim binding As New WebHttpBinding(WebHttpSecurityMode.None)
            Dim address As New Uri("http://localhost/Fibonacci")

            Dim channelFactory As New WebChannelFactory(Of IFibonacci)(binding, address)

            Dim proxy As IFibonacci = channelFactory.CreateChannel()

            ' add the token to the proxy
            Using TempOperationContextScope As OperationContextScope = New OperationContextScope(TryCast(proxy, IContextChannel))
                Dim authHeaderValue As String = String.Format("WRAP access_token=""{0}""", HttpUtility.UrlDecode(token))

                WebOperationContext.Current.OutgoingRequest.Headers.Add("authorization", authHeaderValue)

                ' call the service and get a response
                fibNumber = proxy.Calculate(valueToCalculate)
            End Using

            CType(proxy, IClientChannel).Close()

            channelFactory.Close()

            Return fibNumber.ToString()
        End Function

        Private Shared Function GetTokenFromACS() As String
            ' request a token from ACS
            Dim client As New WebClient()
            client.BaseAddress = String.Format("https://{0}.{1}", serviceNamespace, acsBaseAddress)

            Dim values As New NameValueCollection()
            values.Add("wrap_name", "wcfauthmanager")
            values.Add("wrap_password", issuerKey)
            values.Add("wrap_scope", "http://localhost/Fibonacci/")

            Dim responseBytes() As Byte = client.UploadValues("WRAPv0.9/", "POST", values)

            Dim response As String = Encoding.UTF8.GetString(responseBytes)

            Console.WriteLine(vbLf & "received token from ACS: {0}" & vbLf, response)

            Return response.Split("&"c).Single(Function(value) value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase)).Split("="c)(1)
        End Function
    End Class
End Namespace
