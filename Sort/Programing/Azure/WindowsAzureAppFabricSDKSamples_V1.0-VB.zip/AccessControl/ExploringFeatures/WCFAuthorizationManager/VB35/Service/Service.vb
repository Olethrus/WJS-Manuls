﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Generic
Imports System.ServiceModel
Imports System.ServiceModel.Web
Imports System.Text

Namespace Microsoft.AccessControl.SDK.WCF

	Friend Class Service
		Shared Sub Main(ByVal args() As String)
            Dim serviceNamespace As String = "updateToServiceNamespace"
            Dim trustedTokenPolicyKey As String = "updateToTokenPolicyKey"

            Dim acsBaseAddress As String = "accesscontrol.windows.net"

            Dim trustedAudience As String = "http://localhost/Fibonacci"
            Dim requiredClaimType As String = "action"
            Dim requiredClaimValue As String = "calculate"

            Dim binding As New WebHttpBinding(WebHttpSecurityMode.None)

            Dim address As New Uri("http://localhost/Fibonacci")

            Dim host As New WebServiceHost(GetType(Fibonacci))
            host.AddServiceEndpoint(GetType(IFibonacci), binding, address)

            host.Authorization.ServiceAuthorizationManager = New ACSAuthorizationManager(acsBaseAddress, serviceNamespace, trustedAudience, Convert.FromBase64String(trustedTokenPolicyKey), requiredClaimType, requiredClaimValue)

			host.Open()

			Console.WriteLine("The Fibonacci Service is listening")
                        Console.WriteLine("Press <ENTER> to exit")
			Console.ReadLine()
		End Sub
	End Class
End Namespace
