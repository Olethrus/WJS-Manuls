﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Collections.Specialized
Imports System.IO
Imports System.Linq
Imports System.Net
Imports System.Text
Imports System.Web

Namespace Microsoft.AccessControl.SDK.GettingStarted.Client

	Friend Class Program
        Private Shared serviceNamespace As String
        Private Shared issuerKey As String
        Private Shared acsHostName As String = "accesscontrol.windows.net"

        Shared Sub Main(ByVal args() As String)
            Console.WriteLine("Enter your Service Namespace, then press <ENTER>")
            serviceNamespace = Console.ReadLine()

            Console.WriteLine(vbLf & "Enter your Client issuer key, then press <ENTER>")
            issuerKey = Console.ReadLine()

            Console.WriteLine(vbLf & "Enter a string to reverse, then press <ENTER>")
            Dim valueToReverse As String = Console.ReadLine()

            Dim token As String = GetTokenFromACS()

            Dim serviceResponse As String = SendMessageToService(token, valueToReverse)

            Console.WriteLine("Service responded with: {0}" & vbLf, serviceResponse)

            Console.WriteLine("Press <ENTER> to exit")

            Console.ReadLine()
        End Sub

        Private Shared Function SendMessageToService(ByVal token As String, ByVal valueToReverse As String) As String
            Dim client As New WebClient()
            client.BaseAddress = "http://localhost/ACSGettingStarted/Default.aspx"

            Dim headerValue As String = String.Format("WRAP access_token=""{0}""", HttpUtility.UrlDecode(token))

            client.Headers.Add("Authorization", headerValue)

            Dim values As New NameValueCollection()
            values = New NameValueCollection()
            values.Add("string_to_reverse", valueToReverse)

            Dim serviceResponseBytes() As Byte = client.UploadValues(String.Empty, values)

            Return Encoding.UTF8.GetString(serviceResponseBytes)
        End Function

        Private Shared Function GetTokenFromACS() As String
            ' request a token from ACS
            Dim client As New WebClient()
            client.BaseAddress = String.Format("https://{0}.{1}", serviceNamespace, acsHostName)

            Dim values As New NameValueCollection()
            values.Add("wrap_name", "gettingstarted")
            values.Add("wrap_password", issuerKey)
            values.Add("wrap_scope", "http://localhost/ACSGettingStarted")

            Dim responseBytes() As Byte = client.UploadValues("WRAPv0.9/", "POST", values)

            Dim response As String = Encoding.UTF8.GetString(responseBytes)

            Console.WriteLine(vbLf & "received token from ACS: {0}" & vbLf, response)

            Return response.Split("&"c).Single(Function(value) value.StartsWith("wrap_access_token=", StringComparison.OrdinalIgnoreCase)).Split("="c)(1)
        End Function
	End Class
End Namespace

