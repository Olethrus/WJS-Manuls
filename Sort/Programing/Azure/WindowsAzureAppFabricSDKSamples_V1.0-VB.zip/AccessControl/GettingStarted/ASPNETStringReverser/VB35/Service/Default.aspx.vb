﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Partial Class _Default
    Inherits System.Web.UI.Page

    Dim serviceNamespace As String = "updateToServiceNamespace"
    Dim trustedTokenPolicyKey As String = "updateToTokenPolicyKey"

    Dim acsHostName As String = "accesscontrol.windows.net"

    Dim trustedAudience As String = "http://localhost/ACSGettingStarted"
    Dim requiredClaimType As String = "action"
    Dim requiredClaimValue As String = "reverse"

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' get the authorization header
        Dim headerValue As String = Request.Headers.Get("Authorization")

        ' check that a value is there
        If String.IsNullOrEmpty(headerValue) Then
            Me.ReturnUnauthorized()
            Return
        End If

        ' check that it starts with 'WRAP'
        If Not headerValue.StartsWith("WRAP") Then
            Me.ReturnUnauthorized()
            Return
        End If

        Dim nameValuePair() As String = headerValue.Substring("WRAP ".Length).Split(New [char]() {"="c}, 2)

        If nameValuePair.Length <> 2 Or _
           nameValuePair(0) <> "access_token" Or _
           Not nameValuePair(1).StartsWith(""""c) Or _
           Not nameValuePair(1).EndsWith(""""c) Then
            Me.ReturnUnauthorized()
            Return
        End If

        ' trim off the leading and trailing double-quotes
        Dim token As String = nameValuePair(1).Substring(1, nameValuePair(1).Length - 2)

        ' create a token validator
        Dim validator As New TokenValidator(Me.acsHostName, Me.serviceNamespace, Me.trustedAudience, Me.trustedTokenPolicyKey)

        ' validate the token
        If Not validator.Validate(token) Then
            Me.ReturnUnauthorized()
            Return
        End If

        ' check for an action claim
        Dim claims As Dictionary(Of String, String) = validator.GetNameValues(token)

        Dim actionClaimValue As String = String.Empty
        If Not claims.TryGetValue(Me.requiredClaimType, actionClaimValue) Then
            Me.ReturnUnauthorized()
            Return
        End If

        ' check for the correct action claim value
        If Not actionClaimValue.Equals(Me.requiredClaimValue) Then
            Me.ReturnUnauthorized()
            Return
        End If

        ' reverse the string and return to caller
        Dim stringToReverse As String = Request.Form("string_to_reverse")
        Dim chars() As Char = stringToReverse.ToCharArray()
        Array.Reverse(chars)

        Response.Write(New String(chars))
        Response.End()
    End Sub

    Private Sub ReturnUnauthorized()
        Response.StatusCode = 401
        Response.End()
    End Sub

End Class
