'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
Namespace Microsoft.ServiceBus.Samples

    <ServiceBehavior(Name := "MulticastService", Namespace := "http://samples.microsoft.com/ServiceModel/Relay/")> _
    Friend Class MulticastService
        Implements IMulticastContract
        Private Sub Hello(ByVal nickname As String) Implements IMulticastContract.Hello
            Console.WriteLine("[" & nickname & "] joins")
        End Sub

        Private Sub Chat(ByVal nickname As String, ByVal text As String) Implements IMulticastContract.Chat
            Console.WriteLine("[" & nickname & "] says: " & text)
        End Sub

        Private Sub Bye(ByVal nickname As String) Implements IMulticastContract.Bye
            Console.WriteLine("[" & nickname & "] leaves")
        End Sub

    End Class
End Namespace
