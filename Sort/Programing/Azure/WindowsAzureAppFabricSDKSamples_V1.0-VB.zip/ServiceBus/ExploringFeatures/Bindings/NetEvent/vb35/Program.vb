'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Globalization
Imports System.ServiceModel

Namespace Microsoft.ServiceBus.Samples
    Friend Class Program
        Private Sub New(ByVal args() As String)
            ' set the global relay connectivity mode based on optional command line arguments
            ' -tcp - enforces ConnectivityMode.Tcp
            ' -http - enforces ConnectivityMode.Http
            ' -auto (or no argument) - uses default ConnectivityMode.AutoDetect mode
            ServiceBusEnvironment.SystemConnectivity.Mode = Me.GetConnectivityMode(args)
        End Sub

        Shared Sub Main(ByVal args() As String)
            Dim programInstance As New Program(args)
            programInstance.Run()
        End Sub

        Private Sub Run()
            Console.Write("What do you want to call your chat session? ")
            Dim session As String = Console.ReadLine()
            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()
            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()
            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()
            Console.Write("Your Chat Nickname: ")
            Dim chatNickname As String = Console.ReadLine()

            Dim relayCredentials As New TransportClientEndpointBehavior()
            relayCredentials.CredentialType = TransportClientCredentialType.SharedSecret
            relayCredentials.Credentials.SharedSecret.IssuerName = issuerName
            relayCredentials.Credentials.SharedSecret.IssuerSecret = issuerSecret

            Dim serviceAddress As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, String.Format(CultureInfo.InvariantCulture, "{0}/MulticastService/", session))
            Dim host As New ServiceHost(GetType(MulticastService), serviceAddress)
            host.Description.Endpoints(0).Behaviors.Add(relayCredentials)
            host.Open()

            Dim channelFactory As ChannelFactory(Of IMulticastChannel) = New ChannelFactory(Of IMulticastChannel)("RelayEndpoint", New EndpointAddress(serviceAddress))
            channelFactory.Endpoint.Behaviors.Add(relayCredentials)
            Dim channel As IMulticastChannel = channelFactory.CreateChannel()
            channel.Open()

            Console.WriteLine(Constants.vbLf & "Press [Enter] to exit" & Constants.vbLf)

            channel.Hello(chatNickname)

            Dim input As String = Console.ReadLine()
            Do While input <> String.Empty
                channel.Chat(chatNickname, input)
                input = Console.ReadLine()
            Loop

            channel.Bye(chatNickname)

            channel.Close()
            channelFactory.Close()
            host.Close()
        End Sub

        Private Function GetConnectivityMode(ByVal args() As String) As ConnectivityMode
            For Each arg As String In args
                If arg.Equals("/auto", StringComparison.InvariantCultureIgnoreCase) OrElse arg.Equals("-auto", StringComparison.InvariantCultureIgnoreCase) Then
                    Return ConnectivityMode.AutoDetect
                ElseIf arg.Equals("/tcp", StringComparison.InvariantCultureIgnoreCase) OrElse arg.Equals("-tcp", StringComparison.InvariantCultureIgnoreCase) Then
                    Return ConnectivityMode.Tcp
                ElseIf arg.Equals("/http", StringComparison.InvariantCultureIgnoreCase) OrElse arg.Equals("-http", StringComparison.InvariantCultureIgnoreCase) Then
                    Return ConnectivityMode.Http
                End If
            Next arg
            Return ConnectivityMode.AutoDetect
        End Function

    End Class
End Namespace
