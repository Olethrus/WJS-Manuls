'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
Imports System
Imports System.ServiceModel
Imports System.Text
Imports Microsoft.ServiceBus

Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)

            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()
            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()
            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            Dim relayCredentials As New TransportClientEndpointBehavior()
            relayCredentials.CredentialType = TransportClientCredentialType.SharedSecret
            relayCredentials.Credentials.SharedSecret.IssuerName = issuerName
            relayCredentials.Credentials.SharedSecret.IssuerSecret = issuerSecret

            Dim serviceUri As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "HelloService")
            Dim channelFactory As ChannelFactory(Of IHelloChannel) = New ChannelFactory(Of IHelloChannel)("RelayEndpoint", New EndpointAddress(serviceUri))
            channelFactory.Endpoint.Behaviors.Add(relayCredentials)
            Dim channel As IHelloChannel = channelFactory.CreateChannel()
            channel.Open()

            Dim hybridConnectionStatus As IHybridConnectionStatus = channel.GetProperty(Of IHybridConnectionStatus)()
            AddHandler hybridConnectionStatus.ConnectionStateChanged, AddressOf ConnectionStatusChanged

            Console.WriteLine("Press any key to exit")

            Dim lastTime As DateTime = DateTime.Now
            Dim count As Integer = 0

            Do While Not Console.KeyAvailable
                channel.Hello("Hello")

                count += 1
                If DateTime.Now.Subtract(lastTime) > TimeSpan.FromMilliseconds(250) Then
                    lastTime = DateTime.Now
                    Console.WriteLine("Sent {0} messages...", count)
                    count = 0
                End If
            Loop

            channel.Close()
            channelFactory.Close()
        End Sub

        Shared Sub ConnectionStatusChanged(ByVal sender As Object, ByVal e As HybridConnectionStateChangedArgs)
            Console.WriteLine("Upgraded!")
        End Sub

    End Class
End Namespace
