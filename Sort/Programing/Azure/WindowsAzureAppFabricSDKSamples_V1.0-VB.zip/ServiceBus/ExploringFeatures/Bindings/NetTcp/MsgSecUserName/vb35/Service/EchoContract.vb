'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
Namespace Microsoft.ServiceBus.Samples

    <ServiceContract(Name := "IEchoContract", Namespace := "http://samples.microsoft.com/ServiceModel/Relay/")> _
    Public Interface IEchoContract
        <OperationContract> _
        Function Echo(ByVal text As String) As String
    End Interface

    Public Interface IEchoChannel
    Inherits IEchoContract, IClientChannel
    End Interface
End Namespace
