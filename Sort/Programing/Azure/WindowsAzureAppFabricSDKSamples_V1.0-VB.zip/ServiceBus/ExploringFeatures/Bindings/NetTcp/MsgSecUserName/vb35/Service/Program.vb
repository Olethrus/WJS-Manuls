'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
    Imports System.ServiceModel.Description
    Imports Microsoft.ServiceBus
    Imports Microsoft.ServiceBus.Description
Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.Write("Enter the Service Namespace you want to connect to: ")
            Dim serviceNamespace As String = Console.ReadLine()

            Dim baseAddress As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "EchoService")

            Dim host As New ServiceHost(GetType(EchoService), baseAddress)
            host.Open()

            Console.WriteLine("Service address: " + baseAddress.ToString())
            Console.WriteLine("Press [Enter] to exit")
            Console.ReadLine()

            host.Close()
        End Sub

    End Class
End Namespace