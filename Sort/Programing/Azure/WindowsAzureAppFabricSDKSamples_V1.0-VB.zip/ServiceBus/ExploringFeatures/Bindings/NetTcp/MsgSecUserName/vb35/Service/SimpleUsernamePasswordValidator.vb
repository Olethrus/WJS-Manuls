'------------------------------------------------------------
' Copyright (c) Microsoft Corporation.  All rights reserved.
'------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.IdentityModel.Selectors
    Imports System.IdentityModel.Tokens
Namespace Microsoft.ServiceBus.Samples

    Public Class SimpleUsernamePasswordValidator
        Inherits UserNamePasswordValidator
        Public Overrides Sub Validate(ByVal userName As String, ByVal password As String)
            If Nothing Is userName OrElse Nothing Is password Then
                Throw New ArgumentNullException()
            End If

            If Not(userName = "test1" AndAlso password = "1tset") AndAlso Not(userName = "test2" AndAlso password = "2tset") Then
                Throw New SecurityTokenException("Unknown Username or Password")
            End If
        End Sub
    End Class
End Namespace
