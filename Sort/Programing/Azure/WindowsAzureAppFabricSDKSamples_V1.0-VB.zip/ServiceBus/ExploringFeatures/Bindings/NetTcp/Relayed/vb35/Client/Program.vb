'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
    Imports Microsoft.ServiceBus
Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()
            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()
            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            Dim serviceUri As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "PingService")

            Dim sharedSecretServiceBusCredential As New TransportClientEndpointBehavior()
            sharedSecretServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerName = issuerName
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerSecret = issuerSecret

            Dim channelFactory As ChannelFactory(Of IPingContract) = New ChannelFactory(Of IPingContract)("RelayEndpoint", New EndpointAddress(serviceUri))

            channelFactory.Endpoint.Behaviors.Add(sharedSecretServiceBusCredential)

            Dim channel As IPingContract = channelFactory.CreateChannel()
            Console.WriteLine("Opening Channel.")
            channel.Open()

            For i As Integer = 1 To 25
                Console.WriteLine("Ping: {0}", i)
                channel.Ping(i)
            Next i

            Console.WriteLine("Closing Channel.")
            channel.Close()
            channelFactory.Close()

            Console.WriteLine("Press [Enter] to exit.")
            Console.ReadLine()
        End Sub

        Private Shared Function GetHostName() As String
            Return System.Net.Dns.GetHostEntry(String.Empty).HostName
        End Function
    End Class
End Namespace
