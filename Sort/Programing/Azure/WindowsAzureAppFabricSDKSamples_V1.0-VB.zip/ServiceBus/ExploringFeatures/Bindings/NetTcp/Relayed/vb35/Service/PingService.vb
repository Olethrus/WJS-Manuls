'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
Namespace Microsoft.ServiceBus.Samples

    <ServiceBehavior(Name := "PingService", Namespace := "http://samples.microsoft.com/ServiceModel/Relay/")> _
    Friend Class PingService
        Implements IPingContract
        Public Sub Open() Implements IPingContract.Open
            Console.WriteLine("Session ({0}) Opened.", OperationContext.Current.SessionId)
        End Sub

        Public Sub Ping(ByVal count As Integer) Implements IPingContract.Ping
            Console.WriteLine("Session ({0}) Ping: {1}", OperationContext.Current.SessionId, count)
        End Sub

        Public Sub Close() Implements IPingContract.Close
            Console.WriteLine("Session ({0}) Closed.", OperationContext.Current.SessionId)
        End Sub
    End Class
End Namespace
