'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
    Imports System.ServiceModel.Description
    Imports Microsoft.ServiceBus
Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()
            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()
            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            Dim address As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "PingService")

            Dim sharedSecretServiceBusCredential As New TransportClientEndpointBehavior()
            sharedSecretServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerName = issuerName
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerSecret = issuerSecret

            Dim host As New ServiceHost(GetType(PingService), address)

            For Each endpoint As ServiceEndpoint In host.Description.Endpoints
                endpoint.Behaviors.Add(sharedSecretServiceBusCredential)
            Next endpoint

            host.Open()

            Console.WriteLine("Press [Enter] to exit")
            Console.ReadLine()

            host.Close()
        End Sub
    End Class
End Namespace