'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
    Imports Microsoft.ServiceBus
Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()

            Dim serviceUri As Uri = ServiceBusEnvironment.CreateServiceUri("https", serviceNamespace, "EchoService")

            ' explicitly setting the endpoint to entity to "localhost" to match the sample certificate
            Dim channelFactory As ChannelFactory(Of IEchoChannel) = New ChannelFactory(Of IEchoChannel)("ServiceBusEndpoint", New EndpointAddress(serviceUri, EndpointIdentity.CreateDnsIdentity("localhost")))

            Dim channel As IEchoChannel = channelFactory.CreateChannel()
            channel.Open()


            Console.WriteLine("Enter text to echo (or [Enter] to exit):")
            Dim input As String = Console.ReadLine()
            Do While input <> String.Empty
                Try
                    Console.WriteLine("Server echoed: {0}", channel.Echo(input))
                Catch e As Exception
                    Console.WriteLine("Error: " & e.Message)
                End Try
                input = Console.ReadLine()
            Loop

            channel.Close()
            channelFactory.Close()
        End Sub
    End Class
End Namespace
