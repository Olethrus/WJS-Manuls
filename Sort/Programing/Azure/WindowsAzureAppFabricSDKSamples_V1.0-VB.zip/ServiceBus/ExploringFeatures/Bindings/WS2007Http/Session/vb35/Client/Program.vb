'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
    Imports Microsoft.ServiceBus
Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.Write("Enter the name of the Solution you want to connect to: ")
            Dim serviceUserName As String = Console.ReadLine()

            Dim serviceUri As Uri = ServiceBusEnvironment.CreateServiceUri("https", serviceUserName, "PingService")

            Dim channelFactory As ChannelFactory(Of IPingContract) = New ChannelFactory(Of IPingContract)("ServiceBusEndpoint", New EndpointAddress(serviceUri))

            Dim channel As IPingContract = channelFactory.CreateChannel()
            Console.WriteLine("Opening Channel.")
            channel.Open()

            For i As Integer = 1 To 25
                Console.WriteLine("Ping: {0}", i)
                channel.Ping(i)
            Next i

            Console.WriteLine("Closing Channel.")
            channel.Close()

            channelFactory.Close()

            Console.WriteLine("Press [Enter] to exit")
            Console.ReadLine()
        End Sub
    End Class
End Namespace
