'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Runtime.Serialization
Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Web
Imports System.IO

Namespace Microsoft.ServiceBus.Samples

    <ServiceContract(Name:="ImageContract", Namespace:="http://samples.microsoft.com/ServiceModel/Relay/")> _
    Public Interface IImageContract
        <OperationContract(), WebGet()> _
        Function GetImage() As Stream
    End Interface

    Public Interface IImageChannel
        Inherits IImageContract, IClientChannel
    End Interface
End Namespace