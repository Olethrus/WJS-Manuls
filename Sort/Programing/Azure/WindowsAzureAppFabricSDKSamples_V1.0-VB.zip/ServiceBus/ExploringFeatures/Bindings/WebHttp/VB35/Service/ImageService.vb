'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Collections.Generic
Imports System.Drawing
Imports System.Drawing.Imaging
Imports System.IO
Imports Microsoft.ServiceBus.Web
Imports System.ServiceModel
Imports System.ServiceModel.Channels
Imports System.ServiceModel.Web

Namespace Microsoft.ServiceBus.Samples

    <ServiceBehavior(Name:="ImageService", Namespace:="http://samples.microsoft.com/ServiceModel/Relay/")> _
    Friend Class ImageService
        Implements IImageContract
        Private Const imageFileName As String = "image.jpg"
        Private bitmap As Image

        Public Sub New()
            Me.bitmap = Image.FromFile(imageFileName)
        End Sub

        Public Function GetImage() As Stream Implements IImageContract.GetImage
            Dim stream As New MemoryStream()
            Me.bitmap.Save(stream, ImageFormat.Jpeg)

            stream.Position = 0
            WebOperationContext.Current.OutgoingResponse.ContentType = "image/jpeg"

            Return stream
        End Function
    End Class
End Namespace