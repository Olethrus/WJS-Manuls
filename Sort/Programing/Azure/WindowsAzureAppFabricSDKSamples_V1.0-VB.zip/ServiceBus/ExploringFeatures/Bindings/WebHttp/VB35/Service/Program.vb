'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.ServiceModel
Imports System.ServiceModel.Description
Imports Microsoft.ServiceBus
Imports System.ServiceModel.Web

Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()

            ' Tranport level security is required for all *RelayBindings; hence, using https is required
            Dim address As Uri = ServiceBusEnvironment.CreateServiceUri("https", serviceNamespace, "Image")

            Dim host As New WebServiceHost(GetType(ImageService), address)
            host.Open()

            Console.WriteLine("Copy the following address into a browser to see the image: ")
            Console.WriteLine(address.ToString() & "GetImage")
            Console.WriteLine()
            Console.WriteLine("Press [Enter] to exit")
            Console.ReadLine()

            host.Close()
        End Sub
    End Class
End Namespace