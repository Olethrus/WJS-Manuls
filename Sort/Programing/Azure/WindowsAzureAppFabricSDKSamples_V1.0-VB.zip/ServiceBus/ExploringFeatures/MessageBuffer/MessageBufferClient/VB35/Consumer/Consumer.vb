﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.ServiceModel.Channels
Imports Microsoft.ServiceBus

Namespace Microsoft.ServiceBus.Samples

    Friend Class Consumer
        Private client As MessageBufferClient
        Private policy As MessageBufferPolicy
        Private credential As TransportClientEndpointBehavior
        Private uri As Uri

        Public Sub New()
            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()
            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()
            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            ' create the policy for the message buffer
            Me.policy = New MessageBufferPolicy()
            Me.policy.Authorization = AuthorizationPolicy.Required
            Me.policy.MaxMessageCount = 10
            Me.policy.ExpiresAfter = TimeSpan.FromMinutes(5) ' messages in the message buffer expire after 5 mins
            Me.policy.TransportProtection = TransportProtectionPolicy.AllPaths

            ' create the credentials object for the endpoint
            Me.credential = New TransportClientEndpointBehavior()
            Me.credential.CredentialType = TransportClientCredentialType.SharedSecret
            Me.credential.Credentials.SharedSecret.IssuerName = issuerName
            Me.credential.Credentials.SharedSecret.IssuerSecret = issuerSecret

            ' create the URI for the message buffer
            Me.uri = ServiceBusEnvironment.CreateServiceUri("https", serviceNamespace, "MessageBuffer")
        End Sub

        Public Sub CreateMessageBuffer()
            Console.Write("Press [Enter] to create the message buffer: ")
            Console.ReadLine()

            ' create the client for the message buffer
            Me.client = MessageBufferClient.CreateMessageBuffer(Me.credential, Me.uri, Me.policy)
            Console.WriteLine("Message buffer created at '{0}'.", Me.client.MessageBufferUri)
        End Sub

        Public Sub ProcessMessages()
            Dim retrievedMessage As Message

            ' retrieve the first two message from the message buffer
            Console.Write("Press [Enter] to retrieve the first message in the message buffer: ")
            Console.ReadLine()
            retrievedMessage = Me.client.Retrieve()
            Console.WriteLine("Retrieved message with body '{0}'.", retrievedMessage.GetBody(Of String)())
            retrievedMessage.Close()

            Console.Write("Press [Enter] to retrieve the next message from the message buffer: ")
            Console.ReadLine()
            retrievedMessage = Me.client.Retrieve()
            Console.WriteLine("Retrieved message with body '{0}'.", retrievedMessage.GetBody(Of String)())
            retrievedMessage.Close()

            ' lock and peek at the next message; then delete it
            Console.Write("Press [Enter] to lock, peek, and delete the next message from the message buffer: ")
            Console.ReadLine()
            Dim lockedMessage As Message = Me.client.PeekLock()
            Me.client.DeleteLockedMessage(lockedMessage)
            Console.WriteLine("Message with body '{0}' locked, peeked, and then deleted.", lockedMessage.GetBody(Of String)())
            lockedMessage.Close()
        End Sub

        Public Sub DeleteMessageBuffer()
            Console.Write("Press [Enter] to delete the message buffer: ")
            Console.ReadLine()

            ' delete the message buffer
            Me.client.DeleteMessageBuffer()
            Console.WriteLine("Message buffer at {0} was deleted.", Me.client.MessageBufferUri)

            Console.WriteLine("Press any key to continue . . .")
            Console.ReadKey()
        End Sub
    End Class
End Namespace