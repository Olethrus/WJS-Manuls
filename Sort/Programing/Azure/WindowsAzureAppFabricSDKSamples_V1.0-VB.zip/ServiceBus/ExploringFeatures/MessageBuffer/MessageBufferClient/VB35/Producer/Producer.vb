﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.ServiceModel.Channels
Imports Microsoft.ServiceBus

Namespace Microsoft.ServiceBus.Samples

    Friend Class Producer
        Private client As MessageBufferClient
        Private credential As TransportClientEndpointBehavior
        Private uri As Uri

        Public Sub New()
            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()
            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()
            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            ' create the credentials object for the endpoint
            Me.credential = New TransportClientEndpointBehavior()
            Me.credential.CredentialType = TransportClientCredentialType.SharedSecret
            Me.credential.Credentials.SharedSecret.IssuerName = issuerName
            Me.credential.Credentials.SharedSecret.IssuerSecret = issuerSecret

            ' create the URI for the message buffer
            Me.uri = ServiceBusEnvironment.CreateServiceUri("https", serviceNamespace, "MessageBuffer")
        End Sub

        Public Sub ProduceMessages()
            Console.Write("Press [Enter] to connect to the message buffer: ")
            Console.ReadLine()

            ' create the client for the message buffer
            Me.client = MessageBufferClient.GetMessageBuffer(Me.credential, Me.uri)
            Console.WriteLine("Connected to the message buffer at '{0}'.", Me.client.MessageBufferUri)

            Console.Write("Press [Enter] to send messages to the message buffer: ")
            Console.ReadLine()

            ' send three messages to the message buffer
            For i As Integer = 1 To 3
                Dim message As Message = message.CreateMessage(MessageVersion.Default, String.Empty, String.Format("<<MESSAGE {0}>>", i))
                Me.client.Send(message)
                Console.WriteLine("Sent message with body '<<MESSAGE {0}>>' to the message buffer.", i)
                message.Close()
            Next i

            Console.WriteLine("Press any key to continue . . .")
            Console.ReadKey()
        End Sub
    End Class
End Namespace