'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.ServiceModel
    Imports System.ServiceModel.Description
    Imports System.ServiceModel.Dispatcher
    Imports Microsoft.ServiceBus
Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)

            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()
            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()
            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            ' create the endpoint address in the solution's namespace
            Dim sbAddress As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "Echo/Service")
            Dim httpAddress As Uri = ServiceBusEnvironment.CreateServiceUri("http", serviceNamespace, "Echo/mex")

            ' create the credentials object for the endpoint
            Dim sharedSecretServiceBusCredential As New TransportClientEndpointBehavior()
            sharedSecretServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerName = issuerName
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerSecret = issuerSecret

            ' create the service host reading the configuration
            Dim host As New ServiceHost(GetType(EchoService), sbAddress, httpAddress)

            ' create the ServiceRegistrySettings behavior for the endpoint
            Dim serviceRegistrySettings As New ServiceRegistrySettings(DiscoveryType.Public)

            ' add the Service Bus credentials to all endpoints specified in configuration
            For Each endpoint As ServiceEndpoint In host.Description.Endpoints
                endpoint.Behaviors.Add(serviceRegistrySettings)
                endpoint.Behaviors.Add(sharedSecretServiceBusCredential)
            Next endpoint

            ' open the service
            host.Open()


            For Each channelDispatcherBase As ChannelDispatcherBase In host.ChannelDispatchers
                Dim channelDispatcher As ChannelDispatcher = TryCast(channelDispatcherBase, ChannelDispatcher)
                For Each endpointDispatcher As EndpointDispatcher In channelDispatcher.Endpoints
                    Console.WriteLine("Listening at: {0}", endpointDispatcher.EndpointAddress)
                Next endpointDispatcher
            Next channelDispatcherBase

            Console.WriteLine("Press [Enter] to exit")
            Console.ReadLine()

            host.Close()
        End Sub

    End Class
End Namespace