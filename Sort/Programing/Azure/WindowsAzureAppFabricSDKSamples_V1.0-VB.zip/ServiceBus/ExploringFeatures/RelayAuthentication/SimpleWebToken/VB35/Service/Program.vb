'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports System
Imports System.ServiceModel
Imports Microsoft.ServiceBus
Imports Microsoft.ServiceBus.Description

Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()

            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()

            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            Dim address As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "SimpleWebTokenAuthenticationService")

            Dim behavior As New TransportClientEndpointBehavior()
            behavior.CredentialType = TransportClientCredentialType.SimpleWebToken
            behavior.Credentials.SimpleWebToken.SimpleWebToken = SharedSecretCredential.ComputeSimpleWebTokenString(issuerName, issuerSecret)

            Dim host As New ServiceHost(GetType(EchoService), address)
            host.Description.Endpoints(0).Behaviors.Add(behavior)
            host.Open()

            Console.WriteLine("Service address: " + address.ToString())
            Console.WriteLine("Press [Enter] to exit")
            Console.ReadLine()

            host.Close()

        End Sub

    End Class
End Namespace