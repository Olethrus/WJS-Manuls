'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.Net
Imports System.Text
Imports System.Xml
Imports System.IO
Imports System.ServiceModel.Syndication

Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.Write("Enter the name of the Service Namespace you want to connect to: ")
            Dim serviceNamespace As String = Console.ReadLine()

            ' WebHttpRelayBinding uses transport security by default
            Dim serviceUri As Uri = ServiceBusEnvironment.CreateServiceUri("https", serviceNamespace, "SyndicationService")

            Dim request As HttpWebRequest = CType(WebRequest.Create(serviceUri.ToString()), HttpWebRequest)
            Dim response As HttpWebResponse = CType(request.GetResponse(), HttpWebResponse)

            Dim stream As Stream = response.GetResponseStream()
            Dim reader As XmlReader = XmlReader.Create(stream)
            Dim formatter As New Rss20FeedFormatter()
            formatter.ReadFrom(reader)

            Console.WriteLine(Constants.vbLf & "These are the contents of your feed: ")
            Console.WriteLine(" ")
            Console.WriteLine(formatter.Feed.Title.Text)
            For Each item As SyndicationItem In formatter.Feed.Items
                Console.WriteLine(item.Title.Text & ": " & item.Summary.Text)
            Next item

            Console.WriteLine("Press [Enter] to exit")
            Console.ReadLine()
        End Sub
    End Class
End Namespace