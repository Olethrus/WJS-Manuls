'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports Microsoft.VisualBasic
Imports System
Imports System.ServiceModel
Imports System.ServiceModel.Description
Imports Microsoft.ServiceBus
Imports System.ServiceModel.Web
Imports System.Text

Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)

            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()

            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()

            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            ' WebHttpRelayBinding uses transport security by default
            Dim address As Uri = ServiceBusEnvironment.CreateServiceUri("https", serviceNamespace, "SyndicationService")

            Dim clientBehavior As New TransportClientEndpointBehavior()
            clientBehavior.CredentialType = TransportClientCredentialType.SharedSecret
            clientBehavior.Credentials.SharedSecret.IssuerName = issuerName
            clientBehavior.Credentials.SharedSecret.IssuerSecret = issuerSecret

            Dim host As New WebServiceHost(GetType(SyndicationService), address)
            host.Description.Endpoints(0).Behaviors.Add(clientBehavior)
            host.Open()

            Console.WriteLine("Service address: " & address.ToString())
            Console.WriteLine("Press [Enter] to exit")
            Console.ReadLine()

            host.Close()
        End Sub

    End Class
End Namespace