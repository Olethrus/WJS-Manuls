'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.Runtime.Serialization
    Imports System.ServiceModel
    Imports System.ServiceModel.Channels
    Imports System.ServiceModel.Web
    Imports System.ServiceModel.Syndication
Namespace Microsoft.ServiceBus.Samples

    <ServiceContract(Name := "SyndicationContract", Namespace := "http://samples.microsoft.com/ServiceModel/Relay/")> _
    Public Interface SyndicationContract
        <OperationContract, WebGet(UriTemplate := "/")> _
        Function GetFeed() As Rss20FeedFormatter
    End Interface

    Public Interface SyndicationChannel
    Inherits SyndicationContract, IClientChannel
    End Interface
End Namespace
