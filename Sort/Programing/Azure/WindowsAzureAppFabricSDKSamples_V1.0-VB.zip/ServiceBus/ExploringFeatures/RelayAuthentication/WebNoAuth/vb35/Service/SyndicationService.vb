'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.Collections.Generic
    Imports System.ServiceModel
    Imports System.ServiceModel.Channels
    Imports System.ServiceModel.Syndication
    Imports System.ServiceModel.Web
Namespace Microsoft.ServiceBus.Samples

    <ServiceBehavior(Name := "SyndicationService", Namespace := "http://samples.microsoft.com/ServiceModel/Relay/")> _
    Friend Class SyndicationService
        Implements SyndicationContract
        Public Function GetFeed() As Rss20FeedFormatter Implements SyndicationContract.GetFeed
            Dim list As List(Of SyndicationItem) = New List(Of SyndicationItem)()

            list.Add(New SyndicationItem("Day 1", "Today I woke up and went to work. It was fun.", New Uri("http://ex.azure.com/")))
            list.Add(New SyndicationItem("Day 2", "Today I was sick. I didn't go to work. Instead I stayed home and wrote code all day.", New Uri("http://ex.azure.com/")))
            list.Add(New SyndicationItem("Day 3", "This is my third entry. Using Microsoft .NET Services is pretty cool!", New Uri("http://ex.azure.com/")))

            Dim feed As New SyndicationFeed("Microsoft Windows Azure Platform AppFabric", "Software+Service, what can be better", New Uri("http://ex.azure.com/"), list)

            Return New Rss20FeedFormatter(feed)
        End Function
    End Class
End Namespace
