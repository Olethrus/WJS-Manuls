'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Configuration
Imports System.ServiceModel
Imports System.ServiceModel.Description
Imports Microsoft.ServiceBus
Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.WriteLine("CloudTrace Console")
            Console.WriteLine("Connecting ...")

            'Retrieve Settings from App.Config
            Dim servicePath As String = ConfigurationManager.AppSettings("CloudTraceServicePath")
            Dim serviceNamespace As String = ConfigurationManager.AppSettings("CloudTraceServiceNamespace")
            Dim issuerName As String = ConfigurationManager.AppSettings("CloudTraceIssuerName")
            Dim issuerSecret As String = ConfigurationManager.AppSettings("CloudTraceIssuerSecret")

            'Construct a Service Bus URI
            Dim uri As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, servicePath)

            'Create a Behavior for the Credentials
            Dim sharedSecretServiceBusCredential As New TransportClientEndpointBehavior()
            sharedSecretServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerName = issuerName
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerSecret = issuerSecret

            'Create the Service Host 
            Dim host As New ServiceHost(GetType(TraceService), uri)
            Dim serviceEndPoint As ServiceEndpoint = host.AddServiceEndpoint(GetType(ITraceContract), New NetEventRelayBinding(), String.Empty)
            serviceEndPoint.Behaviors.Add(sharedSecretServiceBusCredential)

            'Open the Host
            host.Open()
            Console.WriteLine("Connected To: " & uri.ToString())
            Console.WriteLine("Hit [Enter] to exit")

            'Wait Until the Enter Key is Pressed and Close the Host
            Console.ReadLine()
            host.Close()
        End Sub
    End Class
End Namespace