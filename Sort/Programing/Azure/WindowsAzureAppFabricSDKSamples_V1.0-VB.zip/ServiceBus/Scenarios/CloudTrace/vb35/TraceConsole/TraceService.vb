'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.ServiceModel
Imports System.Diagnostics
Namespace Microsoft.ServiceBus.Samples

    <ServiceBehavior(Name:="TraceService", Namespace:="http://samples.microsoft.com/ServiceModel/Relay/CloudTrace")> _
    Friend Class TraceService
        Implements ITraceContract

        Public Sub Write(ByVal message As String) Implements ITraceContract.Write
            'Write to the Console
            Console.Write(message)

            'Also write to a local Trace Listener
            Trace.Write(message)
        End Sub

        Public Sub Write(ByVal message As String, ByVal category As String) Implements ITraceContract.Write
            'Write to the Console
            Console.Write(message, category)

            'Also write to a local Trace Listener
            Trace.Write(message, category)
        End Sub

        Public Sub WriteLine(ByVal message As String) Implements ITraceContract.WriteLine
            'Write to the Console
            Console.WriteLine(message)

            'Also write to a local Trace Listener
            Trace.WriteLine(message)
        End Sub

        Public Sub WriteLine(ByVal message As String, ByVal category As String) Implements ITraceContract.WriteLine
            'Write to the Console
            Console.WriteLine(message, category)

            'Also write to a local Trace Listener
            Trace.WriteLine(message, category)
        End Sub

        Public Sub Fail(ByVal message As String) Implements ITraceContract.Fail
            'Write to the Console
            Console.WriteLine(String.Format("Fail: {0}", message))

            'Also write to a local Trace Listener
            Trace.Fail(message)
        End Sub

        Public Sub Fail(ByVal message As String, ByVal detailMessage As String) Implements ITraceContract.Fail
            'Write to the Console
            Console.WriteLine(String.Format("Fail: {0}, {1}", message, detailMessage))

            'Also write to a local Trace Listener
            Trace.Fail(message, detailMessage)
        End Sub

    End Class
End Namespace