'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Configuration
Imports System.Diagnostics
Imports System.ServiceModel
Imports System.ServiceModel.Description
Imports Microsoft.ServiceBus
Imports System.Text
Namespace Microsoft.ServiceBus.Samples

    Public Class CloudTraceListener
        Inherits TraceListener
        Private traceChannelFactory As ChannelFactory(Of ITraceChannel)
        Private traceChannel As ITraceChannel
        Private writeMutex As Object
        Private maxRetries As Integer = 1

        Public Sub New()
            Dim servicePath As String = ConfigurationManager.AppSettings("CloudTraceServicePath")
            Dim serviceNamespace As String = ConfigurationManager.AppSettings("CloudTraceServiceNamespace")
            Dim issuerName As String = ConfigurationManager.AppSettings("CloudTraceIssuerName")
            Dim issuerSecret As String = ConfigurationManager.AppSettings("CloudTraceIssuerSecret")

            Initialize(servicePath, serviceNamespace, issuerName, issuerSecret)
        End Sub

        Public Sub New(ByVal servicePath As String, ByVal serviceNamespace As String, ByVal issuerName As String, ByVal issuerSecret As String)
            Initialize(servicePath, serviceNamespace, issuerName, issuerSecret)
        End Sub

        Private Sub Initialize(ByVal servicePath As String, ByVal serviceNamespace As String, ByVal issuerName As String, ByVal issuerSecret As String)
            Me.writeMutex = New Object()

            'Construct a Service Bus URI
            Dim uri As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, servicePath)

            'Create a Behavior for the Credentials
            Dim sharedSecretServiceBusCredential As New TransportClientEndpointBehavior()
            sharedSecretServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerName = issuerName
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerSecret = issuerSecret

            'Create a Channel Factory
            traceChannelFactory = New ChannelFactory(Of ITraceChannel)(New NetEventRelayBinding(), New EndpointAddress(uri))
            traceChannelFactory.Endpoint.Behaviors.Add(sharedSecretServiceBusCredential)
        End Sub

        Public Overrides ReadOnly Property IsThreadSafe() As Boolean
            Get
                Return True
            End Get
        End Property

        Public Overrides Sub Close()
            Me.traceChannel.Close()
            Me.traceChannelFactory.Close()
        End Sub

        Private Sub LockWrapper(ByVal action As Action)
            SyncLock Me.writeMutex
                Dim retry As Integer = 0
                Do
                    EnsureChannel()
                    Try
                        action.Invoke()
                        Return
                    Catch e1 As CommunicationException
                        retry = retry + 1
                        If retry > maxRetries Then
                            Throw
                        End If
                    End Try
                Loop
            End SyncLock
        End Sub

        Public Overloads Overrides Sub Write(ByVal message As String)
            LockWrapper(Function() AnonymousMethod1(message))
        End Sub

        Private Function AnonymousMethod1(ByVal message As String) As Boolean
            Me.traceChannel.Write(message)
            Return True
        End Function

        Public Overloads Overrides Sub Write(ByVal o As Object)
            LockWrapper(Function() AnonymousMethod2(o))
        End Sub

        Private Function AnonymousMethod2(ByVal o As Object) As Boolean
            Me.traceChannel.Write(o.ToString())
            Return True
        End Function

        Public Overloads Overrides Sub Write(ByVal o As Object, ByVal category As String)
            LockWrapper(Function() AnonymousMethod3(o, category))
        End Sub

        Private Function AnonymousMethod3(ByVal o As Object, ByVal category As String) As Boolean
            Me.traceChannel.Write(o.ToString(), category)
            Return True
        End Function

        Public Overloads Overrides Sub Write(ByVal message As String, ByVal category As String)
            LockWrapper(Function() AnonymousMethod4(message, category))
        End Sub

        Private Function AnonymousMethod4(ByVal message As String, ByVal category As String) As Boolean
            Me.traceChannel.Write(message, category)
            Return True
        End Function

        Public Overloads Overrides Sub WriteLine(ByVal message As String)
            LockWrapper(Function() AnonymousMethod5(message))
        End Sub

        Private Function AnonymousMethod5(ByVal message As String) As Boolean
            Me.traceChannel.WriteLine(message)
            Return True
        End Function

        Public Overloads Overrides Sub WriteLine(ByVal o As Object)
            LockWrapper(Function() AnonymousMethod6(o))
        End Sub

        Private Function AnonymousMethod6(ByVal o As Object) As Boolean
            Me.traceChannel.WriteLine(o.ToString())
            Return True
        End Function

        Public Overloads Overrides Sub WriteLine(ByVal o As Object, ByVal category As String)
            LockWrapper(Function() AnonymousMethod7(o, category))
        End Sub

        Private Function AnonymousMethod7(ByVal o As Object, ByVal category As String) As Boolean
            Me.traceChannel.WriteLine(o.ToString(), category)
            Return True
        End Function

        Public Overloads Overrides Sub WriteLine(ByVal message As String, ByVal category As String)
            LockWrapper(Function() AnonymousMethod8(message, category))
        End Sub

        Private Function AnonymousMethod8(ByVal message As String, ByVal category As String) As Boolean
            Me.traceChannel.WriteLine(message, category)
            Return True
        End Function

        Public Overloads Overrides Sub Fail(ByVal message As String)
            LockWrapper(Function() AnonymousMethod9(message))
        End Sub

        Private Function AnonymousMethod9(ByVal message As String) As Boolean
            Me.traceChannel.Fail(message)
            Return True
        End Function

        Public Overloads Overrides Sub Fail(ByVal message As String, ByVal detailMessage As String)
            LockWrapper(Function() AnonymousMethod10(message, detailMessage))
        End Sub

        Private Function AnonymousMethod10(ByVal message As String, ByVal detailMessage As String) As Boolean
            Me.traceChannel.Fail(message, detailMessage)
            Return True
        End Function

        Private Sub EnsureChannel()
            If Me.traceChannel IsNot Nothing AndAlso Me.traceChannel.State = CommunicationState.Opened Then
                Return
            Else
                If Me.traceChannel IsNot Nothing Then
                    Me.traceChannel.Abort()
                    Me.traceChannel = Nothing
                End If

                Me.traceChannel = Me.traceChannelFactory.CreateChannel()
                Me.traceChannel.Open()
            End If
        End Sub
    End Class
End Namespace