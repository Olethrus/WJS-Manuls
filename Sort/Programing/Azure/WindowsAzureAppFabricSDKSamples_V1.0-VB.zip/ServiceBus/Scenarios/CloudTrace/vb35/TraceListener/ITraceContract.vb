'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System.ServiceModel
Namespace Microsoft.ServiceBus.Samples

    <ServiceContract(Name:="ITraceContract", Namespace:="http://samples.microsoft.com/ServiceModel/Relay/CloudTrace", SessionMode:=SessionMode.Allowed)> _
    Public Interface ITraceContract
        <OperationContract(IsOneWay:=True, Name:="Write1")> _
        Sub Write(ByVal message As String)

        <OperationContract(IsOneWay:=True, Name:="Write2")> _
        Sub Write(ByVal message As String, ByVal category As String)

        <OperationContract(IsOneWay:=True, Name:="WriteLine1")> _
        Sub WriteLine(ByVal message As String)

        <OperationContract(IsOneWay:=True, Name:="WriteLine2")> _
        Sub WriteLine(ByVal message As String, ByVal category As String)

        <OperationContract(IsOneWay:=True, Name:="Fail1")> _
        Sub Fail(ByVal message As String)

        <OperationContract(IsOneWay:=True, Name:="Fail2")> _
        Sub Fail(ByVal message As String, ByVal detailMessage As String)
    End Interface

    Public Interface ITraceChannel
        Inherits ITraceContract, IClientChannel
    End Interface
End Namespace