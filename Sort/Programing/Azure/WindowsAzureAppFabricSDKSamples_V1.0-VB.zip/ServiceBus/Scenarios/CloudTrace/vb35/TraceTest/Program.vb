'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Diagnostics
Imports System.Threading
Namespace Microsoft.ServiceBus.Samples

    Friend Class Program
        Shared Sub Main(ByVal args() As String)
            Console.WriteLine("CloudTrace Sample Application")

            Console.WriteLine("List Active Trace Listeners")
            For Each o As Object In Trace.Listeners
                Console.WriteLine(o.GetType().ToString())
            Next o

            Console.WriteLine()
            Console.WriteLine("Hit Control-C to Exit")

            Do
                Trace.WriteLine("Tracing...")
                Console.WriteLine("Tracing...")
                'Sleeping Thread to prevent the Service Bus messages to be sent in a tight loop
                Thread.Sleep(3000)
            Loop
        End Sub
    End Class
End Namespace