﻿'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
	Imports System
	Imports System.Collections.Generic
	Imports System.Linq
	Imports System.Net
	Imports System.ServiceModel
	Imports System.ServiceModel.Channels
	Imports System.ServiceModel.Syndication
	Imports System.Xml
	Imports System.ServiceModel.Description
Namespace Microsoft.ServiceBus.Samples

	Public Class BalancingChannelFactory(Of T As IChannel)
		Inherits ChannelFactory(Of T)
		Private expirationPeriod As TimeSpan = TimeSpan.FromSeconds(120)
		Private cachedFeeds As New Dictionary(Of Uri, SyndicationFeed)()
		Private cacheMutex As Object = New Object()
		Private random As New Random()

		Public Sub New()
			MyBase.New()
		End Sub

		Public Sub New(ByVal binding As Binding)
			MyBase.New(binding)
		End Sub

		Public Sub New(ByVal endpoint As ServiceEndpoint)
			MyBase.New(endpoint)
		End Sub

		Public Sub New(ByVal endpointConfigurationName As String)
			MyBase.New(endpointConfigurationName)
		End Sub

		Protected Sub New(ByVal channelType As Type)
			MyBase.New(channelType)
		End Sub

		Public Sub New(ByVal binding As Binding, ByVal remoteAddress As EndpointAddress)
			MyBase.New(binding, remoteAddress)
		End Sub

		Public Sub New(ByVal binding As Binding, ByVal remoteAddress As String)
			MyBase.New(binding, remoteAddress)
		End Sub

		Public Sub New(ByVal endpointConfigurationName As String, ByVal remoteAddress As EndpointAddress)
			MyBase.New(endpointConfigurationName, remoteAddress)
		End Sub

		Public Property RegistryExpiration() As TimeSpan
			Get
				Return expirationPeriod
			End Get
			Set(ByVal value As TimeSpan)
				expirationPeriod = value
			End Set
		End Property

		Public Overrides Function CreateChannel(ByVal address As EndpointAddress, ByVal via As Uri) As T
			Return MyBase.CreateChannel(address, GetTargetViaUri(If(via, address.Uri)))
		End Function

		Public Function GetTargetViaUri(ByVal via As Uri) As Uri
			Dim feed As SyndicationFeed = GetRegistryFeed(via)
			Dim items As New List(Of SyndicationItem)(feed.Items)
			If items.Count > 0 Then
				Dim selectedItem As SyndicationItem = items(random.Next(items.Count))
				Dim link As SyndicationLink = selectedItem.Links.SingleOrDefault(Function(l) l.RelationshipType.Equals("alternate", StringComparison.InvariantCultureIgnoreCase))
				If link Is Nothing OrElse link.Uri Is Nothing Then
					Throw New EndpointNotFoundException()
				Else
					' get the URI and map the scheme to the desired scheme
					Dim targetUri As New UriBuilder(link.Uri)
					targetUri.Scheme = via.Scheme
					Return targetUri.Uri
				End If
			Else
				Throw New EndpointNotFoundException()
			End If
		End Function

		Private Function GetRegistryFeed(ByVal via As Uri) As SyndicationFeed
			Dim httpUriBuilder As New UriBuilder(via)
			httpUriBuilder.Scheme = Uri.UriSchemeHttp
			SyncLock Me.cacheMutex
				Dim cachedFeed As SyndicationFeed = Nothing

				Dim now As DateTime = DateTime.UtcNow
				If (Not cachedFeeds.TryGetValue(httpUriBuilder.Uri, cachedFeed)) OrElse cachedFeed.LastUpdatedTime + expirationPeriod > now Then
					Dim getFeedRequest As HttpWebRequest = TryCast(WebRequest.Create(httpUriBuilder.Uri), HttpWebRequest)
                    getFeedRequest.Method = "GET"
                    getFeedRequest.Headers.Add(HttpRequestHeader.CacheControl, "no-cache")
					Using getFeedResponse As HttpWebResponse = TryCast(getFeedRequest.GetResponse(), HttpWebResponse)
						Dim atomFormatter As New Atom10FeedFormatter()
                        atomFormatter.ReadFrom(XmlReader.Create(getFeedResponse.GetResponseStream()))
						cachedFeed = atomFormatter.Feed
						cachedFeed.LastUpdatedTime = now
						cachedFeeds(httpUriBuilder.Uri) = cachedFeed
					End Using
				End If
				Return cachedFeed
			End SyncLock
		End Function
	End Class
End Namespace
