'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
	Imports System
	Imports System.ServiceModel
	Imports Microsoft.ServiceBus
	Imports System.Text
Namespace Microsoft.ServiceBus.Samples

	Friend Class Program
		Shared Sub Main(ByVal args() As String)
			' Determine the system connectivity mode based on the command line
			' arguments: -http, -tcp or -auto  (defaults to auto)
			ServiceBusEnvironment.SystemConnectivity.Mode = GetConnectivityMode(args)

            Console.Write("Your Service Namespace: ")
            Dim serviceNamespace As String = Console.ReadLine()
            Console.Write("Your Issuer Name: ")
            Dim issuerName As String = Console.ReadLine()
            Console.Write("Your Issuer Secret: ")
            Dim issuerSecret As String = Console.ReadLine()

            ' create the service URI based on the service namespace
            Dim serviceUri As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, "EchoService")

			' create the credentials object for the endpoint
			Dim sharedSecretServiceBusCredential As New TransportClientEndpointBehavior()
			sharedSecretServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret
			sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerName = issuerName
			sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerSecret = issuerSecret

			' create the channel factory loading the configuration
			Dim channelFactory As New BalancingChannelFactory(Of IEchoChannel)(New NetTcpRelayBinding(EndToEndSecurityMode.None, RelayClientAuthenticationType.RelayAccessToken), New EndpointAddress(serviceUri))

			' apply the Service Bus credentials
			channelFactory.Endpoint.Behaviors.Add(sharedSecretServiceBusCredential)


			Console.WriteLine("Enter text to echo (or [Enter] to exit):")
			Dim input As String = Console.ReadLine()
			Do While input IsNot String.Empty
				Dim channel As IEchoChannel = channelFactory.CreateChannel()
				channel.Open()

				Try
					' create and open the client channel
					Console.WriteLine("Server echoed: {0}", channel.Echo(input))
					channel.Close()
				Catch e As Exception
					Console.WriteLine("Error: " & e.Message)
					channel.Abort()
				End Try


				input = Console.ReadLine()
			Loop

			channelFactory.Close()
		End Sub

		Private Shared Function GetConnectivityMode(ByVal args() As String) As ConnectivityMode
			For Each arg As String In args
				If arg.Equals("/auto", StringComparison.InvariantCultureIgnoreCase) OrElse arg.Equals("-auto", StringComparison.InvariantCultureIgnoreCase) Then
					Return ConnectivityMode.AutoDetect
				ElseIf arg.Equals("/tcp", StringComparison.InvariantCultureIgnoreCase) OrElse arg.Equals("-tcp", StringComparison.InvariantCultureIgnoreCase) Then
					Return ConnectivityMode.Tcp
				ElseIf arg.Equals("/http", StringComparison.InvariantCultureIgnoreCase) OrElse arg.Equals("-http", StringComparison.InvariantCultureIgnoreCase) Then
					Return ConnectivityMode.Http
				End If
			Next arg
			Return ConnectivityMode.AutoDetect
		End Function
	End Class
End Namespace
