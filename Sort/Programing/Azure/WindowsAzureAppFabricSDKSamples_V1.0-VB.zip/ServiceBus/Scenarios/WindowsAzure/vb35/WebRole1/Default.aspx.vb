﻿Imports Microsoft.VisualBasic
'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------

Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Web
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Configuration
Imports System.ServiceModel
Imports System.ServiceModel.Description
Imports Microsoft.ServiceBus
Namespace Microsoft.ServiceBus.Samples

    Partial Public Class _Default
        Inherits System.Web.UI.Page
        Private servicePath As String
        Private serviceNamespace As String
        Private issuerName As String
        Private issuerSecret As String
        Private serviceAddress As Uri

        Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs)
            'Retrieve Settings from App.Config
            servicePath = ConfigurationManager.AppSettings("ServicePath")
            serviceNamespace = ConfigurationManager.AppSettings("ServiceNamespace")
            issuerName = ConfigurationManager.AppSettings("IssuerName")
            issuerSecret = ConfigurationManager.AppSettings("IssuerSecret")

            'Construct a Service Bus URI
            serviceAddress = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, servicePath)
            serviceAddressLabel.Text = serviceAddress.ToString()
        End Sub

        Protected Sub sendButton_Click(ByVal sender As Object, ByVal e As EventArgs)
            Dim channelFactory As ChannelFactory(Of IEchoChannel) = Nothing
            Dim channel As IEchoChannel = Nothing
            Try
                'Create a Behavior for the Credentials
                Dim sharedSecretServiceBusCredential As New TransportClientEndpointBehavior()
                sharedSecretServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret
                sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerName = issuerName
                sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerSecret = issuerSecret

                'Create a Channel Factory
                channelFactory = New ChannelFactory(Of IEchoChannel)(New NetTcpRelayBinding(), New EndpointAddress(serviceAddress))
                channelFactory.Endpoint.Behaviors.Add(sharedSecretServiceBusCredential)

                LogMessage("Opening channel to: {0}", serviceAddress)
                channel = channelFactory.CreateChannel()
                channel.Open()

                LogMessage("Sending: {0}", echoTextBox.Text)
                Dim echoedText As String = channel.Echo(echoTextBox.Text)
                LogMessage("Received: {0}", echoedText)
                echoTextBox.Text = String.Empty

                LogMessage("Closing channel")
                channel.Close()
                LogMessage("Closing factory")
                channelFactory.Close()
            Catch ex As Exception
                LogMessage("Error sending: {0}<br/>{1}", ex.Message, ex.StackTrace.Replace(Constants.vbLf, "<br/>"))

                ' Close the channel and factory properly
                If channel IsNot Nothing Then
                    CloseCommunicationObject(channel)
                End If
                If channelFactory IsNot Nothing Then
                    CloseCommunicationObject(channelFactory)
                End If
            End Try
        End Sub

        Private Sub LogMessage(ByVal format As String, ByVal ParamArray parameters() As Object)
            msgLabel.Text += DateTime.Now.ToString() & ": " & String.Format(format, parameters) & "<br/>"
        End Sub

        Private Sub CloseCommunicationObject(ByVal communicationObject As ICommunicationObject)
            Dim shouldAbort As Boolean = True
            If communicationObject.State = CommunicationState.Opened Then
                Try
                    communicationObject.Close()
                    shouldAbort = False
                Catch e1 As TimeoutException
                Catch e2 As CommunicationException
                End Try
            End If

            If shouldAbort Then
                communicationObject.Abort()
            End If
        End Sub

    End Class
End Namespace