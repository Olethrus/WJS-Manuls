'---------------------------------------------------------------------------------
' Microsoft (R)  Windows Azure Platform AppFabric SDK
' Software Development Kit
' 
' Copyright (c) Microsoft Corporation. All rights reserved.  
'
' THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND, 
' EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED WARRANTIES 
' OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE. 
'---------------------------------------------------------------------------------


Imports Microsoft.VisualBasic
    Imports System
    Imports System.Collections.Generic
    Imports System.Threading
    Imports System.Linq
    Imports System.Text
Imports Microsoft.WindowsAzure.ServiceRuntime
Imports System.Configuration
    Imports System.ServiceModel
    Imports System.ServiceModel.Description
    Imports Microsoft.ServiceBus
Namespace Microsoft.ServiceBus.Samples

    Public Class WorkerRole
        Inherits RoleEntryPoint
        Private host As ServiceHost

        Public Overrides Sub Run()
            ' Retrieve Settings from App.Config
            Dim servicePath As String = ConfigurationManager.AppSettings("ServicePath")
            Dim serviceNamespace As String = ConfigurationManager.AppSettings("ServiceNamespace")
            Dim issuerName As String = ConfigurationManager.AppSettings("IssuerName")
            Dim issuerSecret As String = ConfigurationManager.AppSettings("IssuerSecret")

            ' Construct a Service Bus URI
            Dim uri As Uri = ServiceBusEnvironment.CreateServiceUri("sb", serviceNamespace, servicePath)

            ' Create a Behavior for the Credentials
            Dim sharedSecretServiceBusCredential As New TransportClientEndpointBehavior()
            sharedSecretServiceBusCredential.CredentialType = TransportClientCredentialType.SharedSecret
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerName = issuerName
            sharedSecretServiceBusCredential.Credentials.SharedSecret.IssuerSecret = issuerSecret

            ' Create the Service Host 
            host = New ServiceHost(GetType(EchoService), uri)
            Dim contractDescription As ContractDescription = contractDescription.GetContract(GetType(IEchoContract), GetType(EchoService))
            Dim serviceEndPoint As New ServiceEndpoint(contractDescription)
            serviceEndPoint.Address = New EndpointAddress(uri)
            serviceEndPoint.Binding = New NetTcpRelayBinding()
            serviceEndPoint.Behaviors.Add(sharedSecretServiceBusCredential)
            host.Description.Endpoints.Add(serviceEndPoint)

            ' Open the Host
            host.Open()

            While (True)
                'Do Nothing
            End While

        End Sub

        Public Overrides Sub OnStop()
            MyBase.OnStop()
            host.Close()
        End Sub

        Public Overrides Function OnStart() As Boolean

            AddHandler RoleEnvironment.Changing, AddressOf RoleEnvironmentChanging

            Return MyBase.OnStart()
        End Function

        Private Sub RoleEnvironmentChanging(ByVal sender As Object, ByVal e As RoleEnvironmentChangingEventArgs)
            If (e.Changes.Any(Function(change) TypeOf change Is RoleEnvironmentConfigurationSettingChange)) Then
                e.Cancel = True
            End If
        End Sub
    End Class
End Namespace
