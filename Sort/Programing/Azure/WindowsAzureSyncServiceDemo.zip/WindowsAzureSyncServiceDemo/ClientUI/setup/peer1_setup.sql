--
-- ========================================================================================================================================================================
--  PEER 1 - Setup
-- ========================================================================================================================================================================
--

CREATE TABLE orders(order_id int NOT NULL primary key, order_date datetime NULL)
go

CREATE TABLE order_details(order_id int NOT NULL, order_details_id int NOT NULL primary key, product nvarchar(100) NULL, quantity int NULL)
go

--
-- ========================================================================================================================================================================
--  Insert Sample Data In Tables
-- ========================================================================================================================================================================
--
insert into orders (order_id, order_date) values(1, GetDate())
insert into orders (order_id, order_date) values(4, GetDate())

insert into order_details (order_id, order_details_id, product, quantity) values(1, 1 , 'DVD', 5)
insert into order_details (order_id, order_details_id, product, quantity) values(1, 4 , 'CD', 10)
insert into order_details (order_id, order_details_id, product, quantity) values(4, 3 , 'Floppy Disk', 15)