﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.IO;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.ServiceRuntime;

namespace AzureSyncServiceCommonUtility
{
    public enum SyncJobStatus
    {
        DoesNotExist,
        Created,
        InQueue,
        WaitingForBatches,
        PreparingBatches,
        ApplyingBatches,
        Complete,
        Failed
    }

    public enum TraceCategory
    {
        Verbose,
        Info,
        Warning,
        Error
    }

    public class CommonUtil
    {
        public const int MaxServiceMemoryCacheSizeInKb = 15000; //15MB.
        public const int TraceTransferIntervalInMinutes = 2;

        private static readonly TraceSwitch traceSwitch;

        static CommonUtil()
        {
            traceSwitch = new TraceSwitch("AzureSyncServiceTrace", "Azure Sync Service trace switch setting");
            string traceLevel = RoleEnvironment.GetConfigurationSettingValue("TraceLevel");

            switch (traceLevel)
            {
                case "Off":
                    traceSwitch.Level = TraceLevel.Off;
                    break;
                case "Error":
                    traceSwitch.Level = TraceLevel.Error;
                    break;
                case "Warning":
                    traceSwitch.Level = TraceLevel.Warning;
                    break;
                case "Info":
                    traceSwitch.Level = TraceLevel.Info;
                    break;
                case "Verbose":
                    traceSwitch.Level = TraceLevel.Verbose;
                    break;
                default:
                    traceSwitch.Level = TraceLevel.Info;
                    break;
            }
        }

        public static CloudBlobContainer GetBlobContainer(string id)
        {
            CloudBlobClient blobClient = GetCloudBlobClient();
            CloudBlobContainer blobContainer = blobClient.GetContainerReference(id);

            try
            {
                blobContainer.FetchAttributes();
            }
            catch (StorageClientException e)
            {
                // If the container does not exist then swallow the exception (there is no way to check if the container does not exist beforehand) 
                if (e.ErrorCode != StorageErrorCode.ResourceNotFound)
                {
                    throw e;
                }

                throw new SyncServiceJobNotFoundException(String.Format("BlobContainer '{0}' was not found in the store.  The job does not exist in the system.", id));
            }

            return blobContainer;
        }

        public static CloudBlobContainer CreateBlobContainer(string id)
        {
            CloudBlobClient blobClient = GetCloudBlobClient();
            CloudBlobContainer blobContainer = blobClient.GetContainerReference(id);
            blobContainer.CreateIfNotExist();

            return blobContainer;
        }

        private static CloudBlobClient GetCloudBlobClient()
        {
            // read account configuration settings
            CloudStorageAccount storageAccount = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            blobClient.RetryPolicy = RetryPolicies.Retry(10, TimeSpan.FromMilliseconds(100));

            return blobClient;
        }

        public static CloudQueue GetJobQueue()
        {
            // read account configuration settings
            CloudStorageAccount storageAccount = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            CloudQueueClient queueClient = storageAccount.CreateCloudQueueClient();
            queueClient.RetryPolicy = RetryPolicies.Retry(10, TimeSpan.FromMilliseconds(100));

            CloudQueue jobQueue = queueClient.GetQueueReference("jobqueue");
            jobQueue.CreateIfNotExist();
            return jobQueue;
        }

        public static void SyncTrace(TraceCategory traceCategory, string format, params object[] args)
        {
            if (DoTrace(traceCategory))
            {
                Trace.WriteLine(string.Format(format, args), traceCategory.ToString());
            }

        }

        private static bool DoTrace(TraceCategory traceCategory)
        {
            bool doTrace;
            switch (traceCategory)
            {
                case TraceCategory.Verbose:
                    doTrace = traceSwitch.TraceVerbose;
                    break;

                case TraceCategory.Info:
                    doTrace = traceSwitch.TraceInfo;
                    break;

                case TraceCategory.Warning:
                    doTrace = traceSwitch.TraceWarning;
                    break;

                case TraceCategory.Error:
                    doTrace = traceSwitch.TraceError;
                    break;

                default:
                    throw new ArgumentException("Unexpected trace category");
            }
            return doTrace;
        }

        // Activation Context API Functions
        [DllImport("Kernel32.dll", SetLastError = true)]
        private extern static IntPtr CreateActCtx(ref ACTCTX actctx);

        // Activation context structure
        private struct ACTCTX
        {
            public int cbSize;
            public uint dwFlags;
            public string lpSource;
            public ushort wProcessorArchitecture;
            public ushort wLangId;
            public string lpAssemblyDirectory;
            public string lpResourceName;
            public string lpApplicationName;
        }

        private const int ACTCTX_FLAG_ASSEMBLY_DIRECTORY_VALID = 0x004;
        private const int ACTCTX_FLAG_SET_PROCESS_DEFAULT = 0x00000010;
        private IntPtr m_hActCtx = (IntPtr)0;
        private const UInt32 ERROR_SXS_PROCESS_DEFAULT_ALREADY_SET = 14011;

        /// <summary>
        /// Explicitly load a manifest and create the process-default activation
        /// context. It takes effect immediately and stays there until the process exits.
        /// </summary>
        public static void CreateActivationContext(string manifestPath)
        {
            string rootFolder = Path.GetDirectoryName(manifestPath);
            UInt32 dwError = 0;

            // Build the activation context information structure
            ACTCTX info = new ACTCTX();
            info.cbSize = Marshal.SizeOf(typeof(ACTCTX));
            info.dwFlags = ACTCTX_FLAG_SET_PROCESS_DEFAULT;
            info.lpSource = manifestPath;

            if (null != rootFolder && "" != rootFolder)
            {
                info.lpAssemblyDirectory = rootFolder;
                info.dwFlags |= ACTCTX_FLAG_ASSEMBLY_DIRECTORY_VALID;
            }

            dwError = 0;

            // Create the activation context
            IntPtr result = CreateActCtx(ref info);

            if (-1 == result.ToInt32())
            {
                dwError = (UInt32)Marshal.GetLastWin32Error();
            }

            if (-1 == result.ToInt32() && ERROR_SXS_PROCESS_DEFAULT_ALREADY_SET != dwError)
            {
                string err = string.Format("Cannot create process-default win32 sxs context, error={0} manifest={1}",
                   dwError, manifestPath);
                ApplicationException ex = new ApplicationException(err);
                throw ex;
            }
        }        
    }

    public class SyncServiceJobNotFoundException : Exception
    {
        public SyncServiceJobNotFoundException(string message)
            : base(message)
        {
        }
    }

    public class SyncServiceNotAuthorizedException : Exception
    {
        public SyncServiceNotAuthorizedException(string message)
            : base(message)
        {
        }
    }
}
