﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using Microsoft.WindowsAzure.Diagnostics;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure;
using Microsoft.Synchronization.Data.SqlServer;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using Microsoft.Synchronization.Data;
using Microsoft.Synchronization;
using AzureSyncServiceCommonUtility;
using System.Data.SqlClient;

namespace SyncServiceWorkerRole
{
    public class SyncServiceWorkerRole : RoleEntryPoint
    {
        private static object _jobCounterGate = new Object();
        private static int _currentJobs = 0;        

        /// <summary>
        /// The Role start up method that performs various set up tasks such as setting up diagnostics.
        /// One task specific to this sync solution is creating an activation context for the native Sync Framework 
        /// dll so that we can run Sync Framework native components in this Azure instance.
        /// </summary>
        /// <returns></returns>
        public override bool OnStart()
        {
            try
            {
                // Set the maximum number of concurrent connections 
                ServicePointManager.DefaultConnectionLimit = 12;

                DiagnosticMonitorConfiguration diagConfig = DiagnosticMonitor.GetDefaultInitialConfiguration();
                diagConfig.Directories.ScheduledTransferPeriod = TimeSpan.FromMinutes(CommonUtil.TraceTransferIntervalInMinutes);
                diagConfig.Logs.ScheduledTransferPeriod = TimeSpan.FromMinutes(CommonUtil.TraceTransferIntervalInMinutes);
                diagConfig.WindowsEventLog.ScheduledTransferPeriod = TimeSpan.FromMinutes(CommonUtil.TraceTransferIntervalInMinutes);
                AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(AppDomain_UnhandledException);
                DiagnosticMonitor.Start("DiagnosticsConnectionString", diagConfig);

                // For information on handling configuration changes
                // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.
                RoleEnvironment.Changing += RoleEnvironmentChanging;                

                // This code sets up a handler to update CloudStorageAccount instances when their corresponding
                // configuration settings change in the service configuration file.
                CloudStorageAccount.SetConfigurationSettingPublisher((configName, configSetter) =>
                {
                    // Provide the configSetter with the initial value
                    configSetter(RoleEnvironment.GetConfigurationSettingValue(configName));

                    RoleEnvironment.Changed += (sender, arg) =>
                    {
                        if (arg.Changes.OfType<RoleEnvironmentConfigurationSettingChange>()
                            .Any((change) => (change.ConfigurationSettingName == configName)))
                        {
                            // The corresponding configuration setting has changed, propagate the value
                            if (!configSetter(RoleEnvironment.GetConfigurationSettingValue(configName)))
                            {
                                // In this case, the change to the storage account credentials in the
                                // service configuration is significant enough that the role needs to be
                                // recycled in order to use the latest settings. (for example, the 
                                // endpoint has changed)
                                RoleEnvironment.RequestRecycle();
                            }
                        }
                    };
                });

                // Create the activation context for the Sync Framework COM dll
                string manifestPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "webapp.manifest");
                CommonUtil.CreateActivationContext(manifestPath);
            }
            catch (Exception e)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "Caught exception during worker role OnStart: {0}", e);
                throw;
            }

            _currentJobs = 0;
            return base.OnStart();
        }

        private void RoleEnvironmentChanging(object sender, RoleEnvironmentChangingEventArgs e)
        {
            // If a configuration setting is changing
            if (e.Changes.Any(change => change is RoleEnvironmentConfigurationSettingChange))
            {
                // Set e.Cancel to true to restart this role instance
                e.Cancel = true;
            }
        }

        private void AppDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // Get Reference to error container.
            CloudBlobContainer container = CommonUtil.CreateBlobContainer("workerroleerrors");
            
            // Retrieve last exception.
            Exception ex = e.ExceptionObject as Exception;

            if (ex != null)
            {
                // Will create a new entry in the container
                // and upload the text representing the 
                // exception.
                container.GetBlobReference(
                   String.Format(
                       "SyncServiceWorkerRole-{0}-{1}",
                       RoleEnvironment.CurrentRoleInstance.Id,
                       DateTime.UtcNow.Ticks)
                    ).UploadText(ex.ToString());
            }
        }

        /// <summary>
        /// The Worker Role run method that continually polls the job queue for sync requests (either upload or download jobs)
        /// </summary>
        public override void Run()
        {
            if (RoleEnvironment.DeploymentId.Contains("deployment"))
            {
                CommonUtil.SyncTrace(TraceCategory.Info, "Running worker role in Dev Fabric.");
            }
            else
            {
                CommonUtil.SyncTrace(TraceCategory.Info, "Running worker role in live environment.");
            }

            CloudQueue jobQueue = CommonUtil.GetJobQueue();

            while (true)
            {
                CloudQueueMessage job = null;
                try
                {                 
                    // Only 5 concurrent syncs per worker role instance
                    if (_currentJobs <= 5)
                    {
                        // Poll the job queue
                        if ((job = jobQueue.GetMessage(TimeSpan.FromMinutes(20))) != null)
                        {
                            CommonUtil.SyncTrace(TraceCategory.Info, "Job:{0} pulled off queue by worker role", job.AsString);

                            CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(job.AsString);
                            Thread workerThread;

                            // Create and start a new thread based on the job type
                            if (blobContainer.Metadata["jobtype"] == "upload")
                            {
                                workerThread = new Thread(new ParameterizedThreadStart(UploadSync));
                            }
                            else
                            {
                                workerThread = new Thread(new ParameterizedThreadStart(DownloadSync));
                            }

                            lock (_jobCounterGate)
                            {
                                _currentJobs++;
                            }

                            workerThread.Start(job);
                        }
                        else
                        {
                            // If there are no jobs, sleep for 100 milliseconds before polling again.
                            // Note:  This simplistic polling algorithm might not be the most appropriate
                            // solution for a production service.  Some kind of backoff algorithm might be
                            // preferable, based on the requirements of the servce.
                            System.Threading.Thread.Sleep(100);
                        }
                    }
                    else
                    {
                        // The worker role is at max capacity (5 jobs in progress) so sleep longer before polling again
                        System.Threading.Thread.Sleep(1000);
                    }
                }
                catch (Exception ex)
                {
                    CommonUtil.SyncTrace(TraceCategory.Error, "Worker role failed during run loop while processing job: {0}. Exception:\r\n{1}", job == null ? "" : job.AsString, ex);

                    if (job != null)
                    {
                        jobQueue.DeleteMessage(job);
                    }
                }
            }
        }             

        /// <summary>
        /// Handles download jobs.  Gets changes from the db using SqlSyncProvider and puts the resulting batch files
        /// in the blob store.
        /// </summary>
        /// <param name="jobRef"></param>
        private static void DownloadSync(object jobRef)
        {
            CloudQueue jobQueue = null;
            CloudBlobContainer blobContainer = null;
            string jobId = "Unknown";
            try
            {
                // Delete the job off the queue.  We delete the job now because if we fail after this we do not want it to appear
                // again on the queue, and instead just fail the job and force the client to retry.  This simplifies the service logic
                // because we don't have to handle resuming jobs that failed in the middle.  In a production service, this might be
                // worth the extra effort.
                CloudQueueMessage job = (CloudQueueMessage)jobRef;
                jobId = job.AsString;
                jobQueue = CommonUtil.GetJobQueue();
                jobQueue.DeleteMessage(job);
                // Get the job container for the job, containing any batchfiles and job metadata
                blobContainer = CommonUtil.GetBlobContainer(jobId);

                CommonUtil.SyncTrace(TraceCategory.Info, "DownloadSync - Starting download job:{0}", jobId);
                
                blobContainer.FetchAttributes();
                blobContainer.Metadata["status"] = Enum.Format(typeof(SyncJobStatus), SyncJobStatus.PreparingBatches, "g");
                blobContainer.SetMetadata();                

                // Get the local filesystem where we will spool our batchfiles before putting them in the blob store.
                // The limitation in SqlSyncProvider of requiring a local directory to spool to forces us to write batch
                // files twice - once to the local directory, and then when we copy them to the blob store so they can be accessed
                // by web roles.
                LocalResource fileSystem = RoleEnvironment.GetLocalResource("LS1");

                string localBatchingFolder = null;
                if (RoleEnvironment.DeploymentId.Contains("deployment"))
                {
                    localBatchingFolder = Path.Combine(fileSystem.RootPath, ((string)jobId).Substring(0, 2));
                }
                else
                {
                    localBatchingFolder = Path.Combine(fileSystem.RootPath, (string)jobId);
                }

                SqlSyncProvider provider = null;
                System.Data.SqlClient.SqlConnection conn = null;

                try
                {
                    conn = new System.Data.SqlClient.SqlConnection(RoleEnvironment.GetConfigurationSettingValue("SqlAzureConnectionString"));
                    provider = new SqlSyncProvider(blobContainer.Metadata["scope"], conn);

                    Directory.CreateDirectory(localBatchingFolder);
                    provider.BatchingDirectory = localBatchingFolder;
                    provider.MemoryDataCacheSize = CommonUtil.MaxServiceMemoryCacheSizeInKb;  //Service side cache size.
                    provider.BeginSession(Microsoft.Synchronization.SyncProviderPosition.Remote, null);

                    // Get the knowledge from the job container
                    SyncKnowledge knowledge = SyncKnowledge.Deserialize(provider.IdFormats, blobContainer.GetBlobReference("destinationKnowledge").DownloadByteArray());
                    uint batchSize = Convert.ToUInt32(blobContainer.Metadata["batchsize"]);  //Client side cache size.
                    BinaryFormatter bf = new BinaryFormatter();
                    object changeData = null;

                    // Get the first changebatch
                    ChangeBatch cb = provider.GetChangeBatch(batchSize, knowledge, out changeData);

                    blobContainer.Metadata.Add("isbatched", ((DbSyncContext)changeData).IsDataBatched.ToString());
                    blobContainer.Metadata.Add("batchesready", "false");

                    //Use same change batch and change data to avoid transferring them for every batch. 
                    CloudBlob changeBatchblob = blobContainer.GetBlobReference("changebatch");
                    using (MemoryStream ms = new MemoryStream())
                    {
                        bf.Serialize(ms, cb);
                        changeBatchblob.UploadByteArray(ms.ToArray());
                    }

                    CloudBlob changeDataBlob = blobContainer.GetBlobReference("changedata");
                    using (MemoryStream ms = new MemoryStream())
                    {
                        bf.Serialize(ms, changeData);
                        changeDataBlob.UploadByteArray(ms.ToArray());
                    }

                    if (((DbSyncContext)changeData).IsDataBatched == true)
                    {
                        // If there are multiple batches, write the first one out to blob storage, and go get the rest
                        WriteBatchFileToBlob(blobContainer, (DbSyncContext)changeData);

                        while (!cb.IsLastBatch)
                        {
                            cb = provider.GetChangeBatch(batchSize, knowledge, out changeData);
                            WriteBatchFileToBlob(blobContainer, (DbSyncContext)changeData);
                        }
                    }

                    // Update the blob container metadata so that the client can start downloading the batches.
                    blobContainer.Metadata["batchesready"] = "true";
                    blobContainer.Metadata["status"] = Enum.Format(typeof(SyncJobStatus), SyncJobStatus.Complete, "g");
                    blobContainer.SetMetadata();
                }
                finally
                {
                    // Delete the local directory that the provider to which the provider spooled batch files.
                    if (localBatchingFolder != null && Directory.Exists(localBatchingFolder))
                    {
                        Directory.Delete(localBatchingFolder, true);
                    }

                    if (provider != null)
                    {
                        provider.Dispose();
                    }

                    if (conn != null)
                    {
                        conn.Dispose();
                    }
                }

                CommonUtil.SyncTrace(TraceCategory.Info, "Worker role finished preparing batches for download job:{0}", jobId);
            }
            catch (Exception ex)
            {
                // Set the job to failed if exception thrown.
                CommonUtil.SyncTrace(TraceCategory.Error, "Worker role failed to prepare batches for download job:{0}, Exception:\r\n{1}", jobId, ex);

                if (blobContainer != null)
                {
                    blobContainer.Metadata["status"] = Enum.Format(typeof(SyncJobStatus), SyncJobStatus.Failed, "g");
                    blobContainer.SetMetadata();
                }

                if (ex is StorageException)
                {
                    StorageException storageEx = (StorageException)ex;
                    CommonUtil.SyncTrace(TraceCategory.Error, "Job id: {0} StorageClient exception with extra info:\r\n{0}", jobId, storageEx.ExtendedErrorInformation);
                }
            }
            finally
            {
                lock (_jobCounterGate)
                {
                    _currentJobs--;
                }
            }
        }

        private static void WriteBatchFileToBlob(CloudBlobContainer blobContainer, DbSyncContext context)
        {
            // The provider writes the batch file to local disk.  It needs to be copied to the blob store so the web roles can access them
            // when the client makes download requests.
            string batchFilePath = context.BatchFileName;
            string batchFileName = Path.GetFileName(batchFilePath);
            CloudBlobDirectory blobDirectory = blobContainer.GetDirectoryReference("batchfiles");
            CloudBlob batchBlob = blobDirectory.GetBlobReference(batchFileName);
         
            batchBlob.UploadFile(batchFilePath);
            CommonUtil.SyncTrace(TraceCategory.Verbose, "Sync batch {0} is ready for downloading", batchFileName);

            blobContainer.Metadata["isbatched"] = "true";
            
            if (context.IsLastBatch)
            {
                batchBlob.FetchAttributes();
                batchBlob.Metadata.Add("islastbatch", "true");
                batchBlob.SetMetadata();
            }

            blobContainer.SetMetadata();
        }

        /// <summary>
        /// Handles upload jobs.  Retrieves the batch files containing the changes that were uploaded by the client
        /// and applies them using SqlSyncProvider.
        /// </summary>
        /// <param name="jobRef"></param>
        private static void UploadSync(object jobRef)
        {
            CloudQueue jobQueue = null;
            CloudBlobContainer blobContainer = null;
            string jobId = "Unknown";
            
            try
            {
                // Delete the job off the queue.  We delete the job now because if we fail after this we do not want it to appear
                // again on the queue, and instead just fail the job and force the client to retry.  This simplifies the service logic
                // because we don't have to handle resuming jobs that failed in the middle.  In a production service, this might be
                // worth the extra effort.
                CloudQueueMessage job = (CloudQueueMessage)jobRef;
                jobId = job.AsString;
                jobQueue = CommonUtil.GetJobQueue();
                jobQueue.DeleteMessage(job);
                // Get the job container for the job, containing any batchfiles and job metadata
                blobContainer = CommonUtil.GetBlobContainer(jobId);

                CommonUtil.SyncTrace(TraceCategory.Info, "UploadSync - Starting upload job:{0}", jobId);                
                
                blobContainer.FetchAttributes();
                blobContainer.Metadata["status"] = Enum.Format(typeof(SyncJobStatus), SyncJobStatus.ApplyingBatches, "g");
                blobContainer.SetMetadata();                


                // We have to copy the batch files locally first from the blob store before applying them, so get the local file store.
                // The limitation in SqlSyncProvider of requiring a local directory to spool from forces us to write batch
                // files twice - when the web role copies them to the blob store so they can be accessed by the worker role, and
                // then to the local directory so the provider can apply them. 
                LocalResource fileSystem = RoleEnvironment.GetLocalResource("LS1");

                // Get the changedata blob
                CloudBlob blob = blobContainer.GetBlobReference("changedata");
                DbSyncContext changeData;
                using (MemoryStream ms = new MemoryStream(blob.DownloadByteArray()))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    changeData = (DbSyncContext)bf.Deserialize(ms);
                }

                string localBatchingFolder = null;               
                System.Data.SqlClient.SqlConnection conn = null;
                SqlSyncProvider provider = null;
                try
                {
                    if (changeData.IsDataBatched)
                    {
                        if (RoleEnvironment.DeploymentId.Contains("deployment"))
                        {
                            localBatchingFolder = Path.Combine(fileSystem.RootPath, ((string)jobId).Substring(0, 2));
                        }
                        else
                        {
                            localBatchingFolder = Path.Combine(fileSystem.RootPath, (string)jobId);
                        }
                        Directory.CreateDirectory(localBatchingFolder);
                    }

                    conn = new System.Data.SqlClient.SqlConnection(RoleEnvironment.GetConfigurationSettingValue("SqlAzureConnectionString"));                  
                    provider = new SqlSyncProvider(blobContainer.Metadata["scope"], conn);

                    if (changeData.IsDataBatched)
                    {
                        provider.BatchingDirectory = localBatchingFolder;
                    }

                    // Here is where the max transaction size should be set if the service is running into throttling with Sql Azure
                    // provider.ApplicationTransactionSize = ???

                    provider.BeginSession(Microsoft.Synchronization.SyncProviderPosition.Remote, null);

                    // GetSyncBatchParameters only needs to be called because it does some setup in the provider.
                    uint batchSizeNotUsed;
                    SyncKnowledge knowledgeNotUsed = new SyncKnowledge();
                    provider.GetSyncBatchParameters(out batchSizeNotUsed, out knowledgeNotUsed);

                    SyncSessionStatistics syncStats = new SyncSessionStatistics();
                    if (changeData.IsDataBatched)
                    {
                        CloudBlobDirectory batchFilesDirectory = blobContainer.GetDirectoryReference("batchfiles");
                        IEnumerable<IListBlobItem> batchFileUris = batchFilesDirectory.ListBlobs();

                        CommonUtil.SyncTrace(
                            TraceCategory.Info, "Worker role is going to apply:{0} batches from blob container:{1}", batchFileUris.Count(), blobContainer.Uri); ;
                        
                        int currentIndex = 0;
                        int total = batchFileUris.Count();
                        foreach (IListBlobItem batchFileUri in batchFileUris)
                        {
                            currentIndex++;
                            CloudBlob batchFile = blobContainer.GetBlobReference(batchFileUri.Uri.AbsoluteUri);
                            changeData.IsLastBatch = false;
                            string localBatchFile = Path.Combine(localBatchingFolder, Path.GetFileName(batchFileUri.Uri.AbsolutePath));
                            changeData.BatchFileName = localBatchFile;

                            ChangeBatch cb = new ChangeBatch(provider.IdFormats, new SyncKnowledge(), new ForgottenKnowledge());
                            //CloudBlob batchFile = blobContainer.GetBlobReference(batches[i]);
                            // Grab the blob file and write it locally so the provider can process it
                            batchFile.DownloadToFile(localBatchFile);

                            if (currentIndex == total)
                            {
                                changeData.IsLastBatch = true;
                                cb.SetLastBatch();
                            }

                            provider.ProcessChangeBatch(ConflictResolutionPolicy.ApplicationDefined, cb, changeData, new SyncCallbacks(), syncStats);
                            CommonUtil.SyncTrace(TraceCategory.Verbose, "Worker role applied change batch {0}", Path.GetFileName(batchFileUri.Uri.AbsolutePath));
                        }
                    }
                    else
                    {
                        ChangeBatch cb = new ChangeBatch(provider.IdFormats, new SyncKnowledge(), new ForgottenKnowledge());
                        cb.SetLastBatch();
                        provider.ProcessChangeBatch(ConflictResolutionPolicy.ApplicationDefined, cb, changeData, new SyncCallbacks(), syncStats);
                        CommonUtil.SyncTrace(TraceCategory.Verbose, "Worker role applied change batch for non-batching sync");
                    }

                    // Write stats blob
                    blobContainer.Metadata.Add("changesapplied", syncStats.ChangesApplied.ToString());
                    blobContainer.Metadata.Add("changesfailed", syncStats.ChangesFailed.ToString());
                    blobContainer.Metadata["status"] = Enum.Format(typeof(SyncJobStatus), SyncJobStatus.Complete, "g"); ;
                    blobContainer.SetMetadata();
                }
                finally
                {
                    if (localBatchingFolder != null && Directory.Exists(localBatchingFolder))
                    {
                        Directory.Delete(localBatchingFolder, true);
                    }

                    if (provider != null)
                    {
                        provider.Dispose();
                    }

                    if (conn != null)
                    {
                        conn.Dispose();
                    }
                }

                CommonUtil.SyncTrace(TraceCategory.Info, "Worker role finished applying batches for upload job:{0}", jobId);
            }
            catch (Exception ex)
            {
                // Set the job to failed if exception thrown.
                CommonUtil.SyncTrace(
                    TraceCategory.Error, "Worker role failed to apply batches for upload job:{0}, Exception:\r\n{1}", jobId, ex);

                if (blobContainer != null)
                {
                    blobContainer.Metadata["status"] = Enum.Format(typeof(SyncJobStatus), SyncJobStatus.Failed, "g");
                    blobContainer.SetMetadata();
                }

                if (ex is StorageException)
                {
                    StorageException storageEx = (StorageException)ex;
                    CommonUtil.SyncTrace(TraceCategory.Error, "Job id: {0} StorageClient exception with extra info:\r\n{0}", jobId, storageEx.ExtendedErrorInformation);
                }
            }
            finally
            {
                lock (_jobCounterGate)
                {
                    _currentJobs--;
                }
            }
        }        
    }
}
