﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.IO;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;
using System.Web.SessionState;

using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Diagnostics;

using Microsoft.Synchronization;
using Microsoft.Synchronization.Data;
using Microsoft.Synchronization.Data.SqlServer;
using AzureSyncServiceCommonUtility;

namespace WCFSyncServiceWebRole
{
    public class AzureSyncService : RoleEntryPoint, ISyncServiceContract
    {
        /// <summary>
        /// The Role start up method that performs various set up tasks such as setting up diagnostics.
        /// One task specific to this sync solution is creating an activation context for the native Sync Framework 
        /// dll so that we can run Sync Framework native components in this Azure instance.
        /// </summary>
        /// <returns></returns>
        public override bool OnStart()
        {
            try
            {
                DiagnosticMonitorConfiguration diagConfig = DiagnosticMonitor.GetDefaultInitialConfiguration();
                diagConfig.Directories.ScheduledTransferPeriod = TimeSpan.FromMinutes(CommonUtil.TraceTransferIntervalInMinutes);
                diagConfig.Logs.ScheduledTransferPeriod = TimeSpan.FromMinutes(CommonUtil.TraceTransferIntervalInMinutes);
                diagConfig.WindowsEventLog.ScheduledTransferPeriod = TimeSpan.FromMinutes(CommonUtil.TraceTransferIntervalInMinutes);
                DiagnosticMonitor.Start("DiagnosticsConnectionString", diagConfig);
                AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(AppDomain_UnhandledException);

                // For information on handling configuration changes
                // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.
                RoleEnvironment.Changing += RoleEnvironmentChanging;

                // This code sets up a handler to update CloudStorageAccount instances when their corresponding
                // configuration settings change in the service configuration file.
                CloudStorageAccount.SetConfigurationSettingPublisher((configName, configSetter) =>
                {
                    // Provide the configSetter with the initial value
                    configSetter(RoleEnvironment.GetConfigurationSettingValue(configName));

                    RoleEnvironment.Changed += (sender, arg) =>
                    {
                        if (arg.Changes.OfType<RoleEnvironmentConfigurationSettingChange>()
                            .Any((change) => (change.ConfigurationSettingName == configName)))
                        {
                            // The corresponding configuration setting has changed, propagate the value
                            if (!configSetter(RoleEnvironment.GetConfigurationSettingValue(configName)))
                            {
                                // In this case, the change to the storage account credentials in the
                                // service configuration is significant enough that the role needs to be
                                // recycled in order to use the latest settings. (for example, the 
                                // endpoint has changed)
                                RoleEnvironment.RequestRecycle();
                            }
                        }
                    };
                });

                // Create the activation context for the Sync Framework COM dll
                string manifestPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "webapp.manifest");
                CommonUtil.CreateActivationContext(manifestPath);
            }
            catch (Exception e)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "Caught exception during web role OnStart: {0}", e);
                throw;
            }            

            return base.OnStart();
        }

        private void RoleEnvironmentChanging(object sender, RoleEnvironmentChangingEventArgs e)
        {
            // If a configuration setting is changing
            if (e.Changes.Any(change => change is RoleEnvironmentConfigurationSettingChange))
            {
                // Set e.Cancel to true to restart this role instance
                e.Cancel = true;
            }
        }

        private void AppDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // Get Reference to error container.
            CloudBlobContainer container = CommonUtil.CreateBlobContainer("webroleerrors");
            
            // Retrieve last exception.
            Exception ex = e.ExceptionObject as Exception;

            if (ex != null)
            {
                // Will create a new entry in the container
                // and upload the text representing the 
                // exception.
                container.GetBlobReference(
                   String.Format(
                       "WCFSyncServiceWebRole-{0}-{1}",
                       RoleEnvironment.CurrentRoleInstance.Id,
                       DateTime.UtcNow.Ticks)
                    ).UploadText(ex.ToString());
            }
        }

        /// <summary>
        /// Retrieve the DbSyncScopeScription from the server database
        /// </summary>
        /// <param name="ticket">The ticket to validate the client with</param>
        /// <param name="scopeName">The scope to get the scope description for</param>
        /// <returns></returns>
        public DbSyncScopeDescription GetScopeDescription(string ticket, string scopeName)
        {
            try
            {
                // Validate ticket against service ticket
                if (ticket != RoleEnvironment.GetConfigurationSettingValue("ServiceTicket"))
                {
                    throw new SyncServiceNotAuthorizedException("The provided service ticket is not valid.");
                }

                using (System.Data.SqlClient.SqlConnection conn = new System.Data.SqlClient.SqlConnection(RoleEnvironment.GetConfigurationSettingValue("SqlAzureConnectionString")))
                {
                    DbSyncScopeDescription scopeDesc = SqlSyncDescriptionBuilder.GetDescriptionForScope(scopeName, conn);
                    return scopeDesc;
                }
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "GetScopeDescription failed on service, Exception:\r\n{0}", ex);
                throw;
            }
        }

        /// <summary>
        /// Initiates a sync. Creates a job id and associated job container. The job now exists in the service.
        /// </summary>
        /// <param name="ticket">The ticket to validate the client with</param>
        /// <param name="scopeName">The scope to sync</param>
        /// <returns>The new job id</returns>
        public string BeginSession(string ticket, string scopeName)
        {
            try
            {
                // Validate ticket against service ticket
                if (ticket != RoleEnvironment.GetConfigurationSettingValue("ServiceTicket"))
                {
                    throw new SyncServiceNotAuthorizedException("The provided service ticket is not valid.");
                }

                //SessionIDManager to create IDs for our jobids
                SessionIDManager sm = new SessionIDManager();
                string jobId = sm.CreateSessionID(System.Web.HttpContext.Current);  //Context is the current HttpContext
                CommonUtil.SyncTrace(TraceCategory.Info, "BeginSession - sync session job:{0} started for scope:{1}", jobId, scopeName);
                
                CloudBlobContainer blobContainer = CommonUtil.CreateBlobContainer(jobId);
                blobContainer.Metadata.Add("scope", scopeName);
                blobContainer.Metadata.Add("status", Enum.Format(typeof(SyncJobStatus), SyncJobStatus.Created, "g"));
                blobContainer.SetMetadata();

                return jobId;
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "BeginSession failed on service, Exception:\r\n{0}", ex);
                throw;
            }
        }

        /// <summary>
        /// Retrieves the knowledge from the server db. First checks if the knowledge is already in the job container (from a previous
        /// interrupted sync).
        /// Gets it from the database if it's not there, puts it in the job container and returns the knowledge.
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns>SyncBatchParameters - includes batch size and knowledge</returns>
        public SyncBatchParameters GetKnowledge(string jobId)
        {
            try
            {
                CommonUtil.SyncTrace(TraceCategory.Verbose, "GetKnowledge - for job:{0}", jobId);

                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);
                string scopeName = blobContainer.Metadata["scope"];

                SyncBatchParameters destParameters = new SyncBatchParameters();

                if (DoesBlobExist(blobContainer, "knowledge"))
                {
                    SyncIdFormatGroup idFormatGroup = new SyncIdFormatGroup();

                    //
                    // 1 byte change unit id (Harmonica default before flexible ids)
                    //
                    idFormatGroup.ChangeUnitIdFormat.IsVariableLength = false;
                    idFormatGroup.ChangeUnitIdFormat.Length = 1;

                    //
                    // Guid replica id
                    //
                    idFormatGroup.ReplicaIdFormat.IsVariableLength = false;
                    idFormatGroup.ReplicaIdFormat.Length = 16;

                    //
                    // Sync global id for item ids
                    //
                    idFormatGroup.ItemIdFormat.IsVariableLength = true;
                    idFormatGroup.ItemIdFormat.Length = 10 * 1024;

                    destParameters.DestinationKnowledge = SyncKnowledge.Deserialize(idFormatGroup, blobContainer.GetBlobReference("knowledge").DownloadByteArray());
                    destParameters.BatchSize = CommonUtil.MaxServiceMemoryCacheSizeInKb;
                    return destParameters;
                }
                else
                {
                    System.Data.SqlClient.SqlConnection conn = null;
                    SqlSyncProvider provider = null;

                    try
                    {
                        conn = new System.Data.SqlClient.SqlConnection(RoleEnvironment.GetConfigurationSettingValue("SqlAzureConnectionString"));
                        provider = new SqlSyncProvider(scopeName, conn);
                        provider.MemoryDataCacheSize = CommonUtil.MaxServiceMemoryCacheSizeInKb;
                        provider.BeginSession(SyncProviderPosition.Remote, null);
                        provider.GetSyncBatchParameters(out destParameters.BatchSize, out destParameters.DestinationKnowledge);

                        // Write the knowledge to the blob container in case the sync fails and wants to resume
                        blobContainer.GetBlobReference("knowledge").UploadByteArray(destParameters.DestinationKnowledge.Serialize());

                        return destParameters;
                    }
                    finally
                    {
                        if (provider != null)
                        {
                            provider.Dispose();
                        }

                        if (conn != null)
                        {
                            conn.Dispose();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "GetKnowledge failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }
        }

        /// <summary>
        /// Tells the service it wants it to prepare changes to be downloaded, using the given knowledge. 
        /// Here the web role will put the download job request on the queue to be handled by a worker role.
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="batchSize"></param>
        /// <param name="destinationKnowledge"></param>
        public void PrepareBatches(string jobId, uint batchSize, SyncKnowledge destinationKnowledge)
        {
            try
            {
                CommonUtil.SyncTrace(TraceCategory.Verbose, "PrepareBatches - Request to prepare batches for job:{0}", jobId);
                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);
                CloudQueue jobQueue = CommonUtil.GetJobQueue();

                blobContainer.Metadata.Add("jobtype", "download");
                blobContainer.Metadata.Add("batchsize", batchSize.ToString());
                blobContainer.SetMetadata();

                CloudBlob blob = blobContainer.GetBlobReference("destinationKnowledge");
                blob.UploadByteArray(destinationKnowledge.Serialize());

                jobQueue.AddMessage(new CloudQueueMessage(jobId));

                blobContainer.Metadata["status"] = Enum.Format(typeof(SyncJobStatus), SyncJobStatus.InQueue, "g");
                blobContainer.SetMetadata();

                CommonUtil.SyncTrace(TraceCategory.Info, "Web role put download job {0} in queue for worker", jobId);
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "PrepareBatches failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }
        }

        /// <summary>
        /// Notifies the service that all changes have been uploaded and ready to be applied to the server db.
        /// Here the web role will put the request on the queue to be handled by a worker role.
        /// </summary>
        /// <param name="jobId"></param>
        /// <param name="changeData"></param>
        public void ApplyChanges(string jobId, object changeData)
        {
            try
            {
                CommonUtil.SyncTrace(TraceCategory.Verbose, "ApplyChanges - Apply Changes for job:{0}", jobId);

                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);

                // Only put the job on the queue if it is in "Created" state
                if (SyncJobStatus.Created == (SyncJobStatus)Enum.Parse(typeof(SyncJobStatus), blobContainer.Metadata["status"]))
                {
                    CloudQueue jobQueue = CommonUtil.GetJobQueue();
                    CloudBlob blob = blobContainer.GetBlobReference("changedata");

                    using (MemoryStream ms = new MemoryStream())
                    {
                        BinaryFormatter bf = new BinaryFormatter();
                        bf.Serialize(ms, changeData);
                        blob.UploadByteArray(ms.ToArray());
                    }

                    blobContainer.Metadata.Add("jobtype", "upload");
                    blobContainer.Metadata["jobtype"] = "upload";
                    blobContainer.SetMetadata();

                    jobQueue.AddMessage(new CloudQueueMessage(jobId));

                    blobContainer.Metadata["status"] = Enum.Format(typeof(SyncJobStatus), SyncJobStatus.InQueue, "g");
                    blobContainer.SetMetadata();
                    CommonUtil.SyncTrace(TraceCategory.Info, "Web role put upload job {0} in queue for worker", jobId);
                }
                else
                {
                    CommonUtil.SyncTrace(TraceCategory.Warning, "Web role has already put upload job {0} in queue for worker", jobId);
                }                
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "ApplyChanges failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }
        }

        /// <summary>
        /// EndSession cleans up the blob container for the job.  Notice that the service relies on the client to do clean up.
        /// In a production service there will likely need to be a mechanism where the service cleans up old jobs.
        /// </summary>
        /// <param name="jobId"></param>
        public void EndSession(string jobId)
        {
            try
            {
                CommonUtil.SyncTrace(TraceCategory.Info, "EndSession - Sync session job:{0} ends", jobId);

                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);
                if (blobContainer != null)
                {
                    blobContainer.Delete();
                }
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "EndSession failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }
        }

        /// <summary>
        /// Used by proxy to see if the batch file has already been uploaded. Optimizes by not resending batch files.
        /// NOTE: This method takes in a file name as an input parameter and hence is suseptible for name canonicalization
        /// attacks. This sample is meant to be a starting point in demonstrating how to transfer sync batch files and is
        /// not intended to be a secure way of doing the same. This SHOULD NOT be used as such in production environment
        /// without doing proper security analysis.
        /// 
        /// Please refer to the following two MSDN whitepapers for more information on guidelines for securing Web servies.
        /// 
        /// Design Guidelines for Secure Web Applications - http://msdn.microsoft.com/en-us/library/aa302420.aspx (Refer InputValidation section)
        /// Architecture and Design Review for Security - http://msdn.microsoft.com/en-us/library/aa302421.aspx (Refer InputValidation section)
        /// </summary>
        /// <param name="batchFileId"></param>
        /// <returns>Whether the service has the given batch file already</returns>
        public bool HasUploadedBatchFile(string jobId, String batchFileId)
        {
            try
            {
                //Check to see if the proxy has already uploaded this file to the service
                CommonUtil.SyncTrace(TraceCategory.Verbose, "HasUploadedBatchFile - check batch file:{0} for job:{1}", batchFileId, jobId);

                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);
                return DoesBlobExist(blobContainer, "batchfiles/" + batchFileId);
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "HasUploadedBatchFile failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }
        }

        /// <summary>
        /// NOTE: This method takes in a file name as an input parameter and hence is suseptible for name canonicalization
        /// attacks. This sample is meant to be a starting point in demonstrating how to transfer sync batch files and is
        /// not intended to be a secure way of doing the same. This SHOULD NOT be used as such in production environment
        /// without doing proper security analysis.
        /// 
        /// Please refer to the following two MSDN whitepapers for more information on guidelines for securing Web servies.
        /// 
        /// Design Guidelines for Secure Web Applications - http://msdn.microsoft.com/en-us/library/aa302420.aspx (Refer InputValidation section)
        /// Architecture and Design Review for Security - http://msdn.microsoft.com/en-us/library/aa302421.aspx (Refer InputValidation section)
        /// </summary>
        /// <param name="batchFileId"></param>
        /// <param name="batchContents"></param>
        /// <param name="remotePeerId"></param>
        public void UploadBatchFile(string jobId, string batchFileId, byte[] batchContents)
        {
            try
            {
                CommonUtil.SyncTrace(TraceCategory.Verbose, "UploadBatchFile - upload batch file:{0} for job:{1}", batchFileId, jobId);

                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);
                CloudBlobDirectory blobDirectory = blobContainer.GetDirectoryReference("batchfiles");

                CloudBlob blob = blobDirectory.GetBlobReference(batchFileId);
                blob.UploadByteArray(batchContents);
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "UploadBatchFile failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }

        }

        /// <summary>
        /// Used by the client to poll the service when waiting for batch files.  Once the worker role has prepared the batch files
        /// the batch info is ready to be returned.
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns>null if the batches are not ready, otherwise the changebatch, dataretriever and batchfile list wrapped
        /// in a GetChangesParameters object</returns>
        public GetChangesParameters GetBatchInfo(string jobId)
        {
            try
            {
                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);

                if (blobContainer.Metadata["batchesready"] == "true")
                {
                    CommonUtil.SyncTrace(TraceCategory.Verbose, "GetBatchInfo - get change batch information for job:{0}", jobId);
                    BinaryFormatter bf = new BinaryFormatter();
                    GetChangesParameters returnValue = new GetChangesParameters();

                    if (DoesBlobExist(blobContainer, "changebatch") && DoesBlobExist(blobContainer, "changedata"))
                    {
                        CloudBlob changeBatchBlob = blobContainer.GetBlobReference("changebatch");
                        using (MemoryStream ms = new MemoryStream(changeBatchBlob.DownloadByteArray()))
                        {
                            returnValue.ChangeBatch = (ChangeBatch)(bf.Deserialize(ms));
                        }

                        CloudBlob changeDataBlob = blobContainer.GetBlobReference("changedata");
                        using (MemoryStream ms = new MemoryStream(changeDataBlob.DownloadByteArray()))
                        {
                            returnValue.DataRetriever = bf.Deserialize(ms);
                        }
                    }
                    else
                    {
                        throw new InvalidOperationException("Expected changebatch and changedata not found.");
                    }

                    // If there are batch files we need to provide a list of them to the client
                    if (blobContainer.Metadata["isbatched"] == "true")
                    {                     
                        CloudBlobDirectory blobDirectory = blobContainer.GetDirectoryReference("batchfiles");
                        returnValue.BatchFiles = new List<string>();
                        foreach (IListBlobItem batchfileUri in blobDirectory.ListBlobs())
                        {
                            string filename = Path.GetFileName(batchfileUri.Uri.AbsolutePath);
                            returnValue.BatchFiles.Add(filename);
                        }
                    }

                    return returnValue;
                }
                else
                {
                    // Batches are not ready, return null
                    return null;
                }
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "GetBatchInfo failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }
        }


        /// <summary>
        /// NOTE: This method takes in a file name as an input parameter and hence is suseptible for name canonicalization
        /// attacks. This sample is meant to be a starting point in demonstrating how to transfer sync batch files and is
        /// not intended to be a secure way of doing the same. This SHOULD NOT be used as such in production environment
        /// without doing proper security analysis.
        /// 
        /// Please refer to the following two MSDN whitepapers for more information on guidelines for securing Web servies.
        /// 
        /// Design Guidelines for Secure Web Applications - http://msdn.microsoft.com/en-us/library/aa302420.aspx (Refer InputValidation section)
        /// Architecture and Design Review for Security - http://msdn.microsoft.com/en-us/library/aa302421.aspx (Refer InputValidation section)
        /// </summary>
        /// <param name="batchFileId"></param>
        /// <returns>The requested batch file</returns>
        public byte[] DownloadBatchFile(string jobId, string batchFileId)
        {
            try
            {
                CommonUtil.SyncTrace(TraceCategory.Verbose, "DownloadBatchFile - download batch file:{0} for job:{1}", batchFileId, jobId);

                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);
                blobContainer.FetchAttributes();

                if (DoesBlobExist(blobContainer, "batchfiles/" + batchFileId))
                {
                    CloudBlob batchBlob = blobContainer.GetBlobReference("batchfiles/" + batchFileId);
                    return batchBlob.DownloadByteArray();
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "DownloadBatchFile failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }
        }

        /// <summary>
        /// Returns the status of the given job.
        /// </summary>
        /// <param name="jobId"></param>
        /// <returns>The SyncJobState of the given job</returns>
        public SyncJobState GetStatus(String jobId)
        {
            try
            {
                CloudBlobContainer blobContainer = CommonUtil.GetBlobContainer(jobId);

                SyncJobState jobState = new SyncJobState();
                jobState.Statistics = null;

                if (blobContainer == null)
                {
                    jobState.Status = SyncJobStatus.DoesNotExist;
                }
                else
                {
                    jobState.Status = (SyncJobStatus)Enum.Parse(typeof(SyncJobStatus), blobContainer.Metadata["status"]);

                    if (jobState.Status == SyncJobStatus.Complete)
                    {
                        CommonUtil.SyncTrace(TraceCategory.Verbose, "GetStatus - get job status for job:{0}", jobId);

                        jobState.Statistics = new SyncSessionStatistics();
                        UInt32 changesApplied = 0;
                        UInt32 changesFailed = 0;
                        if (blobContainer.Metadata.AllKeys.Contains("changesapplied"))
                        {
                            if (!UInt32.TryParse(blobContainer.Metadata["changesapplied"], out changesApplied))
                            {
                                CommonUtil.SyncTrace(TraceCategory.Error, "Invalid changesapplied value, {0}, for job:{1}", blobContainer.Metadata["changesapplied"], jobId);
                            }
                        }
                        if (blobContainer.Metadata.AllKeys.Contains("changesfailed"))
                        {
                            if (!UInt32.TryParse(blobContainer.Metadata["changesfailed"], out changesFailed))
                            {
                                CommonUtil.SyncTrace(TraceCategory.Error, "Invalid changesfailed value, {0}, for job:{1}", blobContainer.Metadata["changesfailed"], jobId);
                            }
                        }

                        jobState.Statistics.ChangesApplied = changesApplied;
                        jobState.Statistics.ChangesFailed = changesFailed;
                    }
                }

                return jobState;
            }
            catch (Exception ex)
            {
                CommonUtil.SyncTrace(TraceCategory.Error, "GetStatus failed on service for job:{0}, Exception:\r\n{1}", jobId, ex);
                throw;
            }
        }

        private bool DoesBlobExist(CloudBlobContainer blobContainer, string blobName)
        {
            CloudBlob blob = blobContainer.GetBlobReference(blobName);
            try
            {
                blob.FetchAttributes();
            }
            catch (StorageClientException e)
            {
                if (e.ErrorCode == StorageErrorCode.ResourceNotFound)
                {
                    return false;
                }
            }

            return true;
        }
    }
}
