﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using Microsoft.Synchronization;
using Microsoft.Synchronization.Data;
using System.Data;
using AzureSyncServiceCommonUtility;

namespace WCFSyncServiceWebRole
{
    [ServiceContract]
    [ServiceKnownType(typeof(SyncIdFormatGroup))]
    [ServiceKnownType(typeof(DbSyncContext))]
    [ServiceKnownType(typeof(SyncBatchParameters))]
    [ServiceKnownType(typeof(GetChangesParameters))]
    public interface ISyncServiceContract
    {
        [OperationContract]
        DbSyncScopeDescription GetScopeDescription(string ticket, string scopeName);

        [OperationContract]
        string BeginSession(string ticket, string scopeName);

        [OperationContract]
        SyncBatchParameters GetKnowledge(string jobId);

        [OperationContract]
        void PrepareBatches(string jobId, uint batchSize, SyncKnowledge destinationKnowledge);

        [OperationContract]
        GetChangesParameters GetBatchInfo(string jobId);

        [OperationContract]
        void ApplyChanges(string jobId, object changeData);

        [OperationContract]
        bool HasUploadedBatchFile(string jobId, string batchFileid);

        [OperationContract]
        void UploadBatchFile(string jobId, string batchFileid, byte[] batchFile);

        [OperationContract]
        byte[] DownloadBatchFile(string jobId, string batchFileId);

        [OperationContract]
        void EndSession(string jobId);

        [OperationContract]
        SyncJobState GetStatus(string jobId);
    }

    [DataContract]
    public class SyncBatchParameters
    {
        [DataMember]
        public SyncKnowledge DestinationKnowledge;

        [DataMember]
        public uint BatchSize;
    }

    [DataContract]
    public class SyncJobState
    {
        [DataMember]
        public SyncJobStatus Status;

        [DataMember]
        public SyncSessionStatistics Statistics;
    }

    [DataContract]
    [KnownType(typeof(DataSet))]
    public class GetChangesParameters
    {
        [DataMember]
        public object DataRetriever;

        [DataMember]
        public ChangeBatch ChangeBatch;

        [DataMember]
        public List<string> BatchFiles;
    }
}
