﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using System.Timers;
using System.Security;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization;

using Microsoft.Synchronization;
using Microsoft.Synchronization.Data;

using WCFSyncServiceWebRole;
using AzureSyncServiceCommonUtility;
using System.ServiceModel.Description;

namespace WCFSyncServiceWebRole
{   
    public class RelationalProviderProxy : KnowledgeSyncProvider, IDisposable
    {
        protected ISyncServiceContract proxy;
        protected SyncIdFormatGroup idFormatGroup;
        private string _scopeName;
        private string _hostName; //Host name is Service provider Azure service Url        
        private string _ticket; //The string to pass to the server to authenticate this client
        private string _batchingDirectoryRoot = Environment.ExpandEnvironmentVariables("%TEMP%");
        private string _jobId; //The current job id
        private SyncJobStatus _syncJobStatus = SyncJobStatus.DoesNotExist;
        private GetChangesParameters _changeParams = null; // Cached change parameters for resumed jobs
        private bool _exceptionThrown = false;

        public RelationalProviderProxy(string scopeName, string hostName, string ticket, string jobId)
        {           
            _scopeName = scopeName;
            _hostName = hostName;
            _ticket = ticket;
            _jobId = jobId;
        }

        public RelationalProviderProxy(string scopeName, string hostName, string ticket) : this (scopeName, hostName, ticket, null)
        {
        }

        public string BatchingDirectoryRoot
        {
            get { return _batchingDirectoryRoot; }
            set { _batchingDirectoryRoot = value; }
        }

        public string JobId
        {
            get { return _jobId; }
            set { _jobId = value; }
        }

        public SyncJobStatus SyncJobStatus
        {
            get { return _syncJobStatus; }
        }

        public override SyncIdFormatGroup IdFormats
        {
            get
            {
                if (idFormatGroup == null)
                {
                    idFormatGroup = new SyncIdFormatGroup();

                    //
                    // 1 byte change unit id
                    //
                    idFormatGroup.ChangeUnitIdFormat.IsVariableLength = false;
                    idFormatGroup.ChangeUnitIdFormat.Length = 1;

                    //
                    // Guid replica id
                    //
                    idFormatGroup.ReplicaIdFormat.IsVariableLength = false;
                    idFormatGroup.ReplicaIdFormat.Length = 16;

                    //
                    // Sync global id for item ids
                    //
                    idFormatGroup.ItemIdFormat.IsVariableLength = true;
                    idFormatGroup.ItemIdFormat.Length = 10 * 1024;
                }

                return idFormatGroup;
            }
        }

        /// <summary>
        /// KnowledgeSyncProvider override.  Calls service to get a job id.
        /// </summary>
        /// <param name="position"></param>
        /// <param name="syncSessionContext"></param>
        public override void BeginSession(SyncProviderPosition position, SyncSessionContext syncSessionContext)
        {
            try
            {
                SyncTracer.Verbose("Client proxy entered BeginSession.");
                this.CreateProxy();                
                _changeParams = null;
                _exceptionThrown = false;

                if (this._jobId == null)
                {
                    this._jobId = this.proxy.BeginSession(_ticket, this._scopeName);
                }

                _syncJobStatus = this.proxy.GetStatus(_jobId).Status;
            }
            catch (Exception ex)
            {
                _exceptionThrown = true;
                SyncTracer.Error("Client proxy failed during BeginSession with Exception: {0}", ex);
                throw;
            }
        }

        /// <summary>
        /// KnowledgeSyncProvider override. Calls service to get server db knowledge
        /// </summary>
        /// <param name="batchSize"></param>
        /// <param name="knowledge"></param>
        public override void GetSyncBatchParameters(out uint batchSize, out SyncKnowledge knowledge)
        {
            try
            {
                SyncTracer.Verbose("Client proxy entered GetSyncBatchParameters.");
                SyncBatchParameters wrapper = proxy.GetKnowledge(this._jobId);
                batchSize = wrapper.BatchSize;
                knowledge = wrapper.DestinationKnowledge;
            }
            catch (Exception ex)
            {
                _exceptionThrown = true;
                SyncTracer.Error("Client proxy failed during GetSyncBatchParameters with Exception: {0}", ex);
                throw;
            }
        }

        /// <summary>
        /// KnowledgeSyncProvider override. Ask the service to prepare the batches, wait for them, and then download them during subsequent
        /// GetChangeBatch calls.
        /// </summary>
        /// <param name="batchSize"></param>
        /// <param name="destinationKnowledge"></param>
        /// <param name="changeDataRetriever"></param>
        /// <returns></returns>
        public override ChangeBatch GetChangeBatch(uint batchSize, SyncKnowledge destinationKnowledge, out object changeDataRetriever)
        {
            try
            {
                SyncTracer.Verbose("Client proxy entered GetChangeBatch.");

                // Check the status of the job and if we've already called PrepareBatches (only need to call it once per download job)
                _syncJobStatus = proxy.GetStatus(this._jobId).Status;
                if (_syncJobStatus == SyncJobStatus.Created)
                {
                    // Kick off the request for the service to prepare the batches
                    proxy.PrepareBatches(this._jobId, batchSize, destinationKnowledge);
                }

                // Poll the service for the changeParams.
                if (_changeParams == null)
                {
                    PollServiceForCompletion();                    

                    if (_syncJobStatus == SyncJobStatus.Complete)
                    {
                        _changeParams = proxy.GetBatchInfo(_jobId);

                        if (_changeParams == null)
                        {
                            throw new DbSyncException(String.Format("Service returned null GetChangesParameters during download. Job ID: {0}", _jobId));
                        }
                    }
                }

                // If we are actually using batch files we check if we have them locally first (from a previous interrupted sync) before
                // trying to download them
                if (((DbSyncContext)_changeParams.DataRetriever).IsDataBatched)
                {
                    string jobBatchingDirectory = Path.Combine(_batchingDirectoryRoot, _jobId);
                    string currentBatchFileId = _changeParams.BatchFiles[0];

                    if (!Directory.Exists(jobBatchingDirectory))
                    {
                        Directory.CreateDirectory(jobBatchingDirectory);
                    }

                    if (!File.Exists(Path.Combine(jobBatchingDirectory, currentBatchFileId)))
                    {
                        byte[] batchFile = proxy.DownloadBatchFile(_jobId, currentBatchFileId);

                        using (FileStream localFileStream = new FileStream(Path.Combine(jobBatchingDirectory, currentBatchFileId), FileMode.Create, FileAccess.Write))
                        {
                            localFileStream.Write(batchFile, 0, batchFile.Length);
                        }
                    }

                    if (_changeParams.BatchFiles.Count == 1)
                    {
                        ((DbSyncContext)_changeParams.DataRetriever).IsLastBatch = true;
                        _changeParams.ChangeBatch.SetLastBatch();
                    }

                    _changeParams.BatchFiles.Remove(currentBatchFileId);
                    ((DbSyncContext)_changeParams.DataRetriever).BatchFileName = Path.Combine(jobBatchingDirectory, currentBatchFileId);
                    changeDataRetriever = _changeParams.DataRetriever;
                    return _changeParams.ChangeBatch;
                }
                else
                {
                    _changeParams.ChangeBatch.SetLastBatch();
                    ((DbSyncContext)_changeParams.DataRetriever).IsLastBatch = true;
                    changeDataRetriever = _changeParams.DataRetriever;

                    return _changeParams.ChangeBatch;
                }
            }
            catch (Exception ex)
            {
                _exceptionThrown = true;
                SyncTracer.Error("Client proxy failed during GetChangeBatch with Exception: {0}", ex);                
                throw;
            }            
        }

        public override FullEnumerationChangeBatch GetFullEnumerationChangeBatch(uint batchSize, SyncId lowerEnumerationBound, SyncKnowledge knowledgeForDataRetrieval, out object changeDataRetriever)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// KnowledgeSyncProvider override. Uploads batch files to service and calls ApplyChanges after the last batch.
        /// </summary>
        /// <param name="resolutionPolicy"></param>
        /// <param name="sourceChanges"></param>
        /// <param name="changeDataRetriever"></param>
        /// <param name="syncCallbacks"></param>
        /// <param name="sessionStatistics"></param>
        public override void ProcessChangeBatch(ConflictResolutionPolicy resolutionPolicy, ChangeBatch sourceChanges, object changeDataRetriever, SyncCallbacks syncCallbacks, SyncSessionStatistics sessionStatistics)
        {
            try
            {
                SyncTracer.Verbose("Client proxy entered ProcessChangeBatch.");
                DbSyncContext context = changeDataRetriever as DbSyncContext;
                if (context != null && context.IsDataBatched)
                {
                    string fileName = new FileInfo(context.BatchFileName).Name;

                    //Check to see if service already has this file
                    if (!this.proxy.HasUploadedBatchFile(this._jobId, fileName))
                    {
                        //Upload this file to remote service
                        using (FileStream stream = new FileStream(context.BatchFileName, FileMode.Open, FileAccess.Read))
                        {
                            byte[] contents = new byte[stream.Length];
                            stream.Read(contents, 0, contents.Length);
                            this.proxy.UploadBatchFile(this._jobId, fileName, contents);
                        }
                    }

                    context.BatchFileName = fileName;
                }

                if (sourceChanges.IsLastBatch)
                {
                    this.proxy.ApplyChanges(this._jobId, changeDataRetriever);

                    SyncJobState jobState = PollServiceForCompletion();                    

                    if (jobState.Statistics != null)
                    {
                        sessionStatistics.ChangesApplied = jobState.Statistics.ChangesApplied;
                        sessionStatistics.ChangesFailed = jobState.Statistics.ChangesFailed;
                    }
                }
            }
            catch (Exception ex)
            {
                _exceptionThrown = true;
                SyncTracer.Error("Client proxy failed during ProcessChangeBatch with Exception: {0}", ex);
                throw;
            }
        }

        /// <summary>
        /// Helper method to poll the service in upload and download situations.  Simply waits 1 second between polls.
        /// </summary>
        /// <returns></returns>
        private SyncJobState PollServiceForCompletion()
        {
            // Create a timeout before we start polling for completion.
            DateTime endTime = DateTime.Now.AddMinutes(30);
            SyncJobState jobState = null;

            while (true)
            {
                if (DateTime.Now > endTime)
                {
                    SyncTracer.Error(String.Format("Client timed out while waiting for the service to apply/prepare batches during upload/download. Job ID: {0}", _jobId));
                    throw new TimeoutException(String.Format("Client timed out while waiting for the service to apply/prepare batches during upload/download. Job ID: {0}", _jobId));
                }

                jobState = proxy.GetStatus(_jobId);
                _syncJobStatus = jobState.Status;

                // If the service is still applying/preparing batches, we'll wait to see if it completes successfully.
                if (_syncJobStatus == SyncJobStatus.ApplyingBatches || _syncJobStatus == SyncJobStatus.PreparingBatches || _syncJobStatus == SyncJobStatus.InQueue)
                {
                    System.Threading.Thread.Sleep(1000);
                }
                else if (_syncJobStatus == SyncJobStatus.Failed || _syncJobStatus == SyncJobStatus.DoesNotExist)
                {
                    SyncTracer.Error("The service failed to carry out the requested operation.  Please check the service logs for the exception. Job Status: {0}, Job ID: {1}", _syncJobStatus, _jobId);
                    throw new DbSyncException(String.Format("The service failed to carry out the requested operation.  Please check the service logs for the exception. Job Status: {0}, Job ID: {1}", _syncJobStatus, _jobId));
                }
                // The job is either done or something weird happened, so we are done waiting.
                else
                {
                    break;
                }
            }

            return jobState;
        }

        public override void ProcessFullEnumerationChangeBatch(ConflictResolutionPolicy resolutionPolicy, FullEnumerationChangeBatch sourceChanges, object changeDataRetriever, SyncCallbacks syncCallbacks, SyncSessionStatistics sessionStatistics)
        {
            throw new NotImplementedException();
        }


        /// <summary>
        /// KnowledgeSyncProvider override.  Clean up service job if necessary.
        /// </summary>
        /// <param name="syncSessionContext"></param>
        public override void EndSession(SyncSessionContext syncSessionContext)
        {
            try
            {
                SyncTracer.Verbose("Client proxy entered EndSession.");

                // If the job completed AND the sync session completed then we can clean up and call end session on the service.
                // If the job failed on the service, we'll have to create a new job, so clean this one up.
                if ((_syncJobStatus == SyncJobStatus.Complete && !_exceptionThrown) || _syncJobStatus == SyncJobStatus.Failed || _syncJobStatus == SyncJobStatus.DoesNotExist)
                {
                    if (_syncJobStatus != SyncJobStatus.DoesNotExist)
                    {
                        proxy.EndSession(this._jobId);
                    }

                    if (Directory.Exists(Path.Combine(_batchingDirectoryRoot, _jobId)))
                    {
                        // Cleanup batch files from this session
                        Directory.Delete(Path.Combine(_batchingDirectoryRoot, _jobId), true);
                    }

                    _jobId = null;
                }
            }
            catch (Exception ex)
            {
                _exceptionThrown = true;
                SyncTracer.Error("Client proxy failed during EndSession with Exception: {0}", ex);
                throw;
            }
            finally
            {
                _changeParams = null;                
            }
        }

        /// <summary>
        /// Retrieves the DbSyncScopeDescription from the service for the given scope
        /// </summary>
        /// <returns></returns>
        public DbSyncScopeDescription GetScopeDescription()
        {
            try
            {
                SyncTracer.Verbose("Client proxy entered GetScopeDescription.");
                CreateProxy();
                return this.proxy.GetScopeDescription(_ticket, this._scopeName);
            }
            catch (Exception ex)
            {
                SyncTracer.Error("Client proxy failed during GetScopeDescription with Exception: {0}", ex);
                throw;
            }
        }

        protected void CreateProxy()
        {
            CloseProxy();
            BasicHttpBinding binding = new BasicHttpBinding();
            int maxMessageSize = 20000000;  //20MB - this will limit the batch file size to 20mb.  If a higher batch size is desired then 
                                            // this will also need to be increased.
            binding.ReceiveTimeout = TimeSpan.FromMinutes(30);
            binding.SendTimeout = TimeSpan.FromMinutes(30);
            binding.MaxReceivedMessageSize = maxMessageSize;
            binding.ReaderQuotas.MaxArrayLength = maxMessageSize;

            ChannelFactory<ISyncServiceContract> factory = new ChannelFactory<ISyncServiceContract>(binding, new EndpointAddress(this._hostName));
            this.proxy = factory.CreateChannel();
        }

        public void CloseProxy()
        {
            ICommunicationObject clientProxy = proxy as ICommunicationObject;
            if (clientProxy != null)
            {
                if (clientProxy.State != CommunicationState.Faulted)
                {
                    clientProxy.Close();
                }
                else
                {
                    clientProxy.Abort();
                }
            }
        }

        public void Dispose()
        {
            ICommunicationObject clientProxy = proxy as ICommunicationObject;
            if (clientProxy != null)
            {
                if (clientProxy.State != CommunicationState.Faulted)
                {
                    clientProxy.Close();
                }
                else
                {
                    clientProxy.Abort();
                }
            }
            
            this.proxy = null;
            GC.SuppressFinalize(this);
        }
    }
}
