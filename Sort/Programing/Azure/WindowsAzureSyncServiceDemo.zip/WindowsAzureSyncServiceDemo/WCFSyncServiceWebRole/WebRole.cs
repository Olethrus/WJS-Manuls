using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Data;
using System.IO;
using System.Diagnostics;
using System.Data.SqlClient;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure.ServiceRuntime;
using Microsoft.WindowsAzure.Diagnostics;

using Microsoft.Synchronization;
using Microsoft.Synchronization.Data;
using Microsoft.Synchronization.Data.SqlServer;
using AzureSyncServiceCommonUtility;


namespace WCFSyncServiceWebRole
{
    public class WebRole : RoleEntryPoint
    {
        private static bool _storageInitialized = false;
        private static object _storageGate = new Object();
        private static CloudBlobClient _cloudBlobClient;
        private static CloudQueue _jobQueue;

        public override bool OnStart()
        {
            DiagnosticMonitorConfiguration diagConfig = DiagnosticMonitor.GetDefaultInitialConfiguration();
            diagConfig.Logs.ScheduledTransferPeriod = TimeSpan.FromMinutes(CommonUtil.TraceTransferIntervalInMinutes);
            DiagnosticMonitor.Start("DiagnosticsConnectionString", diagConfig);
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(AppDomain_UnhandledException);

            // For information on handling configuration changes
            // see the MSDN topic at http://go.microsoft.com/fwlink/?LinkId=166357.
            RoleEnvironment.Changing += RoleEnvironmentChanging;

            // This code sets up a handler to update CloudStorageAccount instances when their corresponding
            // configuration settings change in the service configuration file.
            CloudStorageAccount.SetConfigurationSettingPublisher((configName, configSetter) =>
            {
                // Provide the configSetter with the initial value
                configSetter(RoleEnvironment.GetConfigurationSettingValue(configName));

                RoleEnvironment.Changed += (sender, arg) =>
                {
                    if (arg.Changes.OfType<RoleEnvironmentConfigurationSettingChange>()
                        .Any((change) => (change.ConfigurationSettingName == configName)))
                    {
                        // The corresponding configuration setting has changed, propagate the value
                        if (!configSetter(RoleEnvironment.GetConfigurationSettingValue(configName)))
                        {
                            // In this case, the change to the storage account credentials in the
                            // service configuration is significant enough that the role needs to be
                            // recycled in order to use the latest settings. (for example, the 
                            // endpoint has changed)
                            RoleEnvironment.RequestRecycle();
                        }
                    }
                };
            });

            string manifestPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "webapp.manifest");
            CommonUtil.CreateActivationContext(manifestPath);

            return base.OnStart();
        }

        private void RoleEnvironmentChanging(object sender, RoleEnvironmentChangingEventArgs e)
        {
            // If a configuration setting is changing
            if (e.Changes.Any(change => change is RoleEnvironmentConfigurationSettingChange))
            {
                // Set e.Cancel to true to restart this role instance
                e.Cancel = true;
            }
        }

        void AppDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            // Initialize the storage variables.
            InitializeStorage();

            // Get Reference to error container.
            CloudBlobContainer container = _cloudBlobClient.GetContainerReference("webroleerrors");

            if (container != null)
            {
                // Retrieve last exception.
                Exception ex = e.ExceptionObject as Exception;

                if (ex != null)
                {
                    // Will create a new entry in the container
                    // and upload the text representing the 
                    // exception.
                    container.GetBlobReference(
                       String.Format(
                           "SyncServiceWorkerRole-{0}-{1}",
                           RoleEnvironment.CurrentRoleInstance.Id,
                           DateTime.UtcNow.Ticks)
                        ).UploadText(ex.ToString());
                }
            }
        }        

        private void InitializeStorage()
        {
            if (_storageInitialized)
            {
                return;
            }

            lock (_storageGate)
            {
                if (_storageInitialized)
                {
                    return;
                }

                // read account configuration settings
                CloudStorageAccount storageAccount = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
                _cloudBlobClient = storageAccount.CreateCloudBlobClient();
                _cloudBlobClient.RetryPolicy = RetryPolicies.Retry(10, TimeSpan.FromMilliseconds(100));

                CloudQueueClient cloudQueueClient = storageAccount.CreateCloudQueueClient();
                cloudQueueClient.RetryPolicy = RetryPolicies.Retry(10, TimeSpan.FromMilliseconds(100));
                _jobQueue = cloudQueueClient.GetQueueReference("jobqueue");
                _jobQueue.CreateIfNotExist();

                // create container for unhandled worker role exceptions
                CloudBlobContainer blobContainer = _cloudBlobClient.GetContainerReference("workerroleerrors");
                blobContainer.CreateIfNotExist();

                _storageInitialized = true;
            }
        }                 
    }
}
