////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#include "stdafx.h"
#include "Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CCDummyDoc, CDocument)
BEGIN_MESSAGE_MAP(CCDummyDoc, CDocument)
END_MESSAGE_MAP()

CCDummyDoc::CCDummyDoc()
{
}

CCDummyDoc::~CCDummyDoc()
{
}

void CCDummyDoc::Serialize(CArchive& ar)
{
	ASSERT(FALSE);
}

