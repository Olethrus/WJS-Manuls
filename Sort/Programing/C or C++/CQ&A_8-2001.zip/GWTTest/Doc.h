////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#pragma once

class CCDummyDoc : public CDocument {
protected:
	CCDummyDoc();
	virtual ~CCDummyDoc();
public:
	virtual void Serialize(CArchive& ar);
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CCDummyDoc)
};
