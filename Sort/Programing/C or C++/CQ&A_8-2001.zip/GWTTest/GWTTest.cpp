////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#include "StdAfx.h"
#include "MainFrm.h"
#include "Doc.h"
#include "View.h"
#include "TraceWin.h"
#include "StatLink.h"
#include "Resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////
// Standard MFC app class
//
class CGWTTesterApp : public CWinApp {
public:
	CGWTTesterApp() { }
	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
} theApp;

BEGIN_MESSAGE_MAP(CGWTTesterApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

BOOL CGWTTesterApp::InitInstance()
{
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CCDummyDoc),
		RUNTIME_CLASS(CMainFrame),
		RUNTIME_CLASS(CMyView));
	AddDocTemplate(pDocTemplate);

	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}

//////////////////
// Custom about dialog uses CStaticLink for hyperlinks.
// URL is specified as string resource or static text
//
class CAboutDialog : public CDialog {
protected:
	// static controls with hyperlinks
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	CStaticLink	m_wndLink3;

public:
	CAboutDialog() : CDialog(IDD_ABOUTBOX) { }
	virtual BOOL OnInitDialog();
};

/////////////////
// Initialize dialog: subclass static text/icon controls
//
BOOL CAboutDialog::OnInitDialog()
{
	// subclass static controls. URL is static text or 3rd arg
	m_wndLink1.SubclassDlgItem(IDC_PDURL,this);
	m_wndLink2.SubclassDlgItem(IDC_MSDNURL,this);
	m_wndLink3.SubclassDlgItem(IDC_MSDNLOGO,this);
	return CDialog::OnInitDialog();
}

//////////////////
// Run the About dialog
//
void CGWTTesterApp::OnAppAbout()
{
	CAboutDialog().DoModal();
}
