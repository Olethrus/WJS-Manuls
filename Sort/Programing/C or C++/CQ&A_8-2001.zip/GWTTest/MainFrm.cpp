////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#include "stdafx.h"
#include "MainFrm.h"
#include "Resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)
BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

CMainFrame::CMainFrame()
{
}

CMainFrame::~CMainFrame()
{
}

//////////////////
// Register main window class: use appropriate styles
//
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= WS_CLIPCHILDREN;
	cs.style &= ~(FWS_ADDTOTITLE|FWS_PREFIXTITLE);
   cs.lpszClass = AfxRegisterWndClass(
      0,											 // no redraw
      NULL,                             // no cursor (use default)
      NULL,                             // no background brush
      AfxGetApp()->LoadIcon(IDR_MAINFRAME)); // app icon
   ASSERT(cs.lpszClass);
	return TRUE;
}

////////////////////
// Create child windows
//
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	VERIFY(CFrameWnd::OnCreate(lpCreateStruct) == 0);
	
	VERIFY(m_wndToolBar.CreateEx(this));
	VERIFY(m_wndToolBar.LoadToolBar(IDR_MAINFRAME));

	VERIFY(m_wndStatusBar.Create(this));
	VERIFY(m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)));

	return 0;
}
