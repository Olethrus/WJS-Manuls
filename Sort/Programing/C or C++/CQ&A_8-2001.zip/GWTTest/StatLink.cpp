////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#include "StdAfx.h"
#include "StatLink.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

COLORREF CStaticLink::g_colorUnvisited = RGB(0,0,255);		 // blue
COLORREF CStaticLink::g_colorVisited   = RGB(128,0,128);		 // purple

HCURSOR	CStaticLink::g_hCursorLink = NULL;

IMPLEMENT_DYNAMIC(CStaticLink, CStatic)

BEGIN_MESSAGE_MAP(CStaticLink, CStatic)
	ON_WM_CREATE()
	ON_WM_NCHITTEST()
	ON_WM_CTLCOLOR_REFLECT()
	ON_WM_LBUTTONDOWN()
	ON_WM_SETCURSOR()
END_MESSAGE_MAP()

///////////////////
// Constructor sets default colors = blue/purple.
//
CStaticLink::CStaticLink(BOOL bDeleteOnDestroy)
{
	m_color = g_colorUnvisited;				// not visited yet
	m_bDeleteOnDestroy = bDeleteOnDestroy;	// delete object with window?
}

//////////////////
// Window control created: initialize
//
int CStaticLink::OnCreate(LPCREATESTRUCT lpcs)
{
	if (CStatic::OnCreate(lpcs)!=0)
		return -1;
	CommonInit();
	return 0;
}

//////////////////
// Window subclassed: initialize
//
void CStaticLink::PreSubclassWindow()
{
	CommonInit();
}

//////////////////
// Common initialization for creation or subclassing.
//
void CStaticLink::CommonInit()
{
	DWORD dwStyle = GetStyle();
	
	HBRUSH hbr = NULL;
	if (IsTextControl()) {
		// this is a text control: set up font and colors
		ASSERT((HFONT)m_font==NULL);
		LOGFONT lf;
		CFont *pFont = GetFont();
		if (pFont) {
			pFont->GetObject(sizeof(lf), &lf);
			lf.lfUnderline = TRUE;
			m_font.CreateFontIndirect(&lf);
		}
	}
}

//////////////////
// Normally, a static control does not get mouse events unless it has
// SS_NOTIFY. This achieves the same effect as SS_NOTIFY, but it's fewer
// lines of code and more reliable than turning on SS_NOTIFY in OnCtlColor
// because Windows doesn't send WM_CTLCOLOR to bitmap static controls.
//
UINT CStaticLink::OnNcHitTest(CPoint point)
{
	return HTCLIENT;
}

//////////////////
// Handle reflected WM_CTLCOLOR to set custom control color. For a text
// control, use visited/unvisited colors and underline font. For non-text
// controls, do nothing.
//
HBRUSH CStaticLink::CtlColor(CDC* pDC, UINT nCtlColor)
{
	ASSERT(nCtlColor == CTLCOLOR_STATIC);
	DWORD dwStyle = GetStyle();
	
	HBRUSH hbr = NULL;
	if (IsTextControl()) {
		// text control: use underline font and visited/unvisited colors
		pDC->SelectObject(&m_font);
		pDC->SetTextColor(m_color);
		pDC->SetBkMode(TRANSPARENT);

		// return hollow brush to preserve parent background color
		hbr = (HBRUSH)::GetStockObject(HOLLOW_BRUSH);
	}
	return hbr;
}

/////////////////
// Handle mouse click: navigate link
//
void CStaticLink::OnLButtonDown(UINT nFlags, CPoint point)
{
	if (m_link.IsEmpty()) {							// try current link
		if (!m_link.LoadString(GetDlgCtrlID()))
			GetWindowText(m_link);
	}
	if (!TryNavigate()) {					// ..and try it
		MessageBeep(0);						// can't navigate!
		TRACE(_T("*** CStaticLink: can't navigate %s!\n"),(LPCTSTR)m_link);
	}
}
			
//////////////////
// Try to navigate the link.
//
BOOL CStaticLink::TryNavigate()
{
	if (m_link.Navigate()) {				 // success!
		m_color = g_colorVisited;			 // change color
		Invalidate();							 // repaint
		return TRUE;
	}
	return FALSE;
}

//////////////////
// Set "hand" cursor to cue user that this is a link. If app has not set
// g_hCursorLink, then try to get the cursor from winhlp32.exe,
// resource 106, which is a pointing finger. This is a bit of a kludge,
// but it works on all versions of Windows.
//
BOOL CStaticLink::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	if (g_hCursorLink == NULL) {
		static bTriedOnce = FALSE;
		if (!bTriedOnce) {
			HMODULE hModule = LoadLibrary(_T("winhlp32.exe"));
			if (hModule) {
				g_hCursorLink =
					CopyCursor(::LoadCursor(hModule, MAKEINTRESOURCE(106)));
			}
			FreeLibrary(hModule);
			bTriedOnce = TRUE;
		}
	}
	if (g_hCursorLink) {
		::SetCursor(g_hCursorLink);
		return TRUE;
	}
	return FALSE;
}

//////////////////
// Normally, a control class is not destoyed when the window is;
// however, CPixieDlg creates static controls with "new" instead of
// as class members, so it's convenient to allow the option of destroying
// object with window. In applications where you create the CStaticLink with
// new, you should call with bDeleteOnDestroy=TRUE.
//
void CStaticLink::PostNcDestroy()
{
	if (m_bDeleteOnDestroy)
		delete this;
}
