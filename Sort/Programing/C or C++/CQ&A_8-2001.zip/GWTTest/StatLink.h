////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#pragma once

//////////////////
// Simple text hyperlink derived from CString
//
class CHyperlink : public CString {
public:
	CHyperlink(LPCTSTR lpLink = NULL) : CString(lpLink) { }
	~CHyperlink() { }
	const CHyperlink& operator=(LPCTSTR lpsz) {
		CString::operator=(lpsz);
		return *this;
	}
	operator LPCTSTR() {
		return CString::operator LPCTSTR(); 
	}
	BOOL Navigate() {
		if (IsEmpty())
			return FALSE;
		HANDLE h = ShellExecute(NULL,_T("open"),*this,0,0,SW_SHOWNORMAL);
		return (UINT)h > 32;
	}
};

//////////////////
// CStaticLink: a static control with hyperlink. Clicking on the control
// navigates the link.
//
class CStaticLink : public CStatic {
public:
	DECLARE_DYNAMIC(CStaticLink)
	CStaticLink(BOOL bDeleteOnDestroy=FALSE);
	~CStaticLink() { }

	// Use this to create a static link from scratch
	BOOL Create(LPCTSTR lpszText, DWORD dwStyle, CWnd* pParentWnd,
		UINT nID = 0xffff, LPCTSTR lpszLink=NULL, RECT rc=CRect(0,0,0,0)) {
		m_link = lpszLink;
		return CStatic::Create(lpszText, dwStyle, rc, pParentWnd, nID);
	}

	// Use to subclass a dialog control and also set different URL
	BOOL SubclassDlgItem(UINT nID, CWnd* pParent, LPCTSTR lpszLink=NULL) {
		m_link = lpszLink;
		return CStatic::SubclassDlgItem(nID, pParent);
	}

	// Hyperlink contains URL/filename. If NULL, I'll try the window text.
	// If that doesn't work, I'll try a resource string w/same ID as control.
	// 
	CHyperlink	m_link;
	COLORREF		m_color;

	// Default colors--you can change.
	// These are global, so they're the same for all links.
	static COLORREF g_colorUnvisited;
	static COLORREF g_colorVisited;

	// Cursor used when mouse is on a link--you can set, or
	// it will default to the standard hand with pointing finger.
	// This is global, so it's the same for all links.
	static HCURSOR	 g_hCursorLink;

protected:
	CFont			m_font;					// underline font for text control
	BOOL			m_bDeleteOnDestroy;	// delete object when window destroyed?

	void CommonInit();
	BOOL TryNavigate();
	BOOL IsTextControl() {
		return (GetStyle() & 0xFF) <= SS_RIGHT;
	}

	virtual void PostNcDestroy();

	// override
	virtual void PreSubclassWindow();

	// message handlers
	DECLARE_MESSAGE_MAP()
	afx_msg int		OnCreate(LPCREATESTRUCT lpcs);
	afx_msg UINT	OnNcHitTest(CPoint point);
	afx_msg HBRUSH CtlColor(CDC* pDC, UINT nCtlColor);
	afx_msg void	OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg BOOL	OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
};
