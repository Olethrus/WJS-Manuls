////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#include "stdafx.h"
#include "View.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

const STRINGLEN=256;

IMPLEMENT_DYNCREATE(CMyView, CListView)
BEGIN_MESSAGE_MAP(CMyView, CListView)
END_MESSAGE_MAP()

CMyView::CMyView()
{
}

CMyView::~CMyView()
{
}

//////////////////
// Pre-create: set report (detailed) mode and no sorting for list control.
//
BOOL CMyView::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style |= LVS_REPORT | LVS_NOSORTHEADER;
	return CListView::PreCreateWindow(cs);
}

void CMyView::OnDraw(CDC* pDC)
{
}

//////////////////
// First-time init: add list control column headers
//
void CMyView::OnInitialUpdate()
{
	CListView::OnInitialUpdate();
	
	const COLWIDTH = 250;
	CListCtrl& lc = GetListCtrl();
	lc.InsertColumn(0, _T("Window"),LVCFMT_LEFT,COLWIDTH);
	lc.InsertColumn(1, _T("ClassName"),LVCFMT_LEFT,COLWIDTH,1);
	lc.InsertColumn(2, _T("GetWindowText"),LVCFMT_LEFT,COLWIDTH,1);
	lc.InsertColumn(3, _T("SendMessageTimeout(WM_GETTEXT)"),LVCFMT_LEFT,COLWIDTH,1);

	PopulateList();
}

//////////////////
// Enumerate all windows: call back to view.
//
BOOL CALLBACK CMyView::MyEnumWindowsProc(HWND hwnd, LPARAM lParam)
{
	CMyView* pView = (CMyView*)lParam;
	pView->AddWindowToList(hwnd);
	return TRUE;
}

//////////////////
// Enumerate child windows: call back to view.
//
BOOL CALLBACK CMyView::MyEnumChildWindowsProc(HWND hwnd, LPARAM lParam)
{
	CMyView* pView = (CMyView*)lParam;
	pView->AddChildWindowToList(hwnd);
	return TRUE;
}

//////////////////
// Populate list: call EnumWindows to enumerate all top-level windows.
//
void CMyView::PopulateList()
{
	CListCtrl& lc = GetListCtrl();
	lc.DeleteAllItems();
	EnumWindows(MyEnumWindowsProc, (LPARAM)this);
}

//////////////////
// Add top-level window to list
//
void CMyView::AddWindowToList(HWND hwnd)
{
	CListCtrl& lc = GetListCtrl();
	int iItem=-1;

	if (hwnd!=GetParentFrame()->GetSafeHwnd()) {
		DWORD dwStyle = GetWindowLong(hwnd, GWL_STYLE);
		if ((dwStyle & WS_OVERLAPPEDWINDOW) && (dwStyle & WS_VISIBLE)) {
			// add window to list
			CString s;
			s.Format("Main Window(%04X)",hwnd);
			iItem = lc.InsertItem(lc.GetItemCount(),s);

			// add window information to list control subitems
			AddWindowInfo(iItem, hwnd);

			// add window's children
			EnumChildWindows(hwnd, MyEnumChildWindowsProc, (LPARAM)this);
		}
	}
}

//////////////////
// Add child window to list--if it's an edit control!
//
void CMyView::AddChildWindowToList(HWND hwnd)
{
	CListCtrl& lc = GetListCtrl();
	int iItem=-1;

	CString s;
	GetClassName(hwnd, s.GetBuffer(STRINGLEN),STRINGLEN);
	s.ReleaseBuffer();
	if (s=="Edit") {
		// found an edit control: add it
		s.Format("  Edit(%04X)",hwnd);
		iItem = lc.InsertItem(lc.GetItemCount(),s);
		AddWindowInfo(iItem, hwnd);
	}
}

//////////////////
// Add window info, either top-level or edit control
//
void CMyView::AddWindowInfo(int iItem, HWND hwnd)
{
	CListCtrl& lc = GetListCtrl();
	CWnd* pWnd = CWnd::FromHandle(hwnd);
	
	int iSubitem = 1;

	// add class name
	CString s;
	::GetClassName(hwnd, s.GetBuffer(STRINGLEN), STRINGLEN);
	lc.SetItemText(iItem,iSubitem++,s);

	// add window text -- use GetWindowText
	pWnd->GetWindowText(s);
	lc.SetItemText(iItem,iSubitem++,s);

	// add window text -- use WM_GETTEXT
	DWORD result;
	SendMessageTimeout(hwnd,
		WM_GETTEXT,
		STRINGLEN,
		(LPARAM)s.GetBuffer(STRINGLEN),
		0,
		1000,
		&result);
	lc.SetItemText(iItem,iSubitem++,s);
	s.ReleaseBuffer();
}
