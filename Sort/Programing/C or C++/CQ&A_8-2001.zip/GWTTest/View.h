////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#pragma once

//////////////////
// View displays list control with window text
//
class CMyView : public CListView {
public:
	virtual ~CMyView();
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

protected:
	CMyView();

	static BOOL CALLBACK MyEnumWindowsProc(HWND hwnd, LPARAM lParam);
	static BOOL CALLBACK MyEnumChildWindowsProc(HWND hwnd, LPARAM lParam);

	void PopulateList();
	void AddWindowToList(HWND hwnd);
	void AddChildWindowToList(HWND hwnd);
	void AddWindowInfo(int iItem, HWND hwnd);

	virtual void OnInitialUpdate(); // called first time after construct

	DECLARE_MESSAGE_MAP()
	DECLARE_DYNCREATE(CMyView)
};


