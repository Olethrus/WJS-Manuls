////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#pragma once

#include "ComToys.h"

//////////////////
// handy to initialize a POINTL
struct CPointL : public POINTL {
	CPointL(long xx, long yy) { x=xx; y=yy; }
};

//////////////////
// class factory used create band objects
//
class CBandObjFactory : public COleObjectFactory {
protected:
	CBandObjFactory* m_pNext;				 // next band factory
	CATID m_catid;								 // band object categroy ID
	UINT	m_nIDRes;							 // resource ID for stuff
	friend class CBandObjDll;
	
public:
	CBandObjFactory(REFCLSID clsid, CRuntimeClass* pClass,
		const CATID& catid, UINT nResID);
	~CBandObjFactory();

	// useful methods
	UINT		GetResourceID()	{ return m_nIDRes; }
	REFCATID GetCategoryID()	{ return m_catid; }

	// substrings must be in the resource string n_IDRes, separated by newline
	CString GetResourceSubstring(UINT n) {
		return PLGetResourceSubstring(GetResourceID(), n);
	}
	CString GetTitle()		{ return GetResourceSubstring(0); }
	CString GetClassName()	{ return GetResourceSubstring(1); }
	CString GetProgID()		{ return GetResourceSubstring(2); }

	// new vertual fn: override to add registry variables
	virtual BOOL OnInitRegistryVariables(IRegistrar* pRegistrar);

	// overrides
	virtual BOOL UpdateRegistry(BOOL bRegister);

	DECLARE_DYNAMIC(CBandObjFactory)
};

//////////////////
// This is here just in case there's ever a need to do
// band-obj stuff derive your DLL from this. Derived from
// COleControlModule to inherit the good initialization stuff
// MFC does in InitInstance/ExitInstance.
//
class CBandObjDll : public COleControlModule {
protected:
	CCriticalSection m_myself;				 // protection for object
	CBandObjFactory* m_pBandFactories;	 // first factory
	CBandObjDll();								 // use in derived class only
	virtual ~CBandObjDll();

public:
	virtual BOOL AddBandClass(REFCLSID clsid, CRuntimeClass* pClass,
		const CATID& catid, UINT nResID);
	CBandObjFactory* GetFactory(REFCLSID clsid);

	// MFC override
	virtual int ExitInstance();

	// so you can override (rare)
	virtual CBandObjFactory* OnCreateFactory(REFCLSID clsid,
		CRuntimeClass* pClass, const CATID& catid, UINT nResID);

	DECLARE_DYNAMIC(CBandObjDll);
};

DECLARE_SMARTPTR(IInputObjectSite)


//////////////////
// The band object! Common implementation for info, comm and desk bands.
// This is a CWnd, and it also inherits all the band object COM interfaces.
//
class CBandObj : public CWnd {
protected:
	SPIInputObjectSite m_spSite;	// smart ptr to input site
	DESKBANDINFO m_dbiDefault;		// default band info
	REFIID	m_clsid;					// ref to class ID
	CString	m_strTitle;				// window title
	UINT		m_nIDRes;				// resource ID
	DWORD		m_dwBandID;				// band ID (from Windows)
	DWORD		m_dwViewMode;			// view mode (from Windows)
	CMenu		m_contextMenu;			// context menu
	HACCEL	m_hAccel;				// accelerators
	BOOL		m_bModified;			// always FALSE;

	friend CBandObjFactory;
	void InitMenuItem(CCmdTarget* pTarg, CMenu& menu, UINT nIndex);

public:
	static BOOL bTRACE; // controls tracing

	CBandObj(REFCLSID clsid);
	virtual ~CBandObj();

	UINT		GetResourceID()	{ return m_nIDRes; }
	CString	GetTitle()			{ return m_strTitle; }

	// overrides
	virtual void OnFinalRelease();

	// MFC overrides
	virtual BOOL OnCmdMsg(UINT, int, void*, AFX_CMDHANDLERINFO*);

	// new fns
	virtual void		OnFocusChange(BOOL bFocus);
	virtual BOOL		OnCreateWindow(CWnd* pParent, const CRect& rc);
	virtual HRESULT	OnSetSite(IUnknown* pSite);
	virtual BOOL		OnTranslateAccelerator(LPMSG pMsg);

   // COM interfaces
	DECLARE_INTERFACE_MAP()

	// IUnknown--all nested versions call these
	STDMETHOD_(ULONG, AddRef)();
	STDMETHOD_(ULONG, Release)();
	STDMETHOD(QueryInterface)(REFIID iid, LPVOID* ppvObj);

	BEGIN_INTERFACE_PART(DeskBand, IDeskBand);
   STDMETHOD (GetWindow) (HWND*);				// IOleWindow
   STDMETHOD (ContextSensitiveHelp) (BOOL);
   STDMETHOD(ShowDW) (BOOL fShow);				// IDockingWindow
   STDMETHOD(CloseDW) (DWORD dwReserved);
   STDMETHOD(ResizeBorderDW) (LPCRECT prcBorder,
		IUnknown* punkDWSite, BOOL fReserved);
   STDMETHOD (GetBandInfo) (DWORD, DWORD, DESKBANDINFO*);    // IDeskBand
	END_INTERFACE_PART(DeskBand);

	// IPersistStream
	BEGIN_INTERFACE_PART(PersistStream, IPersistStream);
	STDMETHOD(GetClassID)(LPCLSID pClassID);
   STDMETHOD(IsDirty)(void);
   STDMETHOD(Load)(LPSTREAM);
   STDMETHOD(Save)(LPSTREAM, BOOL);
   STDMETHOD(GetSizeMax)(ULARGE_INTEGER*);
	END_INTERFACE_PART(PersistStream);

	// IInputObject
	BEGIN_INTERFACE_PART(InputObject, IInputObject);
   STDMETHOD (UIActivateIO) (BOOL, LPMSG);
   STDMETHOD (HasFocusIO) (void);
   STDMETHOD (TranslateAcceleratorIO) (LPMSG);
	END_INTERFACE_PART(InputObject);

	// IContextMenu
	BEGIN_INTERFACE_PART(ContextMenu, IContextMenu);
   STDMETHOD (QueryContextMenu)(HMENU, UINT, UINT, UINT, UINT);
   STDMETHOD (InvokeCommand)(LPCMINVOKECOMMANDINFO);
   STDMETHOD (GetCommandString)(UINT, UINT, UINT*, LPSTR, UINT);
	END_INTERFACE_PART(ContextMenu);

	// IObjectWithSite
	BEGIN_INTERFACE_PART(ObjectWithSite, IObjectWithSite);
   STDMETHOD (SetSite) (IUnknown* pUnk);
   STDMETHOD (GetSite) (REFIID iid, void** ppv);
	END_INTERFACE_PART(ObjectWithSite);

protected:
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg int  OnMouseActivate(CWnd* pDesktopWnd, UINT nHitTest, UINT message);
	DECLARE_MESSAGE_MAP();
	DECLARE_DYNAMIC(CBandObj)
};
