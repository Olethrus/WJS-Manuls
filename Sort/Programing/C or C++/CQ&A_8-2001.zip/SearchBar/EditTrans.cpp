////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#include "stdafx.h"
#include "EditTrans.h"

/////////////////
// Translate edit control "accelerators."
// If I forgot any, you can add them here.
//
BOOL TranslateEditAccelerator(HWND hwndEdit, MSG* pMsg)
{
	UINT msg = pMsg->message;
	if (WM_KEYFIRST<=msg && msg<=WM_KEYLAST) {
		int key = (int)pMsg->wParam;
		switch(key) {
		case VK_BACK:
			// edit controls handle Backspace via WM_CHAR
			if (msg==WM_KEYDOWN) {
				// on keydown, pass to edit as WM_CHAR
				::SendMessage(hwndEdit, WM_CHAR, key, pMsg->lParam);
			}
			return TRUE;
		case VK_LEFT:
		case VK_RIGHT:
		case VK_HOME:
		case VK_END:
			// edit controls handle these keys via WM_KEYDOWN
			if (msg==WM_KEYDOWN) {
				// on keydown, pass to edit as WM_KEYDOWN
				::SendMessage(hwndEdit, WM_KEYDOWN, key, pMsg->lParam);
			}
			return TRUE;
		}
	}
	return FALSE;
}
