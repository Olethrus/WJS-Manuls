////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//

/////////////////
// Function to translate edit control "accelerators"
//
BOOL TranslateEditAccelerator(HWND hwndEdit, MSG* pMsg);
