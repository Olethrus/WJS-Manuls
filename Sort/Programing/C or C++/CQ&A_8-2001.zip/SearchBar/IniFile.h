////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
// ----
// CIniFile lets you put profile settings in a .INI file instead
// of the registry. To use it, write:
//
//	CIniFile::Use(this, CIniFile::WindowsINI); // put INI file in \WINDOWS dir
//	CIniFile::Use(this, CIniFile::LocalINI);	 // put it in same dir as pgm
//
// where "this" is a ptr to your CWinApp/
// Normally do this in your app's InitInstance fn.
//
class CIniFile {
public:
	enum { WinDir, LocalDir };
	static void Use(CWinApp *pApp, int where, LPCTSTR pszFile=NULL);
};
