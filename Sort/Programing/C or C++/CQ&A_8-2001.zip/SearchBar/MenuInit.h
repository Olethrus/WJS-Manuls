////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#pragma once

#include "Subclass.h"

//////////////////
// Initialize any menu by routing through any MFC command target.
//
class CPopupMenuInit {
public:
	static void Init(CCmdTarget* pTarg,
		CMenu* pMenu, BOOL bAutoMenuEnable=TRUE);
};

//////////////////
// Handles WM_INITMENUPOPUP on behalf of any CWnd object.
//
class CPopupMenuInitHandler: public CSubclassWnd {
public:
	BOOL m_bAutoMenuEnable;		// disable menu items w/no handler?
	CPopupMenuInitHandler();
	virtual ~CPopupMenuInitHandler();
	BOOL Install(CWnd* pWnd)	{ return HookWindow(pWnd); }
	void Remove()					{ HookWindow((HWND)NULL); }
protected:
	virtual void OnMenuInitPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu);
	virtual LRESULT WindowProc(UINT msg, WPARAM wp, LPARAM lp);
};