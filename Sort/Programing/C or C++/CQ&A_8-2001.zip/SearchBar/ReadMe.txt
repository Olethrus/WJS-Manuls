Dear readers,

SearchBar is a modified version of the band object first presented in the
November and December 1999 issues of MSJ. For a full explanation of the code
and band objects, see those articles.

This modified version for the August 2001 MSDN Magazine shows how to make the
Backspace key work for an edit control inside a band object. See my C++ Q&A
column for an explanation of the modifications.

Happy Programming!

Paul DiLascia
May 2001
