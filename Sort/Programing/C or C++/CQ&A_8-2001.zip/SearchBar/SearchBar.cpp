////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#include "StdAfx.h"
#include "SearchBar.h"
#include "Debug.h"
#include "TraceWin.h"
#include "resource.h"
#include "ComToys.h"
#include "IniFile.h"
#include "EditTrans.h"
#include <initguid.h> // so my GUIDs are created

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

IMPLEMENT_DYNAMIC(CSearchBarDll, CBandObjDll)
BEGIN_MESSAGE_MAP(CSearchBarDll, CBandObjDll)
END_MESSAGE_MAP()

CSearchBarDll theApp;

// {4647E383-520B-11d2-A0D0-004033D0645D}
DEFINE_GUID(CLSID_MYDESKBAND,
0x4647e383, 0x520b, 0x11d2, 0xa0, 0xd0, 0x0, 0x40, 0x33, 0xd0, 0x64, 0x5d);

// {4647E384-520B-11d2-A0D0-004033D0645D}
DEFINE_GUID(CLSID_MYEXPLRBAR,
0x4647e384, 0x520b, 0x11d2, 0xa0, 0xd0, 0x0, 0x40, 0x33, 0xd0, 0x64, 0x5d);

CSearchBarDll::CSearchBarDll()
{
	CBandObj::bTRACE=TRUE; // TRACEing on for bandobj
}

CSearchBarDll::~CSearchBarDll()
{
}

//////////////////
// initialize: add each band class
//
BOOL CSearchBarDll::InitInstance()
{
	TRACEFN(_T("CSearchBarDll::InitInstance\n"));
	CIniFile::Use(this, CIniFile::LocalDir); // use .INI file in program dir

	VERIFY(AddBandClass(CLSID_MYDESKBAND,
		RUNTIME_CLASS(CMyDeskBand),
		CATID_DeskBand,
		IDR_DESKBAND));

	VERIFY(AddBandClass(CLSID_MYEXPLRBAR,
		RUNTIME_CLASS(CMyExplrBar),
		CATID_DeskBand,
		IDR_EXPLRBAR));

	return CBandObjDll::InitInstance();
}

//////////////// CMyDeskBand ////////////////

IMPLEMENT_DYNCREATE(CMyDeskBand, CBandObj)
BEGIN_MESSAGE_MAP(CMyDeskBand, CBandObj)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_SETFOCUS()
	ON_EN_SETFOCUS(1, OnEnSetFocus)
	ON_EN_KILLFOCUS(1, OnEnKillFocus)
END_MESSAGE_MAP()
IMPLEMENT_DYNCREATE(CMyExplrBar, CMyDeskBand)

CMyDeskBand::CMyDeskBand() : CBandObj(CLSID_MYDESKBAND),
	m_wndEdit(_T("SearchStrings"))
{
	const CXDESIRED = 100;	 // desired width = 100
	m_dbiDefault.ptActual  = CPointL(CXDESIRED,0);
	m_dbiDefault.dwModeFlags = DBIMF_VARIABLEHEIGHT;
}

CMyDeskBand::~CMyDeskBand()
{
}

BOOL CMyDeskBand::PreCreateWindow(CREATESTRUCT& cs)
{
	cs.style &= ~WS_BORDER;
	return CBandObj::PreCreateWindow(cs);
}

//////////////////
// I'm being created: create edit control and set band obj
// context menu from edit search control
//
int CMyDeskBand::OnCreate(LPCREATESTRUCT lpcs)
{
	TRACE(_T("CMyDeskBand::OnCreate\n"));
	if (CBandObj::OnCreate(lpcs)==-1)
		return -1;
	m_wndEdit.Create(WS_VISIBLE|WS_CHILD|WS_BORDER, CRect(0,0,0,0), this, 1);
	m_wndEdit.CreateSearchMenu(m_contextMenu);
	return 0;
}

//////////////////
// Window was resized: adjust edit control
//
void CMyDeskBand::OnSize(UINT nType, int cx, int cy)
{
	TRACE(_T("CMyDeskBand::OnSize(%d,%d)\n"),cx,cy);
	int h = min(m_wndEdit.GetDesiredHeight(),cy);
	int cyMargin = (cy-h)/2;
	CRect rc(CPoint(1,cyMargin),CSize(cx-2,h));
	rc.DeflateRect(2,0);

	m_wndEdit.SetWindowPos(NULL, rc.left, rc.top, rc.Width(), rc.Height(), 0);
}

//////////////////
// Route commands through edit control, then me.
// This is standard MFC command plumbing.
//
BOOL CMyDeskBand::OnCmdMsg(UINT a, int b, void* c, AFX_CMDHANDLERINFO* d)
{
	return m_wndEdit.OnCmdMsg(a, b, c, d) ? TRUE :
		CBandObj::OnCmdMsg(a, b, c, d);
}

void CMyDeskBand::OnSetFocus(CWnd* pOldWnd)
{
	m_wndEdit.SetFocus();
}

void CMyDeskBand::OnEnSetFocus()
{
	TRACE(_T("CMyDeskBand::OnEnSetFocus\n"));
	OnFocusChange(TRUE);
}

void CMyDeskBand::OnEnKillFocus()
{
	TRACE(_T("CMyDeskBand::OnEnKillFocus\n"));
	OnFocusChange(FALSE);
}

//////////////////
// Override CBandObj to translate edit control keys. Just do it.
// There may be some keys I missed--if so, just add them here.
//
BOOL CMyDeskBand::OnTranslateAccelerator(LPMSG pMsg)
{
	TRACE(_T("CMyDeskBand::OnTranslateAccelerator(%s, %d)...\n"),
		_TR(pMsg->message), pMsg->wParam);

	if (TranslateEditAccelerator(m_wndEdit, pMsg))
		return TRUE;
	return CBandObj::OnTranslateAccelerator(pMsg);
}

