////////////////////////////////////////////////////////////////
// MSDN Magazine -- August 2001
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0. Runs on Win 98 and probably Win 2000 too.
// Set tabsize = 3 in your editor.
//
#include "Resource.h"
#include "BandObj.h"
#include "EditSearch.h"

//////////////////
// Application class: derive from CBandObjApp
//
class CSearchBarDll : public CBandObjDll {
public:
	CSearchBarDll();
	virtual ~CSearchBarDll();
	virtual BOOL InitInstance();
protected:
	DECLARE_MESSAGE_MAP()
	DECLARE_DYNAMIC(CSearchBarDll)
};

DECLARE_SMARTPTR(IWebBrowser2);

//////////////////
// Desk band lives in task bar
//
class CMyDeskBand : public CBandObj {
public:
	CMyDeskBand();
	~CMyDeskBand();

protected:
	CEditSearch m_wndEdit;

	// CBandObj override
	virtual BOOL OnTranslateAccelerator(LPMSG pMsg);

	// MFC override
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnCmdMsg(UINT nID, int nCode, void* pExtra,
		AFX_CMDHANDLERINFO* pHandlerInfo);

	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnEnSetFocus();
	afx_msg void OnEnKillFocus();
	DECLARE_MESSAGE_MAP();
	DECLARE_DYNCREATE(CMyDeskBand)
};

////////////////
// Explorer bar lives in Internet/Windows Explorer.  It uses the same code as
// CMyDeskBand, the only thing different is it has to be registered
// differently and for that it needs a different resource ID, CLSID and MFC
// runtime class. So I simply derive from CMyDeskBand without implementing
// any new code.
//
class CMyExplrBar : public CMyDeskBand {
public:
	CMyExplrBar() {}
	~CMyExplrBar() {}
	DECLARE_DYNCREATE(CMyExplrBar)
};
