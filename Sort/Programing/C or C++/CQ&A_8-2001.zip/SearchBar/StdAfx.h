#include <afxwin.h>         // MFC core and standard components
#include <afxpriv.h>        // For Unicode conversion macros

