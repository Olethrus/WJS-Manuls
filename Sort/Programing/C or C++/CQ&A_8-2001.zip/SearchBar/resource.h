//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SearchBar.rc
//
#define IDR_DESKBAND                    1
#define IDR_EXPLRBAR                    2
#define IDD_ABOUTBOX                    3
#define IDC_MSDNLOGO                    1000
#define IDC_PDURL                       1001
#define IDC_MSDNURL                     1003
#define ID_COMMAND1                     1004
#define ID_COMMAND2                     1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        100
#define _APS_NEXT_COMMAND_VALUE         1006
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
