﻿namespace TeamFoundation.Build.ActivityPack.Tests
{
    using System;
    using System.Activities;
    using System.Collections.Generic;
    using System.Globalization;
    using System.IO;

    using Microsoft.TeamFoundation.Build.Client;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    using Mocks;

    /// <summary>
    /// Tests to verify the functionality of the UpdateVersionInfo activity
    /// </summary>
    [TestClass]
    public class UpdateVersionInfo
    {
        #region Fields

        private static String _sourcesDirectory;

        #endregion Fields

        #region Properties

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get; set;
        }

        /// <summary>
        /// Path to a "Sources" directory beneath the working directory
        /// (the TestResults folder in this case). This directory will be used
        /// to store the canonical AssemblyInfo files for testing.
        /// </summary>
        private static String SourcesDirectory
        {
            get
            {
                if (String.IsNullOrEmpty(_sourcesDirectory))
                {
                    var pathSources = Path.Combine(Environment.CurrentDirectory, "Sources");
                    var sourcesDir = new DirectoryInfo(pathSources);

                    if (!sourcesDir.Exists)
                        sourcesDir = Directory.CreateDirectory(pathSources);

                    _sourcesDirectory = sourcesDir.FullName;
                }

                return _sourcesDirectory;
            }
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Exercise the mainline scenario for the UpdateVersionInfo workflow
        /// activity by specifying a valid file specification, sources directory
        /// and regular expression.
        /// <remarks>
        /// This method is dependent on the BuildDetail class in the Mocks assembly
        /// to provide a build number with the appropriate format.
        /// </remarks>
        /// </summary>
        [TestMethod]
        public void MainlineScenario()
        {
            // Create an instance of our test workflow
            var workflow = new TestWorkflow();

            // Declare a list of the AssemblyInfo files we'll be using for the test
            List<Tuple<String, String>> resourceFiles = new List<Tuple<String, String>>() {
                new Tuple<String, String>("AssemblyInfo.cs", Resources.AssemblyInfo_cs),
                new Tuple<String, String>("AssemblyInfo.vb", Resources.AssemblyInfo_vb),
                new Tuple<String, String>("AssemblyInfo.cpp", Resources.AssemblyInfo_cpp),
            };

            // Write each file out to the "Sources" directory with a suitable file name
            foreach (Tuple<String, String> tuple in resourceFiles)
            {
                using (StreamWriter writer = File.CreateText(
                    Path.Combine(SourcesDirectory, tuple.Item1)))
                {
                    writer.Write(tuple.Item2);
                    writer.Flush();
                    writer.Close();
                }
            }

            // Create the workflow run-time environment
            var workflowInvoker = new WorkflowInvoker(workflow);

            // New up an instance of our mock BuildDetail object to add to the Workflow
            // environment's extensions
            workflowInvoker.Extensions.Add(new BuildDetail());

            // Set the in arguments for the workflow as specified
            workflow.SourceDir = SourcesDirectory;
            workflow.FileSpec = "AssemblyInfo.*";

            // Invoke the workflow and capture the outputs
            IDictionary<String, Object> outputs = workflowInvoker.Invoke();

            // Retrieve the out arguments to do our verification
            var buildDetail = (IBuildDetail)outputs["BuildDetail"];
            var versionInfo = (String)outputs["VersionInfo"];

            // Leave the source files in the test outputs so that we can manually
            // review them if desired
            //Directory.Delete(sourceDir.FullName);

            // Verify that we captured the version component of the build number
            Assert.IsTrue(buildDetail.BuildNumber.Contains(versionInfo));
        }

        /// <summary>
        /// Test the case where the user specifies an empty FileSpec.
        /// <remarks>
        /// This method is dependent on the BuildDetail class in the Mocks assembly
        /// to provide a build number with the appropriate format. Note that the 
        /// FileSpec property's default value is "AssemblyInfo.*"
        /// </remarks>
        /// </summary>
        [TestMethod]
        public void NoFileSpecSpecified()
        {
            // another way of specifying in arguments to our workflow
            var workflow = new TestWorkflow() {
                SourceDir = SourcesDirectory,
                FileSpec = String.Empty
            };

            // create the workflow run-time environment and add our mock
            // BuildDetail object.
            var workflowInvoker = new WorkflowInvoker(workflow);
            workflowInvoker.Extensions.Add(new BuildDetail());

            try
            {
                workflowInvoker.Invoke();
            }
            catch (ArgumentException ex)
            {
                // this is the expected exception - verify that the parameter is correct
                if (String.Compare(ex.ParamName, "FileSpec", true, CultureInfo.InvariantCulture) != 0)
                    Assert.Fail(ex.Message);
            }
        }

        /// <summary>
        /// Test the scenario where the user forgets to specify the source directory
        /// for the UpdateVersionInfo activity.
        /// <remarks>
        /// This method is dependent on the BuildDetail class in the Mocks assembly
        /// to provide a build number with the appropriate format.
        /// </remarks>
        /// </summary>
        [TestMethod]
        public void NoSourceDirectorySpecified()
        {
            // New up the workflow and an inputs collection
            var workflow = new TestWorkflow();
            var inputs = new Dictionary<String, Object>();

            // Create the workflow run-time environment and add our
            // mock BuildDetail object
            var workflowInvoker = new WorkflowInvoker(workflow);
            workflowInvoker.Extensions.Add(new BuildDetail());

            try
            {
                // illustrating another way of passing in arguments
                inputs["SourceDir"] = null;
                inputs["FileSpec"] = "AssemblyInfo.*";
                var outputs = workflowInvoker.Invoke(inputs);
            }
            catch (ArgumentException ex)
            {
                // this is the expected exception - verify that the parameter is set correctly
                if (String.Compare(ex.ParamName, "SourcesDirectory", true, CultureInfo.InvariantCulture) != 0)
                    Assert.Fail(ex.Message);
            }
        }

        #endregion Methods

        #region Other

        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test
        // [TestInitialize()]
        // public void MyTestInitialize() { }
        //
        // Use TestCleanup to run code after each test has run
        // [TestCleanup()]
        // public void MyTestCleanup() { }
        //

        #endregion Other
    }
}