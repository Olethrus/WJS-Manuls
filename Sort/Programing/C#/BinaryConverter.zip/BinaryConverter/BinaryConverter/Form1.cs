using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BinaryConverter
{
    //This program uses the algorithm in which the base 10 number is divided by 2^n,( where n>(log x)/(log 2) )
    //then by 2^(n-1), then by 2^(n-2), and so on until n=0.
    public partial class Form1 : Form
    {
        //Input
        double x;

        double y;
        double z = 1;
        double i = 0;
        
        //Static base variable
        double fix = 2;

        string Output = null;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void Calculate()
        {
            z = 1;
            i = 0;
            fix = 2;
            Output = null;
            label1.Text = null;
            Output = null;
            try
            {
                x = double.Parse(textBox1.Text);
            }
            catch
            {
                MessageBox.Show("Please enter a valid real number.");
                x = 0;
                z = 0.3;
            }
            if (x < 0)
            {
                x = Math.Abs(x);
                Output = "-";
            }
                
            while (x >= z * fix)
            {
                z = Math.Pow(fix, i);
                i++;
            }
            while (z >= 1)
            {
                y = x - z;
                if (y < 0)
                {
                    label1.Text = Output + "0";
                    Output = label1.Text;
                }
                else
                {
                    label1.Text = Output + "1";
                    Output = label1.Text;
                    x = y;
                }
                z = z / 2;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Calculate();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            //If enter key is pressed:
            if (e.KeyChar == 13)
            {
                Calculate();
            }
        }    
    }
}