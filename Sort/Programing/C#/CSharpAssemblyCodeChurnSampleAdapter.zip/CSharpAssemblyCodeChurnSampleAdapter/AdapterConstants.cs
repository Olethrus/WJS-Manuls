﻿//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************
namespace CSharpAssemblyCodeChurnSample.Adapter
{
    /// <summary>
    /// This class has some general constants used throughout the adapter.
    /// 
    /// These could come out of metadata, but for simplicity they are just explicitly defined here.
    /// </summary>
    static class AdapterConstants
    {
        #region Nested Types

        /// <summary>
        /// The TFS out-of-box Code Churn table.
        /// </summary>
        public static class CodeChurnTable
        {
            #region Fields

            public const string AnalysisDimensionName = "Fact Code Churn";
            public const string AnalysisOverlayTableName = @"vFactCodeChurnOverlay";

            #endregion Fields
        }

        /// <summary>
        /// The CSharp Assembly table.
        /// </summary>
        public static class CSharpAssemblyTable
        {
            #region Fields

            public const string AnalysisDimensionKeyFieldName = @"Assembly Name";
            public const string AnalysisDimensionName = "C Sharp Assembly";
            public const string AnalysisDimensionOutputTypeFieldName = @"Type";
            public const string AnalysisDsvTableName = @"dbo_" + TableName;
            public const string AssemblyNameColumnName = @"AssemblyName";
            public const string BusinessKeyFieldName = BaseName + @"BK";
            public const string DestroyDataStoredProcedureName = @"prc_Dimension_" + TableName + @"_Destroy";
            public const string LoadDataStoredProcedureName = @"prc_Dimension_" + TableName + @"_AddUpdate";
            public const string OutputTypeColumnName = @"OutputType";
            public const string SurrogateKeyFieldName = BaseName + @"SK";
            public const string TableName = @"Dim" + BaseName;
            public const string TeamProjectCollectionKeyColumnName = @"TeamProjectCollectionSK";

            private const string BaseName = @"CSharpAssembly";

            #endregion Fields
        }

        /// <summary>
        /// The CSharp Assembly to Files mapping table.
        /// </summary>
        public static class CSharpAssemblyToFilesMappingTable
        {
            #region Fields

            public const string AnalysisDimensionName = @"C Sharp Assembly to File";
            public const string AnalysisDsvTableName = @"dbo_" + TableName;
            public const string BusinessKeyFieldName = BaseName + @"BK";
            public const string LoadDataStoredProcedureName = @"prc_Fact_" + TableName + @"_AddUpdate";
            public const string SurrogateKeyFieldName = BaseName + @"SK";
            public const string TableName = @"Fact" + BaseName;

            private const string BaseName = @"CSharpAssemblyToFiles";

            #endregion Fields
        }

        /// <summary>
        /// Data serialization for this adapter's ETL uses these formats.
        /// </summary>
        public static class DataSerialization
        {
            #region Fields

            public const string SqlBatchName = @"dataSet";
            public const string SqlBatchXmlRootElement = @"ds";
            public const string SqlBatchXmlRowElement = @"r";
            public const string SqlDateTimeFormat = @"yyyy-MM-ddTHH:mm:ss.fff";

            #endregion Fields
        }

        /// <summary>
        /// The TFS out-of-box File table.
        /// </summary>
        public static class FileTable
        {
            #region Fields

            public const string AnalysisDimensionName = "File";
            public const string AnalysisDsvTableName = @"dbo_" + TableName;
            public const string BusinessKeyFieldName = BaseName + @"BK";
            public const string SurrogateKeyFieldName = BaseName + @"SK";
            public const string TableName = @"Dim" + BaseName;

            private const string BaseName = @"File";

            #endregion Fields
        }

        /// <summary>
        /// The TFS out-of-box Team Project table.
        /// </summary>
        public static class TeamProjectTable
        {
            #region Fields

            public const string AnalysisDsvTableName = @"dbo_DimTeamProject";
            public const string SurrogateKeyFieldName = @"ProjectNodeSK";

            #endregion Fields
        }

        public static class WarehouseCustomSqlErrors
        {
            #region Fields

            /// <summary>
            /// General error when parsing the xml data set parameter.
            /// </summary>
            public const int XmlParsingError = 6000001;

            #endregion Fields
        }

        /// <summary>
        /// Some Log Ids used by this adapter.
        /// </summary>
        /// <remarks>
        /// Ideally these would be tied to the resources for the errors.  For simplicity this is not done in this project.
        /// </remarks>
        internal static class LogId
        {
            #region Fields

            public const string EventSource = "CSharpAssemblyCodeChurnSampleAdapter";
            public const int FailedParsingProjectFile = 11928;
            public const string LogName = "Application";

            #endregion Fields
        }

        #endregion Nested Types
    }
}