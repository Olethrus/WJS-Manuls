﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace CSharpAssemblyCodeChurnSample.Adapter
{
    using System;
    using System.Data;
    using System.Data.OleDb;
    using System.Diagnostics;
    using System.Globalization;
    using System.Threading;

    using Microsoft.TeamFoundation.Warehouse;

    using Analysis = Microsoft.AnalysisServices;

    /// <summary>
    /// Analysis Database helper class.
    /// 
    /// This creates the schema required in the Analysis Database.
    /// </summary>
    /// <remarks>
    /// This does not add the translations required for a fully localized cube.  
    /// These should be added.
    /// </remarks>
    class AnalysisDatabase
    {
        #region Fields

        /// <summary>
        /// Format string for the count measure name.
        /// Parameters: {0} = Measure Group name.
        /// </summary>
        private const string CountMeasureNameFormat = @"{0} Count";

        /// <summary>
        /// Format string for a data relation name.
        /// Parameters: {0} = Parent Table name
        ///             {1} = Parent Column name.
        ///             {2} = Child Table name.
        ///             {3} = Child Column name.
        /// </summary>
        private const string DataRelationNameFormat = @"FK_{0}_{1}_{2}_{3}";

        /// <summary>
        /// Format string for a unique constraint name.
        /// Parameters: {0} = DSV Table name.
        ///             {1} = Column name.
        /// </summary>
        private const string UniqueConstraintNameFormat = @"{0}_{1}_PKConstraint";

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Create a new AnalysisDatabase helper.
        /// </summary>
        /// <param name="warehouseContext"></param>
        public AnalysisDatabase(WarehouseContext warehouseContext)
        {
            WarehouseContext = warehouseContext;

            TranslationLocaleId = Thread.CurrentThread.CurrentUICulture.LCID;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// The translation locale id to use for cube translations.
        /// </summary>
        private int TranslationLocaleId
        {
            get; set;
        }

        /// <summary>
        /// The Warehouse context.
        /// </summary>
        private WarehouseContext WarehouseContext
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        public void CreateSchema()
        {
            // Some adapters need to transform the data in the Warehouse before it is read into the cube.  This is usually
            // done with views - the DSV is linked with the view instead of the underlying table.  If these views are required
            // they should probably be created here, as part of creating the Analysis Schema.

            // Update the Analysis db.
            CreateAnalysisSchema();
        }

        /// <summary>
        /// Create all the regular mappings between the dimensions and measure groups.
        /// </summary>
        /// <param name="analysisComponent">Analysis Services Component.</param>
        private static void AddCSharpAssemblyToFileRegularMappingsToCube(AnalysisServicesComponent analysisComponent)
        {
            Debug.Assert(analysisComponent.TeamSystemCube.MeasureGroups.Contains(
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName));

            var assemblyToFileMeasureGroup = analysisComponent.TeamSystemCube.MeasureGroups[
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName];

            // Add the Regular Measure Group Dimensions mapping CSharpAssemblyToFile to File.
            var fileDimension = analysisComponent.TeamSystemDatabase.Dimensions[
                AdapterConstants.FileTable.AnalysisDimensionName];

            var assemblyToFileFileMapping = new Analysis::RegularMeasureGroupDimension(fileDimension.ID);
            assemblyToFileMeasureGroup.Dimensions.Add(assemblyToFileFileMapping);

            var assemblyToFileFileAttribute = assemblyToFileFileMapping.Attributes.Add(fileDimension.KeyAttribute.ID);
            assemblyToFileFileAttribute.Type = Analysis::MeasureGroupAttributeType.Granularity;

            assemblyToFileFileAttribute.KeyColumns.Add(
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDsvTableName, // CSharp Assembly to File mapping table name.
                AdapterConstants.FileTable.SurrogateKeyFieldName,                        // File Key column name in CSharp Assembly to File table.
                OleDbType.Integer);

            // Add the Regular Measure Group Dimensions mapping CSharpAssemblyToFile to CSharpAssembly.
            var assemblyDimension = analysisComponent.TeamSystemDatabase.Dimensions[
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName];

            var assemblyToFileAssemblyMapping = new Analysis::RegularMeasureGroupDimension(assemblyDimension.ID);
            assemblyToFileMeasureGroup.Dimensions.Add(assemblyToFileAssemblyMapping);

            var assemblyToFileAssemblyAttribute = assemblyToFileAssemblyMapping.Attributes.Add(
                AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName);
            assemblyToFileAssemblyAttribute.Type = Analysis::MeasureGroupAttributeType.Granularity;

            assemblyToFileAssemblyAttribute.KeyColumns.Add(
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDsvTableName,  // CSharp Assembly to File mapping table name.
                AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName,               // CSharp Assembly Key column name in CSharp Assembly to File table.
                OleDbType.Integer);
        }

        /// <summary>
        /// Create the many to many mapping from CSharp Assembly to File to Code Churn.
        /// </summary>
        /// <param name="analysisComponent">Analysis Services Component.</param>
        private static void AddCSharpAssemblyToFileToCodeChurnMappingToCube(AnalysisServicesComponent analysisComponent)
        {
            Debug.Assert(analysisComponent.TeamSystemDatabase.Dimensions.Contains(
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName));
            Debug.Assert(analysisComponent.TeamSystemCube.MeasureGroups.Contains(
                AdapterConstants.CodeChurnTable.AnalysisDimensionName));
            Debug.Assert(analysisComponent.TeamSystemCube.MeasureGroups.Contains(
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName));

            var assemblyDimension = analysisComponent.TeamSystemDatabase.Dimensions[
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName];
            var assemblyToFileMeasureGroup = analysisComponent.TeamSystemCube.MeasureGroups[
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName];

            // Add the Many to Many Measure Group Dimension mapping to Code Churn.
            var codeChurnAssemblyMapping = new Analysis.ManyToManyMeasureGroupDimension(
                assemblyDimension.ID, assemblyToFileMeasureGroup.ID);
            analysisComponent.TeamSystemCube.MeasureGroups[AdapterConstants.CodeChurnTable.AnalysisDimensionName].
                Dimensions.Add(codeChurnAssemblyMapping);

            analysisComponent.TeamSystemCube.Update(Analysis::UpdateOptions.ExpandFull);
        }

        /// <summary>
        /// Add a data relation from the parent table/column to the child table/column.
        /// </summary>
        /// <param name="analysisComponent"></param>
        /// <param name="parentTableName"></param>
        /// <param name="parentColumnName"></param>
        /// <param name="childTableName"></param>
        /// <param name="childColumnName"></param>
        private static void AddDataRelation(AnalysisServicesComponent analysisComponent, 
            string parentTableName, string parentColumnName,
            string childTableName, string childColumnName)
        {
            var relationName = String.Format(CultureInfo.InvariantCulture,
                DataRelationNameFormat,
                parentTableName,
                parentColumnName,
                childTableName,
                childColumnName);

            if (!analysisComponent.TeamSystemWarehouseDataSourceView.Schema.Relations.Contains(relationName))
            {
                var parentColumn = analysisComponent.TeamSystemWarehouseDataSourceView.Schema.Tables[parentTableName].Columns[parentColumnName];
                var childColumn = analysisComponent.TeamSystemWarehouseDataSourceView.Schema.Tables[childTableName].Columns[childColumnName];

                var dataRelation = new DataRelation(relationName, parentColumn, childColumn, true);

                analysisComponent.TeamSystemWarehouseDataSourceView.Schema.Relations.Add(dataRelation);
                analysisComponent.TeamSystemWarehouseDataSourceView.Update();
            }
        }

        /// <summary>
        /// Find an existing Translation for an LCID or create a new one if it doesn't exist.
        /// </summary>
        /// <param name="translationCollection">TranslationCollection or AttributeTranslationCollection.</param>
        /// <param name="translationLocaleId">Local Id.</param>
        /// <returns></returns>
        private static Analysis::Translation FindCreateTranslation(Analysis::TranslationCollection translationCollection, int translationLocaleId)
        {
            var cubeTranslation = translationCollection.FindByLanguage(translationLocaleId);

            if (cubeTranslation == null)
            {
                // Note:  This method is required even though AttributeTranslationCollection
                // derives from TranslationCollection.  TranslationCollection.Add will throw
                // an InvalidOperationException("The item type 'Translation' is not valid.")
                // when called with a AttributeTranslationCollection.
                if (translationCollection is Analysis::AttributeTranslationCollection)
                {
                    cubeTranslation = ((Analysis::AttributeTranslationCollection)translationCollection).Add(translationLocaleId);
                }
                else
                {
                    cubeTranslation = translationCollection.Add(translationLocaleId);
                }
            }

            return cubeTranslation;
        }

        /// <summary>
        /// Should we add translations to this Analysis DB?
        /// </summary>
        /// <param name="analysisComponent">Analysis DB.</param>
        /// <returns>True if we should, otherwise false.</returns>
        private static bool ShouldAddTranslations(AnalysisServicesComponent analysisComponent)
        {
            var serverEdition = analysisComponent.AnalysisServicesServer.Edition;

            return (serverEdition == Analysis.ServerEdition.Enterprise ||
                    serverEdition == Analysis.ServerEdition.Enterprise64 ||
                    serverEdition == Analysis.ServerEdition.Developer ||
                    serverEdition == Analysis.ServerEdition.Developer64);
        }

        /// <summary>
        /// Create the CSharp Assembly dimension in the cube.
        /// </summary>
        /// <param name="analysisComponent">Analysis Services Component.</param>
        private void AddCSharpAssemblyToCube(AnalysisServicesComponent analysisComponent)
        {
            if (analysisComponent.TeamSystemCube.Dimensions.Contains(
                    AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName))
            {
                return;
            }

            var csharpAssemblyDimension = analysisComponent.TeamSystemCube.Dimensions.Add(
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName,
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName,
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName);

            if (ShouldAddTranslations(analysisComponent))
            {
                AddUpdateTranslation(csharpAssemblyDimension.Translations, AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName);
            }

            // The CSharp Assembly cube dimension isn't added to any perspectives.  One could add it to a perspective
            // here.

            analysisComponent.TeamSystemCube.Update(Analysis::UpdateOptions.ExpandFull);
        }

        /// <summary>
        /// Create the CSharp Assembly Table dimension in the Database.
        /// </summary>
        /// <param name="analysisComponent">Analysis Services Component.</param>
        private void AddCSharpAssemblyToDatabase(AnalysisServicesComponent analysisComponent)
        {
            if (
                analysisComponent.TeamSystemDatabase.Dimensions.Contains(
                    AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName))
            {
                return;
            }

            // Step 1 - Add the new CSharp Assembly dimension to the Team System database.

            // Add the dimension.
            var dimension = analysisComponent.TeamSystemDatabase.Dimensions.Add(AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName, AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName);

            // Bind the new dimension to the TFS DSV.
            dimension.Source = new Analysis::DataSourceViewBinding(analysisComponent.TeamSystemWarehouseDataSourceView.ID);

            // Set the unknown member properties.
            dimension.UnknownMember = Analysis::UnknownMemberBehavior.Visible;
            dimension.UnknownMemberName = Resources.UnknownMemberName;

            if (ShouldAddTranslations(analysisComponent))
            {
                AddUpdateTranslation(dimension.UnknownMemberTranslations, Resources.UnknownMemberName);
                AddUpdateTranslation(dimension.Translations, AdapterConstants.CSharpAssemblyTable.AnalysisDimensionName);
            }

            // Step 2 - Add the attributes.

            // First the key attribute.  This will be the SK for the table.
            var keyAttribute = dimension.Attributes.Add(
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionKeyFieldName,
                AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName);

            // Note: Here we have set up the SK as the key column.  These values are
            // not preserved across Warehouse rebuild.  In cases where this is important
            // this must be converted to an integer stable key.
            keyAttribute.Usage = Analysis::AttributeUsage.Key;
            keyAttribute.InstanceSelection = Analysis::InstanceSelection.DropDown;
            keyAttribute.KeyColumns.Add(new Analysis::DataItem(
                                            AdapterConstants.CSharpAssemblyTable.AnalysisDsvTableName,
                                            AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName,
                                            OleDbType.Integer)
                                            {
                                                NullProcessing = Analysis::NullProcessing.UnknownMember
                                            }
                );

            keyAttribute.NameColumn = new Analysis::DataItem(
                AdapterConstants.CSharpAssemblyTable.AnalysisDsvTableName,
                AdapterConstants.CSharpAssemblyTable.AssemblyNameColumnName,
                OleDbType.WChar);

            if (ShouldAddTranslations(analysisComponent))
            {
                AddUpdateTranslation(keyAttribute.Translations, AdapterConstants.CSharpAssemblyTable.AnalysisDimensionKeyFieldName);
            }

            // Now the rest of the attributes - in this case this is only the Type attribute
            var typeAttribute = dimension.Attributes.Add(
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionOutputTypeFieldName,
                AdapterConstants.CSharpAssemblyTable.AnalysisDimensionOutputTypeFieldName);

            typeAttribute.KeyColumns.Add(
                new Analysis::DataItem(AdapterConstants.CSharpAssemblyTable.AnalysisDsvTableName,
                    AdapterConstants.CSharpAssemblyTable.OutputTypeColumnName, OleDbType.WChar)
                    {
                        NullProcessing = Analysis::NullProcessing.UnknownMember
                    }
                );

            typeAttribute.AttributeHierarchyVisible = true;
            typeAttribute.OrderBy = Analysis::OrderBy.Key;

            // Add a relationship to the key.
            var relationship = dimension.KeyAttribute.AttributeRelationships.Add(typeAttribute.ID);
            relationship.Name = Analysis::Utils.GetSyntacticallyValidName(
                typeAttribute.ID, typeof(Analysis::AttributeRelationship));

            if (ShouldAddTranslations(analysisComponent))
            {
                AddUpdateTranslation(typeAttribute.Translations,
                    AdapterConstants.CSharpAssemblyTable.AnalysisDimensionOutputTypeFieldName);
            }

            dimension.Update();
        }

        /// <summary>
        /// Add dimension table for CSharp Assembly into the Analysis DB Data Source View
        /// </summary>
        /// <param name="analysisComponent">Analysis Services Component.</param>
        private void AddCSharpAssemblyToDataSourceView(AnalysisServicesComponent analysisComponent)
        {
            // Add the CSharp Assembly table to the DSV.
            AddWarehouseItemToDsv(
                analysisComponent,
                AdapterConstants.CSharpAssemblyTable.TableName,
                AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName,
                AnalysisExtendedProperties.TableTypeValueTable,
                AdapterConstants.CSharpAssemblyTable.AnalysisDsvTableName);

            // Add the relation from the CSharp Assembly table to the Team Project dimension (at the collection level).
            AddDataRelation(
                analysisComponent,
                AdapterConstants.TeamProjectTable.AnalysisDsvTableName,
                AdapterConstants.TeamProjectTable.SurrogateKeyFieldName,
                AdapterConstants.CSharpAssemblyTable.AnalysisDsvTableName,
                AdapterConstants.CSharpAssemblyTable.TeamProjectCollectionKeyColumnName);
        }

        /// <summary>
        /// Create the CSharp Assembly to File measure group in the cube.
        /// </summary>
        /// <param name="analysisComponent">Analysis Services Component.</param>
        private void AddCSharpAssemblyToFileMeasureGroupToCube(AnalysisServicesComponent analysisComponent)
        {
            if (analysisComponent.TeamSystemCube.MeasureGroups.Contains(
                    AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName))
            {
                return;
            }

            // Add the new measure group.
            var assemblyToFileMeasureGroup = analysisComponent.TeamSystemCube.MeasureGroups.Add(
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName);
            assemblyToFileMeasureGroup.Type = Analysis::MeasureGroupType.Regular;

            if (ShouldAddTranslations(analysisComponent))
            {
                AddUpdateTranslation(assemblyToFileMeasureGroup.Translations,
                    AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName);
            }

            // Add a partition for the measure group and hook it up.
            var assemblyToFilePartition = assemblyToFileMeasureGroup.Partitions.Add(
                assemblyToFileMeasureGroup.Name, assemblyToFileMeasureGroup.ID);
            assemblyToFilePartition.Source = new Analysis::DsvTableBinding(
                analysisComponent.TeamSystemWarehouseDataSourceView.ID,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDsvTableName);
            assemblyToFilePartition.ProcessingMode = Analysis::ProcessingMode.Regular;
            assemblyToFilePartition.StorageMode = Analysis::StorageMode.Molap;

            // Add at least one measure.  This measure will be hidden because it is of little value to report authors.
            // Note:  CountMeasureNameFormat is not localizable because this value is used for the ID/Name of the measure, not the translation caption.
            var countMeasureName = String.Format(CultureInfo.CurrentCulture, CountMeasureNameFormat,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDimensionName);
            var countMeasure = assemblyToFileMeasureGroup.Measures.Add(countMeasureName, countMeasureName);

            countMeasure.AggregateFunction = Analysis::AggregationFunction.Count;
            countMeasure.Source = new Analysis::DataItem(
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDsvTableName,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.SurrogateKeyFieldName,
                OleDbType.Integer);
            countMeasure.Visible = false;

            if (ShouldAddTranslations(analysisComponent))
            {
                AddUpdateTranslation(countMeasure.Translations, countMeasureName);
            }

            // Create all the mappings from CSharp Assembly to File to the dimensions.
            AddCSharpAssemblyToFileRegularMappingsToCube(analysisComponent);

            analysisComponent.TeamSystemCube.Update(Analysis::UpdateOptions.ExpandFull);
        }

        /// <summary>
        /// Add adapter's warehouse fact table to Analysis DB Data Source View
        /// </summary>
        /// <param name="analysisComponent">Analysis Services Component.</param>
        private void AddCSharpAssemblyToFileToDataSourceView(AnalysisServicesComponent analysisComponent)
        {
            // Add the CSharp Assembly to File mapping table to the DSV.
            AddWarehouseItemToDsv(
                analysisComponent,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.TableName,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.SurrogateKeyFieldName,
                AnalysisExtendedProperties.TableTypeValueTable,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDsvTableName);

            // Add the relation from the CSharp Assembly to File mapping table to the File dimension table.
            AddDataRelation(
                analysisComponent,
                AdapterConstants.FileTable.AnalysisDsvTableName,
                AdapterConstants.FileTable.SurrogateKeyFieldName,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDsvTableName,
                AdapterConstants.FileTable.SurrogateKeyFieldName);

            // Add the relation from the CSharp Assembly to File mapping table to the CSharp Assembly table.
            AddDataRelation(
                analysisComponent,
                AdapterConstants.CSharpAssemblyTable.AnalysisDsvTableName,
                AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName,
                AdapterConstants.CSharpAssemblyToFilesMappingTable.AnalysisDsvTableName,
                AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName);
        }

        /// <summary>
        /// Add or update the translation caption.
        /// </summary>
        /// <param name="translationCollection">Translation Collection.</param>
        /// <param name="translatedValue">Translated value.</param>
        private void AddUpdateTranslation(Analysis::TranslationCollection translationCollection, string translatedValue)
        {
            if (String.IsNullOrEmpty(translatedValue))
            {
                return;
            }

            var translation = FindCreateTranslation(translationCollection, TranslationLocaleId);

            translation.Caption = translatedValue;
        }

        /// <summary>
        /// Add a table or view in the Warehouse DB into Data Source View.
        /// </summary>
        /// <param name="analysisComponent">Analysis Services Component.</param>
        /// <param name="warehouseItemName">Name of the Warehouse item for which to create the DSV item.</param>
        /// <param name="primaryKeyColumnName">Name of the primary key column in the warehouse item.  This will be used to 
        /// create a unique primary key constraint in the DSV for this table.</param>
        /// <param name="warehouseItemType">Type of Warehouse item (i.e. Table/View).</param>
        /// <param name="dsvSchemaTableName">Name of the DSV schema table.</param>
        private void AddWarehouseItemToDsv(AnalysisServicesComponent analysisComponent, string warehouseItemName, string primaryKeyColumnName, string warehouseItemType, string dsvSchemaTableName)
        {
            if (analysisComponent.TeamSystemWarehouseDataSourceView.Schema.Tables.Contains(dsvSchemaTableName)) return;

            var schemaTable = CreateSchemaTableFromWarehouseItem(warehouseItemName, warehouseItemType, dsvSchemaTableName, warehouseItemName);

            // Add the unique primary key constraint.
            var constraintName = String.Format(CultureInfo.InvariantCulture, UniqueConstraintNameFormat, dsvSchemaTableName, primaryKeyColumnName);
            var constraintColumn = schemaTable.Columns[primaryKeyColumnName];
            var uniqueConstraint = new UniqueConstraint(constraintName, constraintColumn, true)
                                       {ConstraintName = constraintName};
            schemaTable.Constraints.Add(uniqueConstraint);

            analysisComponent.TeamSystemWarehouseDataSourceView.Schema.Tables.Add(schemaTable);
            analysisComponent.TeamSystemWarehouseDataSourceView.Update();
        }

        /// <summary>
        /// Create the Analysis Database schema.
        /// </summary>
        private void CreateAnalysisSchema()
        {
            using (var analysisComponent = WarehouseContext.CreateAnalysisServicesComponent())
            {
                analysisComponent.AnalysisServicesServer.BeginTransaction();

                AddCSharpAssemblyToDataSourceView(analysisComponent);
                AddCSharpAssemblyToFileToDataSourceView(analysisComponent);

                AddCSharpAssemblyToDatabase(analysisComponent);

                AddCSharpAssemblyToCube(analysisComponent);
                AddCSharpAssemblyToFileMeasureGroupToCube(analysisComponent);
                AddCSharpAssemblyToFileToCodeChurnMappingToCube(analysisComponent);

                analysisComponent.AnalysisServicesServer.CommitTransaction();

                // Note:  Each individual Analysis component above udpates only the portion of the Analysis DB that needs to be updated.
                // You should not do a full update on the entire database because this will update the Analysis DB Data Source.  Updating
                // the Data Source requires administrator permissions (which you many not have) and blanks out the password on
                // the Data Source user.
            }
        }

        /// <summary>
        /// Convert a Warehouse database item into a schema table used to create a DSV item.
        /// </summary>
        /// <param name="warehouseItemName">Name of the Warehouse item for which to create the DSV item.</param>
        /// <param name="warehouseItemType">Type of Warehouse item (i.e. Table/View).</param>
        /// <param name="dsvSchemaTableName">Name of the DSV schema table.</param>
        /// <param name="dsvTableFriendlyName">Friendly name of the DSV schema table.</param>
        private DataTable CreateSchemaTableFromWarehouseItem(string warehouseItemName, string warehouseItemType, string dsvSchemaTableName, string dsvTableFriendlyName)
        {
            var schemaTable = new DataTable(dsvSchemaTableName);

            using (var dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                var query = String.Format(CultureInfo.InvariantCulture, SqlResources.SelectItemSchemaOnly, warehouseItemName);
                using (var reader = dac.ExecuteReader(CommandType.Text, query, null))
                {
                    schemaTable.Load(reader);

                    schemaTable.ExtendedProperties.Add(AnalysisExtendedProperties.FriendlyName, dsvTableFriendlyName);
                    schemaTable.ExtendedProperties.Add(AnalysisExtendedProperties.DbSchemaName, "dbo");
                    schemaTable.ExtendedProperties.Add(AnalysisExtendedProperties.DbTableName, warehouseItemName);
                    schemaTable.ExtendedProperties.Add(AnalysisExtendedProperties.TableType, warehouseItemType);

                    foreach (DataColumn column in schemaTable.Columns)
                    {
                        column.ExtendedProperties.Add(AnalysisExtendedProperties.FriendlyName, column.ColumnName);
                        column.ExtendedProperties.Add(AnalysisExtendedProperties.DbColumnName, column.ColumnName);
                    }
                }
            }

            return schemaTable;
        }

        #endregion Methods

        #region Nested Types

        /// <summary>
        /// Common analysis extended property names.
        /// </summary>
        private static class AnalysisExtendedProperties
        {
            #region Fields

            public const string DbColumnName = "DbColumnName";
            public const string DbSchemaName = "DbSchemaName";
            public const string DbTableName = "DbTableName";
            public const string FriendlyName = "FriendlyName";
            public const string TableType = "TableType";
            public const string TableTypeValueTable = "Table";

            #endregion Fields
        }

        #endregion Nested Types
    }
}