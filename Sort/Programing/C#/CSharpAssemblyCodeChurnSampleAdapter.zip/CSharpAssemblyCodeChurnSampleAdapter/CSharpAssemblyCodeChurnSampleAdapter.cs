﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace CSharpAssemblyCodeChurnSample.Adapter
{
    using System;
    using System.Diagnostics;
    using System.Globalization;

    using Microsoft.TeamFoundation.Framework.Server;
    using Microsoft.TeamFoundation.Server;
    using Microsoft.TeamFoundation.Warehouse;

    /// <summary>
    /// The CSharp Assembly Code Churn Sample Adapter
    /// 
    /// This adapter is intended as a sample that shows the general outline of how to implement a custom adapter.  This adapter
    /// parses CSharp Project files from the TFS source control database in an attempt to determine which files are used
    /// by MSBuild to compile that Assembly/Exe.  This is not a complete adapter and is intended for sample use only.  There are 
    /// several limitations to this adapter such as:
    ///  - The parsing of CSharp Project files can be inaccurate because of things like:
    ///    - Build environment information is not known by the adapter
    ///    - Wildcard compile items (i.e. *.cs) are not resolved
    ///    - The server must have a compatible version of MSBuild on the server, the adapter may not be able to open MSBuild 1.0 files
    ///  - The presentation of the data in the cube could be enhanced.  For example the Assembly information (C Sharp Assembly) could
    ///    be presented as a hierarchy instead of a flat list.
    /// 
    /// The following describes the general call order for this adapter after this adapter is installed and scheduled (see
    /// SetupCSharpCodeChurnAdapter project for instructions on install and setup):
    /// 
    /// First time adapter is run:
    ///  - Job Agent instantiates Adapter and sets properties on Adapter (i.e. RequestContext)
    ///  - Job Agent executes Adapter::Initialize()
    ///  - Job Agent executes Adapter::MakeDataChanges()
    ///    - MakeDataChanges() detects schema for Warehouse and Cube is not installed and returns SchemaChangesPending and 
    ///      DataChangesPending to indicate to the Job Agent that this adapter needs to make schema changes and, after that is 
    ///      done, needs to make data changes.  ** This is code Adapter authors are required to implement **
    ///  - Job Agent disposes Adapter and requests all other adapters stop executing
    ///    - All other adapters stop
    ///  - Job Agent instantiates Adapter and sets properties on Adapter (i.e. RequestContext)
    ///  - Job Agent executes Adapter::MakeSchemaChanges()
    ///    - MakeSchemaChanges() detects if schema needs to be applied.  If it does it applies schema and returns, otherwise
    ///      it just returns.  ** This is code Adapter authors are required to implement **
    ///  - Job Agent disposes Adapter and releases all other adapters
    ///  - Job Agent instantiates Adapter and sets properties on Adapter (i.e. RequestContext)
    ///  - Job Agent executes Adapter::Initialize()
    ///  - Job Agent executes Adapter::MakeDataChanges()
    ///    - MakeDataChanges() detects schema is installed and then continues to process new data into the Warehouse.
    ///      ** This is code Adapter authors are required to implement **
    ///      - For all unprocessed csproj files in all unprocessed changesets parse the csproj file and add the assembly and 
    ///        assembly-to-file mappings to the Warehouse.
    ///        
    /// All other times adapter is run:
    ///  - Same as the last 3 steps from above.
    /// </summary>
    public class CSharpAssemblyCodeChurnSampleAdapter : WarehouseAdapter
    {
        #region Enumerations

        /// <summary>
        /// What pending schema changes are there?
        /// </summary>
        [Flags]
        enum PendingSchemaChanges
        {
            None = 0,
            Warehouse = 1,
            Analysis = 2
        }

        #endregion Enumerations

        #region Properties

        /// <summary>
        /// A simple wrapper to process changeset data.
        /// </summary>
        private ChangesetProcessor ChangesetProcessor
        {
            get; set;
        }

        private SchemaVersion SchemaVersion
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Handle a cancel notification from TFS.
        /// 
        /// When another adapter requests a schema lock this adapter's IsWarehouseSchemaLockRequested will be set to true 
        /// and Cancel(...) will be called with a cancel reason of WarehouseSchemaLockRequested.  This adapter is requested 
        /// to stop at the the next convenient time.  Typically this will be after sending out a batch of data to the 
        /// Warehouse and before building up the next batch.  Until all adapters stop processing data the adapter waiting for 
        /// the schema lock will be blocked.  
        /// 
        /// When the host is cancelled this adapter's IsWarehouseHostCancelled will be set to true and Cancel(...) will
        /// be called with a cancel reason of HostCancelled.  All all outstanding SQL or Analysis queries/commands will be 
        /// cancelled and this adapter is demanded to stop processing immediately.  If this adapter does not stop processing 
        /// it will be thread-aborted.  
        /// This sort of cancelation (host cancelled) can occur, for example, when the job agent service that is running this 
        /// adapter is being stopped.
        /// 
        /// This method will be executed asynchronously from the main adapter thread.
        /// </summary>
        /// <param name="reason">Reason for the cancellation.</param>
        public override void Cancel(CancelReason reason)
        {
            if (ChangesetProcessor != null)
            {
                switch (reason)
                {
                    case CancelReason.HostCancelled:
                        ChangesetProcessor.IsWarehouseHostCancelled = true;
                        break;
                    case CancelReason.WarehouseSchemaLockRequested:
                        ChangesetProcessor.IsWarehouseSchemaLockRequested = true;
                        break;
                }
            }
            base.Cancel(reason);
        }

        /// <summary>
        /// Initialize the adapter.
        /// </summary>
        /// <remarks>
        /// This method will be called, on a new instance of the adapter class, before MakeDataChanges and MakeSchemaChanges 
        /// is called.  Each of these methods will be called on a new initialized instance of this adapter.  You 
        /// should not cache data across these method calls.
        /// 
        /// During this method call this adapter can be cancelled.
        /// 
        /// You should do only minimal lightweight initialization in this method.
        /// </remarks>
        public override void Initialize()
        {
            TeamFoundationServiceHost serviceHost = RequestContext.ServiceHost;

            // This job runs at a Project Collection level, so we should have a project collection service host.
            Debug.Assert(serviceHost != null);
            Debug.Assert(serviceHost.ServiceHostContext == ServiceHostContext.ProjectCollection);

            SchemaVersion = new SchemaVersion(WarehouseContext, RequestContext);
        }

        /// <summary>
        /// Move data changes from operational stores into the Warehouse.
        /// 
        /// See the comments on this class for more details about how/when this method is called by the TFS framework.
        /// </summary>
        /// <returns>Result indicating if this adapter needs to make schema changes and/or additional data changes.</returns>
        public override DataChangesResult MakeDataChanges()
        {
            if (CheckForPendingSchemaChanges() != PendingSchemaChanges.None)
            {
                return DataChangesResult.SchemaChangesPending | DataChangesResult.DataChangesPending;
            }

            ChangesetProcessor = new ChangesetProcessor(RequestContext, WarehouseContext, RequestContext.ServiceHost.InstanceId);

            // Check to see if this adapter has been cancelled before executing ProcessChangesets in case the cancel came in
            // before ChangesetProcessor was created.
            if (IsWarehouseHostCancelled || IsWarehouseSchemaLockRequested)
            {
                return DataChangesResult.DataChangesPending;
            }

            return ChangesetProcessor.ProcessChangesets();
        }

        /// <summary>
        /// Make the schema changes required to both process this adapter's schema into the Warehouse and to
        /// allow report authors simple consumption of that data.
        /// 
        /// Typically this means:
        ///     - Add tables to the Warehouse to store this adapter's data.
        ///     - Optionally add views over this data for TSQL report authors.
        ///     - Optionally add Analysis elements to surface this data in the cube.
        /// 
        /// See the comments on this class for more details about how/when this method is called by the TFS framework.
        /// </summary>
        public override void MakeSchemaChanges()
        {
            PendingSchemaChanges pendingChanges = CheckForPendingSchemaChanges();
            if ((pendingChanges & PendingSchemaChanges.Warehouse) == PendingSchemaChanges.Warehouse)
            {
                var warehouseDatabase = new WarehouseDatabase(WarehouseContext);

                // Note:  CreateSchema() is re-entrant.  If this exits before setting the Warehouse schema version stamp
                //        we will re-call CreateSchema the next time we run then set set the version level.
                warehouseDatabase.CreateSchema();
                SchemaVersion.SetCurrentWarehouseVersion();
            }
            if((pendingChanges & PendingSchemaChanges.Analysis) == PendingSchemaChanges.Analysis)
            {
                var analysisDatabase = new AnalysisDatabase(WarehouseContext);

                analysisDatabase.CreateSchema();
                SchemaVersion.SetCurrentAnalysisVersion();

                // After schema changes the cube will be unprocessed - to minimize how long the cube remains unprocessed schedule
                // a process now.  Most adapters, and probably this one included, don't need to do this.  This is mostly
                // here to be sure custom adapter authors consider it.
                var warehouseJobService = new WarehouseJobService(RequestContext);
                warehouseJobService.TryScheduleAnalysisProcess();
            }
        }

        /// <summary>
        /// Check to see if this adapter is pending any schema changes to the Warehouse or Analysis DBs.
        /// </summary>
        /// <returns>Pending changes.</returns>
        private PendingSchemaChanges CheckForPendingSchemaChanges()
        {
            PendingSchemaChanges pendingChanges = PendingSchemaChanges.None;

            switch (SchemaVersion.WarehouseActionRequired())
            {
                case SchemaVersion.ActionRequired.None:
                    break;
                case SchemaVersion.ActionRequired.Install:
                    pendingChanges |= PendingSchemaChanges.Warehouse;
                    break;
                default:    // Upgrade or Downgrade
                    // Currently this adapter does not know how to upgrade or downgrade between service levels
                    // so we will throw an exception.
                    throw new WarehouseException(
                        String.Format(CultureInfo.CurrentCulture,
                            Resources.SchemaVersionMismatch,
                            SchemaVersion.GetCurrentWarehouseVersionAsString(),
                            SchemaVersion.CurrentVersion));
            }

            switch (SchemaVersion.AnalysisActionRequired())
            {
                case SchemaVersion.ActionRequired.None:
                    break;
                case SchemaVersion.ActionRequired.Install:
                    pendingChanges |= PendingSchemaChanges.Analysis;
                    break;
                default:    // Upgrade or Downgrade
                    // Currently this adapter does not know how to upgrade or downgrade between service levels
                    // so we will throw an exception.
                    throw new WarehouseException(
                        String.Format(CultureInfo.CurrentCulture,
                            Resources.SchemaVersionMismatch,
                            SchemaVersion.GetCurrentAnalysisVersionAsString(),
                            SchemaVersion.CurrentVersion));
            }

            return pendingChanges;
        }

        #endregion Methods
    }

    /// <summary>
    /// Sync Job Extension for the CSharp Assembly Code Churn Sample Adapter.
    /// 
    /// This class is required and indicates which class represents the adapter.  All adapters have a corresponding 
    /// class like this which have the template parameter type of the adapter class name.  The class itself should follow 
    /// the naming pattern:
    ///   {Adapter class name without Adapter}SyncJobExtension
    /// </summary>
    public class CSharpAssemblyCodeChurnSampleSyncJobExtension : WarehouseSyncJobExtension<CSharpAssemblyCodeChurnSampleAdapter>
    {
    }
}