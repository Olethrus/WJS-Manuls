﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace CSharpAssemblyCodeChurnSample.Adapter
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Globalization;
    using System.IO;
    using System.Xml;

    using Microsoft.Build.Evaluation;
    using Microsoft.TeamFoundation.Framework.Server;
    using Microsoft.TeamFoundation.VersionControl.Common;
    using Microsoft.TeamFoundation.VersionControl.Server;
    using Microsoft.TeamFoundation.Warehouse;

    /// <summary>
    /// A helper class that handles processing changesets into the Warehouse.
    /// 
    /// This retrieves all the new changesets from the operational store and iterates through all the files in those 
    /// changesets looking for csproj files.  When it finds one it parses the csproj file contents to determine the 
    /// assembly name/type build by the csproj file and the file dependencies.  It then saves this data to the Warehouse.
    /// </summary>
    class ChangesetProcessor
    {
        #region Fields

        /// <summary>
        /// The currnet changeset id that is being processed by this adapter.
        /// </summary>
        private const string CurrentChangesetIdProcessingWatermarkPropertyName = @"/Adapter/Watermark/CSharpAssemblyCodeChurnSampleAdapter/CurrentChangesetIdProcessing";

        /// <summary>
        /// The first changeset id, if no watermark is defined we will start processing from this changeset.
        /// </summary>
        private const int FirstChangesetId = 1;

        /// <summary>
        /// The maximum size of a batch of items to retrieve from the operational store.
        /// </summary>
        private const int ItemsFromChangesetBatchSize = 1000;
        private const char ItemSpecDelimiter = ';';

        /// <summary>
        /// The last ItemSpec saved within the current changeset.
        /// </summary>
        private const string LastChangesetItemSpecSavedWatermarkPropertyName = @"/Adapter/Watermark/CSharpAssemblyCodeChurnSampleAdapter/LastChangesetItemSpecSaved";

        /// <summary>
        /// Maximum size of a CSharp Project file to attemp to parse.
        /// </summary>
        private const int MaximumCsProjFileSize = 1024 * 1024;

        private static readonly char[] InvalidFileNameChars = Path.GetInvalidFileNameChars();
        private static readonly char[] InvalidPathChars = Path.GetInvalidPathChars();
        private static readonly Char[] ItemSpecDelimiters = new[] { ItemSpecDelimiter };

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Create a new Changeset Processor.
        /// </summary>
        /// <param name="requestContext">Request Context.</param>
        /// <param name="warehouseContext">Warehouse Context.</param>
        /// <param name="teamProjectCollectionId">Team Project Collection Id.</param>
        public ChangesetProcessor(TeamFoundationRequestContext requestContext, WarehouseContext warehouseContext, Guid teamProjectCollectionId)
        {
            RequestContext = requestContext;
            WarehouseContext = warehouseContext;
            TeamProjectCollectionId = teamProjectCollectionId;

            VersionControlService = RequestContext.GetService<TeamFoundationVersionControlService>();
            WarehouseDatabase = new WarehouseDatabase(WarehouseContext);
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Has the Warehouse Host been cancelled?
        /// </summary>
        public bool IsWarehouseHostCancelled
        {
            get; set;
        }

        /// <summary>
        /// Is the Warehouse schema lock requested by another adapter?
        /// </summary>
        public bool IsWarehouseSchemaLockRequested
        {
            get; set;
        }

        /// <summary>
        /// The current Changeset Id being processed.
        /// </summary>
        /// <remarks>
        /// This value is persisted to the Warehouse and retrieved when GetLastSavedWatermarks is called.
        /// </remarks>
        private int CurrentChangesetIdProcessing
        {
            get; set;
        }

        /// <summary>
        /// The item spec in a changeset saved.  If a changeset is not fully processed this will let this
        /// adapter know where to pick back up processing.  If a changeset is not yet processed this will
        /// have the value NULL.
        /// </summary>
        /// <remarks>
        /// This value is persisted to the Warehouse and retrieved when GetLastSavedWatermarks is called.
        /// </remarks>
        private ItemSpec LastChangesetItemSpecSaved
        {
            get; set;
        }

        /// <summary>
        /// The Request Context associated with the operational store for which this adapter is running.
        /// </summary>
        private TeamFoundationRequestContext RequestContext
        {
            get; set;
        }

        /// <summary>
        /// The Team Project Collection Id for which this adapter is currently running.
        /// </summary>
        private Guid TeamProjectCollectionId
        {
            get; set;
        }

        /// <summary>
        /// The Version Control service associated with the operational store for which this adapter is running.
        /// </summary>
        private TeamFoundationVersionControlService VersionControlService
        {
            get; set;
        }

        /// <summary>
        /// The Warehouse Context associated with the warehouse for which this adapter is running.
        /// </summary>
        private WarehouseContext WarehouseContext
        {
            get; set;
        }

        /// <summary>
        /// The Warehouse database wrapper (created in this sample) used here to batch save data to the Warehouse.
        /// </summary>
        private WarehouseDatabase WarehouseDatabase
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Process all new changesets.
        /// </summary>
        /// <returns>Data Changes Result indicating if there are additional changes required.</returns>
        public DataChangesResult ProcessChangesets()
        {
            // Get the current largest changeset id from the operational store.
            int processUntilChangesetId = VersionControlService.GetLatestChangeset();

            // Get the watermarks in the Warehouse indicating where we should resume processing from.
            GetLastSavedWatermarks();

            while (CurrentChangesetIdProcessing <= processUntilChangesetId)
            {
                Changeset changeset = RetrieveCurrentChangeset();

                // Process the items in the changeset in batches.
                // If changeset is null then a changeset with that ID was not found.  Just skip this changeset id and continue
                // with the next one.
                // Note:  We could be a bit smarter here around batching and build batches across changesets and
                //        ensure that the file batches are sent before getting too large, but to keep things simple
                //        we are just batching all the changes within a single changeset.
                bool unprocessedItemsRemainingInChangeset = true;
                while (changeset != null && unprocessedItemsRemainingInChangeset)
                {
                    // Build a batch of CSharp project change items to process
                    using (TeamFoundationDataReader changesReader = VersionControlService.QueryChangesForChangeset(
                        RequestContext,             // Request context for the TPC.
                        changeset.ChangesetId,      // Current Changeset id.
                        false,                      // Don't generated download URLs.
                        ItemsFromChangesetBatchSize,// Maximum number of items to return.
                        LastChangesetItemSpecSaved, // The last Itemspec processed.
                        null,                       // Don't get any properties.
                        false)                      // Don't include merged source information.
                        )
                    {
                        int changesReturned = 0;
                        Item lastItemInChangesetBatch = null;

                        foreach (Change change in changesReader.Current<StreamingCollection<Change>>())
                        {
                            changesReturned++;
                            lastItemInChangesetBatch = change.Item;

                            if (IsStopIssued(true))
                            {
                                // Stop is demanded.  Throw away this batch and exit.
                                return DataChangesResult.DataChangesPending;
                            }

                            if (IsCSharpProjectFile(change.Item))
                            {
                                // todo: Handle Rename/SourceRename/Delete change.ChangeEx ChangeType values.

                                // Parse a single CSharp Project file and batch all changes required to the Warehouse.
                                BatchChangesForCsProjFile(change);

                                WarehouseDatabase.CSharpAssemblyTable.SaveBatch();
                                WarehouseDatabase.CSharpAssemblyToFilesMappingTable.SaveBatch();

                                LastChangesetItemSpecSaved = new ItemSpec(change.Item.ServerItem, RecursionType.None, change.Item.DeletionId);
                                SaveCurrentWatermarks();
                            }
                        }

                        // If we got back the same number of items that we asked for then there may be more items remaining for this changeset.
                        unprocessedItemsRemainingInChangeset = (changesReturned >= ItemsFromChangesetBatchSize);

                        LastChangesetItemSpecSaved = lastItemInChangesetBatch == null ?
                            null : new ItemSpec(lastItemInChangesetBatch.ServerItem, RecursionType.None, lastItemInChangesetBatch.DeletionId);
                    }
                    SaveCurrentWatermarks();

                    if (IsStopIssued(false))
                    {
                        // Stop is requested.  Stop processing the current changeset and exit.
                        return DataChangesResult.DataChangesPending;
                    }
                }

                // Start on the next changeset.
                CurrentChangesetIdProcessing++;
                LastChangesetItemSpecSaved = null;

                SaveCurrentWatermarks();
            }

            return DataChangesResult.NoChangesPending;
        }

        /// <summary>
        /// Check if the churn item is a .csproj file
        /// </summary>
        private static bool IsCSharpProjectFile(Item changesetItem)
        {
            if (changesetItem.ItemType == ItemType.File)
            {
                string fileExtension = VersionControlPath.GetExtension(changesetItem.ServerItem);

                if (String.Equals(fileExtension, WellKnownProjectFileConstants.CsprojFileExtension, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        /// <summary>
        /// Parse a CSharp Project file and batch all associated changes needed to the Warehouse in the WarehouseDatabase object.
        /// </summary>
        /// <param name="csprojChange">CSharp Project file change.</param>
        private void BatchChangesForCsProjFile(Change csprojChange)
        {
            string csharpAssemblyBusinessKey = WarehouseDatabase.CSharpAssemblyTable.GetBusinessKey(TeamProjectCollectionId.ToString(), csprojChange.Item.ServerItem);

            // First batch a destroy action for the assembly and all its mappings.  This is to handle changes in the
            // assembly name and mappings.  This is not the efficient way to handle this, but acceptable for a non-production
            // sample.
            WarehouseDatabase.CSharpAssemblyTable.CreateBatchedDestroyEntry(csharpAssemblyBusinessKey);

            // Don't bother parsing files that are too large, this probably isn't a CSharp project file.
            if (csprojChange.Item.FileLength > MaximumCsProjFileSize)
            {
                // Very basic logging - this should be improved in a production adapter.
                if (!EventLog.SourceExists(AdapterConstants.LogId.EventSource))
                {
                    EventLog.CreateEventSource(AdapterConstants.LogId.EventSource, AdapterConstants.LogId.LogName);
                }

                EventLog.WriteEntry(
                    AdapterConstants.LogId.EventSource,
                    String.Format(CultureInfo.CurrentCulture, Resources.ProjectFileTooBig, csprojChange.Item.ServerItem, csprojChange.Item.FileLength, MaximumCsProjFileSize),
                    EventLogEntryType.Information,
                    AdapterConstants.LogId.FailedParsingProjectFile);

                return;
            }

            // If the content is destroyed we cannot parse the file.
            if (csprojChange.Item.IsContentDestroyed)
            {
                return;
            }

            Project project = null;
            using(TeamFoundationDataReader dataReader = VersionControlService.QueryFileContents(RequestContext, csprojChange.Item))
            {
                var dataStream = dataReader.Current<Stream>();
                var xmlReader = XmlReader.Create(dataStream);

                var dummyCollection = new ProjectCollection();
                try
                {
                    project = new Project(xmlReader, null, null, dummyCollection, ProjectLoadSettings.IgnoreMissingImports);
                }
                catch
                {
                    // Catch any exception, skip this assembly, and keep going.  We will write out the assembly entry, but use the item name
                    // as the assembly name.
                    // You can get these when, for example, MSBuild cannot parse the project file because it is an older version.
                }
            }

            string projectFilePath = VersionControlPath.GetFolderName(csprojChange.Item.ServerItem);

            // Create a new CSharp Assembly entry using the properties from the project file.
            var assemblyNameProperty = (project == null) ? null : project.GetProperty(WellKnownProjectFileConstants.AssemblyName);
            var outputTypeProperty = (project == null) ? null : project.GetProperty(WellKnownProjectFileConstants.OutputType);

            Hashtable assemblyEntry = WarehouseDatabase.CSharpAssemblyTable.CreateBatchedEntry(csharpAssemblyBusinessKey);
            // Note:  The assembly properties can be NULL when we failed to parse the project file or when we parsed the project file but the
            //        property did not exist.
            //        We write these out to the DB mostly for debugging purposes.  They will probably be of little use to report authors.
            assemblyEntry[AdapterConstants.CSharpAssemblyTable.AssemblyNameColumnName] = 
                (assemblyNameProperty == null) ? 
                    csprojChange.Item.ServerItem : 
                    VersionControlPath.Combine(projectFilePath, assemblyNameProperty.EvaluatedValue);

            assemblyEntry[AdapterConstants.CSharpAssemblyTable.OutputTypeColumnName] = 
                (outputTypeProperty == null) ? 
                    String.Empty : outputTypeProperty.EvaluatedValue;

            assemblyEntry["TeamProjectCollectionBK"] = TeamProjectCollectionId.ToString();

            // Add the links to the file Dimension.
            if (project != null)
            {
                var compileItems = project.GetItems(WellKnownProjectFileConstants.Compile);
                
                foreach (var compileItem in compileItems)
                {
                    string compileItemFullPath;

                    try
                    {
                        if (compileItem.EvaluatedInclude.IndexOfAny(InvalidPathChars) > -1)
                        {
                            // Skip anything that is an invalid path.
                            continue;
                        }
                        string fileName = Path.GetFileName(compileItem.EvaluatedInclude);
                        if (fileName.IndexOfAny(InvalidFileNameChars) > -1)
                        {
                            // Skip any file names that are invalid.
                            continue;
                        }
                        if (Path.IsPathRooted(compileItem.EvaluatedInclude))
                        {
                            // Skip absolute paths.  We could try to resolve these in source control but it would always, at best,
                            // be a guess.
                            continue;
                        }

                        compileItemFullPath = VersionControlPath.Combine(projectFilePath, compileItem.EvaluatedInclude);
                    }
                    catch
                    {
                        // Skip paths that we can't combine to VC paths or have some other general path error.
                        // Usually this is because the compile path is not valid in some way.
                        continue;
                    }
                    var fileBusinessKey = TeamProjectCollectionId + "|" + compileItemFullPath;

                    var mappingKey = WarehouseDatabase.CSharpAssemblyToFilesMappingTable.GetBusinessKey(csharpAssemblyBusinessKey, compileItemFullPath);
                    var mappingEntry = WarehouseDatabase.CSharpAssemblyToFilesMappingTable.CreateBatchedEntry(mappingKey);

                    mappingEntry[AdapterConstants.CSharpAssemblyTable.BusinessKeyFieldName] = csharpAssemblyBusinessKey;
                    mappingEntry[AdapterConstants.FileTable.BusinessKeyFieldName] = fileBusinessKey;
                }
            }
        }

        private void GetLastSavedWatermarks()
        {
            using (var dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                CurrentChangesetIdProcessing = GetWatermark(dac, CurrentChangesetIdProcessingWatermarkPropertyName, FirstChangesetId);
                LastChangesetItemSpecSaved = GetWatermark(dac, LastChangesetItemSpecSavedWatermarkPropertyName, null);
            }
        }

        /// <summary>
        /// Get the watermark.
        /// </summary>
        /// <param name="dac">Data Access Component</param>
        /// <param name="watermarkKey">Key for the watermark.</param>
        /// <param name="defaultValue">Default value for the watermark if no value currently exists.</param>
        /// <returns>Watermark</returns>
        private int GetWatermark(WarehouseDataAccessComponent dac, string watermarkKey, int defaultValue)
        {
            int value;

            if (!Int32.TryParse(dac.GetProperty(TeamProjectCollectionId.ToString(), watermarkKey), out value))
            {
                value = defaultValue;
            }

            return value;
        }

        /// <summary>
        /// Get the watermark.
        /// </summary>
        /// <param name="dac">Data Access Component</param>
        /// <param name="watermarkKey">Key for the watermark.</param>
        /// <param name="defaultValue">Default value for the watermark if no value currently exists.</param>
        /// <returns>Watermark</returns>
        private ItemSpec GetWatermark(WarehouseDataAccessComponent dac, string watermarkKey, ItemSpec defaultValue)
        {
            ItemSpec value = null;
            var lastItemProcessedString = dac.GetProperty(TeamProjectCollectionId.ToString(), watermarkKey);

            if (!string.IsNullOrEmpty(lastItemProcessedString))
            {
                var tokens = lastItemProcessedString.Split(ItemSpecDelimiters);

                if (tokens[0].Length > 0)
                {
                    int deletionId;

                    value = Int32.TryParse(tokens[1], out deletionId) ?
                        new ItemSpec(tokens[0], RecursionType.None, deletionId) : new ItemSpec(tokens[0], RecursionType.None);
                }
            }

            return value;
        }

        /// <summary>
        /// Check if stop demand or request has been issued to this adapter from the job service.
        /// </summary> 
        /// <param name="ignoreRequests">Ignore requests when checking to see if a stop has been issued.</param>
        /// <returns>True if a stop has been issued.</returns>
        private bool IsStopIssued(bool ignoreRequests)
        {
            return IsWarehouseHostCancelled || (IsWarehouseSchemaLockRequested && !ignoreRequests);
        }

        /// <summary>
        /// Read the changeset from Version Control associated with the Current Changeset Id.
        /// </summary>
        private Changeset RetrieveCurrentChangeset()
        {
            Changeset changeset = null;
            try
            {
                // Read just the top-level changeset info, no items, download URLs, or properties.
                // QueryChangeset() throws if it cannot obtain the changeset.
                using (var changesetReader = VersionControlService.QueryChangeset(
                    RequestContext, CurrentChangesetIdProcessing, false, false, false))
                {
                    changeset = changesetReader.Current<Changeset>();
                }
            }
            catch (ChangesetNotFoundException)
            {
                // Propagate all exceptions to caller except for ChangesetNotFoundException.
            }

            return changeset;
        }

        private void SaveCurrentWatermarks()
        {
            using (WarehouseDataAccessComponent dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                SetWatermark(dac, CurrentChangesetIdProcessingWatermarkPropertyName, CurrentChangesetIdProcessing);
                SetWatermark(dac, LastChangesetItemSpecSavedWatermarkPropertyName, LastChangesetItemSpecSaved);
            }
        }

        /// <summary>
        /// Set the watermark.
        /// </summary>
        /// <param name="dac">Data Access Component.</param>
        /// <param name="watermarkKey">Key for the watermark.</param>
        /// <param name="value">Value to set.</param>
        private void SetWatermark(WarehouseDataAccessComponent dac, string watermarkKey, int value)
        {
            dac.SetProperty(TeamProjectCollectionId.ToString(), watermarkKey, 
                value.ToString(CultureInfo.InvariantCulture));
        }

        /// <summary>
        /// Set the watermark.
        /// </summary>
        /// <param name="dac">Data Access Component.</param>
        /// <param name="watermarkKey">Key for the watermark.</param>
        /// <param name="value">Value to set.</param>
        private void SetWatermark(WarehouseDataAccessComponent dac, string watermarkKey, ItemSpec value)
        {
            dac.SetProperty(TeamProjectCollectionId.ToString(), watermarkKey,
                              ((value != null) ? value.Item : String.Empty) +
                              ItemSpecDelimiter +
                              ((value != null) ? value.DeletionId.ToString(CultureInfo.InvariantCulture) : String.Empty));
        }

        #endregion Methods

        #region Nested Types

        /// <summary>
        /// Some well known project file constants.
        /// </summary>
        private static class WellKnownProjectFileConstants
        {
            #region Fields

            public const string AssemblyName = @"AssemblyName";
            public const string Compile = @"Compile";
            public const string CsprojFileExtension = ".csproj";
            public const string OutputType = @"OutputType";

            #endregion Fields
        }

        #endregion Nested Types
    }
}