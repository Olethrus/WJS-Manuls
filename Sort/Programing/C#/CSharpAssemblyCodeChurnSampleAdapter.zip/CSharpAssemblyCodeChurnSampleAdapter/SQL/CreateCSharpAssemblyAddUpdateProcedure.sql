-----------------------------------------------------------------------------
--
--    Copyright (c) Microsoft Corporation. All rights reserved.
--    This code is licensed under the Visual Studio SDK license terms.
--    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
--    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
--    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
--    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
--
-----------------------------------------------------------------------------

-- Create the stored procedure to load the CSharp Assembly data into the Warehouse.
-- Here we are processing batches of rows passed in as XML.
--
-- Parameters:  {0}     This stored procedure name.
--              {7}     XML batch data set name.
--              {1}     Root element in the XML batch.
--              {2}     Row element in the XML batch.
--              {3}     CSharp Assembly table name.
--              {4}     Business key for the CSharp Assembly table.
--              {5}     AssemblyName column name.
--              {6}     OutputType column name.
CREATE PROCEDURE [dbo].[{0}]
     @{7} NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- Step 1:  Extract the dataset (XML input) into a temporary table.

    DECLARE @xmlDocHandle INT
    EXEC sp_xml_preparedocument @xmlDocHandle OUTPUT, @{7}

    BEGIN TRY
        SELECT
             [{4}]
            ,[{5}]
            ,[{6}]
            ,[TeamProjectCollectionBK]
        INTO 
            #workingSet
        FROM OPENXML(@xmlDocHandle, N'/{1}/{2}') WITH
        (
             [{4}] NVARCHAR(576) N'@{4}'
            ,[{5}] NVARCHAR(512) N'@{5}'
            ,[{6}] NVARCHAR(128) N'@{6}'
            ,[TeamProjectCollectionBK] NVARCHAR(256) N'@TeamProjectCollectionBK'
        )
    END TRY
    BEGIN CATCH
        DECLARE @__ErrorNumber INT;
        DECLARE @__ErrorMessage NVARCHAR(4000);

        SELECT  @__ErrorNumber = ERROR_NUMBER(),
                @__ErrorMessage = ERROR_MESSAGE();

        EXEC sp_xml_removedocument @xmlDocHandle

        RAISERROR(6000001, 16, 1, @__ErrorNumber, @__ErrorMessage)
        RETURN
    END CATCH
    EXEC sp_xml_removedocument @xmlDocHandle

    -- Step 2: Create an early ariving entry for the Team Project Collection if needed.
    --         This is required to handle the case that this adapter happens to run before the TPC nodes are added 
    --         to the Warehouse.

    -- Note:  When creating early ariving entries you must take a holdlock/updlock on the table to ensure that
    --        another adapter doens't add the duplicate entry between the time this adapter selects and inserts.
    BEGIN TRAN   
        INSERT INTO 
            [dbo].[DimTeamProject] ( [ProjectNodeGUID], [LastUpdatedDateTime] )
        SELECT
             ws.[TeamProjectCollectionBK]
            ,GETUTCDATE()
        FROM
            ( SELECT DISTINCT [TeamProjectCollectionBK] FROM #workingSet ) AS ws
        LEFT JOIN
            [dbo].[DimTeamProject] WITH (HOLDLOCK, UPDLOCK)
            ON  [dbo].[DimTeamProject].[ProjectNodeGUID] = ws.[TeamProjectCollectionBK]
        WHERE
            [dbo].[DimTeamProject].[ProjectNodeGUID] IS NULL 
            AND ws.[TeamProjectCollectionBK] IS NOT NULL

        IF (@@ROWCOUNT > 0)
            EXEC [dbo].[prc_WarehouseUpdate_Update] 'DimTeamProject', 1;   -- 1 for Add, 2 = Update. 
    COMMIT TRAN


    -- Step 3: Load the data into the table.

    BEGIN TRAN;

        -- Note:  Normally an adapter would probably want to handle both insert and update, for this sample we only handle insert.
        MERGE 
            [dbo].[{3}] WITH(HOLDLOCK, UPDLOCK) AS c
        USING
        ( 
            SELECT 
                 ws.[{4}]
                ,ws.[{5}]
                ,ws.[{6}]
                ,[TeamProjectCollection].[ProjectNodeSK] AS [TeamProjectCollectionSK]
            FROM 
                #workingSet ws
            LEFT JOIN 
                [dbo].[DimTeamProject] AS [TeamProjectCollection] 
                ON  [TeamProjectCollection].[ProjectNodeGUID] = ws.[TeamProjectCollectionBK]
        ) jws 
            ON  c.[{4}] = jws.[{4}]
        WHEN NOT MATCHED THEN
            INSERT 
            (
                 [{4}]
                ,[{5}]
                ,[{6}]
                ,[LastUpdatedDateTime]
                ,[TeamProjectCollectionSK]
            )
            VALUES
            (
                 jws.[{4}]
                ,jws.[{5}]
                ,jws.[{6}]
                ,GETUTCDATE()
                ,jws.[TeamProjectCollectionSK]
            );

        -- Step 4: Flag this table as having been added to or updated.  Cube processing will use this data to 
        --         determine what cube objects to process.
        IF (@@ROWCOUNT > 0)
            EXEC [dbo].[prc_WarehouseUpdate_Update] N'{3}', 1;    -- 1 for Add, 2 = Update.   

    COMMIT TRAN;
END
