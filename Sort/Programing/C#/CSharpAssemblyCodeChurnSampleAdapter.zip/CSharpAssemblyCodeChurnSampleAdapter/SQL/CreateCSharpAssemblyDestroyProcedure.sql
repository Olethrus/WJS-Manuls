-----------------------------------------------------------------------------
--
--    Copyright (c) Microsoft Corporation. All rights reserved.
--    This code is licensed under the Visual Studio SDK license terms.
--    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
--    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
--    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
--    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
--
-----------------------------------------------------------------------------

-- Create the stored procedure to destroy (delete) the CSharp Assembly data from the Warehouse.
-- Here we are processing batches of rows passed in as XML.
--
-- Parameters:  {0}     This stored procedure name.
--              {1}     Root element in the XML batch.
--              {2}     Row element in the XML batch.
--              {3}     CSharp Assembly table name.
--              {4}     Business key for the CSharp Assembly table
--              {5}     XML batch data set name.
--              {6}     CSharp Assembly to File mapping table name.
CREATE PROCEDURE [dbo].[{0}]
     @{5} NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- Step 1:  Extract the dataset (XML input) into a temporary table.

    DECLARE @xmlDocHandle INT
    EXEC sp_xml_preparedocument @xmlDocHandle OUTPUT, @{5}

    BEGIN TRY
        SELECT
             [{4}]
        INTO 
            #workingSet
        FROM OPENXML(@xmlDocHandle, N'/{1}/{2}') WITH
        (
             [{4}] NVARCHAR(576) N'@{4}'
        )
    END TRY
    BEGIN CATCH
        DECLARE @__ErrorNumber INT;
        DECLARE @__ErrorMessage NVARCHAR(4000);

        SELECT  @__ErrorNumber = ERROR_NUMBER(),
                @__ErrorMessage = ERROR_MESSAGE();

        EXEC sp_xml_removedocument @xmlDocHandle

        RAISERROR(6000001, 16, 1, @__ErrorNumber, @__ErrorMessage)
        RETURN
    END CATCH
    EXEC sp_xml_removedocument @xmlDocHandle

    -- Step 2: Delete the data from the table.
    --         This will cascade to the CSharp Assembly to File Mapping table.

    BEGIN TRAN;

        DELETE CSharpAssembly
        FROM
            [dbo].[{3}] AS CSharpAssembly
        JOIN
            #workingSet AS DestroyedItems
        ON
            CSharpAssembly.[{4}] = DestroyedItems.[{4}]

        -- Step 3: Flag this table as having been added to or updated.  Cube processing will use this data to 
        --         determine what cube objects to process.
        IF (@@ROWCOUNT > 0)
        BEGIN
            EXEC [dbo].[prc_WarehouseUpdate_Update] N'{3}', 2;    -- 1 for Add, 2 = Update.
            EXEC [dbo].[prc_WarehouseUpdate_Update] N'{6}', 2;    -- 1 for Add, 2 = Update.
        END

    COMMIT TRAN;
END
