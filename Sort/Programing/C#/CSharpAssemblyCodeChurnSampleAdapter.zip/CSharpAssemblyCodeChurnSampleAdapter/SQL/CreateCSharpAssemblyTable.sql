-----------------------------------------------------------------------------
--
--    Copyright (c) Microsoft Corporation. All rights reserved.
--    This code is licensed under the Visual Studio SDK license terms.
--    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
--    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
--    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
--    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
--
-----------------------------------------------------------------------------

-- Create the Dimension table to store the list of CSharp Assemblies.
-- Parameters:  {0}     This table name.
--              {1}     Surrogate key for this table.
--              {2}     Business key for this table.
--              {3}     Foreign Key to Team Project table (Collection level link).
--              {4}     AssemblyName column name.
--              {5}     OutputType column name.
CREATE TABLE [dbo].[{0}]
(
    [{1}]                       INT IDENTITY PRIMARY KEY,       -- Surrogate key for this table.
    [{2}]                       NVARCHAR(576) NOT NULL,         -- Business key for this table.
    [{4}]                       NVARCHAR(512) NOT NULL,         -- The assembly name for the project file (full path).
    [{5}]                       NVARCHAR(128) NOT NULL,         -- The output type of the project file (i.e. Library/WinExe/Exe).
    [LastUpdatedDateTime]       DATETIME NOT NULL,
    [{3}]                       INT NULL FOREIGN KEY REFERENCES [dbo].[DimTeamProject]( [ProjectNodeSK] ) ON DELETE NO ACTION
)
