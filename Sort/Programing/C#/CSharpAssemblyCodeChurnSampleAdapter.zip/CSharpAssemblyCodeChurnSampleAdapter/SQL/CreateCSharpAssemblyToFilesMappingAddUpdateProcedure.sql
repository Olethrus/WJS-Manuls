-----------------------------------------------------------------------------
--
--    Copyright (c) Microsoft Corporation. All rights reserved.
--    This code is licensed under the Visual Studio SDK license terms.
--    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
--    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
--    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
--    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
--
-----------------------------------------------------------------------------

-- Create the stored procedure to load the CSharp Assembly to File Mapping data into the Warehouse.
-- Here we are processing batches of rows passed in as XML.
--
-- Parameters:  {0}     This stored procedure name.
--              {8}     OutputType column name.
--              {1}     Root element in the XML batch.
--              {2}     Row element in the XML batch.
--              {3}     CSharp Assembly to File mapping table name.
--              {4}     Business key for the CSharp Assembly to File mapping table.
--              {5}     CSharp Assembly table name.
--              {6}     Business key for the CSharp Assembly table.
--              {7}     Surrogate key for the CSharp Assembly table.
CREATE PROCEDURE [dbo].[{0}]
     @{8} NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    -- Step 1:  Extract the dataset (XML input) into a temporary table.

    DECLARE @xmlDocHandle INT
    EXEC sp_xml_preparedocument @xmlDocHandle OUTPUT, @{8}

    BEGIN TRY
        SELECT
             [{4}]          -- Business key for the CSharp Assembly to File mapping table.
            ,[{6}]          -- Business key for the CSharp Assembly table.
            ,[FileBK]
        INTO #workingSet
        FROM OPENXML(@xmlDocHandle, N'/{1}/{2}') WITH
        (
             [{4}]              NVARCHAR(837) N'@{4}'
            ,[{6}]              NVARCHAR(576) N'@{6}'
            ,[FileBK]           NVARCHAR(380) N'@FileBK'
        )
    END TRY
    BEGIN CATCH
        DECLARE @__ErrorNumber INT;
        DECLARE @__ErrorMessage NVARCHAR(4000);

        SELECT  @__ErrorNumber = ERROR_NUMBER(),
                @__ErrorMessage = ERROR_MESSAGE();

        EXEC sp_xml_removedocument @xmlDocHandle

        RAISERROR(6000001, 16, 1, @__ErrorNumber, @__ErrorMessage)
        RETURN
    END CATCH
    EXEC sp_xml_removedocument @xmlDocHandle

    -- Step 2: Create an early ariving entry for the Files if needed.
    --         This is required to handle the case that this adapter happens to run before the files are added 
    --         to the Warehouse.

    -- Note:  When creating early ariving entries you must take a holdlock/updlock on the table to ensure that
    --        another adapter doens't add the duplicate entry between the time this adapter selects and inserts.
    BEGIN TRAN
        INSERT INTO 
            [dbo].[DimFile] ( [FileBK], [LastUpdatedDateTime] )
        SELECT
            ws.[FileBK]
            ,GETUTCDATE()
        FROM
            ( SELECT DISTINCT [FileBK] FROM #workingSet ) AS ws
        LEFT JOIN
            [dbo].[DimFile] WITH (HOLDLOCK, UPDLOCK)
            ON  [dbo].[DimFile].[FileBK] = ws.[FileBK]
        WHERE
            [dbo].[DimFile].[FileBK] IS NULL 
            AND ws.[FileBK] IS NOT NULL

        IF (@@ROWCOUNT > 0)
            EXEC [dbo].[prc_WarehouseUpdate_Update] 'DimFile', 1;   -- 1 for Add, 2 = Update.
    COMMIT TRAN

    -- Step 3:  Load the new Assembly to File relationships.
    --          This does not do updates, some adapters may need to update entries.

    BEGIN TRAN;
        MERGE [dbo].[{3}] WITH(HOLDLOCK, UPDLOCK) AS c
        USING
        ( 
            SELECT
                 [{4}]                      -- [Business key for the CSharp Assembly to File mapping table]
                ,[{5}].[{7}]                -- [CSharp Assembly table name].[Surrogate key for the CSharp Assembly table]
                ,[DimFile].[FileSK]
            FROM 
                #workingSet ws
            LEFT JOIN 
                [dbo].[{5}]                 -- [CSharp Assembly table name]
                ON  [{5}].[{6}] = ws.[{6}]  -- [CSharp Assembly table name].[Business key for the CSharp Assembly table] = ...
            LEFT JOIN 
                [dbo].[DimFile] AS [DimFile]
                ON  [DimFile].[FileBK] = ws.[FileBK]
        ) jws 
            ON  c.[{7}] = jws.[{7}]
        WHEN NOT MATCHED THEN
            INSERT 
            (
                 [{4}]                      -- [Business key for the CSharp Assembly to File mapping table]
                ,[{7}]                      -- [Surrogate key for the CSharp Assembly table]
                ,[FileSK]
                ,[LastUpdatedDateTime]
            )
            VALUES
            (
                 jws.[{4}]                  -- [Business key for the CSharp Assembly to File mapping table]
                ,jws.[{7}]                  -- [Surrogate key for the CSharp Assembly table]
                ,jws.[FileSK]
                ,GETUTCDATE()
            ); 

        IF (@@ROWCOUNT > 0)
            EXEC [dbo].[prc_WarehouseUpdate_Update] N'{3}', 1;    -- 1 for Add    

    COMMIT TRAN;
END
