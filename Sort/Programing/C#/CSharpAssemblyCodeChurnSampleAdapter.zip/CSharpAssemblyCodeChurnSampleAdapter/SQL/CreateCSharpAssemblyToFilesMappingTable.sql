-----------------------------------------------------------------------------
--
--    Copyright (c) Microsoft Corporation. All rights reserved.
--    This code is licensed under the Visual Studio SDK license terms.
--    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
--    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
--    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
--    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
--
-----------------------------------------------------------------------------

-- Create a fact table mapping the CSharp Assembly table to the files used to build that assembly.
-- Parameters:  {0}     This table name.
--              {1}     Surrogate key for this table.
--              {2}     Business key for this table.
--              {3}     CSharp Assembly table name.
--              {4}     Surrogate key in the CSharp Assembly table.
--              {5}     Foreign key to the File dimension table
CREATE TABLE [dbo].[{0}]
(
    [{1}]                   INT IDENTITY PRIMARY KEY,       -- Surrogate key for this table.
    [{2}]                   NVARCHAR(837) NOT NULL,         -- Business key for this table.
    [{4}]                   INT NOT NULL FOREIGN KEY REFERENCES [dbo].[{3}]( [{4}] ) ON DELETE CASCADE,   -- Link to CSharp Assembly table.
    [{5}]                   INT NOT NULL FOREIGN KEY REFERENCES [dbo].[DimFile]([{5}]) ON DELETE CASCADE, -- Link to File Dimension table.
    [LastUpdatedDateTime]   DATETIME NOT NULL
)
