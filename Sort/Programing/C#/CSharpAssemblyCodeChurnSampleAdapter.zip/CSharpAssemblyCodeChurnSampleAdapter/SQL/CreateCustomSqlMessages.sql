-----------------------------------------------------------------------------
--
--    Copyright (c) Microsoft Corporation. All rights reserved.
--    This code is licensed under the Visual Studio SDK license terms.
--    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
--    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
--    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
--    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
--
-----------------------------------------------------------------------------

-- These are the custom sql messages passed back by the stored procedures in this adapter.
-- These messages are not used throughout this adapter code but are here more to show a technique for passing errors between
-- your SQL and your adapter code.

-- WarehouseCustomSqlErrors.XmlParsingError
EXEC sp_addmessage 6000001, 16, 'Error %%error="%d";%%message=%s', @lang='us_english', @replace = replace
