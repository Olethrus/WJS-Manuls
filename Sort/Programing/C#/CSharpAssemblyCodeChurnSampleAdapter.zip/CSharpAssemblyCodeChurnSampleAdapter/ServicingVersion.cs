﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace CSharpAssemblyCodeChurnSample.Adapter
{
    using System;
    using System.Diagnostics;
    using System.Globalization;

    using Microsoft.TeamFoundation.Framework.Server;
    using Microsoft.TeamFoundation.Server;
    using Microsoft.TeamFoundation.Warehouse;

    /// <summary>
    /// This small helper class checks the version of the schema that this adapter installs.
    /// 
    /// It does this by checking a property bag value (one for Warehouse schema version, and one for Analysis DB schema
    /// version).  Another option would be to check the schema itself.  This is alright as long as it is a fairly lightweight
    /// operation - this needs to be checked each time the adapter makes data changes.
    /// 
    /// The version checking done here is specific to the adapter (i.e. the Warehouse property keys used are for this adapter, and 
    /// error messages include this adapter).  This could be generalized if needed.
    /// </summary>
    internal class SchemaVersion
    {
        #region Fields

        /// <summary>
        /// The current version of this adapter/assembly.  This will be used for both the 
        /// Warehouse and Analysis schema version.
        /// </summary>
        public Version CurrentVersion = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;

        /// <summary>
        /// The Analysis schema version of this adapter.
        /// </summary>
        private const string AnalysisSchemaVersionPropertyName = "/Adapter/Schema/CSharpAssemblyCodeChurnSampleAdapter/AnalysisSchemaVersion";

        /// <summary>
        /// The Warehouse schema version of this adapter.
        /// </summary>
        private const string WarehouseSchemaVersionPropertyName = "/Adapter/Schema/CSharpAssemblyCodeChurnSampleAdapter/WarehouseSchemaVersion";

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Create a schema version object assocated with a Warehouse Context.
        /// </summary>
        /// <param name="warehouseContext">Warehouse context.</param>
        /// <param name="requestContext">Request context.</param>
        public SchemaVersion(WarehouseContext warehouseContext, TeamFoundationRequestContext requestContext)
        {
            WarehouseContext = warehouseContext;
            RequestContext = requestContext;
        }

        #endregion Constructors

        #region Enumerations

        /// <summary>
        /// The action required to bring the version from its current version to the version of this assembly.
        /// </summary>
        public enum ActionRequired
        {
            None = 0,
            Install,
            Upgrade,
            Downgrade
        }

        #endregion Enumerations

        #region Properties

        /// <summary>
        /// The Request Context associated with the operational store for which this adapter is running.
        /// </summary>
        private TeamFoundationRequestContext RequestContext
        {
            get; set;
        }

        /// <summary>
        /// The Warehouse context.
        /// </summary>
        private WarehouseContext WarehouseContext
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Return any action required by this adapter to bring the Analysis DB to this adapter's version.
        /// </summary>
        /// <returns>Action required.</returns>
        public ActionRequired AnalysisActionRequired()
        {
            return GetActionRequired(AnalysisSchemaVersionPropertyName);
        }

        /// <summary>
        /// Get the current Analysis DB version for this adapter.
        /// </summary>
        /// <returns>String value of version</returns>
        public string GetCurrentAnalysisVersionAsString()
        {
            using (WarehouseDataAccessComponent dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                return dac.GetProperty(null, AnalysisSchemaVersionPropertyName);
            }
        }

        /// <summary>
        /// Get the current Warehouse version for this adapter.
        /// </summary>
        /// <returns>String value of version</returns>
        public string GetCurrentWarehouseVersionAsString()
        {
            using (WarehouseDataAccessComponent dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                return dac.GetProperty(null, WarehouseSchemaVersionPropertyName);
            }
        }

        /// <summary>
        /// Set the Analysis DB version for this adapter's schema to version of this assembly.
        /// </summary>
        public void SetCurrentAnalysisVersion()
        {
            SetCurrentVersion(AnalysisSchemaVersionPropertyName);
        }

        /// <summary>
        /// Set the Warehouse version for this adapter's schema to version of this assembly.
        /// </summary>
        public void SetCurrentWarehouseVersion()
        {
            SetCurrentVersion(WarehouseSchemaVersionPropertyName);
        }

        /// <summary>
        /// Return any action required by this adapter to bring the Warehouse to this adapter's version.
        /// </summary>
        /// <returns>Action required.</returns>
        public ActionRequired WarehouseActionRequired()
        {
            return GetActionRequired(WarehouseSchemaVersionPropertyName);
        }

        /// <summary>
        /// Get the action required to bring the item associated with the given schema version level property bag key
        /// to the current version.
        /// </summary>
        /// <param name="schemaVersionPropertyBagKey">Property bag key.</param>
        /// <returns>Action required.</returns>
        private ActionRequired GetActionRequired(string schemaVersionPropertyBagKey)
        {
            using (WarehouseDataAccessComponent dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                string currentVersionInWarehouse = dac.GetProperty(null, schemaVersionPropertyBagKey);

                if (String.IsNullOrEmpty(currentVersionInWarehouse))
                {
                    // No version level is currently defined for this adapter.  We can install.
                    return ActionRequired.Install;
                }

                Version currentWarehouseVersion;

                if (!Version.TryParse(currentVersionInWarehouse, out currentWarehouseVersion))
                {
                    // Cannot determine current version.
                    throw new WarehouseException(
                        String.Format(CultureInfo.CurrentCulture,
                                      Resources.CannotDetermineVersion,
                                      currentVersionInWarehouse)
                        );
                }

                int compareValue = CurrentVersion.CompareTo(currentWarehouseVersion);

                if (compareValue == 0)
                {
                    return ActionRequired.None;
                }

                if (compareValue < 0)
                {
                    return ActionRequired.Upgrade;
                }

                return ActionRequired.Downgrade;
            }
        }

        /// <summary>
        /// Set the version associated with the given key for this adapter's schema to version of this assembly.
        /// </summary>
        /// <param name="schemaVersionPropertyBagKey"></param>
        private void SetCurrentVersion(string schemaVersionPropertyBagKey)
        {
            using (var dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                try
                {
                    dac.SetProperty(null, schemaVersionPropertyBagKey, CurrentVersion.ToString());
                }
                catch
                {
                    // Very basic logging - this should be improved in a production adapter.
                    if (!EventLog.SourceExists(AdapterConstants.LogId.EventSource))
                    {
                        EventLog.CreateEventSource(AdapterConstants.LogId.EventSource, AdapterConstants.LogId.LogName);
                    }

                    EventLog.WriteEntry(
                        AdapterConstants.LogId.EventSource,
                        Resources.FailedToSetSchemaVersion,
                        EventLogEntryType.Error,
                        AdapterConstants.LogId.FailedParsingProjectFile);

                    throw;
                }
            }
        }

        #endregion Methods
    }
}