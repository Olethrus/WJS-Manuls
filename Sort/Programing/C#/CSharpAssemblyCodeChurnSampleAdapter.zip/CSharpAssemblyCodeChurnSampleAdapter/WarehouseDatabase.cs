﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace CSharpAssemblyCodeChurnSample.Adapter
{
    using Microsoft.TeamFoundation.Warehouse;

    /// <summary>
    /// The Warehouse Database.
    /// 
    /// Some wrapper methods to create a simple interface to the Warehouse DB.  This could be data driven.
    /// </summary>
    /// <remarks>
    /// This could also be implemented as a singleton - if this is done be sure the design accounts for the fact that 
    /// multiple instances of this adapter can be running against different operational stores on different threads.
    /// </remarks>
    internal class WarehouseDatabase
    {
        #region Constructors

        /// <summary>
        /// Create a new Warehouse Database interface and initialize its members.
        /// </summary>
        /// <param name="warehouseContext">The warehouse context.</param>
        public WarehouseDatabase(WarehouseContext warehouseContext)
        {
            WarehouseContext = warehouseContext;

            CSharpAssemblyTable = new CSharpAssemblyTable(WarehouseContext);
            CSharpAssemblyToFilesMappingTable = new CSharpAssemblyToFilesMappingTable(WarehouseContext);
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// The CSharp Assembly table.
        /// </summary>
        public CSharpAssemblyTable CSharpAssemblyTable
        {
            get; private set;
        }

        /// <summary>
        /// The CSharp Assembly to File mapping table.
        /// </summary>
        public CSharpAssemblyToFilesMappingTable CSharpAssemblyToFilesMappingTable
        {
            get; private set;
        }

        /// <summary>
        /// The Warehouse context.
        /// </summary>
        private WarehouseContext WarehouseContext
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Create the schema (tables and stored procedures) associated with this adapter in the Warehouse.
        /// </summary>
        public void CreateSchema()
        {
            // Create the custom error messages.  The Stored procedures created below will reference these.
            using (var dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                dac.ExecuteNonQuery(System.Data.CommandType.Text,
                    SqlResources.CreateCustomSqlMessages,
                    null);
            }

            // Create the schema for the custom tables.
            CSharpAssemblyTable.CreateSchema();
            CSharpAssemblyToFilesMappingTable.CreateSchema();
        }

        #endregion Methods
    }
}