﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace CSharpAssemblyCodeChurnSample.Adapter
{
    using System;

    using Microsoft.TeamFoundation.Framework.Server;

    /// <summary>
    /// This is a simple wrapper on the Warehouse Job Service exposing just the functionality required by this adapter.
    /// 
    /// It would be better, in terms of forward compatibility, to use the WarehouseControlWebService instead of using 
    /// the Job Service directly.  However for this simple sample adapter I don't want to include all the proxy code 
    /// to the web service so this approach is taken.
    /// </summary>
    internal class WarehouseJobService
    {
        #region Fields

        /// <summary>
        /// Time to delay running a job when it is queued.
        /// </summary>
        private const int JobScheduleDelay = 3 * 60;

        /// <summary>
        /// Well known analysis full process job identity.
        /// </summary>
        private static readonly Guid AnalysisSyncFullJobIdentity = new Guid(@"702b715e-0814-464b-aea2-1462796ba823");

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Create a Warehouse job service wrapper.
        /// </summary>
        /// <param name="collectionRequestContext">Collection level request context.</param>
        public WarehouseJobService(TeamFoundationRequestContext collectionRequestContext)
        {
            RequestContext = collectionRequestContext;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Collection level request context.
        /// </summary>
        protected TeamFoundationRequestContext RequestContext
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Schedule an Analysis process.
        /// </summary>
        /// <remarks>
        /// This should not be done under normal operations (i.e. after making data changes).
        /// </remarks>
        internal void TryScheduleAnalysisProcess()
        {
            const string jobType = @"JobType";
            var jobDataDelimiters = new[] { ';', '=' }; // Delimiters for the Job Data {item 1 name}={item 1 value};{item 2 name}={item 2 value}...

            var applicationRequestContext = RequestContext.CreateImpersonationContext(RequestContext.ServiceHost.TopmostServiceHost);

            var jobService = applicationRequestContext.GetService<TeamFoundationJobService>();
            var jobDefinitions = jobService.QueryJobDefinitions(applicationRequestContext, null);

            foreach (var jobDefinition in jobDefinitions)
            {
                if (jobDefinition.Data != null && jobDefinition.Data.InnerText != null)
                {
                    string jobData = jobDefinition.Data.InnerText;
                    string[] toks = jobData.Split(jobDataDelimiters, StringSplitOptions.RemoveEmptyEntries);
                    for (int i = 0; i < toks.Length; i++)
                    {
                        string tok = toks[i];

                        if (String.Equals(tok, jobType, StringComparison.OrdinalIgnoreCase))
                        {
                            if (++i < toks.Length)
                            {
                                Guid jobGuid;
                                if (Guid.TryParse(toks[i], out jobGuid))
                                {
                                    if (jobGuid.Equals(AnalysisSyncFullJobIdentity))
                                    {
                                        // Found the full analysis sync job definition; queue it.
                                        jobService.QueueDelayedJobs(applicationRequestContext,
                                            new[] { jobDefinition.JobId }, JobScheduleDelay);
                                        return;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        #endregion Methods
    }
}