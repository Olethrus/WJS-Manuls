﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace CSharpAssemblyCodeChurnSample.Adapter
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Globalization;
    using System.Text;
    using System.Xml;

    using Microsoft.TeamFoundation.Warehouse;
    using System.Diagnostics;

    /// <summary>
    /// A generic Warehouse table used by this adapter.
    /// </summary>
    internal abstract class WarehouseTable
    {
        #region Fields

        /// <summary>
        /// The batch of entries that are pending save.
        /// 
        /// This is a dictionary of entry cell values keyed by the column name.
        /// </summary>
        private readonly Dictionary<string, Hashtable> _entryBatch = new Dictionary<string, Hashtable>();

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Create a Warehouse Table.
        /// </summary>
        /// <param name="warehouseContext"></param>
        protected WarehouseTable(WarehouseContext warehouseContext)
        {
            WarehouseContext = warehouseContext;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// The business key for this table.
        /// </summary>
        public abstract string BusinessKeyFieldName
        {
            get;
        }

        /// <summary>
        /// The surrogate key for this table.
        /// </summary>
        public abstract string SurrogateKeyFieldName
        {
            get;
        }

        /// <summary>
        /// The name of this table.
        /// </summary>
        public abstract string TableName
        {
            get;
        }

        /// <summary>
        /// The SQL used to create the stored procedure used to load data into the Warehouse.
        /// </summary>
        protected abstract string CreateLoadDataStoredProcedureText
        {
            get;
        }

        /// <summary>
        /// The SQL used to create this table in the Warehouse.
        /// </summary>
        protected abstract string CreateTableText
        {
            get;
        }

        /// <summary>
        /// The name of the stored procedure in the Warehouse used to load or update entries in this table.
        /// </summary>
        protected abstract string LoadDataStoredProcedureName
        {
            get;
        }

        /// <summary>
        /// The Warehouse context.
        /// </summary>
        protected WarehouseContext WarehouseContext
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Add a new entry in this object to the batch.
        /// </summary>
        /// <returns>The batched item.</returns>
        public virtual Hashtable CreateBatchedEntry(string businessKeyValue)
        {
            var entry = new Hashtable();
            entry[BusinessKeyFieldName] = businessKeyValue;

            _entryBatch[businessKeyValue] = entry;

            return entry;
        }

        /// <summary>
        /// Create the schema required for this object.
        /// </summary>
        public virtual void CreateSchema()
        {
            CreateTable();
            CreateLoadStoredProcedure();
        }

        /// <summary>
        /// Create this table in the Warehouse if it does not already exist.
        /// </summary>
        public virtual void CreateTable()
        {
            using (WarehouseDataAccessComponent dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                dac.ExecuteNonQuery(CommandType.Text,
                    String.Format(CultureInfo.InvariantCulture, SqlResources.CreateTableIfNotExistFormat, TableName, CreateTableText),
                    null);
            }
        }

        /// <summary>
        /// Save all the entries currently in the batch.
        /// </summary>
        public virtual void SaveBatch()
        {
            if (_entryBatch.Count > 0)
            {
                var datasetXml = ConvertEntriesToXml(_entryBatch.Values);

                using (var dac = WarehouseContext.CreateWarehouseDataAccessComponent())
                {
                    dac.ExecuteNonQuery(
                        CommandType.StoredProcedure,
                        LoadDataStoredProcedureName,
                        new List<SqlParameter>(1)
                    {
                        new SqlParameter("@" + AdapterConstants.DataSerialization.SqlBatchName, SqlDbType.NVarChar, datasetXml.Length) { Value = datasetXml }
                    });
                }

                _entryBatch.Clear();
            }
        }

        /// <summary>
        /// Convert IEnumerable members into XML to pass to the batch save stored procedure.
        /// </summary>
        protected static string ConvertEntriesToXml(IEnumerable<Hashtable> members)
        {
            var xmlBuilder = new StringBuilder();
            var settings = new XmlWriterSettings {OmitXmlDeclaration = true};

            using (var writer = XmlWriter.Create(xmlBuilder, settings))
            {
                Debug.Assert(writer != null);

                writer.WriteStartDocument();
                writer.WriteStartElement(AdapterConstants.DataSerialization.SqlBatchXmlRootElement);
                foreach (Hashtable member in members)
                {
                    writer.WriteStartElement(AdapterConstants.DataSerialization.SqlBatchXmlRowElement);
                    foreach (string key in member.Keys)
                    {
                        writer.WriteAttributeString(key, FormatValue(member[key]));
                    }
                    writer.WriteEndElement();
                }
                writer.WriteEndElement();
                writer.WriteEndDocument();
                writer.Close();
            }

            return xmlBuilder.ToString();
        }

        /// <summary>
        /// Create the stored procedure used to load data into the Warehouse.  If the stored procedure already exists this will
        /// delete and recreate it.
        /// </summary>
        protected virtual void CreateLoadStoredProcedure()
        {
            using (WarehouseDataAccessComponent dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                dac.ExecuteNonQuery(CommandType.Text,
                    String.Format(CultureInfo.InvariantCulture, SqlResources.DropProcedureIfExistsFormat, LoadDataStoredProcedureName),
                    null);

                dac.ExecuteNonQuery(CommandType.Text,
                    CreateLoadDataStoredProcedureText,
                    null);
            }
        }

        /// <summary>
        /// Get a generic business key in the standard format.
        /// </summary>
        /// <param name="keyComponents">Components of business key.</param>
        /// <returns>Business key in the format {component 1}|{component 2}|...|{component N}</returns>
        protected virtual string GetBusinessKey(params string[] keyComponents)
        {
            IEnumerator enumerator = keyComponents.GetEnumerator();
            enumerator.MoveNext();
            var key = (string) enumerator.Current;
            while(enumerator.MoveNext())
            {
                key += "|" + enumerator.Current;
            }
            return key;
        }

        /// <summary>
        /// Format a value object into a string
        /// </summary>
        private static string FormatValue(object value)
        {
            if (value is DateTime)
            {
                return ((DateTime)value).ToString(AdapterConstants.DataSerialization.SqlDateTimeFormat, DateTimeFormatInfo.InvariantInfo);
            }
            
            return value.ToString();
        }

        #endregion Methods
    }
}