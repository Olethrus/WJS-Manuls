﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace CSharpAssemblyCodeChurnSample.Adapter
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Globalization;

    using Microsoft.TeamFoundation.Warehouse;

    /// <summary>
    /// The CSharp Assembly table.
    /// </summary>
    internal class CSharpAssemblyTable : WarehouseTable
    {
        #region Fields

        /// <summary>
        /// The batch of entries that are pending destruction.
        /// 
        /// This is a list of entry cell values keyed by the column name.
        /// </summary>
        private readonly List<Hashtable> _destroyEntryBatch = new List<Hashtable>();

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Create a CSharp Assembly table wrapper.
        /// </summary>
        /// <param name="warehouseContext">Warehouse Context</param>
        public CSharpAssemblyTable(WarehouseContext warehouseContext)
            : base(warehouseContext)
        {
        }

        #endregion Constructors

        #region Properties

        public override string BusinessKeyFieldName
        {
            get { return AdapterConstants.CSharpAssemblyTable.BusinessKeyFieldName; }
        }

        public override string SurrogateKeyFieldName
        {
            get { return AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName; }
        }

        public override string TableName
        {
            get { return AdapterConstants.CSharpAssemblyTable.TableName; }
        }

        protected override string CreateLoadDataStoredProcedureText
        {
            get
            {
                return String.Format(CultureInfo.InvariantCulture,
                    SqlResources.CreateCSharpAssemblyAddUpdateProcedure,
                    LoadDataStoredProcedureName,
                    AdapterConstants.DataSerialization.SqlBatchXmlRootElement,
                    AdapterConstants.DataSerialization.SqlBatchXmlRowElement,
                    TableName,
                    BusinessKeyFieldName,
                    AdapterConstants.CSharpAssemblyTable.AssemblyNameColumnName,
                    AdapterConstants.CSharpAssemblyTable.OutputTypeColumnName,
                    AdapterConstants.DataSerialization.SqlBatchName);
            }
        }

        protected override string CreateTableText
        {
            get
            {
                return String.Format(CultureInfo.InvariantCulture,
                    SqlResources.CreateCSharpAssemblyTable,
                    TableName,
                    SurrogateKeyFieldName,
                    BusinessKeyFieldName,
                    AdapterConstants.CSharpAssemblyTable.TeamProjectCollectionKeyColumnName,
                    AdapterConstants.CSharpAssemblyTable.AssemblyNameColumnName,
                    AdapterConstants.CSharpAssemblyTable.OutputTypeColumnName);
            }
        }

        protected override string LoadDataStoredProcedureName
        {
            get { return AdapterConstants.CSharpAssemblyTable.LoadDataStoredProcedureName; }
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Add a new entry to the batch to destroy the item with the given business key.
        /// </summary>
        /// <remarks>
        /// Destroy here means to delete the entry and all dependent entries.
        /// </remarks>
        /// <param name="businessKeyValue">Business key of the item to destroy.</param>
        public virtual void CreateBatchedDestroyEntry(string businessKeyValue)
        {
            var entry = new Hashtable();
            entry[BusinessKeyFieldName] = businessKeyValue;

            _destroyEntryBatch.Add(entry);
        }

        /// <summary>
        /// Create the schema for this table.
        /// </summary>
        public override void CreateSchema()
        {
            // First create the base table and ETL procedure.
            base.CreateSchema();

            // Next add the additional procedure to destroy items in this table.
            CreateDestroyStoredProcedure();
        }

        /// <summary>
        /// Return the business key for this table given its parts.
        /// </summary>
        /// <remarks>
        /// In this case the business key cannot rely on any data inside the actual CSharp Project file (i.e. the assembly name)
        /// because we may not have the contents of the file around when we need to process the change in version control. 
        /// For example if the project file has been destroyed we need to remove the Assembly entry and all the mappings for that assembly.
        /// </remarks>
        /// <param name="tpcGuid">Team Project Collection Id.</param>
        /// <param name="projectFile">Full path and file name of the project file.</param>
        /// <returns>Business Key</returns>
        public string GetBusinessKey(string tpcGuid, string projectFile)
        {
            return base.GetBusinessKey(tpcGuid, projectFile);
        }

        /// <summary>
        /// Save all batched ETL for this table.
        /// 
        /// This will first destroy all detroy items batched, then add the new items.  It does not 
        /// interleave destroys and new items in the order that they were added to the batch.
        /// </summary>
        public override void SaveBatch()
        {
            // First destroy exising entries.
            if (_destroyEntryBatch.Count > 0)
            {
                string datasetXml = ConvertEntriesToXml(_destroyEntryBatch);

                using (WarehouseDataAccessComponent dac = WarehouseContext.CreateWarehouseDataAccessComponent())
                {
                    dac.ExecuteNonQuery(
                        CommandType.StoredProcedure,
                        AdapterConstants.CSharpAssemblyTable.DestroyDataStoredProcedureName,
                        new List<SqlParameter>(1)
                    {
                        new SqlParameter("@" + AdapterConstants.DataSerialization.SqlBatchName, SqlDbType.NVarChar, datasetXml.Length) { Value = datasetXml }
                    });
                }

                _destroyEntryBatch.Clear();
            }

            // Now save the new entries.
            base.SaveBatch();
        }

        /// <summary>
        /// Create a stored procedure used to destroy batches of CSharp Assembly entries.
        /// </summary>
        protected virtual void CreateDestroyStoredProcedure()
        {
            using (WarehouseDataAccessComponent dac = WarehouseContext.CreateWarehouseDataAccessComponent())
            {
                dac.ExecuteNonQuery(CommandType.Text,
                    String.Format(CultureInfo.InvariantCulture, SqlResources.DropProcedureIfExistsFormat, AdapterConstants.CSharpAssemblyTable.DestroyDataStoredProcedureName),
                    null);

                string destroyStoredProcedure = String.Format(CultureInfo.InvariantCulture,
                    SqlResources.CreateCSharpAssemblyDestroyProcedure,
                    AdapterConstants.CSharpAssemblyTable.DestroyDataStoredProcedureName,
                    AdapterConstants.DataSerialization.SqlBatchXmlRootElement,
                    AdapterConstants.DataSerialization.SqlBatchXmlRowElement,
                    TableName,
                    BusinessKeyFieldName,
                    AdapterConstants.DataSerialization.SqlBatchName,
                    AdapterConstants.CSharpAssemblyToFilesMappingTable.TableName);

                dac.ExecuteNonQuery(CommandType.Text,
                    destroyStoredProcedure,
                    null);
            }
        }

        #endregion Methods
    }

    /// <summary>
    /// The CSharp Assembly to File mapping table.
    /// </summary>
    internal class CSharpAssemblyToFilesMappingTable : WarehouseTable
    {
        #region Constructors

        /// <summary>
        /// Create a CSharp Assembly to Files table wrapper.
        /// </summary>
        /// <param name="warehouseContext">Warehouse Context</param>
        public CSharpAssemblyToFilesMappingTable(WarehouseContext warehouseContext)
            : base(warehouseContext)
        {
        }

        #endregion Constructors

        #region Properties

        public override string BusinessKeyFieldName
        {
            get { return AdapterConstants.CSharpAssemblyToFilesMappingTable.BusinessKeyFieldName; }
        }

        public override string SurrogateKeyFieldName
        {
            get { return AdapterConstants.CSharpAssemblyToFilesMappingTable.SurrogateKeyFieldName; }
        }

        public override string TableName
        {
            get { return AdapterConstants.CSharpAssemblyToFilesMappingTable.TableName; }
        }

        protected override string CreateLoadDataStoredProcedureText
        {
            get
            {
                return String.Format(CultureInfo.InvariantCulture,
                    SqlResources.CreateCSharpAssemblyToFilesMappingAddUpdateProcedure,
                    LoadDataStoredProcedureName,
                    AdapterConstants.DataSerialization.SqlBatchXmlRootElement,
                    AdapterConstants.DataSerialization.SqlBatchXmlRowElement,
                    TableName,
                    BusinessKeyFieldName,
                    AdapterConstants.CSharpAssemblyTable.TableName,
                    AdapterConstants.CSharpAssemblyTable.BusinessKeyFieldName,
                    AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName,
                    AdapterConstants.DataSerialization.SqlBatchName);
            }
        }

        protected override string CreateTableText
        {
            get
            {
                return String.Format(CultureInfo.InvariantCulture,
                    SqlResources.CreateCSharpAssemblyToFilesMappingTable,
                    TableName,
                    SurrogateKeyFieldName,
                    BusinessKeyFieldName,
                    AdapterConstants.CSharpAssemblyTable.TableName,
                    AdapterConstants.CSharpAssemblyTable.SurrogateKeyFieldName,
                    AdapterConstants.FileTable.SurrogateKeyFieldName);
            }
        }

        protected override string LoadDataStoredProcedureName
        {
            get { return AdapterConstants.CSharpAssemblyToFilesMappingTable.LoadDataStoredProcedureName; }
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Return the business key for this table given its parts.
        /// </summary>
        /// <param name="csharpAssemblyBk">The business key for the CSharp Assembly.</param>
        /// <param name="file">The full path and file name for the file.</param>
        /// <returns>Business Key</returns>
        public string GetBusinessKey(string csharpAssemblyBk, string file)
        {
            return base.GetBusinessKey(csharpAssemblyBk, file);
        }

        #endregion Methods
    }
}