﻿#region Header

//***************************************************************************
//
//    Copyright (c) Microsoft Corporation. All rights reserved.
//    This code is licensed under the Visual Studio SDK license terms.
//    THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
//    ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
//    IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
//    PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
//
//***************************************************************************

#endregion Header

namespace SetupCSharpCodeChurnAdapter
{
    using System;
    using System.Globalization;

    /// <summary>
    /// A simple command line tool used to create or delete a Warehouse job and schedule for the CSharp Assembly Code Churn adapter.
    /// 
    /// In order to fully install and configure this custom adapter you need to do the following:
    ///  - Build the CSharpAssemblyCodeChurnSample.Adapter and copy it to the 
    ///      %ProgramFiles%\Microsoft Team Foundation Server 2010\Application Tier\TFSJobAgent\plugins
    ///    directory on all of your Team Foundation Server Application Tier machines.  Assemblies in
    ///    this location will be loaded by the TFS Job Agent.
    ///  - Restart the "Visual Studio Team Foundation Background Job Agent" service.  This will
    ///    force the TFS Job Agent to reload all the job plugins.
    ///      net stop TfsJobAgent
    ///      net start TfsJobAgent
    ///  - Run this executable with the -c flag.  This will create a TFS Job and schedule for the custom
    ///    adapter.
    /// 
    /// In order to fully uninstall this custom adapter and remove all related schema from the Warehouse 
    /// you will need to do the following:
    ///  - Run this executable with the -d flag.  This will delete the TFS Job and schedule for the custom
    ///    adapter.
    ///  - Delete the CSharpAssemblyCodeChurnSample.Adapter assembly from the 
    ///      %ProgramFiles%\Microsoft Team Foundation Server 2010\Application Tier\TFSJobAgent\plugins
    ///    directory.
    ///  - Rebuild the Warehouse
    ///      Either use TfsConfig.exe rebuildWarehouse /all
    ///              or Tfs Administration Console, under the Application Tier -> Reporting pane click "Start Rebuild"
    ///    This will rebuild the Warehouse schema and data without the custom schema added by this adapter.
    /// </summary>
    public class ManageCustomWarehouseJob
    {
        #region Fields

        /// <summary>
        /// The custom adapter job extension.  This is in the format:
        ///     {Assembly Name}.{WarehouseSyncJobExtension class name}
        /// See the CSharpAssemblyCodeChurnSampleSyncJobExtension class in the CSharpAssemblyCodeChurnSampleAdapter.cs file.
        /// </summary>
        const string CustomAdapterJobExtensionName = "CSharpAssemblyCodeChurnSample.Adapter.CSharpAssemblyCodeChurnSampleSyncJobExtension";

        /// <summary>
        /// The custom adapter job name.  This is the friendly name, but within this sample it is assumed to be unique.
        /// </summary>
        const string CustomAdapterJobName = "CSharp Assembly Code Churn Sample Adapter";

        #endregion Fields

        #region Methods

        static void Main(string[] args)
        {
            if (args.Length != 2 || args[0].Length != 2 || args[0][0] != '-')
            {
                Console.WriteLine(Resource.Usage);
                return;
            }

            var tfsServerUrl = args[1];
            var jobManager = new WarehouseJobManager(new Uri(tfsServerUrl));

            switch (args[0][1])
            {
                case 'c':
                    if (jobManager.CreateJob(CustomAdapterJobName, CustomAdapterJobExtensionName))
                    {
                        Console.WriteLine(String.Format(CultureInfo.CurrentCulture,
                            Resource.CreatedJob,
                            CustomAdapterJobName,
                            CustomAdapterJobExtensionName));
                    }
                    else
                    {
                        Console.WriteLine(String.Format(CultureInfo.CurrentCulture,
                            Resource.JobAlreadyExists,
                            CustomAdapterJobName));
                    }
                    break;
                case 'd':
                    if (jobManager.DeleteJob(CustomAdapterJobName))
                    {
                        Console.WriteLine(String.Format(CultureInfo.CurrentCulture,
                            Resource.JobDeleted,
                            CustomAdapterJobName));
                    }
                    else
                    {
                        Console.WriteLine(String.Format(CultureInfo.CurrentCulture,
                            Resource.JobNotFound,
                            CustomAdapterJobName));
                    }
                    break;
                default:
                    Console.WriteLine(Resource.Usage);
                    break;
            }
        }

        #endregion Methods
    }
}