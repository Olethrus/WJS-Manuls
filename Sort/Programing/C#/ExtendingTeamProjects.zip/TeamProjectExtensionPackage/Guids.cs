﻿namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
    using System;

    static class GuidList
    {
        #region Fields

        public const string GuidProjectCreationWizardPluginString = "6AB375D6-0577-4ee7-A7E3-BA9E59F11D32";
        public const string GuidTeamExplorerExtensionCommandSetString = "10dab6af-1ad4-44c2-a53f-2dcf417788a2";
        public const string GuidTeamExplorerPluginString = "29623139-f55d-404e-985d-a95f46337049";
        public const string GuidTeamProjectExtensionPackageString = "3406498a-625e-424e-a7ec-f035187e7abb";

        public static readonly Guid GuidTeamExplorerExtensionCommandSet = new Guid(GuidTeamExplorerExtensionCommandSetString);

        #endregion Fields
    }
}