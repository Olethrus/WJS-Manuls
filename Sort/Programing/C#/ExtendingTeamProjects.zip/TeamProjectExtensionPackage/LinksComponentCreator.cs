﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;
    using System.Xml;
    using System.Xml.Schema;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.TeamFoundation.Server;

    /// <summary>
    /// The LinksProjectComponentCreator retrieves a set of links specified in the
    /// process template, merges them with the set of links specified by the
    /// user in the Project Creation Wizard plug-in and writes the union of
    /// those sets out to the project context object.
    /// </summary>
    public class LinksProjectComponentCreator : IProjectComponentCreator
    {
        #region Properties

        /// <summary>
        /// Stores a reference to the actual Wizard Page (WinForms).
        /// </summary>
        /// <value>The wizard page.</value>
        public PluginSampleWizardPage WizardPage
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// This method is not implemented.
        /// </summary>
        /// <exception cref="NotImplementedException"></exception>
        public void CreateLink(ProjectCreationContext context, string sourceId, string targetUri, string type)
        {
            throw new NotImplementedException("Linking is not supported");
        }

        /// <summary>
        /// Constructs the content for this extension that's used to create the team project
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="taskXml">The task XML.</param>
        public void Execute(ProjectCreationContext context, XmlNode taskXml)
        {
            var assemblyName = GetType().Assembly.GetName().Name;

            context.Logger.LogEvent(assemblyName, LogLevels.Informational,
                "Preparing links for upload");

            var projectName = context.PublicData[PublicDataKeys.ProjectName].ToString();

            // validate taskXml against schema
            Validate(context, taskXml);

            // create xml structure: project-folders-links
            var rootXml = taskXml.SelectSingleNode("descendant::Root");
            var document = new XmlDocument();
            var projectElement = document.CreateElement("project");

            projectElement.SetAttribute("name", projectName);
            document.AppendChild(projectElement);

            // Add items from the taskXml
            projectElement.InnerXml = rootXml.InnerXml;

            var projectContext = new ProjectContextWrapper(context);

            if ((projectContext.Links.Count > 0) || (projectContext.AddWebAccessLink))
            {
                // Add items from the our PCW Wizard Page
                var userFolderElement = document.CreateElement("folder");
                userFolderElement.SetAttribute("name", Resources.FolderName_UserSpecifiedLinks);
                projectElement.AppendChild(userFolderElement);

                if (projectContext.AddWebAccessLink)
                {
                    projectContext.Links.Add(new KeyValuePair<String, Uri>(
                        Resources.LinkName_WebAccess, GetWebAccessUri(context)));
                }

                foreach (var link in projectContext.Links)
                {
                    var linkElement = document.CreateElement("link");
                    linkElement.SetAttribute("name", link.Key);
                    linkElement.SetAttribute("url", link.Value.ToString());
                    userFolderElement.AppendChild(linkElement);
                }
            }

            SaveLinksToProjectProperty(context, document);

            // write the actual XML content to the project creation log
            context.Logger.LogEvent(assemblyName, LogLevels.Informational, document);
        }

        /// <summary>
        /// Once the user completes the project creation wizard, the resulting data
        /// is used to create the team project on the project collection. This is the
        /// first method that gets called in the course of that process.
        /// </summary>
        /// <param name="context">The project creation context obect which, among
        /// other things, stores a set of public and private contextual data related
        /// to the creation of the team project.</param>
        public void Initialize(ProjectCreationContext context)
        {
            // this plug-in doesn't require any special initialization at this stage
            // of the team project creation process
        }

        /// <summary>
        /// Validates the XML provided for this task in the process template.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="taskXml">The task XML.</param>
        public void Validate(ProjectCreationContext context, XmlNode taskXml)
        {
            XmlReader reader = null;
            Stream stream = null;

            try
            {
                var assembly = Assembly.GetExecutingAssembly();

                stream = assembly.GetManifestResourceStream(
                    "ExtendingTeamProjects.TeamProjectExtensionPackage.PluginSampleSchema.xsd");

                // Construct the schema object.
                if (stream != null)
                {
                    // read in the XML schema
                    var schema = XmlSchema.Read(stream, null);

                    // Prepare the schema settings.
                    var settings = new XmlReaderSettings();
                    settings.Schemas.Add(schema);
                    settings.ValidationType = ValidationType.Schema;
                    settings.ValidationEventHandler += ValidationHandler;

                    // Create the reader.
                    using (var nodeReader = new XmlNodeReader(taskXml))
                    {
                        reader = XmlReader.Create(nodeReader, settings);

                        // Read the entire xml.
                        while (reader.Read())
                        {
                        }
                    }
                }
            }
            finally
            {
                if (reader != null)
                {
                    ((IDisposable)reader).Dispose();
                }
                if (stream != null)
                {
                    stream.Close();
                }
            }
        }

        /// <summary>
        /// Given the Server and Project Uri, get the Url of the Team Project
        /// in Team System Web Access
        /// </summary>
        /// <param name="context">The context.</param>
        /// <returns></returns>
        private static Uri GetWebAccessUri(ProjectCreationContext context)
        {
            // get the hyperlink service for the team project collection
            var collectionUri = new Uri(context.PublicData[PublicDataKeys.ServerUri].ToString());
            var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri);
            var hyperlinkService = projectCollection.GetService<TswaClientHyperlinkService>();

            // use the hyperlink service to get the home page of our team project
            var projectUri = new Uri(context.PublicData[PublicDataKeys.ProjectUri].ToString());
            return hyperlinkService.GetHomeUrl(projectUri);
        }

        /// <summary>
        /// Saves the links to project property.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="xmlLinks">The XML links.</param>
        private static void SaveLinksToProjectProperty(ProjectCreationContext context, XmlDocument xmlLinks)
        {
            var collectionUri = new Uri(context.PublicData[PublicDataKeys.ServerUri].ToString());
            var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri);
            var commonStructureService = projectCollection.GetService<ICommonStructureService>();
            var projectUri = context.PublicData[PublicDataKeys.ProjectUri].ToString();

            string name, state;
            int templateId;
            ProjectProperty[] properties;

            // get the team project's properties from the server
            commonStructureService.GetProjectProperties(projectUri,
                                                        out name, out state, out templateId, out properties);

            // construct a new properties collection from the current properties
            var newProperties = new List<ProjectProperty>(properties)
                                    {
                                        // add a property with the set of links to be shown in Team Explorer
                                        new ProjectProperty(TeamExplorerPlugin.LinkProjectPropertyName,
                                                            xmlLinks.OuterXml)
                                    };

            // save the new properties to the server
            commonStructureService.UpdateProjectProperties(projectUri,
                                                           state, newProperties.ToArray());
        }

        /// <summary>
        /// Handle XML validation errors
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="args">The <see cref="System.Xml.Schema.ValidationEventArgs"/> instance containing the event data.</param>
        private static void ValidationHandler(object sender, ValidationEventArgs args)
        {
            // Bail out only on errors.
            if (args.Severity == XmlSeverityType.Error)
            {
                throw args.Exception;
            }
        }

        #endregion Methods
    }
}