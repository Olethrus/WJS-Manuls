﻿/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/
namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
    static class PkgCmdIdList
    {
        #region Fields

        /// <summary>
        /// This is the command identifier for the actual menu item in our
        /// extension's context menu.
        /// </summary>
        public const uint CmdidHelloPlugin = 0x0100;

        /// <summary>
        /// This is the identifier for the context menu available for our
        /// Team Explorer extension. It's accessed by invoking the context
        /// menu on the root node of our extension in Team Explorer.
        /// </summary>
        public const uint RootContextMenu = 0x1000;

        #endregion Fields
    }
}