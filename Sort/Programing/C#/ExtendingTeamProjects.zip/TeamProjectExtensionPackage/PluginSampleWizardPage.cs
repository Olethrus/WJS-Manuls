#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
    using System;
    using System.Collections.Generic;
    using System.Windows.Forms;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.WizardFramework;
    using System.Runtime.InteropServices;

    /// <summary>
    /// This wizard page is added to the TFS Team Project Creation Wizard
    /// </summary>
    [ComVisible(false)]
    public partial class PluginSampleWizardPage : TeamProjectWizardPage
    {
        #region Fields

        /// <summary>
        /// Reference to the underlying wizard framework form.
        /// </summary>
        private readonly WizardForm _wizardForm;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="PluginSampleWizardPage"/>.
        /// </summary>
        /// <param name="wizardForm">The wizard form.</param>
        /// <param name="context">The context.</param>
        public PluginSampleWizardPage(WizardForm wizardForm, ProjectCreationContext context)
            : base(wizardForm)
        {
            InitializeComponent();
            _wizardForm = wizardForm;
            ProjectContext = new ProjectContextWrapper(context);

            LinkName.HeaderText = Resources.PluginSampleWizardPage_NameColumn;
            LinkUri.HeaderText = Resources.PluginSampleWizardPage_UrlColumn;

            Headline = Resources.WizardPage_Headline;

            // check the 'add web access link' box if appropriate
            AddWebAccessLink.Checked = ProjectContext.AddWebAccessLink;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Wraps the project context to make accessing certain private
        /// data elements more convenient.
        /// </summary>
        /// <value>The project context.</value>
        private ProjectContextWrapper ProjectContext
        {
            get; set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Adds the entries to the Project Creation Wizard's Confirmation page.
        /// Use this method to review the choices the user has made related to your
        /// wizard page.
        /// </summary>
        /// <param name="confBuilder">The conf builder.</param>
        public override void AddConfirmationEntries(ConfirmationBuilder confBuilder)
        {
            // no need to add anything if no links were specified and the web access check box wasn't checked
            if ((ProjectContext.Links.Count <= 0) && (!ProjectContext.AddWebAccessLink)) return;

            confBuilder.AddPageTitle(Resources.Confirmation_Title);

            // if the user has specified at least one link, add an entry
            if (ProjectContext.Links.Count > 0)
            {
                confBuilder.AddPageEntry(Resources.ConfirmationLabel_UserLinks,
                                         String.Format(Resources.ConfirmationPageEntry_LinkCountFormat,
                                         ProjectContext.Links.Count));
            }

            // if the user checked the box to create a web access link, add an entry
            if (ProjectContext.AddWebAccessLink)
            {
                confBuilder.AddPageEntry(Resources.ConfirmationLabel_WebAccessLink,
                                         Resources.ConfirmationPageEntry_WebAccessLinks);
            }
        }

        /// <summary>
        /// Called when the wizard page is activated. The Finish button is disabled so 
        /// that the user needs to complete this page before proceeding.
        /// </summary>
        public override void OnActivated()
        {
            Skippable = true;
            _wizardForm.EnableButton(ButtonType.Finish, true);
            _wizardForm.DefaultButton = ButtonType.Next;

            // if your wizard page should not be skipped, you can use the following line
            // of code in place of the above ->
            // _wizardForm.EnableButton(ButtonType.Finish, false);
        }

        /// <summary>
        /// Called when deactivated, we use this opportunity to save the user-specified
        /// links to the context object.
        /// </summary>
        public override void OnDeactivated()
        {
            // reset the list of links
            ProjectContext.Links.Clear();

            foreach (DataGridViewRow row in Grid.Rows)
            {
                // if we hit the "new" row, then we're at the end of the data
                if (row.IsNewRow) break;

                // add a link using the user-entered data provided
                ProjectContext.Links.Add(new KeyValuePair<String, Uri>(
                                 row.Cells["LinkName"].Value.ToString(),
                                 new Uri(row.Cells["LinkUri"].Value.ToString())));
            }
        }

        /// <summary>
        /// When the check box is clicked in the UI, update the option of whether or 
        /// not to automatically add a link to the portal page for this team project 
        /// to the set of links to present in Team Explorer.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void AddWebAccessLinkCheckedChanged(object sender, EventArgs e)
        {
            // our project context wrapper implements a convenience setter we can use here
            ProjectContext.AddWebAccessLink = AddWebAccessLink.Checked;
        }

        #endregion Methods
    }
}