/***************************************************************************
 
Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.
 
***************************************************************************/
namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
	partial class PluginSampleWizardPage
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PluginSampleWizardPage));
            this.LayoutTable = new System.Windows.Forms.TableLayoutPanel();
            this.GridLinks = new System.Windows.Forms.DataGridView();
            this.LinkName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LinkUri = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Introduction = new System.Windows.Forms.Label();
            this.LinksLabel = new System.Windows.Forms.Label();
            this.AddWebAccessLink = new System.Windows.Forms.CheckBox();
            this.LayoutTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridLinks)).BeginInit();
            this.SuspendLayout();
            // 
            // infoPanel
            // 
            this.infoPanel.Location = new System.Drawing.Point(0, 12);
            this.infoPanel.Size = new System.Drawing.Size(508, 304);
            // 
            // LayoutTable
            // 
            this.LayoutTable.ColumnCount = 1;
            this.LayoutTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.LayoutTable.Controls.Add(this.GridLinks, 0, 2);
            this.LayoutTable.Controls.Add(this.Introduction, 0, 0);
            this.LayoutTable.Controls.Add(this.LinksLabel, 0, 1);
            this.LayoutTable.Controls.Add(this.AddWebAccessLink, 0, 3);
            this.LayoutTable.Location = new System.Drawing.Point(0, 0);
            this.LayoutTable.Name = "LayoutTable";
            this.LayoutTable.RowCount = 4;
            this.LayoutTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.LayoutTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.LayoutTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.LayoutTable.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.LayoutTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.LayoutTable.Size = new System.Drawing.Size(505, 261);
            this.LayoutTable.TabIndex = 4;
            // 
            // GridLinks
            // 
            this.GridLinks.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.GridLinks.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.LinkName,
            this.LinkUri});
            this.GridLinks.Dock = System.Windows.Forms.DockStyle.Fill;
            this.GridLinks.Location = new System.Drawing.Point(3, 67);
            this.GridLinks.Name = "GridLinks";
            this.GridLinks.Size = new System.Drawing.Size(499, 168);
            this.GridLinks.TabIndex = 31;
            this.GridLinks.Text = "GridLinks";
            // 
            // LinkName
            // 
            this.LinkName.HeaderText = "LinkName";
            this.LinkName.Name = "LinkName";
            this.LinkName.Width = 130;
            // 
            // LinkUri
            // 
            this.LinkUri.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.LinkUri.HeaderText = "LinkUri";
            this.LinkUri.Name = "LinkUri";
            // 
            // Introduction
            // 
            this.Introduction.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.Introduction.AutoSize = true;
            this.Introduction.Location = new System.Drawing.Point(0, 0);
            this.Introduction.Margin = new System.Windows.Forms.Padding(0, 0, 0, 1);
            this.Introduction.Name = "Introduction";
            this.Introduction.Size = new System.Drawing.Size(505, 39);
            this.Introduction.TabIndex = 28;
            this.Introduction.Text = resources.GetString("Introduction.Text");
            // 
            // LinksLabel
            // 
            this.LinksLabel.Location = new System.Drawing.Point(0, 50);
            this.LinksLabel.Margin = new System.Windows.Forms.Padding(0, 10, 0, 1);
            this.LinksLabel.Name = "LinksLabel";
            this.LinksLabel.Size = new System.Drawing.Size(57, 13);
            this.LinksLabel.TabIndex = 30;
            this.LinksLabel.Text = "Add &Links:";
            // 
            // AddWebAccessLink
            // 
            this.AddWebAccessLink.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AddWebAccessLink.AutoSize = true;
            this.AddWebAccessLink.Location = new System.Drawing.Point(3, 244);
            this.AddWebAccessLink.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.AddWebAccessLink.Name = "AddWebAccessLink";
            this.AddWebAccessLink.Size = new System.Drawing.Size(408, 17);
            this.AddWebAccessLink.TabIndex = 32;
            this.AddWebAccessLink.Text = "Automatically add a link to this project\'s home page in Team System &Web Access";
            this.AddWebAccessLink.UseVisualStyleBackColor = true;
            this.AddWebAccessLink.CheckedChanged += new System.EventHandler(this.AddWebAccessLinkCheckedChanged);
            // 
            // PluginSampleWizardPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.LayoutTable);
            this.Name = "PluginSampleWizardPage";
            this.Size = new System.Drawing.Size(508, 316);
            this.Controls.SetChildIndex(this.infoPanel, 0);
            this.Controls.SetChildIndex(this.LayoutTable, 0);
            this.LayoutTable.ResumeLayout(false);
            this.LayoutTable.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GridLinks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

        private System.Windows.Forms.TableLayoutPanel LayoutTable;
        private System.Windows.Forms.DataGridView GridLinks;
        private System.Windows.Forms.DataGridViewTextBoxColumn LinkName;
        private System.Windows.Forms.DataGridViewTextBoxColumn LinkUri;
        private System.Windows.Forms.Label Introduction;
        private System.Windows.Forms.Label LinksLabel;
        private System.Windows.Forms.CheckBox AddWebAccessLink;

        public System.Windows.Forms.DataGridView Grid
        {
            get
            {
                return GridLinks;
            }
        }

    }
}