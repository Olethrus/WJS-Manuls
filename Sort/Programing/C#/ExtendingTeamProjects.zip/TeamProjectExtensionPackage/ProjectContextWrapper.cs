﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;

    using Microsoft.TeamFoundation.Client;

    /// <summary>
    /// Wraps a ProjectCreationContext object to provide convenience accessors for
    /// private data we're storing there.
    /// </summary>
    internal class ProjectContextWrapper
    {
        #region Fields

        private readonly ProjectCreationContext _context;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectContextWrapper"/> class.
        /// Requires a ProjectCreationContext object.
        /// </summary>
        /// <param name="context">The context.</param>
        public ProjectContextWrapper(ProjectCreationContext context)
        {
            Debug.Assert(context != null);
            _context = context;
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets or sets a value indicating whether the user indicated that they want
        /// a link to the Team Project's web access page included in the set of links to
        /// show in Team Explorer.
        /// </summary>
        /// <value><c>true</c> if [web access links]; otherwise, <c>false</c>.</value>
        public bool AddWebAccessLink
        {
            get
            {
                // if the property doesn't exist, create it and default it to true
                if (!_context.PrivateData.HasProperty(DataKeys.WebAccessLink))
                {
                    _context.PrivateData[DataKeys.WebAccessLink] = true;
                }

                return (bool)_context.PrivateData[DataKeys.WebAccessLink];
            }

            set
            {
                _context.PrivateData[DataKeys.WebAccessLink] = value;
            }
        }

        /// <summary>
        /// Gets the user-specified links that were collected by the Project
        /// Creation Wizard page.
        /// </summary>
        /// <value>The links.</value>
        public List<KeyValuePair<string, Uri>> Links
        {
            get
            {
                // if the property doesn't exist, create it and set it to an empty list
                if (!_context.PrivateData.HasProperty(DataKeys.WebLinks))
                {
                    _context.PrivateData[DataKeys.WebLinks] = new List<KeyValuePair<String, Uri>>();
                }

                return (List<KeyValuePair<string, Uri>>)_context.PrivateData[DataKeys.WebLinks];
            }
        }

        #endregion Properties

        #region Nested Types

        /// <summary>
        /// Container struct for the keys used to store data in the project
        /// context's public data dictionary.
        /// </summary>
        private struct DataKeys
        {
            #region Fields

            public const String WebAccessLink = "WebAccessLink";
            public const String WebLinks = "WebLinks";

            #endregion Fields
        }

        #endregion Nested Types
    }
}