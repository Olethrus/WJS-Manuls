﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
    using System.Runtime.InteropServices;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.WizardFramework;

    /// <summary>
    /// Handles the Project Creation Wizard (PCW) Tasks for this sample including
    /// a wizard page that gets added to PCW.
    /// </summary>
    [Guid(GuidList.GuidProjectCreationWizardPluginString)]
    public class ProjectCreationWizardPlugin : IProjectCreationPlugin
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="ProjectCreationWizardPlugin"/> class
        /// and initializes it with an instance of our uploader.
        /// </summary>
        public ProjectCreationWizardPlugin()
        {
            SampleUploader = new LinksProjectComponentCreator();
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Obtain an instance of IProjectComponentCreator for this plugin.
        /// </summary>
        /// <value>The component creator.</value>
        /// <seealso cref="IProjectComponentCreator"/>
        public IProjectComponentCreator ComponentCreator
        {
            get
            {
                return SampleUploader;
            }
        }

        /// <summary>
        /// Holds a reference to an instance of our uploader object
        /// </summary>
        /// <value>The sample uploader.</value>
        public LinksProjectComponentCreator SampleUploader
        {
            get; private set;
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Gets the wizard page for this extension which will appear in the 
        /// Project Creation Wizard.
        /// </summary>
        /// <param name="wizard">The wizard.</param>
        /// <param name="context">The project creation context.</param>
        /// <returns></returns>
        public TeamProjectWizardPage GetWizardPage(WizardForm wizard, ProjectCreationContext context)
        {
            return SampleUploader.WizardPage ??
                   (SampleUploader.WizardPage = new PluginSampleWizardPage(wizard, context));
        }

        #endregion Methods
    }
}