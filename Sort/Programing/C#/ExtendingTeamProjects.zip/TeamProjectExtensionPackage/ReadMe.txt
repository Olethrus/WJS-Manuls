﻿Extending Team Projects

This sample implements a Project Creation Wizard (PCW) extension and a Team Explore extension. 
It includes a stripped down process template that references the PCW extension and provides 
default data for it. To use this sample, please follow these steps:

1.  Make sure you have the following components installed:
	
	Visual Studio 2010 RC

	Visual Studio 2010 SDK RC
    http://www.microsoft.com/downloads/details.aspx?displaylang=en&FamilyID=4659f71d-4e58-4dcd-b755-127539e21147
	
	MSBuild Community Tasks (optional for packaging sources into a ZIP file)
	http://msbuildtasks.tigris.org/

2.  Open the ExtendingTeamProjects solution in Visual Studio 2010.

3.  Configure the project to use an experimental instance of Visual Studio by opening the project 
properties for the TeamProjectExtensionPackage project and selecting the Debug tab. Under "Start Action"
select Start External Program and specify the full path to Visual Studio 2010 
(%ProgramFiles(x86)%\Microsoft Visual Studio 10.0\Common7\IDE\DevEnv.exe) 
and under “Start Options” specify the following command line arguments: /rootsuffix Exp.

4.  Build the solution.

5.  Start Debugging (F5) the solution – this will start a new instance of Visual Studio.

6.  Open the Process Template Manager from the Visual Studio menu by selecting 
    Team > Team Project Collection Settings > Process Template Manager...

7.  Upload the sample process template provided with the solution.

8.  Launch the New Team Project Wizard and choose the "Project Creation Wizard Plugin Sample Process Template".

9.  You will see a new page in the wizard the lets you enter a set of links.

10. Once you’ve created the Team Project, you will see a new node in Team Explorer 
that includes the links you entered as well as a set of links defined in the sample 
process template.
