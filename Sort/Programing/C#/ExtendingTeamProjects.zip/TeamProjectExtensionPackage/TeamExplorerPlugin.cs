﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
    using System;
    using System.ComponentModel.Design;
    using System.Linq;
    using System.Runtime.InteropServices;
    using System.Windows.Forms;
    using System.Xml;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.TeamFoundation.Common;
    using Microsoft.TeamFoundation.Server;
    using Microsoft.VisualStudio.Shell.Interop;

    /// <summary>
    /// The Team Explorer plug-in provides the UI hierarchy to be shown in 
    /// Team Explorer and handles the corresponding events.
    /// </summary>
    [Guid(GuidList.GuidTeamExplorerPluginString)]
    public class TeamExplorerPlugin : BasicAsyncPlugin, ITeamExplorerPluginFilter
    {
        #region Fields

        /// <summary>
        /// This is the name of the project property that the link XML data is 
        /// stored in.
        /// </summary>
        public const string LinkProjectPropertyName = "Links";

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TeamExplorerPlugin"/> class.
        /// </summary>
        public TeamExplorerPlugin()
            : base(TeamProjectExtensionPackage.Instance)
        {
            // Add command handler for cmdidHelloPlugin command
            var menuSvc = TeamProjectExtensionPackage.Instance.GetService<IMenuCommandService>();
            var menuCommandId = new CommandID(GuidList.GuidTeamExplorerExtensionCommandSet, (int)PkgCmdIdList.CmdidHelloPlugin);
            var menuItem = new MenuCommand(OnHelloPlugin, menuCommandId);
            menuSvc.AddCommand(menuItem);
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets a suitable display priority that determines where our plug-in
        /// appears in the list of Team Explorer root nodes.
        /// </summary>
        /// <value>The display priority.</value>
        public override int DisplayPriority
        {
            get { return 250; }
        }

        /// <summary>
        /// Gets the name from the assembly resources.
        /// </summary>
        /// <value>The name.</value>
        public override String Name
        {
            get { return Resources.TeamExplorerPlugin_Name; }
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// Only present our Team Explorer Extension for Team Projects that
        /// have a project property populated with Links.
        /// </summary>
        /// <param name="projectContext">The project context.</param>
        /// <returns></returns>
        public bool SupportsProject(IProjectContext projectContext)
        {
            return LoadConfig(projectContext).HasChildNodes;
        }

        /// <summary>
        /// Creates the new tree.
        /// NOTE: This method is called from a background thread - please implement accordingly
        /// </summary>
        /// <param name="hierarchy">The hierarchy.</param>
        /// <returns></returns>
        protected override BaseHierarchyNode CreateNewTree(BaseUIHierarchy hierarchy)
        {
            var root = new TeamExplorerPluginRoot(hierarchy.ServerName + '/' + hierarchy.ProjectName);

            // Load the project specific links and folders.
            var doc = LoadConfig(hierarchy.ProjectContext);

            if (doc != null)
            {
                PopulateTree(root, doc.DocumentElement);
            }

            return root;
        }

        /// <summary>
        /// Constructs and returns a UI hierarchy based on the link content provided
        /// by our project creation wizard plug-in.
        /// </summary>
        /// <param name="parentHierarchy">The parent hierarchy.</param>
        /// <param name="itemId">The item id.</param>
        /// <returns></returns>
        protected override BaseUIHierarchy GetNewUIHierarchy(IVsUIHierarchy parentHierarchy, uint itemId)
        {
            using (var uiHierarchy = new TeamExplorerPluginUiHierarchy(parentHierarchy, itemId, this))
            {
                var root = new TeamExplorerPluginRoot(null);
                uiHierarchy.AddTreeToHierarchy(root, true);
                return uiHierarchy;
            }
        }

        /// <summary>
        /// Loads the hierarchical set of links that the project creation wizard plug-in
        /// stored in the team project property on the server.
        /// </summary>
        /// <param name="projectContext">The project context.</param>
        /// <returns></returns>
        private static XmlDocument LoadConfig(IProjectContext projectContext)
        {
            var doc = new XmlDocument();
            var collectionUri = new Uri(projectContext.DomainUri);

            var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri);
            var commonStructureService = projectCollection.GetService<ICommonStructureService>();

            string name, state;
            int templateId;
            ProjectProperty[] projectProperties;

            commonStructureService.GetProjectProperties(projectContext.ProjectUri,
                out name, out state, out templateId, out projectProperties);

            var property =
                projectProperties.Where(p => String.Compare(p.Name, LinkProjectPropertyName, true) == 0);

            if ((property != null)  && (property.Count() > 0))
            {
                doc.LoadXml(property.First().Value);
            }

            return doc;
        }

        /// <summary>
        /// Called when the user invokes the command on the context menu
        /// for the root node of our UI hierarchy.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private static void OnHelloPlugin(object sender, EventArgs e)
        {
            MessageBox.Show(Resources.TeamExplorerPlugin_OnHelloPlugin);
        }

        /// <summary>
        /// Populates the tree from the XML data retrieved from the team project property.
        /// </summary>
        /// <param name="teNode">The Team Explorer node.</param>
        /// <param name="node">The node.</param>
        private static void PopulateTree(BaseHierarchyNode teNode, XmlNode node)
        {
            foreach (XmlNode childNode in node.ChildNodes)
            {
                var nodeName = childNode.Attributes["name"].Value;

                if (childNode.Name == "folder")
                {
                    var folder = new TeamExplorerPluginFolder(teNode.CanonicalName + "/" + nodeName, nodeName);
                    teNode.AddChild(folder);

                    // recurse as appropriate to populate folder contents
                    PopulateTree(folder, childNode);
                }
                else if (childNode.Name == "link")
                {
                    var leaf = new TeamExplorerPluginLeaf(teNode.CanonicalName + "/" + nodeName,
                        nodeName, childNode.Attributes["url"].Value);
                    teNode.AddChild(leaf);
                }
                else
                {
                    throw new InvalidOperationException("Invalid XmlNode : " + childNode.Name);
                }
            }
        }

        #endregion Methods
    }

    /// <summary>
    /// Implements a folder in the hierarchy we present in Team Explorer
    /// </summary>
    public class TeamExplorerPluginFolder : BaseHierarchyNode
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TeamExplorerPluginFolder"/> class
        /// for the specified path and name.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <param name="name">The name.</param>
        public TeamExplorerPluginFolder(string path, string name)
            : base(path, name)
        {
            InitAsFolder();
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets the name of the properties class.
        /// </summary>
        /// <value>The name of the properties class.</value>
        public override String PropertiesClassName
        {
            get { return Resources.TeamExplorerPluginFolder_PropertiesClassName; }
        }

        #endregion Properties
    }

    /// <summary>
    /// Implements a leaf node (web link) in the hierarchy we present in
    /// Team Explorer
    /// </summary>
    public class TeamExplorerPluginLeaf : BaseHierarchyNode
    {
        #region Fields

        private readonly string _uri;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TeamExplorerPluginLeaf"/> class
        /// with a path, display name and URL
        /// </summary>
        /// <param name="path">The path.</param>
        /// <param name="name">The name.</param>
        /// <param name="uri">The URI.</param>
        public TeamExplorerPluginLeaf(string path, string name, string uri)
            : base(path, name)
        {
            _uri = uri;
            InitAsLeaf();
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// This is the descriptive string that appears in the properties grid 
        /// when this node is selected in Team Explorer
        /// </summary>
        /// <value>The name of the properties class.</value>
        public override string PropertiesClassName
        {
            get { return Resources.TeamExplorerPluginLeaf_PropertiesClassName_SearchEngine; }
        }

        #endregion Properties

        #region Methods

        /// <summary>
        /// The default action when you 'activate' a leaf node is, in this case,
        /// to open a browser window inside Visual Studio.
        /// </summary>
        public override void DoDefaultAction()
        {
            LaunchVsBrowserWindow(_uri);
        }

        #endregion Methods
    }

    /// <summary>
    /// The root node for our data in Team Explorer
    /// </summary>
    public class TeamExplorerPluginRoot : RootNode
    {
        #region Fields

        private CommandID _commandId;
        private ImageList _imageList;

        #endregion Fields

        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TeamExplorerPluginRoot"/> class
        /// for the specified path.
        /// </summary>
        /// <param name="path">The path.</param>
        public TeamExplorerPluginRoot(string path)
            : base(path)
        {
        }

        #endregion Constructors

        #region Properties

        /// <summary>
        /// Gets the context menu which is accessed by right clicking (or using the
        /// context menu keyboard shortcut) on our root node in Team Explorer.
        /// </summary>
        /// <value>The context menu.</value>
        public override CommandID ContextMenu
        {
            get
            {
                // instantiate the commandId on demand
                return _commandId ?? (_commandId = new CommandID(GuidList.GuidTeamExplorerExtensionCommandSet,
                                                                 (int) PkgCmdIdList.RootContextMenu));
            }
        }

        /// <summary>
        /// Gets the icons used for our nodes in Team Explorer
        /// </summary>
        /// <value>The icons.</value>
        public override ImageList Icons
        {
            get
            {
                // instantiate the imageList on demand
                return _imageList ?? (_imageList = new ImageList());
            }
        }

        /// <summary>
        /// This is the descriptive string that appears in the properties grid 
        /// when this node is selected in Team Explorer
        /// </summary>
        /// <value>The name of the properties class.</value>
        public override string PropertiesClassName
        {
            get { return Resources.TeamExplorerPluginRoot_PropertiesClassName; }
        }

        #endregion Properties
    }

    /// <summary>
    /// Implements a UI hierarchy for our data that can represent it in Team Explorer
    /// </summary>
    public class TeamExplorerPluginUiHierarchy : BaseUIHierarchy
    {
        #region Constructors

        /// <summary>
        /// Initializes a new instance of the <see cref="TeamExplorerPluginUiHierarchy"/> class.
        /// </summary>
        /// <param name="parentHierarchy">The parent hierarchy.</param>
        /// <param name="itemId">The item id.</param>
        /// <param name="plugin">The plugin.</param>
        public TeamExplorerPluginUiHierarchy(IVsUIHierarchy parentHierarchy, uint itemId, BasicAsyncPlugin plugin)
            : base(parentHierarchy, itemId, plugin, TeamProjectExtensionPackage.Instance)
        {
        }

        #endregion Constructors
    }
}