﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace ExtendingTeamProjects.TeamProjectExtensionPackage
{
    using System;
    using System.ComponentModel.Design;
    using System.Diagnostics;
    using System.Runtime.InteropServices;

    using Microsoft.VisualStudio.Shell;
    using Microsoft.VisualStudio.TeamFoundation;

    [PackageRegistration(UseManagedResourcesOnly = true)]
    [ProvideLoadKey("Standard", "1.0", "PluginHost", "Microsoft", 1)]
    [ProvideMenuResource(1000, 1)]
    [ProvideService(typeof(TeamExplorerPlugin))]
    [PluginRegistration(Catalogs.TeamProject, "Sample Team Explorer Plugin", typeof(TeamExplorerPlugin))]
    [ProvideService(typeof(ProjectCreationWizardPlugin))]
    [PluginRegistration(Catalogs.ProjectCreation, "Sample Project Creation Wizard Plugin", typeof(ProjectCreationWizardPlugin))]
    [InstalledProductRegistration("#110", "#112", "1.0", IconResourceID = 400)]
    [Guid(GuidList.GuidTeamProjectExtensionPackageString)]
    public sealed class TeamProjectExtensionPackage : Package, IHostPlugin
    {
        #region Fields

        private ProjectCreationWizardPlugin _projectCreationWizardPlugin;
        private TeamExplorerPlugin _teamExplorerPlugin;

        #endregion Fields

        #region Constructors

        public TeamProjectExtensionPackage()
        {
            Instance = this;
        }

        #endregion Constructors

        #region Properties

        public static TeamProjectExtensionPackage Instance
        {
            get; private set;
        }

        #endregion Properties

        #region Methods

        public TV GetService<T, TV>()
        {
            object obj = GetService(typeof(T));
            return (TV)obj;
        }

        public T GetService<T>()
        {
            object obj = GetService(typeof(T));
            return (T)obj;
        }

        protected override void Initialize()
        {
            base.Initialize();

            // Create plugin services on-demand via ServiceCreatorCallback handler
            var callback = new ServiceCreatorCallback(OnCreateService);
            var svcContainer = GetService<IServiceContainer>();
            svcContainer.AddService(typeof(TeamExplorerPlugin), callback, true);
            svcContainer.AddService(typeof(ProjectCreationWizardPlugin), callback, true);
        }

        private object OnCreateService(IServiceContainer container, Type serviceType)
        {
            // Check if the IServiceContainer is this package.
            if (container != this)
            {
                Trace.WriteLine("TeamProjectExtensionPackage.OnCreateService called from an unexpected service container.");
                return null;
            }

            // Find the type of the requested service and create it if necessary
            if (typeof(TeamExplorerPlugin) == serviceType)
            {
                return _teamExplorerPlugin ?? (_teamExplorerPlugin = new TeamExplorerPlugin());
            }

            if (typeof(ProjectCreationWizardPlugin) == serviceType)
            {
                return _projectCreationWizardPlugin ?? (_projectCreationWizardPlugin = new ProjectCreationWizardPlugin());
            }

            // If we are here the service type is unknown, so write a message on the debug output
            // and return null.
            Trace.WriteLine("TeamProjectExtensionPackage.OnCreateService called for an unknown service type.");
            return null;
        }

        #endregion Methods
    }
}