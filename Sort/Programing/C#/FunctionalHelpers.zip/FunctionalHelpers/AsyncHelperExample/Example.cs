﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net;
using System.IO;
using System.Threading;
using System.ComponentModel;
using FunctionalHelpers;

namespace AsyncHelperExample
{
  public class Example
  {
    public string GetUri(Uri uri)
    {
      using (var client = new WebClient())
      {
        using (var reader = new StreamReader(client.OpenRead(uri)))
        {
          return reader.ReadToEnd();
        }
      }
    }

    public void GetUriAsync(Uri uri)
    {
      AsyncHelper.InvokeAsync<string>(() => GetUri(uri), this, GetUriCompleted, uri);
    }

    public event AsyncCompletedEventHandler<string> GetUriCompleted;
  }

  public class GetUriCompletedEventArgs : AsyncCompletedEventArgs
  {
    public GetUriCompletedEventArgs(string value)
      : base(null, false, null)
    {

    }

    public GetUriCompletedEventArgs(Exception error)
      : base(error, false, null)
    {

    }
  }

  public delegate void GetUriCompletedEventHandler(object sender, GetUriCompletedEventArgs e);
}
