﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using FunctionalHelpers;

namespace AsyncHelperExample
{
    class Program
    {
        static void Main(string[] args)
        {
            var example = new Example();

            example.GetUriCompleted += GetUriCompletedHandler;

            var uri = new Uri("http://blogs.windowsclient.net/rendle/rss.aspx");

            example.GetUriAsync(uri);

            uri = new Uri("http://blogs.windowsclient.net/rendle/notavalidaddress");

            example.GetUriAsync(uri);

            while (waiting > 0)
            {
                Console.WriteLine(DateTime.Now.ToLongTimeString());
                Thread.Sleep(10);
            }

            Console.WriteLine("All calls returned");
        }

        static int waiting = 2;

        static void GetUriCompletedHandler(object sender, AsyncCompletedEventArgs<string> e)
        {
            waiting--;
            if (e.Error != null)
            {
                Console.WriteLine("Error: {0}", e.Error.Message);
            }
            else
            {
                Console.WriteLine("Found: {0}", e.ReturnValue.Substring(0,20));
            }
        }
    }
}
