﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Net;
using System.Threading;
using FunctionalHelpers;

namespace AutoMethodCachingExample
{
    public class Example
    {
        public Example()
        {
            getFromWeb = _GetFromWeb;
        }

        private string _GetFromWeb(Uri uri)
        {
            Thread.Sleep(1000);
            var webClient = new WebClient();
            var reader = new StreamReader(webClient.OpenRead(uri));
            return reader.ReadToEnd();
        }

        Func<Uri, string> getFromWeb;

        public string GetFromWeb(Uri uri)
        {
            return getFromWeb(uri);
        }

        bool cached;

        public bool Cached
        {
            get { return cached; }
            set
            {
                if (value != cached)
                {
                    getFromWeb = (cached = value) ?
                        MethodCacher.MakeCached<Uri, string>(_GetFromWeb)
                        :
                        _GetFromWeb;
                }
            }
        }
    }
}
