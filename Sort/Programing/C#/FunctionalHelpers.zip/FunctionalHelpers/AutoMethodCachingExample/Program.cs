﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AutoMethodCachingExample
{
    class Program
    {
        static Example example = new Example();

        static void Main(string[] args)
        {
            try
            {
                TimedCall("First call, uncached");

                TimedCall("Second call, uncached");

                example.Cached = true;

                TimedCall("First call, cached");

                TimedCall("Second call, cached");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }

#if(DEBUG)
            Console.Write("Press any key to continue . . . ");
            Console.ReadKey(true);
#endif
        }

        private static void TimedCall(string text)
        {
            var start = DateTime.Now;

            var rss = example.GetFromWeb(new Uri("http://blogs.windowsclient.net/rendle/rss.aspx"));

            var end = DateTime.Now;

            Console.WriteLine("{0}: {1}", text, end - start);
            Console.WriteLine(rss.Substring(0, 80));
            Console.WriteLine();
        }
    }
}
