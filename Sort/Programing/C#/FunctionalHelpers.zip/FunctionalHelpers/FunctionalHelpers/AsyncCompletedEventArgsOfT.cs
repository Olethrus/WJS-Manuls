﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace FunctionalHelpers
{
  public class AsyncCompletedEventArgs<T> : AsyncCompletedEventArgs
  {
    private readonly T returnValue;

    public AsyncCompletedEventArgs(T returnValue, object userState)
      : base(null, false, userState)
    {
      this.returnValue = returnValue;
    }

    public AsyncCompletedEventArgs(Exception error, object userState)
      : base(error, false, userState) { }

    public T ReturnValue
    {
      get
      {
        this.RaiseExceptionIfNecessary(); // Inherited from AsyncCompletedEventArgs
        return returnValue;
      }
    }
  }
}
