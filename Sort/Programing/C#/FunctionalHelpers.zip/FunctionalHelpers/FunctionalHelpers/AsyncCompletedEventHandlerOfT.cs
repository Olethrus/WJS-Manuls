﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FunctionalHelpers
{
  public delegate void AsyncCompletedEventHandler<T>(object sender, AsyncCompletedEventArgs<T> e);
}
