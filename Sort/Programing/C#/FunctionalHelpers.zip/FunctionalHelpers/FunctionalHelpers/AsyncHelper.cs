﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;

namespace FunctionalHelpers
{
  /// <summary>
  /// Helper class for implementing the Event-Based Asynchronous Pattern
  /// </summary>
  public class AsyncHelper
  {
    /// <summary>
    /// Invokes a <c>Func&lt;T&gt;</c> delegate asynchronously and raises an event on completion.
    /// </summary>
    /// <typeparam name="T">Specifies the type returned by the Func delegate</typeparam>
    /// <param name="func">The delegate to invoke.</param>
    /// <param name="sender">The sender value to pass to the event handler.</param>
    /// <param name="eventHandler">The event handler to call when the operation completes.</param>
    public static void InvokeAsync<T>(Func<T> func, object sender, AsyncCompletedEventHandler<T> eventHandler, object userState)
    {
      // Wrap the passed Func in an Action delegate which raises the AsyncComplete event
      Action asyncAction = () =>
          {
            try
            {
              // Call the supplied Func
              T returnValue = func();

              // Raise the AsyncCompleted event with the returned value
              eventHandler(sender, new AsyncCompletedEventArgs<T>(returnValue, userState));
            }
            catch (Exception ex)
            {
              // Raise the AsyncCompleted event with the exception
              eventHandler(sender, new AsyncCompletedEventArgs<T>(ex, userState));
            }
          };

      // Use a callback to call EndInvoke on the Action delegate
      AsyncCallback callback = (asyncResult) => asyncAction.EndInvoke(asyncResult);

      // Start the Action delegate on another thread using BeginInvoke
      asyncAction.BeginInvoke(callback, null);
    }

    /// <summary>
    /// Invokes an <c>Action</c> delegate asynchronously and raises an event on completion.
    /// </summary>
    /// <param name="action">The delegate to invoke.</param>
    /// <param name="sender">The sender value to pass to the event handler.</param>
    /// <param name="eventHandler">The event handler to call when the operation completes.</param>
    public static void InvokeAsync(Action action, object sender, AsyncCompletedEventHandler eventHandler)
    {
      // Wrap the passed Func in an Action delegate which raises the AsyncComplete event
      Action asyncAction = () =>
      {
        try
        {
          // Call the supplied Action
          action();

          // Raise the AsyncCompleted event with the returned value
          if (eventHandler != null)
          {
            eventHandler(sender, new AsyncCompletedEventArgs(null, false, null));
          }
        }
        catch (Exception ex)
        {
          // Raise the AsyncCompleted event with the exception
          if (eventHandler != null)
          {
            eventHandler(sender, new AsyncCompletedEventArgs(ex, false, null));
          }
        }
      };

      // Use a callback to call EndInvoke on the Action delegate
      AsyncCallback callback = (asyncResult) => asyncAction.EndInvoke(asyncResult);

      // Start the Action delegate on another thread using BeginInvoke
      asyncAction.BeginInvoke(callback, null);
    }
  }
}
