﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FunctionalHelpers
{
  /// <summary>
  /// Static helper class for creating cached methods.
  /// </summary>
  public static class MethodCacher
  {
    /// <summary>
    /// Wraps a method in a delegate which adds caching.
    /// </summary>
    /// <typeparam name="T">The type of the method parameter.</typeparam>
    /// <typeparam name="TResult">The type of the result.</typeparam>
    /// <param name="func">The method to be cached.</param>
    /// <returns>The caching delegate.</returns>
    public static Func<T, TResult> MakeCached<T, TResult>(Func<T, TResult> func)
    {
      // cache and lockObject will be bundled into the delegate as closures.
      var cache = new Dictionary<T, TResult>();
      var lockObject = new object();

      Func<T, TResult> cachedFunc = (arg) =>
          {
            if (!cache.ContainsKey(arg)) // check for cached value
            {
              lock (lockObject) // exclusive lock
              {
                if (!cache.ContainsKey(arg)) // re-check after obtaining lock
                {
                  cache.Add(arg, func(arg)); // add return value from wrapped delegate to cache
                }
              }
            }

            return cache[arg];
          };

      return cachedFunc;
    }
  }
}
