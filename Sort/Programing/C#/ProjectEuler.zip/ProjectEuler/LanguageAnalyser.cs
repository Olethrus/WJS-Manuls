﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjectEuler
{
    public class LanguageAnalyser
    {
        public double DetermineCloseness(string sample, LanguageSignature signature)
        {
            var characterFrequencies = CalculateCharacterFrequencies(sample);
            var distance = CalculateDistanceFromSignature(signature, characterFrequencies);

            return distance;
        }

        private static double CalculateDistanceFromSignature(LanguageSignature signature, IEnumerable<CharacterFrequency> characterFrequencies)
        {
            var distance = characterFrequencies
                .Where(characterFrequency => signature.GetFrequency(characterFrequency.Character) > 0)
                .Select(characterFrequency
                    => Math.Pow(characterFrequency.Frequency - signature.GetFrequency(characterFrequency.Character), 2))
                .Sum()
                .Sqrt();
            return distance;
        }

        private static IEnumerable<CharacterFrequency> CalculateCharacterFrequencies(string sample)
        {
            var characterFrequencies = sample
                .ToCharArray()
                .Select(char.ToLower)
                .GroupBy(c => c)
                .Select(group => new CharacterFrequency
                {
                    Character = group.Key,
                    Frequency = (double)group.Count() / sample.Length
                });

            return characterFrequencies;
        }

        public LanguageSignature DetermineMostLikelyLanguage(string sample, IEnumerable<LanguageSignature> signatures)
        {
            var characterFrequencies = CalculateCharacterFrequencies(sample);

            var closestLanguage = signatures.Select(signature => new
            {
                Language = signature,
                Distance = CalculateDistanceFromSignature(signature, characterFrequencies)
            })
            .MinItem(languageDistance => languageDistance.Distance);

            return closestLanguage.Language;
        }

        private class CharacterFrequency
        {
            public char Character { get; set; }

            public double Frequency { get; set; }
        }
    }
}
