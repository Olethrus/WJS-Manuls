﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MbUnit.Framework;

namespace ProjectEuler
{
    public class LanguageAnalyserTests
    {
        [Test]
        [XmlData("//Sample", FilePath = "ProblemData\\LanguageSamples.xml")]
        public void TestAnalysis([Bind("Text")]string text, [Bind("@Language")]string expectedLanguage)
        {
            var analyser = new LanguageAnalyser();
            var determinedLanguage = analyser.DetermineMostLikelyLanguage(
                text, 
                new[] { LanguageSignatures.English, LanguageSignatures.French, LanguageSignatures.German, LanguageSignatures.Dutch, LanguageSignatures.Spanish, LanguageSignatures.Italian });

            Assert.AreEqual(expectedLanguage, determinedLanguage.Language);
        }
    }
}
