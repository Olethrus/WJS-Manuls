﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;

namespace ProjectEuler
{
    [DebuggerDisplay("Language = { Language }")]
    public class LanguageSignature
    {
        private IDictionary<char, double> _frequencies;

        public LanguageSignature(string language, IDictionary<char, double> characterFrequencies)
        {
            Language = language;
            _frequencies = characterFrequencies;
        }

        public string Language { get; protected set; }

        public double GetFrequency(char character)
        {
            double frequency;
            return _frequencies.TryGetValue(character, out frequency) ? frequency : 0;
        }
    }
}
