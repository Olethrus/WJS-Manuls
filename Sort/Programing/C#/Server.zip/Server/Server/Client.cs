﻿using System.Net.Sockets;
using System;


namespace Server
{
    public class Client
    {
        private Socket          _socket;
        private TcpClient       _tcpClient;
        private string          _name;
        private int             _hitPoints = 100;
        private int             _spellPoints = 100;
        private int             _currentX;
        private int             _currentY;
        private Enums.Direction _direction = Enums.Direction.South;
        private int             _destX;
        private int             _destY;
        private int             _mapID = 0;
        private int             _playerID = -1;
        public bool             _dead = false;

        public Client(int x, int y)
        {
            _currentX = _destX = x;
            _currentY = _destY = y;
        }

        public void HeartBeatHeal()
        {
            _hitPoints += 5;
            if (_hitPoints > 100)
                _hitPoints = 100;
        }

        public int PlayerID
        {
            get { return _playerID; }
            set { _playerID = value; }
        }

        public Enums.Direction Direction
        {
            get { return _direction; }
            set { _direction = value; }
        }

        public int MapID
        {
            get { return _mapID; }
            set { _mapID = value; }
        }

        public int CurrentX
        {
            get { return _currentX; }
            set { _currentX = value; }
        }

        public int CurrentY
        {
            get { return _currentY; }
            set { _currentY = value; }
        }

        public int DestX
        {
            get { return _destX; }
            set { _destX = value; }
        }

        public int DestY
        {
            get { return _destY; }
            set { _destY = value; }
        }

        public int HitPoints
        {
            get { return _hitPoints; }
        }

        public void TakeDamage(int dmg)
        {
            _hitPoints -= dmg;
            if (_hitPoints <= 0)
            {
                _hitPoints = 0;
                _dead = true;
            }
        }

        public bool IsDead
        {
            get { return _dead; }
        }

        public int SpellPoints
        {
            get { return _spellPoints; }
            set { _spellPoints = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public Socket Socket
        {
            get { return this._socket; }
            set { _socket = value; }
        }

        public TcpClient TcpClient
        {
            get { return _tcpClient; }
            set { _tcpClient = value; }
        }
    }
}
