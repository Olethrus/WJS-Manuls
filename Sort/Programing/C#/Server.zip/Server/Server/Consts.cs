﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Server
{
    class Consts
    {
        public const int Port = 4503;
        public const string WELCOME_MESSAGE = "Welcome to Silverlight Fireball";
    }
}
