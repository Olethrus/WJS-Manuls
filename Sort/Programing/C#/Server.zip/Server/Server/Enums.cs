﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Server
{
    public class Enums
    {
        public enum Direction
        {
            North = 0,
            NE = 1,
            East = 2,
            SE = 3,
            South = 4,
            SW = 5,
            West = 6,
            NW = 7,
            None = 8,
        }
    }
}
