﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading;
using System.Collections;

namespace Server
{
    public partial class MainForm : Form
    {
        Server _server = new Server();
        Thread _serverThread;
        public EventHandler _clientUpdateEvent;
        private delegate void InvokeUpdateClientDelegate();
        
        public MainForm()
        {
            InitializeComponent();
            StatusInfo.MsgBox = this.richTextBoxMain;
            _clientUpdateEvent += new EventHandler(OnClientUpdate);

            //string frameNumber = "2.png";
            //string file = "walkinge0000.png";
            //int index = file.IndexOf(".");
            //file = file.Remove(index-1,5);
            //file = file.Insert(index-1, frameNumber);
        }

        private void StartServer()
        {
            _server = new Server();
            _server.SetClientUpdateEvent(_clientUpdateEvent);
            
            _serverThread = new Thread(new ThreadStart(_server.StartServer));
            _serverThread.Name = "Main Server Thread";
            _serverThread.Start();

            toolStripButtonStartServer.Enabled = false;
            startToolStripMenuItem.Enabled = false;
            
            toolStripButtonStopServer.Enabled = true;
            stopToolStripMenuItem.Enabled = true;
        }

        private void StopServer()
        {
            _server.StopServer();
            
            toolStripButtonStartServer.Enabled = true;
            startToolStripMenuItem.Enabled = true;

            toolStripButtonStopServer.Enabled = false;
            stopToolStripMenuItem.Enabled = false;
        }

        private void buttonStartServer_Click(object sender, EventArgs e)
        {
            StartServer();   
        }

        private void buttonStopServer_Click(object sender, EventArgs e)
        {
            StopServer();
        }

        private void UpdateClientList()
        {
            listViewClients.BeginInvoke(new InvokeUpdateClientDelegate(InvokeUpdateClientList));
        }

        private void InvokeUpdateClientList()
        {
            List<Client> clients = _server.Clients;

            lock (clients)
            {
                listViewClients.Items.Clear();

                foreach (Client client in clients)
                {
                    ListViewItem lvi = new ListViewItem(client.Name);
                    listViewClients.Items.Add(lvi);
                }
            }
        }

        public void OnClientUpdate(object sender, EventArgs e)
        {
            UpdateClientList();
        }

    
        private void buttonSend_Click(object sender, EventArgs e)
        {
            string text = textBoxMessage.Text;
            _server.SendMessage(text);
            textBoxMessage.Text = String.Empty;
            
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            UpdateClientList();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            StopServer();
        }

        private void startToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StartServer();
        }

        private void stopToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StopServer();
        }
       
        private void toolStripButtonStartServer_Click(object sender, EventArgs e)
        {
            StartServer();
        }

        private void toolStripButtonStopServer_Click(object sender, EventArgs e)
        {
            StopServer();
        }
    }
}
