﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Server
{
    public class Packet
    {
        private Client _clientObject;
        private string _packetData;

        public Packet(Client client, string packetData)
        {
            _clientObject = client;
            _packetData = packetData;
        }

        public Client ClientObject
        {
            get { return _clientObject; }
        }

        public string PacketData
        {
            get { return _packetData; }
        }
    }
}
    