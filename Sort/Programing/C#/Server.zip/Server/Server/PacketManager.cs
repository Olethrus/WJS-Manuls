﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Net.Sockets;

namespace Server
{
    public class PacketManager
    {
        private List<byte[]>    _data               = new List<byte[]>();
        private List<int>       _dataLength         = new List<int>();
        private List<string>    _processedPackets   = new List<string>();
        private bool            _packetStart        = true;
        private int             _expectedLength     = 0;
        private int             _currentLength      = 0;
        private byte[]          _packetData;

        public const string ADD_PLAYER          = "AP";
        public const string CHANGE_DIRECTION    = "CD";
        public const string CHAT_MESSAGE        = "CM";
        public const string DEATH               = "DT";
        public const string ENTER_GAME          = "EG";
        public const string FIREBALL            = "FB";
        public const string HEAL                = "HE";
        public const string REPORT_HIT          = "HT";
        public const string INVALID_LOGON       = "IL";
        public const string LOGIN               = "L";
        public const string MOVE_TO_MAP         = "MM";
        public const string MOVE_TO             = "MT";
        public const string REMOVE_PLAYER       = "RP";
        public const string SYSTEM_MESSAGE      = "SM";

        public static byte[] Heal(int playerID, int totalHP)
        {
            return Encoding.ASCII.GetBytes(HEAL + "," + totalHP);
        }

        public static byte[] AddPlayer(int x, int y, bool isDead, Enums.Direction direction, int playerID, string playerName)
        {
            int dead = 0;
            if (true == isDead)
                dead = 1;

            int directionValue = Convert.ToInt32(direction);

            return Encoding.ASCII.GetBytes(ADD_PLAYER + "," + x + "," + y + "," + dead + "," + directionValue + "," + playerID + "," + playerName);
        }

        public static byte[] RemovePlayer(int playerID)
        {
            return Encoding.ASCII.GetBytes(REMOVE_PLAYER + "," + playerID);
        }

        public static byte[] ReportDeath(int playerID)
        {
            return Encoding.ASCII.GetBytes(DEATH + "," + playerID);
        }

        public static byte[] ReportHit(int playerID)
        {
            return Encoding.ASCII.GetBytes(REPORT_HIT + "," + playerID);
        }

        public static byte[] Fireball(int playerID, int stepX, int stepY, int totalSteps, Enums.Direction direction)
        {
            int directionValue = Convert.ToInt32(direction);
            return Encoding.ASCII.GetBytes(FIREBALL + "," + playerID + "," + stepX + "," + stepY + "," + totalSteps+","+directionValue);
        }

        public static byte[] EnterGame(int playerID)
        {
            return Encoding.ASCII.GetBytes(ENTER_GAME+ "," + playerID);
        }

        public static byte[] MoveToMap(int x, int y, string mapFileName)
        {
            return Encoding.ASCII.GetBytes(MOVE_TO_MAP + "," + x + "," + y + "," + mapFileName);
        }

        public static byte[] ChatMessage(int playerID, string message)
        {
            return Encoding.ASCII.GetBytes(CHAT_MESSAGE + "," + playerID + "," + message);
        }

        public static byte[] MoveTo(int x, int y, int playerID)
        {
            return Encoding.ASCII.GetBytes(MOVE_TO + "," + x + "," + y + "," + playerID);
        }

        public static byte[] ChangeDirection(Enums.Direction direction, int playerID)
        {
            int directionValue = Convert.ToInt32(direction);
            return Encoding.ASCII.GetBytes(CHANGE_DIRECTION + "," + playerID + "," + directionValue);
        }

        public static byte[] SystemMessage(string msg)
        {
            return Encoding.ASCII.GetBytes(SYSTEM_MESSAGE + "," + msg);
        }

        public static byte[] InvalidLogin(string msg)
        {
            return Encoding.ASCII.GetBytes(INVALID_LOGON + "," + msg);
        }

        public string DequeuePacket()
        {
            string packet = String.Empty;
            lock (this)
            {
                if (_processedPackets.Count > 0)
                {
                    packet = _processedPackets[0];
                    _processedPackets.RemoveAt(0);
                }
            }
            return packet;
        }


        public bool IsPacketAvailable()
        {
            return (_processedPackets.Count > 0);
        }

        private void ProcessPacketStart(byte[] data, int dataIndex, int dataLength)
        {
            byte[] packetLength = new Byte[4];
            packetLength[0] = data[dataIndex];
            packetLength[1] = data[dataIndex + 1];
            packetLength[2] = data[dataIndex + 2];
            packetLength[3] = data[dataIndex + 3];
            _expectedLength = BitConverter.ToInt32(packetLength, 0);

            _packetData = new byte[_expectedLength];

            int bytesCopied = 0;
            while (bytesCopied < _expectedLength && bytesCopied < (dataLength - 4))
            {
                _packetData[bytesCopied] = data[dataIndex + bytesCopied + 4];
                bytesCopied++;
            }
            _currentLength = bytesCopied;

            if (_currentLength == _expectedLength) // did we get enough to create a full packet?
            {
                _processedPackets.Add(Encoding.UTF8.GetString(_packetData, 0, _expectedLength));
                if (bytesCopied + 4 < dataLength) // Is there more data to process?
                    ProcessPacketStart(data, bytesCopied + 4 + dataIndex, dataLength - (bytesCopied + 4));
                else
                {
                    Reset();
                }
            }
        }

        private void Reset()
        {
            _packetStart = true;
            _currentLength = 0;
        }

        private void AddToPacket(byte[] data, int dataIndex, int dataLength)
        {
            int bytesCopied = 0;
            while (_currentLength < _expectedLength && bytesCopied < dataLength)
            {
                _packetData[_currentLength] = data[dataIndex + bytesCopied];
                bytesCopied++;
                _currentLength++;
            }
            if (_currentLength == _expectedLength) // did we get enough to create a full packet?
            {
                _processedPackets.Add(Encoding.UTF8.GetString(_packetData, 0, _expectedLength));
            }

            if (bytesCopied < dataLength) // Is there more data to process?
                ProcessPacketStart(data, bytesCopied, (dataLength - bytesCopied));
            else
                Reset();
        }

        public void AddPacketData(byte[] data, int dataLength)
        {
            lock (this)
            {
                if (true == _packetStart)
                {
                    ProcessPacketStart(data, 0, dataLength);
                }
                else
                {
                    AddToPacket(data, 0, dataLength);
                }
            }
        }

        public static void SendPacket(NetworkStream ns, byte[] data)
        {
            int packetLength = data.Length + 4;
            byte[] dataLength = BitConverter.GetBytes(Convert.ToInt32(data.Length));
            byte[] packet = new byte[packetLength];
            for (int i = 0; i < 4; i++)
                packet[i] = dataLength[i];
            for (int i = 4; i < packetLength; i++)
                packet[i] = data[i - 4];

            string t = Encoding.ASCII.GetString(data);
            StatusInfo.OutputText("TEST=" + t);

            ns.Write(packet, 0, packet.Length);
            ns.Flush();
        }
    }
}
