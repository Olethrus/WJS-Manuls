﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Collections;
using System.Collections.Generic;

namespace Server
{
    public class Server
    {
        private TcpListener     _tcpListener;
        private int             _connections = 0;
        private bool            _keepAlive = true;
        private List<Client>    _clients = new List<Client>();
        private Queue           _packetQueue = new Queue();
        private EventHandler    _clientUpdateEvent;
        private Thread          _pollForConnectionsThread = null;
        private Thread          _processPacketsThread = null;
        private int             _nextID = 1;
        private int             _startX = 1000;
        private int             _startY = 1000;

        public List<Client> Clients
        {
            get { return _clients; }
        }

        public void StartServer()
        {
            _keepAlive = true;

            try
            {
                _tcpListener = new TcpListener(IPAddress.Any, Consts.Port);
                _tcpListener.Start();

                _pollForConnectionsThread = new Thread(new ThreadStart(PollForConnections));
                _pollForConnectionsThread.Name = "PollForConnectionsThread";
                _pollForConnectionsThread.Start();

                _processPacketsThread = new Thread(new ThreadStart(ProcessPackets));
                _processPacketsThread.Name = "ProcessPacketsThread";
                _processPacketsThread.Start();
            }
            catch (SocketException e)
            {
                StatusInfo.OutputText("Exception thrown " + e.Message);
            }
        }

        public void StopServer()
        {
            _keepAlive = false;

            lock (_clients)
            {
                foreach (Client client in _clients)
                {
                    client.TcpClient.Close();
                }
            }
            if (null != _tcpListener)
            {
                _tcpListener.Stop();
                _tcpListener = null;

            }
           
            StatusInfo.OutputText("Server stopped.");
        }

        public void SendMessage(string text)
        {
            byte[]  data = PacketManager.SystemMessage(text);

            lock (_clients)
            {
                foreach (Client client in _clients)
                {
                    NetworkStream ns = client.TcpClient.GetStream();
                    PacketManager.SendPacket(ns, data);
                }
            }
        }

        public void SetClientUpdateEvent(EventHandler clientUpdateEvent) 
        {
            _clientUpdateEvent = clientUpdateEvent; 
        }
  
        private void PollForConnections()
        {
            StatusInfo.OutputText("Waiting for clients...");
            int elapsedTime = 0;
            DateTime lastHeal = DateTime.Now;


            while (true == _keepAlive)
            {
                while (true == _keepAlive && null != _tcpListener && false == _tcpListener.Pending())
                {
                    System.Threading.Thread.Sleep(100);
                }
                TimeSpan elapsed = DateTime.Now - lastHeal;
                if (elapsedTime > 5000)
                {
                    lastHeal = DateTime.Now;
                    lock (_clients)
                    {
                        foreach (Client client in _clients)
                        {
                            client.HeartBeatHeal();
                            PacketManager.SendPacket(client.TcpClient.GetStream(), PacketManager.Heal(client.PlayerID, client.HitPoints));
                        }
                    }
                }
                if (true == _keepAlive && null != _tcpListener)
                {
                    Thread clientThread = new Thread(new ParameterizedThreadStart(HandleClient));
                    clientThread.Name = "ClientThread";
                    clientThread.Start(_clients);
                }
            }
        }

        private void AddPacketToQueue(Packet packet)
        {
            lock (_packetQueue)
            {
                _packetQueue.Enqueue(packet);
            }
        }

        private void ReportMoveToClients(Client movingClient)
        {
            lock (_clients)
            {
                foreach (Client client in _clients)
                {
                    if (client != movingClient)
                        PacketManager.SendPacket(client.TcpClient.GetStream(), PacketManager.MoveTo(movingClient.DestX, movingClient.DestY, movingClient.PlayerID));
                }
            }
        }

        private void ReportChatToClients(Client chatClient, string message)
        {
            lock (_clients)
            {
                foreach (Client client in _clients)
                    PacketManager.SendPacket(client.TcpClient.GetStream(), PacketManager.ChatMessage(chatClient.PlayerID, message));
            }
        }

        private void ReportDirectionChangeToClients(Client thisClient)
        {
            lock (_clients)
            {
                foreach (Client client in _clients)
                {
                    if (client != thisClient)
                        PacketManager.SendPacket(client.TcpClient.GetStream(), PacketManager.ChangeDirection(thisClient.Direction, thisClient.PlayerID));
                }
            }
        }

        private void ReportFireball(Client thisClient, int stepX, int stepY, int totalSteps, Enums.Direction direction)
        {
            lock (_clients)
            {
                foreach (Client client in _clients)
                {
                    if (client != thisClient)
                        PacketManager.SendPacket(client.TcpClient.GetStream(), PacketManager.Fireball(thisClient.PlayerID, stepX, stepY, totalSteps, direction));
                }
            }
        }

        private void ProcessHit(Client thisClient)
        {
            lock (_clients)
            {
                byte[] packet;

                thisClient.TakeDamage(50);

                if (thisClient.IsDead)
                {
                    packet = PacketManager.ReportDeath(thisClient.PlayerID);
                    PacketManager.SendPacket(thisClient.TcpClient.GetStream(), packet);
                }
                else
                    packet = PacketManager.ReportHit(thisClient.PlayerID);

                foreach (Client client in _clients)
                {
                    if (client != thisClient)
                        PacketManager.SendPacket(client.TcpClient.GetStream(), packet);
                }

                
            }
        }

        private void ProcessPackets()
        {
            while (true == _keepAlive)
            {
                while(_packetQueue.Count > 0)
                {
                    lock(_packetQueue)
                    {
                        Packet packet = (Packet) _packetQueue.Dequeue();
                        string[] idenifiers = packet.PacketData.Split(new Char[] { ',' });
                        switch (idenifiers[0])
                        {
                            case PacketManager.CHAT_MESSAGE:
                                ReportChatToClients(packet.ClientObject, idenifiers[1]);
                                break;
                            case PacketManager.MOVE_TO:
                                packet.ClientObject.DestX = Convert.ToInt32(idenifiers[1]);
                                packet.ClientObject.DestY = Convert.ToInt32(idenifiers[2]);
                                ReportMoveToClients(packet.ClientObject);
                                break;
                            case PacketManager.CHANGE_DIRECTION:
                                packet.ClientObject.Direction = (Enums.Direction) Convert.ToInt32(idenifiers[1]);
                                ReportDirectionChangeToClients(packet.ClientObject);
                                break;
                            case PacketManager.FIREBALL:
                                int stepX =  Convert.ToInt32(idenifiers[1]);
                                int stepY = Convert.ToInt32(idenifiers[2]);
                                int totalSteps = Convert.ToInt32(idenifiers[3]);
                                Enums.Direction direction = (Enums.Direction)Convert.ToInt32(idenifiers[4]);
                                ReportFireball(packet.ClientObject, stepX, stepY, totalSteps, direction);
                                break;
                            case PacketManager.REPORT_HIT:
                                ProcessHit(packet.ClientObject);
                                break;
                                
                        }
                    }
                }


                System.Threading.Thread.Sleep(100);
            }
        }

        private bool ProcessLogin(NetworkStream ns, Client thisClient)
        {
            PacketManager packetMgr = new PacketManager();
            byte[] dataReader = new Byte[1024];

            while (true == _keepAlive)
            {
                int bytesRead = ns.Read(dataReader, 0, dataReader.Length);
                if (bytesRead == 0)
                    return false;

                packetMgr.AddPacketData(dataReader, bytesRead);

                if (true == packetMgr.IsPacketAvailable())
                {
                    string packet = packetMgr.DequeuePacket();
                    string[] idenifiers = packet.Split(new Char[] { ',' });
                    if (idenifiers.Length == 3)
                    {
                        if (idenifiers[0] == PacketManager.LOGIN)
                        {
                            thisClient.Name = idenifiers[1];                            
                            string password = idenifiers[2];
                            return true;
//                            PacketManager.SendPacket(ns, PacketManager.InvalidLogin("Password is incorrect"));
  //                          System.Threading.Thread.Sleep(500);
                        }
                    }
                    return false;
                }
            }
            return false;
        }

        private void RemovePlayerFromMap(Client thisClient)
        {
            lock (_clients)
            {
                byte[] removePlayerPacket = PacketManager.RemovePlayer(thisClient.PlayerID);
                foreach (Client client in _clients)
                {
                    if (client != thisClient)
                    {
                        // tell each player already on to add me.
                        PacketManager.SendPacket(client.TcpClient.GetStream(), removePlayerPacket);
                    }
                }
            }
        }

        private void AddPlayerToGame(Client thisClient)
        {
            PacketManager.SendPacket(thisClient.TcpClient.GetStream(), PacketManager.EnterGame(thisClient.PlayerID));
        }

        private void AddPlayerToMap(Client thisClient)
        {
            // tell new player to enter the game.
            PacketManager.SendPacket(thisClient.TcpClient.GetStream(), PacketManager.MoveToMap(thisClient.CurrentX, thisClient.CurrentY, "TestMap.xml"));

            lock (_clients)
            {
                byte[] addPlayerPacket = PacketManager.AddPlayer(thisClient.CurrentX, thisClient.CurrentY, thisClient.IsDead, thisClient.Direction, thisClient.PlayerID, thisClient.Name);
                foreach (Client client in _clients)
                {
                    if (client != thisClient)
                    {
                        // tell each player already on to add me.
                        PacketManager.SendPacket(client.TcpClient.GetStream(), addPlayerPacket);

                        // tell me about each player that is already on.
                        byte[] reportPlayer = PacketManager.AddPlayer(client.DestX, client.DestY, client.IsDead, client.Direction, client.PlayerID, client.Name);
                        StatusInfo.OutputText("Adding player " + client.Name);
                        PacketManager.SendPacket(thisClient.TcpClient.GetStream(), reportPlayer);

                    }
                }
            }
        }

        private void HandleClient(object clientList)
        {
            int bytesRead;
            PacketManager packetMgr = new PacketManager();
            Client thisClient = new Client(_startX, _startY);
            byte[] dataReader = new Byte[1024];

            try
            {
                TcpClient tcpClient = _tcpListener.AcceptTcpClient();
                NetworkStream ns = tcpClient.GetStream();
                _connections++;

                if (true == ProcessLogin(ns, thisClient))
                {
                    thisClient.TcpClient = tcpClient;
                    thisClient.PlayerID = _nextID++;
                    if (_nextID == Int32.MaxValue)
                        _nextID = 0;

                    lock (_clients)
                    {
                        _clients.Add(thisClient);
                        StatusInfo.OutputText("New client accepted: " + _clients.Count + " active connections.");
                    }
                    _clientUpdateEvent(null, null);

                    thisClient.CurrentX = _startX;
                    thisClient.CurrentY = _startY;
                    thisClient.MapID = 0;

                    PacketManager.SendPacket(ns, PacketManager.SystemMessage(Consts.WELCOME_MESSAGE));
                    AddPlayerToGame(thisClient);
                    AddPlayerToMap(thisClient);

                    try
                    {
                        while (true == _keepAlive)
                        {
                            bytesRead = ns.Read(dataReader, 0, dataReader.Length);
                            if (bytesRead == 0)
                                break;

                            packetMgr.AddPacketData(dataReader, bytesRead);

                            while (true == packetMgr.IsPacketAvailable())
                            {
                                string packet = packetMgr.DequeuePacket();
                                AddPacketToQueue(new Packet(thisClient, packet));
                            }
                        }
                    }
                    catch (ThreadAbortException tae1)
                    {
                    }
                    catch (SocketException se)
                    {
                    }
                    catch (Exception e)
                    {
                    }

                    lock (_clients)
                    {
                        _clients.Remove(thisClient);
                        RemovePlayerFromMap(thisClient);
                        _clientUpdateEvent(null, null);
                    }
                }
                ns.Close();
                tcpClient.Close();
                _connections--;
                StatusInfo.OutputText("Client disconnected: " + _connections + " active connections.");                
            }
            catch (ThreadAbortException tae)
            {
                StatusInfo.OutputText("Thread aborted");
            }
            catch (Exception e2)
            {
                StatusInfo.OutputText("Exception thrown in HandleClient(): " + e2.Message);
            }
            
        }
    }
}