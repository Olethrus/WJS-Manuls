﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Server
{
    public class StatusInfo
    {
        public static RichTextBox _msgBox = null;
        private delegate void InvokeSetTextDelegate(string msg);

        public static RichTextBox MsgBox
        {
            set { _msgBox = value; }
        }

        public static void OutputText(string text)
        {            
            _msgBox.BeginInvoke(new InvokeSetTextDelegate(InvokeSetText), new Object[] { text });
        }

        private static void InvokeSetText(string text)
        {
            _msgBox.Text += text + "\n";
            _msgBox.ScrollToCaret();
        }
    }
}
