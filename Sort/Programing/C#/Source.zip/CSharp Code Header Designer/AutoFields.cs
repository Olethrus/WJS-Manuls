﻿

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner
{
    internal enum AutoFields
    {
        FILE,
        AUTHOR,
        MODIFICATION_DATE,
        CREATION_DATE,
        PROJECT,
        SOLUTION,
        NAMESPACE,
        INHERIT,
        IMPLEMENT,
        SUMMARY,
        CURRENT_YEAR,
        CURRENT_DATE
    }
}
