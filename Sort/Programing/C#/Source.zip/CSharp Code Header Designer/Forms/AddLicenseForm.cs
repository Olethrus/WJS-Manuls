﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms
{
    public partial class AddLicenseForm : Form
    {
        Boolean _Validate = true;

        public AddLicenseForm()
        {
            InitializeComponent();
        }

        private void btnOK_Click(object sender, EventArgs e)
        {
            
            if (this.txtCode.Text.Trim() == String.Empty)
            {
                errorProvider.SetError(this.txtCode, "Code is empty");
                _Validate = false;
            }
            else
            {
                errorProvider.SetError(this.txtCode, String.Empty);
            }

            if (this.txtText.Text.Trim() == String.Empty && this.txtLink.Text.Trim() == String.Empty)
            {
                _Validate = false;
                errorProvider.SetError(this.txtText, "Link and Text are empty");
                errorProvider.SetError(this.txtLink, "Link and Text are empty");
            }
            else
            {
                errorProvider.SetError(this.txtText, String.Empty);
                errorProvider.SetError(this.txtLink, String.Empty);
            }

            if (_Validate)
            {
                XDocument doc = XDocument.Load(Application.StartupPath + @"\Licenses.xml");
                XElement root = doc.Root;
                XElement license = new XElement("License");
                license.Add(new XElement("Code", this.txtCode.Text));
                license.Add(new XElement("Text", this.txtText.Text));
                license.Add(new XElement("Link", this.txtLink.Text));

                root.Add(license);

                doc.Save(Application.StartupPath + @"\Licenses.xml");
            }

        }

        private void AddLicenseForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (!_Validate)
            {
                e.Cancel = true;

                _Validate = true;
            }
        }
    }
}
