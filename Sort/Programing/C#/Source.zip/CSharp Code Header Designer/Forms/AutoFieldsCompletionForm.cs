﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms
{
    public partial class AutoFieldsCompletionForm : Form
    {
        public String AutoField { get; set; }

        public AutoFieldsCompletionForm()
        {
            InitializeComponent();
        }

        private void AutoFiledsCompletionForm_Load(object sender, EventArgs e)
        {
            this.lbAutoComplete.DataSource = Enum.GetNames(typeof(AutoFields));

            this.lbAutoComplete.SelectedIndex = 0;

            this.lbAutoComplete.Focus();
        }

        private void lbAutoComplete_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else if (e.KeyCode == Keys.Escape)
            {
                this.DialogResult = DialogResult.Cancel;
                this.Close();
            }
        }

        private void AutoFiledsCompletionForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            this.AutoField = this.lbAutoComplete.Text;
        }
    }
}
