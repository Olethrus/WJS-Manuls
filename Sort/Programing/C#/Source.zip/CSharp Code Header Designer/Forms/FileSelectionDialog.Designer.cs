﻿using ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties;

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms
{
    partial class FileSelectionDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FileSelectionDialog));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.exitToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.searchPatternLabel = new System.Windows.Forms.ToolStripLabel();
            this.searchPatternToolStripTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.excludeGeneratedCodeToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.searchToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.searchTextBox = new System.Windows.Forms.ToolStripTextBox();
            this.searchToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.openSelectedFileToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.directoryContensSelectionToolStripDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unselectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mainSplitContainer = new System.Windows.Forms.SplitContainer();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.treeView = new System.Windows.Forms.TreeView();
            this.directoryContentsCheckedListBox = new System.Windows.Forms.CheckedListBox();
            this.resultsCheckedListBox = new System.Windows.Forms.CheckedListBox();
            this.searchResultsTopPanel = new System.Windows.Forms.Panel();
            this.toolStrip2 = new System.Windows.Forms.ToolStrip();
            this.searchResultsToolStripLabel = new System.Windows.Forms.ToolStripLabel();
            this.hideSearchResultsToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.searchSelectionToolStripDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.searchResultsSelectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchResultsUnselectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            this.mainSplitContainer.Panel1.SuspendLayout();
            this.mainSplitContainer.Panel2.SuspendLayout();
            this.mainSplitContainer.SuspendLayout();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.searchResultsTopPanel.SuspendLayout();
            this.toolStrip2.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitToolStripButton,
            this.toolStripSeparator4,
            this.searchPatternLabel,
            this.searchPatternToolStripTextBox,
            this.excludeGeneratedCodeToolStripButton,
            this.toolStripSeparator2,
            this.searchToolStripLabel,
            this.searchTextBox,
            this.searchToolStripButton,
            this.toolStripSeparator1,
            this.openSelectedFileToolStripButton,
            this.toolStripSeparator3,
            this.directoryContensSelectionToolStripDropDownButton});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(992, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // exitToolStripButton
            // 
            this.exitToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.exitToolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.accept;
            this.exitToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.exitToolStripButton.Name = "exitToolStripButton";
            this.exitToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.exitToolStripButton.Text = "&Exit";
            this.exitToolStripButton.ToolTipText = "&Exit";
            this.exitToolStripButton.Click += new System.EventHandler(this.exitToolStripButton_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 25);
            // 
            // searchPatternLabel
            // 
            this.searchPatternLabel.Name = "searchPatternLabel";
            this.searchPatternLabel.Size = new System.Drawing.Size(30, 22);
            this.searchPatternLabel.Text = "Filter";
            // 
            // searchPatternToolStripTextBox
            // 
            this.searchPatternToolStripTextBox.Name = "searchPatternToolStripTextBox";
            this.searchPatternToolStripTextBox.Size = new System.Drawing.Size(100, 25);
            this.searchPatternToolStripTextBox.KeyUp += new System.Windows.Forms.KeyEventHandler(this.searchPatternToolStripTextBox_KeyUp);
            // 
            // excludeGeneratedCodeToolStripButton
            // 
            this.excludeGeneratedCodeToolStripButton.Checked = true;
            this.excludeGeneratedCodeToolStripButton.CheckOnClick = true;
            this.excludeGeneratedCodeToolStripButton.CheckState = System.Windows.Forms.CheckState.Checked;
            this.excludeGeneratedCodeToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.excludeGeneratedCodeToolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.arrow_in;
            this.excludeGeneratedCodeToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.excludeGeneratedCodeToolStripButton.Name = "excludeGeneratedCodeToolStripButton";
            this.excludeGeneratedCodeToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.excludeGeneratedCodeToolStripButton.Text = "&Exclude Generated Code Files";
            this.excludeGeneratedCodeToolStripButton.Click += new System.EventHandler(this.excludeGeneratedCodeToolStripButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // searchToolStripLabel
            // 
            this.searchToolStripLabel.Name = "searchToolStripLabel";
            this.searchToolStripLabel.Size = new System.Drawing.Size(42, 22);
            this.searchToolStripLabel.Text = "Search";
            // 
            // searchTextBox
            // 
            this.searchTextBox.Name = "searchTextBox";
            this.searchTextBox.Size = new System.Drawing.Size(100, 25);
            // 
            // searchToolStripButton
            // 
            this.searchToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.searchToolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.application_form_magnify;
            this.searchToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.searchToolStripButton.Name = "searchToolStripButton";
            this.searchToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.searchToolStripButton.Text = "toolStripButton1";
            this.searchToolStripButton.Click += new System.EventHandler(this.searchToolStripButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // openSelectedFileToolStripButton
            // 
            this.openSelectedFileToolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.folder_page1;
            this.openSelectedFileToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openSelectedFileToolStripButton.Name = "openSelectedFileToolStripButton";
            this.openSelectedFileToolStripButton.Size = new System.Drawing.Size(72, 22);
            this.openSelectedFileToolStripButton.Text = "&Open File";
            this.openSelectedFileToolStripButton.Click += new System.EventHandler(this.openSelectedFileToolStripButton_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // directoryContensSelectionToolStripDropDownButton
            // 
            this.directoryContensSelectionToolStripDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.selectAllToolStripMenuItem,
            this.unselectAllToolStripMenuItem});
            this.directoryContensSelectionToolStripDropDownButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.application_side_list;
            this.directoryContensSelectionToolStripDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.directoryContensSelectionToolStripDropDownButton.Name = "directoryContensSelectionToolStripDropDownButton";
            this.directoryContensSelectionToolStripDropDownButton.Size = new System.Drawing.Size(109, 22);
            this.directoryContensSelectionToolStripDropDownButton.Text = "&Selection Tools";
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.selectAllToolStripMenuItem.Text = "&Select All";
            this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
            // 
            // unselectAllToolStripMenuItem
            // 
            this.unselectAllToolStripMenuItem.Name = "unselectAllToolStripMenuItem";
            this.unselectAllToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.unselectAllToolStripMenuItem.Text = "&Unselect All";
            this.unselectAllToolStripMenuItem.Click += new System.EventHandler(this.unselectAllToolStripMenuItem_Click);
            // 
            // mainSplitContainer
            // 
            this.mainSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainSplitContainer.Location = new System.Drawing.Point(0, 25);
            this.mainSplitContainer.Name = "mainSplitContainer";
            this.mainSplitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // mainSplitContainer.Panel1
            // 
            this.mainSplitContainer.Panel1.Controls.Add(this.splitContainer);
            // 
            // mainSplitContainer.Panel2
            // 
            this.mainSplitContainer.Panel2.Controls.Add(this.resultsCheckedListBox);
            this.mainSplitContainer.Panel2.Controls.Add(this.searchResultsTopPanel);
            this.mainSplitContainer.Size = new System.Drawing.Size(992, 560);
            this.mainSplitContainer.SplitterDistance = 357;
            this.mainSplitContainer.TabIndex = 2;
            // 
            // splitContainer
            // 
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.treeView);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.directoryContentsCheckedListBox);
            this.splitContainer.Size = new System.Drawing.Size(992, 357);
            this.splitContainer.SplitterDistance = 330;
            this.splitContainer.TabIndex = 2;
            // 
            // treeView
            // 
            this.treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView.Location = new System.Drawing.Point(0, 0);
            this.treeView.Name = "treeView";
            this.treeView.Size = new System.Drawing.Size(330, 357);
            this.treeView.TabIndex = 0;
            this.treeView.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView_AfterSelect);
            // 
            // directoryContentsCheckedListBox
            // 
            this.directoryContentsCheckedListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.directoryContentsCheckedListBox.FormattingEnabled = true;
            this.directoryContentsCheckedListBox.IntegralHeight = false;
            this.directoryContentsCheckedListBox.Location = new System.Drawing.Point(0, 0);
            this.directoryContentsCheckedListBox.Name = "directoryContentsCheckedListBox";
            this.directoryContentsCheckedListBox.Size = new System.Drawing.Size(658, 357);
            this.directoryContentsCheckedListBox.TabIndex = 0;
            this.directoryContentsCheckedListBox.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListBox_ItemCheck);
            // 
            // resultsCheckedListBox
            // 
            this.resultsCheckedListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resultsCheckedListBox.FormattingEnabled = true;
            this.resultsCheckedListBox.IntegralHeight = false;
            this.resultsCheckedListBox.Location = new System.Drawing.Point(0, 25);
            this.resultsCheckedListBox.Name = "resultsCheckedListBox";
            this.resultsCheckedListBox.Size = new System.Drawing.Size(992, 174);
            this.resultsCheckedListBox.TabIndex = 0;
            this.resultsCheckedListBox.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.resultsCheckedListBox_ItemCheck);
            // 
            // searchResultsTopPanel
            // 
            this.searchResultsTopPanel.Controls.Add(this.toolStrip2);
            this.searchResultsTopPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.searchResultsTopPanel.Location = new System.Drawing.Point(0, 0);
            this.searchResultsTopPanel.Name = "searchResultsTopPanel";
            this.searchResultsTopPanel.Size = new System.Drawing.Size(992, 25);
            this.searchResultsTopPanel.TabIndex = 1;
            // 
            // toolStrip2
            // 
            this.toolStrip2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchResultsToolStripLabel,
            this.hideSearchResultsToolStripButton,
            this.searchSelectionToolStripDropDownButton});
            this.toolStrip2.Location = new System.Drawing.Point(0, 0);
            this.toolStrip2.Name = "toolStrip2";
            this.toolStrip2.Size = new System.Drawing.Size(992, 25);
            this.toolStrip2.TabIndex = 1;
            this.toolStrip2.Text = "toolStrip2";
            // 
            // searchResultsToolStripLabel
            // 
            this.searchResultsToolStripLabel.Name = "searchResultsToolStripLabel";
            this.searchResultsToolStripLabel.Size = new System.Drawing.Size(81, 22);
            this.searchResultsToolStripLabel.Text = "Search Results";
            // 
            // hideSearchResultsToolStripButton
            // 
            this.hideSearchResultsToolStripButton.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.hideSearchResultsToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.hideSearchResultsToolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.application_put;
            this.hideSearchResultsToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.hideSearchResultsToolStripButton.Name = "hideSearchResultsToolStripButton";
            this.hideSearchResultsToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.hideSearchResultsToolStripButton.Text = "Hide";
            this.hideSearchResultsToolStripButton.Click += new System.EventHandler(this.hideSearchResultsToolStripButton_Click);
            // 
            // searchSelectionToolStripDropDownButton
            // 
            this.searchSelectionToolStripDropDownButton.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.searchResultsSelectAllToolStripMenuItem,
            this.searchResultsUnselectAllToolStripMenuItem});
            this.searchSelectionToolStripDropDownButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.application_side_list;
            this.searchSelectionToolStripDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.searchSelectionToolStripDropDownButton.Name = "searchSelectionToolStripDropDownButton";
            this.searchSelectionToolStripDropDownButton.Size = new System.Drawing.Size(109, 22);
            this.searchSelectionToolStripDropDownButton.Text = "Selection Tools";
            // 
            // searchResultsSelectAllToolStripMenuItem
            // 
            this.searchResultsSelectAllToolStripMenuItem.Name = "searchResultsSelectAllToolStripMenuItem";
            this.searchResultsSelectAllToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.searchResultsSelectAllToolStripMenuItem.Text = "&Select All";
            this.searchResultsSelectAllToolStripMenuItem.Click += new System.EventHandler(this.searchResultsSelectAllToolStripMenuItem_Click);
            // 
            // searchResultsUnselectAllToolStripMenuItem
            // 
            this.searchResultsUnselectAllToolStripMenuItem.Name = "searchResultsUnselectAllToolStripMenuItem";
            this.searchResultsUnselectAllToolStripMenuItem.Size = new System.Drawing.Size(139, 22);
            this.searchResultsUnselectAllToolStripMenuItem.Text = "&Unselect All";
            this.searchResultsUnselectAllToolStripMenuItem.Click += new System.EventHandler(this.searchResultsUnselectAllToolStripMenuItem_Click);
            // 
            // FileSelectionDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(992, 585);
            this.Controls.Add(this.mainSplitContainer);
            this.Controls.Add(this.toolStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.KeyPreview = true;
            this.Name = "FileSelectionDialog";
            this.Text = "Select Files";
            this.Shown += new System.EventHandler(this.FileSelectionDialog_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FileSelectionDialog_KeyDown);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.mainSplitContainer.Panel1.ResumeLayout(false);
            this.mainSplitContainer.Panel2.ResumeLayout(false);
            this.mainSplitContainer.ResumeLayout(false);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.ResumeLayout(false);
            this.searchResultsTopPanel.ResumeLayout(false);
            this.searchResultsTopPanel.PerformLayout();
            this.toolStrip2.ResumeLayout(false);
            this.toolStrip2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton exitToolStripButton;
        private System.Windows.Forms.ToolStripLabel searchPatternLabel;
        private System.Windows.Forms.ToolStripTextBox searchPatternToolStripTextBox;
        private System.Windows.Forms.ToolStripButton excludeGeneratedCodeToolStripButton;
        private System.Windows.Forms.ToolStripDropDownButton directoryContensSelectionToolStripDropDownButton;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unselectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton openSelectedFileToolStripButton;
        private System.Windows.Forms.ToolStripLabel searchToolStripLabel;
        private System.Windows.Forms.ToolStripTextBox searchTextBox;
        private System.Windows.Forms.ToolStripButton searchToolStripButton;
        private System.Windows.Forms.SplitContainer mainSplitContainer;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.TreeView treeView;
        private System.Windows.Forms.CheckedListBox directoryContentsCheckedListBox;
        private System.Windows.Forms.Panel searchResultsTopPanel;
        private System.Windows.Forms.ToolStrip toolStrip2;
        private System.Windows.Forms.ToolStripLabel searchResultsToolStripLabel;
        private System.Windows.Forms.ToolStripButton hideSearchResultsToolStripButton;
        private System.Windows.Forms.CheckedListBox resultsCheckedListBox;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripDropDownButton searchSelectionToolStripDropDownButton;
        private System.Windows.Forms.ToolStripMenuItem searchResultsSelectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchResultsUnselectAllToolStripMenuItem;

    }
}