﻿/*  ----------------------------------------------------------------------------
 *  CSharp Code Header Designer -  (http://colbyafrica.blogspot.com)
 *  ----------------------------------------------------------------------------
 *  Author: Colby Africa
 *  ----------------------------------------------------------------------------
 *  http://code.msdn.microsoft.com/HeaderDesigner/Project/License.aspx
 *  ----------------------------------------------------------------------------
 *  Header Created With CSharp Code Header Designer
 */
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;
using ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties;

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms
{
    /// <summary>
    /// Implements the file selection dialog for CSharp Code Header Designer
    /// </summary>
    public partial class FileSelectionDialog : Form
    {
        #region Instance Data

        private readonly string _RootDirectory;
        private readonly Dictionary<string, List<string>> _SelectedFiles;
        private bool _IsLoading;

        #endregion

        #region Constructors

        public FileSelectionDialog(string rootDirectory, IEnumerable<string> selectedFiles, string searchPattern)
        {
            InitializeComponent();

            _RootDirectory = rootDirectory;
            _SelectedFiles = new Dictionary<string, List<string>>();

            foreach (string path in selectedFiles)
            {
                string directory = Path.GetDirectoryName(path);

                if (!_SelectedFiles.ContainsKey(directory))
                {
                    _SelectedFiles.Add(directory, new List<string>());
                }
                if (!_SelectedFiles[directory].Contains(Path.GetFileName(path)))
                {
                    _SelectedFiles[directory].Add(Path.GetFileName(path));
                }
            }

            searchPatternToolStripTextBox.Text = searchPattern;
        }

        #endregion

        #region Public Properties

        public List<string> SelectedFiles
        {
            get
            {
                List<string> selectedFiles = new List<string>();

                foreach (KeyValuePair<string, List<string>> directory in _SelectedFiles)
                {
                    foreach (string file in directory.Value)
                    {
                        selectedFiles.Add(Path.Combine(directory.Key, file));
                    }
                }

                return selectedFiles;
            }
        }

        #endregion

        #region Private Methods

        private void Search()
        {
            if (string.IsNullOrEmpty(searchTextBox.Text))
            {
                MessageBox.Show(this, "Please provide search criteria.", "Header Designer", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                searchTextBox.Focus();
                return;
            }

            List<string> results = new List<string>();

            Search(treeView.Nodes[0], searchTextBox.Text, excludeGeneratedCodeToolStripButton.Checked, ref results);

            if (results.Count == 0)
            {
                MessageBox.Show(this, "No results found.", "Header Designer", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                mainSplitContainer.Panel2Collapsed = false;

                resultsCheckedListBox.Items.Clear();

                _IsLoading = true;

                foreach (string result in results)
                {
                    string directory = Path.GetDirectoryName(result);

                    bool isItemSelected;

                    if (_SelectedFiles.ContainsKey(directory))
                    {
                        isItemSelected = _SelectedFiles[directory].Contains(Path.GetFileName(result));
                    }
                    else
                    {
                        isItemSelected = false;
                    }

                    resultsCheckedListBox.Items.Add(result, isItemSelected);
                }

                _IsLoading = false;
            }
        }

        private static void Search(TreeNode node, string criteria, bool ignoreDesignerFiles, ref List<string> results)
        {
            try
            {
                if (node.Tag != null)
                {
                    string directory = node.Tag.ToString();

                    if (Directory.Exists(directory))
                    {
                        try
                        {
                            string[] files = Directory.GetFiles(directory, criteria);
                            foreach (string file in files)
                            {
                                if (ignoreDesignerFiles)
                                {
                                    if (!IsFileGenerated(file))
                                    {
                                        results.Add(file);
                                    }
                                }
                                else
                                {
                                    results.Add(file);
                                }
                            }
                        }
                        catch { }
                    }

                    foreach (TreeNode thisNode in node.Nodes)
                    {
                        Search(thisNode, criteria, ignoreDesignerFiles, ref results);
                    }

                }
            }
            catch (Exception) { }
        }

        private void SearchDirectory(string rootDirectory, TreeNode node)
        {
            try
            {
                Application.DoEvents();

                string[] directories = Directory.GetDirectories(rootDirectory);

                foreach (string directory in directories)
                {
                    if ((File.GetAttributes(directory) & FileAttributes.Hidden) == 0)
                    {
                        TreeNode newNode = node.Nodes.Add(Path.GetFileName(directory));
                        newNode.Tag = directory;

                        SearchDirectory(directory, newNode);
                    }
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(this, exception.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
                
        private static bool IsFileGenerated(string file)
        {
            return file.Contains("assemblyInfo.cs") ||
                   file.Contains("AssemblyInfo.cs") ||
                   file.Contains("reference.cs") ||
                   file.Contains("Reference.cs") ||
                   file.Contains(".Designer.") || 
                   file.Contains(".designer.");
        }

        private void LoadFiles(string directory)
        {
            _IsLoading = true;

            directoryContentsCheckedListBox.Items.Clear();

            if (!_SelectedFiles.ContainsKey(directory))
            {
                _SelectedFiles.Add(directory, new List<string>());
            }

            string searchPattern;

            if (string.IsNullOrEmpty(searchPatternToolStripTextBox.Text))
            {
                searchPattern = "*.*";
            }
            else
            {
                searchPattern = searchPatternToolStripTextBox.Text;
            }

            string[] files;

            try
            {
                files = Directory.GetFiles(directory, searchPattern);
            }
            catch (Exception exception)
            {
                MessageBox.Show(this, exception.Message, "Header Designer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                searchPatternToolStripTextBox.Focus();
                return;
            }

            foreach (string file in files)
            {
                if ((File.GetAttributes(file) & FileAttributes.Hidden) == 0)
                {
                    string fileName = Path.GetFileName(file);

                    if (excludeGeneratedCodeToolStripButton.Checked)
                    {
                        if (!fileName.ToUpper().Contains(".DESIGNER."))
                        {
                            directoryContentsCheckedListBox.Items.Add(fileName, _SelectedFiles[directory].Contains(fileName));
                        }
                    }
                    else
                    {
                        directoryContentsCheckedListBox.Items.Add(fileName, _SelectedFiles[directory].Contains(fileName));
                    }
                }
            }

            _IsLoading = false;
        }

        private static void SetListChecked(CheckedListBox checkedListBox, bool isItemChecked)
        {
            for (int i = 0; i < checkedListBox.Items.Count; i++)
            {
                checkedListBox.SetItemChecked(i, isItemChecked);
            }
        }

        #endregion

        #region Event Handlers

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (!string.IsNullOrEmpty((string)treeView.SelectedNode.Tag))
            {
                LoadFiles(treeView.SelectedNode.Tag.ToString());
            }
        }

        private void FileSelectionDialog_Shown(object sender, EventArgs e)
        {
            TreeNode rootNode = treeView.Nodes.Add("Source Directory");
            rootNode.Tag = _RootDirectory;

            SearchDirectory(_RootDirectory, rootNode);

            rootNode.Expand();
        }

        private void checkedListBox_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (!_IsLoading)
            {
                _IsLoading = true;

                string directory = treeView.SelectedNode.Tag.ToString();
                string file = directoryContentsCheckedListBox.Items[e.Index].ToString();

                if (e.CurrentValue == CheckState.Checked)
                {
                    _SelectedFiles[directory].Remove(file);
                }
                else
                {
                    if (!_SelectedFiles.ContainsKey(directory))
                    {
                        _SelectedFiles.Add(directory, new List<string>());
                    }
                    if (!_SelectedFiles[directory].Contains(file))
                    {
                        _SelectedFiles[directory].Add(file);    
                    }                    
                }

                int index = resultsCheckedListBox.FindString(Path.Combine(directory, file));

                if (index != -1)
                {
                    resultsCheckedListBox.SetItemChecked(index, e.NewValue == CheckState.Checked ? true : false);
                }
                _IsLoading = false;
            }
        }

        private void excludeGeneratedCodeToolStripButton_Click(object sender, EventArgs e)
        {
            if (excludeGeneratedCodeToolStripButton.Checked)
            {
                excludeGeneratedCodeToolStripButton.Image = Resources.arrow_out;
            }
            else
            {
                excludeGeneratedCodeToolStripButton.Image = Resources.arrow_in;
            }

            if (treeView.SelectedNode != null)
            {
                LoadFiles(treeView.SelectedNode.Tag.ToString());

                if (!string.IsNullOrEmpty(searchTextBox.Text))
                {
                    Search();
                }
            }
        }

        private void searchPatternToolStripTextBox_KeyUp(object sender, KeyEventArgs e)
        {
            if (treeView.SelectedNode != null)
            {
                LoadFiles(treeView.SelectedNode.Tag.ToString());
            }
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetListChecked(directoryContentsCheckedListBox, true);
        }

        private void unselectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetListChecked(directoryContentsCheckedListBox, false);
        }

        private void exitToolStripButton_Click(object sender, EventArgs e)
        {
            DialogResult = DialogResult.OK;
            this.Close();
        }

        private void openSelectedFileToolStripButton_Click(object sender,EventArgs e)
        {
            if (directoryContentsCheckedListBox.SelectedItem == null && resultsCheckedListBox.SelectedItem == null)
            {
                MessageBox.Show(this, "Please select a file.", "Header Designer", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (directoryContentsCheckedListBox.SelectedItem != null)
                {
                    Process.Start(Path.Combine(treeView.SelectedNode.Tag.ToString(), directoryContentsCheckedListBox.SelectedItem.ToString()));    
                }
                else
                {
                    Process.Start(resultsCheckedListBox.SelectedItem.ToString());
                }                
            }
        }

        private void searchToolStripButton_Click(object sender, EventArgs e)
        {
            Search();
        }

        private void hideSearchResultsToolStripButton_Click(object sender, EventArgs e)
        {
            mainSplitContainer.Panel2Collapsed = true;
        }

        private void resultsCheckedListBox_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            if (!_IsLoading)
            {
                string path = resultsCheckedListBox.Items[e.Index].ToString();
                string directory = Path.GetDirectoryName(path);
                string file = Path.GetFileName(path);

                if (e.CurrentValue == CheckState.Checked)
                {
                    if (_SelectedFiles.ContainsKey(directory) && _SelectedFiles[directory].Contains(file))
                    {
                        _SelectedFiles[directory].Remove(file);
                    }                    
                }
                else
                {
                    if (!_SelectedFiles.ContainsKey(directory))
                    {
                        _SelectedFiles.Add(directory, new List<string>());
                    }

                    if (!_SelectedFiles[directory].Contains(file))
                    {
                        _SelectedFiles[directory].Add(file);    
                    }                    
                }

                if (treeView.SelectedNode != null && directory.Equals(treeView.SelectedNode.Tag.ToString(), StringComparison.InvariantCultureIgnoreCase))
                {
                    int index = directoryContentsCheckedListBox.FindString(file);

                    if (index != -1)
                    {
                        directoryContentsCheckedListBox.SetItemChecked(index, e.NewValue == CheckState.Checked ? true : false);
                    }
                }
            }
        }

        private void searchResultsSelectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetListChecked(resultsCheckedListBox, true);
        }

        private void searchResultsUnselectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SetListChecked(resultsCheckedListBox, false);
        }

        private void FileSelectionDialog_KeyDown(object sender, KeyEventArgs e)
        {
            if (ActiveControl == searchTextBox.Control)
            {
                if (e.KeyCode == Keys.Enter)
                {
                    Search();
                }
            }

            if (e.KeyCode == Keys.F && e.Control)
            {
                searchTextBox.Focus();
                searchTextBox.SelectAll();
            }
        }

        #endregion

    }
}
