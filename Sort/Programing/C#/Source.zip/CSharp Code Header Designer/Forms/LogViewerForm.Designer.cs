﻿namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms
{
    partial class LogViewerForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogViewerForm));
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.logSplitContainer = new System.Windows.Forms.SplitContainer();
            this.listView = new System.Windows.Forms.ListView();
            this.pathColumn = new System.Windows.Forms.ColumnHeader("flag_green.png");
            this.logItemsListBox = new System.Windows.Forms.ListBox();
            this.logSplitContainer.Panel1.SuspendLayout();
            this.logSplitContainer.Panel2.SuspendLayout();
            this.logSplitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "flag_green.png");
            this.imageList.Images.SetKeyName(1, "flag_red.png");
            // 
            // logSplitContainer
            // 
            this.logSplitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logSplitContainer.Location = new System.Drawing.Point(0, 0);
            this.logSplitContainer.Name = "logSplitContainer";
            // 
            // logSplitContainer.Panel1
            // 
            this.logSplitContainer.Panel1.Controls.Add(this.listView);
            // 
            // logSplitContainer.Panel2
            // 
            this.logSplitContainer.Panel2.Controls.Add(this.logItemsListBox);
            this.logSplitContainer.Size = new System.Drawing.Size(801, 642);
            this.logSplitContainer.SplitterDistance = 266;
            this.logSplitContainer.TabIndex = 1;
            // 
            // listView
            // 
            this.listView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.pathColumn});
            this.listView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listView.Location = new System.Drawing.Point(0, 0);
            this.listView.Name = "listView";
            this.listView.Size = new System.Drawing.Size(266, 642);
            this.listView.SmallImageList = this.imageList;
            this.listView.TabIndex = 0;
            this.listView.UseCompatibleStateImageBehavior = false;
            this.listView.View = System.Windows.Forms.View.Details;
            this.listView.SelectedIndexChanged += new System.EventHandler(this.listView_SelectedIndexChanged);
            // 
            // pathColumn
            // 
            this.pathColumn.Text = "Path";
            // 
            // logItemsListBox
            // 
            this.logItemsListBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.logItemsListBox.FormattingEnabled = true;
            this.logItemsListBox.Location = new System.Drawing.Point(0, 0);
            this.logItemsListBox.Name = "logItemsListBox";
            this.logItemsListBox.Size = new System.Drawing.Size(531, 641);
            this.logItemsListBox.TabIndex = 0;
            // 
            // LogViewerForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 642);
            this.Controls.Add(this.logSplitContainer);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "LogViewerForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Log Viewer";
            this.Shown += new System.EventHandler(this.LogViewerForm_Shown);
            this.logSplitContainer.Panel1.ResumeLayout(false);
            this.logSplitContainer.Panel2.ResumeLayout(false);
            this.logSplitContainer.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.SplitContainer logSplitContainer;
        private System.Windows.Forms.ListView listView;
        private System.Windows.Forms.ColumnHeader pathColumn;
        private System.Windows.Forms.ListBox logItemsListBox;
    }
}