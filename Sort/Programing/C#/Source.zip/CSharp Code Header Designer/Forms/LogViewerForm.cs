﻿/*  ----------------------------------------------------------------------------
 *  CSharp Code Header Designer -  (http://colbyafrica.blogspot.com)
 *  ----------------------------------------------------------------------------
 *  Author: Colby Africa
 *  ----------------------------------------------------------------------------
 *  http://code.msdn.microsoft.com/HeaderDesigner/Project/License.aspx
 *  ----------------------------------------------------------------------------
 *  Header Created With CSharp Code Header Designer
 */
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms
{
    public partial class LogViewerForm : Form
    {
        private readonly Dictionary<string, List<string>> _Status;

        public LogViewerForm(Dictionary<string, List<string>> Status)
        {
            InitializeComponent();

            _Status = Status;
        }

        private void LogViewerForm_Shown(object sender,
                                         EventArgs e)
        {
            if (_Status != null)
            {
                foreach (KeyValuePair<string, List<string>> pair in _Status)
                {
                    ListViewItem listViewItem = new ListViewItem(pair.Key);

                    bool isError = false;
                    foreach (string value in pair.Value)
                    {
                        isError = value.Contains("not success");
                    }
                    if (isError)
                    {
                        listViewItem.ImageKey = "flag_red.png";
                    }
                    else
                    {
                        listViewItem.ImageKey = "flag_green.png";
                    }
                                        
                    listView.Items.Add(listViewItem);
                }
            }

            listView.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent);
        }

        private void listView_SelectedIndexChanged(object sender,
                                                       EventArgs e)
        {
            logItemsListBox.Items.Clear();

            if (listView.SelectedItems.Count > 0 && _Status.ContainsKey(listView.SelectedItems[0].SubItems[0].Text))
            {
                foreach (string logItem in _Status[listView.SelectedItems[0].SubItems[0].Text])
                {
                    logItemsListBox.Items.Add(logItem);
                }
            }
        }
    }
}
