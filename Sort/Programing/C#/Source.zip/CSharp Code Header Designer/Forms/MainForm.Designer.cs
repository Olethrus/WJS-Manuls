﻿using ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties;

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.sourceDirectoryLabel = new System.Windows.Forms.Label();
            this.sourceDirectoryTextBox = new System.Windows.Forms.TextBox();
            this.browseButton = new System.Windows.Forms.Button();
            this.headerLabel = new System.Windows.Forms.Label();
            this.headerTextBox = new System.Windows.Forms.TextBox();
            this.dataGridView = new System.Windows.Forms.DataGridView();
            this.supportedFieldColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.replaceableFieldNameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.replaceableFieldValueColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.commentsColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.replaceablFieldsLabel = new System.Windows.Forms.Label();
            this.imageList = new System.Windows.Forms.ImageList(this.components);
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.famFamFamLink = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.selectFilesButton = new System.Windows.Forms.Button();
            this.headerPanel = new System.Windows.Forms.Panel();
            this.lbAutoComplete = new System.Windows.Forms.ListBox();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.openToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.saveToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.baseTemplatetoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.styleCopeToolStripButton = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.autoFieldsTtoolStripButton = new System.Windows.Forms.ToolStripButton();
            this.LicenseToolStripDropDownButton = new System.Windows.Forms.ToolStripDropDownButton();
            this.removeHeadersAndFootersCheckBox = new System.Windows.Forms.CheckBox();
            this.viewLogButton = new System.Windows.Forms.Button();
            this.goButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).BeginInit();
            this.statusStrip.SuspendLayout();
            this.headerPanel.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // sourceDirectoryLabel
            // 
            this.sourceDirectoryLabel.AutoSize = true;
            this.sourceDirectoryLabel.Location = new System.Drawing.Point(12, 10);
            this.sourceDirectoryLabel.Name = "sourceDirectoryLabel";
            this.sourceDirectoryLabel.Size = new System.Drawing.Size(86, 13);
            this.sourceDirectoryLabel.TabIndex = 0;
            this.sourceDirectoryLabel.Text = "Source Directory";
            // 
            // sourceDirectoryTextBox
            // 
            this.sourceDirectoryTextBox.Location = new System.Drawing.Point(15, 27);
            this.sourceDirectoryTextBox.Name = "sourceDirectoryTextBox";
            this.sourceDirectoryTextBox.Size = new System.Drawing.Size(676, 20);
            this.sourceDirectoryTextBox.TabIndex = 1;
            this.sourceDirectoryTextBox.TextChanged += new System.EventHandler(this.sourceDirectoryTextBox_TextChanged);
            // 
            // browseButton
            // 
            this.browseButton.Location = new System.Drawing.Point(534, 53);
            this.browseButton.Name = "browseButton";
            this.browseButton.Size = new System.Drawing.Size(75, 23);
            this.browseButton.TabIndex = 2;
            this.browseButton.Text = "&Browse";
            this.browseButton.UseVisualStyleBackColor = true;
            this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
            // 
            // headerLabel
            // 
            this.headerLabel.AutoSize = true;
            this.headerLabel.Location = new System.Drawing.Point(12, 66);
            this.headerLabel.Name = "headerLabel";
            this.headerLabel.Size = new System.Drawing.Size(42, 13);
            this.headerLabel.TabIndex = 3;
            this.headerLabel.Text = "Header";
            // 
            // headerTextBox
            // 
            this.headerTextBox.AcceptsReturn = true;
            this.headerTextBox.AcceptsTab = true;
            this.headerTextBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this.headerTextBox.Font = new System.Drawing.Font("Courier New", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.headerTextBox.ForeColor = System.Drawing.Color.Green;
            this.headerTextBox.Location = new System.Drawing.Point(0, 25);
            this.headerTextBox.Multiline = true;
            this.headerTextBox.Name = "headerTextBox";
            this.headerTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.headerTextBox.Size = new System.Drawing.Size(676, 234);
            this.headerTextBox.TabIndex = 5;
            this.headerTextBox.Text = resources.GetString("headerTextBox.Text");
            this.headerTextBox.WordWrap = false;
            this.headerTextBox.TextChanged += new System.EventHandler(this.headerTextBox_TextChanged);
            this.headerTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.headerTextBox_KeyDown);
            // 
            // dataGridView
            // 
            this.dataGridView.AllowUserToAddRows = false;
            this.dataGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supportedFieldColumn,
            this.replaceableFieldNameColumn,
            this.replaceableFieldValueColumn,
            this.commentsColumn});
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView.Location = new System.Drawing.Point(14, 369);
            this.dataGridView.Name = "dataGridView";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView.RowHeadersVisible = false;
            this.dataGridView.Size = new System.Drawing.Size(676, 193);
            this.dataGridView.TabIndex = 6;
            this.dataGridView.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_CellEndEdit);
            // 
            // supportedFieldColumn
            // 
            this.supportedFieldColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.supportedFieldColumn.HeaderText = "";
            this.supportedFieldColumn.Name = "supportedFieldColumn";
            this.supportedFieldColumn.Width = 5;
            // 
            // replaceableFieldNameColumn
            // 
            this.replaceableFieldNameColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.replaceableFieldNameColumn.HeaderText = "Replaceable Field";
            this.replaceableFieldNameColumn.Name = "replaceableFieldNameColumn";
            this.replaceableFieldNameColumn.ReadOnly = true;
            this.replaceableFieldNameColumn.Width = 117;
            // 
            // replaceableFieldValueColumn
            // 
            this.replaceableFieldValueColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.replaceableFieldValueColumn.HeaderText = "Value";
            this.replaceableFieldValueColumn.Name = "replaceableFieldValueColumn";
            this.replaceableFieldValueColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.replaceableFieldValueColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.replaceableFieldValueColumn.Width = 40;
            // 
            // commentsColumn
            // 
            this.commentsColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.commentsColumn.HeaderText = "Feedback";
            this.commentsColumn.Name = "commentsColumn";
            this.commentsColumn.ReadOnly = true;
            // 
            // replaceablFieldsLabel
            // 
            this.replaceablFieldsLabel.AutoSize = true;
            this.replaceablFieldsLabel.Location = new System.Drawing.Point(12, 353);
            this.replaceablFieldsLabel.Name = "replaceablFieldsLabel";
            this.replaceablFieldsLabel.Size = new System.Drawing.Size(97, 13);
            this.replaceablFieldsLabel.TabIndex = 7;
            this.replaceablFieldsLabel.Text = "Replaceable Fields";
            // 
            // imageList
            // 
            this.imageList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageList.ImageStream")));
            this.imageList.TransparentColor = System.Drawing.Color.Transparent;
            this.imageList.Images.SetKeyName(0, "supportedField");
            this.imageList.Images.SetKeyName(1, "notSupportedField");
            this.imageList.Images.SetKeyName(2, "supportedFieldWithError");
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.famFamFamLink,
            this.toolStripProgressBar,
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 611);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(707, 22);
            this.statusStrip.SizingGrip = false;
            this.statusStrip.TabIndex = 10;
            this.statusStrip.Text = "statusStrip1";
            // 
            // famFamFamLink
            // 
            this.famFamFamLink.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.famFamFamLink.IsLink = true;
            this.famFamFamLink.Name = "famFamFamLink";
            this.famFamFamLink.Size = new System.Drawing.Size(142, 17);
            this.famFamFamLink.Text = "Icons from FAMFAMFAM";
            this.famFamFamLink.Click += new System.EventHandler(this.famFamFamLink_Click);
            // 
            // toolStripProgressBar
            // 
            this.toolStripProgressBar.Name = "toolStripProgressBar";
            this.toolStripProgressBar.Size = new System.Drawing.Size(100, 16);
            this.toolStripProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Marquee;
            this.toolStripProgressBar.Visible = false;
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(64, 17);
            this.toolStripStatusLabel.Text = "<Waiting>";
            this.toolStripStatusLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // selectFilesButton
            // 
            this.selectFilesButton.Enabled = false;
            this.selectFilesButton.Location = new System.Drawing.Point(615, 53);
            this.selectFilesButton.Name = "selectFilesButton";
            this.selectFilesButton.Size = new System.Drawing.Size(75, 23);
            this.selectFilesButton.TabIndex = 13;
            this.selectFilesButton.Text = "&Select Files";
            this.selectFilesButton.UseVisualStyleBackColor = true;
            this.selectFilesButton.Click += new System.EventHandler(this.selectFilesButton_Click);
            // 
            // headerPanel
            // 
            this.headerPanel.Controls.Add(this.lbAutoComplete);
            this.headerPanel.Controls.Add(this.headerTextBox);
            this.headerPanel.Controls.Add(this.toolStrip);
            this.headerPanel.Location = new System.Drawing.Point(14, 83);
            this.headerPanel.Name = "headerPanel";
            this.headerPanel.Size = new System.Drawing.Size(676, 259);
            this.headerPanel.TabIndex = 16;
            // 
            // lbAutoComplete
            // 
            this.lbAutoComplete.FormattingEnabled = true;
            this.lbAutoComplete.Location = new System.Drawing.Point(292, 97);
            this.lbAutoComplete.Name = "lbAutoComplete";
            this.lbAutoComplete.Size = new System.Drawing.Size(144, 95);
            this.lbAutoComplete.Sorted = true;
            this.lbAutoComplete.TabIndex = 7;
            this.lbAutoComplete.Visible = false;
            this.lbAutoComplete.SelectedIndexChanged += new System.EventHandler(this.lbAutoComplete_SelectedIndexChanged);
            this.lbAutoComplete.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lb_KeyDown);
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripButton,
            this.saveToolStripButton,
            this.toolStripSeparator1,
            this.baseTemplatetoolStripButton,
            this.styleCopeToolStripButton,
            this.toolStripSeparator2,
            this.autoFieldsTtoolStripButton,
            this.LicenseToolStripDropDownButton});
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(676, 25);
            this.toolStrip.TabIndex = 6;
            this.toolStrip.Text = "toolStrip1";
            // 
            // openToolStripButton
            // 
            this.openToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.openToolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.folder_page;
            this.openToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.openToolStripButton.Name = "openToolStripButton";
            this.openToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.openToolStripButton.Text = "&Open";
            this.openToolStripButton.ToolTipText = "Open (Ctrl+O)";
            this.openToolStripButton.Click += new System.EventHandler(this.openToolStripButton_Click);
            // 
            // saveToolStripButton
            // 
            this.saveToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.saveToolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.page_save;
            this.saveToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.saveToolStripButton.Name = "saveToolStripButton";
            this.saveToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.saveToolStripButton.Text = "&Save";
            this.saveToolStripButton.ToolTipText = "Save (Ctrl+S)";
            this.saveToolStripButton.Click += new System.EventHandler(this.saveToolStripButton_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // baseTemplatetoolStripButton
            // 
            this.baseTemplatetoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.baseTemplatetoolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.script;
            this.baseTemplatetoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.baseTemplatetoolStripButton.Name = "baseTemplatetoolStripButton";
            this.baseTemplatetoolStripButton.Size = new System.Drawing.Size(23, 22);
            this.baseTemplatetoolStripButton.Text = "Base template";
            this.baseTemplatetoolStripButton.ToolTipText = "Base template (Ctrl+B)";
            this.baseTemplatetoolStripButton.Click += new System.EventHandler(this.baseTemplatetoolStripButton_Click);
            // 
            // styleCopeToolStripButton
            // 
            this.styleCopeToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.styleCopeToolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.StyleCop;
            this.styleCopeToolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.styleCopeToolStripButton.Name = "styleCopeToolStripButton";
            this.styleCopeToolStripButton.Size = new System.Drawing.Size(23, 22);
            this.styleCopeToolStripButton.Text = "StyleCop Template";
            this.styleCopeToolStripButton.ToolTipText = "StyleCop Template (Ctrl+E)";
            this.styleCopeToolStripButton.Click += new System.EventHandler(this.styleCopeToolStripButton_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // autoFieldsTtoolStripButton
            // 
            this.autoFieldsTtoolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.autoFieldsTtoolStripButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.autofields;
            this.autoFieldsTtoolStripButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.autoFieldsTtoolStripButton.Name = "autoFieldsTtoolStripButton";
            this.autoFieldsTtoolStripButton.Size = new System.Drawing.Size(23, 22);
            this.autoFieldsTtoolStripButton.Text = "Auto fields";
            this.autoFieldsTtoolStripButton.ToolTipText = "Auto fields (Ctrl+A)";
            this.autoFieldsTtoolStripButton.Click += new System.EventHandler(this.autoFieldsTtoolStripButton_Click);
            // 
            // LicenseToolStripDropDownButton
            // 
            this.LicenseToolStripDropDownButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.LicenseToolStripDropDownButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.license;
            this.LicenseToolStripDropDownButton.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.LicenseToolStripDropDownButton.Name = "LicenseToolStripDropDownButton";
            this.LicenseToolStripDropDownButton.Size = new System.Drawing.Size(29, 22);
            this.LicenseToolStripDropDownButton.Text = "License";
            // 
            // removeHeadersAndFootersCheckBox
            // 
            this.removeHeadersAndFootersCheckBox.AutoSize = true;
            this.removeHeadersAndFootersCheckBox.Checked = true;
            this.removeHeadersAndFootersCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
            this.removeHeadersAndFootersCheckBox.Location = new System.Drawing.Point(74, 583);
            this.removeHeadersAndFootersCheckBox.Name = "removeHeadersAndFootersCheckBox";
            this.removeHeadersAndFootersCheckBox.Size = new System.Drawing.Size(201, 17);
            this.removeHeadersAndFootersCheckBox.TabIndex = 17;
            this.removeHeadersAndFootersCheckBox.Text = "&Remove existing headers and footers";
            this.removeHeadersAndFootersCheckBox.UseVisualStyleBackColor = true;
            // 
            // viewLogButton
            // 
            this.viewLogButton.Enabled = false;
            this.viewLogButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.page_error;
            this.viewLogButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.viewLogButton.Location = new System.Drawing.Point(611, 576);
            this.viewLogButton.Name = "viewLogButton";
            this.viewLogButton.Size = new System.Drawing.Size(80, 28);
            this.viewLogButton.TabIndex = 14;
            this.viewLogButton.Text = "&View Log";
            this.viewLogButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.viewLogButton.UseVisualStyleBackColor = true;
            this.viewLogButton.Click += new System.EventHandler(this.viewLogButton_Click);
            // 
            // goButton
            // 
            this.goButton.Enabled = false;
            this.goButton.Image = global::ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Properties.Resources.arrow_right;
            this.goButton.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.goButton.Location = new System.Drawing.Point(12, 576);
            this.goButton.Name = "goButton";
            this.goButton.Size = new System.Drawing.Size(53, 28);
            this.goButton.TabIndex = 8;
            this.goButton.Text = "&Go";
            this.goButton.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.goButton.UseVisualStyleBackColor = true;
            this.goButton.Click += new System.EventHandler(this.goButton_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(707, 633);
            this.Controls.Add(this.removeHeadersAndFootersCheckBox);
            this.Controls.Add(this.headerPanel);
            this.Controls.Add(this.viewLogButton);
            this.Controls.Add(this.selectFilesButton);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.goButton);
            this.Controls.Add(this.replaceablFieldsLabel);
            this.Controls.Add(this.dataGridView);
            this.Controls.Add(this.headerLabel);
            this.Controls.Add(this.browseButton);
            this.Controls.Add(this.sourceDirectoryTextBox);
            this.Controls.Add(this.sourceDirectoryLabel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "MainForm";
            this.Text = "Colby Africa\'s C# Code Header";
            this.Shown += new System.EventHandler(this.MainForm_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.headerPanel.ResumeLayout(false);
            this.headerPanel.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sourceDirectoryLabel;
        private System.Windows.Forms.TextBox sourceDirectoryTextBox;
        private System.Windows.Forms.Button browseButton;
        private System.Windows.Forms.Label headerLabel;
        private System.Windows.Forms.TextBox headerTextBox;
        private System.Windows.Forms.DataGridView dataGridView;
        private System.Windows.Forms.Label replaceablFieldsLabel;
        private System.Windows.Forms.Button goButton;
        private System.Windows.Forms.ImageList imageList;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripProgressBar toolStripProgressBar;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.Button selectFilesButton;
        private System.Windows.Forms.DataGridViewImageColumn supportedFieldColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn replaceableFieldNameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn replaceableFieldValueColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn commentsColumn;
        private System.Windows.Forms.Button viewLogButton;
        private System.Windows.Forms.ToolStripStatusLabel famFamFamLink;
        private System.Windows.Forms.Panel headerPanel;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton openToolStripButton;
        private System.Windows.Forms.ToolStripButton saveToolStripButton;
        private System.Windows.Forms.CheckBox removeHeadersAndFootersCheckBox;
        private System.Windows.Forms.ListBox lbAutoComplete;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton baseTemplatetoolStripButton;
        private System.Windows.Forms.ToolStripButton styleCopeToolStripButton;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton autoFieldsTtoolStripButton;
        private System.Windows.Forms.ToolStripDropDownButton LicenseToolStripDropDownButton;
    }
}