﻿/*  ----------------------------------------------------------------------------
 *  CSharp Code Header Designer -  (http://colbyafrica.blogspot.com)
 *  ----------------------------------------------------------------------------
 *  Author: Colby Africa
 *  ----------------------------------------------------------------------------
 *  http://code.msdn.microsoft.com/HeaderDesigner/Project/License.aspx
 *  ----------------------------------------------------------------------------
 *  Header Created With CSharp Code Header Designer
 */

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Drawing;
    using System.IO;
    using System.Windows.Forms;
    using System.Xml.Linq;
    using System.Linq;

    /// <summary>
    /// Implements the main user interface for CSharp Code Header Designer
    /// </summary>
    public partial class MainForm : Form
    {
        #region Private Enums

        private enum GoStatus
        {
            None,
            Go,
            Stop
        }

        #endregion

        #region Constants

        private const int FIELD_COMPONENT_IMAGE_INDEX = 0;
        private const int FIELD_COMPONENT_NAME_INDEX = 1;
        private const int FIELD_COMPONENT_VALUE_INDEX = 2;
        private const int FIELD_COMPONENT_FEEDBACK_INDEX = 3;
        private const string MAGIC_NUMBER = "48 65 6C 6C 6F 20 57 6F 72 6C 64 21";
        private const string MAGIC_NUMBER_FILES = "46 69 6C 65 73 20 73 61 76 65 64 21";

        #endregion

        #region Instance Data

        private List<string> _SelectedFiles = new List<string>();
        private string _CurrentTemplatePath;
        private HeaderDesigner _Core;
        int _CurPos;
        int _OldCurPos;
        int _OldSelectedIndex;

        #endregion

        #region Constructors

        public MainForm()
        {
            InitializeComponent();

            goButton.Tag = GoStatus.None;

            InitializeAutoCompleteListBox();

            this.LoadLicenses();
        }

        public MainForm(string headerFile)
        {
            InitializeComponent();

            goButton.Tag = GoStatus.None;

            InitializeAutoCompleteListBox();

            OpenHeaderFile(headerFile);

            this.LoadLicenses();
        }

        #endregion

        #region Private Methods

        private void LoadLicenses()
        {
            XDocument doc = XDocument.Load(Application.StartupPath+@"\Licenses.xml");
            XElement root = doc.Root;

            this.LicenseToolStripDropDownButton.DropDownItems.Clear();

            ToolStripMenuItem tsmiAdd = new ToolStripMenuItem("Add");
            tsmiAdd.ToolTipText = "Add another license";
            tsmiAdd.Click += new EventHandler(tsmiAdd_Click);

            this.LicenseToolStripDropDownButton.DropDownItems.Add(tsmiAdd);

            foreach (ToolStripMenuItem tsmi in (from l in root.Elements()
                                                select new ToolStripMenuItem
                                                {
                                                    Text = l.Element("Code").Value,
                                                    ToolTipText = l.Element("Text").Value,
                                                    Tag = l.Element("Link").Value
                                                }).ToList())
            {
                tsmi.Click += new EventHandler(LicenseTsmi_Click);
                this.LicenseToolStripDropDownButton.DropDownItems.Add(tsmi);
            }

        }

        void tsmiAdd_Click(object sender, EventArgs e)
        {
            AddLicenseForm alf = new AddLicenseForm();

            if (alf.ShowDialog() == DialogResult.OK)
            {
                this.LoadLicenses();
            }
        }

        void LicenseTsmi_Click(object sender, EventArgs e)
        {
            ToolStripMenuItem tsl = sender as ToolStripMenuItem;

            Int32 selectionStart = this.headerTextBox.SelectionStart;
            String insertValue = tsl.ToolTipText + " (" + tsl.Tag + ")";

            this.headerTextBox.Text = this.headerTextBox.Text.Insert(selectionStart, insertValue);
            this.headerTextBox.SelectionStart = selectionStart + insertValue.Length;
        }

        private void InitializeAutoCompleteListBox()
        {
            lbAutoComplete.DataSource = Enum.GetNames(typeof(AutoFields));


            //resize the listBox
            string maxWidth = string.Empty;
            foreach (string str in lbAutoComplete.Items)
            {
                if (str.Length > maxWidth.Length)
                {
                    maxWidth = str;
                }
            }

            int width = (int)CreateGraphics().MeasureString(maxWidth, lbAutoComplete.Font).Width;
            int height = (lbAutoComplete.Items.Count + 1) * lbAutoComplete.Font.Height;

            lbAutoComplete.Size = new Size(width, height);
        }

        private void UpdateReplaceableFields()
        {
            List<string> fields = HeaderDesigner.GetFields(headerTextBox.Text);

            DataGridViewRow[] rows = new DataGridViewRow[dataGridView.Rows.Count];
            dataGridView.Rows.CopyTo(rows, 0);

            dataGridView.Rows.Clear();

            foreach (string field in fields)
            {
                if (!IsFieldPresent(field))
                {
                    if (HeaderDesigner.IsAutoField(field))
                    {
                        if (!field.Contains("DATE"))
                        {
                            dataGridView.Rows.Add(imageList.Images["supportedField"], field, "<Automatically assigned>", "Validating...");
                        }
                        else
                        {
                            Boolean isFound = false;
                            String rowValue = String.Empty;
                            foreach (DataGridViewRow row in rows)
                            {
                                if (field == row.Cells[1].Value.ToString())
                                {
                                    isFound = true;
                                    rowValue = row.Cells[2].Value.ToString();
                                    break;
                                }
                            }

                            if (isFound)
                            {
                                dataGridView.Rows.Add(imageList.Images["supportedField"], field, rowValue, "Validating...");
                            }
                            else
                            {
                                dataGridView.Rows.Add(imageList.Images["supportedField"], field, "You can provide a format date here", "Validating...");
                            }
                        }
                    }
                    else
                    {
                        Boolean isFound = false;
                        String rowValue = String.Empty;
                        foreach (DataGridViewRow row in rows)
                        {
                            if (field == row.Cells[1].Value.ToString())
                            {
                                isFound = true;
                                rowValue = row.Cells[2].Value.ToString();
                                break;
                            }
                        }

                        if (isFound)
                        {
                            dataGridView.Rows.Add(imageList.Images["supportedFieldWithError"], field, rowValue, String.Empty);
                        }
                        else
                        {
                            dataGridView.Rows.Add(imageList.Images["supportedFieldWithError"], field, String.Empty, "please provide a value.");
                        }
                    }
                }

                UpdateRow(dataGridView.Rows.Count - 1);
            }

            for (int i = dataGridView.Rows.Count - 1; i > 0; i--)
            {
                DataGridViewRow row = dataGridView.Rows[i];

                if (!fields.Contains(row.Cells[FIELD_COMPONENT_NAME_INDEX].Value.ToString()))
                {
                    dataGridView.Rows.RemoveAt(i);
                }
            }
        }


        private bool IsFieldPresent(string fieldName)
        {
            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (row.Cells[FIELD_COMPONENT_NAME_INDEX].Value.ToString().Equals(fieldName, StringComparison.InvariantCultureIgnoreCase))
                {
                    return true;
                }
            }

            return false;
        }

        private void UpdateRow(int rowIndex)
        {
            string field = dataGridView.Rows[rowIndex].Cells[FIELD_COMPONENT_NAME_INDEX].Value.ToString();

            Image feedBackImage = imageList.Images["supportedField"];
            string feedback = string.Empty;

            if (HeaderDesigner.IsAutoField(field))
            {
                if (!field.Contains("DATE"))
                {
                    dataGridView.Rows[rowIndex].ReadOnly = true;
                }
                else
                {
                    if (dataGridView.Rows[rowIndex].Cells[FIELD_COMPONENT_VALUE_INDEX].Value.ToString() == "<Automatically assigned>")
                    {
                        dataGridView.Rows[rowIndex].Cells[FIELD_COMPONENT_VALUE_INDEX].Value = "You can provide a format date here";
                    }
                }

                if (HeaderDesigner.IsValidAutoField(field))
                {
                    feedBackImage = imageList.Images["supportedField"];
                }
                else
                {
                    feedBackImage = imageList.Images["supportedFieldWithError"];
                    feedback = string.Format("{0} is not a supported Auto field", field);
                    dataGridView.Rows[rowIndex].Cells[FIELD_COMPONENT_VALUE_INDEX].Value = string.Empty;
                }
            }
            else
            {
                dataGridView.Rows[rowIndex].ReadOnly = false;
                if (string.IsNullOrEmpty((string)dataGridView.Rows[rowIndex].Cells[FIELD_COMPONENT_VALUE_INDEX].Value))
                {
                    feedBackImage = imageList.Images["supportedFieldWithError"];
                    feedback = "Please provide a value.";
                }
            }

            dataGridView.Rows[rowIndex].Cells[FIELD_COMPONENT_IMAGE_INDEX].Value = feedBackImage;
            dataGridView.Rows[rowIndex].Cells[FIELD_COMPONENT_FEEDBACK_INDEX].Value = feedback;
        }

        private void Document()
        {
            if (_SelectedFiles == null || _SelectedFiles.Count == 0)
            {
                MessageBox.Show(this, "Please select files to apply the header to.", "Header Designer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            Dictionary<string, string> replaceableFields = GetReplaceableFields();

            if (replaceableFields == null)
            {
                return;
            }

            _Core = null;

            try
            {
                _Core = new HeaderDesigner(sourceDirectoryTextBox.Text,
                                 headerTextBox.Text,
                                 string.Empty,
                                 removeHeadersAndFootersCheckBox.Checked,
                                 replaceableFields,
                                 _SelectedFiles);

                toolStripProgressBar.Visible = true;
                toolStripStatusLabel.Visible = true;

                _Core.OnStatusChanged += CoreOnStatusChanged;
                _Core.StartProcessing();
            }
            catch (Exception exception)
            {
                MessageBox.Show(this, exception.Message, "Header Designer", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                if (_Core != null)
                {
                    _Core.OnStatusChanged -= CoreOnStatusChanged;
                }

                toolStripProgressBar.Visible = false;
                toolStripStatusLabel.Visible = false;
            }
        }

        private Dictionary<string, string> GetReplaceableFields()
        {
            Dictionary<string, string> replaceableFields = new Dictionary<string, string>();
            bool errorsUnresolved = false;

            foreach (DataGridViewRow row in dataGridView.SelectedRows)
            {
                row.Selected = false;
            }

            foreach (DataGridViewRow row in dataGridView.Rows)
            {
                if (string.IsNullOrEmpty((string)row.Cells[FIELD_COMPONENT_VALUE_INDEX].Value))
                {
                    row.Selected = true;
                    errorsUnresolved = true;
                }
                else
                {
                    if (!errorsUnresolved)
                    {
                        replaceableFields.Add((string)row.Cells[FIELD_COMPONENT_NAME_INDEX].Value, (string)row.Cells[FIELD_COMPONENT_VALUE_INDEX].Value);
                    }
                }
            }

            if (errorsUnresolved)
            {
                MessageBox.Show(this, "Please correct the selected rows.", "Header Designer", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return null;
            }

            return replaceableFields;
        }

        private void SetStatusText(string status)
        {
            toolStripStatusLabel.Text = status;
            Application.DoEvents();
            Application.DoEvents();
            Application.DoEvents();
            Application.DoEvents();
        }

        /// <summary>
        /// Open headerx file
        /// </summary>
        /// <param name="headerFile">headerx path</param>
        private void OpenHeaderFile(String headerFile)
        {
            _CurrentTemplatePath = headerFile;

            headerTextBox.Text = string.Empty;

            string templateText;

            bool filesChanged = false;

            using (StreamReader streamReader = new StreamReader(headerFile))
            {
                templateText = streamReader.ReadToEnd();

                String header = templateText.Substring(0, templateText.IndexOf(MAGIC_NUMBER) - 2);

                headerTextBox.Text = header;

                templateText = templateText.Replace("\r", String.Empty);

                Int32 index = templateText.IndexOf(MAGIC_NUMBER) + MAGIC_NUMBER.Length;

                String fieldData;

                if (templateText.IndexOf(MAGIC_NUMBER_FILES) != -1)
                {
                    fieldData = templateText.Substring(index, templateText.IndexOf(MAGIC_NUMBER_FILES) - index);
                }
                else
                {
                    fieldData = templateText.Substring(index);
                }

                String[] fields = fieldData.Split('\n');

                dataGridView.Rows.Clear();

                foreach (String field in fields)
                {
                    if (!String.IsNullOrEmpty(field))
                    {
                        String[] fieldComponents = field.Split('=');

                        dataGridView.Rows.Add(imageList.Images["supportedField"], fieldComponents[0], fieldComponents[1], "Validating...");

                        UpdateRow(dataGridView.Rows.Count - 1);
                    }
                }

                if (templateText.IndexOf(MAGIC_NUMBER_FILES) != -1)
                {
                    String filesData = templateText.Substring(templateText.IndexOf(MAGIC_NUMBER_FILES) + MAGIC_NUMBER_FILES.Length);

                    _SelectedFiles.Clear();

                    Boolean isFolder = true;

                    foreach (String file in filesData.Split('\n'))
                    {
                        if (!String.IsNullOrEmpty(file))
                        {

                            if (isFolder)
                            {
                                isFolder = false;
                                sourceDirectoryTextBox.Text = file;
                            }
                            else
                            {
                                if (File.Exists(file))
                                {
                                    _SelectedFiles.Add(file);
                                }
                                else if (!filesChanged)
                                {
                                    filesChanged = true;
                                }
                            }
                        }
                    }


                }

                SetButtonEnabledState();
            }

            if (filesChanged)
            {
                this.SaveHeaderFile(_CurrentTemplatePath);
            }
        }


        private String GetBaseTemplate()
        {
            return "/*  ----------------------------------------------------------------------------\r\n"
                     + " *  [COMPANY NAME]\r\n"
                     + " *  ----------------------------------------------------------------------------\r\n"
                     + " *  [PRODUCT NAME]\r\n"
                     + " *  ----------------------------------------------------------------------------\r\n"
                     + " *  File:       [AUTO:FILE]\r\n"
                     + " *  Author:     [AUTO:AUTHOR]\r\n"
                     + " *  ----------------------------------------------------------------------------\r\n"
                     + " */\r\n";
        }


        private String GetStyleCopTemplate()
        {
            return "//-----------------------------------------------------------------------\r\n"
                    + "// <copyright file=\"[AUTO:FILE]\" company=\"[COMPANY NAME]\">\r\n"
                    + "//     Copyright (c) [COMPANY NAME]. All rights reserved.\r\n"
                    + "// </copyright>\r\n"
                    + "// <author[AUTO:AUTHOR]</author>\r\n"
                    + "// <email>[EMAIL]</email>\r\n"
                    + "// <date>[AUTO:MODIFICATION_DATE]</date>\r\n"
                    + "// <summary>[AUTO:SUMMARY]</summary>\r\n"
                    + "//-----------------------------------------------------------------------\r\n";

        }

        private void ShowAutoCompleteListBox()
        {
            if (!lbAutoComplete.Visible)
            {
                _OldCurPos = _CurPos;

                lbAutoComplete.SelectedIndex = 0;
                lbAutoComplete.Visible = lbAutoComplete.Enabled = true;

                Point location;

                if (_CurPos < headerTextBox.Text.Length - 1)
                {
                    location = headerTextBox.GetPositionFromCharIndex(_CurPos);
                }
                // fix bug if _CurPos is last char in headerTextBox
                else
                {
                    location = headerTextBox.GetPositionFromCharIndex(_CurPos - 1);
                    location.X += ((int)CreateGraphics().MeasureString(" ", headerTextBox.Font).Width) * 2;
                }

                int x = location.X;
                int y = location.Y + lbAutoComplete.Font.Height * 2;

                lbAutoComplete.Location = new Point(x, y);

                lbAutoComplete.Focus();
            }
        }


        private void SaveHeaderFile(String filepath)
        {
            Dictionary<string, string> fields = GetReplaceableFields();

            if (fields == null)
            {
                return;
            }

            using (StreamWriter streamWriter = new StreamWriter(_CurrentTemplatePath, false))
            {
                streamWriter.WriteLine(headerTextBox.Text);
                streamWriter.WriteLine(MAGIC_NUMBER);

                foreach (KeyValuePair<string, string> pair in fields)
                {
                    streamWriter.WriteLine(pair.Key + "=" + pair.Value);
                }

                if (sourceDirectoryTextBox.Text != string.Empty)
                {
                    streamWriter.WriteLine(MAGIC_NUMBER_FILES);
                    streamWriter.WriteLine(sourceDirectoryTextBox.Text);

                    if (_SelectedFiles.Count > 0)
                    {
                        foreach (string file in _SelectedFiles)
                        {
                            streamWriter.WriteLine(file);
                        }
                    }
                }
            }
        }

        #endregion

        #region Event Handlers

        private void MainForm_Shown(object sender, EventArgs e)
        {
            UpdateReplaceableFields();
        }

        private void dataGridView_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            UpdateRow(e.RowIndex);
        }

        private void goButton_Click(object sender, EventArgs e)
        {
            GoStatus goStatus = goButton.Tag is GoStatus ? (GoStatus)goButton.Tag : GoStatus.None;

            if (goStatus == GoStatus.Stop || goStatus == GoStatus.None)
            {
                goButton.Text = "Cancel";
                goButton.Tag = GoStatus.Go;
                viewLogButton.Enabled = false;

                Document();
            }
            else
            {
                _Core.StopProcessing();
            }

            viewLogButton.Enabled = _Core != null;
            goButton.Text = "Go";
            goButton.Tag = GoStatus.Stop;
        }

        private void CoreOnStatusChanged(object sender, ProcessingStatusEventArgs e)
        {
            switch (e.Status)
            {
                case ProcessingStatusEventArgs.ProcessingStatus.None:
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.Error:
                    if (e.Exception != null)
                    {
                        MessageBox.Show(this, e.Exception.Message, "Header Designer", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.Sucess:
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.Cancelled:
                    SetStatusText("Cancelled.");
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.BeginProcessing:
                    SetStatusText("Begin processing.");
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.BeginProcessingFile:
                    SetStatusText(string.Format("Processing {0}", Path.GetFileName(e.FileName)));
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.ReadSvn:
                    SetStatusText(string.Format("Reading Subversion information for {0}", Path.GetFileName(e.FileName)));
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.ProcessingFields:
                    SetStatusText(string.Format("Processing fields for {0}", Path.GetFileName(e.FileName)));
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.WritingFile:
                    SetStatusText(string.Format("Writing file {0}", Path.GetFileName(e.FileName)));
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.EndProcessingFile:
                    SetStatusText(string.Format("Processing of {0} complete", Path.GetFileName(e.FileName)));
                    break;
                case ProcessingStatusEventArgs.ProcessingStatus.EndPocessing:
                    SetStatusText("End processing.");
                    break;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        private void browseButton_Click(object sender, EventArgs e)
        {
            FolderBrowserDialog folderBrowserDialog = new FolderBrowserDialog
                                                          {
                                                              Description = "Select source directory"
                                                          };

            // Specify root folder where start browsing starts
            folderBrowserDialog.SelectedPath = sourceDirectoryTextBox.Text;
            if (folderBrowserDialog.ShowDialog(this) == DialogResult.Cancel)
            {
                return;
            }

            if (sourceDirectoryTextBox.Text != folderBrowserDialog.SelectedPath)
            {
                _SelectedFiles.Clear();
            }

            sourceDirectoryTextBox.Text = folderBrowserDialog.SelectedPath;
        }

        private void sourceDirectoryTextBox_TextChanged(object sender, EventArgs e)
        {
            SetButtonEnabledState();
        }

        private void SetButtonEnabledState()
        {
            selectFilesButton.Enabled = !string.IsNullOrEmpty(sourceDirectoryTextBox.Text) && Directory.Exists(sourceDirectoryTextBox.Text);
            goButton.Enabled = selectFilesButton.Enabled && _SelectedFiles.Count > 0;
        }

        private void selectFilesButton_Click(object sender, EventArgs e)
        {
            FileSelectionDialog fileSelectionDialog = new FileSelectionDialog(sourceDirectoryTextBox.Text, _SelectedFiles, "*.cs");

            if (fileSelectionDialog.ShowDialog(this) == DialogResult.OK)
            {
                _SelectedFiles = fileSelectionDialog.SelectedFiles;

                for (int i = _SelectedFiles.Count - 1; i > 0; i--)
                {
                    string file = _SelectedFiles[i];

                    string extension = Path.GetExtension(file);

                    if (!extension.Equals(".cs"))
                    {
                        _SelectedFiles.RemoveAt(i);
                    }
                }
                SetButtonEnabledState();
            }
        }

        private void headerTextBox_TextChanged(object sender, EventArgs e)
        {
            UpdateReplaceableFields();

            _CurPos = headerTextBox.SelectionStart;

            if (_CurPos >= 6)
            {
                if (headerTextBox.Text.Substring(_CurPos - 5, 5).ToUpper() == HeaderDesigner.AUTO_FIELD_PREFIX)
                {
                    this.ShowAutoCompleteListBox();
                }
            }
        }


        void lb_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Enter:
                    lbAutoComplete.Visible = lbAutoComplete.Enabled = false;
                    headerTextBox.Focus();
                    headerTextBox.Text = headerTextBox.Text.Insert(headerTextBox.SelectionStart, lbAutoComplete.Text + "]");
                    headerTextBox.SelectionStart = _OldCurPos + lbAutoComplete.Text.Length + 1;
                    break;

                case Keys.Escape:
                    headerTextBox.Focus();
                    lbAutoComplete.Visible = lbAutoComplete.Enabled = false;
                    break;

                case Keys.Left:
                    headerTextBox.Focus();
                    headerTextBox.SelectionStart = headerTextBox.SelectionStart - 1;
                    lbAutoComplete.Visible = lbAutoComplete.Enabled = false;
                    break;

                case Keys.Right:
                    headerTextBox.Focus();
                    headerTextBox.SelectionStart = headerTextBox.SelectionStart + 1;
                    lbAutoComplete.Visible = lbAutoComplete.Enabled = false;
                    break;

                default:
                    break;
            }
        }

        private void lbAutoComplete_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_OldSelectedIndex < lbAutoComplete.SelectedIndex)
            {
                lbAutoComplete.Location = new Point(lbAutoComplete.Location.X, lbAutoComplete.Location.Y - (lbAutoComplete.SelectedIndex - _OldSelectedIndex) * lbAutoComplete.Font.Height);
            }
            else if (_OldSelectedIndex > lbAutoComplete.SelectedIndex)
            {
                lbAutoComplete.Location = new Point(lbAutoComplete.Location.X, lbAutoComplete.Location.Y + (_OldSelectedIndex - lbAutoComplete.SelectedIndex) * lbAutoComplete.Font.Height);
            }

            _OldSelectedIndex = lbAutoComplete.SelectedIndex;
        }

        private void famFamFamLink_Click(object sender, EventArgs e)
        {
            Process.Start("http://www.famfamfam.com/");
        }

        private void viewLogButton_Click(object sender, EventArgs e)
        {
            if (_Core != null)
            {
                LogViewerForm logViewerForm = new LogViewerForm(_Core.Status);

                logViewerForm.ShowDialog(this);
            }
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
                                                {
                                                    CheckFileExists = true,
                                                    CheckPathExists = true,
                                                    DefaultExt = ".headerx",
                                                    Filter = "Code Headers (*.headerx|*.headerx"
                                                };

            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                OpenHeaderFile(openFileDialog.FileName);
            }
        }


        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            if (GetReplaceableFields() == null)
            {
                return;
            }

            if (string.IsNullOrEmpty(_CurrentTemplatePath))
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog
                                                    {
                                                        CheckFileExists = false,
                                                        CheckPathExists = false,
                                                        DefaultExt = ".headerx",
                                                        AddExtension = true,
                                                        Filter = "Code Headers (*.headerx|*.headerx"
                                                    };

                if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                {
                    _CurrentTemplatePath = saveFileDialog.FileName;
                }
                else
                {
                    return;
                }
            }

            this.SaveHeaderFile(_CurrentTemplatePath);
        }


        private void headerTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyData)
            {
                // Ctrl+O: Open headerx file
                case Keys.O | Keys.Control:
                    this.openToolStripButton_Click(this, null);
                    break;

                // Ctrl+S: Save headerx file
                case Keys.S | Keys.Control:
                    this.saveToolStripButton_Click(this, null);
                    break;

                // Ctrl+B: apply base template
                case Keys.B | Keys.Control:
                    this.baseTemplatetoolStripButton_Click(this, null);
                    break;

                // Ctrl+E: apply StyleCope template
                case Keys.E | Keys.Control:
                    this.styleCopeToolStripButton_Click(this, null);
                    break;

                // Ctrl+A: insert an auto field
                case Keys.A | Keys.Control:
                    this.autoFieldsTtoolStripButton_Click(this, null);
                    break;
            }


        }


        private void baseTemplatetoolStripButton_Click(object sender, EventArgs e)
        {
            this.headerTextBox.Text = this.GetBaseTemplate();
        }


        private void styleCopeToolStripButton_Click(object sender, EventArgs e)
        {
            this.headerTextBox.Text = this.GetStyleCopTemplate();
        }

        private void autoFieldsTtoolStripButton_Click(object sender, EventArgs e)
        {
            Int32 index = this.headerTextBox.SelectionStart;
            this.headerTextBox.Text = this.headerTextBox.Text.Insert(this.headerTextBox.SelectionStart, "[AUTO:");
            this.headerTextBox.SelectionStart = index + 6;
            _CurPos = index + 6;
            this.ShowAutoCompleteListBox();
        }

        #endregion

    }
}
