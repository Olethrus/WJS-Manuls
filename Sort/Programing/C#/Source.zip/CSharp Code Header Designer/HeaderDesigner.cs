﻿/*  ----------------------------------------------------------------------------
 *  CSharp Code Header Designer -  (http://colbyafrica.blogspot.com)
 *  ----------------------------------------------------------------------------
 *  Author: Colby Africa
 *  ----------------------------------------------------------------------------
 *  http://code.msdn.microsoft.com/HeaderDesigner/Project/License.aspx
 *  ----------------------------------------------------------------------------
 *  Header Created With CSharp Code Header Designer
 */


namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Text.RegularExpressions;

    /// <summary>
    /// HeaderDesigner
    /// </summary>
    public class HeaderDesigner
    {
        #region Static Fields
        private static readonly Regex NamespacePattern = new Regex(".*(?:namespace )(.*)\r.*");
        private static readonly Regex InheritPattern = new Regex(".* : (.*)\r.*");
        private static readonly Regex SummaryPattern = new Regex("/// <summary>\r\n(///.*\r\n)*/// </summary>\r\n.* class");//"/// ([^<].*)\r.*");
        private static String FileContent = String.Empty;
        #endregion Static Fields

        #region Static Methods

        public static bool IsAutoField(string field)
        {
            field = field.ToUpper();

            if (field.Length > AUTO_FIELD_PREFIX.Length)
            {
                return field.Substring(0, AUTO_FIELD_PREFIX.Length).Equals(AUTO_FIELD_PREFIX);
            }
            return false;
        }

        public static bool IsValidAutoField(string field)
        {
            field = field.Remove(0, 5);

            AutoFields autofield;

            return EnumTryParse(field, out autofield);
        }

        public static bool EnumTryParse<T>(string valueToParse, out T returnValue)
        {
            returnValue = default(T);

            if (Enum.IsDefined(typeof(T), valueToParse))
            {
                returnValue = (T)Enum.Parse(typeof(T), valueToParse);

                return true;

            }

            return false;
        }


        public static List<string> GetFields(string headerText)
        {
            Regex tokenizer = new Regex(FIELD_PATTERN);
            MatchCollection tokens = tokenizer.Matches(headerText);

            List<string> fields = new List<string>();

            for (int matchCount = 0; matchCount < tokens.Count; matchCount++)
            {
                string token = tokens[matchCount].Value;

                token = token.Replace("[", "");
                token = token.Replace("]", "");

                token = token.ToUpper();

                if (!fields.Contains(token))
                {
                    fields.Add(token);
                }
            }

            return fields;
        }

        #endregion Static Methods

        #region Public Constants

        public const string SUBVERSION_FIELD_PREFIX = "SVN:";
        public const string AUTO_FIELD_PREFIX = "AUTO:";
        private const string FIELD_PATTERN = @"\[(?<Tokens>([^\]])*)\]";

        #endregion Public Constants

        #region Instance Data

        private bool _Cancel;
        private readonly string _Header;
        private readonly string _Footer;
        private readonly Dictionary<string, string> _ReplaceableFields;
        private readonly Dictionary<string, List<string>> _Status = new Dictionary<string, List<string>>();
        private readonly List<string> _SourceFiles = new List<string>();
        #endregion Instance Data

        #region Constructor

        public HeaderDesigner(string sourceDirectory,
                    string header,
                    string footer,
                    bool removeHeadersAndFooters,
                    Dictionary<string, string> replaceableFields,
                    List<string> filePaths)
        {
            if (string.IsNullOrEmpty(sourceDirectory) || !Directory.Exists(sourceDirectory))
            {
                throw new ArgumentException("sourceDirectory");
            }

            if (replaceableFields == null)
            {
                throw new ArgumentException("replaceableFields");
            }

            if (filePaths == null)
            {
                throw new ArgumentException("filePaths");
            }

            SourceDirectory = sourceDirectory;
            RemoveHeadersAndFooters = removeHeadersAndFooters;

            _Header = header;
            _Footer = footer;
            _ReplaceableFields = replaceableFields;
            _SourceFiles = filePaths;

        }

        #endregion Constructor

        #region Public Events

        public event EventHandler<ProcessingStatusEventArgs> OnStatusChanged;

        #endregion Public Events

        #region Public Properties

        public string SourceDirectory { get; private set; }
        public bool RemoveHeadersAndFooters { get; set; }

        public Dictionary<string, List<string>> Status
        {
            get { return _Status; }
        }

        #endregion Public Properties

        #region Public Methods

        public void StartProcessing()
        {
            RaiseOnStatusChanged(null, ProcessingStatusEventArgs.ProcessingStatus.BeginProcessing, null);

            Status.Clear();

            foreach (string sourceFile in _SourceFiles)
            {
                RaiseOnStatusChanged(sourceFile, ProcessingStatusEventArgs.ProcessingStatus.BeginProcessingFile, null);

                Status.Add(sourceFile, new List<string>());

                if (_Cancel)
                {
                    Status[sourceFile].Add("User cancelled");
                    RaiseOnStatusChanged(null, ProcessingStatusEventArgs.ProcessingStatus.Cancelled, null);
                    break;
                }

                string header;
                string footer;

                if (CreateFileComponents(sourceFile, out header, out footer))
                {
                    Status[sourceFile].Add("Header and footer created.");

                    FileInfo fileInfo = new FileInfo(sourceFile);
                    DateTime lastWriteTime = fileInfo.LastWriteTime;

                    if (WriteFileComponents(sourceFile, header, footer))
                    {
                        Status[sourceFile].Add("Header and footer successfully written to file.");
                        RaiseOnStatusChanged(sourceFile, ProcessingStatusEventArgs.ProcessingStatus.ProcessingFields, null);
                    }
                    else
                    {
                        Status[sourceFile].Add("Header and footer not successfully written to file.");
                        RaiseOnStatusChanged(sourceFile, ProcessingStatusEventArgs.ProcessingStatus.Error, null);
                    }

                    File.SetLastWriteTime(sourceFile, lastWriteTime);
                }
                else
                {
                    Status[sourceFile].Add("Could not retriev file information");
                    RaiseOnStatusChanged(sourceFile, ProcessingStatusEventArgs.ProcessingStatus.Error, null);
                }
            }

            RaiseOnStatusChanged(null, ProcessingStatusEventArgs.ProcessingStatus.EndPocessing, null);
        }

        public void StopProcessing()
        {
            _Cancel = true;
        }

        #endregion Public Methods

        #region Private Methods

        private bool WriteFileComponents(string file,
                                         string header,
                                         string footer)
        {
            if (header == null)
            {
                header = string.Empty;
            }

            if (footer == null)
            {
                footer = string.Empty;
            }

            try
            {
                if (File.Exists(file))
                {
                    string originalFileContents;

                    Encoding encoding = GetFileEncoding(file);

                    bool writeHeader;

                    using (StreamReader sourceFile = new StreamReader(file, encoding, true))
                    {
                        originalFileContents = sourceFile.ReadToEnd();
                        originalFileContents = originalFileContents.Trim();

                        if (RemoveHeadersAndFooters)
                        {
                            originalFileContents = RemoveDocumentation(originalFileContents).Trim();
                        }

                        writeHeader = !originalFileContents.StartsWith(header, StringComparison.InvariantCultureIgnoreCase);

                        sourceFile.Close();
                    }

                    using (StreamWriter targetFile = new StreamWriter(file, false, encoding))
                    {
                        if (writeHeader)
                        {
                            targetFile.Write(header);
                        }

                        targetFile.Write(originalFileContents);

                        if (!String.IsNullOrEmpty(footer))
                        {
                            targetFile.Write(footer);
                        }

                        targetFile.Flush();
                        targetFile.Close();
                    }

                    return true;
                }

                Status[file].Add(string.Format("Invalid path: + {0}", file));
            }
            catch (Exception exception)
            {
                Status[file].Add(exception.Message);
            }

            return false;
        }

        private static string RemoveDocumentation(string originalFile)
        {
            originalFile = originalFile.Replace("\r", "");

            string[] lines = originalFile.Split(Convert.ToChar("\n"));

            bool startMultiLineComment = false;
            string trimLine;
            int headerEndsLine = 0;

            for (int i = 0; i < lines.Length; i++)
            {
                string line = lines[i];
                trimLine = line.Trim();

                if (trimLine.IndexOf("/*") == 0)
                {
                    startMultiLineComment = true;

                    if (trimLine.IndexOf("*/") == trimLine.Length - ("/*").Length)
                    {
                        startMultiLineComment = false;
                    }
                }
                else
                {
                    if (startMultiLineComment)
                    {
                        if (trimLine.IndexOf("*/") != -1)
                        {
                            startMultiLineComment = false;
                            headerEndsLine++;
                            break;

                            //trimLine = trimLine.Replace("*/", "");
                            //if (!string.IsNullOrEmpty(trimLine))
                            //{
                            //lines[i] = trimLine;
                            //}
                        }
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(trimLine))
                        {
                            if (trimLine.IndexOf("//") != 0)
                            {
                                break;
                            }
                        }
                    }
                }

                headerEndsLine++;
            }

            for (int i = lines.Length - 1; i >= headerEndsLine; i--)
            {
                trimLine = lines[i].Trim();

                if (!string.IsNullOrEmpty(trimLine))
                {
                    if (trimLine.IndexOf("//") == 0)
                    {
                        lines[i] = null;
                    }
                    else
                    {
                        break;  // Last line of source detected.  Exit footer.
                    }
                }
            }

            StringBuilder code = new StringBuilder(lines.Length);

            for (int i = headerEndsLine; i < lines.Length; i++)
            {
                string line = lines[i];

                if (line != null)
                {
                    code.Append(line);
                    code.Append("\r\n");
                }
            }
            return code.ToString();
        }

        private static string[] GetFiles(string folderPath, string searchPattern)
        {
            string[] files = Directory.GetFiles(folderPath, searchPattern);

            if (files.Length == 0)
            {
                if (folderPath.LastIndexOf(@"\") > 0)
                {
                    return GetFiles(folderPath.Remove(folderPath.LastIndexOf(@"\")), searchPattern);
                }

                return files;
            }

            return files;
        }

        private static string GetFileName(string sourceFile, string searchPattern)
        {
            string fileName = "Unknown";

            string folder = Path.GetDirectoryName(sourceFile);

            string[] solutionFiles = GetFiles(folder, searchPattern);

            if (solutionFiles.Length == 1)
            {
                fileName = Path.GetFileNameWithoutExtension(solutionFiles[0]);
            }

            return fileName;
        }

        private static string GetNamespace(string sourceFile)
        {
            string namespaceName = "nothing";

            if (FileContent == String.Empty)
            {
                StreamReader reader = new StreamReader(sourceFile);
                FileContent = reader.ReadToEnd();
                reader.Close();
                reader.Dispose();
            }

            Match result = NamespacePattern.Match(FileContent);

            if (result.Groups.Count == 2)
            {
                namespaceName = result.Groups[1].Value;
            }

            return namespaceName;
        }

        private static string GetInherit(string sourceFile)
        {
            string inherit = "Inherits nothing";

            if (FileContent == String.Empty)
            {
                StreamReader reader = new StreamReader(sourceFile);
                FileContent = reader.ReadToEnd();
                reader.Close();
                reader.Dispose();
            }

            Match result = InheritPattern.Match(FileContent);

            if (result.Groups.Count == 2)
            {
                string test = result.Groups[1].Value.Split(',')[0].Trim();

                if (test[0] != 'I' && test[1] > 90)
                {
                    inherit = test;
                }
            }

            return inherit;
        }

        private static string GetImplements(string sourceFile)
        {
            string implements = "No interface implementations";

            if (FileContent == String.Empty)
            {
                StreamReader reader = new StreamReader(sourceFile);
                FileContent = reader.ReadToEnd();
                reader.Close();
                reader.Dispose();
            }

            Match result = InheritPattern.Match(FileContent);

            if (result.Groups.Count == 2)
            {
                string test = result.Groups[1].Value.Split(',')[0].Trim();

                if (test[0] == 'I' && test[1] > 64 && test[1] < 91)
                {
                    implements = result.Groups[1].Value;
                }
                else
                {
                    if (result.Groups[1].Value != test)
                    {
                        implements = result.Groups[1].Value.Remove(0, result.Groups[1].Value.IndexOf(',')).Trim();
                    }
                }
            }

            return implements;
        }

        private static string GetSummary(string sourceFile)
        {
            string summary = "no summary";

            if (FileContent == String.Empty)
            {
                StreamReader reader = new StreamReader(sourceFile);
                FileContent = reader.ReadToEnd();
                reader.Close();
                reader.Dispose();
            }

            Match result = SummaryPattern.Match(FileContent);

            String temp = result.Value.Replace("///", String.Empty).Replace("<summary>", String.Empty).Replace("</summary>", String.Empty).Trim();

            String[] lines = temp.Split(new Char[] { '\r', '\n' }, StringSplitOptions.RemoveEmptyEntries);

            String comment = String.Empty;
            if (FileContent[0] == '/' && FileContent[1] == '*')
            {
                comment = " *  ";
            }
            else
            {
                comment = "/// ";
            }

            if (lines.Length > 1)
            {
                summary = String.Empty;

                for (int i = 0; i < lines.Length; i++)
                {
                    if (!lines[i].Contains("class") && !String.IsNullOrEmpty(lines[i].Trim()))
                    {
                        if (i > 0)
                        {
                            summary += "\r\n" + comment;
                        }

                        summary += lines[i].Trim();
                    }
                }
            }

            return summary;
        }

        private bool CreateFileComponents(string sourceFile,
                                          out string header,
                                          out string footer)
        {
            header = _Header;
            footer = _Footer;

            RaiseOnStatusChanged(sourceFile, ProcessingStatusEventArgs.ProcessingStatus.ProcessingFields, null);

            foreach (KeyValuePair<string, string> replaceableField in _ReplaceableFields)
            {
                string key = string.Format("[{0}]", replaceableField.Key);

                if (IsAutoField(replaceableField.Key))
                {
                    if (IsValidAutoField(replaceableField.Key))
                    {
                        AutoFields autoField = (AutoFields)Enum.Parse(typeof(AutoFields), replaceableField.Key.Remove(0, 5));

                        switch (autoField)
                        {
                            case AutoFields.FILE:
                                header = header.Replace(key, Path.GetFileName(sourceFile));
                                break;

                            case AutoFields.AUTHOR:
                                if (!string.IsNullOrEmpty(Environment.UserDomainName) && !string.IsNullOrEmpty(Environment.UserName))
                                {
                                    header = header.Replace(key, string.Format(@"{0}\{1}", Environment.UserDomainName, Environment.UserName));
                                }
                                else
                                {
                                    header = header.Replace(key, "<Unknown>");
                                }
                                break;


                            case AutoFields.MODIFICATION_DATE:
                                if (replaceableField.Value != "You can provide a format date here")
                                {
                                    header = header.Replace(key, new FileInfo(sourceFile).LastWriteTime.ToString(replaceableField.Value));
                                }
                                else
                                {
                                    header = header.Replace(key, new FileInfo(sourceFile).LastWriteTime.ToString("dd/MM/yyyy"));
                                }
                                break;

                            case AutoFields.CREATION_DATE:
                                if (replaceableField.Value != "You can provide a format date here")
                                {
                                    header = header.Replace(key, new FileInfo(sourceFile).CreationTime.ToString(replaceableField.Value));
                                }
                                else
                                {
                                    header = header.Replace(key, new FileInfo(sourceFile).CreationTime.ToString("dd/MM/yyyy"));
                                }
                                break;

                            case AutoFields.CURRENT_DATE:
                                if (replaceableField.Value != "You can provide a format date here")
                                {
                                    header = header.Replace(key, DateTime.Now.ToString(replaceableField.Value));
                                }
                                else
                                {
                                    header = header.Replace(key, DateTime.Now.ToShortDateString());
                                }
                                break;

                            case AutoFields.CURRENT_YEAR:
                                header = header.Replace(key, DateTime.Now.Year.ToString());
                                break;

                            case AutoFields.PROJECT:
                                header = header.Replace(key, GetFileName(sourceFile, "*proj"));
                                break;

                            case AutoFields.SOLUTION:
                                header = header.Replace(key, GetFileName(sourceFile, "*.sln"));
                                break;

                            case AutoFields.NAMESPACE:
                                header = header.Replace(key, GetNamespace(sourceFile));
                                break;

                            case AutoFields.INHERIT:
                                header = header.Replace(key, GetInherit(sourceFile));
                                break;

                            case AutoFields.IMPLEMENT:
                                header = header.Replace(key, GetImplements(sourceFile));
                                break;

                            case AutoFields.SUMMARY:
                                header = header.Replace(key, GetSummary(sourceFile));
                                break;

                            default:
                                Status[sourceFile].Add("Invalid Auto Field");
                                return false;
                        }

                        FileContent = String.Empty;
                    }
                    else
                    {
                        Status[sourceFile].Add("Invalid Auto Field");
                        return false;
                    }
                }
                else
                {
                    header = header.Replace(key, replaceableField.Value);
                }
            }

            return true;
        }

        /// <summary>
        /// http://www.personalmicrocosms.com/Pages/dotnettips.aspx?c=15&t=17
        /// </summary>
        /// <param name="fileName"></param>
        /// <returns></returns>
        private static Encoding GetFileEncoding(string fileName) // Return the Encoding of a text file.  Return Encoding.Default if no Unicode
        {
            Encoding result = null;

            FileInfo fi = new FileInfo(fileName);

            FileStream fs = null;

            try
            {
                fs = fi.OpenRead();

                Encoding[] unicodeEncodings = { Encoding.BigEndianUnicode, Encoding.Unicode, Encoding.UTF8 };

                for (int i = 0; result == null && i < unicodeEncodings.Length; i++)
                {
                    fs.Position = 0;

                    byte[] preamble = unicodeEncodings[i].GetPreamble();

                    bool preamblesAreEqual = true;

                    for (int j = 0; preamblesAreEqual && j < preamble.Length; j++)
                    {
                        preamblesAreEqual = preamble[j] == fs.ReadByte();
                    }

                    if (preamblesAreEqual)
                    {
                        result = unicodeEncodings[i];
                    }
                }
            }
            catch (IOException) { }
            finally
            {
                if (fs != null)
                {
                    fs.Close();
                }
            }

            if (result == null)
            {
                result = Encoding.Default;
            }

            return result;
        }

        private void RaiseOnStatusChanged(string fileName,
                                          ProcessingStatusEventArgs.ProcessingStatus status,
                                          Exception exception)
        {
            if (OnStatusChanged != null)
            {
                OnStatusChanged(this, new ProcessingStatusEventArgs(fileName, status, exception));
            }
        }

        #endregion
    }
}
