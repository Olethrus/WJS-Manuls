﻿/*  ----------------------------------------------------------------------------
 *  CSharp Code Header Designer -  (http://colbyafrica.blogspot.com)
 *  ----------------------------------------------------------------------------
 *  Author: Colby Africa
 *  ----------------------------------------------------------------------------
 *  http://code.msdn.microsoft.com/HeaderDesigner/Project/License.aspx
 *  ----------------------------------------------------------------------------
 *  Header Created With CSharp Code Header Designer
 */
using System;

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner
{
    /// <summary>
    /// Implements an event handler argument for communicating
    /// header application processing messages
    /// </summary>
    public class ProcessingStatusEventArgs : EventArgs
    {
        public enum ProcessingStatus
        {
            None,
            Error,
            Sucess,
            Cancelled,
            BeginProcessing,
            BeginProcessingFile,
            ReadSvn,
            ProcessingFields,
            WritingFile,
            EndProcessingFile,
            EndPocessing
        }

        public Exception Exception { get; private set; }
        public string FileName { get; private set; }
        public ProcessingStatus Status { get; private set; }

        public ProcessingStatusEventArgs(string fileName,
                                         ProcessingStatus status,
                                         Exception exception)
        {
            FileName = fileName;
            Status = status;
            Exception = exception;
        }
    }
}
