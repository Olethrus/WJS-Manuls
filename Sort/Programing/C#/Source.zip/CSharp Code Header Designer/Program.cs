﻿/*  ----------------------------------------------------------------------------
 *  CSharp Code Header Designer -  (http://colbyafrica.blogspot.com)
 *  ----------------------------------------------------------------------------
 *  Author: Colby Africa
 *  ----------------------------------------------------------------------------
 *  http://code.msdn.microsoft.com/HeaderDesigner/Project/License.aspx
 *  ----------------------------------------------------------------------------
 *  Header Created With CSharp Code Header Designer
 */
using System;
using System.Windows.Forms;
using ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner.Forms;

namespace ColbyAfrica.Public.Projects.CSharpCodeHeaderDesigner
{
    /// <summary>
    /// Implements CSharp Code Header Designer
    /// </summary>
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        private static void Main(params String[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            if (args.Length == 1)
            {
                Application.Run(new MainForm(args[0]));
            }
            else
            {
                Application.Run(new MainForm());
            }
        }
    }
}
