﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace Attachments
{
    using System;
    using System.Reflection;
    using System.Windows.Forms;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.TeamFoundation.WorkItemTracking.Client;

    /// <summary>
    /// Illustrates how to create a new work item and add a file attachment to it
    /// </summary>
    class Program
    {
        #region Methods

        /// <summary>
        /// Entry point for this sample
        /// </summary>
        static void Main(string[] args)
        {
            // get the Uri to the project collection to use
            var collectionUri = Common.Helper.GetCollectionUri(args);

            try
            {
                // get the work item store from the TeamFoundationServer
                Console.WriteLine("Connecting to {0}...", collectionUri);

                // get a reference to the team project collection
                using (var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri))
                {
                    // get a reference to the work item tracking service
                    var workItemStore = projectCollection.GetService<WorkItemStore>();

                    if (workItemStore.Projects.Count <= 0)
                    {
                        throw new ApplicationException("There are no projects in this server");
                    }

                    // get a reference to the list of work item types defined for the first team project
                    var workItemTypes = workItemStore.Projects[0].WorkItemTypes;

                    if (workItemTypes.Count <= 0)
                    {
                        throw new ApplicationException("There are no work item types in this project");
                    }

                    // create a new work item
                    var workItem = new WorkItem(workItemTypes[0])
                                       {
                                           Title = String.Format("Created by {0} sample",
                                                                 Assembly.GetExecutingAssembly().GetName().Name)
                                       };

                    Console.WriteLine("Created a new {0} work item in team project {1}",
                        workItem.Type.Name, workItem.Project.Name);

                    // add an event handler to handle changes to fields
                    workItem.FieldChanged += OnFieldChanged;

                    // setup an open file dialog
                    var openFileDialog = new OpenFileDialog
                                             {
                                                 InitialDirectory =
                                                     Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments),
                                                 Multiselect = false,
                                                 Title = "Select a file to attach"
                                             };

                    // prompt the user to select a file to attach to the work item
                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        var attachment = new Attachment(openFileDialog.FileName);
                        workItem.Attachments.Add(attachment);

                        Console.WriteLine("Attached {0} to {1}", attachment.Name, workItem.Type.Name);

                        workItem.Save();
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        /// <summary>
        /// Called when a field is changed on a work item
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The <see cref="Microsoft.TeamFoundation.WorkItemTracking.Client.WorkItemEventArgs"/> instance containing the event data.</param>
        private static void OnFieldChanged(object sender, WorkItemEventArgs e)
        {
            if (e.Field != null)
            {
                Console.WriteLine("Field '{0}' is changed to '{1}'", e.Field.Name, e.Field.Value);
            }
        }

        #endregion Methods
    }
}