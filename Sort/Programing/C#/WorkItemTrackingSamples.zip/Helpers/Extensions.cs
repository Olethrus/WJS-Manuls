﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace Common
{
    using System;

    using Microsoft.TeamFoundation.WorkItemTracking.Client;

    public static class Extensions
    {
        #region Methods

        public static bool IsDisplayable(this Field field, int revision)
        {
            if (field.FieldDefinition == null) return false;

            switch ((CoreField)field.Id)
            {
                case CoreField.History:
                case CoreField.ChangedDate:
                case CoreField.RevisedDate:
                case CoreField.ChangedBy:
                case CoreField.AuthorizedAs:
                    return false;

                default:
                    break;
            }

            if (revision == 0)
            {
                if (field.Value == null ||
                   Equals(field.Value, String.Empty) ||
                   Equals(field.Value, 0)) return false;
            }

            return true;
        }

        #endregion Methods
    }
}