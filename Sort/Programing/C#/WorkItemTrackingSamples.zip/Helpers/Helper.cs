﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace Common
{
    using System;

    public static class Helper
    {
        #region Methods

        public static Uri GetCollectionUri(string[] args)
        {
            String collectionUri;
            
            if ((args.Length > 0) && (!String.IsNullOrEmpty(args[0])) && 
                Uri.IsWellFormedUriString(args[0], UriKind.Absolute))
            {
                collectionUri = args[0];               
            }
            else
            {
                collectionUri = Environment.GetEnvironmentVariable("TFS_COLLECTION_URI");
            }

            while (String.IsNullOrEmpty(collectionUri))
            {
                Console.WriteLine(
                    "Please enter your TFS Team Project Collection URI,\n" +
                    "or you can set it in TFS_COLLECTION_URI environment variable:");

                collectionUri = Console.ReadLine();

                if (!Uri.IsWellFormedUriString(collectionUri, UriKind.Absolute))
                {
                    collectionUri = null;
                }
            }

            return new Uri(collectionUri);
        }

        #endregion Methods
    }
}