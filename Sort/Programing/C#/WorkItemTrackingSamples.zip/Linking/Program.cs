﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace Linking
{
    using System;
    using System.Reflection;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.TeamFoundation.WorkItemTracking.Client;

    class Program
    {
        #region Methods

        static void Main(string[] args)
        {
            // get the Uri to the project collection to use
            var collectionUri = Common.Helper.GetCollectionUri(args);

            try
            {
                // get the work item store from the TeamFoundationServer
                Console.WriteLine("Connecting to {0}...", collectionUri);

                // get a reference to the team project collection
                using (var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri))
                {
                    // get a reference to the work item tracking service
                    var workItemStore = projectCollection.GetService<WorkItemStore>();

                    if (workItemStore.Projects.Count <= 0)
                    {
                        throw new ApplicationException("There are no projects in this server");
                    }

                    // get a reference to the list of work item types defined for the first team project
                    var workItemTypes = workItemStore.Projects[0].WorkItemTypes;

                    if (workItemTypes.Count <= 0)
                    {
                        throw new ApplicationException("There are no work item types in this project");
                    }

                    // create a new work item
                    var workItem = new WorkItem(workItemTypes[0])
                                       {
                                           Title = String.Format("Created by {0} sample",
                                                                 Assembly.GetExecutingAssembly().GetName().Name)
                                       };

                    Console.WriteLine("Created a new {0} work item in team project {1}",
                        workItem.Type.Name, workItem.Project.Name);

                    // Add Hyperlink
                    var hyperLink = new Hyperlink("http://www.microsoft.com") { Comment = "Microsoft Web Location" };
                    workItem.Links.Add(hyperLink);

                    Console.WriteLine("Added hyperlink ({0})", hyperLink.Location);

                    // Create a WorkItem to link to
                    var linkWorkItem = new WorkItem(workItemTypes[0]) { Title = "Created by Linking Sample" };
                    linkWorkItem.Save();

                    // Add Child Link
                    var linkTypeEnd = workItemStore.WorkItemLinkTypes[CoreLinkTypeReferenceNames.Hierarchy].ForwardEnd;
                    var childLink = new WorkItemLink(linkTypeEnd, workItem.Id, linkWorkItem.Id);
                    workItem.Links.Add(childLink);

                    Console.WriteLine("Added {0} #{1} as child of {2} #{3}",
                                      linkWorkItem.Type.Name, linkWorkItem.Id,
                                      workItem.Type.Name, workItem.Id);

                    // Add Related Link
                    var relatedLink = new RelatedLink(linkWorkItem.Id);
                    workItem.Links.Add(relatedLink);

                    Console.WriteLine("Added {0} #{1} as related to {2} #{3}",
                                      linkWorkItem.Type.Name, linkWorkItem.Id,
                                      workItem.Type.Name, workItem.Id);

                    // Add Artifact Link
                    var externalLink = new ExternalLink(
                        workItem.Store.RegisteredLinkTypes[0],
                        "http://www.microsoft.com/") { Comment = "Artifact links are cool." };

                    workItem.Links.Add(externalLink);
                    Console.WriteLine("Added artifact link {0} - {1}\n",
                                      externalLink.ArtifactLinkType.Name,
                                      externalLink.LinkedArtifactUri);

                    // Save WorkItem
                    workItem.Save();

                    Console.WriteLine("Created work item: {0}", workItem.Id);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        #endregion Methods
    }
}