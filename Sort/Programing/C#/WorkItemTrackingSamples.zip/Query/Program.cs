﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace Query
{
    using System;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.TeamFoundation.WorkItemTracking.Client;

    class Program
    {
        #region Methods

        static void Main(string[] args)
        {
            // get the Uri to the project collection to use
            var collectionUri = Common.Helper.GetCollectionUri(args);

            try
            {
                // get the work item store from the TeamFoundationServer
                Console.WriteLine("Connecting to {0}...", collectionUri);

                // get a reference to the team project collection
                using (var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri))
                {
                    // get a reference to the work item tracking service
                    var workItemStore = projectCollection.GetService<WorkItemStore>();

                    const string wiqlQuery = "Select ID, Title from Issue where (State = 'Active') order by Title";

                    // execute the query and retrieve a collection of workitems
                    var workItems = workItemStore.Query(wiqlQuery);

                    // write out the heading
                    Console.WriteLine("Query: {0}\n\n{1}\t{2}", wiqlQuery, "Id", "Title");

                    // output the results of the query
                    foreach (WorkItem workItem in workItems)
                    {
                        Console.WriteLine("{0}\t{1}", workItem.Id, workItem.Title);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        #endregion Methods
    }
}