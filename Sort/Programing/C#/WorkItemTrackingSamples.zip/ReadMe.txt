Work item object model sample applications

These sample applications demonstrate how to use Microsoft Visual Studio 2005 
Team Foundation Server's work item tracking object model.

GOALS
- Shows how to build console applications to work with workitems without invoking the IDE.
- Shows how to use attachment, linking, and query operations.
- Shows how to create and edit work items.
- Shows how to create custom work item types.
