﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace StoredQuery
{
    class Program
    {
        #region Methods

        static void Main(string[] args)
        {
            // get the Uri to the project collection to use
            var collectionUri = Common.Helper.GetCollectionUri(args);

            try
            {
                // get the work item store from the TeamFoundationServer
                Console.WriteLine("Connecting to {0}...", collectionUri);

                // get a reference to the team project collection
                using (var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri))
                {
                    // get a reference to the work item tracking service
                    var workItemStore = projectCollection.GetService<WorkItemStore>();

                    if (workItemStore.Projects.Count <= 0)
                    {
                        throw new ApplicationException("There are no projects in this server");
                    }

                    var projectWithQueries =
                        workItemStore.Projects.Cast<Project>().Where(project => project.QueryHierarchy.Count > 0).First();

                    if (projectWithQueries == null)
                    {
                        throw new ApplicationException("There are no projects with stored queries");
                    }

                    var choices = new List<QueryItem>();
                    RenderQueryMenu(projectWithQueries.QueryHierarchy, ref choices);

                    Int32 selectedIndex = -1;

                    while ((selectedIndex < 1) || (selectedIndex > choices.Count))
                    {
                        Console.Write("Which query do you want to run? ");
                        if (!Int32.TryParse(Console.ReadLine(), out selectedIndex)) continue;
                    }

                    var queryToRun = choices[selectedIndex] as QueryDefinition;
                    Debug.Assert(queryToRun != null);

                    var workItems = workItemStore.Query(queryToRun.QueryText,
                        new Hashtable { { "project", projectWithQueries.Name } });

                    foreach (FieldDefinition fieldDefinition in workItems.Query.DisplayFieldList)
                    {
                        Console.Write("{0}\t", fieldDefinition.Name);
                    }

                    foreach (WorkItem workItem in workItems)
                    {
                        foreach (FieldDefinition fieldDefinition in workItems.Query.DisplayFieldList)
                        {
                            Console.Write("{0}\t", workItem[fieldDefinition.Name]);
                        }

                        Console.WriteLine(String.Empty);
                    }

                    Console.WriteLine("{0} items found", workItems.Count);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        static void RenderQueryMenu(IEnumerable<QueryItem> queries, ref List<QueryItem> choices, int depth = 0)
        {
            foreach (var queryItem in queries)
            {
                for (int i = 0; i < depth; i++) Console.Write("\t");

                if (queryItem is QueryFolder)
                {
                    Console.WriteLine("> {0}", queryItem.Name);
                    RenderQueryMenu(queryItem as QueryFolder, ref choices, depth + 1);
                }
                else
                {
                    choices.Add(queryItem);
                    Console.WriteLine("{0}: {1}", choices.Count, queryItem.Name);
                }
            }
        }

        #endregion Methods
    }
}