﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace WorkItemEdit
{
    using System;
    using System.Linq;
    using System.Reflection;

    using Common;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.TeamFoundation.WorkItemTracking.Client;

    class WorkItemEdit
    {
        #region Methods

        static void Main(string[] args)
        {
            // get the Uri to the project collection to use
            var collectionUri = Helper.GetCollectionUri(args);

            try
            {
                // get the work item store from the TeamFoundationServer
                Console.WriteLine("Connecting to {0}...", collectionUri);

                // get a reference to the team project collection
                using (var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri))
                {
                    // get a reference to the work item tracking service
                    var workItemStore = projectCollection.GetService<WorkItemStore>();

                    if (workItemStore.Projects.Count <= 0)
                    {
                        throw new ApplicationException("There are no projects in this server");
                    }

                    // get a reference to the list of work item types defined for the first team project
                    var workItemTypes = workItemStore.Projects[0].WorkItemTypes;

                    if (workItemTypes.Count <= 0)
                    {
                        throw new ApplicationException("There are no work item types in this project");
                    }

                    // create a new work item
                    var workItem = new WorkItem(workItemTypes[0])
                                       {
                                           Title = String.Format("Created by {0} sample",
                                                                 Assembly.GetExecutingAssembly().GetName().Name)
                                       };

                    Console.WriteLine("Created a new {0} work item in team project {1}",
                                      workItem.Type.Name, workItem.Project.Name);

                    // edit the work item
                    workItem.Open();
                    workItem.Title = String.Format("Edited {0}", DateTime.Now);

                    // make sure all the fields are valid before saving
                    if (workItem.Fields.Cast<Field>().Where(field => !field.IsValid).Any())
                    {
                        throw new ApplicationException("There are invalid field values");
                    }

                    // save the edited work item
                    workItem.Save();
                    Console.WriteLine("Work Item #{0} successfully updated", workItem.Id);

                    var changedFields = workItem.Revisions[workItem.Revision].Fields.Cast<Field>().Where(
                        field => !Equals(field.Value, field.OriginalValue) &&
                                 field.IsDisplayable(workItem.Revision));

                    foreach (var field in changedFields)
                    {
                        if (field.OriginalValue == null)
                        {
                            Console.WriteLine("{0}: {1}", field.Name, field.Value);
                        }
                        else
                        {
                            Console.WriteLine("{0}: {1} -> {2}", field.Name, field.OriginalValue, field.Value);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        #endregion Methods
    }
}