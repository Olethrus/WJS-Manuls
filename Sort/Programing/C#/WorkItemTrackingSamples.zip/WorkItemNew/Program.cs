﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

namespace WorkItemNew
{
    using System;
    using System.Linq;
    using System.Reflection;

    using Microsoft.TeamFoundation.Client;
    using Microsoft.TeamFoundation.WorkItemTracking.Client;

    class WorkItemNew
    {
        #region Methods

        static void Main(string[] args)
        {
            // get the Uri to the project collection to use
            var collectionUri = Common.Helper.GetCollectionUri(args);

            try
            {
                // get the work item store from the TeamFoundationServer
                Console.WriteLine("Connecting to {0}...", collectionUri);

                // get a reference to the team project collection
                using (var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri))
                {
                    // get a reference to the work item tracking service
                    var workItemStore = projectCollection.GetService<WorkItemStore>();

                    if (workItemStore.Projects.Count <= 0)
                    {
                        throw new ApplicationException("There are no projects in this server");
                    }

                    // get a reference to the list of work item types defined for the first team project
                    var workItemTypes = workItemStore.Projects[0].WorkItemTypes;

                    if (workItemTypes.Count <= 0)
                    {
                        throw new ApplicationException("There are no work item types in this project");
                    }

                    // create a new work item
                    var workItem = new WorkItem(workItemTypes["bug"])
                                       {
                                           Title = String.Format("Created by {0} sample",
                                                                 Assembly.GetExecutingAssembly().GetName().Name)
                                       };

                    Console.WriteLine("Created a new {0} work item in team project {1}",
                                      workItem.Type.Name, workItem.Project.Name);

                    foreach (var field in workItem.Fields.Cast<Field>().Where(field => !field.IsValid))
                    {
                        Console.WriteLine("Invalid field '{0}': {1}", field.Name, field.Status);
                        Console.WriteLine("Current value: '{0}'\n", field.Value);
                    }

                    if (workItem.Fields.Cast<Field>().Where(field => !field.IsValid).Any())
                    {
                        throw new ApplicationException("There are invalid field values");
                    }

                    workItem.Save();
                    Console.WriteLine("Work item #{0} successfully created", workItem.Id);

                    // transition work item to the next state (given an action)
                    workItem.State = workItem.GetNextState("Microsoft.VSTS.Actions.Checkin");
                    workItem.Save();
                    Console.WriteLine("Transitioned work item #{0} to {1}", workItem.Id, workItem.State);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        #endregion Methods
    }
}