﻿#region Header

/***************************************************************************

Copyright (c) Microsoft Corporation. All rights reserved.
This code is licensed under the Visual Studio SDK license terms.
THIS CODE IS PROVIDED *AS IS* WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING ANY
IMPLIED WARRANTIES OF FITNESS FOR A PARTICULAR
PURPOSE, MERCHANTABILITY, OR NON-INFRINGEMENT.

***************************************************************************/

#endregion Header

using System;
using Microsoft.TeamFoundation.Client;
using Microsoft.TeamFoundation.WorkItemTracking.Client;

namespace WorkItemType
{
    class WorkItemTypes
    {
        #region Methods

        static void Main(string[] args)
        {
            // get the Uri to the project collection to use
            var collectionUri = Common.Helper.GetCollectionUri(args);

            try
            {
                // get the work item store from the TeamFoundationServer
                Console.WriteLine("Connecting to {0}...", collectionUri);

                // get a reference to the team project collection
                using (var projectCollection = TfsTeamProjectCollectionFactory.GetTeamProjectCollection(collectionUri))
                {
                    // get a reference to the work item tracking service
                    var workItemStore = projectCollection.GetService<WorkItemStore>();

                    foreach (Project project in workItemStore.Projects)
                    {
                        Console.WriteLine("Project: {0}", project.Name);

                        foreach (Microsoft.TeamFoundation.WorkItemTracking.Client.WorkItemType workItemType in project.WorkItemTypes)
                        {
                            // display all the field names and Ids for this work item type
                            Console.WriteLine("\t{0} Fields:", workItemType.Name);

                            foreach (FieldDefinition fieldDefinition in workItemType.FieldDefinitions)
                            {
                                Console.WriteLine("\t\t{0, -10}{1}", fieldDefinition.Id, fieldDefinition.Name);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        #endregion Methods
    }
}