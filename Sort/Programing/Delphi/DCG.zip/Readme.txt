Delphi Compiler Generator (DCG)

This archive contains the sources of the Delphi Compiler Generator and its associated support files and components. Although the entire project is only in an early beta state I have created this archive to satisfy those many requests for sending the sources to interested people. You might subscribe to the DCG mailing list (see link on my homepage) to receive help for DCG and to keep in touch with other users as well as me.


LICENSE AGREEMENT

The project is published as freeware for non-commercial use and can be used by everyone under the following conditions:

     1) I'm given proper credit for my work.
     2) You do not claim that DCG is written by you.
     3) You do not use the project in commercial software (including shareware).
     4) If the software is modified, any software containing modifications must prominently state in the modified product 
        or documentation (i) that it has been modified, (ii) the identity of the person or entity that made the modifications, 
        and (iii) the date the modifications were made.
     5) DCG may not be transferred to any third party unless such third party receives a copy of this agreement 
        and agrees to be bound by all of its terms and conditions.


DISCLAIMER

This product and the accompanying files and documentation are distributes "as is" and without warranties 
as to performance or merchantability or any other warranties whether expressed or implied. The user assumes the
entire risk as to the use of this product. The author does not assume liability for the use of this product. In no event will 
the author be liable for additional direct or indirect damages including any lost profits, lost savings, or 
other incidental or consequential damages arising from any defects, or the use or inability to use this product, 
even if the author has been advised of the possibility of such damages.

Dipl. Ing. Mike Lischke

www.lischke-online.de
public@lischke-online.de