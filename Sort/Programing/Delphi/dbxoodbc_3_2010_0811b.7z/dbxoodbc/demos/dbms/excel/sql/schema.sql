SELECT * FROM `customer$`'
SELECT 'F' as F0, c.* FROM `customer$`c

CREATE TABLE SHEET_NNN (`FLD_ID` INTEGER, `FLD_NAME` TEXT)

create table table_1 (ID string)
create table table_1 (ID varchar)

select * from Sheet1
