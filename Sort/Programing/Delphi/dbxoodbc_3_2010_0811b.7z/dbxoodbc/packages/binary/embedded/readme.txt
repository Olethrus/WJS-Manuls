Package with contained of dbxoodbc inwardly.

This must allow to track the reason of errors in IDE.
In IDE must be installed handler of the exceptions (in old IDE oho no: D6,D7.)

Packages is compiled with option: -D_DEBUG_;_EMBEDDED_DBXOODBC_
