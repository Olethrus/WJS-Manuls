Jan 13, 2002

*** Tcl Scripting Language Components for Borland's Delphi(tm) 32 bit RADical Tools ***
---------------------------------------------------------------------------------------
Providing Scripting Solutions Is A Snap!
  - Tcl Scripting Language Components (Tslc) provide seemless integration of the
    Tcl engine into your applications.

  - The Tslc visual components bind into the Tcl engine enabling the perfect blend
    of interpreted and machine code.

  - Tool Command Language (Tcl) scripting is intuitive, effective, and efficient; an
    established and well designed interpreted language writtenby John K. Ousterhout. 

  - Tslc will jump-start scripting solutions into your development projects. You'll
    have the tools that will help you serve your customers better.


Used extensively for in-house development and data processing. Deployed in numerous
business applicationsThis distribution has the binaries for D2, D3, and D4 

---------------------------------------------------------------------------------------

Ok, promo over. This distribution is somewhat old. There's no support for D5 and
D6; however, with a few fix-ups and may work out just fine. Eventually, I'll get
around to rev'ing the source. The source is built around Tcl v8.0p2. I included
the Tcl/Tk binaries to offset complaints about my to coming to terms with the fact
that software development didn't end in 1997. Send me a heads-up if there's
something you think I should know about D5, D6, or Kylix. <-- That's gonna be fun.

So here it is. This is my contribution to the Open Source world which has been 
more than friendly to me. I'm a believer in commercial success. So, those of
you concerned about having to pay me a nickel - don't worry about. Just include
the appropriate info as stipulated in the LGPL (see license.txt). 

Short list of notes, hints, and tips...

- My final tests were done using D4.
- Open, build, and install TslcPkg.dpk then install ext/TslxPkg.dpk
- Locate and build the ScriptPad project (Pardon the UI)
- Do some basic Tcl stuff for simple verification
- From within the ScriptPad, open demos/tkbde.tcl,
   - Hit <evaluate> and you should get a mix of Tk and BDE.
   - The demo requires the DBDEMOS alias (demo matl from a Delphi install)
     If it can't detect the alias, it will attempt to create one referring
     to sample data located in a sub directory. 
- Some demos effect the Tcl engine state in a way unfavorable to other demos.
  Simply restart the ScriptPad.
- The ScriptPad demo utilizes most of the components in the Tslc dist. So tear
  it apart, mock my code, twist it, turn it, do what ya' gotta do to get things
  working for you. Generally, I was pretty clean, though litely commented, on most
  of the code. The ScriptPad, though, served as an incremental test platform which
  got abused and a little over preprocessed - yeah, it's baked.
- The ScriptPad demo has all the Tcl utility script (init.tcl,...) resourced into
  it's exe via uTslcLib.pas. This is really cool for deployment. You don't need to
  install a Tcl dist to get all the required files in place; however, you'll need
  the binaries located in this distributions bin directory if they aren't already
  on the target machine. Try not to delete TslcLibs.RES. It contains the *.tcl.
- Check out library/tix4.1/vtcl_tix.tcl. This demonstrates the layout tool by Stewart
  Allen and the Tix components by the Tix Project Group. Other installations of Tcl 
  may prevent this demo from working (version conflicts). Isolate your installations
  if necessary. I simply renamed one of my newer Tcl installations to coerce the Tcl
  engine to notice the tix4180.dll shipped with this dist. 
- TslcLibs.tcl in the dev directory includes the following comments:
  #	Creates compressed files with hashed file names for resourcing
  #	into binary executable. Generates complimentary rc file for
  #	processing by a resource compiler. The res file can then be linked
  #	into exe or dll eliminating the need for script files to be located
  #	in file system.
- There's support for IDE integration; however, I haven't tested it in a while. Open
  the IDEPkg.dpk. Next, open ext/TslcPad.pas and modify the proprocessor statements for an
  IDE build. Basically, comment out {$DEFINE TSLC_NORMAL}  and uncomment {$DEFINE TSLC_IDE}.
  Rebuild the package and install. Look under the Edit menu and you should see a Script 
  menu item. Navigate to the ScriptPad and open library/ide1.0/delphi32.tcl. If all goes
  well, you'll get a Favorites list (it's a TK window.) Look again under the Edit->Script 
  menu item and you should see newly registered Macros. Not everything's working. The
  IDE extensions were built in the D3 environment - so it's a bit rusty. BTW, there were issues
  when putting the needed preprocessor statements in the project DEFINE area. Not sure why.
  Remember to re-comment {$DEFINE TSLC_IDE} and uncomment {$DEFINE TSLC_NORMAL} when you're
  done since I noticed I spend more time on the ScriptPad project than on the IDEPkg.dpk.
  ****  REMOVE THE IDE PACKAGE IF YOU'RE EXPERIENCING PROBLEMS WITH NORMAL PROJECTS. ****
- Use the _clean.bat batch file to clean out stale object files.
- Tcl v8.0p2 binaries located in the bin subdirectory. 
- The help subdirectory has RTFs and a HPJ project for generating help.

That's all for now - Good Luck!
William Byrne
WilliamB@ByrneLitho.com


Borland, Borland Delphi are registered trademarks of Inprise Corporation. 
