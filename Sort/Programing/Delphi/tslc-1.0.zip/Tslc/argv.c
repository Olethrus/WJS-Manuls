
char * __export ArgvItem(char **argv, int idx) {
	return argv[idx];
}

char * __export AssignArgvItem( char **argv, int idx, char *ptr ) {
	return ( argv[idx] = ptr );
}