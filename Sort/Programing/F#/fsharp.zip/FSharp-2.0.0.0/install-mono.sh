#!/bin/sh
# This script is for use with CLIs on Unix, e.g. Mono

if [ -e mono.snk ]; then
  # A mono.snk exists so re-sign FSharp.Core.dll and GAC install
  echo -- Resigning FSharp.Core.dll with mono.snk
  sn -q -R bin/FSharp.Core.dll mono.snk
else
  # Advise on the options for making the DLLs locatable on Mono.
  echo "In order to add FSharp.Core.dll to the Mono GAC the DLL needs to be"
  echo "re-signed with the mono.snk key. The mono.snk key is available from"
  echo "the 'Mono Sources'."
  echo ""
  echo "  http://www.mono-project.com/"
  echo "  http://anonsvn.mono-project.com/source/trunk/mcs/class/mono.snk" 
  echo ""
  echo "To proceed with a Mono GAC install, obtain mono.snk, put it in the"
  echo "current directory and re-run this script."
  echo ""
  echo "An alternative to installing the DLLs in the Mono GAC is to add the"
  echo "FSharp bin directory to the MONO_PATH variable. For more information"
  echo "on 'How Mono Finds Assemblies' see http://www.mono-project.com/Gacutil"
  exit 0
fi

# GAC installing FSharp DLLs
echo -- Installing FSharp DLLS into the GAC
gacutil -i bin/FSharp.Core.dll

# On some linux systems, these can be run directly
chmod ugo+rx bin/fsc.exe
chmod ugo+rx bin/fsi.exe

# Trying to use --aot on Mono does not seem to work correctly,
# at least on the pre-release of Mono 2.0.
# On Un*x, it seems to work in the sense that it creates the
# .so files, but then fsi.exe does not seem to work at all.
# On Windows, it just does not work.
# For this reason, it does not seem to be advisable to try to
# use it.
#mono --aot bin/FSharp.Core.dll
#mono --aot bin/FSharp.Compiler.dll
#mono --aot bin/fsc.exe
#mono --aot bin/fsi.exe
