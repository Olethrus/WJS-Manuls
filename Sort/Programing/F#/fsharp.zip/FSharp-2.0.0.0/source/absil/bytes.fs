// (c) Microsoft Corporation 2005-2009.

/// Byte arrays
namespace Microsoft.FSharp.Compiler.AbstractIL.Internal

open System.IO
open Internal.Utilities

open Microsoft.FSharp.Compiler.AbstractIL 
open Microsoft.FSharp.Compiler.AbstractIL.Internal 

module internal Bytes = 
    let b0 n =  (n &&& 0xFF)
    let b1 n =  ((n >>> 8) &&& 0xFF)
    let b2 n =  ((n >>> 16) &&& 0xFF)
    let b3 n =  ((n >>> 24) &&& 0xFF)

    let dWw1 n = int32 ((n >>> 32) &&& 0xFFFFFFFFL)
    let dWw0 n = int32 (n          &&& 0xFFFFFFFFL)

    let length (b:byte[]) = Array.length b
    let get (b:byte[]) n = int32 (Array.get b n)  
    let make (f : _ -> int) n = Array.init n (fun i -> byte (f i))  
    let zeroCreate n : byte[] = Array.zeroCreate n      

    let really_input_impl (br:BinaryReader) (buf: byte[]) (len: int) = 
        let mutable n = 0 
        let mutable i = 1 
        while (i > 0 && n < len) do 
            i <- br.Read(buf,n,len-n)
            n <- n + i
        // endloop when either (a) i<=0   (i.e. i=0)   -- did not read any bytes
        //                  or (b) n>=len (i.e. n=len) -- read enough bytes
        assert(n=len)
        if n <> len then failwithf "Bytes.really_input: failed to read enough bytes. Required %d bytes. Read %d bytes. BaseStream.Position=%d" len n br.BaseStream.Position

    let really_input (is:BinaryReader) n =
        let buff = Array.create n 0uy 
        really_input_impl is buff n;
        buff

    let maybe_input (br:BinaryReader) n =
        let buff = Array.create n 0uy 
        let x = br.Read(buff,0,n)
        if x = n then buff else Array.sub buff 0 x

    let output (bw:BinaryWriter) (b:byte[]) =
        bw.Write(b,0,Array.length b) 
      
    let sub ( b:byte[]) s l = Array.sub b s l   
    let set bb n (b:int32) = Array.set bb n (byte b) 
    let blit (a:byte[]) b c d e = Array.blit a b c d e 
    let string_as_unicode_bytes (s:string) = System.Text.Encoding.Unicode.GetBytes s 
    let utf8_bytes_as_string (b:byte[]) = System.Text.Encoding.UTF8.GetString b 
    let unicode_bytes_as_string (b:byte[]) = System.Text.Encoding.Unicode.GetString b 
    let compare (b1:byte[]) (b2:byte[]) = compare b1 b2

    let toInt32Array (b:byte[]) =  Array.init (length b) (get b)
    let ofInt32Array (arr:int[]) = make (fun i -> arr.[i]) (Array.length arr)

    let string_as_utf8_bytes (s:string) = System.Text.Encoding.UTF8.GetBytes s  

    let append (b1: byte[]) (b2:byte[]) = Array.append b1 b2 

    let string_as_utf8_bytes_null_terminated (s:string) = 
        append (string_as_utf8_bytes s) (ofInt32Array [| 0x0 |]) 

    let string_as_unicode_bytes_null_terminated (s:string) = 
        append (string_as_unicode_bytes s) (ofInt32Array [| 0x0;0x0 |]) 

type internal ByteStream = 
    { bytes: byte[]; 
      mutable pos: int; 
      max: int }

module internal Bytestream = 

    let of_bytes b n len = 
        if n < 0 || (n+len) > Bytes.length b then failwith "Bytestream.of_bytes";
        { bytes = b; pos = n; max = n+len }

    let read_byte b  = 
        if b.pos >= b.max then failwith "Bytestream.read_byte: end of stream";
        let res = Bytes.get b.bytes b.pos
        b.pos <- b.pos + 1;
        res 
      
    let read_bytes b n  = 
        if b.pos + n > b.max then failwith "Bytestream.read_bytes: end of stream";
        let res = Bytes.sub b.bytes b.pos n
        b.pos <- b.pos + n;
        res 

    let position b = b.pos 
    let clone_and_seek b pos = { bytes=b.bytes; pos=pos; max=b.max }
    let skip b n = b.pos <- b.pos + n

    let read_utf8_bytes_as_string (b:ByteStream) n = 
        let res = System.Text.Encoding.UTF8.GetString(b.bytes,b.pos,n)  
        b.pos <- b.pos + n; res 

type internal ByteBuffer = 
    { mutable bbArray: byte[]; 
      mutable bbCurrent: int }

    member buf.Ensure newSize = 
        let oldBufSize = buf.bbArray.Length 
        if newSize > oldBufSize then 
            let old = buf.bbArray 
            buf.bbArray <- Bytes.zeroCreate (max newSize (oldBufSize * 2));
            Bytes.blit old 0 buf.bbArray 0 buf.bbCurrent;

    member buf.Close () = Bytes.sub buf.bbArray 0 buf.bbCurrent

    member buf.EmitIntAsByte (i:int) = 
        let newSize = buf.bbCurrent + 1 
        buf.Ensure newSize;
        Bytes.set buf.bbArray buf.bbCurrent i;
        buf.bbCurrent <- newSize 

    member buf.EmitByte (b:byte) = buf.EmitIntAsByte (int b)

    member buf.EmitIntsAsBytes arr = 
        let n = Array.length arr 
        let newSize = buf.bbCurrent + n 
        buf.Ensure newSize;
        let bbarr = buf.bbArray
        let bbbase = buf.bbCurrent
        for i= 0 to n - 1 do Bytes.set bbarr (bbbase + i) arr.[i] done;
        buf.bbCurrent <- newSize 

    member bb.FixupInt32 pos n = 
        Bytes.set bb.bbArray pos (Bytes.b0 n);
        Bytes.set bb.bbArray (pos + 1) (Bytes.b1 n);
        Bytes.set bb.bbArray (pos + 2) (Bytes.b2 n);
        Bytes.set bb.bbArray (pos + 3) (Bytes.b3 n);

    member buf.EmitInt32 n = 
        let newSize = buf.bbCurrent + 4 
        buf.Ensure newSize;
        buf.FixupInt32 buf.bbCurrent n;
        buf.bbCurrent <- newSize 

    member buf.EmitBytes i = 
        let n = Bytes.length i 
        let newSize = buf.bbCurrent + n 
        buf.Ensure newSize;
        Bytes.blit i 0 buf.bbArray buf.bbCurrent n;
        buf.bbCurrent <- newSize 

    member buf.EmitInt32AsUInt16 n = 
        let newSize = buf.bbCurrent + 2 
        buf.Ensure newSize;
        Bytes.set buf.bbArray buf.bbCurrent (Bytes.b0 n);
        Bytes.set buf.bbArray (buf.bbCurrent + 1) (Bytes.b1 n);
        buf.bbCurrent <- newSize 
    
    member buf.EmitBoolAsByte (b:bool) = buf.EmitIntAsByte (if b then 1 else 0)

    member buf.EmitUInt16 (x:uint16) = buf.EmitInt32AsUInt16 (int32 x)

    member buf.EmitInt64 x = 
        buf.EmitInt32 (Bytes.dWw0 x);
        buf.EmitInt32 (Bytes.dWw1 x)

    member buf.Position = buf.bbCurrent

    static member Create sz = 
        { bbArray=Bytes.zeroCreate sz; 
          bbCurrent = 0; }


