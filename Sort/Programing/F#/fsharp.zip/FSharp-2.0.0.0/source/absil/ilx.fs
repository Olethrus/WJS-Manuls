// (c) Microsoft Corporation 2005-2009. 


/// Defines an extension of the IL algebra
module internal Microsoft.FSharp.Compiler.AbstractIL.Extensions.ILX.Types



open Internal.Utilities
open Microsoft.FSharp.Compiler.AbstractIL 
open Microsoft.FSharp.Compiler.AbstractIL.Internal 
module Il = Microsoft.FSharp.Compiler.AbstractIL.IL 
module Illib = Microsoft.FSharp.Compiler.AbstractIL.Internal.Library 

open Illib
open Il

// --------------------------------------------------------------------
// Define an extension of the IL instruction algebra
// -------------------------------------------------------------------- 

type IlxUnionAlternative = 
    { altName: string;
      altFields: ILFieldDef[];
      altCustomAttrs: ILAttributes }

    member x.FieldDefs = x.altFields
    member x.FieldDef n = x.altFields.[n]
    member x.Name = x.altName
    member x.IsNullary  = (x.FieldDefs.Length = 0)
    member x.FieldTypes = List.map (fun fd -> fd.fdType) (Array.toList x.FieldDefs)

type IlxUnionHasHelpers = 
   | NoHelpers
   | AllHelpers
   | SpecialFSharpListHelpers 
   | SpecialFSharpOptionHelpers 
   
type IlxUnionRef = 
    | IlxUnionRef of ILTypeRef * IlxUnionAlternative array * bool * (* hasHelpers: *) IlxUnionHasHelpers 

type IlxUnionSpec = 
    | IlxUnionSpec of IlxUnionRef * ILGenericArgs
    member x.EnclosingType = let (IlxUnionSpec(IlxUnionRef(tref,_,_,_),inst)) = x in mk_boxed_typ tref inst
    member x.TypeRef = let (IlxUnionSpec(IlxUnionRef(tref,_,_,_),_)) = x in tref
    member x.GenericArgs = let (IlxUnionSpec(_,inst)) = x in inst
    member x.AlternativesArray = let (IlxUnionSpec(IlxUnionRef(_,alts,_,_),_)) = x in alts
    member x.IsNullPermitted = let (IlxUnionSpec(IlxUnionRef(_,_,np,_),_)) = x in np
    member x.HasHelpers = let (IlxUnionSpec(IlxUnionRef(_,_,_,b),_)) = x in b
    member x.Alternatives = Array.toList x.AlternativesArray
    member x.Alternative idx = x.AlternativesArray.[idx]

    member x.FieldDef idx fidx = x.Alternative(idx).FieldDef(fidx)


type IlxClosureLambdas = 
    | Lambdas_forall of ILGenericParameterDef * IlxClosureLambdas
    | Lambdas_lambda of ILParameter * IlxClosureLambdas
    | Lambdas_return of ILType

type IlxClosureApps = 
  | Apps_tyapp of ILType * IlxClosureApps 
  | Apps_app of ILType * IlxClosureApps 
  | Apps_done of ILType

let rec inst_apps_aux n inst = function
    Apps_tyapp (ty,rty) -> Apps_tyapp(inst_typ_aux n inst ty, inst_apps_aux n inst rty)
  | Apps_app (dty,rty) ->  Apps_app(inst_typ_aux n inst dty, inst_apps_aux n inst rty)
  | Apps_done rty ->  Apps_done(inst_typ_aux n inst rty)

let rec inst_lambdas_aux n inst = function
  | Lambdas_forall (b,rty) -> 
      Lambdas_forall(b, inst_lambdas_aux n inst rty)
  | Lambdas_lambda (p,rty) ->  
      Lambdas_lambda({ p with paramType=inst_typ_aux n inst p.paramType},inst_lambdas_aux n inst rty)
  | Lambdas_return rty ->  Lambdas_return(inst_typ_aux n inst rty)

let inst_lambdas i t = inst_lambdas_aux 0 i t

type IlxClosureFreeVar = 
    { fvName: string ; 
      fvCompilerGenerated:bool; 
      fvType: ILType }

let mk_freevar (name,compgen,ty) = 
    { fvName=name;
      fvCompilerGenerated=compgen;
      fvType=ty; }
let typ_of_freevar p = p.fvType
let name_of_freevar p = p.fvName


type IlxClosureRef = 
    | IlxClosureRef of ILTypeRef * IlxClosureLambdas * IlxClosureFreeVar list 

type IlxClosureSpec = 
    | IlxClosureSpec of IlxClosureRef * ILGenericArgs
    member x.TypeRef = let (IlxClosureRef(tref,_,_)) = x.ClosureRef in tref
    member x.ClosureRef = let (IlxClosureSpec(cloref,_)) = x in cloref 
    member x.FormalFreeVarType n = let (IlxClosureRef(_,_,fvs)) = x.ClosureRef in typ_of_freevar (List.nth fvs n)
    member x.ActualFreeVarType n = inst_typ x.GenericArgs (x.FormalFreeVarType n)
    member x.FormalFreeVars = let (IlxClosureRef(_,_,fvs)) = x.ClosureRef in fvs
    member x.ActualFreeVars = List.map (fun fv -> {fv with fvType = inst_typ x.GenericArgs fv.fvType}) x.FormalFreeVars
    member x.ActualLambdas = inst_lambdas x.GenericArgs x.FormalLambdas
    member x.FormalLambdas = let (IlxClosureRef(_,lambdas,_)) = x.ClosureRef in lambdas
    member x.GenericArgs = let (IlxClosureSpec(_,inst)) = x in inst



type IlxInstr = 
  // Discriminated unions
  | EI_lddata of (* avoidHelpers: *) bool * IlxUnionSpec * int * int
  | EI_isdata of (* avoidHelpers: *) bool * IlxUnionSpec * int
  | EI_brisdata of (* avoidHelpers: *) bool * IlxUnionSpec * int * ILCodeLabel * ILCodeLabel
  | EI_castdata of bool * IlxUnionSpec * int
  | EI_stdata of IlxUnionSpec * int * int
  | EI_datacase of (* avoidHelpers: *) bool * IlxUnionSpec * (int * ILCodeLabel) list * ILCodeLabel (* last label is fallthrough *)
  | EI_lddatatag of (* avoidHelpers: *) bool * IlxUnionSpec
  | EI_newdata of IlxUnionSpec * int
  
  // Closures
  | EI_newclo of IlxClosureSpec
  | EI_castclo of IlxClosureSpec
  | EI_isclo of IlxClosureSpec
  | EI_callclo of Tailcall * IlxClosureSpec * IlxClosureApps
  | EI_stclofld  of (IlxClosureSpec * int)  (* nb. leave these brackets *)
  | EI_stenv  of int
  | EI_ldenv  of int
  | EI_ldenva  of int
  | EI_callfunc of Tailcall * IlxClosureApps
#if CLOSURES_VIA_POINTERS
  | EI_ldftn_then_call of ILMethodSpec * (Tailcall * ILMethodSpec * varargs)  (* special: for internal use only *)
  | EI_ld_instance_ftn_then_newobj of ILMethodSpec * ILCallingSignature * (ILMethodSpec * varargs)  (* special: for internal use only *)
#endif

let destinations_of_IlxInstr i =
  match i with 
  |  (EI_brisdata (_,_,_,l1,l2)) ->  [l1; l2]
  |  (EI_callfunc (Tailcall,_)) |  (EI_callclo (Tailcall,_,_)) ->   []
  |  (EI_datacase (_,_,ls,l)) -> l:: (List.foldBack (fun (_,l) acc -> ListSet.insert l acc) ls [])
  | _ -> []

let fallthrough_of_IlxInstr i = 
  match i with 
  |  (EI_brisdata (_,_,_,_,l)) 
  |  (EI_datacase (_,_,_,l)) -> Some l
  | _ -> None

let IlxInstr_is_tailcall i = 
  match i with 
  |  (EI_callfunc (Tailcall,_)) |  (EI_callclo (Tailcall,_,_)) -> true
  | _ -> false

let remap_ilx_labels lab2cl i = 
  match i with 
    | EI_brisdata (z,a,b,l1,l2) -> EI_brisdata (z,a,b,lab2cl l1,lab2cl l2)
    | EI_datacase (z,x,ls,l) -> EI_datacase (z,x,List.map (fun (y,l) -> (y,lab2cl l)) ls, lab2cl l)
    | _ -> i

let (mk_ilx_ext_instr,is_ilx_ext_instr,dest_ilx_ext_instr) = 
  RegisterInstructionSetExtension  
    { instrExtDests=destinations_of_IlxInstr;
      instrExtFallthrough=fallthrough_of_IlxInstr;
      instrExtIsTailcall=IlxInstr_is_tailcall;
      instrExtRelabel=remap_ilx_labels; }

let mk_IlxInstr i = I_other (mk_ilx_ext_instr i)

// Define an extension of the IL algebra of type definitions
type IlxClosureInfo = 
    { cloStructure: IlxClosureLambdas;
      cloFreeVars: IlxClosureFreeVar list;  
      cloCode: Lazy<ILMethodBody>;
      cloSource: ILSourceMarker option}

and IlxUnionInfo = 
    { cudReprAccess: ILMemberAccess; (* is the representation public? *)
      cudHelpersAccess: ILMemberAccess; (* are the representation public? *)
      cudHasHelpers: IlxUnionHasHelpers; (* generate the helpers? *)
      cudDebugProxies: bool; (* generate the helpers? *)
      cudDebugDisplayAttributes: ILAttribute list;
      cudAlternatives: IlxUnionAlternative array;
      cudNullPermitted: bool;
      (* debug info for generated code for classunions *) 
      cudWhere: ILSourceMarker option; }

type IlxTypeDefKind = 
 | ETypeDef_closure of IlxClosureInfo
 | ETypeDef_classunion of IlxUnionInfo


let (mk_ilx_ext_type_def_kind,is_ilx_ext_type_def_kind,dest_ilx_ext_type_def_kind) = 
  (RegisterTypeDefKindExtension TypeDefKindExtension : (IlxTypeDefKind -> IlxExtensionTypeKind) * (IlxExtensionTypeKind -> bool) * (IlxExtensionTypeKind -> IlxTypeDefKind) )

let mk_IlxTypeDefKind i = ILTypeDefKind.Other (mk_ilx_ext_type_def_kind i)

// --------------------------------------------------------------------
// Define these as extensions of the IL types
// -------------------------------------------------------------------- 

let dest_func_app = function Apps_app (d,r) -> d,r | _ -> failwith "dest_func_app"
let dest_tyfunc_app = function Apps_tyapp (b,c) -> b,c | _ -> failwith "dest_tyfunc_app"

let gen_mk_array_ty (shape,ty) = Type_array(shape,ty)

let gen_is_array_ty ty = 
  match ty with 
    Type_array _ -> true
  | _ -> false

let gen_dest_array_ty ty =
  match ty with 
  | Type_array(shape,ty) -> (shape,ty)
  | _ -> failwith "gen_dest_array_ty"


let mk_array_ty_old (shape,ty) = gen_mk_array_ty (shape,ty)


let generalize_cloref gparams csig = IlxClosureSpec(csig, generalize_gparams gparams)


let actual_typ_of_cuspec_field (cuspec : IlxUnionSpec) idx fidx =
  inst_typ cuspec.GenericArgs (cuspec.FieldDef idx fidx).fdType

