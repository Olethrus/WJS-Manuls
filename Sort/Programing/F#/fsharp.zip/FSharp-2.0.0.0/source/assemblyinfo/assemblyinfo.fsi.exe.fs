#light
namespace Microsoft.FSharp
open System.Reflection
[<assembly:AssemblyDescription("fsi.exe")>]
[<assembly:AssemblyCompany("Microsoft Corporation")>]
[<assembly:AssemblyTitle("fsi.exe")>]
[<assembly:AssemblyCopyright("\169 Microsoft Corporation.  All rights reserved.")>]
[<assembly:AssemblyProduct("Microsoft\174 F#")>]
do()
