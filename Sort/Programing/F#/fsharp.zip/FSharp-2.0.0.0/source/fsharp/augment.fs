// (c) Microsoft Corporation 2005-2009. 

///  Generate the hash/compare functions we add to user-defined types by default.
module internal Microsoft.FSharp.Compiler.Augment 
open Internal.Utilities
open Microsoft.FSharp.Compiler 
open Microsoft.FSharp.Compiler.AbstractIL 
open Microsoft.FSharp.Compiler.AbstractIL.IL
open Microsoft.FSharp.Compiler.AbstractIL.Internal 
open Microsoft.FSharp.Compiler.AbstractIL.Internal.Library
open Microsoft.FSharp.Compiler.Tast
open Microsoft.FSharp.Compiler.Tastops
open Microsoft.FSharp.Compiler.Ast
open Microsoft.FSharp.Compiler.ErrorLogger
open Microsoft.FSharp.Compiler.PrettyNaming
open Microsoft.FSharp.Compiler.Lib
open Microsoft.FSharp.Compiler.Env
open Microsoft.FSharp.Compiler.Infos

let mk_IComparable_CompareTo_slotsig g = 
    TSlotSig("CompareTo",g.mk_IComparable_ty, [],[], [[TSlotParam(Some("obj"),g.obj_ty,false,false,false,[])]],Some g.int_ty)
    
let mk_GenericIComparable_CompareTo_slogsig g typ =
    TSlotSig("CompareTo",(mk_tyapp_ty g.system_GenericIComparable_tcref [typ]),[],[], [[TSlotParam(Some("obj"),typ,false,false,false,[])]],Some g.int_ty)
    
let mk_IStructuralComparable_CompareTo_slotsig g =
    TSlotSig("CompareTo",g.mk_IStructuralComparable_ty,[],[],[[TSlotParam(None,(mk_tuple_ty [g.obj_ty ; g.mk_IComparer_ty]),false,false,false,[])]], Some g.int_ty)
    
let mk_GenericIEquatable_Equals_slogsig g typ =
    TSlotSig("Equals",(mk_tyapp_ty g.system_GenericIEquatable_tcref [typ]),[],[], [[TSlotParam(Some("obj"),typ,false,false,false,[])]],Some g.bool_ty)
    
let mk_IStructuralEquatable_Equals_slotsig g =
    TSlotSig("Equals",g.mk_IStructuralEquatable_ty,[],[],[[TSlotParam(None,(mk_tuple_ty [g.obj_ty ; g.mk_IEqualityComparer_ty]),false,false,false,[])]], Some g.bool_ty)

let mk_IStructuralEquatable_GetHashCode_slotsig g =
    TSlotSig("GetHashCode",g.mk_IStructuralEquatable_ty,[],[],[[TSlotParam(None,g.mk_IEqualityComparer_ty,false,false,false,[])]], Some g.int_ty)
 
let mk_GetHashCode_slotsig g = 
    TSlotSig("GetHashCode", g.obj_ty, [],[], [[]],Some  g.int_ty)

let mk_Equals_slotsig g = 
    TSlotSig("Equals", g.obj_ty, [],[], [[TSlotParam(Some("obj"),g.obj_ty,false,false,false,[])]],Some  g.bool_ty)


let mspec_Object_GetType ilg = IL.mk_instance_nongeneric_mspec_in_nongeneric_boxed_tref(ilg.tref_Object,"GetType",[],ilg.typ_Type)
let mspec_Object_ToString ilg = IL.mk_instance_nongeneric_mspec_in_nongeneric_boxed_tref(ilg.tref_Object,"ToString",[],ilg.typ_String)
let mk_call_Object_GetType_GetString g m e1 = 
  mk_asm ([ IL.mk_normal_callvirt(mspec_Object_ToString g.ilg)   ], [], 
             [ mk_asm ([ IL.mk_normal_callvirt(mspec_Object_GetType g.ilg) ], [], [ e1; ], [ g.int_ty ], m) ], [ g.string_ty ], m)


//-------------------------------------------------------------------------
// Helpers associated with code-generation of comparison/hash augmentations
//------------------------------------------------------------------------- 

let mk_this_typ           g ty = if is_struct_typ g ty then mk_byref_typ g ty else ty 

let mk_compare_obj_typ    g ty = (mk_this_typ g ty) --> (g.obj_ty --> g.int_ty)
let mk_compare_typ        g ty = (mk_this_typ g ty) --> (ty --> g.int_ty)
let mk_compare_withc_typ  g ty = (mk_this_typ g ty) --> ((mk_tuple_ty [g.obj_ty ; g.mk_IComparer_ty]) --> g.int_ty)

let mk_equals_obj_typ     g ty = (mk_this_typ g ty) --> (g.obj_ty --> g.bool_ty)
let mk_equals_typ         g ty = (mk_this_typ g ty) --> (ty --> g.bool_ty)
let mk_equals_withc_typ   g ty = (mk_this_typ g ty) --> ((mk_tuple_ty [g.obj_ty ; g.mk_IEqualityComparer_ty]) --> g.bool_ty)

let mk_hash_typ     g ty = (mk_this_typ g ty) --> (g.unit_ty --> g.int_ty)
let mk_hash_withc_typ     g ty = (mk_this_typ g ty) --> (g.mk_IEqualityComparer_ty --> g.int_ty)

//-------------------------------------------------------------------------
// Polymorphic comparison
//------------------------------------------------------------------------- 

let mk_rel_binop g op m e1 e2 = mk_asm ([ IL.I_arith op  ],[],  [e1; e2],[g.bool_ty],m)
let mk_clt g m e1 e2 = mk_rel_binop g IL.AI_clt m e1 e2 
let mk_cgt g m e1 e2 = mk_rel_binop g IL.AI_cgt m e1 e2

//-------------------------------------------------------------------------
// REVIEW: make this a .constrained call, not a virtual call.
//------------------------------------------------------------------------- 

// for creating and using GenericComparer objects and for creating and using 
// IStructuralComparable objects (Eg, Calling CompareTo(obj o, IComparer comp))
let icomparer_iltref g = g.tcref_System_Collections_IComparer.CompiledRepresentationForTyrepNamed
let icomparer_ilt g = mk_boxed_typ (icomparer_iltref g) []
let istructuralcomparable_iltref g = g.tcref_System_IStructuralComparable.CompiledRepresentationForTyrepNamed

let iequalitycomparer_iltref    g = g.tcref_System_Collections_IEqualityComparer.CompiledRepresentationForTyrepNamed
let iequalitycomparer_ilt       g = mk_boxed_typ (iequalitycomparer_iltref g) []
let istructuralequatable_iltref g = g.tcref_System_IStructuralEquatable.CompiledRepresentationForTyrepNamed
let langprim_iltref             g = g.tcref_LanguagePrimitives.CompiledRepresentationForTyrepNamed
let langprim_ilt g = mk_boxed_typ (langprim_iltref g) []

let mspec_getComparer g = mk_static_nongeneric_mspec_in_typ (langprim_ilt g, "get_GenericComparer",[],icomparer_ilt g)
let mk_call_GetComparer g m = mk_asm([IL.mk_normal_call(mspec_getComparer g)], [], [], [g.mk_IComparer_ty], m)

let mspec_getEqualityComparer g = mk_static_nongeneric_mspec_in_typ (langprim_ilt g,"get_GenericEqualityComparer",[],iequalitycomparer_ilt g)
let mk_call_GetEqualityComparer g m = mk_asm([IL.mk_normal_call(mspec_getEqualityComparer g)], [], [], [g.mk_IEqualityComparer_ty], m)

let mk_thisv g m ty = mk_compgen_local m "this" (mk_this_typ g ty)  

let mk_shl g m acce n = mk_asm([ IL.I_arith IL.AI_shl ],[],[acce; mk_int g m n],[g.int_ty],m)
let mk_shr g m acce n = mk_asm([ IL.I_arith IL.AI_shr ],[],[acce; mk_int g m n],[g.int_ty],m)
let mk_add g m e1 e2 = mk_asm([ IL.I_arith IL.AI_add ],[],[e1;e2],[g.int_ty],m)
                   
let add_to_hash_acc g m e accv acce =
    mk_val_set m accv (mk_add g m (mk_int g m 0x9e3779b9) 
                          (mk_add g m e 
                             (mk_add g m (mk_shl g m acce 6) (mk_shr g m acce 2))))

     
let mk_combine_all_hash_generators g m exprs accv acce =
    (acce,exprs) ||> List.fold (fun tm e -> mk_compgen_seq m (add_to_hash_acc g m e accv acce) tm)

//-------------------------------------------------------------------------
// Build comparison functions for union, record and exception types.
//------------------------------------------------------------------------- 

let mk_thisv_thatv g m ty =
    let thisv,thise = mk_thisv g m ty
    let thatv,thate = mk_compgen_local m "obj" (mk_this_typ g ty)   
    thisv,thatv,thise,thate

let bind_thatv g m ty thatv expr = 
    if is_struct_typ g ty then 
      let thatv2,_ = mk_mut_compgen_local m "obj" ty 
      thatv2,mk_compgen_let m thatv (mk_val_addr m (mk_local_vref thatv2)) expr
    else thatv,expr 

let mk_thataddr_local g m ty =
    if is_struct_typ g ty then
        mk_mut_compgen_local m "objCast" (mk_byref_typ g ty)     
    else
        mk_compgen_local m "objCast" ty
        
let bind_thataddr g m ty thataddrv thatv thate expr =
    if is_struct_typ g ty then
        mk_compgen_let m thataddrv (mk_val_addr m (mk_local_vref thatv))  expr
    else
        mk_compgen_let m thataddrv thate expr

let mk_compare_test_conjs g m exprs =
    match exprs with 
    | [] -> mk_zero g m
    | [h] -> h
    | l -> 
        let a,b = List.frontAndBack l 
        (a,b) ||> List.foldBack (fun e acc -> 
            let nv,ne = mk_compgen_local m "n" g.int_ty
            mk_compgen_let m nv e
              (mk_cond NoSequencePointAtStickyBinding SuppressSequencePointAtTarget m g.int_ty
                 (mk_clt g m ne (mk_zero g m))
                 ne
                 (mk_cond NoSequencePointAtStickyBinding SuppressSequencePointAtTarget m g.int_ty 
                    (mk_cgt g m ne (mk_zero g m))
                    ne
                    acc)))

let mk_equals_test_conjs g m exprs =
    match exprs with 
    | [] -> mk_one g m
    | [h] -> h
    | l -> 
        let a,b = List.frontAndBack l 
        List.foldBack (fun e acc -> mk_cond NoSequencePointAtStickyBinding SuppressSequencePointAtTarget m g.bool_ty e acc (mk_false g m)) a b

let minimal_type g (tcref:TyconRef) = 
    if tcref.Deref.IsExceptionDecl then [], g.exn_ty 
    else generalize_tcref tcref

// check for nulls
let bind_null_comparison g m thise thate expr = 
    let expr = mk_nonnull_cond g m g.int_ty thate expr (mk_one g m) 
    let expr = mk_nonnull_cond g m g.int_ty thise expr (mk_nonnull_cond g m g.int_ty thate (mk_minus_one g m) (mk_zero g m) )
    expr

let bind_this_null_equals g m thise thate expr = 
    let expr = mk_nonnull_cond g m g.bool_ty thise expr (mk_nonnull_cond g m g.int_ty thate (mk_false g m) (mk_true g m) )
    expr

let bind_this_that_null_equals g m thise thate expr = 
    let expr = mk_nonnull_cond g m g.bool_ty thate expr (mk_false g m) 
    let expr = bind_this_null_equals g m thise thate expr
    expr
    
let bind_null_hash g m thise expr = 
    let expr = mk_nonnull_cond g m g.int_ty thise expr (mk_zero g m)
    expr

/// Build the comparison implementation for a record type 
let mk_recd_compare g tcref (tycon:Tycon) = 
    let m = tycon.Range 
    let fields = tycon.AllInstanceFieldsAsList 
    let tinst,ty = minimal_type g tcref
    let thisv,thatv,thise,thate = mk_thisv_thatv g m ty 
    let compe = mk_call_GetComparer g m
    let mk_test (fspec:RecdField) = 
        let fty = fspec.FormalType 
        let fref = rfref_of_rfield tcref fspec 
        let m = fref.Range 
        mk_call_generic_comparison_withc_outer g m fty
          compe
          (mk_recd_field_get_via_expra(thise, fref, tinst, m))
          (mk_recd_field_get_via_expra(thate, fref, tinst, m)) 
    let expr = mk_compare_test_conjs g m (List.map mk_test fields) 

    let expr = if tycon.IsStructOrEnumTycon then expr else bind_null_comparison g m thise thate expr

    let thatv,expr = bind_thatv g m ty thatv expr
    thisv,thatv, expr


/// Build the comparison implementation for a record type when parameterized by a comparer
let mk_recd_compare_withc g tcref (tycon:Tycon) (_thisv,thise) (_,thate) compe = 
    let m = tycon.Range 
    let fields = tycon.AllInstanceFieldsAsList
    let tinst,ty = minimal_type g tcref
    let tcv,tce = mk_compgen_local m "objTemp" ty    // let tcv = thate
    let thataddrv,thataddre = mk_thataddr_local g m ty      // let thataddrv = &tcv, if a struct
    
    let mk_test (fspec:RecdField) = 
        let fty = fspec.FormalType 
        let fref = rfref_of_rfield tcref fspec 
        let m = fref.Range 
        mk_call_generic_comparison_withc_outer g m fty
          compe
          (mk_recd_field_get_via_expra(thise, fref, tinst, m))
          (mk_recd_field_get_via_expra(thataddre, fref, tinst, m))
    let expr = mk_compare_test_conjs g m (List.map mk_test fields) 

    let expr = if tycon.IsStructOrEnumTycon then expr else bind_null_comparison g m thise thate expr

    let expr = bind_thataddr g m ty thataddrv tcv tce expr
    // will be optimized away if not necessary
    let expr = mk_compgen_let m tcv thate expr
    expr    


/// Build the equality implementation wrapper for a record type 
let mk_recd_equality g tcref (tycon:Tycon) = 
    let m = tycon.Range
    let fields = tycon.AllInstanceFieldsAsList 
    let tinst,ty = minimal_type g tcref
    let thisv,thatv,thise,thate = mk_thisv_thatv g m ty 
    let mk_test (fspec:RecdField) = 
        let fty = fspec.FormalType 
        let fref = rfref_of_rfield tcref fspec 
        let m = fref.Range 
        mk_call_generic_equality_er_outer g m fty
          (mk_recd_field_get_via_expra(thise, fref, tinst, m))
          (mk_recd_field_get_via_expra(thate, fref, tinst, m)) 
    let expr = mk_equals_test_conjs g m (List.map mk_test fields) 

    let expr = if tycon.IsStructOrEnumTycon then expr else bind_this_that_null_equals g m thise thate expr

    let thatv,expr = bind_thatv g m ty thatv expr
    thisv,thatv,expr
    
/// Build the equality implementation for a record type when parameterized by a comparer
let mk_recd_equality_withc g tcref (tycon:Tycon) (_thisv,thise) thatobje (thatv,thate) compe =
    let m = tycon.Range
    let fields = tycon.AllInstanceFieldsAsList
    let tinst,ty = minimal_type g tcref
    let thataddrv,thataddre = mk_thataddr_local g m ty
    
    let mk_test (fspec:RecdField) =
        let fty = fspec.FormalType
        let fref = rfref_of_rfield tcref fspec
        let m = fref.Range
        
        mk_call_generic_equality_withc_outer g m fty
            compe
            (mk_recd_field_get_via_expra(thise, fref, tinst, m))
            (mk_recd_field_get_via_expra(thataddre, fref, tinst, m))
    let expr = mk_equals_test_conjs g m (List.map mk_test fields)

    let expr = bind_thataddr g m ty thataddrv thatv thate expr
    // will be optimized away if not necessary
    let expr = mk_isinst_cond g m ty thatobje thatv expr (mk_false g m)
    let expr = if tycon.IsStructOrEnumTycon then expr else bind_this_null_equals g m thise thatobje expr

    expr
        
/// Build the equality implementation for an exception definition
let mk_exnconstr_equality g exnref (exnc:Tycon) = 
    let m = exnc.Range 
    let thatv,thate = mk_compgen_local m "obj" g.exn_ty  
    let thisv,thise = mk_thisv g m g.exn_ty  
    let mk_test i (rfield:RecdField) = 
        let fty = rfield.FormalType
        mk_call_generic_equality_er_outer g m fty
          (mk_exnconstr_field_get(thise, exnref, i, m))
          (mk_exnconstr_field_get(thate, exnref, i, m)) 
    let expr = mk_equals_test_conjs g m (List.mapi mk_test (exnc.AllInstanceFieldsAsList)) 
    let expr =
        let mbuilder = new MatchBuilder(NoSequencePointAtInvisibleBinding,m ) 
        let dtree = 
          TDSwitch(thate,
                   [ mk_case(TTest_isinst(g.exn_ty,mk_tyapp_ty exnref []),
                            mbuilder.AddResultTarget(expr,SuppressSequencePointAtTarget)) ],
                   Some(mbuilder.AddResultTarget(mk_false g m,SuppressSequencePointAtTarget)),
                   m)
        mbuilder.Close(dtree,m,g.bool_ty)

    let expr = bind_this_that_null_equals g m thise thate expr
    thisv,thatv, expr
    
    
/// Build the equality implementation for an exception definition when parameterized by a comparer
let mk_exnconstr_equality_withc g exnref (exnc:Tycon) (_thisv,thise) thatobje (thatv,thate) compe = 
    let m = exnc.Range
    let thataddrv,thataddre =  mk_thataddr_local g m g.exn_ty
    let mk_test i (rfield:RecdField) = 
        let fty = rfield.FormalType
        mk_call_generic_equality_withc_outer g m fty
          compe
          (mk_exnconstr_field_get(thise, exnref, i, m))
          (mk_exnconstr_field_get(thataddre, exnref, i, m))
    let expr = mk_equals_test_conjs g m (List.mapi mk_test (exnc.AllInstanceFieldsAsList)) 
    let expr =
        let mbuilder = new MatchBuilder(NoSequencePointAtInvisibleBinding,m ) 
        let dtree = 
          TDSwitch(thataddre,
                   [ mk_case(TTest_isinst(g.exn_ty,mk_tyapp_ty exnref []),
                            mbuilder.AddResultTarget(expr,SuppressSequencePointAtTarget)) ],
                   Some(mbuilder.AddResultTarget(mk_false g m,SuppressSequencePointAtTarget)),
                   m)
        mbuilder.Close(dtree,m,g.bool_ty)
    let expr = bind_thataddr g m g.exn_ty thataddrv thatv thate expr
    let expr = mk_isinst_cond g m g.exn_ty thatobje thatv expr (mk_false g m)
    let expr = if exnc.IsStructOrEnumTycon then expr else bind_this_null_equals g m thise thatobje expr
    expr

/// Build the comparison implementation for a union type
let mk_union_compare g tcref (tycon:Tycon) = 
    let m = tycon.Range 
    let ucases = tycon.UnionCasesAsList 
    let tinst,ty = minimal_type g tcref
    let thisv,thise = mk_compgen_local m "this" ty  
    let thatv,thate = mk_compgen_local m "obj" ty  
    let thistagv,thistage = mk_compgen_local m "thisTag" g.int_ty  
    let thattagv,thattage = mk_compgen_local m "thatTag" g.int_ty 
    let compe = mk_call_GetComparer g m

    let expr = 
        let mbuilder = new MatchBuilder(NoSequencePointAtInvisibleBinding,m ) 
        let mk_constr_case ucase =
            let cref = ucref_of_ucase tcref ucase 
            let m = cref.Range 
            let thisucv,thisucve = mk_compgen_local m "thisCast" (mk_proven_ucase_typ cref tinst)
            let thatucv,thatucve = mk_compgen_local m "objCast" (mk_proven_ucase_typ cref tinst)
            let mk_test j (argty:RecdField) = 
              mk_call_generic_comparison_withc_outer g m argty.FormalType
                compe
                (mk_ucase_field_get_proven(thisucve, cref, tinst, j, m))
                (mk_ucase_field_get_proven(thatucve, cref, tinst, j, m)) 
            let rfields = ucase.RecdFields 
            if isNil rfields then None else
            Some (mk_case(TTest_unionconstr(cref,tinst),
                          mbuilder.AddResultTarget
                             (mk_compgen_let m thisucv (mk_ucase_proof(thise,cref,tinst,m))
                                 (mk_compgen_let m thatucv (mk_ucase_proof(thate,cref,tinst,m))
                                     (mk_compare_test_conjs g m (List.mapi mk_test rfields))),
                              SuppressSequencePointAtTarget)))
        
        let nullary,nonNullary = List.partition isNone (List.map mk_constr_case ucases)  
        if isNil nonNullary then mk_zero g m else 
        let dtree = 
            TDSwitch(thise,
                     (nonNullary |> List.map (function (Some c) -> c | None -> failwith "mk_union_compare")), 
                     (if isNil nullary then None 
                      else Some (mbuilder.AddResultTarget(mk_zero g m,SuppressSequencePointAtTarget))),
                     m) 
        mbuilder.Close(dtree,m,g.int_ty)

    let expr = 
        if ucases.Length = 1 then expr else
        let tagsEqTested = 
            mk_cond NoSequencePointAtStickyBinding SuppressSequencePointAtTarget m g.int_ty  
              (mk_il_ceq g m thistage thattage)
              expr
              (mk_asm ([ IL.I_arith IL.AI_sub  ],[],  [thistage; thattage],[g.int_ty],m))in 
        mk_compgen_let m thistagv
          (mk_ucase_tag_get (thise,tcref,tinst,m))
          (mk_compgen_let m thattagv
               (mk_ucase_tag_get (thate,tcref,tinst,m))
               tagsEqTested) 

    let expr = bind_null_comparison g m thise thate expr
    thisv,thatv, expr


/// Build the comparison implementation for a union type when parameterized by a comparer
let mk_union_compare_withc g tcref (tycon:Tycon) (_thisv,thise) (thatv,thate) compe = 
    let m = tycon.Range 
    let ucases = tycon.UnionCasesAsList
    let tinst,ty = minimal_type g tcref
    let thistagv,thistage = mk_compgen_local m "thisTag" g.int_ty  
    let thattagv,thattage = mk_compgen_local m "thatTag" g.int_ty  
    let thataddrv,thataddre = mk_thataddr_local g m ty

    let expr = 
        let mbuilder = new MatchBuilder(NoSequencePointAtInvisibleBinding,m ) 
        let mk_constr_case ucase =
            let cref = ucref_of_ucase tcref ucase 
            let m = cref.Range 
            let thisucv,thisucve = mk_compgen_local m "thisCastu" (mk_proven_ucase_typ cref tinst)
            let thatucv,thatucve = mk_compgen_local m "thatCastu" (mk_proven_ucase_typ cref tinst)
            let mk_test j (argty:RecdField) = 
              mk_call_generic_comparison_withc_outer g m argty.FormalType
                compe
                (mk_ucase_field_get_proven(thisucve, cref, tinst, j, m))
                (mk_ucase_field_get_proven(thatucve, cref, tinst, j, m))
            let rfields = ucase.RecdFields 
            if isNil rfields then None else
            Some (mk_case(TTest_unionconstr(cref,tinst),
                          mbuilder.AddResultTarget
                             (mk_compgen_let m thisucv (mk_ucase_proof(thise,cref,tinst,m))
                                 (mk_compgen_let m thatucv (mk_ucase_proof(thataddre,cref,tinst,m))
                                     (mk_compare_test_conjs g m (List.mapi mk_test rfields))),
                              SuppressSequencePointAtTarget)))
        
        let nullary,nonNullary = List.partition isNone (List.map mk_constr_case ucases)  
        if isNil nonNullary then mk_zero g m else 
        let dtree = 
            TDSwitch(thise,
                     (nonNullary |> List.map (function (Some c) -> c | None -> failwith "mk_union_compare")), 
                     (if isNil nullary then None 
                      else Some (mbuilder.AddResultTarget(mk_zero g m,SuppressSequencePointAtTarget))),
                     m) 
        mbuilder.Close(dtree,m,g.int_ty)

    let expr = 
        if ucases.Length = 1 then expr else
        let tagsEqTested = 
            mk_cond NoSequencePointAtStickyBinding SuppressSequencePointAtTarget m g.int_ty  
              (mk_il_ceq g m thistage thattage)
              expr
              (mk_asm ([ IL.I_arith IL.AI_sub  ],[],  [thistage; thattage],[g.int_ty],m))in 
        mk_compgen_let m thistagv
          (mk_ucase_tag_get (thise,tcref,tinst,m))
          (mk_compgen_let m thattagv
               (mk_ucase_tag_get (thataddre,tcref,tinst,m))
               tagsEqTested) 

    let expr = bind_null_comparison g m thise thate expr
    let expr = bind_thataddr g m ty thataddrv thatv thate expr
    expr
    
    
/// Build the equality implementation for a union type
let mk_union_equality g tcref (tycon:Tycon) = 
    let m = tycon.Range 
    let ucases = tycon.UnionCasesAsList 
    let tinst,ty = minimal_type g tcref
    let thisv,thise = mk_compgen_local m "this" ty  
    let thatv,thate = mk_compgen_local m "obj" ty  
    let thistagv,thistage = mk_compgen_local m "thisTag" g.int_ty  
    let thattagv,thattage = mk_compgen_local m "thatTag" g.int_ty  

    let expr = 
        let mbuilder = new MatchBuilder(NoSequencePointAtInvisibleBinding,m ) 
        let mk_constr_case ucase =
            let cref = ucref_of_ucase tcref ucase 
            let m = cref.Range 
            let thisucv,thisucve = mk_compgen_local m "thisCast" (mk_proven_ucase_typ cref tinst)
            let thatucv,thatucve = mk_compgen_local m "objCast" (mk_proven_ucase_typ cref tinst)
            let mk_test j (argty:RecdField) = 
                mk_call_generic_equality_er_outer g m argty.FormalType
                  (mk_ucase_field_get_proven(thisucve, cref, tinst, j, m))
                  (mk_ucase_field_get_proven(thatucve, cref, tinst, j, m)) 
            let rfields = ucase.RecdFields
            if isNil rfields then None else
            Some (mk_case(TTest_unionconstr(cref,tinst),
                          mbuilder.AddResultTarget
                              (mk_compgen_let m thisucv (mk_ucase_proof(thise,cref,tinst,m))
                                 (mk_compgen_let m thatucv (mk_ucase_proof(thate,cref,tinst,m))
                                     (mk_equals_test_conjs g m (List.mapi mk_test rfields))),
                               SuppressSequencePointAtTarget)))
        
        let nullary,nonNullary = List.partition isNone (List.map mk_constr_case ucases)  
        if isNil nonNullary then mk_true g m else 
        let dtree = 
            TDSwitch(thise,List.map (function (Some c) -> c | None -> failwith "mk_union_equality") nonNullary, 
                    (if isNil nullary then None else Some (mbuilder.AddResultTarget(mk_true g m,SuppressSequencePointAtTarget))),
                    m) 
        mbuilder.Close(dtree,m,g.bool_ty)
        
    let expr = 
        if ucases.Length = 1 then expr else
        let tagsEqTested = 
          mk_cond NoSequencePointAtStickyBinding SuppressSequencePointAtTarget m g.bool_ty  
            (mk_il_ceq g m thistage thattage)
            expr
            (mk_false g m)

        mk_compgen_let m thistagv
          (mk_ucase_tag_get (thise,tcref,tinst,m))
          (mk_compgen_let m thattagv
               (mk_ucase_tag_get (thate,tcref,tinst,m))
               tagsEqTested) 

    let expr = bind_this_that_null_equals g m thise thate expr
    thisv,thatv, expr


/// Build the equality implementation for a union type when parameterized by a comparer
let mk_union_equality_withc g tcref (tycon:Tycon) (_thisv,thise) thatobje (thatv,thate) compe =
    let m = tycon.Range 
    let ucases = tycon.UnionCasesAsList
    let tinst,ty = minimal_type g tcref
    let thistagv,thistage = mk_compgen_local m "thisTag" g.int_ty  
    let thattagv,thattage = mk_compgen_local m "thatTag" g.int_ty  
    let thataddrv,thataddre = mk_thataddr_local g m ty

    let expr = 
        let mbuilder = new MatchBuilder(NoSequencePointAtInvisibleBinding,m ) 
        let mk_constr_case ucase =
            let cref = ucref_of_ucase tcref ucase 
            let m = cref.Range 
            let thisucv,thisucve = mk_compgen_local m "thisCastu" (mk_proven_ucase_typ cref tinst)
            let thatucv,thatucve = mk_compgen_local m "thatCastu" (mk_proven_ucase_typ cref tinst)
            let mk_test j (argty:RecdField) = 
              mk_call_generic_equality_withc_outer g m argty.FormalType
                compe
                (mk_ucase_field_get_proven(thisucve, cref, tinst, j, m))
                (mk_ucase_field_get_proven(thatucve, cref, tinst, j, m))
            let rfields = ucase.RecdFields
            if isNil rfields then None else
            Some (mk_case(TTest_unionconstr(cref,tinst),
                          mbuilder.AddResultTarget
                              (mk_compgen_let m thisucv (mk_ucase_proof(thise,cref,tinst,m))
                                 (mk_compgen_let m thatucv (mk_ucase_proof(thataddre,cref,tinst,m))
                                     (mk_equals_test_conjs g m (List.mapi mk_test rfields))),
                               SuppressSequencePointAtTarget)))
        
        let nullary,nonNullary = List.partition isNone (List.map mk_constr_case ucases)  
        if isNil nonNullary then mk_true g m else 
        let dtree = 
            TDSwitch(thise,List.map (function (Some c) -> c | None -> failwith "mk_union_equality") nonNullary, 
                    (if isNil nullary then None else Some (mbuilder.AddResultTarget(mk_true g m,SuppressSequencePointAtTarget))),
                    m) 
        mbuilder.Close(dtree,m,g.bool_ty)
        
    let expr = 
        if ucases.Length = 1 then expr else
        let tagsEqTested = 
          mk_cond NoSequencePointAtStickyBinding SuppressSequencePointAtTarget m g.bool_ty  
            (mk_il_ceq g m thistage thattage)
            expr
            (mk_false g m)

        mk_compgen_let m thistagv
          (mk_ucase_tag_get (thise,tcref,tinst,m))
          (mk_compgen_let m thattagv
               (mk_ucase_tag_get (thataddre,tcref,tinst,m))
               tagsEqTested) 
    let expr = bind_thataddr g m ty thataddrv thatv thate expr
    let expr = mk_isinst_cond g m ty thatobje thatv expr (mk_false g m)
    let expr = if tycon.IsStructOrEnumTycon then expr else bind_this_null_equals g m thise thatobje expr
    expr

//-------------------------------------------------------------------------
// Build hashing functions for union, record and exception types.
// Hashing functions must respect the "=" and comparison operators.
//------------------------------------------------------------------------- 

/// Structural hash implementation for record types when parameterized by a comparer 
let mk_recd_hash_withc g tcref (tycon:Tycon) compe = 
    let m = tycon.Range 
    let fields = tycon.AllInstanceFieldsAsList
    let tinst,ty = minimal_type g tcref
    let thisv,thise = mk_thisv g m ty
    let mk_field_hash (fspec:RecdField) = 
        let fty = fspec.FormalType
        let fref = rfref_of_rfield tcref fspec 
        let m = fref.Range 
        let e = mk_recd_field_get_via_expra(thise, fref, tinst, m)
        
        mk_call_generic_hash_withc_outer g m fty compe e
            
    let accv,acce = mk_mut_compgen_local m "i" g.int_ty                  
    let stmt = mk_combine_all_hash_generators g m (List.map mk_field_hash fields) (mk_local_vref accv) acce
    let expr = mk_compgen_let m accv (mk_zero g m) stmt 
    let expr = if tycon.IsStructOrEnumTycon then expr else bind_null_hash g m thise expr
    thisv,expr

/// Structural hash implementation for exception types when parameterized by a comparer
let mk_exnconstr_hash_withc g exnref (exnc:Tycon) compe = 
    let m = exnc.Range
    let thisv,thise = mk_thisv g m g.exn_ty
    
    let mk_hash i (rfield:RecdField) = 
        let fty = rfield.FormalType
        let e = mk_exnconstr_field_get(thise, exnref, i, m)
        
        mk_call_generic_hash_withc_outer g m fty compe e
       
    let accv,acce = mk_mut_compgen_local m "i" g.int_ty                  
    let stmt = mk_combine_all_hash_generators g m (List.mapi mk_hash (exnc.AllInstanceFieldsAsList)) (mk_local_vref accv) acce
    let expr = mk_compgen_let m accv (mk_zero g m) stmt 
    let expr = bind_null_hash g m thise expr
    thisv,expr

/// Structural hash implementation for union types when parameterized by a comparer   
let mk_union_hash_withc g tcref (tycon:Tycon) compe =
    let m = tycon.Range
    let ucases = tycon.UnionCasesAsList
    let tinst,ty = minimal_type g tcref
    let thisv,thise = mk_thisv g m ty
    let mbuilder = new MatchBuilder(NoSequencePointAtInvisibleBinding,m ) 
    let accv,acce = mk_mut_compgen_local m "i" g.int_ty                  
    let mk_constr_case i ucase1 = 
      let c1ref = ucref_of_ucase tcref ucase1 
      let ucv,ucve = mk_compgen_local m "unionCase" (mk_proven_ucase_typ c1ref tinst)
      let m = c1ref.Range 
      let mk_hash j (rfield:RecdField) =  
        let fty = rfield.FormalType
        let e = mk_ucase_field_get_proven(ucve, c1ref, tinst, j, m)
        mk_call_generic_hash_withc_outer g m fty compe e
      mk_case(TTest_unionconstr(c1ref,tinst),
              mbuilder.AddResultTarget 
                (mk_compgen_let m ucv
                    (mk_ucase_proof(thise,c1ref,tinst,m))
                    (mk_compgen_seq m 
                          (mk_val_set m (mk_local_vref accv) (mk_int g m i)) 
                          (mk_combine_all_hash_generators g m (List.mapi mk_hash ucase1.RecdFields) (mk_local_vref accv) acce)),
                 SuppressSequencePointAtTarget))
    let dtree = TDSwitch(thise,List.mapi mk_constr_case ucases, None,m) 
    let stmt = mbuilder.Close(dtree,m,g.int_ty)
    let expr = mk_compgen_let m accv (mk_zero g m) stmt 
    let expr = bind_null_hash g m thise expr
    thisv,expr


//-------------------------------------------------------------------------
// The predicate that determines which types implement the 
// pre-baked IStructuralHash and IComparable semantics associated with F#
// types.  Note abstract types are not _known_ to implement these interfaces,
// though the interfaces may be discoverable via type tests.
//------------------------------------------------------------------------- 

let isNominalExnc (exnc:Tycon) = 
    match exnc.ExceptionInfo with 
    | TExnAbbrevRepr _ | TExnNone | TExnAsmRepr _ -> false
    | TExnFresh _ -> true

let isTrueFSharpStructTycon _g (tycon: Tycon) = 
    (tycon.IsFSharpStructOrEnumTycon  && not tycon.IsFSharpEnumTycon)

let canBeAugmentedWithEquals g (tycon:Tycon) = 
    tycon.IsUnionTycon ||
    tycon.IsRecordTycon ||
    (tycon.IsExceptionDecl && isNominalExnc tycon) ||
    isTrueFSharpStructTycon g tycon

let canBeAugmentedWithCompare g (tycon:Tycon) = 
    tycon.IsUnionTycon ||
    tycon.IsRecordTycon ||
    isTrueFSharpStructTycon g tycon

let getAugmentationAttribs g (tycon:Tycon) = 
    canBeAugmentedWithEquals g tycon,
    canBeAugmentedWithCompare g tycon,
    TryFindBoolAttrib g g.attrib_NoEqualityAttribute tycon.Attribs,
    TryFindBoolAttrib g g.attrib_CustomEqualityAttribute tycon.Attribs,
    TryFindBoolAttrib g g.attrib_ReferenceEqualityAttribute tycon.Attribs,
    TryFindBoolAttrib g g.attrib_StructuralEqualityAttribute tycon.Attribs,
    TryFindBoolAttrib g g.attrib_NoComparisonAttribute tycon.Attribs,
    TryFindBoolAttrib g g.attrib_CustomComparisonAttribute tycon.Attribs,
    TryFindBoolAttrib g g.attrib_StructuralComparisonAttribute tycon.Attribs 

let CheckAugmentationAttribs isImplementation g amap (tycon:Tycon)= 
    let m = tycon.Range
    let attribs = getAugmentationAttribs g tycon
    match attribs with 
    
    // THESE ARE THE LEGITIMATE CASES 

    // [< >] on anything
    | _, _   ,  None    , None, None      ,       None, None      , None     , None

    // [<CustomEquality; CustomComparison>]  on union/record/struct
    | true, _, None, Some(true), None     , None      , None      , Some(true), None

    // [<CustomEquality; NoComparison>]  on union/record/struct
    | true, _, None, Some(true), None     , None      , Some(true), None      , None -> 
        ()

    // [<ReferenceEquality; NoComparison>]  on union/record/struct
    | true, _, None, None     , Some(true), None      , Some(true), None      , None

    // [<ReferenceEquality>] on union/record/struct
    | true, _, None, None     , Some(true), None      , None      , None      , None ->
        if isTrueFSharpStructTycon g tycon then 
            errorR(Error(FSComp.SR.augNoRefEqualsOnStruct(), m))
        else ()

    // [<StructuralEquality; StructuralComparison>]  on union/record/struct
    | true, true, None, None     , None      , Some(true), None      , None      , Some(true) 

    // [<StructuralEquality; NoComparison>] 
    | true, _, None, None      , None     , Some(true), Some(true), None      , None

    // [<StructuralEquality; CustomComparison>] 
    | true, _, None, None      , None     , Some(true), None      , Some(true), None

    // [<NoComparison>] on anything
    | _   , _, None, None      , None     , None      , Some(true), None      , None 

    // [<NoEquality; NoComparison>] on anything
    | _   , _, Some(true), None, None     , None      , Some(true), None      , None ->

        () 

    (* THESE ARE THE ERROR CASES *)

    // [<NoEquality; ...>] 
    | _, _, Some(true), _, _,           _, None, _, _ ->
        errorR(Error(FSComp.SR.augNoEqualityNeedsNoComparison(), m))

    // [<StructuralComparison(_)>] 
    | true, true, _, _, _         , None      , _, _, Some(true) ->
        errorR(Error(FSComp.SR.augStructCompNeedsStructEquality(), m))
    // [<StructuralEquality(_)>] 
    | true, _, _, _, _         , Some(true), None, _, None ->
        errorR(Error(FSComp.SR.augStructEqNeedsNoCompOrStructComp(), m))

    // [<StructuralEquality(_)>] 
    | true, _, _, Some(true), _ , _, None, None, _ ->
        errorR(Error(FSComp.SR.augCustomEqNeedsNoCompOrCustomComp(), m))

    // [<ReferenceEquality; StructuralEquality>] 
    | true, _, _, _, Some(true)  , Some(true)    ,      _, _, _

    // [<ReferenceEquality; StructuralComparison(_) >] 
    | true, _, _, _, Some(true),             _, _, _, Some(true) -> 
        errorR(Error(FSComp.SR.augTypeCantHaveRefEqAndStructAttrs(), m))

    // non augmented type, [<ReferenceEquality; ... >] 
    // non augmented type, [<StructuralEquality; ... >] 
    // non augmented type, [<StructuralComparison(_); ... >] 
    | false,  _, _, _, Some(true), _         , _         , _, _
    | false,  _, _, _, _         , Some(true), _         , _, _ 
    | false,  _, _, _, _         , _         , _         , _, Some(true)  ->
        errorR(Error(FSComp.SR.augOnlyCertainTypesCanHaveAttrs(), m))
    // All other cases
    | _  -> 
        errorR(Error(FSComp.SR.augInvalidAttrs(), m))
    
    let tcaug = tycon.TypeContents
    
    let hasNominalInterface tcref =
        let ty = generalized_tcref (mk_local_tcref tycon)
        ExistsHeadTypeInEntireHierarchy g amap tycon.Range ty tcref

    let hasExplicitICompare = 
        hasNominalInterface g.tcref_System_IStructuralComparable || 
        hasNominalInterface g.tcref_System_IComparable

    let hasExplicitIGenericCompare = 
        hasNominalInterface g.system_GenericIComparable_tcref 

    let hasExplicitEquals = 
        tcaug_has_override g tcaug "Equals" [g.obj_ty] ||
        hasNominalInterface g.tcref_System_IStructuralEquatable

    let hasExplicitGenericEquals = 
        hasNominalInterface g.system_GenericIEquatable_tcref

    match attribs with 
    // [<NoEquality>] + any equality semantics
    | _, _, Some(true), _, _, _, _, _, _ when (hasExplicitEquals || hasExplicitGenericEquals) -> 
        warning(Error(FSComp.SR.augNoEqNeedsNoObjEquals(), m))
    // [<NoComparison>] + any comparison semantics
    | _, _, _, _,         _, _, Some(true), _, _ when (hasExplicitICompare || hasExplicitIGenericCompare) -> 
        warning(Error(FSComp.SR.augNoCompCantImpIComp(), m))

    // [<CustomEquality>] + no explicit override Object.Equals  + no explicit IStructuralEquatable
    | _, _, _, Some(true), _, _, _, _, _ when isImplementation && not hasExplicitEquals && not hasExplicitGenericEquals-> 
        errorR(Error(FSComp.SR.augCustomEqNeedsObjEquals(), m))
    // [<CustomComparison>] + no explicit IComparable + no explicit IStructuralComparable
    | _, _, _, _, _, _, _, Some(true), _ when isImplementation && not hasExplicitICompare && not hasExplicitIGenericCompare -> 
        errorR(Error(FSComp.SR.augCustomCompareNeedsIComp(), m))

    // [<ReferenceEquality>] + any equality semantics
    | _, _, _, _, Some(true), _, _, _, _ when (hasExplicitEquals || hasExplicitIGenericCompare) -> 
        errorR(Error(FSComp.SR.augRefEqCantHaveObjEquals(), m))

    | _ -> 
        ()

let TyconIsCandidateForAugmentationWithCompare g (tycon:Tycon) = 
    // This type gets defined in prim-types, before we can add attributes to F# type definitions
    let isUnit = g.compilingFslib && tycon.DisplayName = "Unit"
    not isUnit && 

    match getAugmentationAttribs g tycon with 
    // [< >] 
    | true, true, None, None, None, None      , None, None, None
    // [<StructuralEquality; StructuralComparison>] 
    | true, true, None, None, None, Some(true), None, None, Some(true) 
    // [<StructuralComparison>] 
    | true, true, None, None, None, None, None, None, Some(true) -> true
    // other cases 
    | _ -> false

let TyconIsCandidateForAugmentationWithEquals g (tycon:Tycon) = 
    // This type gets defined in prim-types, before we can add attributes to F# type definitions
    let isUnit = g.compilingFslib && tycon.DisplayName = "Unit"
    not isUnit && 

    match getAugmentationAttribs g tycon with 
    // [< >] 
    | true, _, None, None, None, None      , _, _, _
    // [<StructuralEquality; _ >] 
    // [<StructuralEquality; StructuralComparison>] 
    | true, _, None, None, None, Some(true), _, _, _ -> true
    // other cases 
    | _ -> false

let TyconIsCandidateForAugmentationWithHash g tycon = TyconIsCandidateForAugmentationWithEquals g tycon
      
//-------------------------------------------------------------------------
// Make values that represent the implementations of the 
// IComparable semantics associated with F# types.  
//------------------------------------------------------------------------- 

let slotImplMethod (final,c,slotsig) = 
  { ImplementedSlotSigs=[slotsig];
    MemberFlags=
        { MemberIsInstance=true; 
          MemberIsDispatchSlot=false;
          MemberIsFinal=final;
          MemberIsOverrideOrExplicitImpl=true;
          MemberKind=MemberKindMember};
    IsImplemented=false;
    ApparentParent=c} 

let nonVirtualMethod c = 
  { ImplementedSlotSigs=[];
    MemberFlags={ MemberIsInstance=true; 
                  MemberIsDispatchSlot=false;
                  MemberIsFinal=false;
                  MemberIsOverrideOrExplicitImpl=false;
                  MemberKind=MemberKindMember};
    IsImplemented=false;
    ApparentParent=c} 

let unitArg = TopValInfo.unitArgData
let unaryArg = [ TopValInfo.unnamedTopArg ]
let tupArg = [ [ TopValInfo.unnamedTopArg1; TopValInfo.unnamedTopArg1 ] ]
let mk_vspec g (tcref:TyconRef) tmty vis  slotsig methn ty argData = 
    let m = tcref.Range 
    let tps = tcref.Typars(m)
    let final = is_union_typ g tmty || is_recd_typ g tmty || is_struct_typ g tmty 
    let membInfo = match slotsig with None -> nonVirtualMethod tcref | Some(slotsig) -> slotImplMethod(final,tcref,slotsig) 
    let inl = OptionalInline
    let args = TopValInfo.unnamedTopArg :: argData
    let topValInfo = Some (TopValInfo (TopValInfo.InferTyparInfo tps, args, TopValInfo.unnamedRetVal)) 
    NewVal (methn, m, None, ty, Immutable, true, topValInfo, vis, ValNotInRecScope, Some(membInfo), NormalVal, [], inl, emptyXmlDoc, true, false, false, false, false, None, Parent(tcref)) 

let MakeValsForCompareAugmentation g (tcref:TyconRef) = 
    let _,tmty = minimal_type g tcref
    let tps = tcref.Typars(tcref.Range)
    let vis = tcref.TypeReprAccessibility

    mk_vspec g tcref tmty vis  (Some(mk_IComparable_CompareTo_slotsig g)) "CompareTo" (tps +-> (mk_compare_obj_typ g tmty)) unaryArg, 
    mk_vspec g tcref tmty vis  (Some(mk_GenericIComparable_CompareTo_slogsig g tmty)) "CompareTo" (tps +-> (mk_compare_typ g tmty)) unaryArg
    
let MakeValsForCompareWithComparerAugmentation g (tcref:TyconRef) =
    let _,tmty = minimal_type g tcref
    let tps = tcref.Typars(tcref.Range)
    let vis = tcref.TypeReprAccessibility
    mk_vspec g tcref tmty vis (Some(mk_IStructuralComparable_CompareTo_slotsig g)) "CompareTo" (tps +-> (mk_compare_withc_typ g tmty)) tupArg

let MakeValsForEqualsAugmentation g (tcref:TyconRef) = 
    let _,tmty = minimal_type g tcref
    let vis = tcref.TypeReprAccessibility
    let tps = tcref.Typars(tcref.Range)

    let objEqualsVal = mk_vspec g tcref tmty vis  (Some(mk_Equals_slotsig g)) "Equals" (tps +-> (mk_equals_obj_typ g tmty)) unaryArg
    let nocEqualsVal = mk_vspec g tcref tmty vis  (if tcref.Deref.IsExceptionDecl then None else Some(mk_GenericIEquatable_Equals_slogsig g tmty)) "Equals" (tps +-> (mk_equals_typ g tmty)) unaryArg
    objEqualsVal,nocEqualsVal
    
let MakeValsForEqualityWithComparerAugmentation g (tcref:TyconRef) =
    let _,tmty = minimal_type g tcref
    let vis = tcref.TypeReprAccessibility
    let tps = tcref.Typars(tcref.Range)
    let objGetHashCodeVal = mk_vspec g tcref tmty vis  (Some(mk_GetHashCode_slotsig g)) "GetHashCode" (tps +-> (mk_hash_typ g tmty)) unitArg
    let withcGetHashCodeVal = mk_vspec g tcref tmty vis (Some(mk_IStructuralEquatable_GetHashCode_slotsig g)) "GetHashCode" (tps +-> (mk_hash_withc_typ g tmty)) unaryArg
    let withcEqualsVal  = mk_vspec g tcref tmty vis (Some(mk_IStructuralEquatable_Equals_slotsig g)) "Equals" (tps +-> (mk_equals_withc_typ g tmty)) tupArg
    objGetHashCodeVal,withcGetHashCodeVal,withcEqualsVal

let MakeBindingsForCompareAugmentation g (tycon:Tycon) = 
    let tcref = mk_local_tcref tycon 
    let m = tycon.Range
    let tps = tycon.Typars(tycon.Range)
    let mk_compare comparef =
        match tycon.GeneratedCompareToValues with 
        | None ->  []
        | Some (vref1,vref2) -> 
            let vspec1 = vref1.Deref
            let vspec2 = vref2.Deref
            (* this is the body of the override *)
            let rhs1 = 
              let tinst,ty = minimal_type g tcref
              
              let thisv,thise = mk_thisv g m ty  
              let thatobjv,thatobje = mk_compgen_local m "obj" g.obj_ty  
              let comparee = 
                  if is_unit_typ g ty then mk_zero g m else
                  let thate = mk_coerce (thatobje, ty, m, g.obj_ty)

                  mk_appl g ((expr_for_vref m vref2,vref2.Type), (if isNil tinst then [] else [tinst]), [thise;thate], m)
              
              mk_lambdas m tps [thisv;thatobjv] (comparee,g.int_ty)  
            let rhs2 = 
              let thisv,thatv,comparee = comparef g tcref tycon 
              mk_lambdas m tps [thisv;thatv] (comparee,g.int_ty)  
            [ // This one must come first because it may be inlined into the second
              mk_compgen_bind vspec2 rhs2;
              mk_compgen_bind vspec1 rhs1; ] 
    if tycon.IsUnionTycon then mk_compare mk_union_compare 
    elif tycon.IsRecordTycon || tycon.IsStructOrEnumTycon then mk_compare mk_recd_compare 
    else []
    
let MakeBindingsForCompareWithComparerAugmentation g (tycon:Tycon) =
    let tcref = mk_local_tcref tycon
    let m = tycon.Range
    let tps = tycon.Typars(tycon.Range)
    let mk_compare comparef = 
        match tycon.GeneratedCompareToWithComparerValues with
        | None -> []
        | Some (vref) ->
            let vspec = vref.Deref
            let _,ty = minimal_type g tcref

            let compv,compe = mk_compgen_local m "comp" g.mk_IComparer_ty

            let thisv,thise = mk_thisv g m ty
            let thatobjv,thatobje = mk_compgen_local m "obj" g.obj_ty
            let thate = mk_coerce (thatobje, ty, m, g.obj_ty)

            let rhs =
                let comparee = comparef g tcref tycon (thisv,thise) (thatobjv,thate) compe
                let comparee = if is_unit_typ g ty then mk_zero g m else comparee
                mk_multi_lambdas m tps [[thisv];[thatobjv;compv]] (comparee,g.int_ty)
            [mk_compgen_bind vspec rhs]
    if tycon.IsUnionTycon then mk_compare mk_union_compare_withc
    elif tycon.IsRecordTycon || tycon.IsStructOrEnumTycon then mk_compare mk_recd_compare_withc
    else []    
    
let MakeBindingsForEqualityWithComparerAugmentation g (tycon:Tycon) =
    let tcref = mk_local_tcref tycon
    let m = tycon.Range
    let tps = tycon.Typars(tycon.Range)
    let mk_structural_equatable hashf equalsf =
        match tycon.GeneratedHashAndEqualsWithComparerValues with
        | None -> []
        | Some (objGetHashCodeVal,withcGetHashCodeVal,withcEqualsVal) ->
            
            // build the hash rhs
            let withcGetHashCodeExpr =
                let compv,compe = mk_compgen_local m "comp" g.mk_IEqualityComparer_ty
                let thisv,hashe = hashf g tcref tycon compe
                mk_lambdas m tps [thisv;compv] (hashe,g.int_ty)
                
            // build the equals rhs
            let withcEqualsExpr =
                let _tinst,ty = minimal_type g tcref
                let thisv,thise = mk_thisv g m ty
                let thatobjv,thatobje = mk_compgen_local m "obj" g.obj_ty
                let thatv,thate = mk_compgen_local m "that" ty  
                let compv,compe = mk_compgen_local m "comp" g.mk_IEqualityComparer_ty
                let equalse = equalsf g tcref tycon (thisv,thise) thatobje (thatv,thate) compe
                mk_multi_lambdas m tps [[thisv];[thatobjv;compv]] (equalse,g.bool_ty)


            let objGetHashCodeExpr = 
                let tinst,ty = minimal_type g tcref
                
                let thisv,thise = mk_thisv g m ty  
                let unitv,_ = mk_compgen_local m "unitArg" g.unit_ty
                let hashe = 
                    if is_unit_typ g ty then mk_zero g m else

                    let compe = mk_call_GetEqualityComparer g m
                    mk_appl g ((expr_for_vref m withcGetHashCodeVal,withcGetHashCodeVal.Type), (if isNil tinst then [] else [tinst]), [thise; compe], m)
                
                mk_lambdas m tps [thisv; unitv] (hashe,g.int_ty)  
                  
            [(mk_compgen_bind withcGetHashCodeVal.Deref withcGetHashCodeExpr) ; 
             (mk_compgen_bind objGetHashCodeVal.Deref objGetHashCodeExpr) ; 
             (mk_compgen_bind withcEqualsVal.Deref withcEqualsExpr)] 
    if tycon.IsUnionTycon then mk_structural_equatable mk_union_hash_withc mk_union_equality_withc
    elif (tycon.IsRecordTycon || tycon.IsStructOrEnumTycon) then mk_structural_equatable mk_recd_hash_withc mk_recd_equality_withc
    elif tycon.IsExceptionDecl then mk_structural_equatable mk_exnconstr_hash_withc mk_exnconstr_equality_withc
    else []

let MakeBindingsForEqualsAugmentation g (tycon:Tycon) = 
    let tcref = mk_local_tcref tycon 
    let m = tycon.Range 
    let tps = tycon.Typars(m)
    let mk_equals equalsf =
      match tycon.GeneratedHashAndEqualsValues with 
      | None ->  []
      | Some (objEqualsVal,nocEqualsVal) -> 
          // this is the body of the real strongly typed implementation 
          let nocEqualsExpr = 
              let thisv,thatv,equalse = equalsf g tcref tycon 
              mk_lambdas m tps [thisv;thatv] (equalse,g.bool_ty)  

          // this is the body of the override 
          let objEqualsExpr = 
            let tinst,ty = minimal_type g tcref
            
            let thisv,thise = mk_thisv g m ty  
            let thatobjv,thatobje = mk_compgen_local m "obj" g.obj_ty  
            let equalse = 
                if is_unit_typ g ty then mk_true g m else

                let thatv,thate = mk_compgen_local m "that" ty  
                mk_isinst_cond g m ty thatobje thatv 
                    (mk_appl g ((expr_for_vref m nocEqualsVal,nocEqualsVal.Type), (if isNil tinst then [] else [tinst]), [thise;thate], m))
                    (mk_false g m)
            
            mk_lambdas m tps [thisv;thatobjv] (equalse,g.bool_ty)  


          [ mk_compgen_bind nocEqualsVal.Deref nocEqualsExpr;
            mk_compgen_bind objEqualsVal.Deref objEqualsExpr;   ] 
    if tycon.IsExceptionDecl then mk_equals mk_exnconstr_equality 
    elif tycon.IsUnionTycon then mk_equals mk_union_equality 
    elif tycon.IsRecordTycon || tycon.IsStructOrEnumTycon then mk_equals mk_recd_equality 
    else []

let rec ApproxTypeHasEquality g ty = 
    if is_stripped_tyapp_typ g ty && HasAttrib g g.attrib_NoEqualityAttribute (tcref_of_stripped_typ g ty).Attribs then
        false
    else 
        match ty with 
        | SpecialEquatableHeadType g tinst -> 
            tinst |> List.forall (ApproxTypeHasEquality g)
        | SpecialNotEquatableHeadType g _ -> 
            false
        | _ -> 
           // The type is equatable because it has Object.Equals(...)
           is_stripped_tyapp_typ g ty &&
           let tcref,tinst = dest_stripped_tyapp_typ g ty 
           // Give a good error for structural types excluded from the equality relation because of their fields
           not (TyconIsCandidateForAugmentationWithEquals g tcref.Deref && isNone tcref.GeneratedHashAndEqualsWithComparerValues) &&
           // Check the (possibly inferred) structural dependencies
           (tinst, tcref.TyparsNoRange) ||> List.lengthsEqAndForall2 (fun ty tp -> not tp.EqualityConditionalOn || ApproxTypeHasEquality  g ty)

