//==========================================================================
// (c) Microsoft Corporation 2005-2009.  
//==========================================================================

module Microsoft.FSharp.Compiler.Interactive.Attributes
[<assembly: AutoOpen("Microsoft.FSharp.Compiler.Interactive.Settings")>]
do()

