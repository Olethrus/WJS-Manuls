// (c) Microsoft Corporation 2005-2009.
module internal Microsoft.FSharp.Compiler.AbstractIL.Extensions.ILX.Ilxconfig
open Microsoft.FSharp.Compiler.AbstractIL
open Microsoft.FSharp.Compiler.AbstractIL.Extensions.ILX
let defaultTailcallImplementation = Ilxsettings.AllTailcalls  
let defaultIlxCallImplementation = Ilxsettings.VirtEntriesVirtCode 
