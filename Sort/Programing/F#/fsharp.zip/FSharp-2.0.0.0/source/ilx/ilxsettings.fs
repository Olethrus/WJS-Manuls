// (c) Microsoft Corporation. All rights reserved
module internal Microsoft.FSharp.Compiler.AbstractIL.Extensions.ILX.Ilxsettings 


type ilxCallImplementation = 
  | VirtEntriesVirtCode
#if CLOSURES_VIA_POINTERS
  | VirtEntriesPtrCode
#endif

type ilxTailcallImplementation = 
  | AllTailcalls
  | NoTailcalls

