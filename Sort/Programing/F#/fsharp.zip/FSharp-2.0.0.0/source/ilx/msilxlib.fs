// (c) Microsoft Corporation. All rights reserved

module internal Microsoft.FSharp.Compiler.AbstractIL.Extensions.ILX.Msilxlib

open Internal.Utilities
open Microsoft.FSharp.Compiler.AbstractIL 
open Microsoft.FSharp.Compiler.AbstractIL.IL 
open Microsoft.FSharp.Compiler.AbstractIL.Internal 
open Microsoft.FSharp.Compiler.AbstractIL.Extensions.ILX

open Ilxsettings

let ilxCompilingFSharpCoreLib = ref false

let ilxFsharpCoreLibAssemRef = ref (None : ILAssemblyRef option)

#if CLOSURES_VIA_POINTERS
(* How are closures implemented? *)
let ilxCallImplementation = ref Ilxconfig.defaultIlxCallImplementation
#endif
let ilxTailcallImplementation = ref Ilxsettings.AllTailcalls  

/// Scope references for FSharp.Core.dll
let ilxFsharpCoreLibScopeRef () =
    if !ilxCompilingFSharpCoreLib then 
        ScopeRef_local 
    else 
        let assref = 
            match !ilxFsharpCoreLibAssemRef with 
            | Some o -> o
            | None -> 
                 // The exact public key token and version used here don't actually matter, or shouldn't.
                 // ilxFsharpCoreLibAssemRef is only 'None' for startup code paths such as
                 // IsSignatureDataVersionAttr, where matching is done by assembly name strings
                 // rather then versions and tokens.
                ILAssemblyRef.Create("FSharp.Core", None, 
                                     Some (PublicKeyToken(Bytes.ofInt32Array [| 0xb0; 0x3f; 0x5f; 0x7f; 0x11; 0xd5; 0x0a; 0x3a |])),
                                     false, 
                                     Some (IL.parse_version Internal.Utilities.FSharpEnvironment.FSharpTeamVersionNumber), None)
        ScopeRef_assembly assref

let ilxNamespace () =  "Microsoft.FSharp.Core"

