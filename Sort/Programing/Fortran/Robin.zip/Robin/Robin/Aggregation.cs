﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public class Aggregation
  {
    public static Aggregation NullAggregation = Aggregation.it();

    public static Aggregation it()
    {
      return new Aggregation();
    }

    protected List<Definition> definitions = null;

    public virtual List<Definition> Definitions
    {
      get
      {
        return this.definitions ?? (this.definitions = new List<Definition>());
      }
    }

    public Aggregation()
    {
    }

    public virtual Definition GetDefinition(Signal s)
    {
      Definition definition = null;
      
      for (int i = 0; i < this.Definitions.Count; i++)
      {
        Definition def = this.Definitions[i];

        if (def != null && def.Target.Match(s))
        {
          definition = def;
          break;
        }
      }

      return definition;
    }
    public virtual void ResetTerminators()
    {
      for (int i = 0; i < this.Definitions.Count; i++)
      {
        Definition def = this.Definitions[i];

        if (def != null)
        {
          def.Terminators.Clear();
        }
      }
    }
    public virtual bool DeeplyContainsDefinition(Definition container, Definition definition)
    {
      return this.DeeplyContainsDefinition(container, definition, false);
    }
    public virtual bool DeeplyContainsDefinition(Definition container, Definition definition, bool selfresult)
    {
      bool contains = false;

      if (container != null && definition != null)
      {
        for (int i = 0; !contains && (i < container.Patterns.Count); i++)
        {
          Pattern pattern = container.Patterns[i];

          if (pattern != null)
          {
            if (pattern.Sequence.Contains(definition.Target))
            {
              contains = true;

              break;
            }
            else
            {
              for (int j = 0; j < pattern.Sequence.Count; j++)
              {
                Definition c = this.GetDefinition(pattern.Sequence[j]);

                if (c == container)
                {
                  contains = selfresult;
                }
                if (contains)
                {
                  break;
                }
                else if (c != null && c!=container && this.DeeplyContainsDefinition(c, definition))
                {
                  contains = true;
                  break;
                }
              }
            }
          }
        }
      }

      return contains;
    }

    public virtual bool GetTerminators(Definition definition, List<Signal> terminators)
    {
      if (terminators != null && this.GetTerminators(definition, definition, terminators))
      {
        if (!terminators.Contains(Signal.EOF))
        {
          terminators.Add(Signal.EOF);

          return true;
        }
      }
      return false;
    }


    protected virtual bool GetTerminators(Definition definition,Definition original, List<Signal> terminators)
    {
      if (definition != null && original!=null)
      {
        for (int i = 0; i < this.Definitions.Count; i++)
        {
          Definition def = this.Definitions[i];

          if (def != null)
          {
            for (int j = 0; j < def.Patterns.Count; j++)
            {
              Pattern pat = def.Patterns[j];

              if (pat != null && !pat.IsOptional)
              {
                int index = pat.Sequence.LastIndexOf(definition.Target);
                int last = pat.Sequence.Count - 1;
                if (index >= 0)
                {
                  if (index == last)
                  {
                    //是最后一个,对其进行搜索。
                    if (pat.Definition != original)
                    {
                      GetTerminators(pat.Definition, original, terminators);
                    }
                  }
                  //不是最后一个，添加各种情况，包括可选的。
                  {
                    index = 0;

                    while (index>=0)
                    {
                      int steps = 0;

                      index = pat.Sequence.IndexOf(definition.Target,index);

                      if (index < 0)
                      {
                        break;
                      }
                      else
                      {
                        pat.PeekNonOptional(index + 1, out steps);

                        index += 1;

                        for (int t = index; t <= index + steps; t++)
                        {
                          if (t <= last)
                          {
                            Signal next = pat.Sequence[t];

                            if (!terminators.Contains(next))
                            {
                              terminators.Add(next);
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
        return true;
      }
      return false;
    }
  }
}
