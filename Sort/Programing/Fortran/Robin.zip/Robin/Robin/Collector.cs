﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public class Collector
  {
    public static Collector of(Matcher matcher)
    {
      return new Collector(matcher);
    }

    protected Matcher matcher = null;

    protected List<Matcher> matchers = null;

    public virtual Matcher Matcher
    {
      get
      {
        return this.matcher;
      }
    }
    public virtual Definition Definition
    {
      get
      {
        return this.matcher.Definition;
      }
    }
    public virtual List<Matcher> Matchers
    {
      get
      {
        return this.matchers ?? (this.matchers = new List<Matcher>());
      }
    }

    public Collector(Matcher matcher)
    {
      if ((this.matcher = matcher) == null) throw new ArgumentNullException("matcher");
    }

    public virtual bool Collect(List<Signal> input, List<Signal> output, SignalTreeNode node,SignalPrefix prefix)
    {
      bool accepted = false;

      if (input != null && output != null && node != null && prefix!=null)
      {
        Matcher matcher = this.EnsureMathcer(prefix);

        if (matcher !=null)
        {
          if (matcher.Match(input, output, node,prefix))
          {
            accepted = true;
          }
        }
      }
      return accepted;
    }

    public virtual Matcher EnsureMathcer(SignalPrefix prefix)
    {
      Matcher matcher = null;

      if (prefix != null)
      {
        if ((matcher = this.FindMatcher(prefix)) == null)
        {
          //添加新的m用于符合Parser的Prefix规定
          matcher = this.EnterMatcher(prefix);
        }
      }
      return matcher;
    }

    public virtual Matcher EnterMatcher(SignalPrefix prefix)
    {
      Matcher m = null;

      if (prefix != null)
      {
        //不保持pattern
        if ((m = this.Matcher.Clone(prefix)) != null)
        {
          m = this.EnterMatcher(m);
        }
      }
      return m;
    }
    public virtual Matcher EnterMatcher(Matcher matcher)
    {
      if (matcher != null)
      {
        this.Matchers.Insert(0, matcher);
      }
      return matcher;
    }
    public virtual Matcher FindMatcher(SignalPrefix prefix)
    {      
      for (int i = 0; i < this.Matchers.Count; i++)
      {
        Matcher matcher = this.Matchers[i];

        if (matcher != null && matcher.Prefix.Match(prefix))
        {
          return matcher;
        }
      }
      return null;
    }
    public virtual void CompleteMatchers()
    {
      for (int i = 0; i < this.Matchers.Count; i++)
      {
        Matcher matcher = this.Matchers[i];

        if (matcher != null)
        {
          if (matcher.IsSignleton || matcher.IsLeaf)
          {
            matcher.QuitPattern();
          }
          matcher.Complete();
        }
      }
    }
    public virtual void LeaveMatcherBridgings()
    {
      for (int i = 0; i < this.Matchers.Count; i++)
      {
        Matcher matcher = this.Matchers[i];

        if (matcher != null)
        {
          matcher.LeaveBridging();
        }
      }
    }
    public virtual int RemoveMatchers(SignalPrefix prefix)
    {
      int count = 0;

      for (int i = 0; i < this.Matchers.Count; i++)
      {
        Matcher matcher = this.Matchers[i];

        if (matcher != null)
        {
          if (matcher.Prefix.Match(prefix))
          {
            if (this.Matchers.Remove(matcher))
            {
              count++;
            }
          }
        }
      }
      return count;
    }

    public override string ToString()
    {
      return this.Matcher != null ? this.Matcher.ToString() : string.Empty;
    }
  }
}
