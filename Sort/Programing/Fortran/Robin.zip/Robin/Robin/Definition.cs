﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public class Definition
  {
    public static Definition NullDefinition = Definition.of(Aggregation.NullAggregation, string.Empty);

    public static Definition of(Aggregation aggregation,string name)
    {
      return new Definition(aggregation,name);
    }

    protected List<Signal> terminators = null;

    protected Aggregation aggregation = null;

    protected Signal target = Signal.Null;

    protected List<Pattern> patterns = null;

    public virtual Aggregation Aggregation
    {
      get
      {
        return this.aggregation;
      }
    }
    public virtual List<Signal> Terminators
    {
      get
      {
        if (this.terminators == null)
        {
          if ((this.terminators = new List<Signal>())!=null)
          {
            this.Aggregation.GetTerminators(this, this.terminators);
          }
        }
        return this.terminators;
      }
    }
    public virtual string Name
    {
      get
      {
        return this.target.Value;
      }
    }

    public virtual Signal Target
    {
      get
      {
        return this.target;
      }
    }

    public virtual List<Pattern> Patterns
    {
      get
      {
        return this.patterns ?? (this.patterns = new List<Pattern>());
      }
    }

    /// <summary>
    /// If one pattern is recursive, the whole definition is recursive
    /// </summary>
    public virtual bool IsRecursive
    {
      get
      {
        bool r = false;
        for (int i = 0; i < this.Patterns.Count; i++)
        {
          Pattern p = this.Patterns[i];
          if (p != null)
          {
            if (r |= p.IsRecursive)
            {
              break;
            }
          }
        }
        return r;
      }
    }
    /// <summary>
    /// If one pattern is optional, the whole definition is optional.
    /// </summary>
    public virtual bool IsOptional
    {
      get
      {
        bool r = false;
        for (int i = 0; i < this.Patterns.Count; i++)
        {
          Pattern p = this.Patterns[i];
          if (p != null)
          {
            if (r |= p.IsOptional)
            {
              break;
            }
          }
        }
        return r;
      }
    }
    public virtual bool IsCycler
    {
      get
      {
        return this.Aggregation.DeeplyContainsDefinition(this, this);
      }
    }
    public Definition(Aggregation aggregation, string name)
    {
      if ((this.aggregation = aggregation) == null) throw new ArgumentNullException("agregation");

      this.target = Signal.of(name ?? string.Empty,false);
    }

    public virtual bool CreateMatchers(Parser parser,List<Matcher> matchers)
    {
      if (parser!=null && matchers != null)
      {
        for (int i = 0; i < this.Patterns.Count; i++)
        {
          Pattern pattern = this.Patterns[i];

          if (pattern != null)
          {
            Matcher matcher = Matcher.of(parser, pattern, null);

            if (matcher != null)
            {
              matchers.Add(matcher);
            }
          }
        }

        return true;
      }
      return false;
    }


    public override string ToString()
    {
      return this.Target.Value;
    }
  }
}
