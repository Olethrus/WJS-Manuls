﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public class Matcher
  {
    public static Matcher NullMatcher = of(Parser.NullParser, Pattern.NullPattern,SignalPrefix.NullSignalPrefix);

    public static Matcher of(Parser parser, Pattern pattern, SignalPrefix prefix)
    {
      return new Matcher(parser, pattern, prefix);
    }

    protected Parser parser = null;

    protected Pattern pattern = null;

    protected SignalPrefix prefix = null;

    protected Stack<Pattern> patterns = null;

    protected bool quiting = false;

    protected int level = 0;

    protected SignalTree tree = null;

    public virtual SignalTree Tree
    {
      get
      {
        if (this.IsBridging)
        {
          return this.tree;
        }
        return this.PatternTree;
      }
    }
    public virtual SignalTree PatternTree
    {
      get
      {
        return this.IsWorking ? this.CurrentPattern.Tree : null;
      }
    }
    public virtual int CurrentLevel
    {
      get
      {
        return this.level;
      }
    }
    public virtual bool IsBridging
    {
      get
      {
        return this.level>0;
      }
    }
    public virtual bool IsCommonBridging
    {
      get
      {
        return this.level == 1;
      }
    }
    public virtual bool IsRepeativeBridging
    {
      get
      {
        return this.level > 1;
      }
    }

    public virtual Parser Parser
    {
      get
      {
        return this.parser;
      }
    }
    public virtual Pattern Pattern
    {
      get
      {
        return this.pattern;
      }
    }
    public virtual Signal Target
    {
      get
      {
        return this.Definition != null ? this.Definition.Target : Signal.Null;
      }
    }
    public virtual bool IsRecursive
    {
      get
      {
        return this.pattern != null ? this.pattern.IsRecursive : false;
      }
    }
    public virtual bool IsSimpleRecursive
    {
      get
      {
        return this.pattern != null ? this.pattern.IsSimpleRecursive : false;
      }
    }
    public virtual bool IsOptional
    {
      get
      {
        return this.pattern != null ? this.pattern.IsOptional : false;
      }
    }
    public virtual bool IsSignleton
    {
      get
      {
        return this.pattern != null ? this.pattern.IsSignleton : false;
      }
    }
    public virtual bool IsLeaf
    {
      get
      {
        return this.pattern != null ? this.pattern.IsLeaf : false;
      }
    }
    public virtual bool IsDot
    {
      get
      {
        return this.pattern != null ? this.pattern.IsDot : false;
      }
    }
    public virtual bool IsWorking
    {
      get
      {
        return this.Patterns.Count > 0;
      }
    }
    public virtual Stack<Pattern> Patterns
    {
      get
      {
        return this.patterns ?? (this.patterns = new Stack<Pattern>());
      }
    }
    public virtual Definition Definition
    {
      get
      {
        return this.pattern != null ? this.pattern.Definition : null;
      }
    }
    public virtual Pattern CurrentPattern
    {
      get
      {
        return this.IsWorking ? this.Patterns.Peek() : null;
      }
    }
    public virtual int CurrentPosition
    {
      get
      {
        return this.IsWorking ? this.CurrentPattern.Position : 0;
      }
    }
    public virtual SignalPrefix Prefix
    {
      get
      {
        return this.prefix;
      }
    }

    public Matcher(Parser parser, Pattern pattern, SignalPrefix prefix)
    {
      if ((this.parser = parser) == null) throw new ArgumentNullException("parser");
      if ((this.pattern = pattern) == null) throw new ArgumentNullException("pattern");

      if (prefix != null)
      {
        this.prefix = SignalPrefix.of(prefix);
      }
    }
    public virtual Prefix LinkPrefix()
    {
      return this.Prefix.AddPrefix(Robin.Prefix.of(this));
    }
    public virtual Prefix UnlinkPrefix()
    {
      return this.Prefix.RemovePrefix(Robin.Prefix.of(this));
    }

    public virtual bool MatchPrefix(SignalPrefix prefix)
    {
      if (prefix != null)
      {
        return this.Prefix.Match(prefix);
      }
      return false;
    }
    public virtual bool MatchPrefix(Signal s)
    {
      if (prefix != null)
      {
        return this.Prefix.MatchLast(s);
      }
      return false;
    }
    public virtual int EnterBridging()
    {
      int bn = this.level++;

      return bn;
    }
    public virtual int LeaveBridging()
    {
      int bn = this.level > 0 ? this.level-- : 0;

      if (bn == 0)
      {
        if (tree != null)
        {
          this.tree = null;
        }
      }

      return bn;
    }
    public virtual bool Match(List<Signal> input, List<Signal> output, SignalTreeNode node, SignalPrefix prefix)
    {
      bool accepted = false;

      Signal? result = null;

      if (!this.IsDot
        && input != null
        && output != null 
        && node != null 
        && prefix != null
        )
      {
        Signal signal = Signal.Null;
        Status status = Status.Rejected;

        bool init = false;

        bool found = false;

        bool pass = false;

        for (int i = 0; !found && i < input.Count; i++)
        {
          signal = input[i];

          Pattern pattern = this.CurrentPattern;

          if (pattern != null)
          {
            if ((status = pattern.Accept(signal)) == Status.Accepted)
            {
              accepted = true;

              found = true;

              if (pattern.IsRecursive)
              {
                pattern.Advance();
                pattern.Recursing = true;
                pattern.Shifting = true;
                pattern.Accepted = true;
              }
              else
              {
                pattern.Accepted = true;
              }

              if (!this.Definition.IsOptional)
              {
                //如果当前定义是可选的，而且模式是递归的，则不能输出。
                if (!pattern.IsRecursive)
                {
                  if (!output.Contains(pattern.Target))
                  {
                    result = pattern.Target;
                  }
                }
              }

            }
            else if (status == Status.Initializing || status == Status.Shifting)
            {
              int steps = 0;

              Definition d = pattern.PeekNonOptional(out steps);

              if (d != null)
              {
                if (!pattern.IsRecursive)
                {
                  if (!d.Target.Match(signal) && steps > 0)
                  {
                    pattern.Advance(steps);

                    i--;

                    continue;
                  }
                }
              }

              found = true;

              pass = true;

              pattern.Shifting = true;

              init = status == Status.Initializing;
            }
            else if (status == Status.Rejected)
            {
              int steps = 0;

              Definition d = pattern.PeekNonOptional(out steps);

              if (d != null && d.Target.Match(signal) && steps > 0)
              {
                pattern.Advance(steps);

                i--;

                continue;
              }

              if (pattern.IsRecursive)
              {
                if (pattern.Definition.Terminators.Contains(signal))
                {
                  this.QuitBrothers(prefix);

                  pattern.Accepted = true;

                  accepted = true;

                  found = true;

                  //模式是递归的，如果定义还是可选的，则应当释放。
                  //if (pattern.Definition.IsOptional)
                  //{
                  //  if (!output.Contains(pattern.Target))
                  //  {
                  //    result = pattern.Target;
                  //  }
                  //}
                }
              }
            }
          }

          if (!found && !signal.Match(this.Target))
          {
            if ((pattern = this.Pattern) != null)
            {
              if ((status = pattern.Accept(signal)) == Status.Initializing)
              {
                found = true;

                //不要等待，直接强制移进一步。
                if ((pattern = this.EnterPattern(prefix)) != null)
                {
                  pattern.Advance();

                  init = true;

                  pass = true;
                }
              }
              else if (status == Status.Accepted)
              {
                accepted = true;

                found = true;

                pass = true;

                if (!output.Contains(pattern.Target))
                {
                  //对于立即接受，不发放递归和自含。
                  if (!this.IsRecursing(prefix))
                  {
                    result = pattern.Target;

                    if ((pattern = this.EnterPattern(prefix)) != null)
                    {
                      //置于已经接受的状态。
                      pattern.Accepted = true;

                      if (this.Definition.IsRecursive)
                      {
                        this.ResetRecursiveBrothers(prefix);
                      }
                    }
                  }
                }
              }
            }
          }
        } //for loop

        SignalTreeNode cn = null;

        if (found)
        {
          cn = this.Compose(signal, node, prefix);
        }

        if (pass && cn != null && prefix.MatchLast(signal))
        {
          //输入信号已经被接受，且符合前缀最顶层，应将获得的树标记为无效，防止再次使用。

          cn.SetValid(false);
        }

        //当前正在控制中
        if (prefix.MatchLast(Robin.Prefix.of(this)))
        {
          if (this.IsWorking && this.CurrentPattern.Accepted || accepted)
          {
            if (!this.Parser.Leaving)
            {
              this.Parser.Leaving = true;
              
              this.QuitPattern();

              //下一个字符将具有新的前缀（去掉当前前缀）

              //输出稍小一点的信号：修改前缀副本，本次字符范围有效

              prefix.RemovePrefix(this.UnlinkPrefix()); //去掉自己的Prefix，准备迎接新的输入
            }
          }
        }

        if (init && this.Definition.IsCycler && !this.IsRecursive)
        {
          //延迟进入前缀状态：下一个字符将具有新的前缀（增加当前前缀）
          this.Parser.Prefixer = prefix.AddPrefix(this.LinkPrefix());//安装自己的Prefix
          //设定为桥接
          this.EnterBridging();
        }

        if (result.HasValue)
        {
          output.Add(result.Value.WithPrefix(prefix));
        }
      }
      return accepted;
    }



    protected virtual SignalTreeNode Compose(Signal s, SignalTreeNode node, SignalPrefix prefix)
    {
      if (node != null && prefix!=null && this.IsWorking)
      {
        SignalTree tree = this.CurrentPattern.Tree;

        SignalTreeNode cn = this.Parser.GatherTrees(s, prefix);

        if (cn != null)
        {
          if (cn.Trees.Count > 0)
          {
            tree.Sequance.Add(cn);

            if (!node.Trees.Contains(tree))
            {
              node.Trees.Add(tree);
            }
            return cn;
          }
        }
      }
      return null;
    }
    protected virtual bool ResetRecursiveBrothers(SignalPrefix prefix)
    {
      List<Matcher> brothers = new List<Matcher>();

      if (this.GetBrothers(brothers, prefix))
      {
        for (int u = 0; u < brothers.Count; u++)
        {
          Matcher brother = brothers[u];

          if (brother != null && brother!=this && brother.IsRecursive)
          {
            Pattern p = null;

            //用Reset还是用Enter？
            if ((p = brother.ResetPattern(prefix)) != null)
            {

            }
          }
        }
        return true;
      }
      return false;
    }
    protected virtual bool QuitBrothers(SignalPrefix prefix)
    {
      List<Matcher> siblings = new List<Matcher>();

      if (this.GetBrothers(siblings, prefix))
      {
        for (int u = 0; u < siblings.Count; u++)
        {
          Matcher sibling = siblings[u];

          if (sibling != null)
          {
            sibling.QuitPattern();
          }
        }
        return true;
      }
      return false;
    }
    protected virtual bool GetBrothers(List<Matcher> brothers, SignalPrefix prefix)
    {
      return this.parser.GetMatchers(this.Definition, brothers, prefix);
    }

    public virtual Pattern ResetPattern(SignalPrefix prefix)
    {
      this.QuitPattern();

      return this.EnterPattern(prefix);
    }

    public virtual Pattern EnterPattern(SignalPrefix prefix)
    {
      Pattern p = this.Pattern.Clone(this.Target,this.Parser.NextPosition(),prefix);

      if (p != null)
      {
        this.Patterns.Push(p);
      }
      return p;
    }

    public virtual Pattern QuitPattern()
    {
      //注意：因为仅有自含匹配才会发生Quit，所以，仅记录自含的最后一个tree

      Pattern p = this.IsWorking ? this.Patterns.Pop() : null;

      if (p != null && this.IsBridging)
      {
        this.tree = p.Tree;
      }
      return p;
    }
    public virtual void Complete()
    {
      if (this.IsWorking)
      {
        this.CurrentPattern.Shift();
      }

      if (this.quiting)
      {
        this.QuitPattern();

        this.quiting = false;
      }
    }
    public override string ToString()
    {
      return this.Target.ToString();
    }

    public virtual Matcher Clone(SignalPrefix prefix)
    {
      return Matcher.of(this.parser, this.pattern, prefix);
    }

    public virtual bool GetLeaf(ref Signal s)
    {
      return this.Pattern.GetLeaf(ref s);
    }

    protected virtual bool IsRecursing(SignalPrefix prefix)
    {
      bool recursing = false;

      List<Matcher> matchers = new List<Matcher>();

      if (this.GetBrothers(matchers, prefix))
      {
        for (int u = 0; u < matchers.Count; u++)
        {
          Matcher matcher = matchers[u];

          if (matchers != null && matcher.IsWorking && matcher.CurrentPattern.Recursing)
          {
            recursing = true;
            break;
          }
        }
      }
      return recursing;
    }

  }
}
