﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public class Parser
  {
    public static Parser NullParser = Parser.it();

    public static Parser it()
    {
      return new Parser();
    }

    protected Aggregation aggregation = null;

    protected List<Collector> collectors = null;

    protected Stack<SignalTreeNode> nodes = null;

    protected SignalPrefix defaultPrefix = null;

    protected bool leaving = false;

    protected Prefix prefixer = Prefix.NullPrefix;

    protected int position = 0;

    public virtual SignalPrefix DefaultPrefix
    {
      get
      {
        return this.defaultPrefix ?? (this.defaultPrefix = SignalPrefix.it());
      }
    }
    public virtual Aggregation Aggregation
    {
      get
      {
        return this.aggregation ?? (this.aggregation = Aggregation.it());
      }
    }

    public virtual List<Collector> Collectors
    {
      get
      {
        return this.collectors ?? (this.collectors = new List<Collector>());
      }
    }
    public virtual Stack<SignalTreeNode> Nodes
    {
      get
      {
        return this.nodes ?? (this.nodes = new Stack<SignalTreeNode>());
      }
    }
    public virtual bool IsWorking
    {
      get
      {
        return this.Nodes.Count > 0;
      }
    }
    public virtual SignalTreeNode CurrentNode
    {
      get
      {
        return this.IsWorking ? this.Nodes.Peek() : null;
      }
    }

    public virtual bool Leaving
    {
      get
      {
        return this.leaving;
      }
      set
      {
        this.leaving = value;
      }
    }
    public virtual Prefix Prefixer
    {
      get
      {
        return this.prefixer;
      }
      set
      {
        this.prefixer = value;
      }
    }

    public virtual int Position
    {
      get
      {
        return this.position;
      }
    }

    public Parser()
    {

    }
    public virtual void InitNodes()
    {
      this.ClearNodes();
      this.EnterCollecting();
    }
    public virtual void ClearNodes()
    {
      this.Nodes.Clear();
    }


    public virtual void CompletePrefixing()
    {
      if (!this.Prefixer.Equals(Prefix.NullPrefix))
      {
        this.EnterPrefixing(this.prefixer);

        this.prefixer = Prefix.NullPrefix;
      }
      if (this.leaving)
      {
        this.LeavePrefixing();
        
        this.leaving = false;
      }
    }

    public virtual SignalTreeNode EnterCollecting()
    {
      SignalTreeNode node = SignalTreeNode.it();

      if (node != null)
      {
        this.Nodes.Push(node);
      }
      return node;
    }
    public virtual SignalTreeNode LeaveCollecting()
    {
      SignalTreeNode node = this.IsWorking ? this.Nodes.Pop() : null;
      
      if (node != null && this.IsWorking)
      {
        for (int i = 0; i < node.Trees.Count; i++)
        {
          SignalTree tree = node.Trees[i];

          if (tree != null && tree.Prefix.Match(this.DefaultPrefix))
          {
            if (!this.CurrentNode.Trees.Contains(tree))
            {
              this.CurrentNode.Trees.Add(tree);
            }
          }
        }
        //this.Compact(this.CurrentNode);


        this.LeaveBridgings();
      }


      return node;
    }

    public virtual void LeaveBridgings()
    {
      for (int i = 0; i < this.Collectors.Count; i++)
      {
        Collector c = this.Collectors[i];
        if (c != null)
        {
          c.LeaveMatcherBridgings();
        }
      }
    }

    public virtual void EnterPrefixing(Prefix prefix)
    {
      this.DefaultPrefix.AddPrefix(prefix);

      this.EnterCollecting();
    }

    public virtual void LeavePrefixing()
    {
      //修剪掉原来的
      this.TrimCollectors(this.DefaultPrefix);
      //改变前缀
      this.DefaultPrefix.RemovePrefix();

      this.LeaveCollecting();


    }

    public virtual int TrimCollectors()
    {
      return this.TrimCollectors(this.DefaultPrefix);
    }

    public virtual int TrimCollectors(SignalPrefix prefix)
    {
      int count = 0;

      if (prefix != null)
      {
        for (int i = 0; i < this.Collectors.Count; i++)
        {
          Collector collector = this.Collectors[i];

          if (collector != null)
          {
            count += collector.RemoveMatchers(prefix);
          }
        }
      }
      return count;
    }

    public virtual SignalTreeNode Parse(string text, bool compact)
    {
      this.InitNodes();
      this.position = 0;

      if (text != null)
      {
        for (int i = 0; i <= text.Length; i++)
        {
          Signal signal = (i < text.Length ? Signal.of(text[i],true) : Signal.EOF);

          //使用当前前缀的副本而不是直接使用当前前缀。
          this.Parse(signal, this.CurrentNode, SignalPrefix.of(this.DefaultPrefix));
        }
        if (compact)
        {
          this.Compact(this.CurrentNode);
        }
      }
      return this.CurrentNode;
    }

    protected virtual void Parse(Signal signal, SignalTreeNode node,SignalPrefix prefix)
    {
      if (node != null && prefix!=null)
      {
        uint count = 0;

        List<Signal> output = new List<Signal>();
        List<Signal> signals = new List<Signal>();

        signals.Add(signal.WithPrefix(prefix));

        do
        {

          count = 0;

          output.Clear();

          for (int i = 0; i < this.Collectors.Count; i++)
          {
            Collector collector = this.Collectors[i];

            if (collector != null)
            {
              if (collector.Collect(signals, output, node, prefix))
              {
                count++;
              }
            }
          }

          signals.Clear();
          signals.AddRange(output);

        }
        while (count > 0); //possible dead loop

        this.CompleteCollectors();

        this.CompletePrefixing();

      }
    }

    protected virtual void CompleteCollectors()
    {
      for (int i = 0; i < this.Collectors.Count; i++)
      {
        Collector collector = this.Collectors[i];

        if (collector != null)
        {
          collector.CompleteMatchers();
        }
      }
    }

    public virtual bool GetMatchers(List<Matcher> matchers, SignalPrefix prefix)
    {
      if (matchers != null && prefix != null)
      {
        for (int i = 0; i < this.Collectors.Count; i++)
        {
          Collector collector = this.Collectors[i];

          if (collector != null)
          {
            for (int j = 0; j < collector.Matchers.Count; j++)
            {
              Matcher matcher = collector.Matchers[j];

              if (matcher != null)
              {
                bool matched = matcher.MatchPrefix(prefix);

                if (matched)
                {
                  matchers.Add(matcher);
                }

              }
            }
          }
        }
        return true;
      }
      return false;
    }

    public virtual Collector GetCollector(Matcher matcher)
    {
      Collector c = null;

      if (matcher != null)
      {
        for (int i = 0; i < this.Collectors.Count; i++)
        {
          Collector collector = this.Collectors[i];

          if (collector != null && collector.Matchers.Contains(matcher))
          {
            c = collector;
            break;
          }
        }
      }
      return c;
    }

    public virtual bool GetCollectors(Signal s, List<Collector> collectors)
    {
      if (collectors != null)
      {
        Definition definition = this.Aggregation.GetDefinition(s);
        
        if (definition != null)
        {
          return this.GetCollectors(definition, collectors);
        }

      }
      return false;
    }

    public virtual bool GetCollectors(Definition definition, List<Collector> collectors)
    {
      if (definition != null && collectors != null)
      {
        for (int i = 0; i < this.Collectors.Count; i++)
        {
          Collector collector = this.Collectors[i];

          if (collector != null && collector.Definition == definition)
          {
            collectors.Add(collector);
          }
        }
        return true;
      }
      return false;
    }

    public virtual bool GetMatchers(Signal s, List<Matcher> matchers, SignalPrefix prefix)
    {
      Definition definition = this.Aggregation.GetDefinition(s);

      if (definition != null)
      {
        return this.GetMatchers(definition, matchers, prefix);
      }
      return false;
    }
    public virtual bool GetMatchers(Definition definition, List<Matcher> matchers, SignalPrefix prefix)
    {
      if (definition != null && matchers != null)
      {
        List<Matcher> ms = new List<Matcher>();

        if (this.GetMatchers(ms, prefix))
        {
          for (int i = 0; i < ms.Count; i++)
          {
            Matcher m = ms[i];

            if (m != null && m.Definition == definition)
            {
              matchers.Add(m);
            }
          }
        }
        return true;
      }
      return false;
    }

    public virtual SignalTreeNode GatherTrees(Signal s, SignalPrefix prefix)
    {
      SignalTreeNode node = SignalTreeNode.it();

      if (!this.GatherTrees(s, node.Trees, prefix))
      {
        //node.Trees.Add(SignalTree.of(Pattern.NullPattern,s));
      }
      return node;
    }
    protected virtual bool GatherTrees(Signal s, List<SignalTree> trees, SignalPrefix prefix)
    {
      if (trees != null && prefix != null)
      {
        List<Matcher> matchers = new List<Matcher>();

        if (this.GetMatchers(matchers, prefix))
        {
          for (int i = 0; i < matchers.Count; i++)
          {
            Matcher matcher = matchers[i];

            if (matcher != null)
            {
              SignalTree t =  matcher.Tree;

              if (t != null && t.Valid && t.Signal.Match(s))
              {
                if (!trees.Contains(t) && t.Prefix.Match(prefix))
                {
                  trees.Add(t);
                }
              }
              else if (matcher.IsLeaf)
              {
                Signal ls = Signal.Null;

                if (matcher.GetLeaf(ref ls))
                {
                  if (ls.Match(s))
                  {
                    trees.Add(SignalTree.of(matcher.Pattern, ls,this.NextPosition(), prefix));
                  }
                }
              }
            }
          }
          return trees.Count > 0;
        }
      }

      return false;
    }

    protected virtual void Compact(SignalTreeNode node)
    {
      if (node != null)
      {
        this.Compact(node.Trees);
      }
    }
    protected virtual void Compact(List<SignalTree> trees)
    {
      if (trees != null)
      {
        this.Compact(trees, new List<List<SignalTree>>());
      }
    }
    protected virtual void Compact(List<SignalTree> trees, List<List<SignalTree>> guard)
    {
      if (trees != null && guard != null && !guard.Contains(trees))
      {
        this.TrimLevel(trees);

        guard.Add(trees);

        List<SignalTree> ts = new List<SignalTree>();

        for (int i = 0; i < trees.Count; i++)
        {
          SignalTree tree = trees[i];

          if (tree != null && this.HasLeaves(tree)) //不处理任何没有叶子的树（相当于删除）
          {
            for (int j = 0; j < tree.Sequance.Count; j++)
            {
              SignalTreeNode node = tree.Sequance[j];

              if (node != null)
              {
                for (int k = 0; k < node.Trees.Count; k++)
                {
                  SignalTree tp = node.Trees[k];

                  if (tp != null)
                  {
                    this.RemoveCycle(tree, tp);
                  }
                }

                this.Compact(node.Trees, guard);
              }
            }

            ts.Add(this.CompactPath(tree));

          }

        }
        trees.Clear();

        trees.AddRange(ts);

        guard.Remove(trees);
      }
    }

    protected virtual SignalTree CompactPath(SignalTree tree)
    {
      if (tree != null)
      {
        if (tree.Sequance.Count == 1)
        {
          SignalTreeNode subnode = tree.Sequance[0];

          if (subnode != null && subnode.Trees.Count == 1)
          {
            SignalTree subtree = subnode.Trees[0];

            if (subtree != null 
              && subtree.Sequance.Count == 1
              && tree.Signal.Match(subtree.Signal)
              )
            {
              if (subtree.Pattern.IsSignleton)
              {
                tree = this.CompactPath(subtree);
              }
            }
          }
        }
      }

      return tree;
    }


    protected virtual bool HasLeaves(SignalTree tree)
    {
      bool has = false;

      if (tree != null)
      {
        if (!(has = tree.Pattern.IsLeaf))
        {
          this.HasLeaves(tree, new List<SignalTree>(), ref has);
        }
      }
      return has;
    }
    protected virtual bool HasLeaves(SignalTree tree,List<SignalTree> guard,ref bool has)
    {
      if (tree != null && guard != null && !guard.Contains(tree))
      {
        guard.Add(tree);

        for (int i = 0; !has && i < tree.Sequance.Count; i++)
        {
          SignalTreeNode node = tree.Sequance[i];

          if (node != null)
          {
            for (int j = 0; j < node.Trees.Count; j++)
            {
              SignalTree sub = node.Trees[j];

              if (sub != null)
              {
                if (has = sub.Pattern.IsLeaf)
                {
                  break;
                }
                else
                {
                  if (this.HasLeaves(sub,guard, ref has))
                  {
                    if (has)
                    {
                      break;
                    }
                  }
                }
              }
            }
          }
        }

        guard.Remove(tree);

        return true;
      }
      return false;
    }

    protected virtual void TrimLevel(List<SignalTree> trees)
    {
      if (trees != null)
      {
        for (int i = 0; i < trees.Count; i++)
        {
          SignalTree tree = trees[i];

          if (tree != null)
          {
            if (this.HasTrimingConditon(tree, trees))
            {
              i--;

              //如果这个tree是任何一个其他同层次的tree的子层
              //则删除这个tree
              trees.Remove(tree);
            }
          }
        }
      }
    }
    protected virtual bool HasTrimingConditon(SignalTree tree, List<SignalTree> trees)
    {
      if (tree != null && trees != null)
      {
        for (int i = 0; i < trees.Count; i++)
        {
          SignalTree parent = trees[i];

          if (parent != null 
            && tree != parent 
            && 
            (  parent.Prefix.IsParent(tree.Prefix) 
            //|| parent.Pattern.RecursivelyEquals(tree.Pattern)
            || this.IsDescendantOf(tree, parent)
            )
            )
          {
            return true;
          }
        }
      }
      return false;
    }

    //消去内部对自己的循环引用。循环引用是因为内部无法区分结构而造成的。
    //循环引用只是一种可能性，但是却非常影响结果的正确性，所以必须消除。
    protected virtual bool RemoveCycle(SignalTree tree, SignalTree parent)
    {
      return this.RemoveCycle(tree, parent, new List<SignalTree>());
    }
    protected virtual bool RemoveCycle(SignalTree tree, SignalTree parent, List<SignalTree> guard)
    {
      if (tree != null && parent != null && !guard.Contains(parent))
      {
        guard.Add(parent);
        for (int i = 0; i < parent.Sequance.Count; i++)
        {
          SignalTreeNode node = parent.Sequance[i];

          if (node != null)
          {
            List<SignalTree> trees = new List<SignalTree>(node.Trees);

            for (int k = 0; k < trees.Count; k++)
            {
              SignalTree st = trees[k];

              if (st != null && st != tree)
              {
                this.RemoveCycle(tree, st, guard);
              }
            }
            if (node.Trees.Contains(tree))
            {
              while (node.Trees.Remove(tree)) ;
            }

          }
        }
        guard.Remove(parent);
        return true;
      }
      return false;
    }
    protected virtual bool IsDescendantOf(SignalTree tree, SignalTree parent)
    {
      bool found = false;

      if (tree != null && parent != null)
      {
        List<SignalTree> guard = new List<SignalTree>();

        found = this.IsDescendantOf(tree, parent, guard);
      }
      return found;
    }

    protected virtual bool IsDescendantOf(SignalTree tree, SignalTree parent, List<SignalTree> guard)
    {
      bool found = false;

      if (tree != null && parent != null && guard != null && !guard.Contains(parent))
      {
        guard.Add(parent);

        for (int i = 0; !found && i < parent.Sequance.Count; i++)
        {
          SignalTreeNode node = parent.Sequance[i];

          if (node != null)
          {
            for (int j = 0; j < node.Trees.Count; j++)
            {
              SignalTree t = node.Trees[j];

              if (t != null && t != parent)
              {
                if (t == tree)
                {
                  found = true;

                  break;
                }
                else
                {
                  if (found = this.IsDescendantOf(tree, t, guard))
                  {
                    break;
                  }

                }
              }
            }
          }
        }

        guard.Remove(parent);
      }
      return found;
    }

    public virtual int NextPosition()
    {
      return this.position++;
    }
    public virtual Definition GetDefinition(Signal s)
    {
      return this.Aggregation.GetDefinition(s);
    }
  }
}
