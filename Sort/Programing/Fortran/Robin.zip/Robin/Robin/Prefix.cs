﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public struct Prefix
  {
    public static Prefix NullPrefix = of(null);

    public static Prefix of(Matcher matcher)
    {
      return new Prefix(matcher);
    }

    public Matcher Matcher;

    public int Level;


    public Prefix(Matcher Matcher)
    {
      this.Matcher = Matcher;
      this.Level = -1;

      if (this.Matcher != null)
      {
        this.Level = this.Matcher.CurrentLevel;
      }
    }

    public override string ToString()
    {
      return this.Matcher != null ? string.Format("{0}", this.Matcher.Target.ToString()) : string.Empty;
    }

    public bool Match(Prefix p)
    {
      return this.Matcher == p.Matcher;
    }

    public bool StrictlyMatch(Prefix p)
    {
      return this.Matcher == p.Matcher && this.Level == p.Level;
    }

    public override bool Equals(object obj)
    {
      Prefix? p = (Prefix?)obj;

      if (p.HasValue)
      {
        return this.Match(p.Value);// && p.Value.Position == this.Position;
      }
      return base.Equals(obj);
    }

    public override int GetHashCode()
    {
      return this.Matcher != null ? (this.Matcher.GetHashCode() ^ this.Level) : -1;
    }

  }

}
