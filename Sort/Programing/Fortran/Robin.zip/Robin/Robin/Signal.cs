﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public struct Signal
  {
    public static Signal EOF = Signal.of(Char.MaxValue,true);

    public static Signal Null = Signal.of(Char.MinValue,true);

    public static Signal of(char c,bool raw)
    {
      return new Signal(c,raw);
    }

    public static Signal of(string s,bool raw)
    {
      return new Signal(s,raw);
    }

    internal SignalPrefix prefix;

    internal string value;

    internal bool raw;

    public string Value
    {
      get
      {
        return this.value;
      }
    }
    
    public SignalPrefix Prefix
    {
      get
      {
        return this.prefix ?? (this.prefix = SignalPrefix.it());
      }
    }

    public Signal(char c,bool raw)
    {
      this.raw = raw;
      this.value = c.ToString();
      this.prefix = null;
    }
    public Signal(string s,bool raw)
    {
      this.raw = raw;
      this.value = s;
      this.prefix = null;
    }

    public bool Match(Signal s)
    {
      return this.Match(s.value);
    }

    public bool Match(char c)
    {
      return this.value == c.ToString();
    }
    
    public bool Match(string s)
    {
      return this.value == s;
    }

    public override bool Equals(object obj)
    {
      return obj != null ? obj.ToString() == this.ToString() : false;
    }

    public override string ToString()
    {
      return this.value;
    }

    public override int GetHashCode()
    {
      return value == null ? 0 : value.GetHashCode();
    }
    
    public Signal WithPrefix(Signal signal)
    {
      return this.WithPrefix(signal.Prefix);
    }
    
    public Signal WithPrefix(SignalPrefix prefix)
    {
      //保证Prefix和Definition或者Pattern所用的Signal的Prefix不同。
      //既不会错误的改写Pattern或者Definition。

      Signal target = this;
      if (prefix != null)
      {
        target.prefix = null; //重新创建Prefix列表。
        target.Prefix.Prefixes.AddRange(prefix.Prefixes);
      }
      return target;

    }
  }
}
