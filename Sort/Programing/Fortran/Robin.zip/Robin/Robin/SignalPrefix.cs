﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public class SignalPrefix
  {
    public static SignalPrefix NullSignalPrefix = it();

    public static SignalPrefix it()
    {
      return new SignalPrefix(null);
    }

    public static SignalPrefix of(SignalPrefix prefix)
    {
      return new SignalPrefix(prefix!=null ? prefix.Prefixes : null);
    }

    public static SignalPrefix of(ICollection<Prefix> prefix)
    {
      return new SignalPrefix(prefix);
    }

    public static SignalPrefix of(params Prefix[] prefix)
    {
      return new SignalPrefix(prefix);
    }

    protected List<Prefix> prefixes = null;

    public virtual List<Prefix> Prefixes
    {
      get
      {
        return this.prefixes ?? (this.prefixes = new List<Prefix>());
      }
    }

    public virtual bool HasPrefixes
    {
      get
      {
        return this.Prefixes.Count > 0;
      }
    }

    public SignalPrefix(ICollection<Prefix> prefixs)
    {
      if (prefixs != null)
      {
        this.Prefixes.AddRange(prefixs);
      }
    }

    public virtual bool IsParent(SignalPrefix prefix)
    {
      if (prefix != null && prefix.Prefixes.Count == this.Prefixes.Count + 1)
      {
        bool matched = true;

        for (int i = 0; i < this.Prefixes.Count; i++)
        {
          if (!this.Prefixes[i].Equals(prefix.Prefixes[i]))
          {
            matched = false;
            break;
          }
        }

        return matched;
      }
      return false;
    }

    public virtual bool Match(SignalPrefix prefix)
    {
      if (prefix != null && prefix.Prefixes.Count == this.Prefixes.Count)
      {
        bool matched = true;

        for (int i = 0; i < this.Prefixes.Count; i++)
        {
          if (!this.Prefixes[i].Equals(prefix.Prefixes[i]))
          {
            matched = false;
            break;
          }
        }

        return matched;
      }
      return false;
    }

    public virtual bool MatchLast(Prefix prefix)
    {
      if (this.HasPrefixes)
      {
        return this.Prefixes[0].Equals(prefix);
      }
      return false;
    }
    public virtual bool MatchLast(Signal signal)
    {
      if (this.HasPrefixes)
      {
        Prefix prefix = this.Prefixes[0];

        if (prefix.Matcher.Target.Match(signal))
        {
          return true;
        }
      }
      return false;
    }

    public virtual Prefix AddPrefix(Prefix prefix)
    {
      //添加在开头。
      this.Prefixes.Insert(0, prefix);
      
      return prefix;
    }
    public virtual Prefix RemovePrefix(Prefix prefix)
    {
      //必须是第一项，否则不应当移除。
      //按照栈的原则处理前缀。
      if (this.MatchLast(prefix))
      {
        //移除第一项。
        if (this.Prefixes.Remove(prefix))
        {
          return prefix;
        }
      }
      return Prefix.NullPrefix;
    }


    public virtual Prefix RemovePrefix()
    {
      return this.HasPrefixes ? this.RemovePrefix(this.Prefixes[0]) : Prefix.NullPrefix;
    }

    public override string ToString()
    {
      if (this.HasPrefixes)
      {
        StringBuilder builder = new StringBuilder();

        for (int i = 0; i < this.Prefixes.Count; i++)
        {
          Prefix prefix = this.Prefixes[i];

          builder.AppendFormat("{0}-", prefix.ToString());
          
        }
        return builder.ToString();
      }
      return string.Empty;
    }
  }
}
