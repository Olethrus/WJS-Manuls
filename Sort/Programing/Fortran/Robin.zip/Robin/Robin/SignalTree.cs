﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public class SignalTree
  {
    public static SignalTree of(Pattern pattern, Signal s, int position, SignalPrefix prefix)
    {
      return new SignalTree(pattern,s,position,prefix);
    }

    protected Signal signal = Signal.Null;

    protected List<SignalTreeNode> sequance = null;

    protected Pattern pattern = null;

    protected SignalPrefix prefix = null;

    protected int position = 0;

    protected bool valid = true;

    public virtual Signal Signal
    {
      get
      {
        return this.signal;
      }
    }
    public virtual int Position
    {
      get
      {
        return this.position;
      }
    }
    public virtual Pattern Pattern
    {
      get
      {
        return this.pattern;
      }
      set
      {
        this.pattern = value;
      }
    }
    public virtual bool Valid
    {
      get
      {
        return this.valid;
      }
      set
      {
        this.valid = value;
      }
    }
    public virtual List<SignalTreeNode> Sequance
    {
      get
      {
        return this.sequance ?? (this.sequance = new List<SignalTreeNode>());
      }
    }
    public virtual SignalPrefix Prefix
    {
      get
      {
        return this.prefix ?? (this.prefix = SignalPrefix.it());
      }
    }

    public SignalTree(Pattern pattern, Signal s,int position,  SignalPrefix prefix)
    {
      if ((this.pattern = pattern) == null) throw new ArgumentNullException("pattern");

      this.position = position;
      this.signal = s;

      if (prefix != null)
      {
        this.Prefix.Prefixes.AddRange(prefix.Prefixes);
      }
    }

    protected SignalTree(SignalTree tree)
    {
      if (tree != null)
      {
        this.signal = tree.signal;
        this.pattern = tree.pattern;
        this.position = tree.position;

        this.prefix = SignalPrefix.of(tree.prefix);

        this.Sequance.AddRange(tree.Sequance);
      }
    }

    public virtual bool IsAmbigous()
    {
      return this.IsAmbigous(new List<SignalTree>());
    }
    public virtual bool IsAmbigous(List<SignalTree> guard)
    {
      bool ambigous = false;

      if (guard != null && !guard.Contains(this))
      {
        guard.Add(this);

        for (int i = 0; i < this.Sequance.Count; i++)
        {
          SignalTreeNode node = this.Sequance[i];

          if (node != null)
          {
            int count = node.Trees.Count;

            if (count == 0)
            {
              continue;
            }
            else if (count == 1)
            {
              SignalTree tree = node.Trees[0];

              if (tree != null)
              {
                if (ambigous = tree.IsAmbigous(guard))
                {
                  break;
                }
              }
              else
              {
                continue;
              }
            }
            else
            {
              return true; //ambigous
            }
          }
        }
        guard.Remove(this);
      }
      return ambigous;
    }

    public override string ToString()
    {
      StringBuilder builder = new StringBuilder();
      
      builder.AppendFormat("{0}{1}", this.Prefix.ToString(), this.Signal.ToString());

      return builder.ToString();
    }

    public virtual SignalTree Clone()
    {
      return new SignalTree(this);
    }
  }
}
