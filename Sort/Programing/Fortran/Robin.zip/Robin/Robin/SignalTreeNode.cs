﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Robin
{
  public class SignalTreeNode
  {
    protected List<SignalTree> trees = null;

    public virtual List<SignalTree> Trees
    {
      get
      {
        return this.trees ?? (this.trees = new List<SignalTree>());
      }
    }

    public static SignalTreeNode it()
    {
      return new SignalTreeNode();
    }
    public static SignalTreeNode of(SignalTreeNode node)
    {
      return new SignalTreeNode(node);
    }
    public static SignalTreeNode of(ICollection<SignalTree> trees)
    {
      return new SignalTreeNode(trees);
    }
    public static SignalTreeNode of(params SignalTree[] trees)
    {
      return new SignalTreeNode(trees);
    }

    public SignalTreeNode()
      : base()
    {
    }
    public SignalTreeNode(SignalTreeNode node)
    {
      if (node != null)
      {
        this.Trees.AddRange(node.Trees);
      }
    }
    public SignalTreeNode(params SignalTree[] trees)
    {
      if (trees != null)
      {
        this.Trees.AddRange(trees);
      }
    }
    public SignalTreeNode(ICollection<SignalTree> trees)
    {
      if (trees != null)
      {
        this.Trees.AddRange(trees);
      }
    }
    public virtual SignalTreeNode Clone()
    {
      return SignalTreeNode.of(this.Trees);
    }
    public virtual bool SetValid(bool valid)
    {
      if (trees != null)
      {
        for (int u = 0; u < this.Trees.Count; u++)
        {
          SignalTree tr = this.Trees[u];

          if (tr != null)
          {
            tr.Valid = valid;
          }
        }
        return true;
      }
      return false;
    }
    public override string ToString()
    {
      StringBuilder builder = new StringBuilder();

      for (int i = 0; i < this.Trees.Count; i++)
      {
        SignalTree child = this.Trees[i];

        if (child != null)
        {
          builder.AppendFormat("{0}", child.ToString());

          if (i < this.Trees.Count - 1)
          {
            builder.Append(", ");
          }
        }
      }

      return builder.ToString();
    }
  }
}