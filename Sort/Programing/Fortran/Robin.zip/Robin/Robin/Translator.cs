﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace Robin
{
  public class Translator : Parser
  {

    public const string NamespaceName = "http://www.robinproject.org";

    public new static Translator it()
    {
      return new Translator();
    }

    public Translator()
    {

    }

    public virtual void ClearGrammars()
    {
      this.Collectors.Clear();
    }

    public virtual bool AddGrammars(XElement g)
    {
      if (g != null && g.Name.NamespaceName == NamespaceName)
      {
        if (this.Aggregation != null)
        {
          this.Aggregation.ResetTerminators();

          foreach (XElement d in g.Elements())
          {
            if (d != null)
            {
              Definition definition = Definition.of(aggregation, this.FormatName(d.Name.LocalName));

              if (definition != null)
              {
                if (d.HasElements)
                {
                  foreach (XElement p in d.Elements())
                  {
                    if (p != null && p.Name.LocalName == "_" && p.Name.NamespaceName == g.Name.NamespaceName)
                    {

                      bool leaf = !p.HasElements;

                      Pattern pattern = Pattern.of(definition, leaf);

                      if (pattern != null)
                      {
                        if (p.HasElements)
                        {
                          foreach (XElement u in p.Elements())
                          {
                            if (u != null)
                            {
                              pattern.Sequence.Add(Signal.of(this.FormatName(u.Name.LocalName),false));
                            }
                          }
                        }
                        else
                        {
                          string chars = p.Value;

                          if (!string.IsNullOrEmpty(chars))
                          {
                            foreach (char c in chars)
                            {
                              //真实字符
                              pattern.Sequence.Add(Signal.of(c,true));
                            }
                          }
                        }
                        definition.Patterns.Add(pattern);
                      }
                    }
                  }
                }
                else //leaf definitions
                {

                }
                this.Aggregation.Definitions.Add(definition);
              }
            }
          }


          foreach (Definition definition in this.Aggregation.Definitions)
          {
            if (definition != null)
            {
              List<Matcher> matchers = new List<Matcher>();

              if (definition.CreateMatchers(this, matchers))
              {
                foreach (Matcher matcher in matchers)
                {
                  if (matcher != null)
                  {
                    this.Collectors.Add(Collector.of(matcher));
                  }
                }
              }
            }
          }
          return true;
        }
      }
      return false;
    }

    public virtual XElement Translate(string text, bool compact)
    {
      XElement e = new XElement(XName.Get("_", NamespaceName));

      if (!string.IsNullOrEmpty(text))
      {

        SignalTreeNode node = this.Parse(text, compact);

        if (node != null)
        {
          this.TranslateNode(e,node);
        }
      }

      return e;
    }

    protected virtual void TranslateNode(XElement parent,SignalTreeNode node)
    {
      List<SignalTreeNode> originals = new List<SignalTreeNode>();

      if (originals != null)
      {
        this.TranslateNode(parent, node, originals);
      }
    }
    protected virtual void TranslateNode(XElement parent, SignalTreeNode node, List<SignalTreeNode> originals)
    {
      if (node != null && parent != null && originals != null && !originals.Contains(node))
      {
        originals.Add(node);

        XElement te = new XElement(XName.Get("_", NamespaceName));

        if (te != null)
        {
          parent.Add(te);

          for (int i = 0; i < node.Trees.Count; i++)
          {
            SignalTree tree = node.Trees[i];

            if (tree != null)
            {
              if (!tree.Pattern.IsLeaf)
              {
                XElement ne = new XElement(
                  XName.Get(tree.ToString(), NamespaceName)
                  ,
                  new XAttribute(XName.Get("_", NamespaceName), tree.Pattern.ToString())
                  //,
                  //new XAttribute(XName.Get("id", "_"), tree.Pattern.Identifier.ToString())
                  //,
                  //new XAttribute(XName.Get("position", "_"), tree.Position)
                  );

                if (ne != null)
                {
                  te.Add(ne);

                  for (int j = 0; j < tree.Sequance.Count; j++)
                  {
                    SignalTreeNode sn = tree.Sequance[j];

                    if (sn != null)
                    {
                      this.TranslateNode(ne, sn, originals);
                    }
                  }

                }
              }
              else
              {
                te.Add(new XText(tree.Signal.Value));
              }
            }
          }
        }
        originals.Remove(node);
      }
    }
    protected virtual string FormatName(string name)
    {
      return string.Format("{0}", name ?? string.Empty); 
    }
  }
}
