﻿namespace Robin
{
  partial class _MainForm
  {
    /// <summary>
    /// 必需的设计器变量。
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    /// 清理所有正在使用的资源。
    /// </summary>
    /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
    protected override void Dispose(bool disposing)
    {
      if (disposing && (components != null))
      {
        components.Dispose();
      }
      base.Dispose(disposing);
    }

    #region Windows 窗体设计器生成的代码

    /// <summary>
    /// 设计器支持所需的方法 - 不要
    /// 使用代码编辑器修改此方法的内容。
    /// </summary>
    private void InitializeComponent()
    {
      this.LeftContainer = new System.Windows.Forms.SplitContainer();
      this.BNFTreeView = new System.Windows.Forms.TreeView();
      this.RightContainer = new System.Windows.Forms.SplitContainer();
      this.InputText = new System.Windows.Forms.TextBox();
      this.CompactCheckBox = new System.Windows.Forms.CheckBox();
      this.ImportButton = new System.Windows.Forms.Button();
      this.ExportButton = new System.Windows.Forms.Button();
      this.SaveButton = new System.Windows.Forms.Button();
      this.OpenButton = new System.Windows.Forms.Button();
      this.Status = new System.Windows.Forms.StatusStrip();
      this.ParseButton = new System.Windows.Forms.Button();
      this.ClearButton = new System.Windows.Forms.Button();
      this.ResultTreeView = new System.Windows.Forms.TreeView();
      this.OpenDialog = new System.Windows.Forms.OpenFileDialog();
      this.SaveDialog = new System.Windows.Forms.SaveFileDialog();
      this.ImportDialog = new System.Windows.Forms.OpenFileDialog();
      this.ExportDialog = new System.Windows.Forms.SaveFileDialog();
      this.LeftContainer.Panel1.SuspendLayout();
      this.LeftContainer.Panel2.SuspendLayout();
      this.LeftContainer.SuspendLayout();
      this.RightContainer.Panel1.SuspendLayout();
      this.RightContainer.Panel2.SuspendLayout();
      this.RightContainer.SuspendLayout();
      this.SuspendLayout();
      // 
      // LeftContainer
      // 
      this.LeftContainer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.LeftContainer.Location = new System.Drawing.Point(0, 0);
      this.LeftContainer.Name = "LeftContainer";
      // 
      // LeftContainer.Panel1
      // 
      this.LeftContainer.Panel1.Controls.Add(this.BNFTreeView);
      // 
      // LeftContainer.Panel2
      // 
      this.LeftContainer.Panel2.Controls.Add(this.RightContainer);
      this.LeftContainer.Size = new System.Drawing.Size(792, 573);
      this.LeftContainer.SplitterDistance = 208;
      this.LeftContainer.TabIndex = 8;
      this.LeftContainer.TabStop = false;
      // 
      // BNFTreeView
      // 
      this.BNFTreeView.Dock = System.Windows.Forms.DockStyle.Fill;
      this.BNFTreeView.Indent = 19;
      this.BNFTreeView.Location = new System.Drawing.Point(0, 0);
      this.BNFTreeView.Name = "BNFTreeView";
      this.BNFTreeView.ShowRootLines = false;
      this.BNFTreeView.Size = new System.Drawing.Size(208, 573);
      this.BNFTreeView.TabIndex = 9;
      // 
      // RightContainer
      // 
      this.RightContainer.Dock = System.Windows.Forms.DockStyle.Fill;
      this.RightContainer.Location = new System.Drawing.Point(0, 0);
      this.RightContainer.Name = "RightContainer";
      this.RightContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
      // 
      // RightContainer.Panel1
      // 
      this.RightContainer.Panel1.Controls.Add(this.InputText);
      // 
      // RightContainer.Panel2
      // 
      this.RightContainer.Panel2.Controls.Add(this.CompactCheckBox);
      this.RightContainer.Panel2.Controls.Add(this.ImportButton);
      this.RightContainer.Panel2.Controls.Add(this.ExportButton);
      this.RightContainer.Panel2.Controls.Add(this.SaveButton);
      this.RightContainer.Panel2.Controls.Add(this.OpenButton);
      this.RightContainer.Panel2.Controls.Add(this.Status);
      this.RightContainer.Panel2.Controls.Add(this.ParseButton);
      this.RightContainer.Panel2.Controls.Add(this.ClearButton);
      this.RightContainer.Panel2.Controls.Add(this.ResultTreeView);
      this.RightContainer.Size = new System.Drawing.Size(580, 573);
      this.RightContainer.SplitterDistance = 80;
      this.RightContainer.TabIndex = 9;
      this.RightContainer.TabStop = false;
      // 
      // InputText
      // 
      this.InputText.Dock = System.Windows.Forms.DockStyle.Fill;
      this.InputText.Location = new System.Drawing.Point(0, 0);
      this.InputText.Multiline = true;
      this.InputText.Name = "InputText";
      this.InputText.ScrollBars = System.Windows.Forms.ScrollBars.Both;
      this.InputText.Size = new System.Drawing.Size(580, 80);
      this.InputText.TabIndex = 1;
      this.InputText.Text = "123+456*789";
      this.InputText.WordWrap = false;
      // 
      // CompactCheckBox
      // 
      this.CompactCheckBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.CompactCheckBox.AutoSize = true;
      this.CompactCheckBox.Checked = true;
      this.CompactCheckBox.CheckState = System.Windows.Forms.CheckState.Checked;
      this.CompactCheckBox.Location = new System.Drawing.Point(187, 445);
      this.CompactCheckBox.Name = "CompactCheckBox";
      this.CompactCheckBox.Size = new System.Drawing.Size(66, 16);
      this.CompactCheckBox.TabIndex = 10;
      this.CompactCheckBox.Text = "Compac&t";
      this.CompactCheckBox.UseVisualStyleBackColor = true;
      // 
      // ImportButton
      // 
      this.ImportButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.ImportButton.Location = new System.Drawing.Point(259, 441);
      this.ImportButton.Name = "ImportButton";
      this.ImportButton.Size = new System.Drawing.Size(75, 23);
      this.ImportButton.TabIndex = 7;
      this.ImportButton.Text = "I&mport";
      this.ImportButton.UseVisualStyleBackColor = true;
      this.ImportButton.Click += new System.EventHandler(this.ImportButton_Click);
      // 
      // ExportButton
      // 
      this.ExportButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.ExportButton.Location = new System.Drawing.Point(340, 441);
      this.ExportButton.Name = "ExportButton";
      this.ExportButton.Size = new System.Drawing.Size(75, 23);
      this.ExportButton.TabIndex = 8;
      this.ExportButton.Text = "E&xport";
      this.ExportButton.UseVisualStyleBackColor = true;
      this.ExportButton.Click += new System.EventHandler(this.ExportButton_Click);
      // 
      // SaveButton
      // 
      this.SaveButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.SaveButton.Location = new System.Drawing.Point(85, 441);
      this.SaveButton.Name = "SaveButton";
      this.SaveButton.Size = new System.Drawing.Size(75, 23);
      this.SaveButton.TabIndex = 6;
      this.SaveButton.Text = "&Save";
      this.SaveButton.UseVisualStyleBackColor = true;
      this.SaveButton.Click += new System.EventHandler(this.SaveButton_Click);
      // 
      // OpenButton
      // 
      this.OpenButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
      this.OpenButton.Location = new System.Drawing.Point(4, 441);
      this.OpenButton.Name = "OpenButton";
      this.OpenButton.Size = new System.Drawing.Size(75, 23);
      this.OpenButton.TabIndex = 5;
      this.OpenButton.Text = "&Open";
      this.OpenButton.UseVisualStyleBackColor = true;
      this.OpenButton.Click += new System.EventHandler(this.OpenButton_Click);
      // 
      // Status
      // 
      this.Status.Location = new System.Drawing.Point(0, 467);
      this.Status.Name = "Status";
      this.Status.Size = new System.Drawing.Size(580, 22);
      this.Status.TabIndex = 9;
      // 
      // ParseButton
      // 
      this.ParseButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.ParseButton.Location = new System.Drawing.Point(502, 441);
      this.ParseButton.Name = "ParseButton";
      this.ParseButton.Size = new System.Drawing.Size(75, 23);
      this.ParseButton.TabIndex = 3;
      this.ParseButton.Text = "&Parse";
      this.ParseButton.UseVisualStyleBackColor = true;
      this.ParseButton.Click += new System.EventHandler(this.ParseButton_Click);
      // 
      // ClearButton
      // 
      this.ClearButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
      this.ClearButton.Location = new System.Drawing.Point(421, 441);
      this.ClearButton.Name = "ClearButton";
      this.ClearButton.Size = new System.Drawing.Size(75, 23);
      this.ClearButton.TabIndex = 4;
      this.ClearButton.Text = "&Clear";
      this.ClearButton.UseVisualStyleBackColor = true;
      this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
      // 
      // ResultTreeView
      // 
      this.ResultTreeView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                  | System.Windows.Forms.AnchorStyles.Left)
                  | System.Windows.Forms.AnchorStyles.Right)));
      this.ResultTreeView.Indent = 19;
      this.ResultTreeView.Location = new System.Drawing.Point(0, 2);
      this.ResultTreeView.Name = "ResultTreeView";
      this.ResultTreeView.ShowRootLines = false;
      this.ResultTreeView.Size = new System.Drawing.Size(580, 433);
      this.ResultTreeView.TabIndex = 2;
      // 
      // OpenDialog
      // 
      this.OpenDialog.DefaultExt = "xml";
      this.OpenDialog.FileName = "grammar.xml";
      this.OpenDialog.Filter = "XML Files|*.xml|Text File|*.txt|All Files|*.*";
      this.OpenDialog.InitialDirectory = ".";
      // 
      // SaveDialog
      // 
      this.SaveDialog.DefaultExt = "xml";
      this.SaveDialog.FileName = "grammar.xml";
      this.SaveDialog.Filter = "XML Files|*.xml|Text File|*.txt|All Files|*.*";
      this.SaveDialog.InitialDirectory = ".";
      // 
      // ImportDialog
      // 
      this.ImportDialog.DefaultExt = "xml";
      this.ImportDialog.FileName = "result.xml";
      this.ImportDialog.Filter = "XML Files|*.xml|Text File|*.txt|All Files|*.*";
      this.ImportDialog.InitialDirectory = ".";
      // 
      // ExportDialog
      // 
      this.ExportDialog.DefaultExt = "xml";
      this.ExportDialog.FileName = "result.xml";
      this.ExportDialog.Filter = "XML Files|*.xml|Text File|*.txt|All Files|*.*";
      this.ExportDialog.InitialDirectory = ".";
      // 
      // _MainForm
      // 
      this.AcceptButton = this.ParseButton;
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.ClientSize = new System.Drawing.Size(792, 573);
      this.Controls.Add(this.LeftContainer);
      this.KeyPreview = true;
      this.MinimumSize = new System.Drawing.Size(800, 600);
      this.Name = "_MainForm";
      this.Text = "Robin";
      this.LeftContainer.Panel1.ResumeLayout(false);
      this.LeftContainer.Panel2.ResumeLayout(false);
      this.LeftContainer.ResumeLayout(false);
      this.RightContainer.Panel1.ResumeLayout(false);
      this.RightContainer.Panel1.PerformLayout();
      this.RightContainer.Panel2.ResumeLayout(false);
      this.RightContainer.Panel2.PerformLayout();
      this.RightContainer.ResumeLayout(false);
      this.ResumeLayout(false);

    }

    #endregion

    private System.Windows.Forms.SplitContainer LeftContainer;
    private System.Windows.Forms.SplitContainer RightContainer;
    private System.Windows.Forms.TextBox InputText;
    private System.Windows.Forms.Button ClearButton;
    private System.Windows.Forms.TreeView ResultTreeView;
    private System.Windows.Forms.Button ParseButton;
    private System.Windows.Forms.TreeView BNFTreeView;
    private System.Windows.Forms.StatusStrip Status;
    private System.Windows.Forms.Button SaveButton;
    private System.Windows.Forms.Button OpenButton;
    private System.Windows.Forms.OpenFileDialog OpenDialog;
    private System.Windows.Forms.SaveFileDialog SaveDialog;
    private System.Windows.Forms.Button ExportButton;
    private System.Windows.Forms.OpenFileDialog ImportDialog;
    private System.Windows.Forms.SaveFileDialog ExportDialog;
    private System.Windows.Forms.Button ImportButton;
    private System.Windows.Forms.CheckBox CompactCheckBox;
  }
}

