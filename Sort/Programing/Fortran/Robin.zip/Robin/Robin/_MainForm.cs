﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Xml.Linq;

namespace Robin
{
  public partial class _MainForm : Form
  {
    protected XElement g = null;

    protected XElement x = null;

    public _MainForm()
    {
      InitializeComponent();

      using (System.IO.Stream s = typeof(_MainForm).Assembly.GetManifestResourceStream("Robin.Text.Working.xml"))
      {
        if (s != null)
        {
          using (System.IO.StreamReader reader = new System.IO.StreamReader(s))
          {
            if ((this.g = XElement.Load(reader)) != null)
            {
              this.BNFTreeView.BeginUpdate();
              this.BuildXMLTree(this.BNFTreeView, this.g);
              this.BNFTreeView.EndUpdate();
              this.BNFTreeView.ExpandAll();

              //this.DoParse();
            }
          }
        }
      }
    }

    protected virtual void BuildXMLTree(TreeNode treeNode, XElement x)
    {
      if (treeNode != null && x != null)
      {
        if (x.HasElements)
        {
          foreach (XElement s in x.Elements())
          {
            if (s != null)
            {
              StringBuilder builder = new StringBuilder(s.Name.LocalName ?? string.Empty);

              foreach (XAttribute a in s.Attributes())
              {
                if (a != null)
                {
                  builder.AppendFormat(" {0} = \"{1}\" ", a.Name.LocalName, a.Value);
                }
              }

              TreeNode xNode = treeNode.Nodes.Add(builder.ToString());
              
              if (xNode != null)
              {
                xNode.Tag = s;

                this.BuildXMLTree(xNode, s);
              }
            }
          }
        }
        else
        {
          string sName = x.Value;

          if (!string.IsNullOrEmpty(sName))
          {
            TreeNode sNode = treeNode.Nodes.Add(string.Format("\"{0}\"",sName));

            if (sNode != null)
            {
              sNode.Tag = x;
            }
          }
        }
      }

    }


    protected virtual void BuildXMLTree(TreeView treeView, XElement g)
    {
      if (treeView != null && g != null)
      {
        treeView.Nodes.Clear();

        string rootName = g.Name.LocalName ?? string.Empty;

        TreeNode rootNode = treeView.Nodes.Add(rootName);

        if (rootNode != null)
        {
          this.BuildXMLTree(rootNode, g);
        }
      }
    }

    private void ParseButton_Click(object sender, EventArgs e)
    {
      this.DoParse();
    }

    private void DoParse()
    {
      if (g != null)
      {
        bool compact = this.CompactCheckBox.Checked;

        Translator translator = Translator.it();

        if (translator != null)
        {
          if (translator.AddGrammars(g))
          {
            string text = this.InputText.Text ?? string.Empty;

            if ((this.x = translator.Translate(text, compact)) != null)
            {
              this.ResultTreeView.BeginUpdate();
              this.BuildXMLTree(this.ResultTreeView, x);
              this.ResultTreeView.ExpandAll();
              this.ResultTreeView.EndUpdate();
            }
          }
        }
      }
      this.InputText.SelectAll();
    }

    private void ClearButton_Click(object sender, EventArgs e)
    {
      this.ResultTreeView.Nodes.Clear();
    }

    private void OpenButton_Click(object sender, EventArgs e)
    {
      DialogResult dr = this.OpenDialog.ShowDialog(this);

      if (dr == DialogResult.OK)
      {
        try
        {
          if ((this.g = XElement.Load(this.OpenDialog.FileName)) != null)
          {
            this.BNFTreeView.BeginUpdate();
            this.BuildXMLTree(this.BNFTreeView, this.g);
            this.BNFTreeView.EndUpdate();
            this.BNFTreeView.ExpandAll();
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message);
        }
      }
    }

    private void SaveButton_Click(object sender, EventArgs e)
    {
      DialogResult dr = this.SaveDialog.ShowDialog(this);

      if (dr == DialogResult.OK)
      {
        try
        {
          if (this.g != null)
          {
            g.Save(this.SaveDialog.FileName);
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message);
        }
      }
    }

    private void ExportButton_Click(object sender, EventArgs e)
    {
      DialogResult dr = this.ExportDialog.ShowDialog(this);

      if (dr == DialogResult.OK)
      {
        try
        {
          if (this.x != null)
          {
            x.Save(this.ExportDialog.FileName);
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message);
        }
      }
    }

    private void ImportButton_Click(object sender, EventArgs e)
    {
      DialogResult dr = this.ImportDialog.ShowDialog(this);

      if (dr == DialogResult.OK)
      {
        try
        {
          if ((this.x = XElement.Load(this.ImportDialog.FileName)) != null)
          {
            this.ResultTreeView.BeginUpdate();
            this.BuildXMLTree(this.ResultTreeView, this.x);
            this.ResultTreeView.EndUpdate();
            this.ResultTreeView.ExpandAll();
          }
        }
        catch (Exception ex)
        {
          MessageBox.Show(ex.Message);
        }
      }
    }
  }
}
