You will need to download NSIS to compile the package (free from sourceforge)
You will want nsiedit to edit the setup script.