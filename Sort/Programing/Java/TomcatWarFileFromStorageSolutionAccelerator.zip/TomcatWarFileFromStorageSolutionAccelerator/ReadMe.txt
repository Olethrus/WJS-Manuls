Instructions:
----------------

1) The binaries are not present at required locations, so on running buildme or packme,it will prompt to give the path to the binaries and it will get copied to required locations. For e.g if jre binaries are present in D:\jre the path has to be given as D:\jre and not the folder path like D:\.
2) Buildme.cmd creates the .csx folder under Tomcat folder itself.
3) Run Packme.cmd to create the CSPKG file.
4) Packme.cmd creates the Tomcat.cspkg under Tomcat folder itself.
5) Run Runme.cmd to run the solution in dev fabric. This will build and run the solution.