﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.IO;
using System.Xml;

namespace Tomcat
{
    public class RunTomcat
    {
        /// <summary>
        /// Function to start Tomcat exe
        /// </summary>
        /// <param name="tomcatLocation"></param>
        /// <param name="tomcatPort"></param>
        public void StartTomcat(string tomcatLocation, string tomcatPort)
        {
            string response;
            // Call the RunCommand function to change the port in server.xml
            response = RunCommand(Environment.GetEnvironmentVariable("RoleRoot") + @"\approot\setupTomcat.bat", tomcatLocation, tomcatPort, Environment.GetEnvironmentVariable("RoleRoot") + @"\approot");


            // --> Add these lines within RunTomcat StartTomcat() method after RunCommand but before StartTomcatProcess method is called. 
            ConfigurationHelper.Initialize();

            try
            {
                WarFileDownloader.DownloadToWebApps("WarFileBlobContainer", "WarFileBlobName", "WarFileTargetFileName");
            }
            catch (Exception e)
            {
                Trace.TraceError("Downloading war file failed with exception:{0}", e.Message); 
                throw; // let the role die and be restarted
            }
            // <--



            // Call the StartTomcatProcess to start the tomcat process
            StartTomcatProcess(tomcatLocation);
        }

        /// <summary>
        /// Function to start Tomcat Process
        /// </summary>
        /// <param name="tomcatLocation"></param>
        /// <returns></returns>
        private void StartTomcatProcess(string tomcatLocation)
        {
            try
            {
                // initiating process
                Process newProc = new Process();

                //setting the required properties for the process
                newProc.StartInfo.UseShellExecute = false;
                
                newProc.StartInfo.RedirectStandardOutput = true;

                // setting the localsource path tomcatlocation to the environment variable catalina_home 
                newProc.StartInfo.EnvironmentVariables.Remove("CATALINA_HOME");  
                newProc.StartInfo.EnvironmentVariables.Add("CATALINA_HOME", tomcatLocation.Substring(0, tomcatLocation.Length - 1));
                newProc.StartInfo.EnvironmentVariables.Remove("JRE_HOME");  
                newProc.StartInfo.EnvironmentVariables.Add("JRE_HOME", tomcatLocation.Substring(0, tomcatLocation.Length - 1) + @"\jre1.5.0_19");
                
                // setting the file name  bin\startup.bat in tomcatlocation of localresourcepath 
                newProc.StartInfo.FileName = tomcatLocation + @"bin\startup.bat";
                 
                newProc.EnableRaisingEvents = false;
                // starting process
                Trace.TraceInformation("Starting Tomcat process {0}", newProc.StartInfo.FileName);  

                newProc.Start();

                // getting the process output and logging it
                Trace.TraceInformation("Output information from the Tomcat process:\n");

                StreamReader sr = newProc.StandardOutput;

                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine();
                    Trace.TraceInformation(line);
                }


            }
            catch (Exception ex)
            {
                // Logging the exceptiom
                Trace.TraceError(ex.Message);
            }
        }
        /// <summary>
        /// Function to run setupTomcat.bat which in runnin TomcatConfigManager.exe
        /// </summary>
        /// <param name="batchFile"></param>
        /// <param name="tomcatLocation"></param>
        /// <param name="port"></param>
        /// <param name="appRoot"></param>
        /// <returns></returns>
        private string RunCommand(string batchFile, string tomcatLocation, string port, string appRoot)
        {
            // initiating process
            Process newProc = new Process();
            
            // initiating stream reader to get the output details
            StreamReader sr;
            // string variable to store the output details
            string returnDetails;

            try
            {
                // setting the required properties for the process
                newProc.StartInfo.UseShellExecute = false;
                newProc.StartInfo.RedirectStandardOutput = true;

                // setting the localsource path tomcatlocation to the environment variable catalina_home 
                newProc.StartInfo.EnvironmentVariables.Add("CATALINA_HOME", tomcatLocation.Substring(0, tomcatLocation.Length - 1));
                
                // set the batchFile setupTomcat.bat in approot directory as process filename
                newProc.StartInfo.FileName = batchFile;
                
                // set the follwing three arguments for the process {0} catalina_home - environment variable which has the localresource path
                // {1} - port in which the tomcat has to be run and which needs to be changed in the server xml
                // {2} - approot path
                newProc.StartInfo.Arguments = String.Format("{0} {1} \"{2}\"", "%CATALINA_HOME%", port, appRoot);

                newProc.EnableRaisingEvents = false;
                
                // starting the process
                newProc.Start();

                //getting the output details
                sr = newProc.StandardOutput;

                // storing the output details in the string variable
                returnDetails = sr.ReadToEnd();
               
                // Logging the output details
                Trace.TraceInformation(returnDetails);

                newProc.WaitForExit();
                newProc.Close();

                returnDetails = string.Empty;
                
                //setting the serverxml Configpath
                string serverConfigPath = tomcatLocation + @"conf\server.xml"; 

                //Calling ConfigTomcatPort method to configure the port in server.xml
                ConfigTomcatPort(serverConfigPath,port);  

            }
            catch (Exception ex)
            {
                returnDetails = ex.Message;
                Trace.TraceError(ex.Message); 
            }

            return returnDetails;
        }

        /// <summary>
        /// ConfigTomcatPort method is to configure the port in server.xml
        /// </summary>
        /// <param name="serverConfigPath">Full path location of server.xml</param>
        /// <param name="newPort">New value for connector</param>
        private void ConfigTomcatPort(string serverConfigPath, string newPort)
        {
            try
            {
                XmlDocument config = new XmlDocument();

                // Load \conf\server.xml
                config.Load(serverConfigPath);

                Trace.TraceInformation("Original Value = {0}, New Value = {1}", config.SelectSingleNode("/Server/Service/Connector[@protocol='HTTP/1.1']").Attributes["port"].Value, newPort);

                //Change the port with the new port Arg 1
                config.SelectSingleNode("/Server/Service/Connector[@protocol='HTTP/1.1']").Attributes["port"].Value = newPort;

                Trace.TraceInformation("Updating Server.xml...");

                config.Save(serverConfigPath);

                Trace.TraceInformation("Server.xml updated...");
            }
            catch (Exception ex)
            {
                Trace.TraceError(ex.StackTrace);
            }
        }

    }
}
