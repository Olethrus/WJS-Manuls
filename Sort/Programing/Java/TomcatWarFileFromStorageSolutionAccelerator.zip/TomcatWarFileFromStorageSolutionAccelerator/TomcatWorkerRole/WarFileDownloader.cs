﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using Microsoft.WindowsAzure;
using Microsoft.WindowsAzure.StorageClient;
using Microsoft.WindowsAzure.ServiceRuntime;
using System.Diagnostics;


namespace Tomcat
{
    public static class WarFileDownloader
    {
        public static void DownloadToWebApps(string blobContainerConfigurationSetting, string blobNameConfigurationSetting, string destinationWarFileNameConfigurationSetting)
        {
            Trace.TraceInformation("Getting Configuration setting for '{0}'", destinationWarFileNameConfigurationSetting);
            
            string destinationWarFileName = RoleEnvironment.GetConfigurationSettingValue(destinationWarFileNameConfigurationSetting);

            Trace.TraceInformation("Retrieved value for '{0}' is '{1}'", destinationWarFileNameConfigurationSetting, destinationWarFileName);
            
            string tomcatLocation = RoleEnvironment.GetLocalResource("TomcatLocation").RootPath;
            string destinationPath = Path.Combine(tomcatLocation, @"webapps\" + destinationWarFileName);

            DownloadFile(blobContainerConfigurationSetting, blobNameConfigurationSetting, destinationPath);
        }

        public static void DownloadFile(string blobContainerConfigurationSetting, string blobNameConfigurationSetting, string destinationPath)
        {
            string blobContainer = RoleEnvironment.GetConfigurationSettingValue(blobContainerConfigurationSetting);
            string blobName = RoleEnvironment.GetConfigurationSettingValue(blobNameConfigurationSetting);

            BlobHelper.DownloadFileFromBlob(blobContainer, blobName, destinationPath);
        }
    }

    static class BlobHelper
    {
        public static void DownloadFileFromBlob(string containerName, string blobName, string destinationPath)
        {
            CloudStorageAccount storageAccount = CloudStorageAccount.FromConfigurationSetting("DataConnectionString");
            CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
            CloudBlobContainer blobContainer = blobClient.GetContainerReference(containerName);
            CloudBlob blob = blobContainer.GetBlobReference(blobName);
            blob.DownloadToFile(destinationPath);

        }
    }
}
