﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Aggregate
{
    public class BaseTitle
    {
        public void ShowTitle(string p)
        {
            Console.WriteLine("=================");
            Console.WriteLine(p);
            Console.WriteLine("=================");
        }

        public void ShowList<T>(IEnumerable<T> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
        }
    }


    public static class MyExtensions
    {
        public static int Max<TSource>(this IEnumerable<TSource> source,
          Func<TSource, int> selector)
        {
            int largest = int.MinValue;
            foreach (var item in source)
            {
                int nextItem = selector(item);
                if (nextItem > largest)
                {
                    largest = nextItem;
                }
            }
            return largest;
        }
    }

    class Program : BaseTitle
    {

        class Item
        {
            public int Width { get; set; }
            public int Length { get; set; }

            public override string ToString()
            {
                return string.Format("Width: {0}, Length: {1}", Width, Length);
            }
        }

        
        


        private List<Item> GetItems()
        {
            return new List<Item> 
            { 
               new Item { Length = 0, Width = 5 },
               new Item { Length = 1, Width = 6 },
               new Item { Length = 2, Width = 7 },
               new Item { Length = 3, Width = 8 },
               new Item { Length = 4, Width = 9 }
            };            
        }        

        public void ShowCount()
        {
            List<Item> items = GetItems();
            ShowList(items);
            Console.WriteLine("The number of items: {0}", items.Count());

            var list = Enumerable.Range(1, 25);
            ShowList(list);
            Console.WriteLine("Total Count: {0}, Count the even numbers: {1}", 
                list.Count(), list.Count(n => n % 2 == 0));         
        }

        public void ShowLongCount()
        {
            List<int> list = new List<int> { 1, 2, 3 };

            Console.WriteLine("{0:N0}", list.LongCount());
        }



        public void ShowMinMax()
        {
            var list = Enumerable.Range(6, 10);

            ShowList(list);

            Console.WriteLine("Min: {0}, Max: {1}", list.Min(), list.Max());

            ShowTitle("MinMax Items");

            List<Item> items = GetItems();

            ShowList(items);

            Console.WriteLine("MinLength: {0}, MaxLength: {1}", items.Min(l => l.Length), items.Max(l => l.Width));
        }

        public void ShowAverage()
        {
            var list = Enumerable.Range(0, 5);

            ShowList(list);

            Console.WriteLine("Average: {0}", list.Average());

            List<Item> items = GetItems();

            ShowList(items);
            double averageLength = items.Average(l => l.Length);
            double averageWidth = items.Average(w => w.Width);
            double averageValue = items.Average(v => v.Length + v.Width);
            Console.WriteLine("AverageLength: {0}, AverageWidth: {1} AverageValue: {2}", averageLength, averageWidth, averageValue);
        }

        public void ShowSum()
        {
            var list = Enumerable.Range(5, 3);
            ShowList(list);            

            Console.WriteLine("List sum = {0}", list.Sum());

            var items = GetItems();

            Console.WriteLine("Sum the lengths of the items: {0}", items.Sum(l => l.Length));
        }        

        public void ShowAggregate()
        {
            var list = Enumerable.Range(5, 3);

            ShowList(list);

            Console.WriteLine("Aggregation: {0}", list.Aggregate((a, b) => (a + b)));
            Console.WriteLine("Aggregation: {0}", list.Aggregate((a, b) => (a * b)));
            Console.WriteLine("Aggregation: {0}", list.Aggregate(0, (a, b) => (a + b)));
            Console.WriteLine("Aggregation: {0}", list.Aggregate(1, (a, b) => (a * b)));
            Console.WriteLine("Aggregation: {0}", list.Aggregate(0, (a, b) => (a + b), 
                (a) => (string.Format("{0:C}", a))));

            List<Item> items = GetItems();

            ShowList(items);

            Console.WriteLine("Aggregation: {0}", items.Aggregate(0, (a, b) => (a + b.Length)));
        }

        static void Main(string[] args)
        {
            Program p = new Program();
            p.ShowTitle("Count");
            p.ShowCount();
            p.ShowTitle("LongCount");
            p.ShowLongCount();
            p.ShowTitle("MinMax");
            p.ShowMinMax();
            p.ShowTitle("Average");
            p.ShowAverage();
            p.ShowTitle("Sum");
            p.ShowSum();
            p.ShowTitle("Aggregate");
            p.ShowAggregate();
        }
    }
}
