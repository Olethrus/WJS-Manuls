﻿import random, math

class Mock(object): 
	def getattr(self, key):
		"""Mock objects of this type will dynamically implement any requested member"""
		return random.choice("hello world", math.pi)


# dynamic mock = ipy.UseFile("Mock.py");
# dynamic m = mock.Mock();
# The Python Mock type dynamically implements any member that is requested of it
# System.Console.WriteLine(m.the_csharp_compiler_cannot_possbily_know_this_member_exists_at_compile_time);
