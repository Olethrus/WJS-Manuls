﻿using System;
using System.Collections.Generic;

/*
 * The code from Eric Lippert's video on CoVariance and Contravariance.
 * The Titles:
 *  How Do I Use Covariance and Contravariance Part 1
 *  How Do I Use Covariance and Contravariance Part 2
 * URLs at publication time: 
 *  http://msdn.microsoft.com/en-us/vcsharp/ee672314.aspx
 *  http://msdn.microsoft.com/en-us/vcsharp/ee672319.aspx
 */
namespace ContraCovariance
{
    abstract class Person { public string Name { get; set; } }
    abstract class Employee : Person { }
    class Manager : Employee { }
    class Customer : Person { }

    abstract class Game { }
    abstract class BoardGame : Game { }
    class Chess : BoardGame { }

    interface ITaggedItem<out T>
    {
        T Value { get; }
        string Tag { get; }
    }

    class TaggedItem<T> : ITaggedItem<T>
    {
        public T Value { get; private set; }
        public string Tag { get; private set; }
        public TaggedItem(T Value, string tag)
        {
            this.Value = Value;
            this.Tag = tag;
        }
    }

    /// <summary>
    /// "Covariant is about stuff coming out, contravariant is almost
    /// always about stuff coming in. There are some exceptions to that
    /// rule, but those are complicated weird situations that we aren't 
    /// going to talk about today." - Eric Lippert
    /// </summary>
    class Program
    {
        delegate void MyAction<in T1, in T2>(T1 t1, T2 t2);

        static void M1(Person[] persons)
        {
            persons[0] = new Customer();
        }

        static void M2(IEnumerable<Person> persons) { }

        static void M3(ITaggedItem<BoardGame> taggedGame) { }

        static void Main(string[] args)
        {
            Employee[] employees = new[] { new Manager() };
            // M1(employees);
            IEnumerable<Employee> emp2 = employees;
            M2(emp2);

            var chess = new TaggedItem<Chess>(new Chess(), "Civil War");
            M3(chess);

            // TaggedItem<Game> game = chess;

            MyAction<Person, string> setName = (p, s) => { p.Name = s; };
            MyAction<Employee, string> setName2 = setName;

            IComparable<Employee> comp1 = null;
            IComparable<Manager> comp2 = comp1;            
        }
    }
}
