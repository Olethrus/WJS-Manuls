﻿namespace DynamicExample
{
    using global::System;
    using global::System.Collections.Generic;
    using global::System.Dynamic;
    using global::System.Linq.Expressions;

    public class MethodBag : DynamicObject
    {
        private abstract class MethodDescription
        {
            internal abstract int NumberOfParameters
            {
                get;
            }

            internal Expression target
            {
                get;
                set;
            }

            internal abstract object Invoke(object[] parms);
        }

        private class ActionDescription : MethodDescription
        {
            internal override object Invoke(object[] parms)
            {
                var target2 = target as Expression<Action>;
                target2.Compile().Invoke();
                return null;
            }

            internal override int NumberOfParameters
            {
                get { return 0; }
            }
        }

        private class ActionOfTDescription : MethodDescription
        {
            internal override object Invoke(object[] parms)
            {
                dynamic target2 = target;
                target2.Compile().Invoke(parms[0]);
                return null;
            }

            internal override int NumberOfParameters
            {
                get { return 1; }
            }
        }
        private class FuncDescription : MethodDescription
        {
            internal override object Invoke(object[] parms)
            {
                dynamic target2 = target;
                return target2.Compile().Invoke();
            }

            internal override int NumberOfParameters
            {
                get { return 0; }
            }
        }

        private class FuncofTDescription : MethodDescription
        {
            internal override object Invoke(object[] parms)
            {
                dynamic target2 = target;
                return target2.Compile().Invoke(parms[0]);
            }

            internal override int NumberOfParameters
            {
                get { return 1; }
            }
        }

        public void SetMethod(string name, Expression<Action> lambda)
        {
            var desc = new ActionDescription { target = lambda };
            methods.Add(name, desc);
        }

        public void SetMethod<T>(string name, Expression<Action<T>> lambda)
        {
            var desc = new ActionOfTDescription { target = lambda };
            methods.Add(name, desc);
        }

        public void SetMethod<TResult>(string name, Expression<Func<TResult>> lambda)
        {
            var desc = new FuncDescription { target = lambda };
            methods.Add(name, desc);
        }

        public void SetMethod<T1, TResult>(string name, Expression<Func<T1, TResult>> lambda)
        {
            var desc = new FuncofTDescription { target = lambda };
            methods.Add(name, desc);
        }

        private Dictionary<string, MethodDescription> methods = new Dictionary<string, MethodDescription>();

        public override bool TryInvokeMember(InvokeMemberBinder binder, object[] args, out object result)
        {
            result = null;
            if (!methods.ContainsKey(binder.Name))
                return false;

            MethodDescription method = methods[binder.Name];

            if (method.NumberOfParameters != args.Length)
                return false;
            result = method.Invoke(args);
            return true;
        }
    }
}
