﻿namespace DynamicExample
{
    using global::System;
    using global::System.Linq;

    class Program
    {
        static void Main(string[] args)
        {
            // Create an object that contains some new methods:
            var newType = new MethodBag();
            newType.SetMethod("Write", () => Console.WriteLine("Hello World"));
            newType.SetMethod("Display", (string parm) => Console.WriteLine(parm));

            newType.SetMethod("IsValid", () => true);
            newType.SetMethod("Square", (int num) => num * num);
            newType.SetMethod("Sequence", () => from n in Enumerable.Range(1, 100)
                                           where n % 5 == 2
                                           select n * n);

            // Change from static to dynamic typing:
            dynamic dispatcher = newType;
            dispatcher.Write();

            var result = dispatcher.IsValid();
            Console.WriteLine(result);

            dispatcher.Display("This is a message");
            var result2 = dispatcher.Square(5);
            Console.WriteLine(result2);

            var sequence = dispatcher.Sequence();
            foreach (var num in sequence)
                Console.WriteLine(num);
        }
    }
}
