﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication50
{
    public class Customer
    {
        private string firstName;
        public string FirstName
        {
            get
            {
                if (firstName.Length == 0)
                {
                    throw new Exception("Error");
                }
                else
                {
                    return firstName;
                }
                
            }

            set
            {
                firstName = value;
            }
        }

        public string LastName { get; set; }

        public override string ToString()
        {
            return string.Format("{{ Firstname = {0} LastName = {1} }}", FirstName, LastName);
        }        
    }

    public static class MyExtensions
    {
        public static bool IsSuzie(this Customer customer)
        {
            return customer.FirstName == "Suzie";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {            

            var list = new List<Customer> 
            { 
                new Customer() { FirstName = "Alice", LastName = "Smith" },
                new Customer() { FirstName = "Suzie", LastName = "Smith" },
                new Customer() { FirstName = "Freddie", LastName = "Programmer" }
            };

            foreach (var item in list)
            {
                if (item.IsSuzie())
                {
                    Console.WriteLine(item);
                }
            }
        }
    }
}










