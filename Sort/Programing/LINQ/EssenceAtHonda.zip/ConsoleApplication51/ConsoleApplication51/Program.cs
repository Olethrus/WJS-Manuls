﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;


namespace ConsoleApplication51
{
    class Program
    {
        public static void CallDelegate(Func<int, int, int> func)
        {
            Console.WriteLine(func(2, 3));
        }

        public static int Add(int a, int b)
        {
            return a + b;
        }

        static void Main(string[] args)
        {
            Console.WriteLine(Add(2, 3));

            Func<int, int, int> myDelegate = Add;

            Console.WriteLine(myDelegate(2, 3));

            CallDelegate(myDelegate);

            Func<int, int, int> myLambda = (a, b) => (a + b);

            Console.WriteLine(myLambda(2, 3));

            CallDelegate(myLambda);

            Expression<Func<int, int, int>> myExpression = (a, b) => (a + b);

            BinaryExpression body = (BinaryExpression)myExpression.Body;

            Console.WriteLine(body);

            ParameterExpression left = (ParameterExpression)body.Left;
            ParameterExpression right = (ParameterExpression)body.Right;
            ExpressionType nodeType = body.NodeType;

            Console.WriteLine("{0} {1} {2}", left, nodeType, right);

        }
    }
}








