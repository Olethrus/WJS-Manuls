﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication52
{
    public static class MyExtensions
    {
        public static IEnumerable<T> Where<T>(this IEnumerable<T> source, Func<T, bool> predicate)
        {
            foreach (var item in source)
            {
                if (predicate(item))
                {
                    yield return item;
                }
            }
        }
    }

    class Program
    {
        public static IEnumerable<int> GetList()
        {
            var length = 3;

            for (int i = 1; i <= length; i++)
            {
                yield return i;
            }
        }

        static void Main(string[] args)
        {
            // var list = new List<int> { 1, 2, 3 };


            var query = from num in GetList()
                        where num < 3
                        select num;

            //var query = GetList().Where((num) => (num < 3));

            foreach (var item in query)
            {
               Console.WriteLine(item);
            }
        }
    }
}
