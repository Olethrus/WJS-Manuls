﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApplication53
{
    class Program
    {
        static void Main(string[] args)
        {
            DataClasses1DataContext db = new DataClasses1DataContext();

            var query = from c in db.Customers
                        where c.City == "London"
                        select c;

            db.Log = Console.Out;

            foreach (var item in query)
            {
                Console.WriteLine(item.CompanyName);
            }
        }
    }
}
