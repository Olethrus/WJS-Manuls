﻿using System;

namespace GenerateFromUsage
{
    class Automobile
    {
        private string Make;
        private string Model;

        public Automobile(string Make, string Model)
        {
            // TODO: Complete member initialization
            this.Make = Make;
            this.Model = Model;
        }

        internal void TurnLeft(object distance)
        {
            Console.WriteLine("throw new NotImplementedException();");
        }

        public bool IsFacingNorth { get; set; }
    }
}
