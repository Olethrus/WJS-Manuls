﻿
namespace GenerateFromUsage
{
    class Program
    {
        private static object distance;
        static void Main(string[] args)
        {
            var myCar = new Automobile(Make: "Honda", Model: "Accord");
            myCar.TurnLeft(distance);
            myCar.IsFacingNorth = true;
        }
    }
}
