﻿using System.Collections.Generic;

namespace Customer.Models
{
    public class CustomerList
    {
        List<string> list = new List<string>();

        public void Add(string p)
        {
            list.Add(p);
        }
    }
}
