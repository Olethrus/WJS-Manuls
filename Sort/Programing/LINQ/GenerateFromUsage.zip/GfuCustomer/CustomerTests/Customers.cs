﻿using Customer.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CustomerTests
{
    [TestClass]
    public class Customers
    {
        [TestMethod]
        public void IsCustomerListValid()
        {
            CustomerList cust = new CustomerList();
            cust.Add("Karen");
            Assert.IsNotNull(cust);
        }
    }
}
