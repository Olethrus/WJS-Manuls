﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LINQFarmOpFlare01
{
    class Program
    {
        static void Main(string[] args)
        {            
            var query = from m in typeof(Enumerable).GetMethods()
                        orderby m.Name
                        where m.DeclaringType == typeof(Enumerable)                        
                        group m by m.Name into g
                        orderby g.Count()
                        select new { Operator = g.Key, OverrideCount = g.Count() };
                      
            Console.WriteLine("Approximate operator count: {0}", query.Count());

            foreach (var q in query)
            {
                Console.WriteLine(q);
            }
        }
    }
}
