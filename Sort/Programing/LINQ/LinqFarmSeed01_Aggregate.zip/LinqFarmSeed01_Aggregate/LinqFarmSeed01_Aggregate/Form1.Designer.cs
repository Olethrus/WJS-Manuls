﻿namespace LinqFarmSeed01_Aggregate
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonExecute = new System.Windows.Forms.Button();
            this.textBoxNumberOfItems = new System.Windows.Forms.TextBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.buttonClose = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.buttonShowCode = new System.Windows.Forms.Button();
            this.textBoxFirstItem = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonExecute
            // 
            this.buttonExecute.Location = new System.Drawing.Point(93, 229);
            this.buttonExecute.Name = "buttonExecute";
            this.buttonExecute.Size = new System.Drawing.Size(75, 23);
            this.buttonExecute.TabIndex = 1;
            this.buttonExecute.Text = "Aggregate";
            this.buttonExecute.UseVisualStyleBackColor = true;
            this.buttonExecute.Click += new System.EventHandler(this.buttonAggregate_Click);
            // 
            // textBoxNumberOfItems
            // 
            this.textBoxNumberOfItems.Location = new System.Drawing.Point(154, 23);
            this.textBoxNumberOfItems.Name = "textBoxNumberOfItems";
            this.textBoxNumberOfItems.Size = new System.Drawing.Size(118, 20);
            this.textBoxNumberOfItems.TabIndex = 3;
            this.textBoxNumberOfItems.Text = "3";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(12, 49);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(260, 173);
            this.listBox1.TabIndex = 2;
            this.listBox1.TabStop = false;
            // 
            // buttonClose
            // 
            this.buttonClose.Location = new System.Drawing.Point(12, 229);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(75, 23);
            this.buttonClose.TabIndex = 0;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(151, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(109, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Number of items in list";
            // 
            // buttonShowCode
            // 
            this.buttonShowCode.Location = new System.Drawing.Point(175, 229);
            this.buttonShowCode.Name = "buttonShowCode";
            this.buttonShowCode.Size = new System.Drawing.Size(75, 23);
            this.buttonShowCode.TabIndex = 2;
            this.buttonShowCode.Text = "Show Code";
            this.buttonShowCode.UseVisualStyleBackColor = true;
            this.buttonShowCode.Click += new System.EventHandler(this.buttonShowCode_Click);
            // 
            // textBoxFirstItem
            // 
            this.textBoxFirstItem.Location = new System.Drawing.Point(12, 23);
            this.textBoxFirstItem.Name = "textBoxFirstItem";
            this.textBoxFirstItem.Size = new System.Drawing.Size(112, 20);
            this.textBoxFirstItem.TabIndex = 4;
            this.textBoxFirstItem.Text = "3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "First Item in Sequence";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 264);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBoxFirstItem);
            this.Controls.Add(this.buttonShowCode);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonClose);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.textBoxNumberOfItems);
            this.Controls.Add(this.buttonExecute);
            this.Name = "Form1";
            this.Text = "Aggregate((a, b) => a + b);";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonExecute;
        private System.Windows.Forms.TextBox textBoxNumberOfItems;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button buttonShowCode;
        private System.Windows.Forms.TextBox textBoxFirstItem;
        private System.Windows.Forms.Label label2;
    }
}

