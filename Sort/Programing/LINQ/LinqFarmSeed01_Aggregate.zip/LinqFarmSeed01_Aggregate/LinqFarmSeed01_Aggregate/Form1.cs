﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace LinqFarmSeed01_Aggregate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            buttonAggregate_Click(null, null);
        }

        private int AddEm(int a, int b)
        {
            return a + b;
        }

        private void buttonAggregate_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            int firstItem = int.Parse(textBoxFirstItem.Text);
            int count = int.Parse(textBoxNumberOfItems.Text);            

            if (count < 25000)
            {
                List<int> integers = new List<int>();
                for (int i = firstItem; i < firstItem + count; i++)
                {                    
                    integers.Add(i);
                }

                foreach (var item in integers)
                {
                    listBox1.Items.Add(item);   
                }
                int sum = integers.Aggregate((a, b) => a + b);
                // int sum = integers.Aggregate(AddEm);

                listBox1.Items.Add("----------");
                listBox1.Items.Add(sum);
                listBox1.SetSelected(listBox1.Items.Count - 1, true);
            }
            else
            {
                MessageBox.Show("Please enter a smaller number");
            }

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonShowCode_Click(object sender, EventArgs e)
        {
            string code = @"                int value = int.Parse(textBox1.Text);
                List<int> integers = new List<int>();
                for (int i = 0; i < value; i++)
                {
                    listBox1.Items.Add(i);
                    integers.Add(i);
                }               

                int sum = integers.Aggregate((a, b) => a + b);";

            MessageBox.Show(code);
        }
    }
}
