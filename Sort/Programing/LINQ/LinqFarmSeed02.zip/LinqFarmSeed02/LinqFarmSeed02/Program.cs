﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LinqFarmSeed02
{
    class Program
    {
        private static string ReverseString(string sentence)
        {
            List<string> words = new List<string>(sentence.Split(' ').ToList());

            return words.Aggregate((a, b) => b + " " + a);            
        }

        static void Main(string[] args)
        {
            string sentence = "The end is the beginning, the beginning the end";
            Console.WriteLine(sentence);

            string result = ReverseString(sentence);
            Console.WriteLine(result);
        }        
    }
}
