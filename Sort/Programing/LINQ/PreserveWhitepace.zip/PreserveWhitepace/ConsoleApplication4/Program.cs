﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.IO;
using System.Xml;

namespace ConsoleApplication4
{
    class Program
    {

        static string readFileName = "test.xml";
        static string createFileName = @"..\..\test1.xml";

        static void Main(string[] args)
        {            
            ShowTitle("PreseveFormat01");
            PreserveFormat01();
            ShowTitle("PreseveFormat02");
            PreserveFormat02();
            ShowTitle("Clean Format");
            CleanFormat();
            //ShowTitle("Clean Format 02");
            //CleanFormat02();
        }

        private static void PreserveFormat01()
        {
            XDocument x = XDocument.Load(readFileName, LoadOptions.PreserveWhitespace);
            x.Save(createFileName, SaveOptions.DisableFormatting);

            ReadAsText(createFileName);
        }

        private static void PreserveFormat02()
        {
            XDocument x2 = XDocument.Load(readFileName,
                LoadOptions.PreserveWhitespace | LoadOptions.SetLineInfo);
            
            XText value = (from c in x2.Elements().DescendantNodes().OfType<XText>()
                           where c.Value.Trim().Length > 0
                           select c).Single();


            IXmlLineInfo x = (IXmlLineInfo)value;
            Console.WriteLine("Line Number: {0}", x.LineNumber);
            value.Value = Environment.NewLine + "  Sue  " + Environment.NewLine;


            x2.Save(createFileName, SaveOptions.DisableFormatting);

            ShowTitle("Format after query");
            ReadAsText(createFileName);
        }

        private static void CleanFormat()
        {
            XDocument x2 = XDocument.Load(readFileName);

            var query = from c in x2.Elements().DescendantNodes().OfType<XText>()
                        select c;

            foreach (var item in query)
            {
                item.Value = item.Value.Trim();
            }
            
            x2.Save(createFileName);
            ReadAsText(createFileName);
        }

        private static void CleanFormat02()
        {
            XDocument x2 = XDocument.Load(readFileName);

            var query = from c in x2.Elements().DescendantNodes().OfType<XText>()
                        select c;

            foreach (var item in query)
            {
                item.Value = item.Value.Trim();
            }
            
            x2.Save(createFileName, SaveOptions.DisableFormatting);
            ReadAsText(createFileName);
        }

        private static void ReadAsText(string fileName)
        {
            string s = File.ReadAllText(fileName);
            Console.WriteLine(s);
        }

        public static void ShowTitle(string p)
        {
            Console.WriteLine("=================");
            Console.WriteLine(p);
            Console.WriteLine("=================");
        }
    }
}
