﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SetOperators
{
    public class BaseTitle
    {
        public static void ShowTitle(string p)
        {
            Console.WriteLine("=================");
            Console.WriteLine(p);
            Console.WriteLine("=================");
        }

        public static void ShowList<T>(IEnumerable<T> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item);
            }
        }
    }    
}
