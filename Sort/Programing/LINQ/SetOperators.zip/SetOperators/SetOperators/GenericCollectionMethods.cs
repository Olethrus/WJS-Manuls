﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SetOperators
{
    class GenericCollectionMethods : BaseTitle
    {
        public void ShowMethods2()
        {
            var queryList = (from m in typeof(List<int>).GetMethods()
                             where m.DeclaringType == typeof(List<int>)
                             group m by m.Name into g
                             select g.Key).Intersect(from m in typeof(ArrayList).GetMethods()
                                                     where m.DeclaringType == typeof(ArrayList)
                                                     group m by m.Name into g
                                                     select g.Key);

            ShowTitle("ShowMethods2");
            ShowList(queryList);
        }

        public void ShowMethods()
        {
            var queryList = from m in typeof(List<int>).GetMethods()
                            where m.DeclaringType == typeof(List<int>)
                            group m by m.Name into g
                            select g.Key;

            var queryArray = from m in typeof(ArrayList).GetMethods()
                             where m.DeclaringType == typeof(ArrayList)
                             group m by m.Name into g
                             select g.Key;

            ShowTitle("QueryList");
            Console.WriteLine("Count: {0}", queryList.Count());
            ShowList(queryList);
            ShowTitle("QueryArray");
            Console.WriteLine("Count: {0}", queryArray.Count());
            ShowList(queryArray);
            ShowTitle("Intersect");

            var listIntersect = queryList.Intersect(queryArray);
            Console.WriteLine("Count: {0}", listIntersect.Count());
            ShowList(listIntersect);

            var listDifference = queryList.Except(listIntersect);
            ShowTitle("Difference");
            ShowList(listDifference);
        }
    }
}
