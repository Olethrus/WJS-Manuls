﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SetOperators
{
    class Program: BaseTitle
    {
        static void Main(string[] args)
        {
            Program p = new Program();
            ShowTitle("ShowUnion");
            p.ShowUnion();
            ShowTitle("ShowIntersect");
            p.ShowIntersect();
            ShowTitle("ShowExcept");
            p.ShowExcept();
            ShowTitle("ShowDistinct");
            p.ShowDistinct();

            ShowTitle("Romans");
            Romans r = new Romans();
            r.ShowSets();

            ShowTitle("Methods");
            GenericCollectionMethods g = new GenericCollectionMethods();
            g.ShowMethods();
        }

        public void ShowDistinct() 
        {
            var listA = new List<int> { 1, 2, 3, 3, 2, 1 };
            var listB = listA.Distinct();

            foreach (var item in listB)
            {
                Console.WriteLine(item);
            }
        }

        public void ShowUnion()
        {
            var listA = Enumerable.Range(1, 3);
            var listB = new List<int> { 3, 4, 5, 6 };

            var listC = listA.Union(listB);

            foreach (var item in listC)
            {
                Console.WriteLine(item);
            }
        }

        public void ShowExcept() 
        {
            var listA = Enumerable.Range(1, 6);
            var listB = new List<int> { 3, 4 };

            var listC = listA.Except(listB);

            foreach (var item in listC)
            {
                Console.WriteLine(item);
            }
        }

        public void ShowIntersect()
        {
            var listA = Enumerable.Range(1, 4);
            var listB = new List<int> { 3, 4, 5, 6 };

            var listC = listA.Intersect(listB);

            foreach (var item in listC)
            {
                Console.WriteLine(item);
            }
        }              
    }
}
