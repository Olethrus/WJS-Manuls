﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SetOperators
{
     public class Roman
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public char Gender { get; set; }
        public string City { get; set; }
        public Roman() { City = "Unknown"; }
    }

    public class Romans: BaseTitle
    {
        private List<Roman> romans = new List<Roman>() 
        {            
             new Roman() { Id = 00, Name = "Augustus", Gender = 'm', City = "Rome" },
             new Roman() { Id = 01, Name = "Tiberius", Gender = 'm', City = "Rome"  },
             new Roman() { Id = 02, Name = "Caligula", Gender = 'm', City = "Antium"  },
             new Roman() { Id = 03, Name = "Claudius", Gender = 'm', City = "Lugdunum"  },
             new Roman() { Id = 04, Name = "Nero", Gender = 'm', City = "Antium"  },
             new Roman() { Id = 05, Name = "Scribonia", Gender = 'f' },
             new Roman() { Id = 06, Name = "Clodia Pulchra", Gender = 'f' },
             new Roman() { Id = 07, Name = "Livia Drusilla", Gender = 'f' },
             new Roman() { Id = 08, Name = "Plautia Urgulanilla", Gender = 'f' },
             new Roman() { Id = 09, Name = "Aelia Paetina", Gender = 'f' },
             new Roman() { Id = 10, Name = "Messalina", Gender = 'f', City="Rome"  },
             new Roman() { Id = 12, Name = "Vipsania Agrippina", Gender = 'f' },
             new Roman() { Id = 13, Name = "Julia the Elder", Gender = 'f' },
             new Roman() { Id = 14, Name = "Junia Claudilla", Gender = 'f' },
             new Roman() { Id = 15, Name = "Livia Orestilla", Gender = 'f' },
             new Roman() { Id = 16, Name = "Lollia Paulina", Gender = 'f' },
             new Roman() { Id = 17, Name = "Caesonia", Gender = 'f' },
             new Roman() { Id = 18, Name = "Claudia Octavia",Gender='f',City="Rome"},
             new Roman() { Id = 19, Name = "Poppaea Sabina",Gender='f',City="Pompeii"},
             new Roman() { Id = 20, Name = "Statilia Messalina", Gender = 'f' },
             new Roman() { Id = 11, Name = "Agrippina the Younger", Gender = 'f', City = "Oppidum Ubiorum" }
        };
        

        public void ShowSets()
        {
            var women = from r in romans
                        where r.Gender == 'f'
                        select r.City;

            var men = from r in romans
                      where r.Gender == 'm'
                      select r.City;

            ShowTitle("Men");
            ShowList(men.Distinct());
            ShowTitle("Women");
            ShowList(women.Distinct());

            ShowTitle("Union");

            var queryUnion = men.Union(women);

            foreach (var item in queryUnion)
            {
                Console.WriteLine(item);
            }


            ShowTitle("Intersect");

            var queryIntersect = men.Intersect(women);            

            foreach (var item in queryIntersect)
            {
                Console.WriteLine(item);
            }

            ShowTitle("Except");

            var queryExcept = men.Except(women);

            foreach (var item in queryExcept)
            {
                Console.WriteLine(item);
            }

            ShowTitle("Distinct");

            var queryDistinct = men.Distinct();

            foreach (var item in queryDistinct)
            {
                Console.WriteLine(item);
            }
        }       
    }
}
