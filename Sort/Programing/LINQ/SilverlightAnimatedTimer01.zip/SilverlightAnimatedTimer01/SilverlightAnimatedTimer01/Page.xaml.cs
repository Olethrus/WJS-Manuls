﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightAnimatedTimer01
{
    public partial class Page : UserControl
    {
        Double imageX = 0.0;
        Double imageY = 0.0;
        Double rectX = 275.0;
        Double rectY = 1.0;
        Double incValue = 1.0;

        public Page()
        {
            InitializeComponent();
            myRect.SetValue(Canvas.LeftProperty, 275.0);
            myRect.SetValue(Canvas.TopProperty, 1.0);
        }

        private void StartTimer(object sender, RoutedEventArgs e)
        {
            System.Windows.Threading.DispatcherTimer myDispatcherTimer = 
                new System.Windows.Threading.DispatcherTimer();
            // Call the timer once every 10 milliseconds
            myDispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 10); 
            myDispatcherTimer.Tick += new EventHandler(MoveShapes);
            myDispatcherTimer.Start();
        }        
        

        /// <summary>
        /// Called by the timer
        /// </summary>
        /// <param name="o"></param>
        /// <param name="sender"></param>
        public void MoveShapes(object o, EventArgs sender)
        {
            imageX += incValue;
            imageY += incValue;
            rectX -= incValue;
            rectY += incValue;            

            myRect.SetValue(Canvas.LeftProperty, rectX);
            myRect.SetValue(Canvas.TopProperty, rectY);

            myImage.SetValue(Canvas.LeftProperty, imageX);
            myImage.SetValue(Canvas.TopProperty, imageY);
        }

    }
}
