﻿using GameLibrary;
using GameLibrary.Utils;
using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightAnimatedTimer01
{
    public class GameCore
    {
        private MrBlue mrBlue = null;
        private MrRect mrRect = null;
        private Page page = null;        

        public GameCore(Page page)
        {
            this.page = page;
            mrBlue = new MrBlue(page.myImage, 0.0, 0.0);
            mrRect = new MrRect(page.myRect, 325.0, 0.0);
            InitBounds();
        }

        public void MainLoop()
        {
            mrRect.Move();
            mrBlue.Move();
            ShowProgramData();
        }

        private void ShowProgramData()
        {
            string xValue = Strings.PadLeft(mrRect.X.ToString(), '0', 3);
            string yValue = Strings.PadLeft(mrRect.Y.ToString(), '0', 3);
            if (Double.IsNaN(page.myCanvas.ActualHeight) || Double.IsNaN(page.myCanvas.ActualWidth))
            {
                page.myTextBlock.Text = "Not a number";
            }
            else
            {

                page.myTextBlock.Text = "Height " + page.myCanvas.ActualHeight.ToString()
                    + " " + "Width = " + page.myCanvas.ActualWidth.ToString()
                    + " " + "X = " + xValue
                    + " " + "Y = " + yValue;                
            }
        }

        private void InitBounds()
        {
            mrRect.SetBounds(Convert.ToInt32(page.myCanvas.ActualWidth), Convert.ToInt32(page.myCanvas.ActualHeight));
            mrBlue.SetBounds(Convert.ToInt32(page.myCanvas.ActualWidth), Convert.ToInt32(page.myCanvas.ActualHeight));
        }
    }
}
