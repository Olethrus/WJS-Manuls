﻿using GameLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightAnimatedTimer01
{
   

    public partial class Page : UserControl
    {

        GameCore gameCore = null;

        public Page()
        {
            InitializeComponent();
            gameCore = new GameCore(this);                   
        }

        private void StartTimer(object sender, RoutedEventArgs e)
        {
            System.Windows.Threading.DispatcherTimer myDispatcherTimer = 
                new System.Windows.Threading.DispatcherTimer();
            myDispatcherTimer.Interval = new TimeSpan(0, 0, 0, 0, 10); 
            myDispatcherTimer.Tick += new EventHandler(Each_Tick);
            myDispatcherTimer.Start();
        }        
        
        public void Each_Tick(object o, EventArgs sender)
        {
            gameCore.MainLoop();
        }
    }
}
