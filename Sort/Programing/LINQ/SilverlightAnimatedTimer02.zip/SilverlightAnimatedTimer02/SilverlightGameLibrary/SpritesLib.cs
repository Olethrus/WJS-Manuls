﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace GameLibrary
{
    public class Sprite
    {
        internal enum MoveType { None, Up, Down, DownLeft, DownRight, UpLeft, UpRight };

        internal Rect containerBounds = new Rect();
        internal FrameworkElement SpriteShape { get; set; }

        public Double Y { get; set; }
        public Double X { get; set; }
        private Double incValue = 1.0;
        internal MoveType ShapeMoveType { get; set; }

        public Sprite()
        {
            ShapeMoveType = MoveType.None;
        }

        public Sprite(FrameworkElement initSpriteShape, Double initX, Double initY)
            : this()
        {
            this.SpriteShape = initSpriteShape;
            this.X = initX;
            this.Y = initY;
        }

        internal void CheckBounds()
        {
            if ((Y + SpriteShape.ActualHeight) > containerBounds.Height)
            {
                if (ShapeMoveType == MoveType.DownRight)
                {
                    ShapeMoveType = MoveType.UpRight;
                }
                else
                {
                    ShapeMoveType = MoveType.UpLeft;
                }
            }
            else if (Y < 0)
            {
                if (ShapeMoveType == MoveType.UpRight)
                {
                    ShapeMoveType = MoveType.DownRight;
                }
                else
                {
                    ShapeMoveType = MoveType.DownLeft;
                }
            }
            else if (X + SpriteShape.ActualWidth > containerBounds.Width)
            {
                if (ShapeMoveType == MoveType.UpRight)
                {
                    ShapeMoveType = MoveType.UpLeft;
                }
                else
                {
                    ShapeMoveType = MoveType.DownLeft;
                }
            }
            else if (X < 0)
            {
                if (ShapeMoveType == MoveType.DownLeft)
                {
                    ShapeMoveType = MoveType.DownRight;
                }
                else
                {
                    ShapeMoveType = MoveType.UpRight;
                }
            }
        }

        virtual public void Move()
        {
            CheckBounds();

            switch (ShapeMoveType)
            {
                case MoveType.None:
                    break;

                case MoveType.DownRight:
                    X += incValue;
                    Y += incValue;
                    break;

                case MoveType.DownLeft:
                    X -= incValue;
                    Y += incValue;
                    break;

                case MoveType.UpRight:
                    X += incValue;
                    Y -= incValue;
                    break;

                case MoveType.UpLeft:
                    X -= incValue;
                    Y -= incValue;
                    break;

                default:
                    throw new Exception("Bad move type");
            }

            SpriteShape.SetValue(Canvas.LeftProperty, X);
            SpriteShape.SetValue(Canvas.TopProperty, Y);
        }

        public void SetBounds(int initWidth, int initHeight)
        {
            containerBounds.X = 0;
            containerBounds.Y = 0;
            containerBounds.Height = initHeight;
            containerBounds.Width = initWidth;
        }
    }

    public class MrRect : Sprite
    {
        public Rectangle myShape { get; set; }

        public MrRect()
            : base()
        {
           
        }

        public MrRect(Rectangle initRect,
            Double initX, Double initY)
            : base(initRect, initX, initY)
        {
            this.myShape = initRect;            
            ShapeMoveType = MoveType.DownLeft;           
        }
                
    }

    public class MrBlue : Sprite
    {
        public Image myImage { get; set; }

        public MrBlue()
            : base()
        {

        }

        public MrBlue(Image initImage,
            Double initX, Double initY)
            : base(initImage, initX, initY)
        {
            myImage = initImage;
            ShapeMoveType = MoveType.DownRight;
        }        
    }
}
