﻿/* 

This file was written by Charlie Calvert and released under 
the Microsoft Public License. Thanks to Lino Tadros and 
Falafel Software.
  
Microsoft Public License (Ms-PL)
Published: October 12, 2006

This license governs use of the accompanying software. If you use the 
software, you accept this license. If you do not accept the license, 
do not use the software.

1. Definitions
The terms “reproduce,” “reproduction,” “derivative works,” and “distribution” have 
the same meaning here as under U.S. copyright law.

A “contribution” is the original software, or any additions or changes to the software.

A “contributor” is any person that distributes its contribution under this license.

“Licensed patents” are a contributor’s patent claims that read directly on its 
contribution.

2. Grant of Rights
 
(A) Copyright Grant- Subject to the terms of this license, including the 
license conditions and limitations in section 3, each contributor grants 
you a non-exclusive, worldwide, royalty-free copyright license to reproduce 
its contribution, prepare derivative works of its contribution, and distribute 
its contribution or any derivative works that you create.

(B) Patent Grant- Subject to the terms of this license, including the license 
conditions and limitations in section 3, each contributor grants you a 
non-exclusive, worldwide, royalty-free license under its licensed patents to 
make, have made, use, sell, offer for sale, import, and/or otherwise dispose 
of its contribution in the software or derivative works of the contribution 
in the software.

3. Conditions and Limitations
(A) No Trademark License- This license does not grant you rights to use any 
contributors’ name, logo, or trademarks.

(B) If you bring a patent claim against any contributor over patents that 
you claim are infringed by the software, your patent license from such 
contributor to the software ends automatically.

(C) If you distribute any portion of the software, you must retain all 
copyright, patent, trademark, and attribution notices that are present 
in the software.

(D) If you distribute any portion of the software in source code form, 
you may do so only under this license by including a complete copy of 
this license with your distribution. If you distribute any portion of 
the software in compiled or object code form, you may only do so under 
a license that complies with this license.

(E) The software is licensed “as-is.” You bear the risk of using it. 
The contributors give no express warranties, guarantees or conditions. 
You may have additional consumer rights under your local laws which 
this license cannot change. To the extent permitted under your local 
laws, the contributors exclude the implied warranties of merchantability, 
fitness for a particular purpose and non-infringement. */

using System;
using System.Collections.Generic;
using System.Text;

namespace GameLibrary.Utils
{
    public class Strings
    {
        public static String PROCESS_DONE = "All done";
        public static String COULD_NOT_PROCESS = "Could not process. Zero byte file?";

        /// <summary>
        /// Convert an array of Byte to a String
        /// </summary>
        /// <param name="array">The array to convert</param>
        /// <returns>The converted array as a string</returns>
        public static String ByteArrayToString(Byte[] array)
        {
            if (array != null)
            {
                int SIZE = array.Length;
                char[] chars = new char[SIZE];
                array.CopyTo(chars, 0);
                return new String(chars, 0, SIZE);
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// Compare a decimal number represented as a string, and one represented
        /// as a Decimal.
        /// </summary>
        /// <param name="decimalValue">The Decimal number to compare</param>
        /// <param name="decimalString">The String number to compare</param>
        /// <returns>True of they are equal</returns>
        public static Boolean CompareDecimalAndString(Decimal decimalValue, String decimalString)
        {
            if (decimalString == null)
            {
                decimalString = "0.0";
            }
            else if (decimalString.Trim().Length == 0)
            {
                decimalString = "0.0";
            }

            if (Decimal.Parse(decimalString) == decimalValue)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// When working with database, we need to get rid of appostrophes and
        /// replace them with two apostrophes.
        /// 
        /// D'Arrigo Bros. / Castroville -- The problem D'Arrigo
        /// 
        /// </summary>
        /// <param name="data">The string to check for the apostrophe problem</param>
        /// <returns>Any apostrophes in this string will have two apostrophes</returns>
        public static String FixQuotes(String data)
        {
            if (data != null)
            {
                return data.Replace("'", "''");
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// Set the first letter of a string to upper or lower case.
        /// </summary>
        /// <param name="data">The string to massage</param>
        /// <param name="useCaps">Should first letter be upper or lower case?</param>
        /// <returns>A string with the first letter set to upper or lower case</returns>

        public static String FirstSmallCaps(String data, bool useCaps)
        {
            if (data.Length > 0)
            {
                StringBuilder sb = new StringBuilder(data);
                if (useCaps)
                {
                    sb[0] = data.Substring(0, 1).ToUpper()[0];
                }
                else
                {
                    sb[0] = data.Substring(0, 1).ToLower()[0];
                }
                return sb.ToString();
            }
            else
            {
                return "";
            }
        }

        /// <summary>
        /// Get the first word from a string.
        /// Returns original value if there are no spaces or if the value
        /// passed in is the empty string.
        /// </summary>
        /// <param name="value">The string from which you want to get the first word</param>
        /// <returns>The first word from the string passed in if there is a first word in the string.</returns>
        public static string GetFirstWord(String value)
        {
            value = value.Trim();
            if (value.Length == 0) return value;
            int index = value.IndexOf(' ');
            if (index <= 0) return value;
            return value.Substring(0, index);
        }

        /// <summary>
        /// Get the first word from a string.
        /// Returns original value if there are no spaces or if the value
        /// passed in is the empty string.
        /// </summary>
        /// <param name="value">The string from which you want to get the first word</param>
        /// <param name="stripSyntax">If its sentence, strip the period?</param>
        /// <returns>The first word from the string passed in if there is a first word in the string.</returns>
        public static string GetLastWord(String value, Boolean stripSyntax)
        {
            value = value.Trim();
            if (value.Length == 0) return "";
            value = Reverse(value);
            value = GetFirstWord(value);
            if (stripSyntax)
            {
                value = Reverse(value);
                if (value[value.Length - 1] == '.')
                {
                    return Shorten(value, value.Length - 1);
                }
                else
                {
                    return value;
                }
            }
            else
            {
                return Reverse(value);
            }
        }

        /// <summary>
        /// Take a string that is in the form of a floating point
        /// number such as "3.3" and convert it into an int such as 3.
        ///
        ///	Goes to nearest whole number. 3.5 becomes 4 and 4.5 
        ///	becomes 4. It rounds up on odd numbers and down on even.
        /// 
        /// To see more of how it behaves, look at the unit test 
        /// in TestFalafelUtils.cs. 
        /// </summary>
        /// <param name="value">A String form of a double</param>
        /// <returns>An integer form of the string</returns>
        public static int GetStringFloatAsInt(String value)
        {
            value = value.Trim();
            if (value.Length > 0)
            {
                Double doubleValue = Convert.ToDouble(value);
                return Convert.ToInt32(doubleValue);
            }

            return 0;
        }

        
        public static Boolean IsInList(List<string> list, string value)
        {
            foreach (String item in list)
            {
                if (item == value)
                    return true;
            }
            return false;
        }

        /// <summary>
        /// Determine whether the string being passed in could be
        /// interpreted as an Integer
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool IsInteger(String value)
        {
            if (value.Length == 0)
                return false;

            bool isNumber = true;
            for (int i = 0; i < value.Length; i++)
            {
                isNumber = (Char.IsNumber(value, i) == true);
                if (isNumber == false)
                    break;
            }

            // Can we convert it to an int?
            if (isNumber == true)
            {
                try
                {
                    int foo = Convert.ToInt32(value);
                }
                catch (System.OverflowException)
                {
                    isNumber = false;
                }
            }

            return isNumber;
        }

        /// <summary>
        /// Convert a string by padding it on the left
        /// For instance, convert "7" to "07"
        /// </summary>
        /// <example>
        /// String.Pad(Convert.ToString(today.Day), '0', 2)
        /// </example>
        /// <param name="value">The string to pad</param>
        /// <param name="ch">The character to insert into the string</param>
        /// <param name="len">The number of characters to insert.</param>
        /// <returns></returns>
        static public String PadLeft(String value, char ch, int len)
        {
            while (value.Length < len)
            {
                value = ch + value;
            }
            return value;
        }

        static public String PadRight(String value, char ch, int len)
        {
            while (value.Length < len)
            {
                value = value + ch;
            }
            return value;
        }

        /// <summary>
        /// Function to Reverse the String
        /// </summary>
        /// <param name="strParam">The string to reverse</param>
        /// <returns>The reversed string</returns> 
        public static String Reverse(String value)
        {
            return Reverse01(value);
        }

        /// <summary>
        /// Function to Reverse the String
        /// </summary>
        /// <param name="strParam">The string to reverse</param>
        /// <returns>The reversed string</returns> 
        private static String Reverse01(String value)
        {
            char[] strArray = value.ToCharArray();
            Array.Reverse(strArray);
            return new string(strArray);
        }

        /// <summary>
        /// Function to Reverse the String
        /// </summary>
        /// <param name="strParam">The string to reverse</param>
        /// <returns>The reversed string</returns> 
        public static String Reverse02(String strParam)
        {
            if (strParam.Length == 1)
            {
                return strParam;
            }
            else
            {
                return Reverse02(strParam.Substring(1)) + strParam.Substring(0, 1);
            }
        }

        /// <summary>
        /// Get the end of a string, after a token
        /// </summary>
        /// <param token="value">The character to split on</param>
        /// <param name="value">The string to split</param>
        /// <returns>The piece that was split from the end of the string</returns>
        public static String GetLastToken(char token, String value)
        {
            String name = Reverse(value);
            int len = name.IndexOf(token, 0);
            if (len != -1)
                name = name.Substring(0, len);
            return Reverse(name);
        }

        /// <summary>
        /// Shorten a string.
        /// </summary>
        /// <param name="input">The string to shorten</param>
        /// <param name="length">The new length of the strings</param>
        /// <returns>The shortened string</returns>
        public static String Shorten(String input, int newLength)
        {
            if (newLength > input.Length) return input;

            StringBuilder temp = new StringBuilder(input, input.Length);
            temp.Length = newLength;
            return temp.ToString();
        }

        public static String StripCharacter(String input, char charToDelete, char newChar)
        {
            return input.Replace(charToDelete, newChar);
        }

        public static String StripCharacter(String input, string charToDelete, string newChar)
        {
            return input.Replace(charToDelete, newChar);
        }

        /// <summary>
        /// Strip characters from the end of a string based on the
        /// offset from the end of a string of a char.  
        /// 
        /// If the character does not appear in the string, then return 
        /// an empty string. In other words, the character set that appear
        /// before the token comprise an empty set.
        /// </summary>
        /// <example>
        /// String value = Strings.StripFromEnd('\\', "d:\\sam\\tom\\fred.txt");
        /// Assert.AreEqual("d:\\sam\\tom", value); 
        /// </example>
        /// <param name="ch">The character to search for</param>
        /// <param name="value">The string to search</param>
        /// <returns>The truncated string</returns>
        public static String StripFromEnd(char ch, String value)
        {
            String name = Reverse(value);
            name = name.Remove(0, name.IndexOf(ch) + 1);
            name = Reverse(name);
            if (name.Equals(value))
            {
                return "";
            }
            else
            {
                return name;
            }
        }

        /// <summary>
        /// Strip characters from the end of a string based on the
        /// offset of a char. Strips off everything after the nth
        /// occurance from the end of the string of a char.			
        /// </summary>
        /// <example>
        /// Pass in StripFromEnd('\\', "d:\sam\tom\fred.txt", 2);
        /// and get "d:\sam" in return.
        /// </example>
        /// <param name="ch">The character to search for</param>
        /// <param name="value">The string to search</param>
        /// <returns>The truncated string</returns>
        public static String StripFromEnd(char ch, String value, int offset)
        {
            String name = Reverse(value);
            for (int i = 0; i < offset; i++)
            {
                name = name.Remove(0, name.IndexOf(ch) + 1);
            }
            name = Reverse(name);

            if (name.Equals(value))
            {
                return "";
            }
            else
            {
                return name;
            }
        }

        /// <summary>
        /// Strip a certain number of characters from the beginning of a string.
        /// StringFromStart(4, value) turns "ThisString" into "String".
        /// </summary>
        /// <param name="numCharactersToString"></param>
        /// <returns></returns>
        public static String StripFromStart(int numCharactersToStrip, String value)
        {
            return value.Substring(numCharactersToStrip, value.Length - numCharactersToStrip);
        }

        public static String StripLastWord(String line)
        {
            if (!(line == null) && !(line.Length == 0))
            {
                line = Reverse(line);
                int offset = line.IndexOf(' ');
                if ((offset != -1) && (offset != line.Trim().Length))
                {
                    line = StripFromStart(offset, line);
                }
                return Strings.Reverse(line).TrimEnd();
            }
            else
            {
                return "";
            }
        }

        public static String StripToFirstToken(char ch, String value)
        {
            if (value.Trim().Length > 0)
            {
                value = value.Trim();
                int index = value.IndexOf(ch);
                return value.Substring(index, value.Length - index).Trim();
            }
            return "";
        }

         
        public static int TimesInList(List<string> list, string value)
        {
            int count = 0;
            foreach (String item in list)
            {
                if (item == value)
                    count++;
            }
            return count;
        }
         


    }
}
