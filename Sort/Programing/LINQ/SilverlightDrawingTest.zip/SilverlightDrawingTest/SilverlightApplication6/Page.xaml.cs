﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Ink;

namespace SilverlightApplication6
{
    public partial class Page : UserControl
    {
        internal ShapeDrawer shapeDrawer;

        public Page()
        {
            InitializeComponent();
            shapeDrawer = new ShapeDrawer();
        }

        private void OnClick(object sender, RoutedEventArgs e)
        {
            var list = new List<string> { "LINQ", "LINQ Query", "Ordinary Query" };

            var query = from word in list
                        where word.StartsWith("L")
                        select word;

            foreach (var word in query)
            {
                textBox.Text += word + "; ";
            }
        }

        private void DrawRectangle(object sender, RoutedEventArgs e)
        {
            shapeDrawer.DrawRectangle(myCanvas);
            shapeDrawer.DrawRectangle(myInk);
        }

        private void MyIP_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            shapeDrawer.DrawStroke(myInk);

            shapeDrawer.DrawEllipse(myInk);
        }

        private void MyCanvasClick(object sender, MouseButtonEventArgs e)
        {
            shapeDrawer.DrawEllipse(myCanvas);
        }

        private void DrawPath(object sender, RoutedEventArgs e)
        {
            try
            {
                myPath.Visibility = Visibility.Visible;                
            }
            catch (NotImplementedException)
            {
                textBox.Text = "DrawPath not implemented";
            }
        }

        private void DrawLine(object sender, RoutedEventArgs e)
        {
            try
            {
                shapeDrawer.DrawLine(myCanvas);
            }
            catch (NotImplementedException)
            {
                textBox.Text = "DrawLine not implemented";
            }
        }

        private void DrawPolyline(object sender, RoutedEventArgs e)
        {
            try
            {
                shapeDrawer.DrawPolyline(myInk);
            }
            catch (NotImplementedException)
            {
                textBox.Text = "Draw Polyline not implemented";
            }
        }

        private void ButtonUp(object sender, MouseButtonEventArgs e)
        {

        }
    }
}
