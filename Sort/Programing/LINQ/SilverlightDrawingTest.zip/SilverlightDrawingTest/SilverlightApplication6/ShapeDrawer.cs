﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightApplication6
{
    public class ShapeDrawer
    {
        // Ellipse globalEllipse;

        public ShapeDrawer()
        {
            
        }

        public void DrawEllipse(Canvas surface)
        {
            Brush brush = new SolidColorBrush(Color.FromArgb(120, 255, 0, 0));

            Ellipse ellipse01 = new Ellipse();
            Ellipse ellipse02 = new Ellipse();

            ellipse01.Width = surface.Width / 4;
            ellipse01.Height = ellipse01.Width;
            ellipse02.Width = ellipse01.Width;
            ellipse02.Height = ellipse01.Height;            
            
            ellipse01.Fill = brush;
            ellipse02.Fill = brush;

            double left = (surface.Width / 4) - (ellipse01.Width / 2);
            double top = (surface.Height / 2) - (ellipse01.Height / 2);

            ellipse01.SetValue(Canvas.LeftProperty, left);
            ellipse01.SetValue(Canvas.TopProperty,  top);
            ellipse02.SetValue(Canvas.LeftProperty, ((surface.Width / 4) * 3) - (ellipse01.Height / 2));
            ellipse02.SetValue(Canvas.TopProperty, top);

            surface.Children.Add(ellipse01);
            surface.Children.Add(ellipse02);
        }

        public void DrawLine(Canvas surface)
        {
            double width = surface.Width / 5;
            double height = surface.Height / 2;

            Line line = new Line();

            line.Stroke = new SolidColorBrush(Color.FromArgb(255, 255, 0, 255));
            line.StrokeThickness = 3;

            line.X1 = width;
            line.X2 = surface.Width - width;
            line.Y1 = height;
            line.Y2 = height;

            surface.Children.Add(line);
        }

        public void DrawPolyline(Canvas surface)
        {
            Polyline poly = new Polyline();
            
            poly.Stroke = new SolidColorBrush(Color.FromArgb(255, 0, 255, 0));
            poly.StrokeThickness = 5;

            poly.Points = new PointCollection();
            poly.Points.Add(new Point(156, 10));
            poly.Points.Add(new Point(242, 100));
            poly.Points.Add(new Point(156, 100));
            poly.Points.Add(new Point(156, 10));

            poly.Fill = new SolidColorBrush(Color.FromArgb(255, 0, 0, 255));

            surface.Children.Add(poly);
        }

        public void DrawRectangle(Canvas surface)
        {
            Brush brush = new SolidColorBrush(Color.FromArgb(120, 127, 127, 0));
            SolidColorBrush blueBrush = new SolidColorBrush();
            blueBrush.Color = Colors.Blue;
            double offset = (surface.Height / 5);

            Rectangle myRect01 = new Rectangle();
            Rectangle myRect02 = new Rectangle();

            myRect01.Width = 25;
            myRect01.Height = surface.Height - offset;
            myRect02.Width = myRect01.Width;
            myRect02.Height = myRect01.Height;            
            
            myRect01.Fill = brush;
            myRect02.Fill = brush;            
            
            myRect01.Stroke = blueBrush;
            myRect01.StrokeThickness = 2;
            myRect02.Stroke = blueBrush;
            myRect02.StrokeThickness = 2;

            myRect01.SetValue(Canvas.LeftProperty, 5.0);
            myRect02.SetValue(Canvas.LeftProperty, (surface.Width - 5.0) - myRect02.Width);
            myRect01.SetValue(Canvas.TopProperty, offset / 2);
            myRect02.SetValue(Canvas.TopProperty, offset / 2);

            surface.Children.Add(myRect01);
            surface.Children.Add(myRect02);
        }

        public void DrawStroke(InkPresenter surface)
        {
            Stroke newStroke;

            StylusPointCollection MyStylusPointCollection = new StylusPointCollection();

            double offset = surface.Width / 5;
            MyStylusPointCollection.Add(new StylusPoint(offset, surface.Height / 2));
            MyStylusPointCollection.Add(new StylusPoint(surface.Width - offset, surface.Height / 2));
            newStroke = new Stroke(MyStylusPointCollection);

            surface.Strokes.Add(newStroke);
            
            // newStroke.StylusPoints.Add(value);
        }

        public void MoveEllipse()
        {
        
        }


    }
}
