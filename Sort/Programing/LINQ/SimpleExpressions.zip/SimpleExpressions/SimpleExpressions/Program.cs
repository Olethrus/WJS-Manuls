﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Linq.Expressions;

namespace SimpleExpressions
{
    class Program
    {
        public int Add(int a, int b)
        {
            return a + b;
        }


        static void Main(string[] args)
        {
            Func<int, int, int> function = (a,b) => a + b;
            Expression<Func<int, int, int>> expression = (a,b) => a + b;

            int c = function(3, 5);

            Console.WriteLine(c);

            Console.WriteLine("Param 1: {0}, Param 2: {1}", expression.Parameters[0], expression.Parameters[1]);

            int result = expression.Compile()(3, 5);

            Console.WriteLine(result);

            

            BinaryExpression body = (BinaryExpression)expression.Body;
            ParameterExpression left = (ParameterExpression)body.Left;
            ParameterExpression right = (ParameterExpression)body.Right;


            Console.WriteLine(expression.ToString());
            Console.WriteLine(expression.Body);
            Console.WriteLine(" The left part of the expression: " +
                "{0}{4} The NodeType: {1}{4} The right part: {2}{4} The Type: {3}{4}",
                left.Name, body.NodeType, right.Name, body.Type, Environment.NewLine);

            

        }
    }
}
