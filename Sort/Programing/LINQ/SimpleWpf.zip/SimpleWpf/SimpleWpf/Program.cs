﻿using System;
using System.Windows;
using System.Windows.Media;

namespace Project1
{
    class Program: Window
    {
        [STAThread]
        static void Main(string[] args)
        {
            Application app = new Application();
            app.Run(new Program());
        }

        public Program()
        {
            Width = 320;
            Height = 260;
            Title = "A Colorful WPF Window";
            Background = new LinearGradientBrush(Colors.AliceBlue, Colors.Aquamarine,
                new Point(0, 0), new Point(1, 1));
        }
    }
}
