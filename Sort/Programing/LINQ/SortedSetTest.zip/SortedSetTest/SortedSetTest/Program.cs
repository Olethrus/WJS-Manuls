﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace SortedSetTest
{
    class Program
    {
        static void Main(string[] args)
        {
            var hashSet = new HashSet<double>();
            var sortedSet = new SortedSet<double>();

            var testSizesForTestOne = new int[] { 100, 1000, 10000, 50000, 100000 };
            var testSizesForTestTwo = new int[] { 10, 50, 100, 500, 1000, 5000};

            RunTest(hashSet, sortedSet, testSizesForTestOne, "TestOne",
                 (set, testSize) => RunTestOne(set,testSize));

            RunTest(hashSet, sortedSet, testSizesForTestTwo, "TestTwo",
                (set, testSize) => RunTestTwo(set, testSize));
        }

        private static void RunTest(HashSet<double> hashSet, SortedSet<double> sortedSet, IEnumerable<int> testSizes,
            string label,
            Func<ISet<double>, int, TimeSpan> testFunc)
        {

            foreach (int test in testSizes)
            {
                var result = testFunc(hashSet, test);
                Console.WriteLine("{0} with Hash Set ({1}): {2}", label, test, result);
                result = testFunc(sortedSet, test);
                Console.WriteLine("{0} with Sorted Set ({1}): {2}", label, test, result);
                hashSet.Clear();
                sortedSet.Clear();
                Console.WriteLine();
            }
        }

        static TimeSpan RunTestOne(ISet<double> collection, int numItemsToTest)
        {
            Stopwatch timer = new Stopwatch();
            timer.Start();
            // perform the test 50 times:
            for (int counter = 0; counter < 50; counter++)
            {
                collection.Clear();
                // add some random items
                Random rnd = new Random();
                var sequence = from n in Enumerable.Range(1, numItemsToTest)
                               select rnd.NextDouble() * n;
                foreach (var item in sequence)
                    collection.Add(item);

                // search for 1000 random items
                var sequence2 = from n in Enumerable.Range(1, 1000)
                               select rnd.NextDouble() * n;
                bool found = false;
                foreach (var item in sequence2)
                {
                    found &= collection.Contains(item);
                }
            }
            timer.Stop();
            return timer.Elapsed;
        }

        static TimeSpan RunTestTwo(ISet<double> collection, int numItemsToTest)
        {
            Stopwatch timer = new Stopwatch();
            timer.Start();
            // perform the test 50 times:
            for (int counter = 0; counter < 50; counter++)
            {
                collection.Clear();
                // add random items
                Random rnd = new Random();
                var sequence = from n in Enumerable.Range(1, numItemsToTest)
                               select rnd.NextDouble() * n;
                foreach (var item in sequence)
                    collection.Add(item);

                // enumerate 1000 times
                double sum = 0;
                for (int inner = 0; inner < 1000; inner++)
                {

                    IEnumerable<double> ordered = collection.IsSorted() ?
                    collection as IEnumerable<double> :
                    from item in collection
                                  orderby item
                                  select item;
                    // must enumerate to make it work:
                    sum += ordered.Sum();
                }
            }
            timer.Stop();
            return timer.Elapsed;
        }

    }

    public static class Extensions
    {
        public static bool IsSorted<T>(this IEnumerable<T> sequence)
            where T : IComparable<T>
        {
            // Simplified algorithm for this example:
            // Production code would look for other sorted collections 
            // (SortedList, etc)
            if (sequence is SortedSet<T>)
                return true;
            IEnumerator<T> iter = sequence.GetEnumerator();
            if (!iter.MoveNext())
                return true;

            T value = iter.Current;
            while (iter.MoveNext())
            {
                if (value.CompareTo(iter.Current) > 0)
                    return false;
                value = iter.Current;
            }
            return true;
        }
    }
}
