﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using Microsoft.Win32;
using System.IO;
using System.Diagnostics;
using System.Windows.Forms;

namespace SetupExtension
{
    [RunInstaller(true)]
    public partial class VLinqInstaller : Installer
    {
        public VLinqInstaller()
        {
            InitializeComponent();
        }

        public string GetVSTemplateDir()
        {
            var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\VisualStudio\9.0\VSTemplate\Item");
            return key.GetValue("UserFolder") as string;
        }

        public string GetVSTemplateCacheDir()
        {
            var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\VisualStudio\9.0\VSTemplate\Item");
            return key.GetValue("CacheFolder") as string;
        }

        public string GetVSInstallDir()
        {
            var key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\VisualStudio\9.0");
            return key.GetValue("InstallDir") as string;
        }

        protected override void OnBeforeInstall(IDictionary savedState)
        {
            base.OnBeforeInstall(savedState);
        }

        public override void Install(IDictionary stateSaver)
        {
            base.Install(stateSaver);
            
            var templateDir = GetVSTemplateDir();

            var vlinqPath = Path.GetDirectoryName(Context.Parameters["assemblypath"] as string);
            //For CSharp
            File.Copy(
                Path.Combine(vlinqPath + @"\CSharpItemTemplate", "VLinq queries.zip"),
                Path.Combine(templateDir + @"\CSharp\1033", "VLinq queries.zip"), true);
            File.Copy(
                Path.Combine(vlinqPath + @"\CSharpItemTemplate", "VLinq queries.zip"),
                Path.Combine(templateDir + @"\CSharp\Data\1033", "VLinq queries.zip"), true);
            File.Copy(
                Path.Combine(vlinqPath + @"\CSharpItemTemplate", "VLinq queries.zip"),
                Path.Combine(templateDir + @"\CSharp\Web\1033", "VLinq queries.zip"), true);
            
            //For Visual Basic
            File.Copy(
                Path.Combine(vlinqPath + @"\VisualBasicItemTemplate", "VLinq queries.zip"),
                Path.Combine(templateDir + @"\VisualBasic\1033", "VLinq queries.zip"), true);
            File.Copy(
                Path.Combine(vlinqPath + @"\VisualBasicItemTemplate", "VLinq queries.zip"),
                Path.Combine(templateDir + @"\VisualBasic\Data\1033", "VLinq queries.zip"), true);
            File.Copy(
                Path.Combine(vlinqPath + @"\VisualBasicItemTemplate", "VLinq queries.zip"),
                Path.Combine(templateDir + @"\VisualBasic\Web\1033", "VLinq queries.zip"), true);
        }

        private void RefreshVSTemplates()
        {
            var p = Process.Start(
                new ProcessStartInfo
                {
                    FileName = Path.Combine(GetVSInstallDir(), @"devenv.exe"),
                    Arguments = " /installvstemplates"
                });
            p.WaitForExit();
        }
        protected override void OnAfterInstall(IDictionary savedState)
        {
            base.OnAfterInstall(savedState);
        }

        public override void Commit(IDictionary savedState)
        {
            base.Commit(savedState);

            RefreshVSTemplates();
        }

        public override void Uninstall(IDictionary savedState)
        {
            base.Uninstall(savedState);

            var templateDir = GetVSTemplateDir();

            string temp = Path.Combine(templateDir + @"\CSharp\1033", "VLinq queries.zip");
            if (File.Exists(temp)) File.Delete(temp);

            temp = Path.Combine(templateDir + @"\CSharp\Data\1033", "VLinq queries.zip");
            DeleteFileIfExists(temp);

            temp = Path.Combine(templateDir + @"\VisualBasic\1033", "VLinq queries.zip");
            DeleteFileIfExists(temp);

            temp = Path.Combine(templateDir + @"\VisualBasic\Data\1033", "VLinq queries.zip");
            DeleteFileIfExists(temp);

            //var templateCacheDir = GetVSTemplateCacheDir();

            //temp = Path.Combine(templateCacheDir + @"\CSharp\1033", "VLinq queries.zip");
            //if (File.Exists(temp)) File.Delete(temp);

            //temp = Path.Combine(templateCacheDir + @"\CSharp\Data\1033", "VLinq queries.zip");
            //DeleteFileIfExists(temp);

            //temp = Path.Combine(templateCacheDir + @"\VisualBasic\1033", "VLinq queries.zip");
            //DeleteFileIfExists(temp);

            //temp = Path.Combine(templateCacheDir + @"\VisualBasic\Data\1033", "VLinq queries.zip");
            //DeleteFileIfExists(temp);
        }

        private static void DeleteFileIfExists(string filename)
        {
            if (File.Exists(filename)) File.Delete(filename);
        }

        protected override void OnAfterUninstall(IDictionary savedState)
        {
            base.OnAfterUninstall(savedState);

            RefreshVSTemplates();
        }


        public override void Rollback(IDictionary savedState)
        {
            base.Rollback(savedState);

            var templateDir = GetVSTemplateDir();
            
            string temp = Path.Combine(templateDir + @"\CSharp\1033", "VLinq queries.zip");
            if (File.Exists(temp)) File.Delete(temp);

            temp = Path.Combine(templateDir + @"\CSharp\Data\1033", "VLinq queries.zip");
            if (File.Exists(temp)) File.Delete(temp);

            temp = Path.Combine(templateDir + @"\VisualBasic\1033", "VLinq queries.zip");
            if (File.Exists(temp)) File.Delete(temp);

            temp = Path.Combine(templateDir + @"\VisualBasic\Data\1033", "VLinq queries.zip");
            if (File.Exists(temp)) File.Delete(temp);
        }
    }
}
