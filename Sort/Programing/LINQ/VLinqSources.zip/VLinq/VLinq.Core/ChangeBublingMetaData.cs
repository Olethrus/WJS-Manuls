﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Custom metadata used to automatically manage INotifyChanged objects
    /// (Set owner, buble events when the property is changed...)
    /// </summary>
    public class ChangeBublingMetadata : PropertyMetadata 
    {
        private PropertyChangedCallback m_oldCallBack;
        private void OnChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var changedRoot = obj as IVLinqComponent;
            var oldChild = args.OldValue as IVLinqComponent;
            var newChild = args.NewValue as IVLinqComponent;

            if (changedRoot != null)
            {
                if (oldChild != null)
                    oldChild.SetOwner(null,null);
                if (newChild != null)
                    newChild.SetOwner(changedRoot,args.Property);
                changedRoot.NotifyChanged(args.Property);
            }
            if (m_oldCallBack != null)
                m_oldCallBack.Invoke(obj, args);
            
        }

        public ChangeBublingMetadata(object defaultValue, PropertyChangedCallback pcc)
            : base(defaultValue)
        {
            m_oldCallBack = pcc;
            this.PropertyChangedCallback = new PropertyChangedCallback(OnChanged);
        }
        public ChangeBublingMetadata(PropertyChangedCallback pcc)
            : base()
        {
            m_oldCallBack = pcc;
            this.PropertyChangedCallback = new PropertyChangedCallback(OnChanged);
        }
        public ChangeBublingMetadata(object defaultValue)
            : base(defaultValue)
        {
            this.PropertyChangedCallback = new PropertyChangedCallback(OnChanged);
        }
        public ChangeBublingMetadata()
            : base()
        {
            this.PropertyChangedCallback = new PropertyChangedCallback(OnChanged);
        }
    }
}
