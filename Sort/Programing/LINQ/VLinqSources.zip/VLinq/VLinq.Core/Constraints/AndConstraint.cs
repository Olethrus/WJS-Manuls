﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    /// <summary>
    /// Constraint composed of other constraints linked by the "And" keyword
    /// deprecated (use LogicalOperatorConstraint with "And" operator instead)
    /// </summary>
    
    public class AndConstraint : LogicalOperatorConstraint
    {
       
        static AndConstraint()
        {
            LogicalOperatorConstraint.OperatorProperty.OverrideMetadata(typeof(AndConstraint), new ChangeBublingMetadata( LogicalOperator.And));
        }
    }
}
