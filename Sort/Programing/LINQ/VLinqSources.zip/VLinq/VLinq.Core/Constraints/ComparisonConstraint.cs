﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Represent a comparison constraint
    /// </summary>
    public class ComparisonConstraint : Constraint
    {
        /// <summary>
        /// the left operand
        /// </summary>
        public Operand Left
        {
            get { return (Operand)GetValue(LeftProperty); }
            set { SetValue(LeftProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Left.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LeftProperty =
            DependencyProperty.Register("Left", typeof(Operand), typeof(ComparisonConstraint), new ChangeBublingMetadata());



        /// <summary>
        /// the right operand
        /// </summary>
        public Operand Right
        {
            get { return (Operand)GetValue(RightProperty); }
            set { SetValue(RightProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Right.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RightProperty =
            DependencyProperty.Register("Right", typeof(Operand), typeof(ComparisonConstraint), new ChangeBublingMetadata());



        /// <summary>
        /// Operator used for the comparison
        /// </summary>
        public Comparison Operator
        {
            get { return (Comparison)GetValue(OperatorProperty); }
            set { SetValue(OperatorProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operator.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperatorProperty =
            DependencyProperty.Register("Operator", typeof(Comparison), typeof(ComparisonConstraint), new ChangeBublingMetadata());


        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "{0} {1} {2}", Left, Operator, Right);
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            if (Left == null)
                yield return new TextFragment { Text = "null", FragmentKind = FragmentKind.Keyword };
            else
            {
                foreach (var frag in Left.ToInlines())
                    yield return frag;
            }

            switch (Operator)
            {
                case Comparison.Equals:
                    yield return new TextFragment { Text = " == "};
                    break;
                case Comparison.Greater:
                    yield return new TextFragment { Text = " > " };
                    break;
                case Comparison.GreaterOrEquals:
                    yield return new TextFragment { Text = " >= " };
                    break;
                case Comparison.Lower:
                    yield return new TextFragment { Text = " < " };
                    break;
                case Comparison.LowerOrEquals:
                    yield return new TextFragment { Text = " <= " };
                    break;
                case Comparison.NotEquals:
                    yield return new TextFragment { Text = " != " };
                    break;
                default:
                    yield return new TextFragment { Text = string.Format(CultureInfo.InvariantCulture, " {0} ", Operator), FragmentKind = FragmentKind.Keyword };
                    break;
            }

            

            if (Right == null)
                yield return new TextFragment { Text = "null", FragmentKind = FragmentKind.Keyword };
            else
            {
                foreach (var frag in Right.ToInlines())
                    yield return frag;
            }
        }
    }
}
