﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.ComponentModel;
using System.Windows.Markup;

namespace VLinq
{
    /// <summary>
    /// Represents a concatenation between multiple operands
    /// (if an operand is not a string, a ToString transform is applied on it)
    /// </summary>
    [ContentProperty("Operands")]
    public class ConcatOperationOperand : Operand
    {
        public ConcatOperationOperand()
        {
            SetValue(OperandsProperty, new OperandCollection());
        }
        /// <summary>
        /// Operands of the concatenation
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public OperandCollection Operands
        {
            get { return (OperandCollection)GetValue(OperandsProperty); }
        }

        // Using a DependencyProperty as the backing store for Operands.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandsProperty =
            DependencyProperty.Register("Operands", typeof(OperandCollection), typeof(ConcatOperationOperand), new ChangeBublingMetadata());

        public override string ToString()
        {
            var builder = new StringBuilder();
            bool first = true;
            foreach (var op in Operands)
            {
                if (first)
                    first = false;
                else
                    builder.Append(" + ");
                builder.Append(op);
            }
            return builder.ToString();
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            bool first = true;
            foreach (var op in Operands)
            {
                if (first)
                    first = false;
                else
                    yield return new TextFragment { Text = " + "};
                foreach (var frag in op.ToInlines())
                    yield return frag;
            }
        }
    }
}
