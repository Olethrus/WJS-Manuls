﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Operand from a constant
    /// </summary>
    public class ConstantOperand : Operand
    {

        /// <summary>
        /// Value of the constant
        /// </summary>
        public object ConstantValue
        {
            get { return (object)GetValue(ConstantValueProperty); }
            set { SetValue(ConstantValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Value.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ConstantValueProperty =
            DependencyProperty.Register("ConstantValue", typeof(object), typeof(ConstantOperand), new ChangeBublingMetadata(delegate(DependencyObject obj, DependencyPropertyChangedEventArgs args)
                {
                    ConstantOperand operand = obj as ConstantOperand;
                    operand.ConsolidateValueAndType();
                }));

        
       
        /// <summary>
        /// Resolves type of the constant, and tries to convert the value to the desired type
        /// </summary>
        private void ConsolidateValueAndType()
        {

            if (this.GetValue(ConstantValueProperty) != null && this.TypeName != null)
            {
                Type t = Type.GetType(this.TypeName,false);
                if (t == null)
                    throw new InvalidOperationException( string.Format(CultureInfo.InvariantCulture,"Unable to resolve type {0}", TypeName));

            
            
                if (!t.IsAssignableFrom(ConstantValue.GetType()))
                    ConstantValue = Convert.ChangeType( ConstantValue, t, CultureInfo.InvariantCulture);
            }
        }

        /// <summary>
        /// Type of the operand
        /// </summary>
        public string TypeName
        {
            get { return (string)GetValue(TypeNameProperty); }
            set { SetValue(TypeNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Type.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TypeNameProperty =
            DependencyProperty.Register("TypeName", typeof(string), typeof(ConstantOperand), new ChangeBublingMetadata(delegate(DependencyObject obj, DependencyPropertyChangedEventArgs args)
                {
                    ConstantOperand operand = obj as ConstantOperand;
                    operand.ConsolidateValueAndType();
                }));

        public override string ToString()
        {
            if(ConstantValue == null)
                return string.Empty;
            return ConstantValue.ToString();
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            if (ConstantValue == null)
                yield return new TextFragment { Text = "null", FragmentKind = FragmentKind.Keyword };
            
            else
            {
                if(ConstantValue.GetType() == typeof(string))
                    yield return new TextFragment { Text = string.Format(CultureInfo.InvariantCulture,"\"{0}\"", ConstantValue), FragmentKind = FragmentKind.String};
                else
                    yield return new TextFragment { Text = ConstantValue.ToString(), ToolTip=TypeName };
            }
        }
    }
}
