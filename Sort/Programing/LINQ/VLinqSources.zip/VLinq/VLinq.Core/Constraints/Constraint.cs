﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Class representing a constraint to apply in the "where" or "having" clause of the query
    /// </summary>
    public abstract class Constraint : VLinqComponentBase
    {
    }
}
