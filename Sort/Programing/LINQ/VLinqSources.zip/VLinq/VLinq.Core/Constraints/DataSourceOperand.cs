﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Base class used for operand linked to different kind of DataSources
    /// </summary>
    public class DataSourceOperand : Operand
    {
        /// <summary>
        /// Name of the DataSource
        /// </summary>
        public string DataSourceName
        {
            get { return (string)GetValue(DataSourceNameProperty); }
            set { SetValue(DataSourceNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DataSourceName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourceNameProperty =
            DependencyProperty.Register("DataSourceName", typeof(string), typeof(DataSourceOperand), new ChangeBublingMetadata());


        /// <summary>
        /// Transform applied on it
        /// </summary>
        public Transform Transform
        {
            get { return (Transform)GetValue(TransformProperty); }
            set { SetValue(TransformProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Transform.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TransformProperty =
            DependencyProperty.Register("Transform", typeof(Transform), typeof(DataSourceOperand), new ChangeBublingMetadata());



        /// <summary>
        /// Property of the entity used in the constraint (null if the parameter itself)
        /// </summary>
        public string DataSourceProperty
        {
            get { return (string)GetValue(DataSourcePropertyProperty); }
            set { SetValue(DataSourcePropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DataSourceProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourcePropertyProperty =
            DependencyProperty.Register("DataSourceProperty", typeof(string), typeof(DataSourceOperand), new ChangeBublingMetadata());

        public override IEnumerable<TextFragment> ToInlines()
        {
            yield return new TextFragment { Text = DataSourceName };
            if (!string.IsNullOrEmpty(DataSourceProperty))
            {
                yield return new TextFragment { Text = "."+DataSourceProperty };
            }
            if (Transform != null)
            {
                yield return new TextFragment { Text = "."};
                foreach (var frag in Transform.ToInlines())
                    yield return frag;
            }
        }
        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.Append(DataSourceName);
            if (!string.IsNullOrEmpty(DataSourceProperty))
            {
                builder.Append(".");
                builder.Append(DataSourceProperty);
            }
            if (Transform != null)
            {
                builder.Append(".");
                builder.Append(Transform.ToString());
            }


            return builder.ToString();
        }
    }
}
