﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
   /// <summary>
   /// And or Or
   /// </summary>
    public enum LogicalOperator
    {
        And,
        Or
    }
}
