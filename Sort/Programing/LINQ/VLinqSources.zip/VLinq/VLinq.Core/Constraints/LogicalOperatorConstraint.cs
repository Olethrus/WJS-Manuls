﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Collections.ObjectModel;
using System.Windows.Markup;
using System.ComponentModel;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Constraint composed of other constraints joined by "or" or "and" keywords
    /// </summary>
    [ContentProperty("Constraints")]
    public class LogicalOperatorConstraint : Constraint
    {

        /// <summary>
        /// "Or" or "And"
        /// </summary>
        public LogicalOperator Operator
        {
            get { return (LogicalOperator)GetValue(OperatorProperty); }
            set { SetValue(OperatorProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operator.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperatorProperty =
            DependencyProperty.Register("Operator", typeof(LogicalOperator), typeof(LogicalOperatorConstraint), new ChangeBublingMetadata());


        /// <summary>
        /// Child constraints
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public VLinqComponentCollection<Constraint> Constraints
        {
            get { return (VLinqComponentCollection<Constraint>)GetValue(ConstraintsProperty); }
        }

        // Using a DependencyProperty as the backing store for Constraints.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ConstraintsProperty =
            DependencyProperty.Register("Constraints", typeof(VLinqComponentCollection<Constraint>), typeof(LogicalOperatorConstraint), new ChangeBublingMetadata());
        

        public LogicalOperatorConstraint()
        {
            SetValue(ConstraintsProperty, new VLinqComponentCollection<Constraint>());
        }
        /// <summary>
        /// Provides a way to know if the constraint is empty (no comparison in its descendants)
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                foreach (var constraint in Constraints)
                {
                    if (constraint is ComparisonConstraint)
                    {
                        return false;
                    }
                    else
                    {
                        var logop = constraint as LogicalOperatorConstraint;
                        if (logop != null && !logop.IsEmpty)
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
        }
        public override IEnumerable<TextFragment> ToInlines()
        {
            if (Constraints.Count > 1)
                yield return new TextFragment { Text = "(" };

            bool first = true;
            foreach (var c in Constraints)
            {
                if (first)
                    first = false;
                else
                    yield return new TextFragment { Text = string.Format(CultureInfo.InvariantCulture, " {0} ", Operator), FragmentKind = FragmentKind.Keyword };
                foreach (var frag in c.ToInlines())
                    yield return frag;
            }

            if (Constraints.Count > 1)
                yield return new TextFragment { Text = ")" };

        }
        public override string ToString()
        {
            var builder = new StringBuilder();
            if (Constraints.Count > 1)
                builder.Append("(");

            bool first = true;
            foreach (var c in Constraints)
            {
                if (first)
                    first = false;
                else
                    builder.AppendFormat(CultureInfo.InvariantCulture, " {0} ", Operator);
                builder.Append(c);
            }

            if (Constraints.Count > 1)
                builder.Append(")");

            return builder.ToString();
        }

	
    }
}
