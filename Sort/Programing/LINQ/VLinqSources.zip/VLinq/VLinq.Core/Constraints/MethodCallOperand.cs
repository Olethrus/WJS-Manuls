﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.ComponentModel;

namespace VLinq
{
    /// <summary>
    /// Base class for all method calls (static or instance)
    /// Method calls are considered as operands by the model
    /// To add a specific available method call to the model, inherit this class and overrides
    /// its dependency properties metadata
    /// 
    /// Most of its dependency properties are read-only, because they are here for validation / code generation purpose only, 
    /// and may be modified only by overriding their metadata
    /// in inherited classes
    /// </summary>
    public abstract class MethodCallOperand : Operand
    {
        /// <summary>
        /// Type of the caller (or declaring type of the static method)
        /// </summary>
        public string CallerTypeName
        {
            get { return (string)GetValue(CallerTypeNameProperty); }
        }

        // Using a DependencyProperty as the backing store for CallerTypeName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CallerTypeNameProperty =
            DependencyProperty.Register("CallerTypeName", typeof(string), typeof(MethodCallOperand), new ChangeBublingMetadata());

        /// <summary>
        /// Return type of the call (as string)
        /// this type will be the type of the operand
        /// </summary>
        public string ReturnType
        {
            get { return (string)GetValue(ReturnTypeProperty); }
        }

        // Using a DependencyProperty as the backing store for ReturnedType.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ReturnTypeProperty =
            DependencyProperty.Register("ReturnType", typeof(string), typeof(MethodCallOperand), new ChangeBublingMetadata());


        /// <summary>
        /// Array containing the description of parameters of the method (type, required / optionnal)
        /// </summary>
        public ParameterDescription[] ParametersTypes
        {
            get { return (ParameterDescription[])GetValue(ParametersTypesProperty); }
        }

        // Using a DependencyProperty as the backing store for ParametersTypes.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParametersTypesProperty =
            DependencyProperty.Register("ParametersTypes", typeof(ParameterDescription[]), typeof(MethodCallOperand), new ChangeBublingMetadata());

        /// <summary>
        /// Name of the method
        /// </summary>
        public string MethodName
        {
            get { return (string)GetValue(MethodNameProperty); }
        }

        // Using a DependencyProperty as the backing store for MethodName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MethodNameProperty =
            DependencyProperty.Register("MethodName", typeof(string), typeof(MethodCallOperand), new ChangeBublingMetadata());


        /// <summary>
        /// Flag indicating if the method is static
        /// </summary>
        public bool IsStaticMethod
        {
            get { return (bool)GetValue(IsStaticMethodProperty); }
        }

        // Using a DependencyProperty as the backing store for IsStaticMethod.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsStaticMethodProperty =
            DependencyProperty.Register("IsStaticMethod", typeof(bool), typeof(MethodCallOperand), new ChangeBublingMetadata(false));


        /// <summary>
        /// Operand used as a method caller (null if static)
        /// (set at design-time)
        /// </summary>
        public Operand InstanceMethodCaller
        {
            get { return (Operand)GetValue(InstanceMethodCallerProperty); }
            set { SetValue(InstanceMethodCallerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for InstanceMethodCaller.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty InstanceMethodCallerProperty =
            DependencyProperty.Register("InstanceMethodCaller", typeof(Operand), typeof(MethodCallOperand), new ChangeBublingMetadata());


        /// <summary>
        /// Operands used as method parameters
        /// (set at design-time)
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public OperandCollection MethodParameters
        {
            get { return (OperandCollection)GetValue(MethodParametersProperty); }
        }

        // Using a DependencyProperty as the backing store for MethodParameters.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MethodParametersProperty =
            DependencyProperty.Register("MethodParameters", typeof(OperandCollection), typeof(MethodCallOperand), new ChangeBublingMetadata());

        protected MethodCallOperand()
        {
            SetValue(MethodParametersProperty, new OperandCollection());
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }
    }
}
