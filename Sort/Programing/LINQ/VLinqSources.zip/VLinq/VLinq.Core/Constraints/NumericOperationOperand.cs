﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.ComponentModel;
using System.Windows.Markup;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Represents an operation between numeric operands
    /// all operands must be of numeric types
    /// the type of the operation result is inferred from the types of the operands
    /// </summary>
    [ContentProperty("Operands")]
    public class NumericOperationOperand : Operand
    {
        public NumericOperationOperand()
        {
            SetValue(OperandsProperty, new OperandCollection());
        }

        /// <summary>
        /// Operator applied between the operands
        /// </summary>
        public NumericOperation Operation
        {
            get { return (NumericOperation)GetValue(OperationProperty); }
            set { SetValue(OperationProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operation.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperationProperty =
            DependencyProperty.Register("Operation", typeof(NumericOperation), typeof(NumericOperationOperand), new ChangeBublingMetadata(NumericOperation.Plus));


        /// <summary>
        /// Operands of the operation (must be numeric, can be nested numeric operations)
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public OperandCollection Operands
        {
            get { return (OperandCollection)GetValue(OperandsProperty); }
        }

        // Using a DependencyProperty as the backing store for Operands.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandsProperty =
            DependencyProperty.Register("Operands", typeof(OperandCollection), typeof(NumericOperationOperand), new ChangeBublingMetadata());


        public override IEnumerable<TextFragment> ToInlines()
        {
            if (Operands.Count > 1)
                yield return new TextFragment { Text = "(" };

            bool first = true;
            foreach (var c in Operands)
            {
                if (first)
                    first = false;
                else
                    yield return new TextFragment { Text = string.Format(CultureInfo.InvariantCulture, " {0} ", Operation), FragmentKind = FragmentKind.Keyword };
                foreach (var frag in c.ToInlines())
                    yield return frag;
            }

            if (Operands.Count > 1)
                yield return new TextFragment { Text = ")" };
        }

        public override string ToString()
        {
            var builder = new StringBuilder();
            if (Operands.Count > 1)
                builder.Append("(");

            bool first = true;
            foreach (var c in Operands)
            {
                if (first)
                    first = false;
                else
                    builder.AppendFormat(CultureInfo.InvariantCulture, " {0} ", Operation);
                builder.Append(c);
            }

            if (Operands.Count > 1)
                builder.Append(")");

            return builder.ToString();
        }
    }
}
