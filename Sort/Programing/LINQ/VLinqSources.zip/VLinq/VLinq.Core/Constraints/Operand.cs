﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Represents an operand
    /// Operands are used everywhere in the query (comparisons, projections, grouping, method calls...)
    /// </summary>
    public abstract class Operand : VLinqComponentBase
    {

     }
}
