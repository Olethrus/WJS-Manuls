﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    /// <summary>
    /// Collection of operands (implements INotifyChanged for change event bubling)
    /// </summary>
    public class OperandCollection : VLinqComponentCollection<Operand>
    {
    }
}
