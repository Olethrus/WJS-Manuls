﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    /// <summary>
    /// Numeric operation used in NumericOperationOperand
    /// </summary>
    public enum NumericOperation
    {
        Plus,
        Minus,
        Multiply,
        Divide,
        Modulo       
    }
}
