﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    /// <summary>
    /// Constraint composed of other constraints linked by the "Or" keyword
    /// deprecated (use LogicalOperatorConstraint with "Or" operator instead)
    /// </summary>
    public class OrConstraint: LogicalOperatorConstraint
    {
       
        static OrConstraint()
        {
            LogicalOperatorConstraint.OperatorProperty.OverrideMetadata(typeof(OrConstraint), new ChangeBublingMetadata(LogicalOperator.Or));
        }
    }
}
