﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Class used to describe a parameter of a MethodCallOperand
    /// </summary>
    public class ParameterDescription : VLinqComponentBase
    {

        /// <summary>
        /// Type of the parameter
        /// </summary>
        public string TypeName
        {
            get { return (string)GetValue(TypeNameProperty); }
            set { SetValue(TypeNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TypeName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TypeNameProperty =
            DependencyProperty.Register("TypeName", typeof(string), typeof(ParameterDescription));


        /// <summary>
        /// flag indicating if the parameter is required or optionnal
        /// (based on different available method signatures)
        /// </summary>
        public bool IsOptionnal
        {
            get { return (bool)GetValue(IsOptionnalProperty); }
            set { SetValue(IsOptionnalProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsOptionnal.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsOptionnalProperty =
            DependencyProperty.Register("IsOptionnal", typeof(bool), typeof(ParameterDescription));



        public string ParameterName
        {
            get { return (string)GetValue(ParameterNameProperty); }
            set { SetValue(ParameterNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ParameterName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParameterNameProperty =
            DependencyProperty.Register("ParameterName", typeof(string), typeof(ParameterDescription));

        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }
    }
}
