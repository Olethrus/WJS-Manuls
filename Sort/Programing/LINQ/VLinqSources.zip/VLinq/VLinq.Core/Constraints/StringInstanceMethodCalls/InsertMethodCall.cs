﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.MethodCalls.StringInstance
{
    /// <summary>
    /// Represent the string instance method: string strVar.Insert(int index, string value)
    /// </summary>
    public class InsertMethodCall : StringInstanceMethodCall
    {

        static InsertMethodCall()
        {
            MethodCallOperand.MethodNameProperty.OverrideMetadata(typeof(InsertMethodCall), new ChangeBublingMetadata("Insert"));
            MethodCallOperand.ReturnTypeProperty.OverrideMetadata(typeof(InsertMethodCall), new ChangeBublingMetadata("System.String"));
            MethodCallOperand.ParametersTypesProperty.OverrideMetadata(typeof(InsertMethodCall), new ChangeBublingMetadata(new ParameterDescription[] {
                new ParameterDescription{ TypeName = "System.Int32", IsOptionnal=false,ParameterName="startIndex"}
                ,new ParameterDescription{ TypeName = "System.String", IsOptionnal=false,ParameterName="value"}}));
        }

    }
}
