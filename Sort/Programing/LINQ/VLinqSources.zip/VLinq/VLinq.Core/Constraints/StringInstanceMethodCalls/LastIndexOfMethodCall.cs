﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.MethodCalls.StringInstance
{
    /// <summary>
    /// Represent the string instance method: int strVar.LastIndexOf(string pattern, [opt] int start, [opt] int count)
    /// </summary>
    public class LastIndexOfMethodCall : StringInstanceMethodCall
    {
        static LastIndexOfMethodCall()
        {
            MethodCallOperand.MethodNameProperty.OverrideMetadata(typeof(LastIndexOfMethodCall), new ChangeBublingMetadata("LastIndexOf"));
            MethodCallOperand.ReturnTypeProperty.OverrideMetadata(typeof(LastIndexOfMethodCall), new ChangeBublingMetadata("System.Int32"));
            MethodCallOperand.ParametersTypesProperty.OverrideMetadata(typeof(LastIndexOfMethodCall), new ChangeBublingMetadata(new ParameterDescription[] {
                new ParameterDescription{ TypeName = "System.String", IsOptionnal=false,ParameterName="value"}
                ,new ParameterDescription{ TypeName = "System.Int32", IsOptionnal=true,ParameterName="startIndex"}
                ,new ParameterDescription{ TypeName = "System.Int32", IsOptionnal=true,ParameterName="count"}}));
        }

    }
}
