﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.MethodCalls.StringInstance
{
    /// <summary>
    /// Represent the string instance method: string strVar.Remove(int start, [opt] int count)
    /// </summary>
    public class RemoveMethodCall: StringInstanceMethodCall
    {
        static RemoveMethodCall()
        {
            MethodCallOperand.MethodNameProperty.OverrideMetadata(typeof(RemoveMethodCall), new ChangeBublingMetadata("Remove"));
            MethodCallOperand.ReturnTypeProperty.OverrideMetadata(typeof(RemoveMethodCall), new ChangeBublingMetadata("System.String"));
            MethodCallOperand.ParametersTypesProperty.OverrideMetadata(typeof(RemoveMethodCall), new ChangeBublingMetadata(new ParameterDescription[] {
                new ParameterDescription{ TypeName = "System.Int32", IsOptionnal=false,ParameterName="startIndex"}
                ,new ParameterDescription{ TypeName = "System.Int32", IsOptionnal=true,ParameterName="count"}}));

        }

    }
}
