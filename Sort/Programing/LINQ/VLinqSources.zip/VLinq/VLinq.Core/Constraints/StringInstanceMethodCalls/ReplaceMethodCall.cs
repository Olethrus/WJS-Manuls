﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.MethodCalls.StringInstance
{
    /// <summary>
    /// Represent the string instance method: string strVar.Replace(string oldVal, string newVal)
    /// </summary>
    public class ReplaceMethodCall: StringInstanceMethodCall
    {
        static ReplaceMethodCall()
        {
            MethodCallOperand.MethodNameProperty.OverrideMetadata(typeof(ReplaceMethodCall), new ChangeBublingMetadata("Replace"));
            MethodCallOperand.ReturnTypeProperty.OverrideMetadata(typeof(ReplaceMethodCall), new ChangeBublingMetadata("System.String"));
            MethodCallOperand.ParametersTypesProperty.OverrideMetadata(typeof(ReplaceMethodCall), new ChangeBublingMetadata(new ParameterDescription[] {
                new ParameterDescription{ TypeName = "System.String", IsOptionnal=false,ParameterName="oldValue"}
                ,new ParameterDescription{ TypeName = "System.String", IsOptionnal=false,ParameterName="newValue"}}));

        }

    }
}
