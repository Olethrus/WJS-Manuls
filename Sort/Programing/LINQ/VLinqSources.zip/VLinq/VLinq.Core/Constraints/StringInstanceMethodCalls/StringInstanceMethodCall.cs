﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.MethodCalls.StringInstance
{
    /// <summary>
    /// Base class of all string instance method calls
    /// </summary>
    public abstract class StringInstanceMethodCall : MethodCallOperand
    {

        static StringInstanceMethodCall()
        {
            // Make common overrides for all System.String instance method calls
            MethodCallOperand.IsStaticMethodProperty.OverrideMetadata(typeof(StringInstanceMethodCall), new ChangeBublingMetadata(false));
            MethodCallOperand.CallerTypeNameProperty.OverrideMetadata(typeof(StringInstanceMethodCall), new ChangeBublingMetadata("System.String"));
            
        }
    }
}
