﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.MethodCalls.StringInstance
{
    /// <summary>
    /// Represent the string instance method: string strVar.Substring(int start, [opt] int count)
    /// </summary>
    public class SubstringMethodCall : StringInstanceMethodCall
    {
        static SubstringMethodCall()
        {
            MethodCallOperand.MethodNameProperty.OverrideMetadata(typeof(SubstringMethodCall), new ChangeBublingMetadata("Substring"));
            MethodCallOperand.ReturnTypeProperty.OverrideMetadata(typeof(SubstringMethodCall), new ChangeBublingMetadata("System.String"));
            MethodCallOperand.ParametersTypesProperty.OverrideMetadata(typeof(SubstringMethodCall), new ChangeBublingMetadata(new ParameterDescription[] {
                new ParameterDescription{ TypeName = "System.Int32", IsOptionnal=false,ParameterName="startIndex"}
                ,new ParameterDescription{ TypeName = "System.Int32", IsOptionnal=true,ParameterName="length"} }));
        }
        
    }
}
