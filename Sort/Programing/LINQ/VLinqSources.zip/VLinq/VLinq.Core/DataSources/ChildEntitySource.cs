﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{

    /// <summary>
    /// Entity source based on another entity source (used to generate suff like:
    ///     from c in categories
    ///     from p in c.Products)
    /// </summary>
    public class ChildEntitySource : DataSource
    {
        static ChildEntitySource()
        {
            DataSourceTypeProperty.OverrideMetadata(typeof(ChildEntitySource), new PropertyMetadata(DataSourceType.ChildEntitySource));
        }

        /// <summary>
        /// Name of the parent EntitySource
        /// </summary>
        public string ParentEntitySourceName
        {
            get { return (string)GetValue(ParentEntitySourceNameProperty); }
            set { SetValue(ParentEntitySourceNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ParentEntitySourceName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParentEntitySourceNameProperty =
            DependencyProperty.Register("ParentEntitySourceName", typeof(string), typeof(ChildEntitySource), new ChangeBublingMetadata());


        /// <summary>
        /// Name of the property used to create the ChildEntitySource
        /// The type of the property should be EntitySet&lt;...&gt;. At validation, we only test if it is Enumerable.
        /// </summary>
        public string ParentEntitySourceProperty
        {
            get { return (string)GetValue(ParentEntitySourcePropertyProperty); }
            set { SetValue(ParentEntitySourcePropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ParentEntitySourceProperty2.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParentEntitySourcePropertyProperty =
            DependencyProperty.Register("ParentEntitySourceProperty", typeof(string), typeof(ChildEntitySource), new ChangeBublingMetadata());


        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "{0} in {1}.{2}", Name, ParentEntitySourceName, ParentEntitySourceProperty);
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            yield return new TextFragment { Text = Name };
            yield return new TextFragment { Text = " in ", FragmentKind = FragmentKind.Keyword };
            yield return new TextFragment { Text = ParentEntitySourceName +"."+ParentEntitySourceProperty };
        }

    }
}
