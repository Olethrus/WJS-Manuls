﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Represent a named subquery, placed in a "let" statement
    /// It contains the resultset of the query itself (it is not processed entity by entity like a from ... in ... statement)
    /// </summary>
    [System.Windows.Markup.ContentProperty("Query")]
    public class ChildQueryResultSource : DataSource
    {
        static ChildQueryResultSource()
        {
            DataSourceTypeProperty.OverrideMetadata(typeof(ChildQueryResultSource), new PropertyMetadata(DataSourceType.ChildQueryResultSource));
        }

        /// <summary>
        /// Subquery
        /// </summary>
        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(ChildQueryResultSource), new ChangeBublingMetadata());

       

        protected void OnQueryChanged(Query oldQuery, Query newQuery)
        {
            if (oldQuery != null)
                oldQuery.NameChanged -= query_NameChanged;
            if (newQuery != null)
            {
                newQuery.Name = this.Name;
                newQuery.NameChanged += query_NameChanged;
                
            }
        }

        void query_NameChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            this.Name = Query.Name;
        }

        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            if (e.Property == QueryProperty)
            {
                var oldQuery = e.OldValue as Query;
                var newQuery = e.NewValue as Query;
                OnQueryChanged(oldQuery, newQuery);
            }
            else if (e.Property == NameProperty && Query != null)
            {
                Query.Name = Name;
            }
            base.OnPropertyChanged(e);

        }
        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "let {0} = select ... from ... where ...", Name);
        }
        public override IEnumerable<TextFragment> ToInlines()
        {
            yield return new TextFragment { Text = "let ", FragmentKind= FragmentKind.Keyword };
            yield return new TextFragment { Text = Name };
            yield return new TextFragment { Text = " = \n" };
            foreach (var ds in Query.DataSources.Where(source => !(source is ChildQueryResultSource)))
            {
                yield return new TextFragment { Text = "\tfrom ", FragmentKind = FragmentKind.Keyword };
                foreach (var tf in ds.ToInlines())
                    yield return tf;
                yield return new TextFragment { Text = "\n" };
            }

            foreach (var ds in Query.DataSources.Where(source => (source is ChildQueryResultSource)))
            {
                foreach (var tf in ds.ToInlines())
                {
                    if (tf.Text.StartsWith("\t"))
                        tf.Text = tf.Text.Insert(0, "\t");
                    yield return tf;
                }
                yield return new TextFragment { Text = "\n" };
            }
            if (Query.OrderBy.Count > 0)
            {
                yield return new TextFragment { Text = "\torder by ", FragmentKind = FragmentKind.Keyword };
                foreach (var tf in Query.OrderBy.ToInlines())
                    yield return tf;

                yield return new TextFragment { Text = "\n" };
            }
            yield return new TextFragment { Text = "\t...\n" };
            if (Query.Select != null)
            {
                yield return new TextFragment { Text = "\tselect ", FragmentKind = FragmentKind.Keyword };
                foreach (var tf in Query.Select.ToInlines())
                {
                    if (tf.Text.StartsWith("\t"))
                        tf.Text.Insert(0, "\t");
                    yield return tf;
                }
            }
        }

    }
}
