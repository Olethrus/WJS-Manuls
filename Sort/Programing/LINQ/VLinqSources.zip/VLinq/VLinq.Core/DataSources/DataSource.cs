﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Markup;

namespace VLinq
{
    /// <summary>
    /// Base type of all query DataSources
    /// </summary>
    public abstract class DataSource : VLinqComponentBase
    {


        /// <summary>
        /// Flag indicating the type of datasource (for designer optimisation)
        /// </summary>
        public DataSourceType DataSourceType
        {
            get { return (DataSourceType)GetValue(DataSourceTypeProperty); }
        }

        // Using a DependencyProperty as the backing store for DataSourceType.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourceTypeProperty =
            DependencyProperty.Register("DataSourceType", typeof(DataSourceType), typeof(DataSource), new PropertyMetadata(DataSourceType.EntitySource));



        /// <summary>
        /// Name of the datasource
        /// </summary>
        public string Name
        {
            get { return (string)GetValue(NameProperty); }
            set { SetValue(NameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Name.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NameProperty =
            DependencyProperty.Register("Name", typeof(string), typeof(DataSource), new ChangeBublingMetadata());

        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            
            if (e.Property == NameProperty && NameChanged != null)
                NameChanged(this, e);
            base.OnPropertyChanged(e);
        }
        /// <summary>
        /// Event specifically raised when the name of the data source has changed.
        /// It is used at design-time to automatically modify DataSourceOperands referencing this DataSource
        /// </summary>
        public event DependencyPropertyChangedEventHandler NameChanged;
    }
}
