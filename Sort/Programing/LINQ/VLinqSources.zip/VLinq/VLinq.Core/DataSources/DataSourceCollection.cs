﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace VLinq
{
    /// <summary>
    /// Contains DataSources (implements INotifyChanged for Changed event bubbling)
    /// </summary>
    public class DataSourceCollection : VLinqComponentCollection<DataSource>
    {
    }
}
