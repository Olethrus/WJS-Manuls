﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    public enum DataSourceType
    {
        EntitySource,
        ChildEntitySource,
        ParameterSource,
        ChildQueryResultSource
    }
}
