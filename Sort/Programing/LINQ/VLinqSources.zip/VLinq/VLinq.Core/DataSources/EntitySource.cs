﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Represent an EntitySet data source (generates a from ... in ...)
    /// </summary>
    public class EntitySource : DataSource
    {
        static EntitySource()
        {
            DataSourceTypeProperty.OverrideMetadata(typeof(EntitySource), new PropertyMetadata(DataSourceType.EntitySource));
        }


        /// <summary>
        /// Type of the entities
        /// </summary>
        public string EntityTypeName
        {
            get { return (string)GetValue(EntityTypeNameProperty); }
            set { SetValue(EntityTypeNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EntityTypeName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EntityTypeNameProperty =
            DependencyProperty.Register("EntityTypeName", typeof(string), typeof(EntitySource), new ChangeBublingMetadata());


        public override string ToString()
        {
           return string.Format(CultureInfo.InvariantCulture, "{0} in [{1}]", Name, EntityTypeName.Contains('.')?EntityTypeName.Split('.').Last() : EntityTypeName);
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            yield return new TextFragment { Text = Name };
            yield return new TextFragment { Text = " in ", FragmentKind = FragmentKind.Keyword };
           // yield return new TextFragment { Text = "[" };
            yield return new TextFragment { Text =  EntityTypeName.Contains('.') ? EntityTypeName.Split('.').Last() : EntityTypeName,
                ToolTip = EntityTypeName, FragmentKind= FragmentKind.DataType};
           // yield return new TextFragment { Text = "]" };
            var parent = GetOwner();
            while (parent != null && !(parent is Query))
            {
                parent = parent.GetOwner();
            }
            var query = parent as Query;
            if (query != null)
            {
                var join = query.Joins.Where(j => j.RightEntitySource == Name).SingleOrDefault();
                if (join != null)
                {
                    yield return new TextFragment { Text = " (" };
                    if (join.IsLeftOutter)
                    {
                        yield return new TextFragment { Text = "left outer join on ", FragmentKind = FragmentKind.Keyword };
                    }
                    else
                    {
                        yield return new TextFragment { Text = "inner join on ", FragmentKind = FragmentKind.Keyword };
                    }
                    foreach (var inline in join.ToInlines())
                        yield return inline;
                    yield return new TextFragment { Text = ")" };
                }
            }
        }
    }
}
