﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.ComponentModel;

namespace VLinq
{
    public class JoinDeclaration : VLinqComponentBase
    {
        public JoinDeclaration()
        {
            SetValue(LeftPropertiesProperty, new VLinqStringList());
            SetValue(RightPropertiesProperty, new VLinqStringList());
        }

        public bool IsLeftOutter
        {
            get { return (bool)GetValue(IsLeftOutterProperty); }
            set { SetValue(IsLeftOutterProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsLeftOutter.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsLeftOutterProperty =
            DependencyProperty.Register("IsLeftOutter", typeof(bool), typeof(JoinDeclaration), new ChangeBublingMetadata(false));



        public string LeftEntitySource
        {
            get { return (string)GetValue(LeftEntitySourceProperty); }
            set { SetValue(LeftEntitySourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LeftDataSource.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LeftEntitySourceProperty =
            DependencyProperty.Register("LeftEntitySource", typeof(string), typeof(JoinDeclaration), new ChangeBublingMetadata(string.Empty));



        public string RightEntitySource
        {
            get { return (string)GetValue(RightEntitySourceProperty); }
            set { SetValue(RightEntitySourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for RightEntitySource.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RightEntitySourceProperty =
            DependencyProperty.Register("RightEntitySource", typeof(string), typeof(JoinDeclaration), new ChangeBublingMetadata(string.Empty));




        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public VLinqStringList LeftProperties
        {
            get { return (VLinqStringList)GetValue(LeftPropertiesProperty); }
        }

        // Using a DependencyProperty as the backing store for LeftProperties.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LeftPropertiesProperty =
            DependencyProperty.Register("LeftProperties", typeof(VLinqStringList), typeof(JoinDeclaration), new ChangeBublingMetadata());




        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public VLinqStringList RightProperties
        {
            get { return (VLinqStringList)GetValue(RightPropertiesProperty); }
        }

        // Using a DependencyProperty as the backing store for RightProperties.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RightPropertiesProperty =
            DependencyProperty.Register("RightProperties", typeof(VLinqStringList), typeof(JoinDeclaration), new ChangeBublingMetadata());




        public override IEnumerable<TextFragment> ToInlines()
        {
            if(LeftProperties == null || LeftProperties.Count ==0)
            {
                yield return new TextFragment { FragmentKind= FragmentKind.Keyword, Text = "new" };
                yield return new TextFragment { FragmentKind = FragmentKind.Normal, Text = " {} " };
            }
            else if (LeftProperties.Count == 1)
            {
                yield return new TextFragment { Text = LeftEntitySource + "." + LeftProperties[0].Value + " " };
            }
            else
            {
                yield return new TextFragment { FragmentKind = FragmentKind.Keyword, Text = "new" };
                yield return new TextFragment { FragmentKind = FragmentKind.Normal, Text = " {" };
                bool first = true;

                foreach (var val in LeftProperties.Select(strContainer => strContainer.Value))
                {
                    if (first)
                        first = false;
                    else
                        yield return new TextFragment { FragmentKind = FragmentKind.Normal, Text = ", " };
                    yield return new TextFragment { Text = LeftEntitySource + "." + val};

                }

                yield return new TextFragment { FragmentKind = FragmentKind.Normal, Text = "} " };
            }

            yield return new TextFragment { FragmentKind = FragmentKind.Keyword, Text = "equals " };

            if (RightProperties == null || RightProperties.Count == 0)
            {
                yield return new TextFragment { FragmentKind = FragmentKind.Keyword, Text = "new" };
                yield return new TextFragment { FragmentKind = FragmentKind.Normal, Text = " {} " };
            }
            else if (RightProperties.Count == 1)
            {
                yield return new TextFragment { Text = RightEntitySource + "." + RightProperties[0].Value + " " };
            }
            else
            {
                yield return new TextFragment { FragmentKind = FragmentKind.Keyword, Text = "new" };
                yield return new TextFragment { FragmentKind = FragmentKind.Normal, Text = " {" };
                bool first = true;

                foreach (var val in RightProperties.Select(strContainer => strContainer.Value))
                {
                    if (first)
                        first = false;
                    else
                        yield return new TextFragment { FragmentKind = FragmentKind.Normal, Text = ", " };
                    yield return new TextFragment { Text = RightEntitySource + "." + val };

                }

                yield return new TextFragment { FragmentKind = FragmentKind.Normal, Text = "} " };
            }
        }
    }
}
