﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    public class JoinDeclarationCollection : VLinqComponentCollection<JoinDeclaration>
    {
        public override IEnumerable<TextFragment> ToInlines()
        {
            return base.ToInlines();
        }
    }
}
