﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Represent a parameter passed as method argument
    /// </summary>
    public class ParameterSource : DataSource
    {
        static ParameterSource()
        {
            DataSourceTypeProperty.OverrideMetadata(typeof(ParameterSource), new PropertyMetadata(DataSourceType.ParameterSource));
        }
        /// <summary>
        /// Type of the Datasource or DataSource entities 
        /// </summary>
        public string TypeName
        {
            get { return (string)GetValue(TypeNameProperty); }
            set { SetValue(TypeNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TypeName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TypeNameProperty =
            DependencyProperty.Register("TypeName", typeof(string), typeof(ParameterSource), new ChangeBublingMetadata());


        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "{0} : {1}", Name, TypeName);
        }
        public override IEnumerable<TextFragment> ToInlines()
        {
            yield return new TextFragment { Text = TypeName, FragmentKind = FragmentKind.DataType };

            yield return new TextFragment { Text = " "+Name, ToolTip = TypeName };
        }
    }
}
