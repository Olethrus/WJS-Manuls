﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Markup;

namespace VLinq
{
    /// <summary>
    /// Group part (used in group key or value) composed of multiple entity refs
    /// </summary>
    [ContentProperty("EntityRefs")]
    public class ComposedGroupPart : GroupPart
    {

        /// <summary>
        /// type of the composed group part (null or empty to generate anonymous type)
        /// </summary>
        public string TypeName
        {
            get { return (string)GetValue(TypeNameProperty); }
            set { SetValue(TypeNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TypeName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TypeNameProperty =
            DependencyProperty.Register("TypeName", typeof(string), typeof(ComposedGroupPart), new ChangeBublingMetadata());


        /// <summary>
        /// true to generate a new type for this group
        /// </summary>
        public bool GenerateGroupPartType
        {
            get { return (bool)GetValue(GenerateGroupPartTypeProperty); }
            set { SetValue(GenerateGroupPartTypeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for GenerateGroupPartType.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GenerateGroupPartTypeProperty =
            DependencyProperty.Register("GenerateGroupPartType", typeof(bool), typeof(ComposedGroupPart), new ChangeBublingMetadata());


        /// <summary>
        /// Entity references used in this group part
        /// </summary>
        [System.ComponentModel.DesignerSerializationVisibility(System.ComponentModel.DesignerSerializationVisibility.Content)]
        public EntityRefCollection EntityRefs
        {
            get { return (EntityRefCollection)GetValue(EntityRefsProperty); }
        }

        // Using a DependencyProperty as the backing store for EntityRefs.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EntityRefsProperty =
            DependencyProperty.Register("EntityRefs", typeof(EntityRefCollection), typeof(ComposedGroupPart), new ChangeBublingMetadata());

        public ComposedGroupPart()
        {
            SetValue(EntityRefsProperty, new EntityRefCollection());
        }
        public override IEnumerable<TextFragment> ToInlines()
        {
            bool first = true;
            yield return new TextFragment { Text = "{" };
            foreach (var er in EntityRefs)
            {
                if (first)
                    first = false;
                else
                    yield return new TextFragment { Text = ", " };
                yield return new TextFragment { Text = er.Name };
                yield return new TextFragment { Text = " = " };
                if (er.Operand != null)
                {
                    foreach (var frag in er.Operand.ToInlines())
                        yield return frag;
                }
            }
            yield return new TextFragment { Text = "}" };
        }
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("{");
            bool first = true;
            foreach (var er in EntityRefs)
            {
                if (first)
                    first = false;
                else
                    builder.Append(", ");
                builder.Append(er.Name);
                builder.Append(" = ");
                builder.Append(er.Operand);
            }
            builder.Append("}");
            return builder.ToString();
        }
    }
}
