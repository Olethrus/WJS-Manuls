﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Markup;

namespace VLinq
{
    /// <summary>
    /// Named reference to a data source
    /// </summary>
    [ContentProperty("Operand")]
    public class EntityRef : VLinqComponentBase
    {



        /// <summary>
        /// Value referenced by the entity ref (should be a DataSourceOperand referencing an entitysource or childentitysource)
        /// </summary>
        public Operand Operand
        {
            get { return (Operand)GetValue(OperandProperty); }
            set { SetValue(OperandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandProperty =
            DependencyProperty.Register("Operand", typeof(Operand), typeof(EntityRef), new ChangeBublingMetadata());


        /// <summary>
        /// Name of the entity ref (used in ComposedGroupPart to define the property associated with the operand)
        /// </summary>
        public string Name
        {
            get { return (string)GetValue(NameProperty); }
            set { SetValue(NameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Name.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NameProperty =
            DependencyProperty.Register("Name", typeof(string), typeof(EntityRef), new ChangeBublingMetadata());

        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }
    }
}
