﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Group By definition of a query
    /// the generated code is 
    /// group [Value] by [Key] into [GroupName]
    /// </summary>
    public class Group : VLinqComponentBase
    {

        /// <summary>
        /// name associated with this group by statement (group ... by ... into [GroupName])
        /// </summary>
        public string GroupName
        {
            get { return (string)GetValue(GroupNameProperty); }
            set { SetValue(GroupNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for GroupName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GroupNameProperty =
            DependencyProperty.Register("GroupName", typeof(string), typeof(Group), new ChangeBublingMetadata());


        /// <summary>
        /// Key definition of the group (Composed or Simple). (group ... by [Key] into ...)
        /// </summary>
        public GroupPart Key
        {
            get { return (GroupPart)GetValue(KeyProperty); }
            set { SetValue(KeyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Key.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty KeyProperty =
            DependencyProperty.Register("Key", typeof(GroupPart), typeof(Group), new ChangeBublingMetadata());


        /// <summary>
        /// Value definition of the group (Composed or Simple). (group [Value] by ... into ...)
        /// </summary>
        public GroupPart Value
        {
            get { return (GroupPart)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Value.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(GroupPart), typeof(Group), new ChangeBublingMetadata());



        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "{1} by {0} into {2}", Key, Value, GroupName);
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            if (Value == null)
                yield return new TextFragment {Text= "null", FragmentKind=FragmentKind.Keyword };
            else
            {
                foreach (var frag in Value.ToInlines())
                    yield return frag;
            }
            yield return new TextFragment { Text = " by ", FragmentKind = FragmentKind.Keyword };

            if (Key == null)
                yield return new TextFragment { Text = "null", FragmentKind = FragmentKind.Keyword };
            else
            {
                foreach (var frag in Key.ToInlines())
                    yield return frag;
            }

            yield return new TextFragment { Text = " into ", FragmentKind = FragmentKind.Keyword };

            yield return new TextFragment { Text = GroupName };
        }
    }
}
