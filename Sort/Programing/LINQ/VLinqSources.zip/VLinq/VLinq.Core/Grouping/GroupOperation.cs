﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    /// <summary>
    /// Supported grouping operation (used in EntitySetTransform)
    /// </summary>
    public enum  GroupOperation
    {
        Count,
        CountDistinct,
        Min,
        Max,
        Sum,
        Select,
        Average,
        First,
        Last
    }
}
