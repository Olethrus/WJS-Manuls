﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    /// <summary>
    /// Base class of group parts definitions
    /// </summary>
    public abstract class GroupPart : VLinqComponentBase
    {
    }
}
