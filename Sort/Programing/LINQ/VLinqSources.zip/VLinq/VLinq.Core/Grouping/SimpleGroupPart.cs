﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Markup;

namespace VLinq
{
    /// <summary>
    /// Group part (key or value) defined by a single Operand
    /// </summary>
    [ContentProperty("EntityRef")]
    public class SimpleGroupPart : GroupPart
    {

        /// <summary>
        /// Operand referenced by the group part
        /// </summary>
        public Operand EntityRef
        {
            get { return (Operand)GetValue(EntityRefProperty); }
            set { SetValue(EntityRefProperty, value); }
        }

        // Using a DependencyProperty as the backing store for EntityRef.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EntityRefProperty =
            DependencyProperty.Register("EntityRef", typeof(Operand), typeof(SimpleGroupPart), new ChangeBublingMetadata());

        public override string ToString()
        {
            if (EntityRef != null)
                return EntityRef.ToString();
            else
                return string.Empty;
        }
        public override IEnumerable<TextFragment> ToInlines()
        {
            if (EntityRef != null)
                return EntityRef.ToInlines();
            else
                return new TextFragment[] { };
        }
    }
}
