﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;


namespace VLinq
{
    /// <summary>
    /// Interface to implement to participate to the Change event bubbling system
    /// </summary>
    public interface IVLinqComponent 
    {
        /// <summary>
        /// Event called when the object or one of its descendant in the graph has changed
        /// </summary>
        event EventHandler<NotifyChangedEventArgs> Changed;
        /// <summary>
        /// Create the NotifyChangedEventArgs, call the ChangedEvent, and bubble to the owner
        /// </summary>
        void NotifyChanged(DependencyProperty changedProperty);
        /// <summary>
        /// Set the owner of the object 
        /// </summary>
        /// <param name="owner"></param>
        void SetOwner(IVLinqComponent owner, DependencyProperty ownerProperty);

        IVLinqComponent GetOwner();

        DependencyProperty GetOwnerProperty();

        /// <summary>
        /// Add the current instance in the NotifyChangedEventArgs stack, call the ChangedEvent and call BubbleChangedEvent on the owner
        /// </summary>
        /// <param name="args"></param>
        void BubbleChangedEvent(NotifyChangedEventArgs args, DependencyProperty childProp);
        IEnumerable<TextFragment> ToInlines();
    }
}
