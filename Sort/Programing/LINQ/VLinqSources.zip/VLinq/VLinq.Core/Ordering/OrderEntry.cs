﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Represents an Order By clause
    /// </summary>
    public class OrderEntry : VLinqComponentBase
    {

        /// <summary>
        /// Name of the DataSource used to order (should be an Entity / ChildEntity Source)
        /// </summary>
        public string DataSourceName
        {
            get { return (string)GetValue(DataSourceNameProperty); }
            set { SetValue(DataSourceNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DataSourceName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourceNameProperty =
            DependencyProperty.Register("DataSourceName", typeof(string), typeof(OrderEntry), new ChangeBublingMetadata());


        /// <summary>
        /// Property of the DataSource used to order (should be numeric, DateTime or string)
        /// </summary>
        public string DataSourceProperty
        {
            get { return (string)GetValue(DataSourcePropertyProperty); }
            set { SetValue(DataSourcePropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DataSourceProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourcePropertyProperty =
            DependencyProperty.Register("DataSourceProperty", typeof(string), typeof(OrderEntry), new ChangeBublingMetadata());



        /// <summary>
        /// Flag indicating if the order must be descending
        /// </summary>
        public bool Descending
        {
            get { return (bool)GetValue(DescendingProperty); }
            set { SetValue(DescendingProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Descending.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DescendingProperty =
            DependencyProperty.Register("Descending", typeof(bool), typeof(OrderEntry), new ChangeBublingMetadata(false));


        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }
    }
}
