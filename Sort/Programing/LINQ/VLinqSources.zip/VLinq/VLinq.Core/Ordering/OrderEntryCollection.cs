﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Collection of Order entries (implements INotifyChanged)
    /// </summary>
    public class OrderEntryCollection : VLinqComponentCollection<OrderEntry>
    {
        public override IEnumerable<TextFragment> ToInlines()
        {
            bool first = true;
            foreach (var oe in this)
            {
                if (first)
                    first = false;
                else
                    yield return new TextFragment { Text = ",\n" };
                yield return new TextFragment { Text = oe.DataSourceName };
                if (!string.IsNullOrEmpty(oe.DataSourceProperty))
                {
                    yield return new TextFragment { Text = "." };
                    yield return new TextFragment { Text = oe.DataSourceProperty };
                }
                if (oe.Descending)
                    yield return new TextFragment { Text = " descending", FragmentKind = FragmentKind.Keyword };
            }
        }
        public override string ToString()
        {
            StringBuilder builder = new StringBuilder();
            bool first = true;
            foreach (var oe in this)
            {
                if (first)
                    first = false;
                else
                    builder.Append(",\n");
                builder.Append(oe.DataSourceName);
                if (!string.IsNullOrEmpty(oe.DataSourceProperty))
                    builder.AppendFormat(CultureInfo.InvariantCulture, ".{0}", oe.DataSourceProperty);
                if (oe.Descending)
                    builder.Append(" descending");
            }
            return builder.ToString();
        }
    }
}
