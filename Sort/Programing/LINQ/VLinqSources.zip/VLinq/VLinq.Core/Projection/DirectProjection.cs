﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Markup;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Represent a projection returning an entity or an entity property
    /// </summary>
    [ContentProperty("Operand")]
    public class DirectProjection : Projection
    {


        /// <summary>
        /// Operand projected
        /// </summary>
        public Operand Operand
        {
            get { return (Operand)GetValue(OperandProperty); }
            set { SetValue(OperandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandProperty =
            DependencyProperty.Register("Operand", typeof(Operand), typeof(DirectProjection), new ChangeBublingMetadata());


        public override string ToString()
        {
            if (Operand == null)
                return string.Empty;
            else
                return Operand.ToString();
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            if (Operand == null)
                yield return new TextFragment { Text = "empty", FragmentKind = FragmentKind.Keyword };
            else
                foreach (var frag in Operand.ToInlines())
                    yield return frag;
        }
    }
}
