﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Base class of query projections (Select)
    /// </summary>
    public abstract class Projection : VLinqComponentBase
    {
    }
}
