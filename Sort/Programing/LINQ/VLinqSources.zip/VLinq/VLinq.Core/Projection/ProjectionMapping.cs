﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Markup;

namespace VLinq
{
    /// <summary>
    /// Map an operand to an output object property
    /// </summary>
    [ContentProperty("Operand")]
    public class ProjectionMapping : VLinqComponentBase
    {

        
        /// <summary>
        /// Property of the output object
        /// </summary>
        public string OutputProperty
        {
            get { return (string)GetValue(OutputPropertyProperty); }
            set { SetValue(OutputPropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OuputProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OutputPropertyProperty =
            DependencyProperty.Register("OutputProperty", typeof(string), typeof(ProjectionMapping), new ChangeBublingMetadata());



        /// <summary>
        /// Operand associated with the property
        /// </summary>
        public Operand Operand
        {
            get { return (Operand)GetValue(OperandProperty); }
            set { SetValue(OperandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandProperty =
            DependencyProperty.Register("Operand", typeof(Operand), typeof(ProjectionMapping), new ChangeBublingMetadata());


        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }

    }
}
