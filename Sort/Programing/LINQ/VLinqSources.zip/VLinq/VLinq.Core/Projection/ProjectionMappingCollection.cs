﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace VLinq
{
    /// <summary>
    /// Collection of Projection Mappings (implements INotifyChanged)
    /// </summary>
    public class ProjectionMappingCollection : VLinqComponentCollection<ProjectionMapping>
    {

    }
}
