﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Markup;
using System.ComponentModel;

namespace VLinq
{
    /// <summary>
    /// Object regrouping multiple queries. Used to generate a class with multiple static method / compiled querries, or to extend a DataContext via partial classes
    /// </summary>
    [ContentProperty("Queries")]
    [DefaultProperty("ClassName")]
    public class QueryBag : VLinqComponentBase//, ICustomTypeDescriptor
    {


        /// <summary>
        /// Name of the class to generate
        /// </summary>
        [Category("General config")]
        [Description("Set the name of the generated class")]
       [DisplayName("Class name")]
        public string ClassName
        {
            get { return (string)GetValue(ClassNameProperty); }
            set { SetValue(ClassNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ClassName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ClassNameProperty =
            DependencyProperty.Register("ClassName", typeof(string), typeof(QueryBag), new ChangeBublingMetadata());



        /// <summary>
        /// Queries
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public VLinqComponentCollection<Query> Queries
        {
            get { return (VLinqComponentCollection<Query>)GetValue(QueriesProperty); }
        }

        // Using a DependencyProperty as the backing store for Queries.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueriesProperty =
            DependencyProperty.Register("Queries", typeof(VLinqComponentCollection<Query>), typeof(QueryBag), new ChangeBublingMetadata());


        public QueryBag()
        {
            SetValue(QueriesProperty, new VLinqComponentCollection<Query>());
        }



        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }

    }
}
