﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Markup;

namespace VLinq
{
    /// <summary>
    /// Class representing a query 
    /// </summary>
    [DefaultProperty("Name")]
    public class Query : VLinqComponentBase, INamed//, ICustomTypeDescriptor
    {
        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }
        /// <summary>
        /// Data sources indexed by names
        /// </summary>
        private Dictionary<string, DataSource> m_dataSourceDictionnary;
        public Query()
        {
            DataSourceCollection dsc = new DataSourceCollection();
            
            SetValue(DataSourcesProperty, dsc);
            SetValue(OrderByProperty, new OrderEntryCollection());

            SetValue(JoinsProperty, new JoinDeclarationCollection());
        }

      
        /// <summary>
        /// Constraint applied to filter data
        /// </summary>
        public Constraint Where
        {
            get { return (Constraint)GetValue(WhereProperty); }
            set { SetValue(WhereProperty, value); }
        }

       

        // Using a DependencyProperty as the backing store for Where.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty WhereProperty =
            DependencyProperty.Register("Where", typeof(Constraint), typeof(Query), new ChangeBublingMetadata());


        public Constraint Having
        {
            get { return (Constraint)GetValue(HavingProperty); }
            set { SetValue(HavingProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Having.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HavingProperty =
            DependencyProperty.Register("Having", typeof(Constraint), typeof(Query), new ChangeBublingMetadata());



        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public JoinDeclarationCollection Joins
        {
            [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
            get { return (JoinDeclarationCollection)GetValue(JoinsProperty); }
        }

        // Using a DependencyProperty as the backing store for Joins.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty JoinsProperty =
            DependencyProperty.Register("Joins", typeof(JoinDeclarationCollection), typeof(Query), new ChangeBublingMetadata());


        /// <summary>
        /// Data sources for this query.
        /// Data sources can be an entityset (from a DLinq DataContext) or a method parameter
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public DataSourceCollection DataSources
        {
            get {
                EnsureDataSourceDictionary();
                return (DataSourceCollection)GetValue(DataSourcesProperty); }
        }

        // Using a DependencyProperty as the backing store for DataSources.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourcesProperty =
            DependencyProperty.Register("DataSources", typeof(DataSourceCollection), typeof(Query), new ChangeBublingMetadata());

        /// <summary>
        /// Order entries before group operation
        /// </summary>
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public OrderEntryCollection OrderBy
        {
            get { return (OrderEntryCollection)GetValue(OrderByProperty); }
        }

        // Using a DependencyProperty as the backing store for OrderBy.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OrderByProperty =
            DependencyProperty.Register("OrderBy", typeof(OrderEntryCollection), typeof(Query), new ChangeBublingMetadata());


        /// <summary>
        /// Group entities by key values
        /// </summary>
        public Group GroupBy
        {
            get { return (Group)GetValue(GroupByProperty); }
            set { SetValue(GroupByProperty, value); }
        }

        // Using a DependencyProperty as the backing store for GroupBy.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GroupByProperty =
            DependencyProperty.Register("GroupBy", typeof(Group), typeof(Query), new ChangeBublingMetadata());


        /// <summary>
        /// Projection applied to the data
        /// </summary>
        public Projection Select
        {
            get { return (Projection)GetValue(SelectProperty); }
            set { SetValue(SelectProperty, value); }
        }

        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (DependencyPropertyChanged != null)
            {
                DependencyPropertyChanged(this, e);
            }
        }

        public event DependencyPropertyChangedEventHandler DependencyPropertyChanged;

        // Using a DependencyProperty as the backing store for Select.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectProperty =
            DependencyProperty.Register("Select", typeof(Projection), typeof(Query), new ChangeBublingMetadata());


        /// <summary>
        /// Name of the query (used to build the method name)
        /// </summary>
        [DisplayName("Query name")]
        [Category("Query configuration")]
        [Description("Set the name of the method or compiled query generated for this VLinq Query")]
        public string Name
        {
            get { return (string)GetValue(NameProperty); }
            set { SetValue(NameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Name.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NameProperty =
            DependencyProperty.Register("Name", typeof(string), typeof(Query), new ChangeBublingMetadata(new PropertyChangedCallback(OnNameChanged)));
        private static void OnNameChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var q = obj as Query;
            if (q != null)
            {
                if (q.NameChanged != null)
                    q.NameChanged(q, args);
                if (q.NamePathChanged != null)
                    q.NamePathChanged(q, EventArgs.Empty);
            }
        }
        public event DependencyPropertyChangedEventHandler NameChanged;

        public event EventHandler NamePathChanged;


        /// <summary>
        /// Grouping operation on the query output
        /// </summary>
        public EntitySetTransform OutputTransform
        {
            get { return (EntitySetTransform)GetValue(OutputTransformProperty); }
            set { SetValue(OutputTransformProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OutputGrouping.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OutputTransformProperty =
            DependencyProperty.Register("OutputTransform", typeof(EntitySetTransform), typeof(Query), new ChangeBublingMetadata());


        /// <summary>
        /// Activate generation of a pagined version (incompatible with OutputGrouping)
        /// </summary>
        [Category("Query configuration")]
        [DisplayName("Auto-pagination")]
        [Description("Generates paginated version of the query. In case of compiled query, the compiled version will be named \"QueryNamePaginated\"")]
        public bool GeneratePaginatedVersion
        {
            get { return (bool)GetValue(GeneratePaginatedVersionProperty); }
            set { SetValue(GeneratePaginatedVersionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for GeneratePaginedVersion.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GeneratePaginatedVersionProperty =
            DependencyProperty.Register("GeneratePaginatedVersion", typeof(bool), typeof(Query), new ChangeBublingMetadata(false));


        /// <summary>
        /// Add a Distinct() call at the end of the query
        /// </summary>
        [Category("Query configuration")]
        [DisplayName("Distinct")]
        [Description("Automatically delete double values")]
        public bool OnlyDistinctRows
        {
            get { return (bool)GetValue(OnlyDistinctRowsProperty); }
            set { SetValue(OnlyDistinctRowsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OnlyDistinctRows.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OnlyDistinctRowsProperty =
            DependencyProperty.Register("OnlyDistinctRows", typeof(bool), typeof(Query), new ChangeBublingMetadata(false));

        /// <summary>
        /// In case of sub-query, back reference to the the parent querry
        /// </summary>
        public Query ParentQuery
        {
            get
            {
                return GetValue(ParentQueryProperty) as Query;
            }
        }

        // Using a DependencyProperty as the backing store for ParentQuery.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParentQueryProperty =
            DependencyProperty.Register("ParentQuery", typeof(Query), typeof(Query), new PropertyMetadata(OnParentQueryChanged));
        private static void OnParentQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var q = obj as Query;
            if (q != null)
            {
                if (q.NamePathChanged != null)
                    q.NamePathChanged(q, EventArgs.Empty);
                var oldParent = args.OldValue as Query;
                var newParent = args.NewValue as Query;

                q.OnParentQueryChanged(oldParent, newParent);
            }
        }

        protected void OnParentQueryChanged(Query oldParent, Query newParent)
        {
            if(oldParent != null)
                oldParent.NamePathChanged -=parent_NamePathChanged;
            if(newParent != null)
                newParent.NamePathChanged += parent_NamePathChanged;
        }

        void parent_NamePathChanged(object sender, EventArgs e)
        {
            if (NamePathChanged != null)
                NamePathChanged(this, EventArgs.Empty);
        }



        /// <summary>
        /// Get a DataSource by giving its name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        public DataSource FindDataSource(string name)
        {
            EnsureDataSourceDictionary();
            if (!m_dataSourceDictionnary.ContainsKey(name))
            {
                var parent = GetValue(ParentQueryProperty) as Query;
                return parent != null ? parent.FindDataSource(name) : null;
            }
            else
            {
                return m_dataSourceDictionnary[name];
            }
        }

        /// <summary>
        /// DataSources of the query and of its ancestors
        /// </summary>
        public IEnumerable<DataSource> DataSourcesWithParents
        {
            get
            {
                var parent = GetValue(ParentQueryProperty) as Query;
                if (parent != null)
                    foreach (var ds in parent.DataSourcesWithParents)
                        yield return ds;
                foreach (var ds in DataSources)
                    yield return ds;
            }
        }


     
        /// <summary>
        /// Initialize the DataSource index
        /// </summary>
        public void EnsureDataSourceDictionary()
        {
            if (m_dataSourceDictionnary == null)
            {
                m_dataSourceDictionnary = new Dictionary<string, DataSource>();
                foreach (DataSource ds in DataSources)
                {
                    m_dataSourceDictionnary.Add(ds.Name, ds);
                    var cqrs = ds as ChildQueryResultSource;
                    if (cqrs != null)
                        cqrs.Query.SetValue(ParentQueryProperty, this);
                    ds.NameChanged += OnDataSourceNameChanged;
                }
                DataSources.CollectionChanged += delegate(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
                {
                    switch (e.Action)
                    {
                        case System.Collections.Specialized.NotifyCollectionChangedAction.Add:
                            foreach (DataSource ds in e.NewItems)
                            {
                                var cqrs = ds as ChildQueryResultSource;
                                if (cqrs != null)
                                    cqrs.Query.SetValue(ParentQueryProperty, this);
                                ds.NameChanged += OnDataSourceNameChanged;
                            }
                            break;
                        case System.Collections.Specialized.NotifyCollectionChangedAction.Remove:
                            {
                                foreach (DataSource ds in e.OldItems)
                                {
                                    ds.NameChanged -= OnDataSourceNameChanged;
                                }
                            }
                            break;
                    }
                    if (m_dataSourceDictionnary != null)
                    {
                        switch (e.Action)
                        {
                            case System.Collections.Specialized.NotifyCollectionChangedAction.Add:
                                foreach (DataSource ds in e.NewItems)
                                {
                                    
                                    m_dataSourceDictionnary.Add(ds.Name, ds);
                                }
                                break;
                            case System.Collections.Specialized.NotifyCollectionChangedAction.Remove:
                                foreach (DataSource ds in e.OldItems)
                                {
                                    m_dataSourceDictionnary.Remove(ds.Name);
                                }
                                break;
                        }
                    }
                };
            }
        }

        /// <summary>
        /// Update the DataSource index, when a DataSource name changes
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="args"></param>
        private void OnDataSourceNameChanged(object sender, DependencyPropertyChangedEventArgs args)
        {
            
            if (m_ignoreDSNameChanged == sender)
                m_ignoreDSNameChanged = null;
            else
            {
                var asDs = sender as DataSource;
                string newName = args.NewValue.ToString();
                if (m_dataSourceDictionnary != null)
                {
                    m_dataSourceDictionnary.Remove(args.OldValue.ToString());
                    if (FindDataSource(args.NewValue.ToString()) != null)
                    {
                        string baseName = args.NewValue.ToString();
                        var counter = 1;
                        string name = baseName + counter.ToString();
                        while (FindDataSource(name) != null)
                            name = baseName + (++counter).ToString();
                        m_ignoreDSNameChanged = asDs;
                        m_ignoreDSNameChanged.Name = name;
                        newName = name;
                    }
                }
                m_dataSourceDictionnary.Add(newName, asDs);
                PropagateDataSourceNameChanged(args.OldValue.ToString(), newName);
            }
        }

        DataSource m_ignoreDSNameChanged = null;

        private void PropagateDataSourceNameChanged(string oldName, string newName)
        {
            foreach (var ces in DataSources.OfType<ChildEntitySource>().Where(o => o.ParentEntitySourceName == oldName))
                ces.ParentEntitySourceName = newName;
            foreach (var cqrs in DataSources.OfType<ChildQueryResultSource>())
                cqrs.Query.PropagateDataSourceNameChanged(oldName, newName);
        }

        /// <summary>
        /// Switch the generation mode to "compiled-querry" instead of method (this calls CompiledQuery.Compile instead of creating a new method)
        /// </summary>
        /// 
        [Category("Query configuration")]
        [DisplayName("Compiled")]
        [Description("Generates a compiled query instead of a classical query. Can improve performance, but all queries are not compatible with this functionnality")]
        public bool Compiled
        {
            get { return (bool)GetValue(CompiledProperty); }
            set { SetValue(CompiledProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Compiled.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CompiledProperty =
            DependencyProperty.Register("Compiled", typeof(bool), typeof(Query), new ChangeBublingMetadata());




        
    }
}
