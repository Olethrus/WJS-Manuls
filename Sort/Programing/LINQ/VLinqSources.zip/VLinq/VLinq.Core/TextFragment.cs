﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq
{
    public class TextFragment
    {
        public string Text { get; set; }
        public string ToolTip { get; set; }
        public FragmentKind FragmentKind { get; set; }
        public string LinkUrl { get; set; }
        public bool IsLink
        {
            get { return !string.IsNullOrEmpty(LinkUrl); }
        }
    }
    public enum FragmentKind
    {
        Normal,
        Keyword,
        DataType,
        String
    }
}
