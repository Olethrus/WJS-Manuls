﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Transform used to generate : ([OutputType]) Convert.ChangeType([Operand],typeof([OutputType]))
    /// </summary>
    public class ChangeTypeTransform : Transform
    {

        /// <summary>
        /// Output type
        /// </summary>
        public string OutputTypeName
        {
            get { return (string)GetValue(OutputTypeNameProperty); }
            set { SetValue(OutputTypeNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OutputTypeName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OutputTypeNameProperty =
            DependencyProperty.Register("OutputTypeName", typeof(string), typeof(ChangeTypeTransform), new ChangeBublingMetadata());


        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.Append("To(");
            builder.Append(OutputTypeName);
            builder.Append(")");
            if (!string.IsNullOrEmpty( OutputProperty))
            {
                builder.AppendFormat(CultureInfo.InvariantCulture, ".{0}", OutputProperty);
            }
            if(ChainedTransform != null)
                builder.AppendFormat(CultureInfo.InvariantCulture, ".{0}", ChainedTransform);
            return builder.ToString();
        }

        public override IEnumerable<TextFragment> ToInlines()
        {
            yield return new TextFragment { Text = "To("};
            yield return new TextFragment{Text=  OutputTypeName, FragmentKind= FragmentKind.DataType };
            yield return new TextFragment { Text = ")" };
            if (!string.IsNullOrEmpty(OutputProperty))
            {
                yield return new TextFragment { Text = "." };
                yield return new TextFragment { Text = OutputProperty };
            }
            if (ChainedTransform != null)
            {
                yield return new TextFragment { Text = "."};
                foreach (var frag in ChainedTransform.ToInlines())
                    yield return frag;
            }
        }
    }
}
