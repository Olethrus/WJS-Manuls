﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Markup;

namespace VLinq
{
    /// <summary>
    /// Transform used to add custom C# or VB code on an operand
    /// </summary>
    [ContentProperty("ExpressionText")]
    public class CustomExpressionTransform : Transform
    {
        
        /// <summary>
        /// C# or VB code (use {0} to place the operand itself)
        /// </summary>
        public string ExpressionText
        {
            get { return (string)GetValue(ExpressionTextProperty); }
            set { SetValue(ExpressionTextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ExpressionText.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ExpressionTextProperty =
            DependencyProperty.Register("ExpressionText", typeof(string), typeof(CustomExpressionTransform), new ChangeBublingMetadata("{0}"));



       
        /// <summary>
        /// Type resulting from the custom expression
        /// </summary>
        public string OutputTypeName
        {
            get { return (string)GetValue(OutputTypeNameProperty); }
            set { SetValue(OutputTypeNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OutputTypeName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OutputTypeNameProperty =
            DependencyProperty.Register("OutputTypeName", typeof(string), typeof(CustomExpressionTransform), new ChangeBublingMetadata());

        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }
    }
}
