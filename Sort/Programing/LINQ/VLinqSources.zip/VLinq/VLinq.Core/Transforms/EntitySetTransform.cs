﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Allows to make a scalar output from the request result (using a group operation)
    /// </summary>
    public class EntitySetTransform : Transform
    {

        /// <summary>
        /// Operation to apply to the output
        /// </summary>
        public GroupOperation Operation
        {
            get { return (GroupOperation)GetValue(OperationProperty); }
            set { SetValue(OperationProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operation.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperationProperty =
            DependencyProperty.Register("Operation", typeof(GroupOperation), typeof(EntitySetTransform),  new ChangeBublingMetadata(GroupOperation.Count));



        /// <summary>
        /// (optionnal) property on wich the operation will be applied. If not specified, the whole projection will be used
        /// </summary>
        public string ProjectionProperty
        {
            get { return (string)GetValue(ProjectionPropertyProperty); }
            set { SetValue(ProjectionPropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ProjectionProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProjectionPropertyProperty =
            DependencyProperty.Register("ProjectionProperty", typeof(string), typeof(EntitySetTransform), new ChangeBublingMetadata());


        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.AppendFormat(CultureInfo.InvariantCulture, "{0}({1})", Operation, ProjectionProperty);
            if (!string.IsNullOrEmpty(OutputProperty))
            {
                builder.AppendFormat(CultureInfo.InvariantCulture, ".{0}", OutputProperty);
            }
            if(ChainedTransform != null)
                builder.AppendFormat(CultureInfo.InvariantCulture, ".{0}", ChainedTransform);
            return builder.ToString();
        }
        public override IEnumerable<TextFragment> ToInlines()
        {
            yield return new TextFragment { Text = string.Format(CultureInfo.InvariantCulture, "{0}({1})", Operation, ProjectionProperty) };
            if (!string.IsNullOrEmpty(OutputProperty))
            {
                yield return new TextFragment { Text = "." };
                yield return new TextFragment { Text = OutputProperty };
            }
            if (ChainedTransform != null)
            {
                yield return new TextFragment { Text = "." };
                foreach (var frag in ChainedTransform.ToInlines())
                    yield return frag;
            }
        }
    }
}
