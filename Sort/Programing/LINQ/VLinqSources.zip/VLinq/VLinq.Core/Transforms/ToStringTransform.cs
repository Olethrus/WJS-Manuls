﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace VLinq
{
    /// <summary>
    /// Simple tranfrom generating a ToString() call
    /// </summary>
    public class ToStringTransform : Transform
    {
        public override string ToString()
        {
            var builder = new StringBuilder();
            builder.Append("ToString()");
            if (!string.IsNullOrEmpty(OutputProperty))
            {
                builder.AppendFormat(CultureInfo.InvariantCulture, ".{0}", OutputProperty);
            }
            if (ChainedTransform != null)
                builder.AppendFormat(CultureInfo.InvariantCulture, ".{0}", ChainedTransform);
            return builder.ToString();
        }
        public override IEnumerable<TextFragment> ToInlines()
        {
            yield return new TextFragment { Text = "ToString()" };
            if (!string.IsNullOrEmpty(OutputProperty))
            {
                yield return new TextFragment { Text = "." };
                yield return new TextFragment { Text = OutputProperty };
            }
            if (ChainedTransform != null)
            {
                yield return new TextFragment { Text = "." };
                foreach (var frag in ChainedTransform.ToInlines())
                    yield return frag;
            }
        }
    }
}
