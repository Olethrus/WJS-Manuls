﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Represent a transformation applied on an Operand
    /// </summary>
    public abstract class Transform : VLinqComponentBase
    {
        /// <summary>
        /// (optional) Property to call after transformation
        /// (for example we can set it to Length on a ToStringTransform, to return the number of characters of the resulting string)
        /// </summary>
        public string OutputProperty
        {
            get { return (string)GetValue(OutputPropertyProperty); }
            set { SetValue(OutputPropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OutputProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OutputPropertyProperty =
            DependencyProperty.Register("OutputProperty", typeof(string), typeof(Transform), new ChangeBublingMetadata());


        /// <summary>
        /// Transform applied to the transformed operand (to generate things like "myAggregate.Average(o=>o.UnitPrice).ToString()")
        /// </summary>
        public Transform ChainedTransform
        {
            get { return (Transform)GetValue(ChainedTransformProperty); }
            set { SetValue(ChainedTransformProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ChainedTransform.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ChainedTransformProperty =
            DependencyProperty.Register("ChainedTransform", typeof(Transform), typeof(Transform), new ChangeBublingMetadata());


    }
}
