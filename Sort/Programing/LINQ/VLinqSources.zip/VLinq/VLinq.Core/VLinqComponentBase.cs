﻿using System;
using System.Collections.Generic;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Basic implementation of INotifyChanged (bubbling from one child)
    /// </summary>
    public abstract class VLinqComponentBase : DependencyObject, IVLinqComponent
    {
        
        private IVLinqComponent m_owner;
        public event EventHandler<NotifyChangedEventArgs> Changed;

        public void NotifyChanged(DependencyProperty property)
        {
            BubbleChangedEvent(new NotifyChangedEventArgs(),property);
        }
        DependencyProperty m_ownerProperty;
        public void SetOwner(IVLinqComponent owner, DependencyProperty ownerProperty)
        {
           
            m_owner = owner;
            m_ownerProperty = ownerProperty;
        }
        public IVLinqComponent GetOwner()
        {
            return m_owner;
        }
        public IVLinqComponent Owner { get { return m_owner; } }

        public DependencyProperty GetOwnerProperty()
        {
            return m_ownerProperty;
        }

       



        public void BubbleChangedEvent(NotifyChangedEventArgs args, DependencyProperty childProp)
        {
            args.ChangedStack.Push(new ChangeNotificationEntry { ChangedObject = this, ChangedProperty = childProp });
            if (Changed != null)
                Changed(this, args);
            if (m_owner != null)
            {
                m_owner.BubbleChangedEvent(args, m_ownerProperty);
            }
        }

        public abstract IEnumerable<TextFragment> ToInlines();



    }
    public class ChangeNotificationEntry
    {
        public IVLinqComponent ChangedObject { get; set; }
        public DependencyProperty ChangedProperty { get; set; }
    }
    public class NotifyChangedEventArgs : EventArgs
    {
        private Stack<ChangeNotificationEntry> m_changedStack = new Stack<ChangeNotificationEntry>();

        public Stack<ChangeNotificationEntry> ChangedStack
        {
            get { return m_changedStack; }
        }

    }
}
