﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;

namespace VLinq
{
    /// <summary>
    /// Observable collection implementing INotifyChanged (Event bubbling from multiple children)
    /// </summary>
    /// <typeparam name="T"></typeparam>
    [Serializable]
    public class VLinqComponentCollection<T> : ObservableCollection<T>, IVLinqComponent where T : IVLinqComponent
    {
        
        #region INotifyChanged Members
        IVLinqComponent m_owner;
        DependencyProperty m_ownerProperty;
        public event EventHandler<NotifyChangedEventArgs> Changed;
        public IVLinqComponent Owner { get { return m_owner; } }
        public void NotifyChanged(DependencyProperty property)
        {
            BubbleChangedEvent(new NotifyChangedEventArgs(), property);
        }

        public void SetOwner(IVLinqComponent owner, DependencyProperty ownerProperty)
        {
            
            m_owner = owner;
            m_ownerProperty = ownerProperty;
        }
        public IVLinqComponent GetOwner()
        {
            return m_owner;
        }

        public System.Windows.DependencyProperty GetOwnerProperty()
        {
            return m_ownerProperty;
        }


        public void BubbleChangedEvent(NotifyChangedEventArgs args, System.Windows.DependencyProperty childProp)
        {
            if (args.ChangedStack.Count > 0)
            {
                if (Contains((T)args.ChangedStack.Peek().ChangedObject ))
                {
                    DoBubleChangedEvent(args);
                }
            }
            else
            {
                DoBubleChangedEvent(args);
            }
        }
        private void DoBubleChangedEvent(NotifyChangedEventArgs args)
        {
            args.ChangedStack.Push(new ChangeNotificationEntry { ChangedObject = this });
            if (Changed != null)
                Changed(this, args);
            if (m_owner != null)
            {
                m_owner.BubbleChangedEvent(args, m_ownerProperty);
            }
        }

        #endregion

       
        protected override void OnCollectionChanged(System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            base.OnCollectionChanged(e);
            NotifyChanged(null);
            switch(e.Action)
            {
                case System.Collections.Specialized.NotifyCollectionChangedAction.Add:
                    foreach (IVLinqComponent child in e.NewItems)
                        if(child != null)
                            child.SetOwner(this,null);
                    break;
                case System.Collections.Specialized.NotifyCollectionChangedAction.Remove:
                    foreach (IVLinqComponent child in e.OldItems)
                        if (child != null)
                            child.SetOwner(null,null);
                    break;
                case System.Collections.Specialized.NotifyCollectionChangedAction.Replace:
                    foreach (IVLinqComponent child in e.OldItems)
                        if (child != null)
                            child.SetOwner(null,null);
                    foreach (IVLinqComponent child in e.NewItems)
                        if (child != null)
                            child.SetOwner(this,null);
                    break;
            }
        }

        public virtual IEnumerable<TextFragment> ToInlines()
        {
            var first = true;
            foreach (var element in this)
            {
                if (first)
                    first = false;
                else
                    yield return new TextFragment { Text = "\n" };

                foreach (var frag in element.ToInlines())
                    yield return frag;
            }
        }
        
    }
}
