﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.OLE.Interop;
using Microsoft.VisualStudio.Shell.Interop;
using Microsoft.VisualStudio;
using System.Windows.Markup;
using System.IO;
using System.Xml;
using VLinq.VSIntegration;
using VLinq.Processing;
using System.Globalization;

namespace VLinq.CustomTools
{
    /// <summary>
    /// COM-exposed used as a CustomTool in Visual Studio (take a vlinq query bag in intput and generates C#)
    /// </summary>
    [Guid("9BB41656-09FE-40ce-92E4-07AD89A1C593")]
    public class XamlToCSGenerator : IVsSingleFileGenerator, IObjectWithSite
    {
        #region IVsSingleFileGenerator Members

        /// <summary>
        /// This indicates to Visual Studio, that it must call the generated file "originalfile.designer.cs"
        /// </summary>
        /// <param name="pbstrDefaultExtension"></param>
        /// <returns></returns>
        public int DefaultExtension(out string pbstrDefaultExtension)
        {
            pbstrDefaultExtension = ".Designer.cs"; 
            return VSConstants.S_OK;
        }

        /// <summary>
        /// Main method of the generator
        /// </summary>
        /// <param name="wszInputFilePath">Input file path (not used)</param>
        /// <param name="bstrInputFileContents">Input file content (xaml string to deserialize)</param>
        /// <param name="wszDefaultNamespace">Default namespace of the project (or namespace specified in the property box of the origin vlinq file)</param>
        /// <param name="rgbOutputFileContents">Output of the custom tool (Use Marshall class to allocate memory and copy the UTF-8 bytes in the pointer)</param>
        /// <param name="pcbOutput">Size of the allocated output pointer (in bytes, should be the size of the UTF-8 encoded byte array)</param>
        /// <param name="pGenerateProgress">Used to send info about errors / warning to Visual Studio</param>
        /// <returns></returns>
        public int Generate(string wszInputFilePath, string bstrInputFileContents, string wszDefaultNamespace, IntPtr[] rgbOutputFileContents, out uint pcbOutput, IVsGeneratorProgress pGenerateProgress)
        {
            var prop = VLinq.Editor.DesignTimeProperties.DescriptionProperty;
            int retval = VSConstants.S_OK;
            QueryBag queryBag = null;
            pcbOutput = 0;
            try
            {
                queryBag = XamlReader.Load(new XmlTextReader( new StringReader(bstrInputFileContents))) as QueryBag;
            }
            catch (XamlParseException ex)
            {
                pGenerateProgress.GeneratorError(0, 0, ex.Message, (uint)ex.LineNumber, (uint)ex.LinePosition);

                return VSConstants.E_FAIL;
            }
            if (queryBag == null)
            {
                pGenerateProgress.GeneratorError(0, 0, Messages.VLinqFileIsCorrupt, 0, 0);

                return VSConstants.E_FAIL;
            }
            StringBuilder classBuilder = new StringBuilder();
            classBuilder.Append("using System;\nusing System.Collections.Generic;\nusing System.Linq;\nusing System.Data.Linq;\n\n");
            classBuilder.AppendFormat("namespace {0}\n", wszDefaultNamespace);
            classBuilder.Append("{\n");
            classBuilder.AppendFormat("public static partial class {0}\n", queryBag.ClassName);
            classBuilder.Append("{\n");

            bool isDataContext = false;
            try
            {
                var svc = VLinq.VSIntegration.TypeResolver.GetCurrentProjectTypeResolutionService();
                if(svc != null)
                {
                    var t = svc.GetType(wszDefaultNamespace + "." + queryBag.ClassName);
                    // TODO: verify Assembly Match

                    isDataContext = (t != null && t.IsSubclassOf(typeof(System.Data.Linq.DataContext)));
                }
            }
            catch
            {
                isDataContext = false;
            }

            CSharpQueryFormatter<DynamicTypeServiceDescriptionBuilder> formatter ;
            try
            {
                formatter = new CSharpQueryFormatter<DynamicTypeServiceDescriptionBuilder>();
                formatter.GeneratesMemberMethods = isDataContext;
            }
            catch (Exception )
            {
                pGenerateProgress.GeneratorError(0, 0, Messages.QueryFormatterInitializationFailed, 0, 0);

                throw;
            }
            foreach (var q in queryBag.Queries)
            {
                try
                {
                    classBuilder.AppendLine(formatter.FormatQuery(q));
                }
                catch (InvalidQueryException iqe)
                {
                    foreach (ValidationError ve in iqe.ValidationResult.Errors)
                    {
                        pGenerateProgress.GeneratorError(0, 0, string.Format(CultureInfo.InvariantCulture, "{2}: {0}: {1}", ve.Kind, ve.Message,q.Name), 0, 0);

                    }
                }
            }
            classBuilder.Append("}\n}\n");
            classBuilder.Replace("\n\r", "\n");
            classBuilder.Replace("\r\n", "\n");

            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(classBuilder.ToString());
            int outputLength = bytes.Length;
            rgbOutputFileContents[0] = Marshal.AllocCoTaskMem(outputLength);
            Marshal.Copy(bytes, 0, rgbOutputFileContents[0], outputLength);
            pcbOutput = (uint)outputLength;

            return retval;
            
        }

        #endregion


        // Generic implementation of IObjectWithSite, required by VS
        #region IObjectWithSite Members

        private const int E_FAIL = unchecked((int)0x80004005);
        private const int E_NOINTERFACE = unchecked((int)0x80004002);

        private object m_site;

        /// <summary>
        /// SetSite method of IOleObjectWithSite
        /// </summary>
        /// <param name="pUnkSite">site for this object to use</param>
        public virtual void SetSite(object pUnkSite)
        {
            m_site = pUnkSite;
        }

        /// <summary>
        /// GetSite method of IOleObjectWithSite
        /// </summary>
        /// <param name="riid">interface to get</param>
        /// <param name="ppvSite">array in which to stuff return value</param>
        public virtual void GetSite(ref Guid riid, out IntPtr ppvSite)
        {



            if (m_site == null)
            {
                throw new COMException("object is not sited", E_FAIL);
            }

            IntPtr pUnknownPointer = Marshal.GetIUnknownForObject(m_site);
            IntPtr intPointer = IntPtr.Zero;
            Marshal.QueryInterface(pUnknownPointer, ref riid, out intPointer);

            if (intPointer == IntPtr.Zero)
            {
                throw new COMException("site does not support requested interface", E_NOINTERFACE);
            }

            ppvSite = Marshal.ReadIntPtr(Marshal.GetObjectForIUnknown(intPointer), 0);
        }

        #endregion
    }
}
