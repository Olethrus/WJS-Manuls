﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Documents;
using System.ComponentModel;

namespace VLinq.Editor
{
    /// <summary>
    /// Attached properties used at design-time
    /// </summary>
    public  class DesignTimeProperties : DependencyObject
    {
        public static readonly DependencyProperty DescriptionProperty = DependencyProperty.RegisterAttached(
            "Description",
            typeof(string),
            typeof(DesignTimeProperties),
            new VLinq.ChangeBublingMetadata());
        public static void SetDescription(DependencyObject element, string value)
        {
            element.SetValue(DesignTimeProperties.DescriptionProperty, value);
        }
        public static string GetDescription(DependencyObject element)
        {
            return element.GetValue(DesignTimeProperties.DescriptionProperty) as string;
        }



        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static FrameworkElement GetEditorFor(DependencyObject obj)
        {
            return (FrameworkElement)obj.GetValue(EditorForProperty);
        }

        public static void SetEditorFor(DependencyObject obj, FrameworkElement value)
        {
            if(obj != null)
                obj.SetValue(EditorForProperty, value);
        }

        // Using a DependencyProperty as the backing store for EditorFor.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EditorForProperty =
            DependencyProperty.RegisterAttached("EditorFor", typeof(FrameworkElement), typeof(DesignTimeProperties), new UIPropertyMetadata());


        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static bool GetHighLight(DependencyObject obj)
        {
            return (bool)obj.GetValue(HighLightProperty);
        }

        public static void SetHighLight(DependencyObject obj, bool value)
        {
            obj.SetValue(HighLightProperty, value);
        }

        // Using a DependencyProperty as the backing store for HighLight.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HighLightProperty =
            DependencyProperty.RegisterAttached("HighLight", typeof(bool), typeof(DesignTimeProperties), new UIPropertyMetadata(false));




    }
}
