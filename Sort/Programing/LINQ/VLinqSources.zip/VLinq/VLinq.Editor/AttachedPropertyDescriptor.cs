﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows;

namespace VLinq.Editor
{
    public class AttachedPropertyDescriptor : PropertyDescriptor
    {
        private DependencyProperty m_property;

        public AttachedPropertyDescriptor(DependencyProperty attachedProperty, string name, Attribute[] attributes)
            : base(name, attributes)
        {
            m_property = attachedProperty;
        }

        public AttachedPropertyDescriptor(DependencyProperty attachedProperty, Attribute[] attributes)
            :this(attachedProperty, attachedProperty.Name, attributes)
        {
        }        

        public override bool CanResetValue(object component)
        {
            return true;
        }

        public override Type ComponentType
        {
            get { return typeof(DependencyObject); }
        }

        public override object GetValue(object component)
        {
            var asDepObj = component as DependencyObject;
            if (asDepObj != null)
                return asDepObj.GetValue(m_property);
            return null;
        }

        public override bool IsReadOnly
        {
            get { return false; }
        }

        public override Type PropertyType
        {
            get { return m_property.PropertyType; }
        }

        public override void ResetValue(object component)
        {
            var asDepObj = component as DependencyObject;
            if (asDepObj != null)
                asDepObj.ClearValue(m_property);
        }

        public override void SetValue(object component, object value)
        {
            var asDepObj = component as DependencyObject;
            if (asDepObj != null)
                asDepObj.SetValue(m_property,value);
        }

        public override bool ShouldSerializeValue(object component)
        {
            return true;
        }
    }

    public class DescriptionPropertyDescriptor : PropertyDescriptor
    {
        public DescriptionPropertyDescriptor()
            : base("Description", new Attribute[] { new CategoryAttribute("Query configuration"), new DisplayNameAttribute("Query description") })
        { }
        public override bool CanResetValue(object component)
        {
            return true;
        }

        public override Type ComponentType
        {
            get { return typeof(Query); }
        }

        public override object GetValue(object component)
        {
            Query q = component as Query;
            if (q != null)
                return DesignTimeProperties.GetDescription(q);
            return null;
        }

        public override bool IsReadOnly
        {
            get { return false; }
        }

        public override Type PropertyType
        {
            get { return typeof(string); }
        }

        public override void ResetValue(object component)
        {
            Query q = component as Query;
            if (q != null)
            {
                q.ClearValue(DesignTimeProperties.DescriptionProperty);
            }
        }

        public override void SetValue(object component, object value)
        {
            Query q = component as Query;
            if (q != null)
            {
                DesignTimeProperties.SetDescription(q, value.ToString());
            }
        }

        public override bool ShouldSerializeValue(object component)
        {
            return true;
        }
    }
}
