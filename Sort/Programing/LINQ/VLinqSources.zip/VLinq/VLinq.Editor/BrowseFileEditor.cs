﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing.Design;
using System.ComponentModel;
using System.Windows.Forms;
using System.Security.Permissions;

namespace VLinq.Editor
{
    public class BrowseFileEditor : UITypeEditor
    {
        [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
        public override UITypeEditorEditStyle GetEditStyle(ITypeDescriptorContext context)
        {
            return UITypeEditorEditStyle.Modal;
        }
        [PermissionSet(SecurityAction.LinkDemand, Name="FullTrust")]
        public override object EditValue(ITypeDescriptorContext context, System.IServiceProvider provider, object value)
        {
            string fileName = (string)value;
            OpenFileDialog fileDialog = new OpenFileDialog();

            if ((fileName != null) && (fileName != ""))
            {
                fileDialog.InitialDirectory = System.IO.Path.GetDirectoryName(fileName);
            }

            if (fileDialog.ShowDialog() == DialogResult.OK)
            {
                return fileDialog.FileName;
            }
            else
                return value;
        }
    }
}
