﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace VLinq.Editor
{
    public class ComparisonToOperatorConverter:IValueConverter
    {

        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is Comparison)
            {
                var comp = (Comparison)value;
                switch (comp)
                {
                    case Comparison.Equals:
                        return "==";
                    case Comparison.Greater:
                        return ">";
                    case Comparison.GreaterOrEquals:
                        return ">=";
                    case Comparison.Lower:
                        return "<";
                    case Comparison.LowerOrEquals:
                        return "<=";
                    case Comparison.NotEquals:
                        return "!=";
                    default:
                        return comp.ToString();
                }
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
