﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing.Design;
using System.Windows.Forms.Design;
using Microsoft.VisualStudio.Shell;
using System.Security.Permissions;

namespace VLinq.Editor
{
    public class ConnectionStringEditor : UITypeEditor
    {
        [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
        public override UITypeEditorEditStyle GetEditStyle(System.ComponentModel.ITypeDescriptorContext context)
        {
            return UITypeEditorEditStyle.Modal;
        }
        [PermissionSet(SecurityAction.LinkDemand, Name = "FullTrust")]
        public override object EditValue(System.ComponentModel.ITypeDescriptorContext context, IServiceProvider provider, object value)
        {
            IWindowsFormsEditorService formsService = provider.GetService(typeof(IWindowsFormsEditorService)) as IWindowsFormsEditorService;
            if (formsService != null)
            {
                var form = new Preview.ConnectionStringEditorForm();
                var qbagTypeDescriptor = context.Instance as QueryBagTypeDescriptor;
                if (qbagTypeDescriptor != null)
                    form.QueryBag = qbagTypeDescriptor.QueryBag;
                else
                {
                    var qtypeDescriptor = context.Instance as QueryTypeDescriptor;
                    if (qtypeDescriptor != null)
                        form.QueryBag = qtypeDescriptor.QueryBag;
                }
                if (formsService.ShowDialog(form) == System.Windows.Forms.DialogResult.OK)
                    return form.Value;
               
            }

            return value;
        }
    }
}
