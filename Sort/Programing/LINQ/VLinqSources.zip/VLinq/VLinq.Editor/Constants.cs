﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media.Animation;

namespace VLinq.Editor
{
    public static class Constants
    {
        public static Duration ShiftAnimationDuration = new Duration(TimeSpan.FromSeconds(1.5));
        public static Duration StepExpandAnimationDuration = new Duration(TimeSpan.FromSeconds(1));
        public static KeySpline SplineDeceleration = new KeySpline(0.1, 0.5, 0.1, 1);
        public static int MaxResultCountDuringPreview = 1000;
    }
}
