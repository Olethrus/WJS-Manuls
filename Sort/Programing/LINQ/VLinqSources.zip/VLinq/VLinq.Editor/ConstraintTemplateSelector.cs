﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;

namespace VLinq.Editor
{
    /// <summary>
    /// This DataTemplate selector contains one template for comparison
    /// and one template for LogicalOperator.
    /// </summary>
    public class ConstraintTemplateSelector : DataTemplateSelector
    {

        public DataTemplate ComparisonTemplate { get; set; }
        public DataTemplate LogicalOperatorTemplate { get; set; }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            if (item is ComparisonConstraint)
                return ComparisonTemplate;
            else
                return LogicalOperatorTemplate;
        }
    }
}