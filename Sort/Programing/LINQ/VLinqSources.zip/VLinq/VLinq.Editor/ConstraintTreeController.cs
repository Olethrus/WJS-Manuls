﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    public class ConstraintTreeController : FrameworkElement
    {

        public ConstraintTreeController()
        {
            AddComparison = new CustomParameterizedCommand<LogicalOperatorConstraint>();
            AddComparison.IsEnabled = true;
            AddComparison.Executing += new EventHandler<ParameterizedCommandEventArgs<LogicalOperatorConstraint>>(AddComparison_Executing);
            AddLogicalOperator = new CustomParameterizedCommand<LogicalOperatorConstraint>();
            AddLogicalOperator.IsEnabled = true;
            AddLogicalOperator.Executing += new EventHandler<ParameterizedCommandEventArgs<LogicalOperatorConstraint>>(AddLogicalOperator_Executing);

            DeleteConstraints = new CustomParameterizedCommand<LogicalOperandConstraintWithSelection>();
            DeleteConstraints.IsEnabled = true;
            DeleteConstraints.Executing += new EventHandler<ParameterizedCommandEventArgs<LogicalOperandConstraintWithSelection>>(DeleteConstraints_Executing);

            GroupConstraints = new CustomParameterizedCommand<LogicalOperandConstraintWithSelection>();
            GroupConstraints.IsEnabled = true;
            GroupConstraints.Executing += new EventHandler<ParameterizedCommandEventArgs<LogicalOperandConstraintWithSelection>>(GroupConstraints_Executing);

            UngroupConstraints = new CustomParameterizedCommand<LogicalOperandConstraintWithSelection>();
            UngroupConstraints.IsEnabled = true;
            UngroupConstraints.Executing += new EventHandler<ParameterizedCommandEventArgs<LogicalOperandConstraintWithSelection>>(UngroupConstraints_Executing);

            Clear = new CustomCommand { IsEnabled = true };
            Clear.Executing += new EventHandler(Clear_Executing);

        }

        void Clear_Executing(object sender, EventArgs e)
        {
            
            var asLogOp = RootConstraint as LogicalOperatorConstraint;
            if (asLogOp != null)
                asLogOp.Constraints.Clear();
        }
        public CustomCommand Clear { get; set; }

        

        public static bool GetIsAfterGroupBy(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsAfterGroupByProperty);
        }

        public static void SetIsAfterGroupBy(DependencyObject obj, bool value)
        {
            obj.SetValue(IsAfterGroupByProperty, value);
        }

        // Using a DependencyProperty as the backing store for IsAfterGroupBy.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsAfterGroupByProperty =
            DependencyProperty.RegisterAttached("IsAfterGroupBy", typeof(bool), typeof(ConstraintTreeController), new FrameworkPropertyMetadata(false,FrameworkPropertyMetadataOptions.Inherits));


        public bool IsAfterGroupBy
        {
            get
            {
                return GetIsAfterGroupBy(this);
            }
            set
            {
                if (value != IsAfterGroupBy)
                {
                    SetIsAfterGroupBy(this, value);
                    if (Query != null)
                    {
                        if (!value)
                        {
                            if (Query.Where == null)
                                Query.Where = new LogicalOperatorConstraint { Operator = LogicalOperator.And };
                            else if (!(Query.Where is LogicalOperatorConstraint))
                            {
                                var old = Query.Where;
                                var newWhere = new LogicalOperatorConstraint { Operator = LogicalOperator.And };
                                Query.Where = newWhere;
                                newWhere.Constraints.Add(old);
                            }
                            RootConstraint = Query.Where;
                        }
                        else
                        {
                            if (Query.Having == null)
                                Query.Having = new LogicalOperatorConstraint { Operator = LogicalOperator.And };
                            else if (!(Query.Having is LogicalOperatorConstraint))
                            {
                                var old = Query.Having;
                                var newHaving = new LogicalOperatorConstraint { Operator = LogicalOperator.And };
                                Query.Having = newHaving;
                                newHaving.Constraints.Add(old);
                            }
                            RootConstraint = Query.Having;
                        }
                        // TODO:Having
                    }
                }
            }
        }




        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(ConstraintTreeController), new UIPropertyMetadata(null, OnQueryChanged));

        private static void OnQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ConstraintTreeController elem = obj as ConstraintTreeController;
            if (elem != null)
            {
                elem.OnQueryChanged(args.OldValue == null ? default(Query) : (Query)args.OldValue, args.NewValue == null ? default(Query) : (Query)args.NewValue);
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
            if (newValue != null)
            {
                if (!IsAfterGroupBy)
                {
                    if (newValue.Where == null)
                        newValue.Where = new LogicalOperatorConstraint { Operator = LogicalOperator.And };
                    else if (!(newValue.Where is LogicalOperatorConstraint))
                    {
                        var old = newValue.Where;
                        var newWhere = new LogicalOperatorConstraint { Operator = LogicalOperator.And };
                        newValue.Where = newWhere;
                        newWhere.Constraints.Add(old);
                    }
                    RootConstraint = newValue.Where;
                }
                else
                {
                    if (Query.Having == null)
                        Query.Having = new LogicalOperatorConstraint { Operator = LogicalOperator.And };
                    else if (!(Query.Having is LogicalOperatorConstraint))
                    {
                        var old = Query.Having;
                        var newHaving = new LogicalOperatorConstraint { Operator = LogicalOperator.And };
                        Query.Having = newHaving;
                        newHaving.Constraints.Add(old);
                    }
                    RootConstraint = Query.Having;
                }
                // TODO:Having
            }
            else
                RootConstraint = null;
        }



        public Constraint RootConstraint
        {
            get { return (Constraint)GetValue(RootConstraintProperty); }
            set { SetValue(RootConstraintProperty, value); }
        }

        // Using a DependencyProperty as the backing store for RootConstraint.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RootConstraintProperty =
            DependencyProperty.Register("RootConstraint", typeof(Constraint), typeof(ConstraintTreeController), new UIPropertyMetadata(null, OnRootConstraintChanged));

        private static void OnRootConstraintChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ConstraintTreeController elem = obj as ConstraintTreeController;
            if (elem != null)
            {
                elem.OnRootConstraintChanged(args.OldValue == null ? default(Constraint) : (Constraint)args.OldValue, args.NewValue == null ? default(Constraint) : (Constraint)args.NewValue);
            }
        }
        protected virtual void OnRootConstraintChanged(Constraint oldValue, Constraint newValue)
        {
        }



        public CustomParameterizedCommand<LogicalOperatorConstraint> AddComparison
        {
            get { return (CustomParameterizedCommand<LogicalOperatorConstraint>)GetValue(AddComparisonProperty); }
            set { SetValue(AddComparisonProperty, value); }
        }

        // Using a DependencyProperty as the backing store for AddComparison.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AddComparisonProperty =
            DependencyProperty.Register("AddComparison", typeof(CustomParameterizedCommand<LogicalOperatorConstraint>), typeof(ConstraintTreeController), new UIPropertyMetadata(null));



        public CustomParameterizedCommand<LogicalOperatorConstraint> AddLogicalOperator
        {
            get { return (CustomParameterizedCommand<LogicalOperatorConstraint>)GetValue(AddLogicalOperatorProperty); }
            set { SetValue(AddLogicalOperatorProperty, value); }
        }

        // Using a DependencyProperty as the backing store for AddLogicalOperator.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AddLogicalOperatorProperty =
            DependencyProperty.Register("AddLogicalOperator", typeof(CustomParameterizedCommand<LogicalOperatorConstraint>), typeof(ConstraintTreeController), new UIPropertyMetadata(null));



        public CustomParameterizedCommand<LogicalOperandConstraintWithSelection> DeleteConstraints
        {
            get { return (CustomParameterizedCommand<LogicalOperandConstraintWithSelection>)GetValue(DeleteConstraintsProperty); }
            set { SetValue(DeleteConstraintsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DeleteConstraints.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DeleteConstraintsProperty =
            DependencyProperty.Register("DeleteConstraints", typeof(CustomParameterizedCommand<LogicalOperandConstraintWithSelection>), typeof(ConstraintTreeController), new UIPropertyMetadata(null));



        public CustomParameterizedCommand<LogicalOperandConstraintWithSelection> GroupConstraints
        {
            get { return (CustomParameterizedCommand<LogicalOperandConstraintWithSelection>)GetValue(GroupConstraintsProperty); }
            set { SetValue(GroupConstraintsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for GroupConstraints.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GroupConstraintsProperty =
            DependencyProperty.Register("GroupConstraints", typeof(CustomParameterizedCommand<LogicalOperandConstraintWithSelection>), typeof(ConstraintTreeController), new UIPropertyMetadata(null));



        public CustomParameterizedCommand<LogicalOperandConstraintWithSelection> UngroupConstraints
        {
            get { return (CustomParameterizedCommand<LogicalOperandConstraintWithSelection>)GetValue(UngroupConstraintsProperty); }
            set { SetValue(UngroupConstraintsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for UngroupConstraints.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty UngroupConstraintsProperty =
            DependencyProperty.Register("UngroupConstraints", typeof(CustomParameterizedCommand<LogicalOperandConstraintWithSelection>), typeof(ConstraintTreeController), new UIPropertyMetadata(null));





        void AddComparison_Executing(object sender, ParameterizedCommandEventArgs<LogicalOperatorConstraint> e)
        {
            if (e.Parameter != null)
            {
                ComparisonConstraint newConstraint = new ComparisonConstraint { Left = new ConstantOperand { TypeName = "System.String" }, Operator = Comparison.Equals, Right = new ConstantOperand { TypeName = "System.String" } };
                e.Parameter.Constraints.Add(newConstraint);
            }
        }

        void AddLogicalOperator_Executing(object sender, ParameterizedCommandEventArgs<LogicalOperatorConstraint> e)
        {
            if (e.Parameter != null)
            {
                if (e.Parameter.Operator == LogicalOperator.And)
                {
                    e.Parameter.Constraints.Add(new LogicalOperatorConstraint { Operator = LogicalOperator.Or,Constraints={new ComparisonConstraint(), new ComparisonConstraint()} });
                }
                else
                {
                    e.Parameter.Constraints.Add(new LogicalOperatorConstraint { Operator = LogicalOperator.And, Constraints = { new ComparisonConstraint(), new ComparisonConstraint() } });
                }
            }
        }

        void DeleteConstraints_Executing(object sender, ParameterizedCommandEventArgs<LogicalOperandConstraintWithSelection> e)
        {
            var asListOfConstraints = e.Parameter.Selection.Cast<Constraint>().ToArray();
            foreach (var c in asListOfConstraints)
                e.Parameter.LogicalOperatorConstraint.Constraints.Remove(c);
        }


        void UngroupConstraints_Executing(object sender, ParameterizedCommandEventArgs<LogicalOperandConstraintWithSelection> e)
        {
            var parent = e.Parameter.LogicalOperatorConstraint.GetOwner();
            while (!(parent is LogicalOperatorConstraint))
            {
                parent = parent.GetOwner();
            }
            var newParentConstraint = parent as LogicalOperatorConstraint;
            if (newParentConstraint != null)
            {
                var asListOfConstraints = e.Parameter.Selection.Cast<Constraint>().ToArray();
                foreach (var c in asListOfConstraints)
                    e.Parameter.LogicalOperatorConstraint.Constraints.Remove(c);
                foreach (var c in asListOfConstraints)
                    newParentConstraint.Constraints.Add(c);
            }
        }

        void GroupConstraints_Executing(object sender, ParameterizedCommandEventArgs<LogicalOperandConstraintWithSelection> e)
        {
            var asListOfConstraints = e.Parameter.Selection.Cast<Constraint>().ToArray();
            foreach (var c in asListOfConstraints)
                e.Parameter.LogicalOperatorConstraint.Constraints.Remove(c);
            var newConstraint = new LogicalOperatorConstraint { Operator = e.Parameter.LogicalOperatorConstraint.Operator == LogicalOperator.And ? LogicalOperator.Or : LogicalOperator.And };
            foreach (var c in asListOfConstraints)
                newConstraint.Constraints.Add(c);
            e.Parameter.LogicalOperatorConstraint.Constraints.Add(newConstraint);
        }

    }
}
