﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Controls.Primitives;
using VLinq.Editor.Operands;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for ConstraintTreeDesigner.xaml
    /// </summary>
    public partial class ConstraintTreeDesigner : UserControl
    {
        public ConstraintTreeController Controller
        {
            get { return DataContext as ConstraintTreeController; }
        }
        public ConstraintTreeDesigner()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ConstraintTreeDesigner_Loaded); 
        }

        void ConstraintTreeDesigner_Loaded(object sender, RoutedEventArgs e)
        {
            Controller.IsAfterGroupBy = this.IsAfterGroupBy;
        }
        
        public bool IsAfterGroupBy
        {
            get { return ConstraintTreeController.GetIsAfterGroupBy(this); }
            set { ConstraintTreeController.SetIsAfterGroupBy(this, value); }
        }

       

        private void ComparisonConstraintTemplateLoaded(object sender, RoutedEventArgs e)
        {
            //TODO : OperandHosts
            var asFrameworkElement = sender as FrameworkElement;
            
            if (asFrameworkElement != null)
            {

                DesignTimeProperties.SetEditorFor(asFrameworkElement.DataContext as DependencyObject, asFrameworkElement);
                var opHostLeft = asFrameworkElement.FindName("leftHost") as OperandHost;
                if (opHostLeft != null)
                    opHostLeft.Controller.Query = Controller.Query;

                var opHostRight = asFrameworkElement.FindName("rightHost") as OperandHost;
                if (opHostRight != null)
                    opHostRight.Controller.Query = Controller.Query;

                if (opHostLeft != null)
                {
                    opHostLeft.Controller.ComparisonRequest += delegate(object sender2, ComparisonRequestEventArgs args)
                    {
                        var comparisonConstraint = asFrameworkElement.DataContext as ComparisonConstraint;
                        comparisonConstraint.Operator = args.Operator;
                        var rightTxtBox = opHostRight.FindFirstVisualDescendantOf<TextBox>(VisualChildExplorationMode.Vertical);
                        if(rightTxtBox != null)
                            rightTxtBox.Focus();
                    };
                }
            }
        }

        private ListBox m_lastChangedSelectionOrigin;
        private bool m_handlingSelectionChanged = false;

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

            var originElement = sender as ListBox;
            //var btnDelete = originElement.FindName("btnDelete") as Button;
            //var btnGroup = originElement.FindName("btnGroup") as Button;
            //var btnUngroup = originElement.FindName("btnUngroup") as Button;
            var enabled = originElement.SelectedItems.Count > 0;
            originElement.ContextMenu.IsEnabled = enabled;

            //btnDelete.IsEnabled = enabled;
            //btnGroup.IsEnabled = enabled;
            //if (btnUngroup != null)
            //    btnUngroup.IsEnabled = enabled;
            if (!m_handlingSelectionChanged && m_lastChangedSelectionOrigin != originElement && originElement.SelectedItems.Count>0)
            {
                
                m_handlingSelectionChanged = true;

               
                    m_lastChangedSelectionOrigin = originElement;
                    
                    
                    ClearSelectionToChildren(rootListView, originElement);
                    
                m_handlingSelectionChanged = false;
            }
        }

        private void ClearSelectionToChildren(ListBox toClear, ListBox toSkip)
        {
            if (toClear != toSkip)
            {
                toClear.UnselectAll();
            }

            foreach (var item in toClear.Items)
            {
                if (item is LogicalOperatorConstraint)
                {
                    var container = toClear.ItemContainerGenerator.ContainerFromItem(item) as ListBoxItem;
                    if (container != null)
                    {
                        var templateKey = new DataTemplateKey(typeof(LogicalOperatorConstraint));
                        var template = FindResource(templateKey) as DataTemplate;
                        if (template != null)
                        {

                            var child = template.FindName("lstSubConstraints", FindContentPresenter(container) as FrameworkElement) as ListBox;
                            if (child != null)
                                ClearSelectionToChildren(child, toSkip);
                        }
                    }
                }
            }
        }

        private static ContentPresenter FindContentPresenter(DependencyObject parent)
        {
            var child = VisualTreeHelper.GetChild(parent, 0);
            while (!(child is ContentPresenter))
                child = VisualTreeHelper.GetChild(child, 0);

            return (ContentPresenter)child;
        }

        private GridViewRowPresenter FindGridViewRowPresenter(DependencyObject parent)
        {
            for (var i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent,i);
                if (child is GridViewRowPresenter)
                    return child as GridViewRowPresenter;
                else
                {
                    var presenter = FindGridViewRowPresenter(child);
                    if (presenter != null)
                        return presenter;
                }
            }
            return null;
        }
        protected override void OnPreviewMouseWheel(MouseWheelEventArgs e)
        {
            
            e.Handled = true;
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var asElement = sender as FrameworkElement;
            var lstView = asElement.FindFirstVisualAncestorOf<ContextMenu>().PlacementTarget as ListBox;

            var param = new LogicalOperandConstraintWithSelection { LogicalOperatorConstraint = asElement.DataContext as LogicalOperatorConstraint, Selection = lstView.SelectedItems };
            if (param.LogicalOperatorConstraint == null)
            {
                param.LogicalOperatorConstraint = Controller.RootConstraint as LogicalOperatorConstraint;
            }
            Controller.DeleteConstraints.Execute(param);
        }

        private void btnGroup_Click(object sender, RoutedEventArgs e)
        {
            var asElement = sender as FrameworkElement;
            var lstView = asElement.FindFirstVisualAncestorOf<ContextMenu>().PlacementTarget as ListBox;

            var param = new LogicalOperandConstraintWithSelection { LogicalOperatorConstraint = asElement.DataContext as LogicalOperatorConstraint, Selection = lstView.SelectedItems };
            if (param.LogicalOperatorConstraint == null)
            {
                param.LogicalOperatorConstraint = Controller.RootConstraint as LogicalOperatorConstraint;
            }
            Controller.GroupConstraints.Execute(param);

        }

        private void btnUngroup_Click(object sender, RoutedEventArgs e)
        {
            var asElement = sender as FrameworkElement;
            var lstView = asElement.FindFirstVisualAncestorOf<ContextMenu>().PlacementTarget as ListBox;
            var param = new LogicalOperandConstraintWithSelection { LogicalOperatorConstraint = asElement.DataContext as LogicalOperatorConstraint, Selection = lstView.SelectedItems };
            if (param.LogicalOperatorConstraint == null)
            {
                param.LogicalOperatorConstraint = Controller.RootConstraint as LogicalOperatorConstraint;
            }
            Controller.UngroupConstraints.Execute(param);
        }

        private void itemLoaded(object sender, RoutedEventArgs e)
        {
            var asElement = sender as FrameworkElement;
            var opLabel = asElement.FindName("opLabel") as FrameworkElement;
            var listBoxItem = asElement.FindFirstVisualAncestorOf<ListBoxItem>();
            var itemsControl = ItemsControl.ItemsControlFromItemContainer(listBoxItem);
            if (itemsControl.ItemContainerGenerator.IndexFromContainer(listBoxItem) == 0)
                opLabel.Visibility = Visibility.Collapsed;
            
        }

        private void btnRootAnd_Click(object sender, RoutedEventArgs e)
        {
            var asLogical = Controller.RootConstraint as LogicalOperatorConstraint;
            if (asLogical != null)
                asLogical.Operator = LogicalOperator.And;
        }

        private void btnRootOr_Click(object sender, RoutedEventArgs e)
        {
            var asLogical = Controller.RootConstraint as LogicalOperatorConstraint;
            if (asLogical != null)
                asLogical.Operator = LogicalOperator.Or;
        }

        private void btnLocalAnd_Click(object sender, RoutedEventArgs e)
        {
            var asLogical = (sender as FrameworkElement).DataContext as LogicalOperatorConstraint;
            if (asLogical != null)
                asLogical.Operator = LogicalOperator.And;
        }

        private void btnLocalOr_Click(object sender, RoutedEventArgs e)
        {
            var asLogical = (sender as FrameworkElement).DataContext as LogicalOperatorConstraint;
            if (asLogical != null)
                asLogical.Operator = LogicalOperator.Or;
        }

        private void ListBox_KeyDown(object sender, KeyEventArgs e)
        {
            var lstView = sender as ListBox;
            if (e.Key == Key.Delete)
            {
                var param = new LogicalOperandConstraintWithSelection { LogicalOperatorConstraint = lstView.DataContext as LogicalOperatorConstraint, Selection = lstView.SelectedItems };
                if (param.LogicalOperatorConstraint == null)
                {
                    param.LogicalOperatorConstraint = Controller.RootConstraint as LogicalOperatorConstraint;
                }
                Controller.DeleteConstraints.Execute(param);
                e.Handled = true;
            }
        }

        
    }
}
