﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Editor
{
    public enum ConstraintType
    {
        And,
        Or,
        Comparison
    }
}
