﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for CreateEntitySourceDialog.xaml
    /// </summary>
    public partial class CreateEntitySourceDialog : Window
    {
        public CreateEntitySourceDialog()
        {
            InitializeComponent();
        }

        public EntitySource EntitySource
        {
            get { return DataContext as EntitySource; }
        }

        public bool Ok { get; private set; }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.Ok = false;
            this.Close();
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            this.Ok = true;
            this.Close();
        }

        private void OnlyDataContextUnchecked(object sender, RoutedEventArgs e)
        {
            if (IsLoaded)
                typesTree.IsForDataContext = false;
        }

        private void OnlyDataContextChecked(object sender, RoutedEventArgs e)
        {
            if (IsLoaded)
                typesTree.IsForDataContext = true;
        }

        private void SelectedItemChanged(object sender, RoutedPropertyChangedEventArgs<object> e)
        {
            if (e.NewValue != null)
            {
                var newValue = e.NewValue as NodeInfo;
                if (newValue != null)
                {
                    if (newValue.Type != null)
                        EntitySource.EntityTypeName = newValue.Type.FullName;
                }
                btnOk.IsEnabled = newValue.IsSelectable;
            }
            else
                btnOk.IsEnabled = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            typesTree.SelectedItemChanged += SelectedItemChanged;
        }

        void typesTree_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (btnOk.IsEnabled)
            {
                this.Ok = true;
                Close();
            }
        }
    }
}
