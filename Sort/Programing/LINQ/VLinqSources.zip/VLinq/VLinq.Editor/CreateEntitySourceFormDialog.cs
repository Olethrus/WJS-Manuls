﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VLinq.Editor
{
    public partial class CreateEntitySourceFormDialog : Form
    {
        public CreateEntitySourceFormDialog()
        {
            InitializeComponent();
        }
    }
}
