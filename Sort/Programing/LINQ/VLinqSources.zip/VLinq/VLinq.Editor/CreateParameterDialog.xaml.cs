﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VLinq.Processing;
using Microsoft.VisualStudio.Modeling.Shell;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for CreateParameterDialog.xaml
    /// </summary>
    public partial class CreateParameterDialog : Window
    {
 


        
        private TypeDescriptionBuilder m_descriptionBuilder;
        public ParameterSource ParameterSource { get { return DataContext as ParameterSource; } }
        public CreateParameterDialog(TypeDescriptionBuilder typeDescriptionBuilder)
        {
            m_descriptionBuilder = typeDescriptionBuilder;
            InitializeComponent();
            cbPrimitive.ItemsSource = new PrimitiveTypeView[]
            {
                new PrimitiveTypeView{Label="bool", TypeName=typeof(bool).FullName},
                new PrimitiveTypeView{Label="byte", TypeName=typeof(byte).FullName},
                new PrimitiveTypeView{Label="byte[]", TypeName=typeof(byte[]).FullName},
                new PrimitiveTypeView{Label="DateTime", TypeName=typeof(DateTime).FullName},
                new PrimitiveTypeView{Label="decimal", TypeName=typeof(decimal).FullName},
                new PrimitiveTypeView{Label="double", TypeName=typeof(double).FullName},
                new PrimitiveTypeView{Label="float", TypeName=typeof(float).FullName},
                new PrimitiveTypeView{Label="int", TypeName=typeof(int).FullName},
                new PrimitiveTypeView{Label="long", TypeName=typeof(long).FullName},
                new PrimitiveTypeView{Label="short", TypeName=typeof(short).FullName},
                new PrimitiveTypeView{Label="string", TypeName=typeof(string).FullName}
            };
            cbPrimitive.SelectedIndex = 7;
            cbPrimitive.SelectionChanged += new SelectionChangedEventHandler(cbPrimitive_SelectionChanged);
        }

        void cbPrimitive_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbPrimitive.IsEnabled)
            {
                var item = cbPrimitive.SelectedItem as PrimitiveTypeView;
                if (item != null)
                    ParameterSource.TypeName = item.TypeName;
            }
        }

        private void btnOk_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
            this.Close();
        }

       
     

        


    }

    public class PrimitiveTypeView
    {
        public string Label { get; set; }
        public string TypeName { get; set; }
        public override string ToString()
        {
            return Label;
        }
    }
}
