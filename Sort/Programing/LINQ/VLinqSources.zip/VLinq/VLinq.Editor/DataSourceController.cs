﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Modeling.Shell;
using System.Collections.ObjectModel;
using System.Windows;
using System.ComponentModel;
using VLinq.Processing;
using System.Windows.Data;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    /// <summary>
    /// Controller for the DataSourceDesigner
    /// </summary>
    public class DataSourceController : DependencyObject
    {



        public bool ShowNewEntityButton
        {
            get { return (bool)GetValue(ShowNewEntityButtonProperty); }
            set { SetValue(ShowNewEntityButtonProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ShowNewEntityButton.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ShowNewEntityButtonProperty =
            DependencyProperty.Register("ShowNewEntityButton", typeof(bool), typeof(DataSourceController), new UIPropertyMetadata(true));



        public bool ShowNewChildQueryButton
        {
            get { return (bool)GetValue(ShowNewChildQueryButtonProperty); }
            set { SetValue(ShowNewChildQueryButtonProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ShowNewChildQueryButton.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ShowNewChildQueryButtonProperty =
            DependencyProperty.Register("ShowNewChildQueryButton", typeof(bool), typeof(DataSourceController), new UIPropertyMetadata(false));



        public bool ShowNewParameterButton
        {
            get { return (bool)GetValue(ShowNewParameterButtonProperty); }
            private set { SetValue(ShowNewParameterButtonProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ShowNewParameterButton.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ShowNewParameterButtonProperty =
            DependencyProperty.Register("ShowNewParameterButton", typeof(bool), typeof(DataSourceController), new UIPropertyMetadata(false));





        /// <summary>
        /// Indicates which kind of data source is controlled (entities, parameters, child queries)
        /// </summary>
        public DataSourceControllerMode Mode
        {
            get { return (DataSourceControllerMode)GetValue(ModeProperty); }
            set { SetValue(ModeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Mode.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ModeProperty =
            DependencyProperty.Register("Mode", typeof(DataSourceControllerMode), typeof(DataSourceController), new UIPropertyMetadata(DataSourceControllerMode.Entities, OnModeChanged));

        private static void OnModeChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            DataSourceController elem = obj as DataSourceController;
            if (elem != null)
            {
                elem.OnModeChanged(args.OldValue == null ? default(DataSourceControllerMode) : (DataSourceControllerMode)args.OldValue, args.NewValue == null ? default(DataSourceControllerMode) : (DataSourceControllerMode)args.NewValue);
            }
        }
        protected virtual void OnModeChanged(DataSourceControllerMode oldValue, DataSourceControllerMode newValue)
        {
            if (RootDataSources != null)
            {
                switch (newValue)
                {
                    case DataSourceControllerMode.ChildQueries:
                        RootDataSources.Filter = (ds => ds is ChildQueryResultSource);
                        break;
                    case DataSourceControllerMode.Entities:
                        RootDataSources.Filter = (ds => (ds is EntitySource) || (ds is ChildEntitySource));
                        break;
                    case DataSourceControllerMode.Parameters:
                        RootDataSources.Filter = (ds => ds is ParameterSource);
                        break;
                }
            }
            ShowNewParameterButton = newValue == DataSourceControllerMode.Parameters;
            ShowNewChildQueryButton = newValue == DataSourceControllerMode.ChildQueries;
            ShowNewEntityButton = newValue == DataSourceControllerMode.Entities;
        }



        /// <summary>
        /// DataFormat name used in Drag & Drop operation of child entities
        /// </summary>
        public static readonly string DataSourcePropertyFormat = "VLinq.DataSourcePropertyFormat";



        public ICollectionView RootDataSources
        {
            get { return (ICollectionView)GetValue(RootDataSourcesProperty); }
            private set { SetValue(RootDataSourcesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for RootDataSources.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RootDataSourcesProperty =
            DependencyProperty.Register("RootDataSources", typeof(ICollectionView), typeof(DataSourceController), new UIPropertyMetadata(null));


       


       

        QueryDesignerController m_parentController;
        public QueryDesignerController ParentController
        {
            get { return m_parentController; }
        }
        public DataSourceController(QueryDesignerController parentController)
            : this()
        {
            m_parentController = parentController;

            InitRootDataSources();
        }
        public CustomCommand Clear { get; set; }
        /// <summary>
        /// Initialize (or reset) the root data source collection (exposed to the designer)
        /// </summary>
        private void InitRootDataSources()
        {
            RootDataSources = new CollectionViewSource { Source = ParentController.Query.DataSources }.View;
            RootDataSources.Filter = (o => (o is EntitySource) || (o is ChildEntitySource));
        }

        public void DeleteDataSource(DataSource ds)
        {
            if (m_parentController.Query.DataSources.Contains(ds))
                m_parentController.Query.DataSources.Remove(ds);
        }
        

       
        public DataSourceController()
        {
            Clear = new CustomCommand { IsEnabled = true };
            Clear.Executing += new EventHandler(Clear_Executing);
            if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))
            {
                EntitySource parent = new EntitySource { EntityTypeName = "TestXaml.Category", Name = "category" };
                var child = new ChildEntitySource{ParentEntitySourceName="category", ParentEntitySourceProperty="Products", Name="product"};
                
                ObservableCollection<DataSource> dsList = new ObservableCollection<DataSource> { parent, child };
                RootDataSources = new CollectionViewSource { Source = dsList }.View;
            }

            Up = new CustomParameterizedCommand<DataSource> { IsEnabled = true };
            Down = new CustomParameterizedCommand<DataSource> { IsEnabled = true };
            Up.Executing += new EventHandler<ParameterizedCommandEventArgs<DataSource>>(Up_Executing);
            Down.Executing += new EventHandler<ParameterizedCommandEventArgs<DataSource>>(Down_Executing);
        }
        public struct TwoInts { public int Min, Max; }

        public TwoInts GetMinAndMaxDataSourceIndex(DataSource ds)
        {
            TwoInts retval = new TwoInts();
            switch (Mode)
            {
                case DataSourceControllerMode.Entities:
                    {
                        if (ds is EntitySource)
                            retval.Min = 0;
                        else
                        {
                            var asChildEntity = ds as ChildEntitySource;
                            var parent = ParentController.Query.FindDataSource(asChildEntity.ParentEntitySourceName);
                            if (parent == null || !ParentController.Query.DataSources.Contains(parent))
                                retval.Min = 0;
                            else retval.Min = ParentController.Query.DataSources.IndexOf(parent) + 1;

                            
                        }
                        var index = 0;
                        foreach (var source in ParentController.Query.DataSources)
                        {
                            if (source is EntitySource || source is ChildEntitySource)
                                index++;
                            else
                            {

                                break;
                            }
                        }

                        retval.Max = --index;
                    }
                    break;
                case DataSourceControllerMode.Parameters:
                    {
                        var index = 0;
                        foreach (var source in ParentController.Query.DataSources)
                        {
                            if (source is EntitySource || source is ChildEntitySource)
                                index++;
                            else
                            {

                                break;
                            }
                        }
                        retval.Min = index;
                        int i = 0;
                        for (i = index; i < ParentController.Query.DataSources.Count; i++)
                        {
                            if (!(ParentController.Query.DataSources[i] is ParameterSource))
                                break;
                        }
                        retval.Max = --i;
                    }
                    break;
                case DataSourceControllerMode.ChildQueries:
                    {
                        var index = 0;
                        foreach (var source in ParentController.Query.DataSources)
                        {
                            if (!(source is ChildQueryResultSource))
                                index++;
                            else
                            {

                                break;
                            }
                        }
                        retval.Min = index;
                        retval.Max = ParentController.Query.DataSources.Count - 1;
                    }
                    break;
            }
            return retval;
        }

        void Down_Executing(object sender, ParameterizedCommandEventArgs<DataSource> e)
        {
            if (e.Parameter != null)
            {
                var oldIndex = ParentController.Query.DataSources.IndexOf(e.Parameter);
                var minAndMax = GetMinAndMaxDataSourceIndex(e.Parameter);
                var desiredIndex = oldIndex + 1;
                ApplyNewDatasourceIndex(e.Parameter, oldIndex, ref minAndMax, ref desiredIndex);
            }
        }

        void Up_Executing(object sender, ParameterizedCommandEventArgs<DataSource> e)
        {
            if (e.Parameter != null)
            {
                var oldIndex = ParentController.Query.DataSources.IndexOf(e.Parameter);
                var minAndMax = GetMinAndMaxDataSourceIndex(e.Parameter);
                var desiredIndex = oldIndex - 1;
                ApplyNewDatasourceIndex(e.Parameter,oldIndex, ref minAndMax, ref desiredIndex);
            }
        }

        private void ApplyNewDatasourceIndex(DataSource ds, int oldIndex, ref TwoInts minAndMax, ref int desiredIndex)
        {
            if (desiredIndex < minAndMax.Min)
                desiredIndex = minAndMax.Min;
            else if (desiredIndex > minAndMax.Max)
                desiredIndex = minAndMax.Max;
            if (oldIndex != desiredIndex)
            {
                //ParentController.Query.DataSources.Move(oldIndex, desiredIndex);
                ParentController.Query.DataSources.Remove(ds);
                
                ParentController.Query.DataSources.Insert(desiredIndex, ds);
                
            }
        }
        public void CreateJoinFromTwoEntitySources(EntitySource left, EntitySource right)
        {
            if (ParentController.Query.DataSources.IndexOf(left)
                    > ParentController.Query.DataSources.IndexOf(right))
            {
                var temp = left;
                left = right;
                right = temp;
            }

            var newJoin = new JoinDeclaration { LeftEntitySource = left.Name, RightEntitySource = right.Name };
            string[] allLeftProps = new String[0];
            string[] allRightProps = new String[0];

            var leftDesc = ValidTimeProperties.GetReturnType(left);
            if (leftDesc != null)
                allLeftProps = leftDesc.Properties.Select(p => p.Name).ToArray();
            var rightDesc = ValidTimeProperties.GetReturnType(right);
            if (rightDesc != null)
                allRightProps = rightDesc.Properties.Select(p => p.Name).ToArray();

            foreach (var prop in allLeftProps.Intersect(allRightProps))
            {
                newJoin.LeftProperties.Add(new VLinqString { Value = prop });
                newJoin.RightProperties.Add(new VLinqString { Value = prop });
            }
            ParentController.Query.Joins.Add(newJoin);
        }

        public CustomParameterizedCommand<DataSource> Up { get; private set; }
        public CustomParameterizedCommand<DataSource> Down { get; private set; }

        void Clear_Executing(object sender, EventArgs e)
        {
            DataSource[] toDelete=null;
            switch (this.Mode)
            {
                case DataSourceControllerMode.ChildQueries:
                    toDelete = (from ds in this.ParentController.Query.DataSources
                                where ds is ChildQueryResultSource
                                select ds).ToArray();
                    break;
                case DataSourceControllerMode.Parameters:
                    toDelete = (from ds in this.ParentController.Query.DataSources
                                where ds is ParameterSource
                                select ds).ToArray();
                    break;
                case DataSourceControllerMode.Entities:
                    toDelete = (from ds in this.ParentController.Query.DataSources
                                where ds is EntitySource || ds is ChildEntitySource
                                select ds).ToArray();
                    break;
            }
            foreach (var ds in toDelete)
                ParentController.Query.DataSources.Remove(ds);
        }

        

        #region IDataSourceController Members

        /// <summary>
        /// See if the query can accept the content of a clipboard  as a new DataSource (Drag & Drop)
        /// </summary>
        /// <param name="dataObject">Should contain Data from Object Browser, Class view or from a property of an existing entity source</param>
        /// <returns></returns>
        public bool IsClipboardValid(System.Windows.Forms.IDataObject dataObject)
        {
            if (Mode == DataSourceControllerMode.ChildQueries)
                return false;

            if (ClassViewNavigationInfo.IsDataPresent(dataObject, ClassViewNavigationInfoTypes.Class, true, false))
            {
                // handling data from Object browser / Class view
                foreach (ClassViewNavigationInfoNode node in ClassViewNavigationInfo.GetData(dataObject))
                {
                    if (ClassViewNavigationInfoTypes.Class == node.InfoType)
                    {
                        // verify that the type is accessible
                        var td = m_parentController.Validator.TypeDescriptionBuilder.BuildTypeDescription(node.FullName);
                        if (td == null || td.IsGenericTypeDefinition)
                            return false;
                    }

                }
                return true;
            }
            else if (dataObject.GetDataPresent(DataSourcePropertyFormat) && Mode == DataSourceControllerMode.Entities)
            {
                // Handles Child entity source case
                string[] parts = dataObject.GetData(DataSourcePropertyFormat).ToString().Split('|');
                if (parts.Length != 2)
                    return false;
                var parentDS = m_parentController.Query.FindDataSource(parts[0]);

                if (parentDS == null)
                    return false;
                var parentTD = ValidTimeProperties.GetReturnType(parentDS);
                if (parentTD == null)
                    return false;
                var propDesc = parentTD.GetProperty(parts[1]);
                if (propDesc == null)
                    return false;
                return propDesc.TypeDescription.IsEnumerable;
            }
            return false;
        }

        /// <summary>
        /// create a DataSource from the content of the clipboard  (Drag & Drop)
        /// </summary>
        /// <param name="dataObject"></param>
        public void CreateFromClipboard(System.Windows.Forms.IDataObject dataObject)
        {
            var unallowedNames = from ds in m_parentController.Query.DataSourcesWithParents
                                 select ds.Name;
            if (ClassViewNavigationInfo.IsDataPresent(dataObject, ClassViewNavigationInfoTypes.Class, true, false))
            {
                foreach (ClassViewNavigationInfoNode node in ClassViewNavigationInfo.GetData(dataObject))
                {
                    if (ClassViewNavigationInfoTypes.Class == node.InfoType)
                    {
                        if (Mode == DataSourceControllerMode.Entities)
                        {

                            EntitySource entitySource = new EntitySource { EntityTypeName = node.FullName };

                            string[] typeNameParts = node.FullName.Split('.');
                            string baseName = typeNameParts.Last().Substring(0, 1).ToLower();
                            string name = baseName;
                            int counter = 0;
                            while (unallowedNames.Contains(name))
                                name = baseName + (++counter).ToString();
                            entitySource.Name = name;
                            var index = 0;
                            foreach (var existingSource in m_parentController.Query.DataSources)
                            {
                                if (existingSource is ParameterSource || existingSource is ChildQueryResultSource)
                                {
                                    break;
                                }
                                index++;
                            }
                            m_parentController.Query.DataSources.Insert(index, entitySource);
                            if (m_parentController.Query.IsSelectEmpty())
                                m_parentController.Query.Select = new DirectProjection { Operand = new DataSourceOperand { DataSourceName = entitySource.Name } };
                        }
                        else if(Mode == DataSourceControllerMode.Parameters)
                        {
                            ParameterSource paramSource = new ParameterSource { TypeName = node.FullName };

                            string baseName = "param";
                            string name = baseName;
                            int counter = 0;
                            while (unallowedNames.Contains(name))
                                name = baseName + (++counter).ToString();
                            paramSource.Name = name;
                            InsertNewParameter(paramSource);
                        }
                    }
                }
            }
            else if (dataObject.GetDataPresent(DataSourcePropertyFormat) && Mode == DataSourceControllerMode.Entities)
            {
                string[] parts = dataObject.GetData(DataSourcePropertyFormat).ToString().Split('|');
                if (parts.Length != 2)
                    return;
                var parentDS = m_parentController.Query.FindDataSource(parts[0]);

                if (parentDS == null)
                    return;
                var parentTD = ValidTimeProperties.GetReturnType(parentDS);
                if (parentTD == null)
                    return;
                var propDesc = parentTD.GetProperty(parts[1]);
                if (propDesc == null)
                    return;
                if (propDesc.TypeDescription.IsEnumerable)
                    CreateChildDataSource(parentDS, propDesc);
            }
        }
        private string EnsureNewName(string baseName)
        {
            baseName = baseName.ToCamlCase();
            var unallowedNames = from ds in m_parentController.Query.DataSourcesWithParents
                                 select ds.Name;
            string name = baseName;
            int counter = 0;
            while (unallowedNames.Contains(name))
                name = baseName + (++counter).ToString();
            return name;
        }
        public void InsertNewEntitySource(EntitySource source)
        {
            if (string.IsNullOrEmpty(source.Name))
            {
                string[] typeNameParts = source.EntityTypeName.Split('.');
                source.Name = typeNameParts.Last().Substring(0, 1).ToLower();
            }
            source.Name = EnsureNewName(source.Name);
            var index = 0;
            foreach (var existingSource in m_parentController.Query.DataSources)
            {
                if (existingSource is ParameterSource || existingSource is ChildQueryResultSource)
                {
                    break;
                }
                index++;
            }
            m_parentController.Query.DataSources.Insert(index, source);
            if (m_parentController.Query.IsSelectEmpty())
                m_parentController.Query.Select = new DirectProjection { Operand = new DataSourceOperand { DataSourceName = source.Name } };
        }
        public void InsertNewParameter(ParameterSource paramSource)
        {
            paramSource.Name = EnsureNewName(paramSource.Name);
            var index = 0;
            foreach (var existingSource in m_parentController.Query.DataSources)
            {
                if (existingSource is ChildQueryResultSource)
                {
                    break;
                }
                index++;
            }
            m_parentController.Query.DataSources.Insert(index, paramSource);
        }

        public ChildQueryResultSource CreateSubQuery()
        {
            var ds = new ChildQueryResultSource { Query = new Query() };
            ds.Name = EnsureNewName("childQuery");
            m_parentController.Query.DataSources.Add(ds);
            return ds;
        }

        /// <summary>
        /// Create a ChildEntitySource
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="property"></param>
        public void CreateChildDataSource(DataSource parent, VLinq.Processing.PropertyDescription property)
        {
            var unallowedNames = from ds in m_parentController.Query.DataSourcesWithParents
                                 select ds.Name;
            if (property.TypeDescription.IsEnumerable)
            {
                ChildEntitySource ces = CreateChildEntitySourceWithoutInsertingIt(parent, property);
                var index = 0;
                if(m_parentController.Query.DataSources.Contains(parent))
                    index = m_parentController.Query.DataSources.IndexOf(parent) + 1;
                for (; index <= m_parentController.Query.DataSources.Count; index++)
                {
                    if (index == m_parentController.Query.DataSources.Count)
                        break;
                    var existingDS = m_parentController.Query.DataSources[index] as ChildEntitySource;
                    if (existingDS == null)
                        break;
                    if (existingDS.ParentEntitySourceName != parent.Name)
                        break;
                }
                m_parentController.Query.DataSources.Insert(index, ces);

            }
        }

        public ChildEntitySource CreateChildEntitySourceWithoutInsertingIt(DataSource parent, VLinq.Processing.PropertyDescription property)
        {
            ChildEntitySource ces = new ChildEntitySource { ParentEntitySourceName = parent.Name, ParentEntitySourceProperty = property.Name };
            string baseName = ces.ParentEntitySourceName + ces.ParentEntitySourceProperty;
            baseName = baseName.ToCamlCase();
            if (baseName.EndsWith("ies"))
                baseName = baseName.Substring(0, baseName.Length - 3) + "y";
            else if (baseName.EndsWith("s"))
                baseName = baseName.Substring(0, baseName.Length - 1);

            ces.Name = EnsureNewName(baseName);
            return ces;
        }

        #endregion
    }
}
