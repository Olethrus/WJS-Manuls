﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.Processing;
using System.Diagnostics;
using System.IO;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for DataSourceSummary.xaml
    /// </summary>
    public partial class DataSourceSummary : UserControl
    {
        public DataSourceSummary()
        {
            InitializeComponent();
        }
        public DataSourceSummaryController Controller
        {
            get { return DataContext as DataSourceSummaryController; }
        }

        private void Entity_MouseMove(object sender, MouseEventArgs e)
        {
            var asFe = sender as FrameworkElement;
            if (asFe.IsMouseCaptureWithin && !IsPointInElement(e.GetPosition(asFe), asFe))
            {
                var ctrl = sender as FrameworkElement;
                if (ctrl != null)
                {
                    var ds = ctrl.DataContext as DataSource;
                    if (ds != null && (ds is EntitySource || ds is ChildEntitySource))
                    {
                        DataObject data = new DataObject(DataSourceController.DataSourcePropertyFormat, ds.Name);
                        Debug.WriteLine("Entity Drag & Drop");
                        this.RaiseEvent(new VLinqBeginDragDropEventArgs { RoutedEvent = QueryBagDesigner.VLinqBeginDragDropEvent, Data = data.GetData(DataSourceController.DataSourcePropertyFormat).ToString() });

                        DragDrop.DoDragDrop(ctrl, data, DragDropEffects.Copy);
                        this.RaiseEvent(new RoutedEventArgs(QueryBagDesigner.VLinqEndDragDropEvent));
                   
                    }
                }
            }
        }
        private bool IsPointInElement(Point p, FrameworkElement container)
        {
            if (p.X < 0 || p.Y < 0 || p.X > container.ActualWidth || p.Y > container.ActualHeight)
                return false;
            return true;
        }
        private static BitmapImage s_propertyImg;

        public BitmapImage PropertyImage
        {
            get
            {
                if (s_propertyImg == null)
                {
                    s_propertyImg = new BitmapImage();
                    s_propertyImg.BeginInit();

                    s_propertyImg.StreamSource = new MemoryStream(Properties.Resources._Properties);

                    s_propertyImg.EndInit();
                }
                return s_propertyImg;
            }
        }
        private void Property_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed
                && e.RightButton == MouseButtonState.Released
                && e.MiddleButton == MouseButtonState.Released)
            {
                FrameworkElement elem = sender as FrameworkElement;
                var propDesc = elem.DataContext as PropertyDescription;
                if (propDesc != null)
                {
                    string propName = propDesc.Name;
                    DependencyObject parent = VisualTreeHelper.GetParent(elem);
                    object oDataContext = parent.GetValue(FrameworkElement.DataContextProperty);
                    while (oDataContext == elem.DataContext)
                    {
                        parent = VisualTreeHelper.GetParent(parent);
                        oDataContext = parent.GetValue(FrameworkElement.DataContextProperty);
                    }
                    DataSource ds = oDataContext as DataSource;
                    if (ds != null && (ds is EntitySource || ds is ChildEntitySource))
                    {
                        Debug.WriteLine("Property Drag & Drop");
                        var data = string.Format("{0}|{1}", ds.Name, propName);
                        this.RaiseEvent(new VLinqBeginDragDropEventArgs { RoutedEvent = QueryBagDesigner.VLinqBeginDragDropEvent, Data = data });
                        DragDrop.DoDragDrop(elem, new DataObject(DataSourceController.DataSourcePropertyFormat, data), DragDropEffects.Copy);
                        this.RaiseEvent(new RoutedEventArgs(QueryBagDesigner.VLinqEndDragDropEvent));
                    }
                }
            }
        }
        private void propertyToOrder_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement elem = sender as FrameworkElement;
            var propDesc = elem.DataContext as PropertyDescription;
            if (propDesc != null)
            {
                string propName = propDesc.Name;
                var ctxMenu = elem.FindFirstVisualAncestorOf<ContextMenu>();

                DataSource ds = ctxMenu.PlacementTarget.FindFirstVisualAncestorOf<ItemsControl>().DataContext as DataSource;
                if (ds != null)
                {
                    Controller.Query.OrderBy.Add(new OrderEntry { DataSourceName = ds.Name, DataSourceProperty = propName });
                }
            }
        }

        private void propertyToGroupKey_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement elem = sender as FrameworkElement;
            var propDesc = elem.DataContext as PropertyDescription;
            if (propDesc != null)
            {
                string propName = propDesc.Name;
                var ctxMenu = elem.FindFirstVisualAncestorOf<ContextMenu>();

                DataSource ds = ctxMenu.PlacementTarget.FindFirstVisualAncestorOf<ItemsControl>().DataContext as DataSource;
                if (ds != null)
                {
                    var data = new DataObject(DataSourceController.DataSourcePropertyFormat, string.Format("{0}|{1}", ds.Name, propName));
                    var groupByController = (Controller.Query.GetValue(QueryBagDesignerController.AttachedQueryControllerProperty) as QueryDesignerController).GroupByController;

                    groupByController.AddKeyMember(data);
                }
            }
        }

        private void propertyToGroupValue_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement elem = sender as FrameworkElement;
            var propDesc = elem.DataContext as PropertyDescription;
            if (propDesc != null)
            {
                string propName = propDesc.Name;
                var ctxMenu = elem.FindFirstVisualAncestorOf<ContextMenu>();

                DataSource ds = ctxMenu.PlacementTarget.FindFirstVisualAncestorOf<ItemsControl>().DataContext as DataSource;
                if (ds != null)
                {
                    var data = new DataObject(DataSourceController.DataSourcePropertyFormat, string.Format("{0}|{1}", ds.Name, propName));
                    var groupByController = (Controller.Query.GetValue(QueryBagDesignerController.AttachedQueryControllerProperty) as QueryDesignerController).GroupByController;

                    groupByController.AddValueMember(data);
                }
            }
        }

        private void propertyToSubQuery_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement elem = sender as FrameworkElement;
            var propDesc = elem.DataContext as PropertyDescription;
            if (propDesc != null)
            {
                var ctxMenu = elem.FindFirstVisualAncestorOf<ContextMenu>();

                DataSource ds = ctxMenu.PlacementTarget.FindFirstVisualAncestorOf<ItemsControl>().DataContext as DataSource;
                if (ds != null)
                {
                    var entitySourceController = (Controller.Query.GetValue(QueryBagDesignerController.AttachedQueryControllerProperty) as QueryDesignerController).EntitySourceController;

                    var subQ = entitySourceController.CreateSubQuery();
                    var newDs = entitySourceController.CreateChildEntitySourceWithoutInsertingIt(ds, propDesc);
                    subQ.Query.DataSources.Add(newDs);
                    subQ.Query.Select = new DirectProjection { Operand = new DataSourceOperand { DataSourceName = newDs.Name } };
                }
            }
        }
    }

    
}
