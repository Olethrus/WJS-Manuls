﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.ComponentModel;
using System.Windows.Data;
using VLinq.Processing;
using System.Windows.Markup;
using System.IO;

namespace VLinq.Editor
{
    public class DataSourceSummaryController : DependencyObject
    {
        public DataSourceSummaryController()
        {
            if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))
            {
                DesignTimeQueries = (XamlReader.Load(new MemoryStream(Properties.Resources.SampleQueries)) as QueryBag).Queries;
                DesignTimeQueryIndex = 0;
            }
        }

        public VLinqComponentCollection<Query> DesignTimeQueries { get; set; }

        private int m_designTimeQueryIndex = -1;
        public int DesignTimeQueryIndex
        {
            get { return m_designTimeQueryIndex; }
            set
            {

                if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this) && m_designTimeQueryIndex != value)
                {
                    m_designTimeQueryIndex = value;
                    if (value < 0 || value >= DesignTimeQueries.Count)
                        Query = null;
                    else
                        Query = DesignTimeQueries[value];
                }
            }
        }


        public ICollectionView Entities
        {
            get { return (ICollectionView)GetValue(EntitiesProperty); }
            set { SetValue(EntitiesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Entities.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EntitiesProperty =
            DependencyProperty.Register("Entities", typeof(ICollectionView), typeof(DataSourceSummaryController), new UIPropertyMetadata(null));



        public ICollectionView NestedQueries
        {
            get { return (ICollectionView)GetValue(NestedQueriesProperty); }
            set { SetValue(NestedQueriesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for NestedQueries.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NestedQueriesProperty =
            DependencyProperty.Register("NestedQueries", typeof(ICollectionView), typeof(DataSourceSummaryController), new UIPropertyMetadata(null));



        public ICollectionView QueryParameters
        {
            get { return (ICollectionView)GetValue(QueryParametersProperty); }
            set { SetValue(QueryParametersProperty, value); }
        }

        // Using a DependencyProperty as the backing store for QueryParameters.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryParametersProperty =
            DependencyProperty.Register("QueryParameters", typeof(ICollectionView), typeof(DataSourceSummaryController), new UIPropertyMetadata(null));





        public FakeDataSource GroupByResult
        {
            get { return (FakeDataSource)GetValue(GroupByResultProperty); }
            set { SetValue(GroupByResultProperty, value); }
        }

        // Using a DependencyProperty as the backing store for GroupByResult.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GroupByResultProperty =
            DependencyProperty.Register("GroupByResult", typeof(FakeDataSource), typeof(DataSourceSummaryController), new UIPropertyMetadata(null));




        public bool IsGrouping
        {
            get { return (bool)GetValue(IsGroupingProperty); }
            set { SetValue(IsGroupingProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsGrouping.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsGroupingProperty =
            DependencyProperty.Register("IsGrouping", typeof(bool), typeof(DataSourceSummaryController), new UIPropertyMetadata(false));




        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(DataSourceSummaryController), new UIPropertyMetadata(null, OnQueryChanged));

        private static void OnQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            DataSourceSummaryController elem = obj as DataSourceSummaryController;
            if (elem != null)
            {
                elem.OnQueryChanged(args.OldValue == null ? default(Query) : (Query)args.OldValue, args.NewValue == null ? default(Query) : (Query)args.NewValue);
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
            if (oldValue != null)
                oldValue.Changed -= Query_Changed;
            if (newValue == null)
            {
                this.Entities = null;
                this.GroupByResult = null;
                this.IsGrouping = false;
                this.NestedQueries = null;
                this.QueryParameters = null;
                
            }
            else
            {
                var entitiesSource = new CollectionViewSource{Source = Query.DataSources}.View;
                entitiesSource.Filter = o => o is EntitySource || o is ChildEntitySource;
                
                this.Entities = entitiesSource;

                if (Query.GroupBy == null)
                {
                    this.GroupByResult = null;
                    this.IsGrouping = false;
                }
                else
                {
                    this.IsGrouping = true;
                    this.GroupByResult = new FakeDataSource { Name = Query.GroupBy.GroupName };
                    ValidTimeProperties.SetReturnType(this.GroupByResult, ValidTimeProperties.GetReturnType(Query.GroupBy));
                }
                
                var nestedSource = new CollectionViewSource { Source = Query.DataSources }.View;
                nestedSource.Filter = o => o is ChildQueryResultSource;
                this.NestedQueries = nestedSource;

                 var paramSource = new CollectionViewSource { Source = Query.DataSources }.View;
                 paramSource.Filter = o => o is ParameterSource;
                this.QueryParameters = paramSource;

                Query.Changed += Query_Changed;
            }
        }

        void Query_Changed(object sender, NotifyChangedEventArgs e)
        {
            if (e.ChangedStack.Peek().ChangedProperty == Query.GroupByProperty)
            {
                if (Query.GroupBy == null)
                {
                    this.GroupByResult = null;
                    this.IsGrouping = false;
                }
                else
                {
                    this.IsGrouping = true;
                    this.GroupByResult = new FakeDataSource { Name = Query.GroupBy.GroupName };
                    ValidTimeProperties.SetReturnType(this.GroupByResult, ValidTimeProperties.GetReturnType(Query.GroupBy));
                }
            }
        }



    }
}
