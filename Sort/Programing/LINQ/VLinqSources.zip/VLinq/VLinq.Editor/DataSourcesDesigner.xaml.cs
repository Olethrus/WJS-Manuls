﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.Processing;
using System.Diagnostics;
using VLinq.WPFControls;
using System.IO;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for DataSourcesDesigner.xaml
    /// </summary>
    public partial class DataSourcesDesigner : UserControl
    {
        public DataSourceController Controller
        {
            get { return DataContext as DataSourceController; }
        }
        public DataSourcesDesigner()
        {
            NewParameter = new CustomCommand();
            NewSubQuery = new CustomCommand();
            DeleteSelectedSources = new CustomCommand();
            InitializeComponent();

            
            

            NewParameter.Executing += new EventHandler(NewParameter_Executing);
            NewSubQuery.Executing += new EventHandler(NewSubQuery_Executing);
            DeleteSelectedSources.Executing += new EventHandler(DeleteSelectedSources_Executing);

            DeleteSelectedSources.IsEnabled = lstSources.SelectedItems.Count > 0;
            lstSources.SelectionChanged += delegate
            {
                DeleteSelectedSources.IsEnabled = lstSources.SelectedItems.Count > 0;
            };

            this.DataContextChanged += new DependencyPropertyChangedEventHandler(DataSourcesDesigner_DataContextChanged);
        }

        

        void DataSourcesDesigner_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (Controller != null)
            {
                NewParameter.IsEnabled = Controller.ShowNewParameterButton;
                NewSubQuery.IsEnabled = Controller.ShowNewChildQueryButton;
            }
        }

        



      


       


        
        protected override void OnDragEnter(DragEventArgs e)        
        {
            var ctrl = Controller;
            bool valid = false;
            if (ctrl != null)
                valid = ctrl.IsClipboardValid(new System.Windows.Forms.DataObject(e.Data));
            e.Effects = valid ? DragDropEffects.Copy : DragDropEffects.None;
            e.Handled = true;

        
        }
        
        protected override void OnDragOver(DragEventArgs e)
        {
            var ctrl = Controller;
            bool valid = false;
            if (ctrl != null)
                valid = ctrl.IsClipboardValid(new System.Windows.Forms.DataObject(e.Data));
            e.Effects = valid ? DragDropEffects.Copy : DragDropEffects.None;
            e.Handled = true;
        }
        private void OnDeleteDataSourceClick(object sender, RoutedEventArgs args)
        {
            if (MessageBox.Show(Messages.ConfirmDeleteDataSource, Messages.ConfirmDeleteDataSourceCaption, MessageBoxButton.OKCancel, MessageBoxImage.Question, MessageBoxResult.Cancel) == MessageBoxResult.OK)
            {

                var elem = sender as FrameworkElement;
                if (elem != null)
                {
                    var ds = elem.DataContext as DataSource;
                    if (ds != null)
                        Controller.DeleteDataSource(ds);
                }
            }
        }
        
        /// <summary>
        /// Handles initialization of Drag and drop operation from an existing DataSource property
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Property_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed 
                && e.RightButton == MouseButtonState.Released 
                && e.MiddleButton == MouseButtonState.Released
                && Controller!=null
                && Controller.Mode == DataSourceControllerMode.Entities)
            {
                FrameworkElement elem = sender as FrameworkElement;
                var propDesc = elem.DataContext as PropertyDescription;
                if (propDesc != null)
                {
                    string propName = propDesc.Name;
                    DependencyObject parent = VisualTreeHelper.GetParent(elem);
                    object oDataContext = parent.GetValue(FrameworkElement.DataContextProperty);
                    while (oDataContext == elem.DataContext)
                    {
                        parent = VisualTreeHelper.GetParent(parent);
                        oDataContext = parent.GetValue(FrameworkElement.DataContextProperty);
                    }
                    DataSource ds = oDataContext as DataSource;
                    if (ds != null)
                    {
                        Debug.WriteLine("Property Drag & Drop");
                        var data = string.Format("{0}|{1}", ds.Name, propName);
                        this.RaiseEvent(new VLinqBeginDragDropEventArgs{RoutedEvent = QueryBagDesigner.VLinqBeginDragDropEvent, Data =data});
                        DragDrop.DoDragDrop(elem, new DataObject(DataSourceController.DataSourcePropertyFormat, data), DragDropEffects.Copy);
                        this.RaiseEvent(new RoutedEventArgs(QueryBagDesigner.VLinqEndDragDropEvent));
                    }
                }
            }
        }

        protected override void OnDrop(DragEventArgs e)
        {
             var ctrl = Controller;
             if (ctrl != null)
                 ctrl.CreateFromClipboard(new System.Windows.Forms.DataObject(e.Data));
        }


        /// <summary>
        /// attach the instanciated template as the editor of the current DataSource (for validation resume)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataSourceTemplate_Loaded(object sender, RoutedEventArgs e)
        {
            var fe = sender as FrameworkElement;
            if (fe != null)
            {
                var data = fe.DataContext as DependencyObject;
                if (data != null)
                    DesignTimeProperties.SetEditorFor(data, fe);
            }
        }

        public CustomCommand DeleteSelectedSources { get; private set; }
        public CustomCommand NewParameter { get; private set; }
        public CustomCommand NewSubQuery { get; private set; }

        void NewSubQuery_Executing(object sender, EventArgs e)
        {
             Controller.CreateSubQuery();
        }

        void NewParameter_Executing(object sender, EventArgs e)
        {
            var createParam = new CreateParameterDialog(Controller.ParentController.Validator.TypeDescriptionBuilder);
            var dlgResult = createParam.ShowDialog();
            if(dlgResult.HasValue && dlgResult.Value && createParam.ParameterSource != null)
            {
                Controller.InsertNewParameter(createParam.ParameterSource);
            }
        }

        void DeleteSelectedSources_Executing(object sender, EventArgs e)
        {
            if (MessageBox.Show(Messages.ConfirmDeleteDataSource, Messages.ConfirmDeleteDataSourceCaption, MessageBoxButton.OKCancel, MessageBoxImage.Question, MessageBoxResult.Cancel) == MessageBoxResult.OK)
            {

                var toDelete = lstSources.SelectedItems.Cast<DataSource>().ToArray();
                foreach (var ds in toDelete)
                {
                    Controller.DeleteDataSource(ds);
                }
            }
        }
        ///// <summary>
        ///// Call the CreateParameterDialog
        ///// </summary>
        ///// <param name="sender"></param>
        ///// <param name="e"></param>
        //private void newParamClicked(object sender, System.Windows.RoutedEventArgs e)
        //{
        //    CreateParameterDialog.Show(Controller.ParentController.Validator.TypeDescriptionBuilder, delegate(ParameterSource paramSource)
        //    {
        //        if(paramSource!=null)
        //            Controller.InsertNewParameter(paramSource);
        //    });
                
            
            
        //}

        //private void newSubQueryClick(object sender, RoutedEventArgs e)
        //{
        //    Controller.CreateSubQuery();
        //}

        //private void editChildQueryClick(object sender, RoutedEventArgs e)
        //{
        //    if (this.Controller.ParentController.Query.ParentQuery != null)
        //    {
        //        var designer = this.FindFirstVisualAncestorOf<SubQueryDesignerForFullScreen>();
        //        designer.EditSubQuery((sender as FrameworkElement).DataContext as ChildQueryResultSource);
        //    }
        //    else
        //    {
        //        var designer = this.FindFirstVisualAncestorOf<QueryDesigner>();
        //        designer.EditSubQuery((sender as FrameworkElement).DataContext as ChildQueryResultSource);
        //    }
        //}


      

        private void Entity_MouseMove(object sender, MouseEventArgs e)
        {
            var asFe = sender as FrameworkElement;
            if(asFe.IsMouseCaptureWithin && !IsPointInElement(e.GetPosition(asFe),asFe))
            {
                var ctrl = sender as FrameworkElement;
                if (ctrl != null)
                {
                    var ds = ctrl.DataContext as DataSource;
                    if (ds != null)
                    {
                        DataObject data = new DataObject(DataSourceController.DataSourcePropertyFormat, ds.Name);
                        Debug.WriteLine("Entity Drag & Drop");
                        this.RaiseEvent(new VLinqBeginDragDropEventArgs { RoutedEvent = QueryBagDesigner.VLinqBeginDragDropEvent, Data = data.GetData(DataSourceController.DataSourcePropertyFormat).ToString() });
                        
                        DragDrop.DoDragDrop(ctrl, data, DragDropEffects.Copy);
                        this.RaiseEvent(new RoutedEventArgs(QueryBagDesigner.VLinqEndDragDropEvent));
                    }
                }
            }
        }

        private bool IsPointInElement(Point p, FrameworkElement container)
        {
            if (p.X < 0 || p.Y < 0 || p.X > container.ActualWidth || p.Y > container.ActualHeight)
                return false;
            return true;
        }



        private void sqd_Loaded(object sender, RoutedEventArgs args)
        {
            var asSQD = sender as SubQueryDesigner;
            if (asSQD != null)
            {
                var query = (asSQD.FindFirstVisualAncestorOf<FrameworkElement>().DataContext as ChildQueryResultSource).Query;
                asSQD.DataContext = new QueryDesignerController(query, Controller.ParentController.ParentController, new QueryValidator(query, Controller.ParentController.Validator.TypeDescriptionBuilder, QueryValidatorOptions.ChildQueryMode));
            }
        }

        private void entityToGroupKey_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement asFe = sender as FrameworkElement;
            var ds = asFe.DataContext as DataSource;
            if (ds != null)
            {
                DataObject data = new DataObject(DataSourceController.DataSourcePropertyFormat, ds.Name);

                Controller.ParentController.GroupByController.AddKeyMember(data);
            }
        }


        private void entityToGroupValue_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement asFe = sender as FrameworkElement;
            var ds = asFe.DataContext as DataSource;
            if (ds != null)
            {
                DataObject data = new DataObject(DataSourceController.DataSourcePropertyFormat, ds.Name);

                Controller.ParentController.GroupByController.AddValueMember(data);
            }
        }

        private void propertyToOrder_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement elem = sender as FrameworkElement;
            var propDesc = elem.DataContext as PropertyDescription;
            if (propDesc != null)
            {
                string propName = propDesc.Name;
                var ctxMenu = elem.FindFirstVisualAncestorOf<ContextMenu>();

                DataSource ds = ctxMenu.PlacementTarget.FindFirstVisualAncestorOf<ItemsControl>().DataContext as DataSource;
                if (ds != null)
                {
                    Controller.ParentController.Query.OrderBy.Add(new OrderEntry { DataSourceName = ds.Name, DataSourceProperty = propName });
                }
            }
        }

        private void propertyToGroupKey_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement elem = sender as FrameworkElement;
            var propDesc = elem.DataContext as PropertyDescription;
            if (propDesc != null)
            {
                string propName = propDesc.Name;
                var ctxMenu = elem.FindFirstVisualAncestorOf<ContextMenu>();

                DataSource ds = ctxMenu.PlacementTarget.FindFirstVisualAncestorOf<ItemsControl>().DataContext as DataSource;
                if (ds != null)
                {
                    var data = new DataObject(DataSourceController.DataSourcePropertyFormat, string.Format("{0}|{1}", ds.Name, propName));
                    Controller.ParentController.GroupByController.AddKeyMember(data);
                }
            }
        }

        private void propertyToGroupValue_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement elem = sender as FrameworkElement;
            var propDesc = elem.DataContext as PropertyDescription;
            if (propDesc != null)
            {
                string propName = propDesc.Name;
                var ctxMenu = elem.FindFirstVisualAncestorOf<ContextMenu>();

                DataSource ds = ctxMenu.PlacementTarget.FindFirstVisualAncestorOf<ItemsControl>().DataContext as DataSource;
                if (ds != null)
                {
                    var data = new DataObject(DataSourceController.DataSourcePropertyFormat, string.Format("{0}|{1}", ds.Name, propName));
                    Controller.ParentController.GroupByController.AddValueMember(data);
                }
            }
        }

        private void propertyToSubQuery_Clicked(object sender, RoutedEventArgs e)
        {
            FrameworkElement elem = sender as FrameworkElement;
            var propDesc = elem.DataContext as PropertyDescription;
            if (propDesc != null)
            {
                var ctxMenu = elem.FindFirstVisualAncestorOf<ContextMenu>();

                DataSource ds = ctxMenu.PlacementTarget.FindFirstVisualAncestorOf<ItemsControl>().DataContext as DataSource;
                if (ds != null)
                {
                    var subQ = Controller.CreateSubQuery();
                    var newDs = Controller.CreateChildEntitySourceWithoutInsertingIt(ds, propDesc);
                    subQ.Query.DataSources.Add(newDs);
                    subQ.Query.Select = new DirectProjection{Operand = new DataSourceOperand{DataSourceName=newDs.Name}};
                }
            }
        }

        private void newEntity_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new CreateEntitySourceDialog();
            dlg.ShowDialog();
            if (dlg.Ok)
            {
                Controller.InsertNewEntitySource(dlg.DataContext as EntitySource);
            }
        }
        private static BitmapImage s_propertyImg;

        public BitmapImage PropertyImage
        {
            get
            {
                if (s_propertyImg == null)
                {
                    s_propertyImg = new BitmapImage();
                    s_propertyImg.BeginInit();

                    s_propertyImg.StreamSource = new MemoryStream(Properties.Resources._Properties);

                    s_propertyImg.EndInit();
                }
                return s_propertyImg;
            }
        }

        private void txtName_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var item = (sender as DependencyObject).FindFirstVisualAncestorOf<ListBoxItem>();
            if (item != null)
            {
                item.RaiseEvent(new MouseButtonEventArgs(e.MouseDevice, e.Timestamp, e.ChangedButton) { RoutedEvent = ListBoxItem.MouseLeftButtonDownEvent });
            }
        }

        private void entityJoin_Clicked(object sender, RoutedEventArgs e)
        {
            var selected = lstSources.SelectedItems.OfType<EntitySource>().ToArray();
            if (selected.Length != 2)
            {
                MessageBox.Show(Messages.PleaseSelect2EntitySourceToJoin);
            }
            else
            {
                Controller.CreateJoinFromTwoEntitySources(selected[0], selected[1]);
            }
        }

       
       

        

       


    }
    /// <summary>
    /// Class associating a ViewMode with a label
    /// </summary>
    public class DataSourceViewModeWithLabel
    {
        public string Label { get; set; }
        public DataSourceViewMode ViewMode { get; set; }

        public override string ToString()
        {
            return Label;
        }
    }
}
