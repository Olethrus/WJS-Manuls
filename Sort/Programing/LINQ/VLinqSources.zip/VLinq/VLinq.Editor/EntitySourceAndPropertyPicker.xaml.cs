﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.WPFControls;
using VLinq.Processing;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for EntitySourceAndPropertyPicker.xaml
    /// </summary>
    public partial class EntitySourceAndPropertyPicker : UserControl
    {
        private EntitySourceAndPropertyResolver m_resolver;
        public EntitySourceAndPropertyPicker()
        {
            m_resolver = new EntitySourceAndPropertyResolver();
            InitializeComponent();
            suggestBox.TextChanged += new DependencyPropertyChangedEventHandler(suggestBox_TextChanged);
            suggestBox.Resolver = m_resolver;
        }

        void suggestBox_TextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (skipNextSourceBinding)
                skipNextSourceBinding = false;
            else
            {
                var parts = suggestBox.Text.Split('.');
                if (parts.Length > 0)
                    DataSourceName = parts[0];
                else
                {
                    DataSourceName = string.Empty;
                }
                if (parts.Length > 1)
                {
                    DataSourceProperty = parts[1];
                }
                else
                {
                    DataSourceProperty = string.Empty;
                }
            }
        }


        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(EntitySourceAndPropertyPicker), new UIPropertyMetadata(null, OnQueryChanged));

        private static void OnQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            EntitySourceAndPropertyPicker elem = obj as EntitySourceAndPropertyPicker;
            if (elem != null)
            {
                elem.OnQueryChanged(args.OldValue == null ? default(Query) : (Query)args.OldValue, args.NewValue == null ? default(Query) : (Query)args.NewValue);
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
            m_resolver.Query = newValue;
        }



        public string DataSourceName
        {
            get { return (string)GetValue(DataSourceNameProperty); }
            set { SetValue(DataSourceNameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DataSourceName.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourceNameProperty =
            DependencyProperty.Register("DataSourceName", typeof(string), typeof(EntitySourceAndPropertyPicker), new UIPropertyMetadata(string.Empty, OnDataSourceNameChanged));

        private static void OnDataSourceNameChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            EntitySourceAndPropertyPicker elem = obj as EntitySourceAndPropertyPicker;
            if (elem != null)
            {
                elem.OnDataSourceNameChanged(args.OldValue == null ? default(string) : (string)args.OldValue, args.NewValue == null ? default(string) : (string)args.NewValue);
            }
        }
        protected virtual void OnDataSourceNameChanged(string oldValue, string newValue)
        {
            if (!suggestBox.IsKeyboardFocusWithin)
            {
                ResetText();
            }
        }



        public string DataSourceProperty
        {
            get { return (string)GetValue(DataSourcePropertyProperty); }
            set { SetValue(DataSourcePropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DataSourceProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourcePropertyProperty =
            DependencyProperty.Register("DataSourceProperty", typeof(string), typeof(EntitySourceAndPropertyPicker), new UIPropertyMetadata(string.Empty, OnDataSourcePropertyChanged));

        private static void OnDataSourcePropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            EntitySourceAndPropertyPicker elem = obj as EntitySourceAndPropertyPicker;
            if (elem != null)
            {
                elem.OnDataSourcePropertyChanged(args.OldValue == null ? default(string) : (string)args.OldValue, args.NewValue == null ? default(string) : (string)args.NewValue);
            }
        }
        protected virtual void OnDataSourcePropertyChanged(string oldValue, string newValue)
        {
            if (!suggestBox.IsKeyboardFocusWithin)
            {
                ResetText();
            }
        }

        private bool skipNextSourceBinding = false;

        private void ResetText()
        {
            var newText = string.IsNullOrEmpty(DataSourceProperty) ? DataSourceName : DataSourceName + "." + DataSourceProperty;
            if (suggestBox.Text != newText)
            {
                skipNextSourceBinding = true;
                suggestBox.Text = newText;
            }
        }

    }

    public class EntitySourceAndPropertyResolver : SuggestionResolverBase
    {
        private Query m_query;

        public Query Query
        {
            get
            {
                return m_query;

            }
            set
            {
                if (m_query != value)
                {
                    m_query = value;
                    if (SuggestBox.ShowingSuggestions)
                        ResetSuggestions();
                }
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
            if (SuggestBox.ShowingSuggestions)
                ResetSuggestions();
        }


        protected override void OnSuggestBoxSet()
        {
        }

        protected override void OnSuggestionsRequested()
        {
            ResetSuggestions();
        }

        protected override void OnSuggestionContextChanged()
        {
            ResetSuggestions();
        }

        protected override void OnCaretIndexChanged()
        {
        }

        protected override void OnTextChanged(object e)
        {
        }

        private void ResetSuggestions()
        {
            var ctx = SuggestionContext;
            Suggestions.Clear();
            if (Query != null)
            {
                if (ctx.Length == 0)
                {
                    var q = from ds in Query.DataSources
                            where ds is EntitySource || ds is ChildEntitySource
                            select new Suggestion { Label = ds.Name, GeneratedText = ds.Name, CaretPosition = ds.Name.Length + 1, IconSource = VLinq.Editor.Properties.Resources._class };
                    foreach (var s in q)
                        Suggestions.Add(s);
                }
                else
                {
                    var ds = Query.FindDataSource(ctx);
                    if (ds != null && (ds is EntitySource || ds is ChildEntitySource))
                    {
                        var retType = ValidTimeProperties.GetReturnType(ds);
                        if (retType != null)
                        {
                            var q = from prop in retType.Properties
                                    select new Suggestion { Label = prop.Name, GeneratedText = ctx + "." + prop.Name, CaretPosition = ctx.Length + prop.Name.Length + 2, IconSource = VLinq.Editor.Properties.Resources._class };
                            foreach (var s in q)
                                Suggestions.Add(s);
                        }
                    }
                }
            }
        }
    }
}
