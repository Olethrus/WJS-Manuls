﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VLinq.Processing;

namespace VLinq.Editor
{
    public class FakeDataSource : DataSource
    {


        public override IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }
        
    }
}
