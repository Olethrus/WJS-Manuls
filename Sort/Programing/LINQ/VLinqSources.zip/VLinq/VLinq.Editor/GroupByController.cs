﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    public class GroupByController : DependencyObject
    {


        public QueryDesignerController ParentController
        {
            get { return (QueryDesignerController)GetValue(ParentControllerProperty); }
            set { SetValue(ParentControllerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ParentController.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParentControllerProperty =
            DependencyProperty.Register("ParentController", typeof(QueryDesignerController), typeof(GroupByController), new UIPropertyMetadata(null, OnParentControllerChanged));

        private static void OnParentControllerChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            GroupByController elem = obj as GroupByController;
            if (elem != null)
            {
                elem.OnParentControllerChanged(args.OldValue == null ? default(QueryDesignerController) : (QueryDesignerController)args.OldValue, args.NewValue == null ? default(QueryDesignerController) : (QueryDesignerController)args.NewValue);
            }
        }
        protected virtual void OnParentControllerChanged(QueryDesignerController oldValue, QueryDesignerController newValue)
        {
        }



        public Group Group
        {
            get { return (Group)GetValue(GroupProperty); }
            set { SetValue(GroupProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Group.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GroupProperty =
            DependencyProperty.Register("Group", typeof(Group), typeof(GroupByController), new UIPropertyMetadata(null, OnGroupChanged));

        private static void OnGroupChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            GroupByController elem = obj as GroupByController;
            if (elem != null)
            {
                elem.OnGroupChanged(args.OldValue == null ? default(Group) : (Group)args.OldValue, args.NewValue == null ? default(Group) : (Group)args.NewValue);
            }
        }
        protected virtual void OnGroupChanged(Group oldValue, Group newValue)
        {
        }


        


        public GroupByController(QueryDesignerController parentController)
        {
            ParentController = parentController;
            if (ParentController != null && ParentController.Query != null && ParentController.Query.GroupBy != null)
            {
                Group = ParentController.Query.GroupBy;
            }
            else
            {
                Group = new Group { GroupName = "gp", Key = new SimpleGroupPart(), Value = new SimpleGroupPart() };
            }
            Group.Changed += new EventHandler<NotifyChangedEventArgs>(Group_Changed);
            Clear = new CustomCommand();
            Clear.Executing += new EventHandler(ClearCommand_Executing);

            DeleteMemberCommand = new CustomParameterizedCommand<object>();
            DeleteMemberCommand.IsEnabled = true;
            DeleteMemberCommand.Executing += new EventHandler<ParameterizedCommandEventArgs<object>>(DeleteMemberCommand_Executing);

           
        }

     
        void Group_Changed(object sender, NotifyChangedEventArgs e)
        {
            if (ParentController.Query.GroupBy != Group && !IsGroupEmpty)
                ParentController.Query.GroupBy = Group;
            else if(IsGroupEmpty)
                ParentController.Query.GroupBy = null;
        }

        public bool IsGroupEmpty
        {
            get
            {
                bool keyNull = false;
                bool valueNull = false;
                if (Group.Key == null)
                    keyNull = true;
                else
                {
                    var keyAsSimple = Group.Key as SimpleGroupPart;
                    if (keyAsSimple != null && keyAsSimple.EntityRef == null)
                        keyNull = true;
                }

                if (Group.Value == null)
                    valueNull = true;
                else
                {
                    var valueAsSimple = Group.Value as SimpleGroupPart;
                    if (valueAsSimple != null && valueAsSimple.EntityRef == null)
                        valueNull = true;
                }
                
                return keyNull && valueNull;
                
            }
        }

        public CustomCommand Clear { get; private set; }
        void ClearCommand_Executing(object sender, EventArgs e)
        {
            Group.Key = new SimpleGroupPart();
            Group.Value = new SimpleGroupPart();
        }

        public CustomParameterizedCommand<object> DeleteMemberCommand { get; private set; }

        void DeleteMemberCommand_Executing(object sender, ParameterizedCommandEventArgs<object> e)
        {
            var asNotifyChanged = e.Parameter as IVLinqComponent;
            GroupPart groupPart = null;
            while (asNotifyChanged != null && !(asNotifyChanged is GroupPart))
                asNotifyChanged = asNotifyChanged.GetOwner();

            groupPart = asNotifyChanged as GroupPart;
            if (groupPart != null)
            {

                var asSimple = groupPart as SimpleGroupPart;
                if (asSimple != null)
                {
                    if (asSimple.EntityRef == e.Parameter)
                    {
                        asSimple.EntityRef = null;
                    }
                }
                else
                {
                    var asComposed = groupPart as ComposedGroupPart;
                    if (asComposed != null)
                    {
                        var paramAsRef = e.Parameter as EntityRef;
                        if (asComposed.EntityRefs.Contains(paramAsRef))
                        {
                            if (asComposed.EntityRefs.Count > 2)
                            {
                                asComposed.EntityRefs.Remove(paramAsRef);
                            }
                            else if (asComposed.EntityRefs.Count == 1)
                            {
                                if (Group.Key == groupPart)
                                {
                                    Group.Key = new SimpleGroupPart();
                                }
                                else
                                {
                                    Group.Value = new SimpleGroupPart();
                                }
                            }
                            else
                            {
                                asComposed.EntityRefs.Remove(paramAsRef);
                                if (Group.Key == groupPart)
                                {

                                    Group.Key = new SimpleGroupPart { EntityRef = asComposed.EntityRefs.First().Operand };
                                }
                                else
                                {
                                    Group.Value = new SimpleGroupPart { EntityRef = asComposed.EntityRefs.First().Operand };
                                }
                            }
                        }
                    }
                }
            }
        }

        public bool IsValidForKey(IDataObject dataObject)
        {
            if (!dataObject.GetDataPresent(DataSourceController.DataSourcePropertyFormat))
                return false;
            var data = dataObject.GetData(DataSourceController.DataSourcePropertyFormat).ToString();
            var parts = data.Split('|');
            var valid= parts.Length < 3 && parts.Length > 0;
            if (!valid)
                return false;

            List<string> presentData = new List<string>();
            var asSimple = Group.Key as SimpleGroupPart;
            if (asSimple != null)
            {
                var operand = asSimple.EntityRef as DataSourceOperand;
                if (operand != null)
                {
                    presentData.Add(operand.DataSourceProperty == null ? operand.DataSourceName : string.Format("{0}|{1}", operand.DataSourceName, operand.DataSourceProperty));

                }
            }
            else
            {
                var asComposed = Group.Key as ComposedGroupPart;
                if (asComposed != null)
                {
                    foreach (var eref in asComposed.EntityRefs)
                    {
                        var operand = eref.Operand as DataSourceOperand;
                        if (operand != null)
                        {
                            presentData.Add(operand.DataSourceProperty == null ? operand.DataSourceName : string.Format("{0}|{1}", operand.DataSourceName, operand.DataSourceProperty));

                        }
                    }
                }
            }
            return !presentData.Contains(data);
        }

        public bool IsValidForValue(IDataObject dataObject)
        {
            if (!dataObject.GetDataPresent(DataSourceController.DataSourcePropertyFormat))
                return false;
            var data = dataObject.GetData(DataSourceController.DataSourcePropertyFormat).ToString();
            var parts = data.Split('|');
            var valid = parts.Length < 3 && parts.Length > 0;
            if (!valid)
                return false;

            List<string> presentData = new List<string>();
            var asSimple = Group.Value as SimpleGroupPart;
            if (asSimple != null)
            {
                var operand = asSimple.EntityRef as DataSourceOperand;
                if (operand != null)
                {
                    presentData.Add(operand.DataSourceProperty == null ? operand.DataSourceName : string.Format("{0}|{1}", operand.DataSourceName, operand.DataSourceProperty));

                }
            }
            else
            {
                var asComposed = Group.Value as ComposedGroupPart;
                if (asComposed != null)
                {
                    foreach (var eref in asComposed.EntityRefs)
                    {
                        var operand = eref.Operand as DataSourceOperand;
                        if (operand != null)
                        {
                            presentData.Add(operand.DataSourceProperty == null ? operand.DataSourceName : string.Format("{0}|{1}", operand.DataSourceName, operand.DataSourceProperty));

                        }
                    }
                }
            }
            return !presentData.Contains(data);
        }

        public string EnsureName(string name, ComposedGroupPart groupPart)
        {
            List<string> invalidNames = new List<string>();
            foreach (var eref in groupPart.EntityRefs)
                invalidNames.Add(eref.Name);
            var baseName = name;
            var counter = 0;
            while (invalidNames.Contains(name))
            {
                name = baseName + (++counter).ToString();
            }
            return name;
        }

        public void AddKeyMember(IDataObject dataObject)
        {
            if (IsValidForKey(dataObject))
            {
                var dataParts = dataObject.GetData(DataSourceController.DataSourcePropertyFormat).ToString().Split('|');
                if (Group.Key == null)
                    Group.Key = new SimpleGroupPart();
                var asSimple = Group.Key as SimpleGroupPart;
                if (asSimple != null)
                {
                    var dso = asSimple.EntityRef as DataSourceOperand;
                    if (dso == null)
                    {
                        if (dataParts.Length == 1)
                        {
                            asSimple.EntityRef = new DataSourceOperand { DataSourceName = dataParts[0] };
                        }
                        else if (dataParts.Length == 2)
                        {
                            asSimple.EntityRef = new DataSourceOperand { DataSourceName = dataParts[0], DataSourceProperty = dataParts[1] };
                            if(Group.Value == null ||
                                (Group.Value is SimpleGroupPart && (Group.Value as SimpleGroupPart).EntityRef == null))
                            {
                                AddValueMember(new DataObject(DataSourceController.DataSourcePropertyFormat,dataParts[0]));
                            }
                        }
                    }
                    else
                    {
                        ComposedGroupPart newPart = new ComposedGroupPart();
                        newPart.EntityRefs.Add(new EntityRef{Operand=dso, Name=dso.DataSourceProperty == null? dso.DataSourceName:dso.DataSourceProperty.Split('.').Last()});
                        var newDso = new DataSourceOperand { DataSourceName = dataParts[0] };
                        if (dataParts.Length == 2)
                            newDso.DataSourceProperty = dataParts[1];
                        newPart.EntityRefs.Add(new EntityRef { Operand = newDso, Name = EnsureName(newDso.DataSourceProperty == null ? newDso.DataSourceName : newDso.DataSourceProperty.Split('.').Last(),newPart) });
                        Group.Key = newPart;
                    }
                }
                else
                {
                    var asComposed = Group.Key as ComposedGroupPart;
                    if (asComposed != null)
                    {
                        var name = dataParts.Length == 1 ? dataParts[0] : dataParts[1].Split('.').Last();
                        var newDso = new DataSourceOperand { DataSourceName = dataParts[0] };
                        if (dataParts.Length == 2)
                            newDso.DataSourceProperty = dataParts[1];
                        asComposed.EntityRefs.Add(new EntityRef { Operand = newDso, Name = EnsureName(name, asComposed) });
                    }
                    
                }
            }
        }

        public void AddValueMember(IDataObject dataObject)
        {
            if (IsValidForValue(dataObject))
            {
                var dataParts = dataObject.GetData(DataSourceController.DataSourcePropertyFormat).ToString().Split('|');
                if (Group.Value == null)
                {
                    Group.Value = new SimpleGroupPart();
                }
                var asSimple = Group.Value as SimpleGroupPart;
                if (asSimple != null)
                {
                    var dso = asSimple.EntityRef as DataSourceOperand;
                    if (dso == null)
                    {
                        if (dataParts.Length == 1)
                        {
                            asSimple.EntityRef = new DataSourceOperand { DataSourceName = dataParts[0] };
                        }
                        else if (dataParts.Length == 2)
                        {
                            asSimple.EntityRef = new DataSourceOperand { DataSourceName = dataParts[0], DataSourceProperty = dataParts[1] };
                        }
                    }
                    else
                    {
                        ComposedGroupPart newPart = new ComposedGroupPart();
                        newPart.EntityRefs.Add(new EntityRef { Operand = dso, Name = dso.DataSourceProperty == null ? dso.DataSourceName : dso.DataSourceProperty.Split('.').Last() });
                        var newDso = new DataSourceOperand { DataSourceName = dataParts[0] };
                        if (dataParts.Length == 2)
                            newDso.DataSourceProperty = dataParts[1];
                        newPart.EntityRefs.Add(new EntityRef { Operand = newDso, Name = EnsureName(newDso.DataSourceProperty == null ? newDso.DataSourceName : newDso.DataSourceProperty.Split('.').Last(), newPart) });
                        Group.Value = newPart;
                    }
                }
                else
                {
                    var asComposed = Group.Value as ComposedGroupPart;
                    if (asComposed != null)
                    {
                        var name = dataParts.Length == 1 ? dataParts[0] : dataParts[1].Split('.').Last();
                        var newDso = new DataSourceOperand { DataSourceName = dataParts[0] };
                        if (dataParts.Length == 2)
                            newDso.DataSourceProperty = dataParts[1];
                        asComposed.EntityRefs.Add(new EntityRef { Operand = newDso, Name = EnsureName(name, asComposed) });
                    }

                }
            }
        }
    }
}
