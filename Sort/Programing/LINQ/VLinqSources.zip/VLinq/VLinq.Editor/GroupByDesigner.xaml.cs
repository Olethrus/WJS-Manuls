﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for GroupByDesigner.xaml
    /// </summary>
    public partial class GroupByDesigner : UserControl
    {
        public GroupByController Controller
        {
            get { return DataContext as GroupByController; }
        }
        public GroupByDesigner()
        {
            InitializeComponent();
            this.DataContextChanged+= delegate
            {
                if (Controller != null)
                {
                    if (Controller.Group != null)
                        DesignTimeProperties.SetEditorFor(Controller.Group, this);
                }
            };
        }
        
       

        private void key_DragEnter(object sender, DragEventArgs e)
        {
            if (Controller != null)
                e.Effects = Controller.IsValidForKey(e.Data) ? DragDropEffects.Copy : DragDropEffects.None;
            else
                e.Effects = DragDropEffects.None;
        }

        private void key_DragOver(object sender, DragEventArgs e)
        {
            if (Controller != null)
                e.Effects = Controller.IsValidForKey(e.Data) ? DragDropEffects.Copy : DragDropEffects.None;
            else
                e.Effects = DragDropEffects.None;
        }

        private void key_Drop(object sender, DragEventArgs e)
        {
            if (Controller != null)
                Controller.AddKeyMember(e.Data);
        }

        private void value_DragEnter(object sender, DragEventArgs e)
        {
            if (Controller != null)
                e.Effects = Controller.IsValidForValue(e.Data) ? DragDropEffects.Copy : DragDropEffects.None;
            else
                e.Effects = DragDropEffects.None;
        }

        private void value_DragOver(object sender, DragEventArgs e)
        {
            if (Controller != null)
                e.Effects = Controller.IsValidForValue(e.Data) ? DragDropEffects.Copy : DragDropEffects.None;
            else
                e.Effects = DragDropEffects.None;
        }

        private void value_Drop(object sender, DragEventArgs e)
        {
            if (Controller != null)
                Controller.AddValueMember(e.Data);
        }

        private void composedGroupPartTpl_Loaded(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("ComposedGroupPartTpl_Loaded");
        }

        private void BindEditorToItem(object sender, RoutedEventArgs e)
        {
            var asFe = sender as FrameworkElement;
            if (asFe != null)
            {
                var item = asFe.DataContext as DependencyObject;
                if (item != null)
                    DesignTimeProperties.SetEditorFor(item, asFe);
            }
        }
    }
}
