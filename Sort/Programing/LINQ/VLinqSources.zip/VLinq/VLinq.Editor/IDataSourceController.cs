﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace VLinq.Editor
//{
//    public interface IDataSourceController
//    {
//        bool IsClipboardValid { get; }
//        void CreateFromClipboard();
//        void CreateChildDataSource(DataSource parent, VLinq.Processing.PropertyDescription property);
//    }
//}
