﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.ComponentModel;
using System.Windows.Data;
using VLinq.Processing;
using System.Collections.ObjectModel;

namespace VLinq.Editor
{
    public class JoinDetailsController : DependencyObject
    {


        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(JoinDetailsController), new UIPropertyMetadata(null, OnQueryChanged));

        private static void OnQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            JoinDetailsController elem = obj as JoinDetailsController;
            if (elem != null)
            {
                elem.OnQueryChanged(args.OldValue == null ? default(Query) : (Query)args.OldValue, args.NewValue == null ? default(Query) : (Query)args.NewValue);
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
            if (newValue != null)
            {
                RebuildLeftDataSources();
                newValue.DataSources.Changed += delegate
                {
                    RebuildLeftDataSources();
                    if (Join != null)
                        RebuildRightDataSources();
                };
                if (Join != null)
                    RebuildRightDataSources();
            }
        }
        private void RebuildLeftDataSources()
        {
            var toMatch = Query.DataSources.Where(ds => ds is EntitySource).Select(ds=>ds.Name).ToList();
            var toDelete = LeftDataSources.Except(toMatch).ToList();
            foreach (var ds in toDelete)
                LeftDataSources.Remove(ds);
            var toAdd = toMatch.Except(LeftDataSources).ToList();
            foreach (var ds in toAdd)
                LeftDataSources.Add(ds);

            for (int i = 0; i < toMatch.Count; i++)
            {
                var curIndex = LeftDataSources.IndexOf(toMatch[i]);
                if (curIndex != i)
                {
                    LeftDataSources.Move(curIndex, i);
                }
            }
        }
        private void RebuildRightDataSources()
        {
            if (Join != null)
            {
                if (LeftDataSources.Contains(Join.LeftEntitySource))
                {
                    var indexOfLeft = LeftDataSources.IndexOf(Join.LeftEntitySource);
                    var toMatch = LeftDataSources.Skip(indexOfLeft + 1).ToList();
                    var toDelete = RightDataSources.Except(toMatch).ToList();
                    foreach (var ds in toDelete)
                        RightDataSources.Remove(ds);
                    var toAdd = toMatch.Except(RightDataSources).ToList();
                    foreach (var ds in toAdd)
                        RightDataSources.Add(ds);

                    for (int i = 0; i < toMatch.Count; i++)
                    {
                        var curIndex = RightDataSources.IndexOf(toMatch[i]);
                        if (curIndex != i)
                        {
                            RightDataSources.Move(curIndex, i);
                        }
                    }
                }
                else
                {
                    RightDataSources.Clear();
                }
            }
        }



        public string[] LeftProperties
        {
            get { return (string[])GetValue(LeftPropertiesProperty); }
            private set { SetValue(LeftPropertiesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LeftProperties.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LeftPropertiesProperty =
            DependencyProperty.Register("LeftProperties", typeof(string[]), typeof(JoinDetailsController), new UIPropertyMetadata(null));



        public string[] RightProperties
        {
            get { return (string[])GetValue(RightPropertiesProperty); }
            set { SetValue(RightPropertiesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for RightProperties.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RightPropertiesProperty =
            DependencyProperty.Register("RightProperties", typeof(string[]), typeof(JoinDetailsController), new UIPropertyMetadata(null));



        public JoinDetailsController()
        {
            LeftDataSources = new ObservableCollection<string>();
            RightDataSources = new ObservableCollection<string>();
        }



        public ObservableCollection<string> LeftDataSources
        {
            get { return (ObservableCollection<string>)GetValue(LeftDataSourcesProperty); }
            private set { SetValue(LeftDataSourcesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LeftDataSources.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LeftDataSourcesProperty =
            DependencyProperty.Register("LeftDataSources", typeof(ObservableCollection<string>), typeof(JoinDetailsController), new UIPropertyMetadata(null));



        public ObservableCollection<string> RightDataSources
        {
            get { return (ObservableCollection<string>)GetValue(RightDataSourcesProperty); }
            private set { SetValue(RightDataSourcesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for RightDataSources.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RightDataSourcesProperty =
            DependencyProperty.Register("RightDataSources", typeof(ObservableCollection<string>), typeof(JoinDetailsController), new UIPropertyMetadata(null));






        public JoinDeclaration Join
        {
            get { return (JoinDeclaration)GetValue(JoinProperty); }
            set { SetValue(JoinProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Join.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty JoinProperty =
            DependencyProperty.Register("Join", typeof(JoinDeclaration), typeof(JoinDetailsController), new UIPropertyMetadata(null, OnJoinChanged));

        private static void OnJoinChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            JoinDetailsController elem = obj as JoinDetailsController;
            if (elem != null)
            {
                elem.OnJoinChanged(args.OldValue == null ? default(JoinDeclaration) : (JoinDeclaration)args.OldValue, args.NewValue == null ? default(JoinDeclaration) : (JoinDeclaration)args.NewValue);
            }
        }
        protected virtual void OnJoinChanged(JoinDeclaration oldValue, JoinDeclaration newValue)
        {
            if (newValue != null)
            {
                if (Query != null)
                {
                    RebuildLeftDataSources();
                    RebuildRightDataSources();
                    RebuildLeftProperties();
                    RebuildRightProperties();
                }
                newValue.Changed += delegate(object sender, NotifyChangedEventArgs args)
                {
                    if (args.ChangedStack.Select(entry => entry.ChangedProperty).Contains(JoinDeclaration.LeftEntitySourceProperty))
                    {
                        if (Query != null)
                        {
                            RebuildRightDataSources();
                            RebuildLeftProperties();
                        }
                    }
                    else if (args.ChangedStack.Select(entry => entry.ChangedProperty).Contains(JoinDeclaration.RightEntitySourceProperty))
                    {
                        if (Query != null)
                        {
                            RebuildRightProperties();
                        }
                    }
                    else if (args.ChangedStack.Select(entry => entry.ChangedProperty).Contains(JoinDeclaration.LeftPropertiesProperty))
                    {
                        var toDelete = Join.LeftProperties.Where(vls => string.IsNullOrEmpty(vls.Value)).ToArray();
                        foreach (var vls in toDelete)
                            Join.LeftProperties.Remove(vls);
                    }
                    else if (args.ChangedStack.Select(entry => entry.ChangedProperty).Contains(JoinDeclaration.RightPropertiesProperty))
                    {
                        var toDelete = Join.RightProperties.Where(vls => string.IsNullOrEmpty(vls.Value)).ToArray();
                        foreach (var vls in toDelete)
                            Join.RightProperties.Remove(vls);
                    }
                };
            }
        }

        private void RebuildRightProperties()
        {
            if (!string.IsNullOrEmpty(Join.RightEntitySource))
            {
                var rightDS = Query.FindDataSource(Join.RightEntitySource);
                if (rightDS != null)
                {
                    var rightDesc = ValidTimeProperties.GetReturnType(rightDS);
                    if (rightDesc != null)
                    {
                        RightProperties = new string[] { "" }.Concat(rightDesc.Properties.Select(prop => prop.Name)).ToArray();
                    }
                    else
                    {
                        RightProperties = new string[] { "" };
                    }
                }
                else
                {
                    RightProperties = new string[] { "" };
                }
            }
            else
            {
                RightProperties = new string[] { "" };
            }
        }

        private void RebuildLeftProperties()
        {
            if (!string.IsNullOrEmpty(Join.LeftEntitySource))
            {
                var leftDS = Query.FindDataSource(Join.LeftEntitySource);
                if (leftDS != null)
                {
                    var leftDesc = ValidTimeProperties.GetReturnType(leftDS);
                    if (leftDesc != null)
                    {
                        LeftProperties = new string[] { "" }.Concat(leftDesc.Properties.Select(prop => prop.Name)).ToArray();
                    }
                    else
                    {
                        LeftProperties = new string[] { "" };
                    }
                }
                else
                {
                    LeftProperties = new string[] { "" };
                }
            }
            else
            {
                LeftProperties = new string[] { "" };
            }
        }


    }
}
