﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for JoinDetailsEditor.xaml
    /// </summary>
    public partial class JoinDetailsEditor : UserControl
    {
        public JoinDetailsEditor()
        {
            InitializeComponent();
        }
        public JoinDetailsController Controller
        {
            get { return DataContext as JoinDetailsController; }
        }

        private void cbNewLeft_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbNewLeft.SelectedItem != null)
            {
                var selected = cbNewLeft.SelectedItem.ToString();
                if (!string.IsNullOrEmpty(selected))
                {
                    Controller.Join.LeftProperties.Add(new VLinqString { Value = selected });
                    cbNewLeft.SelectedItem = string.Empty;
                }
            }
        }

        private void cbNewRight_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbNewRight.SelectedItem != null )
            {
                var selected = cbNewRight.SelectedItem.ToString();
                if (!string.IsNullOrEmpty(selected))
                {
                    Controller.Join.RightProperties.Add(new VLinqString { Value = selected });
                    cbNewRight.SelectedItem = string.Empty;
                }
            }
        }
    }
}
