﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for JoinsDesigner.xaml
    /// </summary>
    public partial class JoinsDesigner : UserControl
    {
        public JoinsDesigner()
        {
            InitializeComponent();
        }
        public Query Query
        {
            get { return DataContext as Query; }
        }
        private void animatedExpander_Loaded(object sender, RoutedEventArgs e)
        {
            var asFe = sender as FrameworkElement;
            var join = asFe.DataContext as JoinDeclaration;
            var correspondingTextBlock = asFe.FindName("txtJoinDesc") as TextBlock;
            correspondingTextBlock.Inlines.Clear();
            correspondingTextBlock.Inlines.AddRange(join.ToInlines().Select( o => VLinqComponentToInlineConverter.ToInline(o)));
            DesignTimeProperties.SetEditorFor(join, asFe);
            join.Changed += delegate
            {
                correspondingTextBlock.Inlines.Clear();
                correspondingTextBlock.Inlines.AddRange(join.ToInlines().Select( o => VLinqComponentToInlineConverter.ToInline(o)));
            };
            var joinDetails = asFe.FindName("joinDetails") as JoinDetailsEditor;
            joinDetails.Controller.Query = Query;
            joinDetails.Controller.Join = join;
        }

        private void btnNew_Click(object sender, RoutedEventArgs e)
        {
            if (Query != null)
                Query.Joins.Add(new JoinDeclaration());
        }

        private void animatedExpander_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var item = (sender as DependencyObject).FindFirstVisualAncestorOf<ListBoxItem>();
            if (item != null)
            {
                item.RaiseEvent(new MouseButtonEventArgs(e.MouseDevice, e.Timestamp, e.ChangedButton) { RoutedEvent = ListBoxItem.MouseLeftButtonDownEvent });
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            var toDelete = ListBox.SelectedItems.OfType<JoinDeclaration>().ToArray();
            foreach (var td in toDelete)
                Query.Joins.Remove(td);
        }
    }
}
