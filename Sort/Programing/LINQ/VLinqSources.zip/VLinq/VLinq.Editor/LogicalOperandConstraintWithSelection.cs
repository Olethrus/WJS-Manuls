﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq.Editor
{
    public class LogicalOperandConstraintWithSelection : FrameworkElement
    {

        public LogicalOperandConstraintWithSelection()
        {
            Visibility = Visibility.Collapsed;
        }
        public LogicalOperatorConstraint LogicalOperatorConstraint
        {
            get { return (LogicalOperatorConstraint)GetValue(LogicalOperatorConstraintProperty); }
            set { SetValue(LogicalOperatorConstraintProperty, value); }
        }

        // Using a DependencyProperty as the backing store for LogicalOperatorConstraint.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LogicalOperatorConstraintProperty =
            DependencyProperty.Register("LogicalOperatorConstraint", typeof(LogicalOperatorConstraint), typeof(LogicalOperandConstraintWithSelection), new UIPropertyMetadata(null));



        public System.Collections.IList Selection
        {
            get { return (System.Collections.IList)GetValue(SelectionProperty); }
            set { SetValue(SelectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Selection.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectionProperty =
            DependencyProperty.Register("Selection", typeof(System.Collections.IList), typeof(LogicalOperandConstraintWithSelection), new UIPropertyMetadata(null));


    }
}
