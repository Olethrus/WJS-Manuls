﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.Processing;
using System.Collections.ObjectModel;

namespace VLinq.Editor
{
    /// <summary>
    /// TreeListView item used in the projection designer in the MappedProjection mode
    /// </summary>
    public class MappedProjectionItem : ProjectionItem
    {
        public MappedProjectionItem(ProjectionController controller)
            : base(controller)
        {
            SetValue(MappablePropertiesProperty, new ObservableCollection<string>());
        }
        MappedProjection m_projection;
        /// <summary>
        /// When the projection is set, the Mappable output properties collection for the item is reset.
        /// At this time we also checked in the existing mappings if this item is part of an existing mapping
        /// </summary>
        /// <param name="projection"></param>
        public override void SetProjection(Projection projection)
        {
            m_projection = projection as MappedProjection;
            if (m_projection != null)
            {
                
                if (Controller != null)
                {
                    MappableProperties.Clear();
                    foreach (var str in Controller.GetOutputAvailableProperties(
                        (Property != null && Property.Length > 0) ? Property.Last().TypeDescription :
                        ValidTimeProperties.GetReturnType(DataSource)))
                        MappableProperties.Add(str);
                }
                UpdateCheckedState();
              
                m_projection.Changed += new EventHandler<NotifyChangedEventArgs>(m_projection_Changed);
            }
        }
        /// <summary>
        /// When the projection is changed we see if the output type has changed, and if the current DataSource / property is mapped
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void m_projection_Changed(object sender, NotifyChangedEventArgs e)
        {
            
            if (Controller != null && e.ChangedStack.Count == 1)
            {
                MappableProperties.Clear();
                foreach (var str in Controller.GetOutputAvailableProperties(
                    (Property != null && Property.Length > 0) ? Property.Last().TypeDescription :
                    ValidTimeProperties.GetReturnType(DataSource)))
                    MappableProperties.Add(str);
            }
            UpdateCheckedState();
            
        }
        /// <summary>
        /// Navigate trough the existing mappings to see if the item must be checked 
        /// </summary>
        private void UpdateCheckedState()
        {
            if (m_projection != null)
            {
                bool isChecked = false;
                foreach (var mapping in m_projection.Mappings)
                {
                    var dsOperand = mapping.Operand as DataSourceOperand;
                    if (dsOperand != null)
                    {
                        // Wow, who did write this beautiful test ?
                        if (dsOperand.DataSourceName == DataSource.Name &&
                            (string.IsNullOrEmpty(dsOperand.DataSourceProperty) ? 
                                (Property == null || Property.Length == 0) :
                                (Property != null && string.Join(".", Property.Select(p => p.Name).ToArray()) == dsOperand.DataSourceProperty)))
                        {
                            Mapping = mapping;
                            OutputProperty = mapping.OutputProperty;
                            isChecked = true;
                            
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(dsOperand.DataSourceProperty)
                                && dsOperand.DataSourceName == DataSource.Name
                                && ((Property == null || Property.Length == 0)
                                   || (Property != null && dsOperand.DataSourceProperty.StartsWith(
                                       string.Join(".", Property.Select(o => o.Name).ToArray())
                                        ))))
                            {
                                this.IsExpanded = true;
                            }
                        }
                    }
                }
                Checked = isChecked;
            }
        }



        /// <summary>
        /// Mapping represented by the item
        /// </summary>
        public ProjectionMapping Mapping
        {
            get { return (ProjectionMapping)GetValue(MappingProperty); }
            set { SetValue(MappingProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Mapping.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MappingProperty =
            DependencyProperty.Register("Mapping", typeof(ProjectionMapping), typeof(MappedProjectionItem), new UIPropertyMetadata(null, OnMappingChanged));

        private static void OnMappingChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            MappedProjectionItem elem = obj as MappedProjectionItem;
            if (elem != null)
            {
                elem.OnMappingChanged(args.OldValue == null ? default(ProjectionMapping) : (ProjectionMapping)args.OldValue, args.NewValue == null ? default(ProjectionMapping) : (ProjectionMapping)args.NewValue);
            }
        }
        /// <summary>
        /// Associates the item to the mapping
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected virtual void OnMappingChanged(ProjectionMapping oldValue, ProjectionMapping newValue)
        {
            if (newValue != null)
            {
                DesignTimeProperties.SetEditorFor(newValue, this);
                if (newValue.Operand != null)
                    DesignTimeProperties.SetEditorFor(newValue.Operand, this);
            }
        }



        /// <summary>
        /// Reflect changes to the actual projection
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected override void OnCheckedChanged(bool oldValue, bool newValue)
        {
            if (newValue)
            {

                if (Mapping == null || !m_projection.Mappings.Contains(Mapping))
                {
                    Mapping = new ProjectionMapping
                    {
                        Operand = new DataSourceOperand
                        {
                            DataSourceName = DataSource.Name,
                            DataSourceProperty = Property != null? string.Join(".", Property.Select(p => p.Name).ToArray()): string.Empty

                        },
                        OutputProperty = OutputProperty
                    };
                    m_projection.Mappings.Add(Mapping);
                }
            }
            else
            {
                if (m_projection.Mappings.Contains(Mapping))
                {
                    m_projection.Mappings.Remove(Mapping);
                }
            }
        }



        /// <summary>
        /// Property names of the output type available for the current DataSource / Property
        /// </summary>
        public ObservableCollection<string> MappableProperties
        {
            get { return (ObservableCollection<string>)GetValue(MappablePropertiesProperty); }
        }

        // Using a DependencyProperty as the backing store for MappableProperties.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MappablePropertiesProperty =
            DependencyProperty.Register("MappableProperties", typeof(ObservableCollection<string>), typeof(MappedProjection), new UIPropertyMetadata());



        /// <summary>
        /// Output property name of the mapping
        /// </summary>
        public string OutputProperty
        {
            get { return (string)GetValue(OutputPropertyProperty); }
            set { SetValue(OutputPropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OutputProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OutputPropertyProperty =
            DependencyProperty.Register("OutputProperty", typeof(string), typeof(MappedProjectionItem), new UIPropertyMetadata(string.Empty, OnOutputPropertyChanged));

        private static void OnOutputPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            MappedProjectionItem elem = obj as MappedProjectionItem;
            if (elem != null)
            {
                elem.OnOutputPropertyChanged(args.OldValue == null ? default(string) : (string)args.OldValue, args.NewValue == null ? default(string) : (string)args.NewValue);
            }
        }
        /// <summary>
        /// Reflect changes to the query object tree
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected virtual void OnOutputPropertyChanged(string oldValue, string newValue)
        {
            if (Mapping != null)
            {
                Mapping.OutputProperty = newValue;
            }
        }


        /// <summary>
        /// Create a child MappedProjection item from a data source and a PropertyDescription chain
        /// </summary>
        /// <param name="dataSource"></param>
        /// <param name="propDescs"></param>
        /// <returns></returns>
        protected override ProjectionItem CreateSubItem(DataSource dataSource, VLinq.Processing.PropertyDescription[] propDescs)
        {
            var subItem = new MappedProjectionItem(Controller) { DataSource = dataSource, Property = propDescs };
            if (subItem.Property == null || subItem.Property.Length == 0)
            {
                subItem.OutputProperty = subItem.DataSource.Name;
            }
            else
            {
                subItem.OutputProperty = subItem.DataSource.Name + string.Join("", subItem.Property.Select(o => o.Name).ToArray());

            }
            subItem.SetProjection(m_projection);
            return subItem;
        }
    }
}
