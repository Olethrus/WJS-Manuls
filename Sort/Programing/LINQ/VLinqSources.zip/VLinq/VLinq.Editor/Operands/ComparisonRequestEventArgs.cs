﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Editor.Operands
{
    public class ComparisonRequestEventArgs : EventArgs
    {
        public Comparison Operator { get; set; }
    }
}
