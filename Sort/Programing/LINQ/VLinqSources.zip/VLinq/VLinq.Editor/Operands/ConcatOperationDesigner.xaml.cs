﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.Processing;
using VLinq.WPFControls;

namespace VLinq.Editor.Operands
{
    /// <summary>
    /// Interaction logic for ConcatOperationDesigner.xaml
    /// </summary>
    public partial class ConcatOperationDesigner : UserControl
    {
        public ConcatOperationDesigner()
        {
            InitializeComponent(); 
        }

        public ConcatOperationController Controller
        {
            get
            {
                return DataContext as ConcatOperationController;
            }
        }

        public int Count
        {
            get { return operandList.Items.Count; }
        }
        private int m_nextIndexToFocus = -1;
        public void FocusAt(int index)
        {
            if (index < Count)
            {
                m_nextIndexToFocus = index;
            }
        }

        private void OperandHost_Loaded(object sender, RoutedEventArgs e)
        {
            var templateInstance = sender as FrameworkElement;
            var host = templateInstance.FindName("OperandHost") as OperandHost;
            var container = VisualTreeHelper.GetParent(templateInstance);
            host.Controller.Query = Controller.Query;
            var operand = operandList.ItemContainerGenerator.ItemFromContainer(container) as Operand;
            host.Controller.Operand = operand;
            var index = operandList.ItemContainerGenerator.IndexFromContainer(container);
            if (index == 0)
            {
                var prefix = templateInstance.FindName("prefix") as FrameworkElement;
                if (prefix != null)
                    prefix.Visibility = Visibility.Collapsed;
            }
            
            host.Controller.OperandChanged += delegate
            {
                (Controller.Operand as ConcatOperationOperand).Operands[index] = host.Controller.Operand;
            };
            host.Controller.OperatorRequest += delegate(object s, OperatorRequestEventArgs ore)
            {
                if (ore.Operator == NumericOperation.Plus)
                {
                    var td = ValidTimeProperties.GetReturnType(host.Operand);
                    if (td == null || !td.IsNumeric)
                    {
                        ore.Handled = true;
                        (Controller.Operand as ConcatOperationOperand).Operands.Insert(index + 1, new ConstantOperand { TypeName = "System.String", ConstantValue = null });
                        FocusAt(index + 1);
                    }
                }
            };
            if (index == m_nextIndexToFocus)
            {
                m_nextIndexToFocus = -1;
                host.FocusOnLoad();
            }
        }

        
    }
}
