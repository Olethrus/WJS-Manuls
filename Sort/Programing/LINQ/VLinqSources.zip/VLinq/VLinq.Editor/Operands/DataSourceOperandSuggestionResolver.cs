﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VLinq.WPFControls;
using VLinq.Processing;
using System.Windows;

namespace VLinq.Editor.Operands
{
    public class DataSourceOperandSuggestionResolver : SuggestionResolverBase
    {
        public bool IsAfterGroupBy
        {
            get
            {
                if (SuggestBox == null)
                    return false;
                return ConstraintTreeController.GetIsAfterGroupBy(SuggestBox);
            }
        }
        public QueryValidator QueryValidator
        {
            get
            {
                if (this.Controller != null && this.Controller.Query != null)
                {
                    return this.Controller.Query.GetValue(QueryValidator.AttachedValidatorProperty) as QueryValidator;
                }
                return null;
            }
        }
        protected override void OnSuggestBoxSet()
        {
            
        }
        protected override void OnCaretIndexChanged()
        {
            
        }
        protected override void OnTextChanged(object e)
        {
            
        }
        public DefaultOperandController Controller { get; set; }

        

        protected override void OnSuggestionsRequested()
        {
            if (this.SuggestBox.ShowingSuggestions)
                ResetSuggestions();
        }

        private void ResetSuggestions()
        {
            if (Controller != null && Controller.Query != null)
            {
                Suggestions.Clear();
                string ctx = SuggestionContext.Trim();
                if (ctx.Length == 0)
                {
                    foreach (var ds in Controller.Query.DataSourcesWithParents)
                    {
                        if (IsAfterGroupBy)
                        {
                            if ((ds is EntitySource) || (ds is ChildEntitySource))
                                continue;
                        }
                        Suggestions.Add(new Suggestion { Label = ds.Name, GeneratedText = ds.Name, CaretPosition = ds.Name.Length, IconSource = Properties.Resources._Properties });
                    }
                    if (IsAfterGroupBy)
                    {
                        Suggestions.Add(new Suggestion { Label = Controller.Query.GroupBy.GroupName, GeneratedText = Controller.Query.GroupBy.GroupName, CaretPosition = Controller.Query.GroupBy.GroupName.Length, IconSource = Properties.Resources._Properties });
                    }
                }
                else
                {
                    var parts = ctx.Split('.');
                    
                    var ds = Controller.Query.FindDataSource(parts[0]);
                    if (IsAfterGroupBy)
                    {
                        if (ds is EntitySource || ds is ChildEntitySource)
                            ds = null;
                        else if (ds == null)
                        {
                            if (parts[0] == this.Controller.Query.GroupBy.GroupName)
                            {
                                ds = new FakeDataSource();
                                ds.Name = parts[0];
                                ValidTimeProperties.SetReturnType(ds, ValidTimeProperties.GetReturnType(this.Controller.Query.GroupBy));
                            }
                        }
                    }
                    if (ds != null)
                    {
                        var td = ValidTimeProperties.GetReturnType(ds);
                        if (td != null)
                        {

                            for (int i = 1; i < parts.Length; i++)
                            {
                                if (parts[i] == "ToString()")
                                {
                                    td = QueryValidator.TypeDescriptionBuilder.BuildTypeDescription("System.String");
                                    continue;
                                }
                                else if (parts[i] == "Count()" || parts[i] == "CountDistinct()")
                                {
                                    td = QueryValidator.TypeDescriptionBuilder.BuildTypeDescription("System.Int32");
                                    continue;
                                }
                                else if (parts[i] == "First()" || parts[i] == "Last()")
                                {
                                    if (!td.IsEnumerable)
                                        return;
                                    if (td.IsGroup)
                                        td = td.GroupValueType;
                                    else td = td.TypeParameters[0];
                                    continue;
                                }
                                
                                else if (parts[i].EndsWith("("))
                                {
                                    if(i == parts.Length-1)
                                    {
                                        if (parts[i] == "Count(")
                                        {
                                            string count = "Count()";
                                            Suggestions.Add(new Suggestion { Label = count, CaretPosition = ctx.Length + 1, GeneratedText = ctx + ")", IconSource = Properties.Resources._Methods });
                                            return;
                                        }
                                        else if (parts[i] == "First(")
                                        {
                                            string count = "First()";
                                            Suggestions.Add(new Suggestion { Label = count, CaretPosition = ctx.Length + 1, GeneratedText = ctx + ")", IconSource = Properties.Resources._Methods });
                                            return;
                                        }
                                        else if (parts[i] == "Last(")
                                        {
                                            string count = "Last()";
                                            Suggestions.Add(new Suggestion { Label = count, IconSource = Properties.Resources._Methods, CaretPosition = ctx.Length + 1, GeneratedText = ctx + ")" });
                                            return;
                                        }
                                        else if (parts[i] == "ToString(")
                                        {
                                            string count = "ToString()";
                                            Suggestions.Add(new Suggestion { Label = count, IconSource = Properties.Resources._Methods, CaretPosition = ctx.Length + 1, GeneratedText = ctx + ")" });
                                            return;
                                        }
                                        else if (parts[i] == "Max(")
                                        {
                                            var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                            foreach (var projProp in enumeratedTd.Properties)
                                            {
                                                if (projProp.TypeDescription.IsNumeric || projProp.TypeDescription.IsString || projProp.TypeDescription.IsDateTime)
                                                    Suggestions.Add(new Suggestion { Label = "Max(" + projProp.Name + ")", IconSource = Properties.Resources._Methods, CaretPosition = projProp.Name.Length + ctx.Length + 1, GeneratedText = ctx + projProp.Name + ")" });
                                            }
                                            return;
                                        }
                                        else if (parts[i] == "Min(")
                                        {
                                            var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                            foreach (var projProp in enumeratedTd.Properties)
                                            {
                                                if (projProp.TypeDescription.IsNumeric || projProp.TypeDescription.IsString || projProp.TypeDescription.IsDateTime)
                                                    Suggestions.Add(new Suggestion { Label = "Min(" + projProp.Name + ")", IconSource = Properties.Resources._Methods, CaretPosition = projProp.Name.Length + ctx.Length + 1, GeneratedText = ctx + projProp.Name + ")" });
                                            }
                                            return;
                                        }
                                        else if (parts[i] == "Sum(")
                                        {
                                            var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                            foreach (var projProp in enumeratedTd.Properties)
                                            {
                                                if (projProp.TypeDescription.IsNumeric)
                                                    Suggestions.Add(new Suggestion { Label = "Sum(" + projProp.Name + ")", IconSource = Properties.Resources._Methods, CaretPosition = projProp.Name.Length + ctx.Length + 1, GeneratedText = ctx + projProp.Name + ")" });
                                            }
                                            return;
                                        }
                                        else if (parts[i] == "Select(")
                                        {
                                            var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                            foreach (var projProp in enumeratedTd.Properties)
                                            {
                                                Suggestions.Add(new Suggestion { Label = "Select(" + projProp.Name + ")", IconSource = Properties.Resources._Methods, CaretPosition = projProp.Name.Length + ctx.Length + 1, GeneratedText = ctx + projProp.Name + ")" });
                                            }
                                            return;
                                        }
                                        else if (parts[i] == "Average(")
                                        {
                                            var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                            foreach (var projProp in enumeratedTd.Properties)
                                            {
                                                if (projProp.TypeDescription.IsNumeric)
                                                    Suggestions.Add(new Suggestion { Label = "Average(" + projProp.Name + ")", IconSource = Properties.Resources._Methods, CaretPosition = projProp.Name.Length + ctx.Length + 1, GeneratedText = ctx + projProp.Name + ")" });
                                            }
                                            return;
                                        }
                                    }
                                    else
                                        return;
                                }
                                else if (parts[i].StartsWith("Max(") && parts[i].EndsWith(")"))
                                {
                                    string projPropName = parts[i].Substring(4,parts[i].Length-5);
                                    var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                    if (projPropName.Length > 0)
                                        td = enumeratedTd.GetProperty(projPropName).TypeDescription;
                                    else
                                        td = enumeratedTd;
                                    if (td == null)
                                        return;
                                }
                                else if (parts[i].StartsWith("Min(") && parts[i].EndsWith(")"))
                                {
                                    string projPropName = parts[i].Substring(4, parts[i].Length - 5);
                                    var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                    if (projPropName.Length > 0)
                                        td = enumeratedTd.GetProperty(projPropName).TypeDescription;
                                    else
                                        td = enumeratedTd;
                                    if (td == null)
                                        return;
                                }
                                else if (parts[i].StartsWith("Sum(") && parts[i].EndsWith(")"))
                                {
                                    string projPropName = parts[i].Substring(4, parts[i].Length - 5);
                                    var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                    if (projPropName.Length > 0)
                                        td = enumeratedTd.GetProperty(projPropName).TypeDescription;
                                    else
                                        td = enumeratedTd;
                                    if (td == null)
                                        return;
                                }
                                else if (parts[i].StartsWith("Select(") && parts[i].EndsWith(")"))
                                {
                                    string projPropName = parts[i].Substring(7, parts[i].Length - 8);
                                    var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                    td = enumeratedTd.GetProperty(projPropName).TypeDescription;
                                    if (td == null)
                                        return;
                                    td = QueryValidator.TypeDescriptionBuilder.BuildEnumerableOf(td);
                                    if (td == null)
                                        return;
                                }
                                else if (parts[i].StartsWith("Average(") && parts[i].EndsWith(")"))
                                {
                                    string projPropName = parts[i].Substring(8, parts[i].Length - 9);
                                    var enumeratedTd = td.IsGroup ? td.GroupValueType : td.TypeParameters[0];
                                    if (projPropName.Length > 0)
                                        td = enumeratedTd.GetProperty(projPropName).TypeDescription;
                                    else
                                        td = enumeratedTd;
                                    if (td == null)
                                        return;
                                }
                                var prop = td.GetProperty(parts[i]);
                                if (prop == null)
                                    return;
                                td = prop.TypeDescription;
                                if (td == null)
                                    return;
                            }
                            foreach (var prop in td.Properties)
                            {
                                Suggestions.Add(new Suggestion { Label = prop.Name, IconSource = Properties.Resources._Properties, CaretPosition = prop.Name.Length + ctx.Length + 1, GeneratedText = ctx + "." + prop.Name });
                            }
                            if (!td.IsString)
                            {
                                var toString = "ToString()";
                                Suggestions.Add(new Suggestion { Label = toString, IconSource = Properties.Resources._Methods, CaretPosition = toString.Length + ctx.Length + 1, GeneratedText = ctx + "." + toString });
                            }
                            if (td.IsEnumerable)
                            {
                                var count = "Count()";
                                Suggestions.Add(new Suggestion { Label = count, IconSource = Properties.Resources._Methods, CaretPosition = count.Length + ctx.Length + 1, GeneratedText = ctx + "." + count });
                                var first = "First()";
                                var last = "Last()";
                                Suggestions.Add(new Suggestion { Label = first, IconSource = Properties.Resources._Methods, CaretPosition = first.Length + ctx.Length + 1, GeneratedText = ctx + "." + first });
                                Suggestions.Add(new Suggestion { Label = last, IconSource = Properties.Resources._Methods, CaretPosition = last.Length + ctx.Length + 1, GeneratedText = ctx + "." + last });
                                var min = "Min(";
                                Suggestions.Add(new Suggestion { Label = min, IconSource = Properties.Resources._Methods, CaretPosition = min.Length + ctx.Length + 1, GeneratedText = ctx + "." + min });
                                var max = "Max(";
                                Suggestions.Add(new Suggestion { Label = max, IconSource = Properties.Resources._Methods, CaretPosition = max.Length + ctx.Length + 1, GeneratedText = ctx + "." + max });
                                var sum = "Sum(";
                                Suggestions.Add(new Suggestion { Label = sum, IconSource = Properties.Resources._Methods, CaretPosition = sum.Length + ctx.Length + 1, GeneratedText = ctx + "." + sum });
                                var avg = "Average(";
                                Suggestions.Add(new Suggestion { Label = avg, IconSource = Properties.Resources._Methods, CaretPosition = avg.Length + ctx.Length + 1, GeneratedText = ctx + "." + avg });
                                var select = "Select(";
                                Suggestions.Add(new Suggestion { Label = select, IconSource = Properties.Resources._Methods, CaretPosition = select.Length + ctx.Length + 1, GeneratedText = ctx + "." + select });
                            }
                        }
                    }
                }
            }
        }

        
        protected override void OnSuggestionContextChanged()
        {
            if (this.SuggestBox.ShowingSuggestions)
                ResetSuggestions();
        }
    }
}
