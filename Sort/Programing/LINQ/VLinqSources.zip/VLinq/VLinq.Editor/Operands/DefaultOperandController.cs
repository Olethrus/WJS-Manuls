﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.Processing;
using System.Globalization;

namespace VLinq.Editor.Operands
{
    public class DefaultOperandController : FrameworkElement
    {


        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(DefaultOperandController), new UIPropertyMetadata(null, OnQueryChanged));

        private static void OnQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            DefaultOperandController elem = obj as DefaultOperandController;
            if (elem != null)
            {
                elem.OnQueryChanged(args.OldValue == null ? default(Query) : (Query)args.OldValue, args.NewValue == null ? default(Query) : (Query)args.NewValue);
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
        }



        public OperandHostController HostController
        {
            get { return (OperandHostController)GetValue(HostControllerProperty); }
            set { SetValue(HostControllerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for HostController.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HostControllerProperty =
            DependencyProperty.Register("HostController", typeof(OperandHostController), typeof(DefaultOperandController), new UIPropertyMetadata(null, OnHostControllerChanged));

        private static void OnHostControllerChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            DefaultOperandController elem = obj as DefaultOperandController;
            if (elem != null)
            {
                elem.OnHostControllerChanged(args.OldValue == null ? default(OperandHostController) : (OperandHostController)args.OldValue, args.NewValue == null ? default(OperandHostController) : (OperandHostController)args.NewValue);
            }
        }
        protected virtual void OnHostControllerChanged(OperandHostController oldValue, OperandHostController newValue)
        {
        }



        public Operand Operand
        {
            get { return (Operand)GetValue(OperandProperty); }
            set { SetValue(OperandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandProperty =
            DependencyProperty.Register("Operand", typeof(Operand), typeof(DefaultOperandController), new UIPropertyMetadata(null, OnOperandChanged));

        private static void OnOperandChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            DefaultOperandController elem = obj as DefaultOperandController;
            if (elem != null)
            {
                elem.OnOperandChanged(args.OldValue == null ? default(Operand) : (Operand)args.OldValue, args.NewValue == null ? default(Operand) : (Operand)args.NewValue);
            }
        }
        protected virtual void OnOperandChanged(Operand oldValue, Operand newValue)
        {
            if (newValue == null)
            {
                if (OperandText != string.Empty)
                {
                    m_skipNextTextChange = true;

                    OperandText = string.Empty;
                }
            }
            else
            {
                var asConstant = newValue as ConstantOperand;
                if (asConstant != null)
                {
                    if (asConstant.ConstantValue == null)
                    {
                        if (OperandText != string.Empty)
                        {
                            m_skipNextTextChange = true;
                            OperandText = string.Empty;
                        }
                    }
                    else
                    {
                        object val = asConstant.ConstantValue;
                        switch (asConstant.TypeName)
                        {
                            case "System.Boolean":
                                if (OperandText != val.ToString())
                                {
                                    m_skipNextTextChange = true;
                                    OperandText = val.ToString();
                                }
                                break;
                            case "System.Int32":
                            case "System.Int16":
                            case "System.Int64":
                            case "System.Single":
                            case "System.Double":
                            case "System.Decimal":
                                var dec = string.Format(CultureInfo.InvariantCulture, "{0}", val);
                                if (OperandText != dec)
                                {
                                    m_skipNextTextChange = true;
                                    OperandText = dec;
                                }
                                break;
                            case "System.String":
                                var str = string.Format(CultureInfo.InvariantCulture, "{0}", PrepareToDisplayConstantText(val.ToString()));
                                if (OperandText != str)
                                {
                                    m_skipNextTextChange = true;
                                    OperandText = str;
                                }
                                break;
                            default:
                                if (OperandText != string.Empty)
                                {
                                    m_skipNextTextChange = true;
                                    OperandText = string.Empty;
                                }
                                break;
                        }
                    }
                }
                else
                {
                    var dso = Operand as DataSourceOperand;
                    if(dso != null)
                    {
                        string txt = string.IsNullOrEmpty(dso.DataSourceProperty) ? dso.DataSourceName : string.Format(CultureInfo.InvariantCulture, "{0}.{1}", dso.DataSourceName, dso.DataSourceProperty);
                        var currentTransform = dso.Transform;
                        while (currentTransform != null)
                        {
                            var asToString = currentTransform as ToStringTransform;
                            var asEntitySet = currentTransform as EntitySetTransform;
                            if (asToString != null)
                            {
                                txt += ".ToString()";
                            }
                            else if (asEntitySet != null)
                            {
                                txt += string.Format( CultureInfo.InvariantCulture, ".{0}({1})", asEntitySet.Operation, asEntitySet.ProjectionProperty);

                            }
                            if (! string.IsNullOrEmpty( currentTransform.OutputProperty))
                                txt += '.'+currentTransform.OutputProperty;
                            currentTransform = currentTransform.ChainedTransform;
                        }
                        if (OperandText != txt)
                        {
                            m_skipNextTextChange = true;
                            OperandText = txt;
                        }
                    }
                }
            }
            if (HostController != null && HostController.Operand != newValue)
                HostController.Operand = newValue;
        }
        private bool m_skipNextTextChange = false;
        private string PrepareToDisplayConstantText(string text)
        {
            return string.Format(CultureInfo.InvariantCulture, "\"{0}\"", text.Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t"));
        }

        private string PrepareToStoreConstantText(string text)
        {
            text = text.Substring(1, text.Length - 2);
            text = text.Replace("\\t", "\t").Replace("\\n", "\n").Replace("\\r", "\r").Replace("\\\"", "\"").Replace("\\\\", "\\");
            return text;
        }


        public string OperandText
        {
            get { return (string)GetValue(OperandTextProperty); }
            set { SetValue(OperandTextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OperandText.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandTextProperty =
            DependencyProperty.Register("OperandText", typeof(string), typeof(DefaultOperandController), new UIPropertyMetadata(string.Empty, OnOperandTextChanged));

        private static void OnOperandTextChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            DefaultOperandController elem = obj as DefaultOperandController;
            if (elem != null)
            {
                elem.OnOperandTextChanged(args.OldValue == null ? default(string) : (string)args.OldValue, args.NewValue == null ? default(string) : (string)args.NewValue);
            }
        }
        protected virtual void OnOperandTextChanged(string oldValue, string newValue)
        {
            if (m_skipNextTextChange)
                m_skipNextTextChange = false;
            else
            {
                bool finishingWithSpace = newValue.EndsWith(" ");
                newValue = newValue.Trim();
                if (finishingWithSpace && HostController != null)
                {
                    if (newValue.EndsWith(">="))
                    {
                        this.OperandText = newValue.Substring(0, newValue.Length - 2);
                        HostController.SendComparisonRequest(Comparison.GreaterOrEquals);
                        if (ExplicitResetOperandText != null)
                            ExplicitResetOperandText(this, EventArgs.Empty);
                        return;
                    }
                    else if (newValue.EndsWith("<="))
                    {
                        this.OperandText = newValue.Substring(0, newValue.Length - 2);
                        HostController.SendComparisonRequest(Comparison.LowerOrEquals);
                        if (ExplicitResetOperandText != null)
                            ExplicitResetOperandText(this, EventArgs.Empty);
                        return;
                    }
                    else if (newValue.EndsWith("!="))
                    {
                        this.OperandText = newValue.Substring(0, newValue.Length - 2);
                        HostController.SendComparisonRequest(Comparison.NotEquals);
                        if (ExplicitResetOperandText != null)
                            ExplicitResetOperandText(this, EventArgs.Empty);
                        return;
                    }
                    else if (newValue.EndsWith("="))
                    {
                        this.OperandText = newValue.Substring(0, newValue.Length - 1);
                        HostController.SendComparisonRequest(Comparison.Equals);
                        if (ExplicitResetOperandText != null)
                            ExplicitResetOperandText(this, EventArgs.Empty);
                        return;
                    }
                    else if (newValue.EndsWith(">"))
                    {
                        this.OperandText = newValue.Substring(0, newValue.Length - 1);
                        HostController.SendComparisonRequest(Comparison.Greater);
                        if (ExplicitResetOperandText != null)
                            ExplicitResetOperandText(this, EventArgs.Empty);
                        return;
                    }
                    else if (newValue.EndsWith("<"))
                    {
                        this.OperandText = newValue.Substring(0, newValue.Length - 1);
                        HostController.SendComparisonRequest(Comparison.Lower);
                        if (ExplicitResetOperandText != null)
                            ExplicitResetOperandText(this, EventArgs.Empty);
                        return;
                    }
                    else if (newValue.EndsWith("+"))
                    {
                        this.OperandText = newValue.Substring(0, newValue.Length - 1);
                        var validator = Query.GetValue(QueryValidator.AttachedValidatorProperty) as QueryValidator;
                        validator.Validate();
                        if (ExplicitResetOperandText != null)
                            ExplicitResetOperandText(this, EventArgs.Empty);
                        if (HostController != null)
                            HostController.SendOperatorRequest(NumericOperation.Plus);
                        return;
                    }
                    
                }
                oldValue = oldValue.Trim();
                if (oldValue != newValue)
                {
                    if (IsConstantText(newValue))
                    {
                        var constant = Operand as ConstantOperand;
                        if (constant == null)
                        {
                            constant = new ConstantOperand();
                        }
                        else if (constant.TypeName != "System.String")
                            constant = new ConstantOperand();
                        constant.ConstantValue = PrepareToStoreConstantText(newValue);
                        constant.TypeName = "System.String";
                        if (Operand != constant)
                            Operand = constant;
                    }
                    else if (IsConstantInteger(newValue))
                    {
                        var constant = Operand as ConstantOperand;
                        if (constant == null)
                        {
                            constant = new ConstantOperand();
                        }
                        else if (constant.TypeName != "System.Int32" && constant.TypeName != "System.Double")
                            constant = new ConstantOperand();
                        constant.ConstantValue = int.Parse(newValue, NumberStyles.Integer, CultureInfo.InvariantCulture);
                        constant.TypeName = "System.Int32";
                        if (Operand != constant)
                            Operand = constant;
                    }
                    else if (IsConstantDouble(newValue))
                    {
                        var constant = Operand as ConstantOperand;
                        if (constant == null)
                        {
                            constant = new ConstantOperand();
                        }
                        else if (constant.TypeName != "System.Int32" && constant.TypeName != "System.Double")
                            constant = new ConstantOperand();
                        constant.ConstantValue = double.Parse(newValue, NumberStyles.Float, CultureInfo.InvariantCulture);
                        constant.TypeName = "System.Double";
                        if (Operand != constant)
                            Operand = constant;
                    }
                    else if (IsConstantBool(newValue))
                    {
                        var constant = Operand as ConstantOperand;
                        if (constant == null)
                        {
                            constant = new ConstantOperand();
                        }
                        else if (constant.TypeName != "System.Boolean")
                            constant = new ConstantOperand();
                        constant.ConstantValue = bool.Parse(newValue.ToLower());
                        constant.TypeName = "System.Boolean";
                        if (Operand != constant)
                            Operand = constant;
                    }
                    else
                    {
                        var dso = Operand as DataSourceOperand;
                        if (dso == null)
                        {
                            dso = new DataSourceOperand();
                        }
                        var parts = newValue.Split('.');
                        dso.DataSourceName = parts[0];
                        dso.Transform = null;
                        if (parts.Length == 1)
                            dso.DataSourceProperty = string.Empty;
                        else
                        {
                            
                            StringBuilder propertyBuilder = new StringBuilder();
                            for (int i = 1; i < parts.Length; i++)
                            {

                                if (parts[i] == "ToString()" || parts[i] == "Count()" || parts[i] == "CountDistinct()" || parts[i] == "First()" || parts[i] == "Last()" ||
                                    (parts[i].EndsWith(")") &&
                                            (parts[i].StartsWith("Max(") || parts[i].StartsWith("Min(") || parts[i].StartsWith("Sum(") ||parts[i].StartsWith("Select(")|| parts[i].StartsWith("Average("))))
                                {
                                    Transform transform = ExtractTransform(parts, i);
                                    dso.Transform = transform;
                                    
                                    break;
                                }
                                else
                                {
                                    if (propertyBuilder.Length > 0)
                                        propertyBuilder.Append(".");
                                    propertyBuilder.Append(parts[i]);
                                }
                            }
                            dso.DataSourceProperty = propertyBuilder.ToString();
                        }

                        if (dso != Operand)
                            Operand = dso;
                    }
                }
            }
        }

        private static void ExtractChainedTransformAndOutputProperty(string[] parts, int i, Transform transform)
        {
            StringBuilder transformPropBuilder = new StringBuilder();
            for (int j = i + 1; j < parts.Length; j++)
            {
                if (parts[j] == "ToString()" || parts[i] == "Count()")
                {
                    transform.OutputProperty = transformPropBuilder.ToString();
                    transformPropBuilder.Remove(0, transformPropBuilder.Length);
                    if (parts[i] == "ToString()")
                    {
                        transform.ChainedTransform = new ToStringTransform();
                    }
                    else if (parts[i] == "Count()")
                    {
                        transform.ChainedTransform = new EntitySetTransform { Operation = GroupOperation.Count };
                    }
                    else if (parts[i] == "CountDistinct()")
                    {
                        transform.ChainedTransform = new EntitySetTransform { Operation = GroupOperation.CountDistinct };
                    }
                    else if (parts[i] == "First()")
                    {
                        transform.ChainedTransform = new EntitySetTransform { Operation = GroupOperation.First };
                    }
                    else if (parts[i] == "Last()")
                    {
                        transform.ChainedTransform = new EntitySetTransform { Operation = GroupOperation.Last };
                    }
                    transform = transform.ChainedTransform;

                }
                else
                {
                    if (transformPropBuilder.Length > 0)
                        transformPropBuilder.Append(".");
                    transformPropBuilder.Append(parts[j]);
                }
            }
            transform.OutputProperty = transformPropBuilder.ToString();
        }

        private static Transform ExtractTransform(string[] parts, int i)
        {
            Transform rootTransform = null;
            if (parts[i] == "ToString()")
            {
                rootTransform = new ToStringTransform();
            }
            else if (parts[i] == "Count()")
            {
                rootTransform = new EntitySetTransform { Operation = GroupOperation.Count };
            }
            else if (parts[i] == "CountDistinct()")
            {
                rootTransform = new EntitySetTransform { Operation = GroupOperation.CountDistinct };
            }
            else if (parts[i] == "First()")
            {
                rootTransform = new EntitySetTransform { Operation = GroupOperation.First };
            }
            else if (parts[i] == "Last()")
            {
                rootTransform = new EntitySetTransform { Operation = GroupOperation.Last };
            }
            else if (parts[i].StartsWith("Max("))
            {
                var et = new EntitySetTransform { Operation = GroupOperation.Max };
                et.ProjectionProperty = parts[i].Substring(4, parts[i].Length - 5);
                rootTransform = et;
            }
            else if (parts[i].StartsWith("Min("))
            {
                var et = new EntitySetTransform { Operation = GroupOperation.Min };
                et.ProjectionProperty = parts[i].Substring(4, parts[i].Length - 5);
                rootTransform = et;
            }
            else if (parts[i].StartsWith("Sum("))
            {
                var et = new EntitySetTransform { Operation = GroupOperation.Sum };
                et.ProjectionProperty = parts[i].Substring(4, parts[i].Length - 5);
                rootTransform = et;
            }
            else if (parts[i].StartsWith("Average("))
            {
                var et = new EntitySetTransform { Operation = GroupOperation.Average };
                et.ProjectionProperty = parts[i].Substring(8, parts[i].Length - 9);
                rootTransform = et;
            }
            else if (parts[i].StartsWith("Select("))
            {
                var et = new EntitySetTransform { Operation = GroupOperation.Select };
                et.ProjectionProperty = parts[i].Substring(7, parts[i].Length - 8);
                rootTransform = et;
            }
            ExtractChainedTransformAndOutputProperty(parts, i, rootTransform);
            return rootTransform;
        }

        

        public event EventHandler ExplicitResetOperandText;

        private bool IsConstantText(string text)
        {
            text = text.Trim();
            if (text.StartsWith("\"") && text.EndsWith("\"") && text.Length > 1 && text[text.Length - 2] != '\\')
                return true;

            return false;
        }

        private bool IsConstantInteger(string text)
        {
            text = text.Trim();
            int result = 0;
            return int.TryParse(text, NumberStyles.Integer, CultureInfo.InvariantCulture, out result);
        }

        private bool IsConstantDouble(string text)
        {
            text = text.Trim();
            double result = 0;
            return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out result);
        }

        private bool IsConstantBool(string text)
        {
            text = text.Trim().ToLower();
            return text == "true" || text == "false";
        }

        
    }
}
