﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.WPFControls;
using System.Diagnostics;

namespace VLinq.Editor.Operands
{
    /// <summary>
    /// Interaction logic for DefaultOperandDesigner.xaml
    /// </summary>
    public partial class DefaultOperandDesigner : UserControl, IGiveFocusToSuggestBox
    {
        public DefaultOperandController Controller
        {
            get { return DataContext as DefaultOperandController; }
        }
        public DefaultOperandDesigner()
        {
            InitializeComponent();
        }
       

        public int CaretIndex
        {
            get
            {
                return suggestBox.CaretIndex;
            }
            set
            {
                suggestBox.CaretIndex = value;
            }
        }
        private void SuggestBox_Loaded(object sender, RoutedEventArgs e)
        {
            var resolver = FindResource("Resolver") as DataSourceOperandSuggestionResolver;
            if (resolver != null)
            {
                resolver.Controller = Controller;
            }
        }

        private void DefaultOperandController_ExplicitResetOperandText(object sender, EventArgs e)
        {
            suggestBox.GetBindingExpression(SuggestBox.TextProperty).UpdateTarget();
        }
       


        #region IGiveFocusToSuggestBox Members

        public void GiveFocusToSuggestBox()
        {
            suggestBox.FocusTextBlock();
        }

        #endregion
    }
}
