﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.WPFControls;

namespace VLinq.Editor.Operands
{
    public class NumericOperationController : FrameworkElement
    {
        public class LabelOperatorAssociation
        {
            public string Label { get; set; }
            public NumericOperation Operator { get; set; }

        }

        private static LabelOperatorAssociation[] s_labelOperatorAssociations = new LabelOperatorAssociation[]{
            new LabelOperatorAssociation{Label="+", Operator=NumericOperation.Plus},
            new LabelOperatorAssociation{Label="-",Operator=NumericOperation.Minus},
            new LabelOperatorAssociation{Label="*",Operator=NumericOperation.Multiply},
            new LabelOperatorAssociation{Label="/", Operator=NumericOperation.Divide},
            new LabelOperatorAssociation{Label="%", Operator=NumericOperation.Modulo}};

        public LabelOperatorAssociation[] OperatorsDataSource
        {
            get { return s_labelOperatorAssociations; }
        }

        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(NumericOperationController), new UIPropertyMetadata(null, OnQueryChanged));

        private static void OnQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            NumericOperationController elem = obj as NumericOperationController;
            if (elem != null)
            {
                elem.OnQueryChanged(args.OldValue == null ? default(Query) : (Query)args.OldValue, args.NewValue == null ? default(Query) : (Query)args.NewValue);
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
        }



        public Operand Operand
        {
            get { return (Operand)GetValue(OperandProperty); }
            set { SetValue(OperandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandProperty =
            DependencyProperty.Register("Operand", typeof(Operand), typeof(NumericOperationController), new UIPropertyMetadata(null, OnOperandChanged));

        private static void OnOperandChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            NumericOperationController elem = obj as NumericOperationController;
            if (elem != null)
            {
                elem.OnOperandChanged(args.OldValue == null ? default(Operand) : (Operand)args.OldValue, args.NewValue == null ? default(Operand) : (Operand)args.NewValue);
            }
        }
        protected virtual void OnOperandChanged(Operand oldValue, Operand newValue)
        {
            if (HostController != null && HostController.Operand != newValue)
                HostController.Operand = newValue;
        }



        public OperandHostController HostController
        {
            get { return (OperandHostController)GetValue(HostControllerProperty); }
            set { SetValue(HostControllerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for HostController.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HostControllerProperty =
            DependencyProperty.Register("HostController", typeof(OperandHostController), typeof(NumericOperationController), new UIPropertyMetadata(null, OnHostControllerChanged));

        private static void OnHostControllerChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            NumericOperationController elem = obj as NumericOperationController;
            if (elem != null)
            {
                elem.OnHostControllerChanged(args.OldValue == null ? default(OperandHostController) : (OperandHostController)args.OldValue, args.NewValue == null ? default(OperandHostController) : (OperandHostController)args.NewValue);
            }
        }
        protected virtual void OnHostControllerChanged(OperandHostController oldValue, OperandHostController newValue)
        {
        }


        public NumericOperationOperand AsNumeric
        {
            get { return Operand as NumericOperationOperand; }
        }

        public NumericOperationController()
        {
            DeleteMemberCommand = new CustomParameterizedCommand<Operand> { IsEnabled = true };
            DeleteMemberCommand.Executing += new EventHandler<ParameterizedCommandEventArgs<Operand>>(DeleteMemberCommand_Executing);
        }

        void DeleteMemberCommand_Executing(object sender, ParameterizedCommandEventArgs<Operand> e)
        {
            AsNumeric.Operands.Remove(e.Parameter);
            if (AsNumeric.Operands.Count == 1)
                HostController.Operand = AsNumeric.Operands[0];
        }

        public CustomParameterizedCommand<Operand> DeleteMemberCommand { get; set; }
    }
}
