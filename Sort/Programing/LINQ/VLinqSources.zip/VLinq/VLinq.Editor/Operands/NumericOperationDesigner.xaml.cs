﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.Processing;

namespace VLinq.Editor.Operands
{
    /// <summary>
    /// Interaction logic for NumericOperationDesigner.xaml
    /// </summary>
    public partial class NumericOperationDesigner : UserControl
    {
        public NumericOperationController Controller
        {
            get { return DataContext as NumericOperationController; }
        }
        public NumericOperationDesigner()
        {
            InitializeComponent();
        }
        public int Count
        {
            get { return operandList.Items.Count; }
        }
        public void FocusAt(int index)
        {
            if (index < Count)
            {
                var container = operandList.ItemContainerGenerator.ContainerFromIndex(index) as FrameworkElement;
                container.ApplyTemplate();
                var templateRoot = VisualTreeHelper.GetChild(container, 0) as FrameworkElement;
                if (templateRoot != null)
                {
                    var host = templateRoot.FindName("OperandHost") as OperandHost;
                    if (host != null)
                    {
                        host.Focus();
                    }
                }
            }
        }

        private void OperandHost_Loaded(object sender, RoutedEventArgs e)
        {
            var templateInstance = sender as FrameworkElement;
            var host = templateInstance.FindName("OperandHost") as OperandHost;
            var container = VisualTreeHelper.GetParent(templateInstance);
            host.Controller.Query = Controller.Query;
            var operand = operandList.ItemContainerGenerator.ItemFromContainer(container) as Operand ;
            host.Controller.Operand = operand;
            var index = operandList.ItemContainerGenerator.IndexFromContainer(container);
            host.Controller.OperandChanged += delegate
            {
                Controller.AsNumeric.Operands[index] = host.Controller.Operand;
            };
            host.Controller.OperatorRequest += delegate(object s, OperatorRequestEventArgs ore)
            {
                if (ore.Operator == Controller.AsNumeric.Operation)
                {
                    var td = ValidTimeProperties.GetReturnType(host.Operand);
                    if (td != null && td.IsNumeric)
                    {
                        ore.Handled = true;
                        Controller.AsNumeric.Operands.Insert(index + 1, new ConstantOperand());

                    }
                }
            };
        }
    }
}
