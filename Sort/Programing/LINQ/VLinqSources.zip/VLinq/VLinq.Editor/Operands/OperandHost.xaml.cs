﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using VLinq.WPFControls;

namespace VLinq.Editor.Operands
{
    /// <summary>
    /// Interaction logic for OperandHost.xaml
    /// </summary>
    public partial class OperandHost : UserControl
    {
        public OperandHostController Controller
        {
            get
            {
                return DataContext as OperandHostController;
            }
        }

        public OperandHost()
        {
            InitializeComponent();
            Controller.OperandChanged += new DependencyPropertyChangedEventHandler(Controller_OperandChanged);
        }

        void Controller_OperandChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            Operand = Controller.Operand;
        }



        public Operand Operand
        {
            get { return (Operand)GetValue(OperandProperty); }
            set { SetValue(OperandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandProperty =
            DependencyProperty.Register("Operand", typeof(Operand), typeof(OperandHost), new UIPropertyMetadata(null, OnOperandChanged));

        private static void OnOperandChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            OperandHost elem = obj as OperandHost;
            if (elem != null)
            {
                elem.OnOperandChanged(args.OldValue == null ? default(Operand) : (Operand)args.OldValue, args.NewValue == null ? default(Operand) : (Operand)args.NewValue);
            }
        }
        protected virtual void OnOperandChanged(Operand oldValue, Operand newValue)
        {
            if(Controller.Operand != newValue)
                Controller.Operand = newValue;
            if(newValue != null)
                DesignTimeProperties.SetEditorFor(newValue, this);
            if (m_currentDesigner != null)
                m_wasFocused = m_currentDesigner.IsKeyboardFocusWithin;
        }
        private bool m_wasFocused = false;
        

        private FrameworkElement m_currentDesigner;

        private void DefaultOperandDesignerLoaded(object sender, RoutedEventArgs e)
        {
            var designer = sender as DefaultOperandDesigner;
            designer.Controller.Query = Controller.Query;
            designer.Controller.HostController = Controller;
            designer.Controller.Operand = Controller.Operand;
            if (m_currentDesigner != null)
            {
                if (m_wasFocused)
                {
                    m_wasFocused = false;

                    var txtBox = designer.FindFirstVisualDescendantOf<TextBox>(VisualChildExplorationMode.Vertical);
                    if (txtBox != null)
                        txtBox.Focus();
                    var asDefault = m_currentDesigner as DefaultOperandDesigner;
                    if (asDefault != null)
                    {
                        designer.CaretIndex = asDefault.CaretIndex;
                    }
                }
            }
            m_currentDesigner = designer;
        }

        public void FocusOnLoad()
        {
            m_wasFocused = true;
        }

        private void ConcatOperationDesignerLoaded(object sender, RoutedEventArgs e)
        {
            var designer = sender as ConcatOperationDesigner;
            designer.Controller.Query = Controller.Query;
            designer.Controller.HostController = Controller;
            designer.Controller.Operand = Controller.Operand;
            
            m_currentDesigner = designer;
            if(m_wasFocused)
                designer.FocusAt(designer.Count - 1);
        }

      

        private void NumericOperationDesignerLoaded(object sender, RoutedEventArgs e)
        {
            var designer = sender as NumericOperationDesigner;
            designer.Controller.Query = Controller.Query;
            designer.Controller.HostController = Controller;
            designer.Controller.Operand = Controller.Operand;

            m_currentDesigner = designer;
            designer.FocusAt(designer.Count - 1);
        }
    }
    public interface IGiveFocusToSuggestBox
    {
        void GiveFocusToSuggestBox();
    }
}
