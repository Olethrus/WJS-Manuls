﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.Processing;

namespace VLinq.Editor.Operands
{
    public class OperandHostController:FrameworkElement
    {
        public bool IsReady
        {
            get
            {
                return Query != null;
            }
        }

        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(OperandHostController), new UIPropertyMetadata(null, OnQueryChanged));

        private static void OnQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            OperandHostController elem = obj as OperandHostController;
            if (elem != null)
            {
                elem.OnQueryChanged(args.OldValue == null ? default(Query) : (Query)args.OldValue, args.NewValue == null ? default(Query) : (Query)args.NewValue);
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
        }



        public Operand Operand
        {
            get { return (Operand)GetValue(OperandProperty); }
            set { SetValue(OperandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Operand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OperandProperty =
            DependencyProperty.Register("Operand", typeof(Operand), typeof(OperandHostController), new UIPropertyMetadata(null, OnOperandChanged));

        private static void OnOperandChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            OperandHostController elem = obj as OperandHostController;
            if (elem != null)
            {
                elem.OnOperandChanged(args.OldValue == null ? default(Operand) : (Operand)args.OldValue, args.NewValue == null ? default(Operand) : (Operand)args.NewValue);
            }
        }
        protected virtual void OnOperandChanged(Operand oldValue, Operand newValue)
        {
            if (OperandChanged != null)
            {
                OperandChanged(this, new DependencyPropertyChangedEventArgs(OperandProperty, oldValue, newValue));
            }
        }
        public void SendComparisonRequest(Comparison comparison)
        {
            if (ComparisonRequest != null)
                ComparisonRequest(this, new ComparisonRequestEventArgs { Operator = comparison });
        }

        public void SendOperatorRequest(NumericOperation op)
        {
            if (OperatorRequest != null)
            {
                var args = new OperatorRequestEventArgs { Operator = op };
                OperatorRequest(this, args);
                if (args.Handled)
                    return;
            }
            var oldOp = Operand;
            switch (op)
            {
                case NumericOperation.Plus:
                        var newOp = new ConcatOperationOperand();
                        DesignTimeProperties.SetEditorFor(oldOp, null);
                        Operand = newOp;
                        
                        newOp.Operands.Add(oldOp);
                        newOp.Operands.Add(new ConstantOperand { TypeName = "System.String", ConstantValue = "" });
                        
                    break;
            
            }
        }

        public event DependencyPropertyChangedEventHandler OperandChanged;
        public event EventHandler<ComparisonRequestEventArgs> ComparisonRequest;
        public event EventHandler<OperatorRequestEventArgs> OperatorRequest;

        public bool IsAfterGroupBy { get; set; }
        
    }
}
