﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;

namespace VLinq.Editor.Operands
{
    public class OperandHostTemplateSelector : DataTemplateSelector
    {
        public DataTemplate DefaultTemplate { get; set; }
        public DataTemplate ConcatOperandTemplate { get; set; }
        public DataTemplate NumericOperationTemplate { get; set; }
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            if (item is ConcatOperationOperand)
                return ConcatOperandTemplate;
            else if (item is NumericOperationOperand)
                return NumericOperationTemplate;
            return DefaultTemplate;
        }
    }
}
