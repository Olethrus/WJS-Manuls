﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Editor.Operands
{
    public class OperatorRequestEventArgs :EventArgs
    {
        public bool Handled { get; set; }
        public NumericOperation Operator { get; set; }
    }
}
