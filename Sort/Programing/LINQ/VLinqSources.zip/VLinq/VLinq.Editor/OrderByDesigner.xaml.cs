﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.Processing;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for OrderByDesigner.xaml
    /// </summary>
    public partial class OrderByDesigner : UserControl
    {
        public OrderByDesigner()
        {
            InitializeComponent();
            DeleteCommand = new CustomParameterizedCommand<OrderEntry> { IsEnabled = true };
            DeleteCommand.Executing += new EventHandler<ParameterizedCommandEventArgs<OrderEntry>>(DeleteCommand_Executing);

            UpCommand = new CustomParameterizedCommand<OrderEntry> { IsEnabled = true };
            UpCommand.Executing += new EventHandler<ParameterizedCommandEventArgs<OrderEntry>>(UpCommand_Executing);

            DownCommand = new CustomParameterizedCommand<OrderEntry> { IsEnabled = true };
            DownCommand.Executing += new EventHandler<ParameterizedCommandEventArgs<OrderEntry>>(DownCommand_Executing);

            Clear = new CustomCommand { IsEnabled = true };
            Clear.Executing += new EventHandler(Clear_Executing);
        }

        void Clear_Executing(object sender, EventArgs e)
        {
            if (Query != null)
                Query.OrderBy.Clear();
        }

        public CustomCommand Clear { get; set; }

        void DownCommand_Executing(object sender, ParameterizedCommandEventArgs<OrderEntry> e)
        {
            var index = Query.OrderBy.IndexOf(e.Parameter);
            if (index < Query.OrderBy.Count - 1)
            {
                Query.OrderBy.Move(index, index + 1);
            }
        }

        void UpCommand_Executing(object sender, ParameterizedCommandEventArgs<OrderEntry> e)
        {
            var index = Query.OrderBy.IndexOf(e.Parameter);
            if (index > 0)
            {
                Query.OrderBy.Move(index, index - 1);
            }
        }

        void DeleteCommand_Executing(object sender, ParameterizedCommandEventArgs<OrderEntry> e)
        {
            Query.OrderBy.Remove(e.Parameter);
        }



        public CustomParameterizedCommand<OrderEntry> DownCommand
        {
            get { return (CustomParameterizedCommand<OrderEntry>)GetValue(DownCommandProperty); }
            set { SetValue(DownCommandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DownCommand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DownCommandProperty =
            DependencyProperty.Register("DownCommand", typeof(CustomParameterizedCommand<OrderEntry>), typeof(OrderByDesigner), new UIPropertyMetadata(null));



        public CustomParameterizedCommand<OrderEntry> UpCommand
        {
            get { return (CustomParameterizedCommand<OrderEntry>)GetValue(UpCommandProperty); }
            set { SetValue(UpCommandProperty, value); }
        }

        // Using a DependencyProperty as the backing store for UpCommand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty UpCommandProperty =
            DependencyProperty.Register("UpCommand", typeof(CustomParameterizedCommand<OrderEntry>), typeof(OrderByDesigner), new UIPropertyMetadata(null));



        public CustomParameterizedCommand<OrderEntry> DeleteCommand
        {
            get { return (CustomParameterizedCommand<OrderEntry>)GetValue(DeleteCommandProperty); }
            set { SetValue(DeleteCommandProperty, value); }
        }
        

        // Using a DependencyProperty as the backing store for DeleteCommand.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DeleteCommandProperty =
            DependencyProperty.Register("DeleteCommand", typeof(CustomParameterizedCommand<OrderEntry>), typeof(OrderByDesigner), new UIPropertyMetadata(null));


        public Query Query
        {
            get { return DataContext as Query; }
        }

        private void Grid_DragEnter(object sender, DragEventArgs e)
        {
            if (IsDataObjectValid(e.Data))
            {
                e.Effects = DragDropEffects.Copy;
            }
            else
                e.Effects = DragDropEffects.None;

            e.Handled = true;
        }

        private bool IsDataObjectValid(IDataObject dataObject)
        {
            if (dataObject.GetDataPresent(DataSourceController.DataSourcePropertyFormat) )
            {
                string[] parts = dataObject.GetData(DataSourceController.DataSourcePropertyFormat).ToString().Split('|');
                if (parts.Length != 2)
                    return false;
                var parentDS = Query.FindDataSource(parts[0]);

                if (parentDS == null)
                    return false;
                var parentTD = ValidTimeProperties.GetReturnType(parentDS);
                if (parentTD == null)
                    return false;
                var propDesc = parentTD.GetProperty(parts[1]);
                if (propDesc == null)
                    return false;
                return propDesc.TypeDescription.IsScalar;
            }
            return false;
        }

        private void Grid_DragOver(object sender, DragEventArgs e)
        {
            if (IsDataObjectValid(e.Data))
            {
                e.Effects = DragDropEffects.Copy;
            }
            else
                e.Effects = DragDropEffects.None;

            e.Handled = true;
        }

        private void Grid_Drop(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataSourceController.DataSourcePropertyFormat))
            {
                string[] parts = e.Data.GetData(DataSourceController.DataSourcePropertyFormat).ToString().Split('|');
                if (parts.Length != 2)
                    return;
                var parentDS = Query.FindDataSource(parts[0]);

                if (parentDS == null)
                    return;
                var parentTD = ValidTimeProperties.GetReturnType(parentDS);
                if (parentTD == null)
                    return;
                var propDesc = parentTD.GetProperty(parts[1]);
                if (propDesc == null)
                    return;
                if (propDesc.TypeDescription.IsScalar)
                {
                    var orderEntry = new OrderEntry { DataSourceName = parts[0], DataSourceProperty = parts[1], Descending = false };
                    Query.OrderBy.Add(orderEntry);
                }
            }
            e.Handled = true;
        }

        private void StackPanel_Loaded(object sender, RoutedEventArgs e)
        {
            var asFe = sender as FrameworkElement;
            if (asFe != null)
            {
                var dc = asFe.DataContext as DependencyObject;
                if (dc != null)
                    DesignTimeProperties.SetEditorFor(dc, asFe);
            }
        }
    }

    public class BoolToOrderDirectionLabelConverter : IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is bool)
            {
                if ((bool)value)
                {
                    return "Descending";
                }
                
            }

            return "Ascending";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if((value as string)=="Descending")
                return true;
            else 
                return false;
        }

        #endregion
    }
}
