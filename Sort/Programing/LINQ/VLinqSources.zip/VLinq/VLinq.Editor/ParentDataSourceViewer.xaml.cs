﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.Processing;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for ParentDataSourceViewer.xaml
    /// </summary>
    public partial class ParentDataSourceViewer : UserControl
    {
        public ParentDataSourceViewer()
        {
            InitializeComponent();
            
        }

        private DataSourceController Controller
        {
            get { return DataContext as DataSourceController; }
        }
        /// <summary>
        /// Handles initialization of Drag and drop operation from an existing DataSource property
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Property_MouseLeave(object sender, System.Windows.Input.MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed
                && e.RightButton == MouseButtonState.Released
                && e.MiddleButton == MouseButtonState.Released
                && Controller != null
                && Controller.Mode == DataSourceControllerMode.Entities)
            {
                FrameworkElement elem = sender as FrameworkElement;
                var propDesc = elem.DataContext as PropertyDescription;
                if (propDesc != null)
                {
                    string propName = propDesc.Name;
                    DependencyObject parent = VisualTreeHelper.GetParent(elem);
                    object oDataContext = parent.GetValue(FrameworkElement.DataContextProperty);
                    while (oDataContext == elem.DataContext)
                    {
                        parent = VisualTreeHelper.GetParent(parent);
                        oDataContext = parent.GetValue(FrameworkElement.DataContextProperty);
                    }
                    DataSource ds = oDataContext as DataSource;
                    if (ds != null)
                    {
                        DragDrop.DoDragDrop(elem, new DataObject(DataSourceController.DataSourcePropertyFormat, string.Format("{0}|{1}", ds.Name, propName)), DragDropEffects.Copy);

                    }
                }
            }
        }
    }
}
