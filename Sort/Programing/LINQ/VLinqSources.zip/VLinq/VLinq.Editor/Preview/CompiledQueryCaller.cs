﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Editor.Preview
{
    public class CompiledQueryCaller
    {
        public Delegate ToCall { get; set; }
        public object Call(object[] parameters)
        {
            return ToCall.Method.Invoke(ToCall.Target, parameters);
        }
    }
}
