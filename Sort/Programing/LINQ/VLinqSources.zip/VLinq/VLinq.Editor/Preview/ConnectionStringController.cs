﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Collections.ObjectModel;

namespace VLinq.Editor.Preview
{
    public class ConnectionStringController : DependencyObject
    {
        public ConnectionStringController()
        {
            if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))
            {
                ConnectionStringProviders = new ObservableCollection<ConnectionStringProvider>{new ConnectionStringProvider(),
                    new ConnectionStringProvider()};
            }
        }

        public QueryBag QueryBag
        {
            get { return (QueryBag)GetValue(QueryBagProperty); }
            set { SetValue(QueryBagProperty, value); }
        }

        // Using a DependencyProperty as the backing store for QueryBag.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryBagProperty =
            DependencyProperty.Register("QueryBag", typeof(QueryBag), typeof(ConnectionStringController), new UIPropertyMetadata(null, OnQueryBagChanged));

        private static void OnQueryBagChanged(DependencyObject sender, DependencyPropertyChangedEventArgs args)
        {
            var asCtrl = sender as ConnectionStringController;
            if (asCtrl != null)
            {
                asCtrl.OnQueryBagChanged(args.OldValue as QueryBag, args.NewValue as QueryBag);
            }
        }
        protected virtual void OnQueryBagChanged(QueryBag oldValue, QueryBag newValue)
        {
            if (newValue != null)
            {
                var provider = newValue.GetConnectionStringProvider();
                if (provider == null)
                {
                    provider = new ConnectionStringProvider();
                    newValue.SetConnectionStringProvider(provider);
                }
                if (provider.GetType() == typeof(ConnectionStringProvider))
                {
                    var asCSP = provider as ConnectionStringProvider;
                    var copy = new ConnectionStringProvider { ConnectionString = asCSP.ConnectionString };
                    ConnectionStringProviders = new ObservableCollection<ConnectionStringProvider> { copy, new ServerExplorerBasedConnectionStringProvider() };
                    SelectedProvider = copy;
                }
                else
                {
                    var asServerBased = provider as ServerExplorerBasedConnectionStringProvider;
                    var copy = new ServerExplorerBasedConnectionStringProvider { SelectedConnection = asServerBased.SelectedConnection };
                    ConnectionStringProviders = new ObservableCollection<ConnectionStringProvider> { new ConnectionStringProvider(), copy };
                    SelectedProvider = copy;
                }
            }
        }



        public ConnectionStringProvider SelectedProvider
        {
            get { return (ConnectionStringProvider)GetValue(SelectedProviderProperty); }
            set { SetValue(SelectedProviderProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SelectedProvider.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectedProviderProperty =
            DependencyProperty.Register("SelectedProvider", typeof(ConnectionStringProvider), typeof(ConnectionStringController), new UIPropertyMetadata(null));




        public ObservableCollection<ConnectionStringProvider> ConnectionStringProviders
        {
            get { return (ObservableCollection<ConnectionStringProvider>)GetValue(ConnectionStringProvidersProperty); }
            set { SetValue(ConnectionStringProvidersProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ConnectionStringProviders.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ConnectionStringProvidersProperty =
            DependencyProperty.Register("ConnectionStringProviders", typeof(ObservableCollection<ConnectionStringProvider>), typeof(ConnectionStringController), new UIPropertyMetadata(null));



    }
}
