﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace VLinq.Editor.Preview
{
    public partial class ConnectionStringEditorForm : Form
    {
        public ConnectionStringProvider Value
        {
            get
            {
                return connectionStringDesigner1.Controller.SelectedProvider;
            }
        }
        public QueryBag QueryBag
        {
            get
            {
                return connectionStringDesigner1.Controller.QueryBag;
            }
            set
            {
                connectionStringDesigner1.Controller.QueryBag = value;
            }
        }
        public ConnectionStringEditorForm()
        {
            InitializeComponent();
        }
    }
}
