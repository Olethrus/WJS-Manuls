﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Editor.Preview
{
    public class ConnectionStringProvider
    {
        public string ConnectionString { get; set; }
        public virtual string GetConnectionString()
        {
            return ConnectionString;
        }

        public override string ToString()
        {
            return GetConnectionString();
        }
    }
}
