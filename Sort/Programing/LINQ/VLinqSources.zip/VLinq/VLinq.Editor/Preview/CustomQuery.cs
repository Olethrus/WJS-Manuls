﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Reflection;
using System.Collections.ObjectModel;
using System.Globalization;
using System.ComponentModel;

namespace VLinq.Editor.Preview
{
    public class CustomQuery : DependencyObject, INamed
    {


        public string Name
        {
            get { return (string)GetValue(NameProperty); }
            set { SetValue(NameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Name.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NameProperty =
            DependencyProperty.Register("Name", typeof(string), typeof(CustomQuery), new UIPropertyMetadata(null));



        public string Description
        {
            get { return DesignTimeProperties.GetDescription(this); }
            set { DesignTimeProperties.SetDescription(this,value); }
        }



        public bool IsCustom { get { return true; } }

        public MethodInfo MethodInfo
        {
            get { return (MethodInfo)GetValue(MethodInfoProperty); }
            set { SetValue(MethodInfoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MethodInfo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MethodInfoProperty =
            DependencyProperty.Register("MethodInfo", typeof(MethodInfo), typeof(CustomQuery), new UIPropertyMetadata(null, OnMethodInfoChanged));

        private static void OnMethodInfoChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            CustomQuery elem = obj as CustomQuery;
            if (elem != null)
            {
                elem.OnMethodInfoChanged(args.OldValue == null ? default(MethodInfo) : (MethodInfo)args.OldValue, args.NewValue == null ? default(MethodInfo) : (MethodInfo)args.NewValue);
            }
        }
        protected virtual void OnMethodInfoChanged(MethodInfo oldValue, MethodInfo newValue)
        {
            StringBuilder descriptionBuilder = new StringBuilder();
            if (newValue != null)
            {
                descriptionBuilder.Append(newValue.Name);
                descriptionBuilder.Append("(");
                var parameters = newValue.GetParameters();
                for (int i = 0; i < parameters.Length; i++)
                {
                    if (i > 0)
                        descriptionBuilder.Append(", ");
                    descriptionBuilder.AppendFormat(CultureInfo.InvariantCulture, "{0} {1}", parameters[i].ParameterType.Name, parameters[i].Name);
                }
                descriptionBuilder.Append(")");
                var descAttributeObj = newValue.GetCustomAttributes(typeof(DescriptionAttribute), false);
                if (descAttributeObj != null && descAttributeObj.Length > 0)
                {
                    var descAttribute = descAttributeObj[0] as DescriptionAttribute;
                    if (descAttribute != null)
                    {
                        descriptionBuilder.AppendFormat(CultureInfo.InvariantCulture, ": {0}", descAttribute.Description);
                    }
                }
            }
            Description = descriptionBuilder.ToString();
        }


        public ParameterInfo[] QueryParameters
        {
            get { return MethodInfo.GetParameters(); }
        }
    }

    public class CustomQueryCollection : ObservableCollection<CustomQuery>
    {
    }
}
