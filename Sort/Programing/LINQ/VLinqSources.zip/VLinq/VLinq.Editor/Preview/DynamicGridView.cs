﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows;

namespace VLinq.Editor.Preview
{
    public class DynamicGridView : GridView
    {


        public Type TypeOfItems
        {
            get { return (Type)GetValue(TypeOfItemsProperty); }
            set { SetValue(TypeOfItemsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TypeOfItems.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TypeOfItemsProperty =
            DependencyProperty.Register("TypeOfItems", typeof(Type), typeof(DynamicGridView), new UIPropertyMetadata(null, OnTypeOfItemsChanged));

        private static void OnTypeOfItemsChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            DynamicGridView elem = obj as DynamicGridView;
            if (elem != null)
            {
                elem.OnTypeOfItemsChanged(args.OldValue == null ? default(Type) : (Type)args.OldValue, args.NewValue == null ? default(Type) : (Type)args.NewValue);
            }
        }
        protected virtual void OnTypeOfItemsChanged(Type oldValue, Type newValue)
        {
            this.Columns.Clear();
            if (newValue != null)
            {
                foreach (var propInfo in newValue.GetProperties(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Instance))
                {
                    Columns.Add( new GridViewColumn { Header = propInfo.Name, DisplayMemberBinding = new Binding(propInfo.Name) });

                }
            }
        }


    }
}
