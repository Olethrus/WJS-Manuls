﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VLinq.Editor.Preview
{
    /// <summary>
    /// Interaction logic for GeneratedCodeRenderer.xaml
    /// </summary>
    public partial class GeneratedCodeRenderer : UserControl
    {
        public GeneratedCodeRenderer()
        {
            InitializeComponent();
        }



        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(GeneratedCodeRenderer), new UIPropertyMetadata(null, OnQueryChanged));

        private static void OnQueryChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            GeneratedCodeRenderer elem = obj as GeneratedCodeRenderer;
            if (elem != null)
            {
                elem.OnQueryChanged(args.OldValue == null ? default(Query) : (Query)args.OldValue, args.NewValue == null ? default(Query) : (Query)args.NewValue);
            }
        }
        protected virtual void OnQueryChanged(Query oldValue, Query newValue)
        {
            if (newValue != null)
            {
                var csFormatter = new VLinq.Processing.CSharpQueryFormatter<VLinq.VSIntegration.DynamicTypeServiceDescriptionBuilder>();
                try
                {
                    CSCode = csFormatter.FormatQuery(newValue).Replace("\t","   ");
                }
                catch { }

                var vbFormatter = new VLinq.Processing.VBQueryFormatter<VLinq.VSIntegration.DynamicTypeServiceDescriptionBuilder>();
                try
                {
                    VBCode = vbFormatter.FormatQuery(newValue).Replace("\t", "   ");
                }
                catch { }
            }
        }



        public string CSCode
        {
            get { return (string)GetValue(CSCodeProperty); }
            set { SetValue(CSCodeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CSCode.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CSCodeProperty =
            DependencyProperty.Register("CSCode", typeof(string), typeof(GeneratedCodeRenderer), new UIPropertyMetadata("No code available"));



        public string VBCode
        {
            get { return (string)GetValue(VBCodeProperty); }
            set { SetValue(VBCodeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for VBCode.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty VBCodeProperty =
            DependencyProperty.Register("VBCode", typeof(string), typeof(GeneratedCodeRenderer), new UIPropertyMetadata("No code available"));

        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (codeViewer != null)
            {
                var combo = (ComboBox)sender;
                if (combo.SelectedIndex == 0)
                    codeViewer.SetBinding(TextBox.TextProperty, new Binding { Source = this, Path = new PropertyPath("CSCode") });
                else if (combo.SelectedIndex == 1)
                {
                    codeViewer.SetBinding(TextBox.TextProperty, new Binding { Source = this, Path = new PropertyPath("VBCode") });
                }
            }
        }


    }
}
