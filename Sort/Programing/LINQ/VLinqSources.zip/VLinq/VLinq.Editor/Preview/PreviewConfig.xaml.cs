﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VLinq.Editor.Preview
{
    /// <summary>
    /// Interaction logic for PreviewConfig.xaml
    /// </summary>
    public partial class PreviewConfig : UserControl
    {
        public PreviewConfigController Controller
        {
            get { return DataContext as PreviewConfigController; }
        }
        public PreviewConfig()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            if (m_showingPreview)
            {
                m_showingPreview = false;
                previewerContainer.Child = null;
            }
            else if (CloseClicked != null)
                CloseClicked(this, EventArgs.Empty);
        }
        public event EventHandler CloseClicked;

        private void PreviewInfoItemTemplateLoaded(object sender, RoutedEventArgs e)
        {
            var container = sender as FrameworkElement;
            var paramEditor = container.FindName("paramEditor") as PreviewInfoParamsEditor;
            paramEditor.PreviewInfoItem = container.DataContext as PreviewInfoItem;
        }

        private void LaunchPreview_Click(object sender, RoutedEventArgs e)
        {
            m_showingPreview = true;
            var previewer = new Previewer();
            previewer.Controller.PreviewInfoItems = from p in Controller.PreviewInfos
                                                    where PreviewConfigController.GetIncludeInPreviewBatch(p)
                                                    select p;
            this.previewerContainer.Child = previewer;
            
        }
        private bool m_showingPreview = false;

        private void btnBrowseMappingFile_Click(object sender, RoutedEventArgs e)
        {
            var initialValue = PreviewProperties.GetExternalMappingSource(Controller.QueryBag);
            var ofd = new System.Windows.Forms.OpenFileDialog();
            ofd.FileName = initialValue;

            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                PreviewProperties.SetExternalMappingSource(Controller.QueryBag,ofd.FileName);
            }
        }
    }
}
