﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Collections.ObjectModel;

namespace VLinq.Editor.Preview
{
    public class PreviewConfigController : DependencyObject
    {


        public static PrimitiveTypeConverter GetAssociatedConverter(DependencyObject obj)
        {
            return (PrimitiveTypeConverter)obj.GetValue(AssociatedConverterProperty);
        }

        public static void SetAssociatedConverter(DependencyObject obj, PrimitiveTypeConverter value)
        {
            obj.SetValue(AssociatedConverterProperty, value);
        }

        // Using a DependencyProperty as the backing store for AssociatedConverter.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AssociatedConverterProperty =
            DependencyProperty.RegisterAttached("AssociatedConverter", typeof(PrimitiveTypeConverter), typeof(PreviewConfigController), new UIPropertyMetadata(null));



        public static bool GetIsPreviewInfoSupported(DependencyObject obj)
        {
            return (bool)obj.GetValue(IsPreviewInfoSupportedProperty);
        }

        public static void SetIsPreviewInfoSupported(DependencyObject obj, bool value)
        {
            obj.SetValue(IsPreviewInfoSupportedProperty, value);
        }

        // Using a DependencyProperty as the backing store for IsPreviewInfoSupported.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsPreviewInfoSupportedProperty =
            DependencyProperty.RegisterAttached("IsPreviewInfoSupported", typeof(bool), typeof(PreviewConfigController), new UIPropertyMetadata(false));



        public static bool GetIncludeInPreviewBatch(DependencyObject obj)
        {
            return (bool)obj.GetValue(IncludeInPreviewBatchProperty);
        }

        public static void SetIncludeInPreviewBatch(DependencyObject obj, bool value)
        {
            obj.SetValue(IncludeInPreviewBatchProperty, value);
        }

        // Using a DependencyProperty as the backing store for IncludeInPreviewBatch.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IncludeInPreviewBatchProperty =
            DependencyProperty.RegisterAttached("IncludeInPreviewBatch", typeof(bool), typeof(PreviewConfigController), new ChangeBublingMetadata(true));



        public static bool GetPreviewPaginatedVersion(DependencyObject obj)
        {
            return (bool)obj.GetValue(PreviewPaginatedVersionProperty);
        }

        public static void SetPreviewPaginatedVersion(DependencyObject obj, bool value)
        {
            obj.SetValue(PreviewPaginatedVersionProperty, value);
        }

        // Using a DependencyProperty as the backing store for PreviewPaginatedVersion.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PreviewPaginatedVersionProperty =
            DependencyProperty.RegisterAttached("PreviewPaginatedVersion", typeof(bool), typeof(PreviewConfigController), new UIPropertyMetadata(true));



        public static int GetFirstRowIndex(DependencyObject obj)
        {
            return (int)obj.GetValue(FirstRowIndexProperty);
        }

        public static void SetFirstRowIndex(DependencyObject obj, int value)
        {
            obj.SetValue(FirstRowIndexProperty, value);
        }

        // Using a DependencyProperty as the backing store for FirstRowIndex.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FirstRowIndexProperty =
            DependencyProperty.RegisterAttached("FirstRowIndex", typeof(int), typeof(PreviewConfigController), new UIPropertyMetadata(0));



        public static int GetPageSize(DependencyObject obj)
        {
            return (int)obj.GetValue(PageSizeProperty);
        }

        public static void SetPageSize(DependencyObject obj, int value)
        {
            obj.SetValue(PageSizeProperty, value);
        }

        // Using a DependencyProperty as the backing store for PageSize.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PageSizeProperty =
            DependencyProperty.RegisterAttached("PageSize", typeof(int), typeof(PreviewConfigController), new UIPropertyMetadata(5));



        public QueryBag QueryBag
        {
            get { return (QueryBag)GetValue(QueryBagProperty); }
            set { SetValue(QueryBagProperty, value); }
        }

        // Using a DependencyProperty as the backing store for QueryBag.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryBagProperty =
            DependencyProperty.Register("QueryBag", typeof(QueryBag), typeof(PreviewConfigController), new UIPropertyMetadata(null, OnQueryBagChanged));

        private static void OnQueryBagChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PreviewConfigController elem = obj as PreviewConfigController;
            if (elem != null)
            {
                elem.OnQueryBagChanged(args.OldValue == null ? default(QueryBag) : (QueryBag)args.OldValue, args.NewValue == null ? default(QueryBag) : (QueryBag)args.NewValue);
            }
        }
        protected virtual void OnQueryBagChanged(QueryBag oldValue, QueryBag newValue)
        {
            if (newValue != null)
            {
                var provider = newValue.GetConnectionStringProvider();
                if(provider == null)
                {
                    provider = new ConnectionStringProvider();
                    newValue.SetConnectionStringProvider(provider);
                }
                if(provider.GetType() == typeof(ConnectionStringProvider))
                    ConnectionStringProviders = new ObservableCollection<ConnectionStringProvider> { provider, new ServerExplorerBasedConnectionStringProvider() };
                else
                    ConnectionStringProviders = new ObservableCollection<ConnectionStringProvider> { new ConnectionStringProvider(), provider };
            }
        }



        public ObservableCollection<ConnectionStringProvider> ConnectionStringProviders
        {
            get { return (ObservableCollection<ConnectionStringProvider>)GetValue(ConnectionStringProvidersProperty); }
            set { SetValue(ConnectionStringProvidersProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ConnectionStringProviders.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ConnectionStringProvidersProperty =
            DependencyProperty.Register("ConnectionStringProviders", typeof(ObservableCollection<ConnectionStringProvider>), typeof(PreviewConfigController), new UIPropertyMetadata(null));







        public List<PreviewInfoItem> PreviewInfos
        {
            get { return (List<PreviewInfoItem>)GetValue(PreviewInfosProperty); }
            set { SetValue(PreviewInfosProperty, value); }
        }

        // Using a DependencyProperty as the backing store for PreviewInfos.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PreviewInfosProperty =
            DependencyProperty.Register("PreviewInfos", typeof(List<PreviewInfoItem>), typeof(PreviewConfigController), new UIPropertyMetadata(null, OnPreviewInfosChanged));

        private static void OnPreviewInfosChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PreviewConfigController elem = obj as PreviewConfigController;
            if (elem != null)
            {
                elem.OnPreviewInfosChanged(args.OldValue == null ? default(List<PreviewInfoItem>) : (List<PreviewInfoItem>)args.OldValue, args.NewValue == null ? default(List<PreviewInfoItem>) : (List<PreviewInfoItem>)args.NewValue);
            }
        }
        protected virtual void OnPreviewInfosChanged(List<PreviewInfoItem> oldValue, List<PreviewInfoItem> newValue)
        {
            if (newValue != null)
            {
                foreach (var item in newValue)
                {
                    var isSupported = true;

                    foreach (var paramInfo in item.MethodParametersInfo)
                    {
                        if (!PreviewProperties.SupportedParameterTypes.Contains(paramInfo.ParameterType))
                        {
                            isSupported = false;
                            break;
                        }
                    }
                    SetIsPreviewInfoSupported(item, isSupported);
                    SetIncludeInPreviewBatch(item, isSupported);
                }
            }
        }
    }
}
