﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Editor.Preview
{
    [global::System.Serializable]
    public class PreviewException : Exception
    {
        //
        // For guidelines regarding the creation of new exception types, see
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpgenref/html/cpconerrorraisinghandlingguidelines.asp
        // and
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dncscol/html/csharp07192001.asp
        //

        public PreviewException() { }
        public PreviewException(string message) : base(message) { }
        public PreviewException(string message, Exception inner) : base(message, inner) { }
        protected PreviewException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

    [global::System.Serializable]
    public class PreviewMethodResolverException : PreviewException
    {
        //
        // For guidelines regarding the creation of new exception types, see
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpgenref/html/cpconerrorraisinghandlingguidelines.asp
        // and
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dncscol/html/csharp07192001.asp
        //

        public PreviewMethodResolverException() { }
        public PreviewMethodResolverException(string message) : base(message) { }
        public PreviewMethodResolverException(string message, Exception inner) : base(message, inner) { }
        protected PreviewMethodResolverException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

    [global::System.Serializable]
    public class VLinqQueryPreviewMethodResolverException : PreviewMethodResolverException
    {
        //
        // For guidelines regarding the creation of new exception types, see
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpgenref/html/cpconerrorraisinghandlingguidelines.asp
        // and
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dncscol/html/csharp07192001.asp
        //

        public Query Query { get; set; }
        public VLinqQueryPreviewMethodResolverException() { }
        public VLinqQueryPreviewMethodResolverException(string message) : base(message) { }
        public VLinqQueryPreviewMethodResolverException(string message, Exception inner) : base(message, inner) { }
        protected VLinqQueryPreviewMethodResolverException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }

    [global::System.Serializable]
    public class CustomQueryPreviewMethodResolverException : PreviewMethodResolverException
    {
        //
        // For guidelines regarding the creation of new exception types, see
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpgenref/html/cpconerrorraisinghandlingguidelines.asp
        // and
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dncscol/html/csharp07192001.asp
        //
        public CustomQuery Query { get; set; }
        public CustomQueryPreviewMethodResolverException() { }
        public CustomQueryPreviewMethodResolverException(string message) : base(message) { }
        public CustomQueryPreviewMethodResolverException(string message, Exception inner) : base(message, inner) { }
        protected CustomQueryPreviewMethodResolverException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }
    }
}
