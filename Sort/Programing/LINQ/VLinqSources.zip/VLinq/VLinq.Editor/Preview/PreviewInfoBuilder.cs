﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Design;
using System.Data.Linq;
using System.Diagnostics;

namespace VLinq.Editor.Preview
{
    public class PreviewInfoBuilder
    {
        public static PreviewInfoItem BuildPreviewInfoFromQuery(Query query, QueryBag queryBag, Type queryBagGeneratedType, ITypeResolutionService resolutionService)
        {

            var item = new PreviewInfoItem { QueryBag = queryBag, Query = query, Name = query.Name, HasPaginatedVersion = query.GeneratePaginatedVersion, MethodParametersValues = query.GetParametersValue() };
            try
            {
                var parameterTypes = new List<Type> { typeof(DataContext) };
                parameterTypes.AddRange(from ds in query.DataSources.OfType<ParameterSource>()
                                        select resolutionService.GetType(ds.TypeName));

                item.MethodInfo = queryBagGeneratedType.GetMethod(query.Name, parameterTypes.ToArray());
                item.MethodParametersInfo = item.MethodInfo.GetParameters().Skip(1).ToArray();
            }
            catch
            {
                Debug.WriteLine("Query parameters type list generation failed, or is not the same as the compiled version");
                throw new VLinqQueryPreviewMethodResolverException("Query parameters type list generation failed, or is not the same as the compiled version") { Query = query };
            }
            if (item.MethodInfo == null)
                throw new VLinqQueryPreviewMethodResolverException("Unable to retrieve the MethodInfo corresponding to the specified query") { Query = query };

            if (query.GeneratePaginatedVersion)
            {
                try
                {
                    var parameterTypes = new List<Type> { typeof(DataContext) };
                    parameterTypes.AddRange(from ds in query.DataSources.OfType<ParameterSource>()
                                            select resolutionService.GetType(ds.TypeName));
                    parameterTypes.Add(typeof(int));
                    parameterTypes.Add(typeof(int));
                    item.PaginatedMethodInfo = queryBagGeneratedType.GetMethod(query.Name, parameterTypes.ToArray());
                }
                catch
                {
                    Debug.WriteLine("Query parameters type list generation failed, or is not the same as the compiled version");
                    throw new VLinqQueryPreviewMethodResolverException("Query parameters type list generation failed, or is not the same as the compiled version") { Query = query };
                }
                if (item.PaginatedMethodInfo == null)
                    throw new VLinqQueryPreviewMethodResolverException("Unable to retrieve the paginated version of the MethodInfo corresponding to the specified query") { Query = query };
            }

            return item;


        }

        public static PreviewInfoItem BuildPreviewInfoFromCustomQuery(CustomQuery query, QueryBag queryBag)
        {
            var item = new PreviewInfoItem { Name = query.Name, QueryBag = queryBag, Query = query, MethodInfo = query.MethodInfo, MethodParametersInfo = query.MethodInfo.GetParameters().Skip(1).ToArray() };
            var values = query.GetParametersValue();
            if (values == null)
            {
                var customValues = queryBag.GetCustomQueriesParametersValues();
                if (customValues != null && customValues.ContainsKey(query.Name))
                    values = customValues[query.Name].ToArray();
            }
            item.MethodParametersValues = values;
            return item;
        }
    }
}
