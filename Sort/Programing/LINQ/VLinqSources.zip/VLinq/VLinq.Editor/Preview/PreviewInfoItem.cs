﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Reflection;
using System.Threading;
using System.Collections;

namespace VLinq.Editor.Preview
{
    public class PreviewInfoItem :DependencyObject
    {
        public Thread Worker { get; set; }
        public CompiledQueryCaller MethodCaller { get; set; }
        public CompiledQueryCaller PaginatedMethodCaller { get; set; }

        public QueryBag QueryBag
        {
            get { return (QueryBag)GetValue(QueryBagProperty); }
            set { SetValue(QueryBagProperty, value); }
        }

        // Using a DependencyProperty as the backing store for QueryBag.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryBagProperty =
            DependencyProperty.Register("QueryBag", typeof(QueryBag), typeof(PreviewInfoItem), new UIPropertyMetadata(null));



        public DependencyObject Query
        {
            get { return (DependencyObject)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(DependencyObject), typeof(PreviewInfoItem), new UIPropertyMetadata(null));



        public string Name
        {
            get { return (string)GetValue(NameProperty); }
            set { SetValue(NameProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Name.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty NameProperty =
            DependencyProperty.Register("Name", typeof(string), typeof(PreviewInfoItem), new UIPropertyMetadata(null));




        public MethodInfo PaginatedMethodInfo
        {
            get { return (MethodInfo)GetValue(PaginatedMethodInfoProperty); }
            set { SetValue(PaginatedMethodInfoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for PaginatedMethodInfo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PaginatedMethodInfoProperty =
            DependencyProperty.Register("PaginatedMethodInfo", typeof(MethodInfo), typeof(PreviewInfoItem), new UIPropertyMetadata(null));


        public MethodInfo MethodInfo
        {
            get { return (MethodInfo)GetValue(MethodInfoProperty); }
            set { SetValue(MethodInfoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MethodInfo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MethodInfoProperty =
            DependencyProperty.Register("MethodInfo", typeof(MethodInfo), typeof(PreviewInfoItem), new UIPropertyMetadata(null, OnMethodInfoChanged));

        private static void OnMethodInfoChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PreviewInfoItem elem = obj as PreviewInfoItem;
            if (elem != null)
            {
                elem.OnMethodInfoChanged(args.OldValue == null ? default(MethodInfo) : (MethodInfo)args.OldValue, args.NewValue == null ? default(MethodInfo) : (MethodInfo)args.NewValue);
            }
        }
        protected virtual void OnMethodInfoChanged(MethodInfo oldValue, MethodInfo newValue)
        {
           
        }



        public ParameterInfo[] MethodParametersInfo
        {
            get { return (ParameterInfo[])GetValue(MethodParametersInfoProperty); }
            set { SetValue(MethodParametersInfoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MethodParametersInfo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MethodParametersInfoProperty =
            DependencyProperty.Register("MethodParametersInfo", typeof(ParameterInfo[]), typeof(PreviewInfoItem), new UIPropertyMetadata(null));

        public Array ParametersAndValues
        {
            get
            {
                var q =
                    from info in this.MethodParametersInfo.Select((mi, n) => new { Info = mi, Index = n })
                    from value in this.MethodParametersValues.Select((v, n) => new { Value = v, Index = n })
                    where info.Index == value.Index
                    select new { Name = info.Info.Name, Value = value.Value };
                return q.ToArray();
            }
        }

        public object[] MethodParametersValues
        {
            get { return (object[])GetValue(MethodParametersValuesProperty); }
            set { SetValue(MethodParametersValuesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MethodParametersValues.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MethodParametersValuesProperty =
            DependencyProperty.Register("MethodParametersValues", typeof(object[]), typeof(PreviewInfoItem), new UIPropertyMetadata(null, OnMethodParametersValuesChanged));

        private static void OnMethodParametersValuesChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PreviewInfoItem elem = obj as PreviewInfoItem;
            if (elem != null)
            {
                elem.OnMethodParametersValuesChanged(args.OldValue == null ? default(object[]) : (object[])args.OldValue, args.NewValue == null ? default(object[]) : (object[])args.NewValue);
            }
        }
        protected virtual void OnMethodParametersValuesChanged(object[] oldValue, object[] newValue)
        {
            if(Query != null)
                PreviewProperties.SetParametersValues(Query, newValue);
            if (Query is CustomQuery && QueryBag!=null)
            {
                var asCustom = (CustomQuery)Query;
                var customValues = QueryBag.GetCustomQueriesParametersValues();
                if (!customValues.ContainsKey(asCustom.Name))
                    customValues.Add(asCustom.Name, new ListOfObjects(  newValue));
                else
                    customValues[asCustom.Name] = new ListOfObjects ( newValue);
            }
        }



        public bool HasPaginatedVersion
        {
            get { return (bool)GetValue(HasPaginatedVersionProperty); }
            set { SetValue(HasPaginatedVersionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for HasPaginatedVersion.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HasPaginatedVersionProperty =
            DependencyProperty.Register("HasPaginatedVersion", typeof(bool), typeof(PreviewInfoItem), new UIPropertyMetadata(false));



    }
}
