﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Reflection;
using System.Globalization;

namespace VLinq.Editor.Preview
{
    public class PreviewInfoParamsController : DependencyObject
    {


        public static bool GetAreParametersValid(DependencyObject obj)
        {
            return (bool)obj.GetValue(AreParametersValidProperty);
        }

        public static void SetAreParametersValid(DependencyObject obj, bool value)
        {
            obj.SetValue(AreParametersValidProperty, value);
        }

        // Using a DependencyProperty as the backing store for AreParametersValid.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty AreParametersValidProperty =
            DependencyProperty.RegisterAttached("AreParametersValid", typeof(bool), typeof(PreviewInfoParamsController), new UIPropertyMetadata(true));



        public PreviewInfoItem PreviewInfoItem
        {
            get { return (PreviewInfoItem)GetValue(PreviewInfoItemProperty); }
            set { SetValue(PreviewInfoItemProperty, value); }
        }

        // Using a DependencyProperty as the backing store for PreviewInfoItem.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PreviewInfoItemProperty =
            DependencyProperty.Register("PreviewInfoItem", typeof(PreviewInfoItem), typeof(PreviewInfoParamsController), new UIPropertyMetadata(null, OnPreviewInfoItemChanged));

        private static void OnPreviewInfoItemChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PreviewInfoParamsController elem = obj as PreviewInfoParamsController;
            if (elem != null)
            {
                elem.OnPreviewInfoItemChanged(args.OldValue == null ? default(PreviewInfoItem) : (PreviewInfoItem)args.OldValue, args.NewValue == null ? default(PreviewInfoItem) : (PreviewInfoItem)args.NewValue);
            }
        }
        protected virtual void OnPreviewInfoItemChanged(PreviewInfoItem oldValue, PreviewInfoItem newValue)
        {
            if (Parameters != null)
                foreach (var param in Parameters)
                    param.ValueChanged -= container_ValueChanged;
            List<PreviewInfoParamContainer> containers = new List<PreviewInfoParamContainer>();
            if (newValue == null)
                Parameters = containers;
            else
            {
                bool initParams = newValue.MethodParametersValues != null && newValue.MethodParametersValues.Length == newValue.MethodParametersInfo.Length;
                containers.AddRange(
                    from pi in newValue.MethodParametersInfo
                    select new PreviewInfoParamContainer { ParameterInfo = pi, Value = initParams ? newValue.MethodParametersValues[pi.Position - 1] : null });

                Parameters = containers;
                foreach (var container in containers)
                {
                    container.ValueChanged += container_ValueChanged;
                    ValidateParam(container);
                }
                SetAreParametersValid(PreviewInfoItem, AreAllParametersValid);
            }
        }

        public bool AreAllParametersValid
        {
            get
            {
                bool valid = true;
                foreach (var container in Parameters)
                    valid &= container.IsValid;
                return valid;
            }
        }
        
        void container_ValueChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            var container = sender as PreviewInfoParamContainer;
            ValidateParam(container);
            if (container.IsValid)
            {
                RebuildParamValues();
            }
            SetAreParametersValid(PreviewInfoItem, AreAllParametersValid);
        }

        private void ValidateParam(PreviewInfoParamContainer container)
        {
            if (container.Value == null)
            {
                container.Value = container.ParameterInfo.ParameterType.GetDefaultValue();
                container.IsValid = true;
            }
            else if (container.Value.GetType() != container.ParameterInfo.ParameterType)
            {
                try
                {
                    container.Value = System.Convert.ChangeType(container.Value, container.ParameterInfo.ParameterType, CultureInfo.InvariantCulture);
                    container.IsValid = true;
                }
                catch
                {
                    container.IsValid = false;
                }
            }    
        }

        private void RebuildParamValues()
        {
            PreviewInfoItem.MethodParametersValues = (from p in Parameters select p.Value).ToArray();            
        }

       


        public List<PreviewInfoParamContainer> Parameters
        {
            get { return (List<PreviewInfoParamContainer>)GetValue(ParametersProperty); }
            set { SetValue(ParametersProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Parameters.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParametersProperty =
            DependencyProperty.Register("Parameters", typeof(List<PreviewInfoParamContainer>), typeof(PreviewInfoParamsController), new UIPropertyMetadata(null));




    }
    public class PreviewInfoParamContainer : DependencyObject
    {


        public ParameterInfo ParameterInfo
        {
            get { return (ParameterInfo)GetValue(ParameterInfoProperty); }
            set { SetValue(ParameterInfoProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ParameterInfo.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParameterInfoProperty =
            DependencyProperty.Register("ParameterInfo", typeof(ParameterInfo), typeof(PreviewInfoParamContainer), new UIPropertyMetadata(null));



        public object Value
        {
            get { return (object)GetValue(ValueProperty); }
            set { SetValue(ValueProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Value.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ValueProperty =
            DependencyProperty.Register("Value", typeof(object), typeof(PreviewInfoParamContainer), new UIPropertyMetadata(null, OnValueChanged));

        private static void OnValueChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PreviewInfoParamContainer elem = obj as PreviewInfoParamContainer;
            if (elem != null)
            {
                elem.OnValueChanged(args.OldValue == null ? default(object) : (object)args.OldValue, args.NewValue == null ? default(object) : (object)args.NewValue);
            }
        }
        protected virtual void OnValueChanged(object oldValue, object newValue)
        {
            if (ValueChanged != null)
                ValueChanged(this, new DependencyPropertyChangedEventArgs(ValueProperty, oldValue, newValue));
        }


        public bool IsValid
        {
            get { return (bool)GetValue(IsValidProperty); }
            set { SetValue(IsValidProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsValid.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsValidProperty =
            DependencyProperty.Register("IsValid", typeof(bool), typeof(PreviewInfoParamContainer), new UIPropertyMetadata(true));


        public event DependencyPropertyChangedEventHandler ValueChanged;

    }
}
