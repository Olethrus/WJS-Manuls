﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VLinq.Editor.Preview
{
    /// <summary>
    /// Interaction logic for PreviewInfoParamsEditor.xaml
    /// </summary>
    public partial class PreviewInfoParamsEditor : UserControl
    {
        public PreviewInfoParamsEditor()
        {
            InitializeComponent();
        }

        public PreviewInfoParamsController Controller
        {
            get { return DataContext as PreviewInfoParamsController; }
        }





        public PreviewInfoItem PreviewInfoItem
        {
            get { return (PreviewInfoItem)GetValue(PreviewInfoItemProperty); }
            set { SetValue(PreviewInfoItemProperty, value); }
        }

        // Using a DependencyProperty as the backing store for PreviewInfoItem.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PreviewInfoItemProperty =
            DependencyProperty.Register("PreviewInfoItem", typeof(PreviewInfoItem), typeof(PreviewInfoParamsEditor), new UIPropertyMetadata(null, OnPreviewInfoItemChanged));

        private static void OnPreviewInfoItemChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PreviewInfoParamsEditor elem = obj as PreviewInfoParamsEditor;
            if (elem != null)
            {
                elem.OnPreviewInfoItemChanged(args.OldValue == null ? default(PreviewInfoItem) : (PreviewInfoItem)args.OldValue, args.NewValue == null ? default(PreviewInfoItem) : (PreviewInfoItem)args.NewValue);
            }
        }
        protected virtual void OnPreviewInfoItemChanged(PreviewInfoItem oldValue, PreviewInfoItem newValue)
        {
            Controller.PreviewInfoItem = newValue;
        }



    }
}
