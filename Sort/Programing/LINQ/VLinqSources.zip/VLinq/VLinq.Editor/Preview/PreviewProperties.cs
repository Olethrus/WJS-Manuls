﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Data.SqlClient;

namespace VLinq.Editor.Preview
{
    public static class PreviewPropertiesExtensions
    {
        public static ConnectionStringProvider GetConnectionStringProvider(this QueryBag queryBag)
        {
            return PreviewProperties.GetConnectionStringProvider(queryBag);
        }
        public static void SetConnectionStringProvider(this QueryBag queryBag,ConnectionStringProvider provider)
        {
            PreviewProperties.SetConnectionStringProvider(queryBag,provider);
        }

        public static bool TestConnectionString(this QueryBag queryBag)
        {
            return !string.IsNullOrEmpty(queryBag.GetConnectionStringProvider().GetConnectionString());
        }

        public static string TestConnection(this QueryBag queryBag)
        {
            string errorMessage = null;
            try
            {
                var connection = new SqlConnection(queryBag.GetConnectionStringProvider().GetConnectionString());
                connection.Open();
                connection.Close();
            }
            catch (Exception ex)
            {
                errorMessage = ex.Message;
            }

            return errorMessage;
        }

        public static object[] GetParametersValue(this Query query)
        {
            return PreviewProperties.GetParametersValues(query);
        }
        public static object[] GetParametersValue(this CustomQuery query)
        {
            return PreviewProperties.GetParametersValues(query);
        }

        public static void SetParametersValue(this Query query, object[] values)
        {
            PreviewProperties.SetParametersValues(query, values);
        }
        public static void SetParametersValue(this CustomQuery query, object[] values)
        {
            PreviewProperties.SetParametersValues(query, values);
        }
        public static ObjectArrayByStringDictionnary GetCustomQueriesParametersValues(this QueryBag queryBag)
        {
            return PreviewProperties.GetCustomQueriesParametersValues(queryBag);
        }
        public static void SetCustomQueriesParametersValues(this QueryBag queryBag, ObjectArrayByStringDictionnary values)
        {
            PreviewProperties.SetCustomQueriesParametersValues(queryBag, values);
        }
    }
    public  class PreviewProperties : DependencyObject
    {


        public static string GetExternalMappingSource(DependencyObject obj)
        {
            return (string)obj.GetValue(ExternalMappingSourceProperty);
        }

        public static void SetExternalMappingSource(DependencyObject obj, string value)
        {
            obj.SetValue(ExternalMappingSourceProperty, value);
        }

        // Using a DependencyProperty as the backing store for ExternalMappingSource.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ExternalMappingSourceProperty =
            DependencyProperty.RegisterAttached("ExternalMappingSource", typeof(string), typeof(PreviewProperties), new ChangeBublingMetadata(string.Empty));



        public static readonly Type[] SupportedParameterTypes = new Type[]{typeof(byte), typeof(short), typeof(int), typeof(long), 
            typeof(sbyte),typeof(ushort),typeof(uint),typeof(ulong),
            typeof(float), typeof(double), typeof(decimal),
            typeof(DateTime), typeof(string)};

        public static ConnectionStringProvider GetConnectionStringProvider(DependencyObject obj)
        {
            var val = (ConnectionStringProvider)obj.GetValue(ConnectionStringProviderProperty);
            if (val == null)
            {
                val = new ConnectionStringProvider();
                SetConnectionStringProvider(obj,val);
            }
            return val;
        }

        public static void SetConnectionStringProvider(DependencyObject obj, ConnectionStringProvider value)
        {
            obj.SetValue(ConnectionStringProviderProperty, value);
        }

        // Using a DependencyProperty as the backing store for ConnectionStringProvider.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ConnectionStringProviderProperty =
            DependencyProperty.RegisterAttached("ConnectionStringProvider", typeof(ConnectionStringProvider), typeof(PreviewProperties), new ChangeBublingMetadata(null));



        public static object[] GetParametersValues(DependencyObject obj)
        {
            return (object[])obj.GetValue(ParametersValuesProperty);
        }

        public static void SetParametersValues(DependencyObject obj, object[] value)
        {
            obj.SetValue(ParametersValuesProperty, value);
        }

        // Using a DependencyProperty as the backing store for ParametersValues.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParametersValuesProperty =
            DependencyProperty.RegisterAttached("ParametersValues", typeof(object[]), typeof(PreviewProperties), new ChangeBublingMetadata(null));



        public static ObjectArrayByStringDictionnary GetCustomQueriesParametersValues(DependencyObject obj)
        {
            var retval = (ObjectArrayByStringDictionnary)obj.GetValue(CustomQueriesParametersValuesProperty);
            if (retval == null)
            {
                retval = new ObjectArrayByStringDictionnary();
                SetCustomQueriesParametersValues(obj, retval);
            }
            return retval;
        }

        public static void SetCustomQueriesParametersValues(DependencyObject obj, ObjectArrayByStringDictionnary value)
        {
            obj.SetValue(CustomQueriesParametersValuesProperty, value);
        }

        // Using a DependencyProperty as the backing store for CustomQueriesParametersValues.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CustomQueriesParametersValuesProperty =
            DependencyProperty.RegisterAttached("CustomQueriesParametersValues", typeof(ObjectArrayByStringDictionnary), typeof(PreviewProperties), new ChangeBublingMetadata(null));


    }
    public class ListOfObjects : List<object> { public ListOfObjects() { }
    public ListOfObjects(IEnumerable<object> values) : base(values) { }
    }
    public class ObjectArrayByStringDictionnary : Dictionary<string, ListOfObjects> { }
}
