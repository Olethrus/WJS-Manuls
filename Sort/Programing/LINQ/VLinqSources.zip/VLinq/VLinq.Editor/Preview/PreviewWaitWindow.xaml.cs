﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using VLinq.WPFControls;
using System.Windows.Threading;
using System.Collections.ObjectModel;

namespace VLinq.Editor.Preview
{
    /// <summary>
    /// Interaction logic for PreviewWaitWindow.xaml
    /// </summary>
    public partial class PreviewWaitWindow : Window
    {
        private PreviewerController m_ctrl;
        public PreviewWaitWindow(PreviewerController controller)
        {
            InitializeComponent();
            m_ctrl = controller;
            this.Loaded += new RoutedEventHandler(PreviewWaitWindow_Loaded);
        }

        private DispatcherOperation previewOperation = null;
        private ObservableCollection<PreviewInfoItem> failedItems;

        void PreviewWaitWindow_Loaded(object sender, RoutedEventArgs e)
        {
            failedItems = new ObservableCollection<PreviewInfoItem>();
            DataContext = failedItems;

            m_ctrl.LoadingChanged += new EventHandler(m_ctrl_LoadingChanged);
            m_ctrl.OnPreviewFailed += new Action<PreviewInfoItem>(PreviewFailed);
            WPFHelpers.WaitForPriority(System.Windows.Threading.DispatcherPriority.Normal);
            previewOperation =
                Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal,
                    new Action(delegate { m_ctrl.ExecutePreviews(); }));
        }

        void PreviewFailed(PreviewInfoItem item)
        {
            Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Normal,
                new Action<PreviewInfoItem>(delegate(PreviewInfoItem failedItem) {
                    failedItems.Add(failedItem);
                }),
                item);
        }

        void m_ctrl_LoadingChanged(object sender, EventArgs e)
        {
            if (!m_ctrl.Loading)
            {
                if (failedItems.Count > 0)
                {
                    btCancel.Content = "Close";
                }
                else
                    Close();
            }
        }
        
        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            if (!m_ctrl.Loading)
            {
                Close();
            }
            else
                if (previewOperation != null)
                    previewOperation.Abort();
                    //m_ctrl.CancelPreviews();
        }
    }
}
