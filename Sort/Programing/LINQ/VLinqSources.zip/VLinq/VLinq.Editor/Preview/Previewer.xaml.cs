﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VLinq.Editor.Preview
{
    /// <summary>
    /// Interaction logic for Previewer.xaml
    /// </summary>
    public partial class Previewer : UserControl
    {
        public PreviewerController Controller
        {
            get
            {
                return DataContext as PreviewerController;
            }
        }
        public Previewer()
        {
            InitializeComponent();
        }
        private DataTemplate m_listOfGroupingsTemplate;
        public DataTemplate ListOfGroupingsTemplate
        {
            get
            {
                if (m_listOfGroupingsTemplate == null)
                    m_listOfGroupingsTemplate = (DataTemplate) FindResource("ListOfGroupingsTemplate");
                return m_listOfGroupingsTemplate;
            }
        }

        private DataTemplate m_listOfItemsTemplate;
        public DataTemplate ListOfItemsTemplate
        {
            get
            {
                if (m_listOfItemsTemplate == null)
                    m_listOfItemsTemplate = (DataTemplate)FindResource("ListOfItemsTemplate");
                return m_listOfItemsTemplate;
            }
        }

        private void SelectResultTemplate(object sender, VLinq.WPFControls.SelectTemplateEventArgs e)
        {
            if (e.Item != null)
            {
                var itemType = e.Item.GetType();
                if (itemType.IsGenericType && itemType.GetGenericTypeDefinition() == typeof(List<>))
                {
                    var enumeratedType = itemType.GetGenericArguments()[0];
                    bool isListOfGroupings = false;
                    if (enumeratedType.IsGenericType && enumeratedType.GetGenericTypeDefinition() == typeof(IGrouping<,>))
                        isListOfGroupings = true;
                    foreach (var interfaceType in enumeratedType.GetInterfaces())
                    {
                        if (interfaceType.IsGenericType && interfaceType.GetGenericTypeDefinition() == typeof(IGrouping<,>))
                        {
                            isListOfGroupings = true;
                            break;
                        }
                    }
                    if (isListOfGroupings)
                        e.Template = ListOfGroupingsTemplate;
                    else
                        e.Template = ListOfItemsTemplate;
                }
            }
        }

        private void DynamicList_Loaded(object sender, RoutedEventArgs e)
        {
            var listView = sender as ListView;
            var dynGridView = listView.View as DynamicGridView;
            dynGridView.TypeOfItems = listView.DataContext.GetType().GetGenericArguments()[0];
        }

        private void groupValuesList_Loaded(object sender, RoutedEventArgs e)
        {
            var listView = sender as ListView;
            var contextType = listView.DataContext.GetType();
            Type enumeratedType = null;
            foreach (var interfaceType in contextType.GetInterfaces())
            {
                if (interfaceType.IsGenericType && interfaceType.GetGenericTypeDefinition() == typeof(IEnumerable<>))
                {
                    enumeratedType = interfaceType.GetGenericArguments()[0];
                    break;
                }
            }
            if (enumeratedType != null)
            {
                if (!PreviewProperties.SupportedParameterTypes.Contains(enumeratedType))
                {
                    listView.View = new DynamicGridView { TypeOfItems = enumeratedType };
                }
            }
        }

        private void GroupKeyTextBlockLoaded(object sender, RoutedEventArgs e)
        {
            var txtBlock = sender as TextBlock;
            var realType = (txtBlock.DataContext).GetType();
            Type groupingType = null;
            foreach(var interfaceType in realType.GetInterfaces())
            {
                if(interfaceType.IsGenericType && interfaceType.GetGenericTypeDefinition() == typeof(IGrouping<,>))
                {
                    groupingType = interfaceType;
                    break;
                }
            }
            if(groupingType != null)
                txtBlock.Text = groupingType.GetProperty("Key").GetValue(txtBlock.DataContext, null).ToString();
        }

        private void QueryPreviewContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            var asTabCtl = sender as TabControl;
            if (asTabCtl != null && asTabCtl.Items.Count > 0)
                asTabCtl.SelectedIndex = 0;

            var paramViewer = asTabCtl.FindName("paramViewer") as PreviewInfoParamsViewer;
            if (paramViewer != null)
                paramViewer.PreviewInfoItem = asTabCtl.DataContext as PreviewInfoItem;
        }

        private void TabControl_Loaded(object sender, RoutedEventArgs e)
        {
            var asTabCtl = sender as TabControl;
            var paramViewer = asTabCtl.FindName("paramViewer") as PreviewInfoParamsViewer;
            if (paramViewer != null)
                paramViewer.PreviewInfoItem = asTabCtl.DataContext as PreviewInfoItem;
        }
    }
}
