﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Data.Linq;
using System.IO;
using System.Collections;
using System.Reflection;
using System.Threading;
using System.Diagnostics;
using System.ComponentModel;
using System.Windows.Threading;

namespace VLinq.Editor.Preview
{
    public enum QueryPreviewState
    {
        Idle,
        Running,
        Ok,
        Failed
    }
    public class PreviewerController : DependencyObject
    {

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static QueryPreviewState GetPreviewState(DependencyObject obj)
        {
            return (QueryPreviewState)obj.GetValue(PreviewStateProperty);
        }

        public static void SetPreviewState(DependencyObject obj, QueryPreviewState value)
        {
            obj.SetValue(PreviewStateProperty, value);
        }

        public static void SetPreviewState(DependencyObject obj, QueryPreviewState value, bool withDelay)
        {
            if (withDelay)
            {
                var timer = new DispatcherTimer(DispatcherPriority.Background);
                timer.Tick += delegate(object sender, EventArgs args)
                {
                    SetPreviewState(obj, value);
                    timer.Stop();
                };
                timer.Interval = TimeSpan.FromMilliseconds(3000);
                timer.Start();
            }
            else
                SetPreviewState(obj, value);
        }

        // Using a DependencyProperty as the backing store for PreviewState.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PreviewStateProperty =
            DependencyProperty.RegisterAttached("PreviewState", typeof(QueryPreviewState), typeof(PreviewerController), new UIPropertyMetadata(QueryPreviewState.Idle));



        public static string GetSQLLog(DependencyObject obj)
        {
            return (string)obj.GetValue(SQLLogProperty);
        }

        public static void SetSQLLog(DependencyObject obj, string value)
        {
            obj.SetValue(SQLLogProperty, value);
        }

        // Using a DependencyProperty as the backing store for SQLLog.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SQLLogProperty =
            DependencyProperty.RegisterAttached("SQLLog", typeof(string), typeof(PreviewerController), new UIPropertyMetadata(null));


        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static object GetQueryResult(DependencyObject obj)
        {
            return (object)obj.GetValue(QueryResultProperty);
        }

        public static void SetQueryResult(DependencyObject obj, object value)
        {
            obj.SetValue(QueryResultProperty, value);
        }

        // Using a DependencyProperty as the backing store for QueryResult.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryResultProperty =
            DependencyProperty.RegisterAttached("QueryResult", typeof(object), typeof(PreviewerController), new UIPropertyMetadata(null));


        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static object GetPaginatedQueryResult(DependencyObject obj)
        {
            return (object)obj.GetValue(PaginatedQueryResultProperty);
        }

        public static void SetPaginatedQueryResult(DependencyObject obj, object value)
        {
            obj.SetValue(PaginatedQueryResultProperty, value);
        }

        // Using a DependencyProperty as the backing store for PaginatedQueryResult.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PaginatedQueryResultProperty =
            DependencyProperty.RegisterAttached("PaginatedQueryResult", typeof(object), typeof(PreviewerController), new UIPropertyMetadata(null));



        public static string GetPaginatedSQLLog(DependencyObject obj)
        {
            return (string)obj.GetValue(PaginatedSQLLogProperty);
        }

        public static void SetPaginatedSQLLog(DependencyObject obj, string value)
        {
            obj.SetValue(PaginatedSQLLogProperty, value);
        }

        // Using a DependencyProperty as the backing store for PaginatedSQLLog.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PaginatedSQLLogProperty =
            DependencyProperty.RegisterAttached("PaginatedSQLLog", typeof(string), typeof(PreviewerController), new UIPropertyMetadata(null));



        public bool Loading
        {
            get { return (bool)GetValue(LoadingProperty); }
            set { SetValue(LoadingProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Loading.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LoadingProperty =
            DependencyProperty.Register("Loading", typeof(bool), typeof(PreviewerController), new UIPropertyMetadata(false, OnLoadingChanged));

        private static void OnLoadingChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            
            var asPC = obj as PreviewerController;
            if (asPC != null)
                asPC.OnLoadingChanged((bool)args.OldValue, (bool)args.NewValue);
        }
        protected virtual void OnLoadingChanged(bool oldValue, bool newValue)
        {
            if (LoadingChanged != null)
                LoadingChanged(this, EventArgs.Empty);
        }
        public event EventHandler LoadingChanged;
        public IEnumerable<PreviewInfoItem> PreviewInfoItems
        {
            get { return (IEnumerable<PreviewInfoItem>)GetValue(PreviewInfoItemsProperty); }
            set { SetValue(PreviewInfoItemsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for PreviewInfoItems.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PreviewInfoItemsProperty =
            DependencyProperty.Register("PreviewInfoItems", typeof(IEnumerable<PreviewInfoItem>), typeof(PreviewerController), new UIPropertyMetadata(null, OnPreviewInfoItemsChanged));

        private static void OnPreviewInfoItemsChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            PreviewerController elem = obj as PreviewerController;
            if (elem != null)
            {
                elem.OnPreviewInfoItemsChanged(args.OldValue == null ? default(IEnumerable<PreviewInfoItem>) : (IEnumerable<PreviewInfoItem>)args.OldValue, args.NewValue == null ? default(IEnumerable<PreviewInfoItem>) : (IEnumerable<PreviewInfoItem>)args.NewValue);
            }
        }
        public void CancelPreviews()
        {
            if (PreviewInfoItems != null)
            {
                foreach (var item in PreviewInfoItems)
                {
                    if(item.Worker != null)
                        try
                        {
                            item.Worker.Abort();
                        }
                        finally { }
                }
            }
        }
        public delegate void VoidDelegate();

        //Sequential version
        public void ExecutePreviews()
        {
            if (PreviewInfoItems != null && PreviewInfoItems.Count() > 0)
            {
                workingCount = PreviewInfoItems.Count();

                var extMappingFile = PreviewProperties.GetExternalMappingSource(PreviewInfoItems.First().QueryBag);
                System.Data.Linq.Mapping.XmlMappingSource extMappingSource = null;
                if (!string.IsNullOrEmpty(extMappingFile))
                {
                    try
                    {
                        extMappingSource = System.Data.Linq.Mapping.XmlMappingSource.FromUrl(extMappingFile);
                    }
                    catch
                    {
                        Debug.WriteLine("XmlMappingSource loading failed");
                    }
                }
                foreach (var item in PreviewInfoItems)
                {
                    SetPreviewState(item.Query, QueryPreviewState.Running);
                    SetPaginatedQueryResult(item, null);
                    SetPaginatedSQLLog(item, null);
                    SetQueryResult(item, null);
                    SetSQLLog(item, null);
                    var log = new StringBuilder();

                    try
                    {
                        DataContext dataContext = null;
                        if (extMappingSource == null)
                            dataContext = new DataContext(item.QueryBag.GetConnectionStringProvider().GetConnectionString());
                        else
                            dataContext = new DataContext(item.QueryBag.GetConnectionStringProvider().GetConnectionString(), extMappingSource);
                        dataContext.DeferredLoadingEnabled = false;
                        dataContext.Log = new StringWriter(log);

                        var realParams = new object[] { dataContext };
                        if (item.MethodParametersValues != null)
                        {
                            var paramList = new List<object>(realParams);
                            paramList.AddRange(item.MethodParametersValues);
                            realParams = paramList.ToArray();
                        }

                        var itemInfos = new InfoItemData
                        {
                            DataContext = dataContext,
                            MethodInfo = item.MethodInfo,
                            QueryCaller = item.MethodCaller,
                            Log = log,
                            Item = item,
                            Parameters = realParams

                        };
                        if (item.HasPaginatedVersion && PreviewConfigController.GetPreviewPaginatedVersion(item.Query))
                        {

                            itemInfos.PaginatedMethodInfo = item.PaginatedMethodInfo;
                            itemInfos.PaginatedQueryCaller = item.PaginatedMethodCaller;
                            var pagingParams = new List<object> { dataContext };
                            if (item.MethodParametersValues != null)
                            {
                                pagingParams.AddRange(item.MethodParametersValues);
                            }
                            pagingParams.AddRange(
                                new object[] { PreviewConfigController.GetFirstRowIndex(item.Query), PreviewConfigController.GetPageSize(item.Query) });
                            itemInfos.PagingParams = pagingParams.ToArray();

                        }
                        TreatPreviewInfoItem(itemInfos);
                        //var t = new Thread(new ParameterizedThreadStart(TreatPreviewInfoItem));
                        //itemInfos.Item.Worker = t;
                        //t.Start(itemInfos);

                    }
                    catch (Exception ex)
                    {
                        this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                        {
                            SetQueryResult(item, ex);
                            SetQueryResult(item.Query, ex.Message + "\n" + ex.StackTrace);
                            SetPreviewState(item.Query, QueryPreviewState.Failed);
                            if (OnPreviewFailed != null)
                                OnPreviewFailed(item);
                        })); 
                    }
                }
            }
            else
                Loading = false;
        }

        public Action<PreviewInfoItem> OnPreviewFailed;

        //Parallele version
        //public void ExecutePreviews()
        //{
        //    if (PreviewInfoItems != null && PreviewInfoItems.Count() > 0)
        //    {
        //        workingCount = PreviewInfoItems.Count();

        //        var extMappingFile = PreviewProperties.GetExternalMappingSource(PreviewInfoItems.First().QueryBag);
        //        System.Data.Linq.Mapping.XmlMappingSource extMappingSource = null;
        //        if (!string.IsNullOrEmpty(extMappingFile))
        //        {
        //            try
        //            {
        //                extMappingSource = System.Data.Linq.Mapping.XmlMappingSource.FromUrl(extMappingFile);
        //            }
        //            catch
        //            {
        //                Debug.WriteLine("XmlMappingSource loading failed");
        //            }
        //        }
        //        foreach (var item in PreviewInfoItems)
        //        {
        //            SetPreviewState(item.Query, QueryPreviewState.Running);
        //            SetPaginatedQueryResult(item, null);
        //            SetPaginatedSQLLog(item, null);
        //            SetQueryResult(item, null);
        //            SetSQLLog(item, null);
        //            var log = new StringBuilder();

        //            try
        //            {
        //                DataContext dataContext = null;
        //                if (extMappingSource == null)
        //                    dataContext = new DataContext(item.QueryBag.GetConnectionStringProvider().GetConnectionString());
        //                else
        //                    dataContext = new DataContext(item.QueryBag.GetConnectionStringProvider().GetConnectionString(), extMappingSource);
        //                dataContext.DeferredLoadingEnabled = false;
        //                dataContext.Log = new StringWriter(log);

        //                var realParams = new object[] { dataContext };
        //                if (item.MethodParametersValues != null)
        //                {
        //                    var paramList = new List<object>(realParams);
        //                    paramList.AddRange(item.MethodParametersValues);
        //                    realParams = paramList.ToArray();
        //                }

        //                var itemInfos = new InfoItemData
        //                {
        //                    DataContext = dataContext,
        //                    MethodInfo = item.MethodInfo,
        //                    QueryCaller = item.MethodCaller,
        //                    Log = log,
        //                    Item = item,
        //                    Parameters = realParams

        //                };
        //                if (item.HasPaginatedVersion && PreviewConfigController.GetPreviewPaginatedVersion(item.Query))
        //                {

        //                    itemInfos.PaginatedMethodInfo = item.PaginatedMethodInfo;
        //                    itemInfos.PaginatedQueryCaller = item.PaginatedMethodCaller;
        //                    var pagingParams = new List<object> { dataContext };
        //                    if (item.MethodParametersValues != null)
        //                    {
        //                        pagingParams.AddRange(item.MethodParametersValues);
        //                    }
        //                    pagingParams.AddRange(
        //                        new object[] { PreviewConfigController.GetFirstRowIndex(item.Query), PreviewConfigController.GetPageSize(item.Query) });
        //                    itemInfos.PagingParams = pagingParams.ToArray();

        //                }
        //                var t = new Thread(new ParameterizedThreadStart(TreatPreviewInfoItem));
        //                itemInfos.Item.Worker = t;
        //                t.Start(itemInfos);

        //            }
        //            catch (Exception ex)
        //            {
        //                SetQueryResult(item, ex);
        //                SetQueryResult(item.Query, ex.Message + "\n" + ex.StackTrace);
        //                SetPreviewState(item.Query, QueryPreviewState.Failed);
        //            }

        //        }
        //    }
        //    else
        //        Loading = false;

            
        //}
        private int workingCount = 0;
        private object m_workerThreadsLocker = new object();
        protected virtual void OnPreviewInfoItemsChanged(IEnumerable<PreviewInfoItem> oldValue, IEnumerable<PreviewInfoItem> newValue)
        {
            Loading = true;
            // Dispatcher.BeginInvoke(System.Windows.Threading.DispatcherPriority.Background,new VoidDelegate(ExecutePreviews));
           // ExecutePreviews();
            var dlg = new PreviewWaitWindow(this);
            dlg.ShowDialog();
        }
        private class InfoItemData
        {
            public DataContext DataContext { get; set; }
            public MethodInfo MethodInfo { get; set; }
            public MethodInfo PaginatedMethodInfo { get; set; }
            public CompiledQueryCaller QueryCaller { get; set; }
            public CompiledQueryCaller PaginatedQueryCaller { get; set; }
            public PreviewInfoItem Item { get; set; }
            public object[] Parameters { get; set; }
            public object[] PagingParams { get; set; }
            public StringBuilder Log { get; set; }
        }
        private void TreatPreviewInfoItem(object oitem)
        {

            var item = oitem as InfoItemData;
            if (item != null)
            {
                try
                {
                    if (item.QueryCaller != null)
                    {
                        var result = item.QueryCaller.Call(item.Parameters);
                        result = TreatResult(result);
                        this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                            {
                                SetQueryResult(item.Item, result);
                                SetPreviewState(item.Item.Query, QueryPreviewState.Ok);
                            }));
                        //SetQueryResult(item, );
                    }
                    else if (item.MethodInfo != null)
                    {
                        var result = item.MethodInfo.Invoke(null, item.Parameters);
                        result = TreatResult(result);
                        this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                            {
                                SetQueryResult(item.Item, result);
                                SetPreviewState(item.Item.Query, QueryPreviewState.Ok);
                            }));
                        //SetQueryResult(item, TreatResult(result));
                    }
                }
                catch (TargetInvocationException tie)
                {
                    if (tie.InnerException is TypeInitializationException)
                    {
                        this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                        {
                            SetQueryResult(item.Item, Messages.QuerybagTypeCannotBeInstanciated);
                            SetQueryResult(item.Item.Query, Messages.QuerybagTypeCannotBeInstanciated);
                            SetPreviewState(item.Item.Query, QueryPreviewState.Failed);
                        }));
                    }
                    else if (tie.InnerException != null)
                    {
                        this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                        {
                            SetQueryResult(item.Item, tie.InnerException);
                            SetQueryResult(item.Item.Query, tie.InnerException.Message + "\n" + tie.InnerException.StackTrace);
                            SetPreviewState(item.Item.Query, QueryPreviewState.Failed);
                        }));
                    }
                    else
                    {
                        this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                        {
                            SetQueryResult(item.Item, tie);
                            SetQueryResult(item.Item.Query, tie.Message + "\n" + tie.StackTrace);
                            SetPreviewState(item.Item.Query, QueryPreviewState.Failed);
                        }));
                    }
                }
                catch (Exception ex)
                {
                    this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                            {
                                SetQueryResult(item.Item, ex);
                                SetQueryResult(item.Item.Query, ex.Message + "\n" + ex.StackTrace);
                                SetPreviewState(item.Item.Query, QueryPreviewState.Failed);
                            }));
                }
                finally
                {
                    this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                            {
                                SetSQLLog(item.Item, item.Log.ToString());
                            }));
                    item.Log.Remove(0, item.Log.Length);
                }
                if (item.PagingParams != null)
                {
                    try
                    {
                        if (item.PaginatedQueryCaller != null)
                        {
                            var result = item.PaginatedQueryCaller.Call(item.PagingParams);
                            result = TreatResult(result);
                            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                            {
                                SetPaginatedQueryResult(item.Item, result);
                                SetPreviewState(item.Item.Query, QueryPreviewState.Ok);
                            }));
                            //SetQueryResult(item, );
                        }
                        else if (item.PaginatedMethodInfo != null)
                        {
                            var result = item.PaginatedMethodInfo.Invoke(null, item.PagingParams);
                            result = TreatResult(result);
                            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                            {
                                SetPaginatedQueryResult(item.Item, result);
                                SetPreviewState(item.Item.Query, QueryPreviewState.Ok);
                            }));
                            //SetQueryResult(item, TreatResult(result));
                        }
                    }
                    catch (TargetInvocationException tie)
                    {
                        if (tie.InnerException is TypeInitializationException)
                        {
                            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                            {
                                SetPaginatedQueryResult(item.Item, Messages.QuerybagTypeCannotBeInstanciated);
                                SetPaginatedQueryResult(item.Item.Query, Messages.QuerybagTypeCannotBeInstanciated);
                                SetPreviewState(item.Item.Query, QueryPreviewState.Failed);
                            }));
                        }
                        else
                        {
                            this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                            {
                                SetPaginatedQueryResult(item.Item, tie);
                                SetPaginatedQueryResult(item.Item.Query, tie.Message + "\n" + tie.StackTrace);
                                SetPreviewState(item.Item.Query, QueryPreviewState.Failed);
                            }));
                        }
                    }
                    catch (Exception ex)
                    {
                        this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                        {
                            SetPaginatedQueryResult(item.Item, ex);
                            SetPaginatedQueryResult(item.Item.Query, ex.Message + "\n" + ex.StackTrace);
                            SetPreviewState(item.Item.Query, QueryPreviewState.Failed);
                        }));
                    }
                    finally
                    {
                        this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                        {
                            SetPaginatedSQLLog(item.Item, item.Log.ToString());
                        }));

                        
                    }
                   
                }
                lock (m_workerThreadsLocker)
                {
                    workingCount--;
                }
                QueryPreviewState state = QueryPreviewState.Failed;
                Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                {
                    state = GetPreviewState(item.Item.Query);
                }));
                if (state == QueryPreviewState.Ok)
                {
                    //Thread.Sleep(3000);
                    Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                    {
                        SetPreviewState(item.Item.Query, QueryPreviewState.Idle, true);
                    }));
                }
                if (item.DataContext != null)
                {
                    item.DataContext.Dispose();
                    item.DataContext = null;
                }
                if (workingCount == 0)
                {
                    this.Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.Background, new VoidDelegate(delegate
                    {
                        Loading = false;
                    }));
                }
            }
        }

        private object TreatResult(object result)
        {
            var asQueryable = result as IQueryable;
            if (asQueryable != null)
            {
                // We call "ToList" to ensure that the SQL log is complete (it forces the evaluation of all returned entities and force execution of subqueries when needed)
                //var method = this.GetType().GetMethod("GetResultList").MakeGenericMethod(asQueryable.ElementType);
                //return method.Invoke(this, new object[] { result });

                IEnumerable asEnumerable;
                Type elementType = asQueryable.ElementType;

                if (asQueryable.ElementType.IsPrimitive || asQueryable.ElementType == typeof(string))
                {
                    asEnumerable = SelectSimpleProperty(asQueryable);
                    elementType = typeof(SimpleResult);
                }
                else
                    asEnumerable = asQueryable;

                var method = typeof(Enumerable).GetMethod("Take").MakeGenericMethod(elementType);
                result = method.Invoke(null, new object[] { asEnumerable, Constants.MaxResultCountDuringPreview });
                method = typeof(Enumerable).GetMethod("ToList").MakeGenericMethod(elementType);

                return method.Invoke(null, new object[] { result });
            }
            else
                return result;
        }

        private IEnumerable<SimpleResult> SelectSimpleProperty(IEnumerable source)
        {
            foreach (var item in source)
                yield return new SimpleResult{ Value = item };
        }

        private List<T> GetResultList<T>(IQueryable<T> source)
        {
            return source.Take(Constants.MaxResultCountDuringPreview).ToList();
        }
        private class SimpleResult
        {
            public object Value {get; set;}
        }
    }
}
