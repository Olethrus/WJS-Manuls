﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Data;
using System.Globalization;

namespace VLinq.Editor.Preview
{
    public static class TypeExtension
    {
        public static object GetDefaultValue(this Type t)
        {
            if (t.IsValueType)
                return Activator.CreateInstance(t);
            else return null;
        }
    }
    public class PrimitiveTypeConverter : DependencyObject, IValueConverter
    {


        public Type ParameterType
        {
            get { return (Type)GetValue(ParameterTypeProperty); }
            set { SetValue(ParameterTypeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ParameterType.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParameterTypeProperty =
            DependencyProperty.Register("ParameterType", typeof(Type), typeof(PrimitiveTypeConverter), new UIPropertyMetadata(typeof(string)));



        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null)
                return string.Empty;
            else if (value.GetType() == typeof(string))
                return value;
            else
            {
                return string.Format(CultureInfo.InvariantCulture, "{0}", value);
            }
   
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            if (value == null)
                return ParameterType.GetDefaultValue();
            else if (value.GetType() == ParameterType)
                return value;
            else
            {
                return System.Convert.ChangeType(value, ParameterType, CultureInfo.InvariantCulture);
            }             
        }

        #endregion
    }
}
