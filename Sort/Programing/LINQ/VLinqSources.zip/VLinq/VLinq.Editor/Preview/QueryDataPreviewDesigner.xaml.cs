﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;
using VLinq.Editor.Preview;

namespace VLinq.Editor.Preview
{
    /// <summary>
    /// Interaction logic for UCQueryDataPreview.xaml
    /// </summary>
    public partial class QueryDataPreviewDesigner : UserControl
    {
        public QueryDataPreviewDesigner()
        {
            InitializeComponent();
        }
        public PreviewerController Controller
        {
            get { return DataContext as PreviewerController; }
        }
        private Storyboard m_loadingAnim;
        private Storyboard LoadingAnim
        {
            get
            {
                if (m_loadingAnim == null)
                    m_loadingAnim = FindResource("loadingAnim") as Storyboard;
                return m_loadingAnim;
            }
        }

        private void QueryPreviewContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            bool paginated = false;
            if (e.NewValue != null)
            { 
                var s = PreviewerController.GetPaginatedSQLLog(e.NewValue as DependencyObject) as string;
                paginated = !string.IsNullOrEmpty(s);
            }
            else 
                paginated = false;

            if (paginated)
            {
                tabResPag.Visibility = Visibility.Visible;
                tabResPag.IsEnabled = true;
                tabSQLPag.Visibility = Visibility.Visible;
                tabSQLPag.IsEnabled = true;
            }
            else
            {
                tabResPag.Visibility = Visibility.Hidden;
                tabResPag.IsEnabled = false;
                tabSQLPag.Visibility = Visibility.Hidden;
                tabSQLPag.IsEnabled = false;
            }
        }

        private DataTemplate m_listOfGroupingsTemplate;
        public DataTemplate ListOfGroupingsTemplate
        {
            get
            {
                if (m_listOfGroupingsTemplate == null)
                    m_listOfGroupingsTemplate = (DataTemplate)FindResource("ListOfGroupingsTemplate");
                return m_listOfGroupingsTemplate;
            }
        }

        private DataTemplate m_listOfItemsTemplate;
        public DataTemplate ListOfItemsTemplate
        {
            get
            {
                if (m_listOfItemsTemplate == null)
                    m_listOfItemsTemplate = (DataTemplate)FindResource("ListOfItemsTemplate");
                return m_listOfItemsTemplate;
            }
        }

        private DataTemplate m_listOfValuesTemplate;
        public DataTemplate ListOfValuesTemplate
        {
            get
            {
                if (m_listOfValuesTemplate == null)
                    m_listOfValuesTemplate = (DataTemplate)FindResource("ListOfValuesTemplate");
                return m_listOfValuesTemplate;
            }
        }

        private DataTemplate m_ErrorMessageTemplate;
        public DataTemplate ErrorMessageTemplate
        {
            get
            {
                if (m_ErrorMessageTemplate == null)
                    m_ErrorMessageTemplate = (DataTemplate)FindResource("ErrorMessageTemplate");
                return m_ErrorMessageTemplate;
            }
        }

        private void SelectResultTemplate(object sender, VLinq.WPFControls.SelectTemplateEventArgs e)
        {
            if (e.Item != null)
            {
                var itemType = e.Item.GetType();
                if (itemType.IsGenericType && itemType.GetGenericTypeDefinition() == typeof(List<>))
                {
                    var enumeratedType = itemType.GetGenericArguments()[0];
                    bool isListOfGroupings = false;
                    if (enumeratedType.IsGenericType && enumeratedType.GetGenericTypeDefinition() == typeof(IGrouping<,>))
                        isListOfGroupings = true;
                    foreach (var interfaceType in enumeratedType.GetInterfaces())
                    {
                        if (interfaceType.IsGenericType && interfaceType.GetGenericTypeDefinition() == typeof(IGrouping<,>))
                        {
                            isListOfGroupings = true;
                            break;
                        }
                    }
                    if (isListOfGroupings)
                        e.Template = ListOfGroupingsTemplate;
                    else
                    {
                        if (enumeratedType.IsPrimitive || (enumeratedType == typeof(string)))
                        {
                            e.Template = ListOfValuesTemplate;
                        }
                        else
                        {
                            e.Template = ListOfItemsTemplate;
                        }
                    }
                }
                else
                    e.Template = ErrorMessageTemplate;
            }
        }

        private void DynamicList_Loaded(object sender, RoutedEventArgs e)
        {
            var listView = sender as ListView;
            var dynGridView = listView.View as DynamicGridView;
            dynGridView.TypeOfItems = listView.DataContext.GetType().GetGenericArguments()[0];
        }

        private void groupValuesList_Loaded(object sender, RoutedEventArgs e)
        {
            var listView = sender as ListView;
            var contextType = listView.DataContext.GetType();
            Type enumeratedType = null;
            foreach (var interfaceType in contextType.GetInterfaces())
            {
                if (interfaceType.IsGenericType && interfaceType.GetGenericTypeDefinition() == typeof(IEnumerable<>))
                {
                    enumeratedType = interfaceType.GetGenericArguments()[0];
                    break;
                }
            }
            if (enumeratedType != null)
            {
                if (!PreviewProperties.SupportedParameterTypes.Contains(enumeratedType))
                    listView.View = new DynamicGridView { TypeOfItems = enumeratedType };
            }
        }

        private void GroupKeyTextBlockLoaded(object sender, RoutedEventArgs e)
        {
            var txtBlock = sender as TextBlock;
            var realType = (txtBlock.DataContext).GetType();
            Type groupingType = null;
            foreach (var interfaceType in realType.GetInterfaces())
            {
                if (interfaceType.IsGenericType && interfaceType.GetGenericTypeDefinition() == typeof(IGrouping<,>))
                {
                    groupingType = interfaceType;
                    break;
                }
            }
            if (groupingType != null)
                txtBlock.Text = groupingType.GetProperty("Key").GetValue(txtBlock.DataContext, null).ToString();
        }

        public byte[] PreviewIcon
        {
            get { return Properties.Resources.Preview; }
        }

        public Visibility BeforeRunningPreviewPanel
        {
            get { return gdBeforeResult.Visibility; }
            set { gdBeforeResult.Visibility = value; }
        }
    }
}
