﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.Data.Services;
using Microsoft.VisualStudio.Shell;
using System.ComponentModel;
using System.Globalization;

namespace VLinq.Editor.Preview
{
    public class ServerExplorerBasedConnectionStringProvider : ConnectionStringProvider
    {
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public new string ConnectionString { get; set; }
        public ServerExplorerBasedConnectionStringProvider()
        {
            var connectionExplorerService = (IVsDataExplorerConnectionManager)Package.GetGlobalService(typeof(IVsDataExplorerConnectionManager));
            Connections = connectionExplorerService.Connections.Values.OrderBy(o => o.DisplayName).Select(o=>o.DisplayName).ToArray();
            
        }
        public string[] Connections
        {
            get;
            private set;
        }

        public string SelectedConnection { get; set; }

        public override string GetConnectionString()
        {
            var connectionExplorerService = (IVsDataExplorerConnectionManager)Package.GetGlobalService(typeof(IVsDataExplorerConnectionManager));
            var conn = connectionExplorerService.Connections.Values.Where(o => o.DisplayName == SelectedConnection).FirstOrDefault();
            if (conn == null)
                return null;
            else
                return conn.Connection.DisplayConnectionString;
        }
        public override string ToString()
        {
            return string.Format(CultureInfo.InvariantCulture, "[{0}]", SelectedConnection);
        }
    }
}
