﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.Processing;
using System.IO;
using System.Windows.Markup;
using Microsoft.VisualStudio.Modeling.Shell;
using System.Windows.Data;
using VLinq.WPFControls;
using System.Collections.ObjectModel;

namespace VLinq.Editor
{
    /// <summary>
    /// Expose a MappedProjection and a DirectProjection to the designer
    /// 
    /// </summary>
    public class ProjectionController : DependencyObject
    {


        /// <summary>
        /// Query being edited
        /// </summary>
        public Query Query
        {
            get { return (Query)GetValue(QueryProperty); }
            set { SetValue(QueryProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Query.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryProperty =
            DependencyProperty.Register("Query", typeof(Query), typeof(ProjectionController), new UIPropertyMetadata());

       
        QueryDesignerController m_parentController;
        public ProjectionController(QueryDesignerController parentController)
        {
            m_parentController = parentController;
            Init();
           // parentController.Query.Changed += new EventHandler<NotifyChangedEventArgs>(Query_Changed);
            //m_parentController.Query.DataSources.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(DataSources_CollectionChanged);
            //m_boundProjection = parentController.Query.Select;
            //BindProjection();
        }

        /// <summary>
        /// Init the controller (create or get projections, create TreeView items for Direct and Mapped projections)
        /// </summary>
        private void Init()
        {
            OutputTypeProperties = new ObservableCollection<string>();
            if (m_parentController.Query.Select == null)
                m_parentController.Query.Select = new DirectProjection();
            var dp = m_parentController.Query.Select as DirectProjection;

            IsMapped = dp == null;
            Query = m_parentController.Query;
            Query.Changed += new EventHandler<NotifyChangedEventArgs>(Query_Changed);

            ConstraintTreeController.SetIsAfterGroupBy(this, Query.GroupBy != null);
            Clear = new CustomCommand { IsEnabled = true };
            Clear.Executing += new EventHandler(Clear_Executing);
            ResetOutputTypeProperties();
        }

        public void ResetOutputTypeProperties()
        {
            OutputTypeProperties.Clear();
            var asMapped = Query.Select as MappedProjection;
            if (asMapped != null && !asMapped.GenerateOutputType)
            {
                var projTd = m_parentController.Validator.TypeDescriptionBuilder.BuildTypeDescription(asMapped.OutputTypeName);
                if (projTd != null)
                {
                    foreach (var prop in projTd.Properties.Select(p => p.Name))
                        OutputTypeProperties.Add(prop);
                }
            }
        }


        void Clear_Executing(object sender, EventArgs e)
        {
            Query.Select = new DirectProjection();
        }

        public CustomCommand Clear { get; set; }
        public void DeleteMappings(IEnumerable<ProjectionMapping> mappings)
        {
            var asMapped = Query.Select as MappedProjection;
            if (asMapped != null)
            {
                foreach (var m in mappings)
                    if (asMapped.Mappings.Contains(m))
                        asMapped.Mappings.Remove(m);
                if (asMapped.Mappings.Count == 0)
                    Query.Select = new DirectProjection();
                else if (asMapped.Mappings.Count == 1)
                    Query.Select = new DirectProjection { Operand = asMapped.Mappings[0].Operand };
            }
        }
        public void AddNewOperand()
        {
            var asMapped = Query.Select as MappedProjection;
            if (asMapped == null)
            {
                var oldDirect = Query.Select as DirectProjection;
                asMapped = new MappedProjection { GenerateOutputType = true };
                if (Query.ParentQuery == null)
                    asMapped.OutputTypeName = Query.Name + "Result";
                var oldMapping = new ProjectionMapping { Operand = oldDirect.Operand };
                var asDso = oldDirect.Operand as DataSourceOperand;
                if (asDso != null)
                    oldMapping.OutputProperty = asDso.DataSourceProperty;
                else
                    oldMapping.OutputProperty = "Property1";
                asMapped.Mappings.Add(oldMapping);
                Query.Select = asMapped;
            }

            asMapped.Mappings.Add(new ProjectionMapping { OutputProperty = "Property2", Operand = new ConstantOperand() });
        }

        public bool IsMapped
        {
            get { return (bool)GetValue(IsMappedProperty); }
            set { SetValue(IsMappedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsMapped.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsMappedProperty =
            DependencyProperty.Register("IsMapped", typeof(bool), typeof(ProjectionController), new UIPropertyMetadata(false));


        void Query_Changed(object sender, NotifyChangedEventArgs e)
        {
            var queryChangedEntry = e.ChangedStack.Peek();
            if (queryChangedEntry.ChangedProperty == Query.GroupByProperty)
            {
                ConstraintTreeController.SetIsAfterGroupBy(this, Query.GroupBy != null);
            }
            else if (queryChangedEntry.ChangedProperty == Query.SelectProperty)
            {
                IsMapped = Query.Select is MappedProjection;
                if (e.ChangedStack.Select(entry => entry.ChangedProperty).Where(depprop => depprop == MappedProjection.GenerateOutputTypeProperty || depprop == MappedProjection.OutputTypeNameProperty).Any())
                {
                    ResetOutputTypeProperties();
                }
            }
        }

        
        public ProjectionController()
        {
            if(System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))
            {
                QueryBagDesignerController qbController = new QueryBagDesignerController();
                qbController.QueryBag = XamlReader.Load(new MemoryStream(Properties.Resources.SampleQueries)) as QueryBag;
                QueryDesignerController qController = new QueryDesignerController(qbController.QueryBag.Queries[0],qbController, new QueryValidator(qbController.QueryBag.Queries[0], new ReflectionBasedTypeDescriptionBuilder(), QueryValidatorOptions.VerifyCSIdentifiers));
                this.m_parentController = qController;

                Init();
            }
            
            
        }
        /// <summary>
        /// Used for Drag and drop from ClassView / ObjectBrowser
        /// </summary>
        /// <param name="dataObject"></param>
        /// <returns></returns>
        public bool IsClipboardValid(System.Windows.Forms.IDataObject dataObject)
        {

            if (ClassViewNavigationInfo.IsDataPresent(dataObject, ClassViewNavigationInfoTypes.Class, true, false))
            {
                ClassViewNavigationInfoNode node = ClassViewNavigationInfo.GetData(dataObject)[0];
                {
                    if (ClassViewNavigationInfoTypes.Class == node.InfoType)
                    {
                        var td = m_parentController.Validator.TypeDescriptionBuilder.BuildTypeDescription(node.FullName);
                        if (td == null || td.IsGenericTypeDefinition)
                            return false;
                        else return true;
                    }

                }
            }
            return false;
        }
        /// <summary>
        /// Used for Drag and drop from ClassView / ObjectBrowser
        /// </summary>
        /// <param name="dataObject"></param>
        /// <returns></returns>
        public void SetOutputTypeFromClipboard(System.Windows.Forms.IDataObject dataObject)
        {
            var asMapped = Query.Select as MappedProjection;
            if (asMapped != null)
            {
                if (ClassViewNavigationInfo.IsDataPresent(dataObject, ClassViewNavigationInfoTypes.Class, true, false))
                {
                    ClassViewNavigationInfoNode node = ClassViewNavigationInfo.GetData(dataObject)[0];

                    if (ClassViewNavigationInfoTypes.Class == node.InfoType)
                    {
                        asMapped.OutputTypeName = node.FullName;

                    }

                }
            }
        }

        /// <summary>
        /// Get the properties of the output type of a MappedProjection capable of storing data of the type defined by the given Type Description
        /// </summary>
        /// <param name="td"></param>
        /// <returns></returns>
        public IEnumerable<string> GetOutputAvailableProperties(TypeDescription td)
        {
            var asMapped = Query.Select as MappedProjection;
            if (asMapped != null)
            {
                if (!asMapped.GenerateOutputType && td != null)
                {
                    var projTd = m_parentController.Validator.TypeDescriptionBuilder.BuildTypeDescription(asMapped.OutputTypeName);
                    if (projTd != null)
                    {
                        foreach (var prop in projTd.Properties)
                        {
                            if (m_parentController.Validator.TypeDescriptionBuilder.IsAssignableFrom(prop.TypeDescription, td))
                                yield return prop.Name;

                        }
                    }
                }
            }
        }

        



        public ObservableCollection<string> OutputTypeProperties
        {
            get { return (ObservableCollection<string>)GetValue(OutputTypePropertiesProperty); }
            private set { SetValue(OutputTypePropertiesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OutputTypeProperties.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty OutputTypePropertiesProperty =
            DependencyProperty.Register("OutputTypeProperties", typeof(ObservableCollection<string>), typeof(ProjectionController), new UIPropertyMetadata(null));


        //void DataSources_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        //{
        //    BindProjection();
        //}
        //public ProjectionController()
        //{ }
        //private bool m_backChanging = false;

        ////void Query_Changed(object sender, NotifyChangedEventArgs e)
        ////{
        ////    if (!m_backChanging)
        ////    {
        ////        if (m_boundProjection != m_parentController.Query.Select || e.ChangedStack.Contains(m_parentController.Query.DataSources))
        ////        {
        ////            BindProjection();
        ////        }
        ////    }
            
        ////}
        //private bool m_binding;
        //private List<DataSource> m_observedDataSources = new List<DataSource>();
        //private Group m_observedGroup;
        //private void BindProjection()
        //{
        //    m_binding = true;
        //    if(m_parentController.Query.Select == null)
        //        m_parentController.Query.Select = new MappedProjection { GenerateOutputType = true };
        //    MappedProjection mp = m_parentController.Query.Select as MappedProjection;
            
        //    if (mp != null)
        //    {
        //        OutputTypeName = mp.OutputTypeName;
        //        var mappings = new Dictionary<string, List<ProjectionMapping>>();
        //        foreach (ProjectionMapping pm in mp.Mappings)
        //        {
        //            if ((bool)pm.GetValue(ValidTimeProperties.IsValidProperty))
        //            {
        //                var dsOperand = pm.Operand as DataSourceOperand;
        //                if (dsOperand != null)
        //                {
                            
        //                    if (!mappings.ContainsKey(dsOperand.DataSourceName))
        //                        mappings.Add(dsOperand.DataSourceName, new List<ProjectionMapping>());
        //                    mappings[dsOperand.DataSourceName].Add(pm);
        //                }
        //            }
        //        }
        //        var items = new NotifyChangedCollection<ProjectionItemData>();
        //        if (m_parentController.Query.GroupBy != null)
        //        {
        //            var typeDesc = m_parentController.Query.GroupBy.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription;
        //            if (typeDesc != null)
        //            {
        //                var item = new ProjectionItemData() { Label = m_parentController.Query.GroupBy.GroupName, OutputName = m_parentController.Query.GroupBy.GroupName };
        //                if (mappings.ContainsKey(m_parentController.Query.GroupBy.GroupName))
        //                {
        //                    var mapping = (from ms in mappings[m_parentController.Query.GroupBy.GroupName]
        //                                   where (ms.Operand as DataSourceOperand).DataSourceProperty == null
        //                                   select ms).FirstOrDefault();
        //                    if (mapping != null)
        //                    {
        //                        item.Checked = true;
        //                        item.OutputName = mapping.OutputProperty;
        //                    }

        //                }
        //                CreateChildProjectionItems(typeDesc, item, mappings, 1);
        //                items.Add(item);
        //            }
        //            if (m_observedGroup != m_parentController.Query.GroupBy)
        //            {
        //                m_observedGroup = m_parentController.Query.GroupBy;
        //                m_observedGroup.Changed += delegate
        //                {
        //                    items_Changed(this, new NotifyChangedEventArgs());
        //                };
        //            }
        //        }
        //        foreach (var ds in m_parentController.Query.DataSources)
        //        {
        //            if (m_parentController.Query.GroupBy == null || ds is ParameterSource)
        //            {
        //                var typeDesc = ds.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription;
        //                if (typeDesc != null)
        //                {
        //                    var item = new ProjectionItemData() { BoundDataSource = ds, Label = ds.Name, OutputName = ds.Name };
        //                    if (mappings.ContainsKey(ds.Name))
        //                    {
        //                        var mapping = (from ms in mappings[ds.Name]
        //                                       where (ms.Operand as DataSourceOperand).DataSourceProperty == null
        //                                       select ms).FirstOrDefault();
        //                        if (mapping != null)
        //                        {
        //                            item.Checked = true;
        //                            item.OutputName = mapping.OutputProperty;
        //                        }

        //                    }
        //                    CreateChildProjectionItems(typeDesc, item, mappings, 1);
        //                    items.Add(item);
        //                }
        //                if (!m_observedDataSources.Contains(ds))
        //                    ds.NameChanged += delegate
        //                    {
        //                        items_Changed(this, new NotifyChangedEventArgs());
        //                    };
        //            }
        //        }
        //        if(ProjectionItems != null)
        //            ProjectionItems.Changed -= new EventHandler<NotifyChangedEventArgs>(items_Changed);
        //        items.Changed += new EventHandler<NotifyChangedEventArgs>(items_Changed);
        //        SetValue(ProjectionItemsProperty, items);
        //    }
        //    m_binding = false ;
            
        //}

        //void items_Changed(object sender, NotifyChangedEventArgs e)
        //{
        //    if (!m_backChanging && !m_binding)
        //    {
        //        m_backChanging = true;
        //        (m_parentController.Query.Select as MappedProjection).Mappings.Clear();
                
        //        BackChange(m_parentController.Query.Select as MappedProjection, ProjectionItems);

        //        (m_parentController.Query.Select as MappedProjection).OutputTypeName = OutputTypeName;

        //        m_backChanging = false;
        //    }
        //}

        //private void BackChange(MappedProjection projection, NotifyChangedCollection<ProjectionItemData> items)
        //{

        //    foreach (var item in items)
        //    {
        //        var mapping = (from m in projection.Mappings
        //                       where m.Operand is DataSourceOperand
        //                             && (m.Operand as DataSourceOperand).DataSourceName == item.BoundDataSource.Name
        //                             && (m.Operand as DataSourceOperand).DataSourceProperty == item.BoundDataSourceProperty
        //                       select m).SingleOrDefault();
        //        if (item.Checked)
        //        {
        //            if (mapping == null)
        //            {
        //                mapping = new ProjectionMapping
        //                {
        //                    Operand = new DataSourceOperand { DataSourceName = item.BoundDataSource.Name, DataSourceProperty = item.BoundDataSourceProperty },
        //                    OutputProperty = item.OutputName
        //                };
        //                projection.Mappings.Add(mapping);
        //            }
        //            else
        //            {
        //                mapping.OutputProperty = item.OutputName;
        //            }
        //        }
        //        else
        //        {
        //            if (mapping != null)
        //                projection.Mappings.Remove(mapping);
        //        }
        //        BackChange(projection, item.Children);

        //    }
        //}

        //private void CreateChildProjectionItems(TypeDescription parentType, ProjectionItemData parentNode, Dictionary<string, List<ProjectionMapping>> mappings, int depth)
        //{
        //    foreach (var prop in parentType.Properties)
        //    {
        //        var child = new ProjectionItemData
        //        {
        //            BoundDataSource = parentNode.BoundDataSource
        //            ,
        //            BoundDataSourceProperty = parentNode.BoundDataSourceProperty == null ? prop.Name : string.Format("{0}.{1}", parentNode.BoundDataSourceProperty, prop.Name)
        //            ,
        //            Label = prop.Name
        //            ,
        //            OutputName = prop.Name,
        //            Depth = depth
        //        };

        //        if (parentNode.BoundDataSource != null && mappings.ContainsKey(parentNode.BoundDataSource.Name))
        //        {
        //            var mapping = (from ms in mappings[parentNode.BoundDataSource.Name]
        //                           where (ms.Operand as DataSourceOperand).DataSourceProperty == child.BoundDataSourceProperty
        //                           select ms).FirstOrDefault();
        //            if (mapping != null)
        //            {
        //                child.Checked = true;
        //                child.OutputName = mapping.OutputProperty;
        //            }
        //        }
        //        parentNode.Children.Add(child);
                    
        //    }
        //}



        //public NotifyChangedCollection<ProjectionItemData> ProjectionItems
        //{
        //    get { return (NotifyChangedCollection<ProjectionItemData>)GetValue(ProjectionItemsProperty); }
        //}

        //// Using a DependencyProperty as the backing store for ProjectionItems.  This enables animation, styling, binding, etc...
        //public static readonly DependencyProperty ProjectionItemsProperty =
        //    DependencyProperty.Register("ProjectionItems", typeof(NotifyChangedCollection<ProjectionItemData>), typeof(ProjectionController));




        //public string OutputTypeName
        //{
        //    get { return (string)GetValue(OutputTypeNameProperty); }
        //    set { SetValue(OutputTypeNameProperty, value); }
        //}

        //// Using a DependencyProperty as the backing store for OutputTypeName.  This enables animation, styling, binding, etc...
        //public static readonly DependencyProperty OutputTypeNameProperty =
        //    DependencyProperty.Register("OutputTypeName", typeof(string), typeof(ProjectionController), new PropertyMetadata(delegate(DependencyObject obj, DependencyPropertyChangedEventArgs args) { (obj as ProjectionController).items_Changed(obj, new NotifyChangedEventArgs()); }));


    }
    
}
