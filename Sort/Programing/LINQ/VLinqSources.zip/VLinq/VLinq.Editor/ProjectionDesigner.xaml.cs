﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.Editor.Operands;
using System.Diagnostics;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for ProjectionDesigner.xaml
    /// </summary>
    public partial class ProjectionDesigner : UserControl
    {
        public ProjectionDesigner()
        {
            InitializeComponent();
            this.Loaded += new RoutedEventHandler(ProjectionDesigner_Loaded);
            
        }

        void ProjectionDesigner_Loaded(object sender, RoutedEventArgs e)
        {
            if (Controller != null)
            {
                DesignTimeProperties.SetEditorFor(Controller.Query.Select, this);
                Controller.Query.Changed += delegate(object sender2, NotifyChangedEventArgs args)
                {
                    var sourceOfChanges = args.ChangedStack.Peek();
                    if(sourceOfChanges.ChangedProperty == Query.SelectProperty)
                        DesignTimeProperties.SetEditorFor(Controller.Query.Select, this);
                };
            }
        }
        public void OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs args)
        {
            
        }

        public ProjectionController Controller
        {
            get { return DataContext as ProjectionController; }
        }

        private void chkGenOutput_Checked(object sender, System.Windows.RoutedEventArgs e)
        {
            outputTypePicker.ContentTemplate = FindResource("GeneratedTypeNameTemplate") as DataTemplate;
           
        }
        private void chkGenOutput_Unchecked(object sender, System.Windows.RoutedEventArgs e)
        {
            outputTypePicker.ContentTemplate = FindResource("ExistingTypeNameTemplate") as DataTemplate;
        }

        private void existingTypeDropZone_DragEnter(object sender, DragEventArgs e)
        {
            var ctrl = Controller;
            bool valid = false;
            if (ctrl != null)
                valid = ctrl.IsClipboardValid(new System.Windows.Forms.DataObject(e.Data));
            e.Effects = valid ? DragDropEffects.Copy : DragDropEffects.None;
            e.Handled = true;
        }

        private void existingTypeDropZone_DragOver(object sender, DragEventArgs e)
        {
            var ctrl = Controller;
            bool valid = false;
            if (ctrl != null)
                valid = ctrl.IsClipboardValid(new System.Windows.Forms.DataObject(e.Data));
            e.Effects = valid ? DragDropEffects.Copy : DragDropEffects.None;
            e.Handled = true;
        }

        private void existingTypeDropZone_Drop(object sender, DragEventArgs e)
        {
            var ctrl = Controller;
            if (ctrl != null)
                ctrl.SetOutputTypeFromClipboard(new System.Windows.Forms.DataObject(e.Data));
        }

        private void OperandHost_Loaded(object sender, RoutedEventArgs e)
        {
            var opHost = sender as OperandHost;
            opHost.Controller.Query = Controller.Query;
        }

        private void btnAddOperand_Click(object sender, RoutedEventArgs e)
        {
            Controller.AddNewOperand();
        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
            var senderAsLst = sender as ListBox;
            try
            {
                var removeBtn = senderAsLst.FindName("btnRemove") as Button;
                removeBtn.IsEnabled = senderAsLst.SelectedItems.Count > 0;
            }
            catch
            {
                Debug.WriteLine("Exception (ProjectionDesigner) : removeBtn exist cannot be disabled (normal if it is due to a \"Clear\" operation");
            }
        }

        private void btnRemoveOperand_Click(object sender, RoutedEventArgs e)
        {
            var removeBtn = sender as Button;
            var lstMappings = removeBtn.FindName("lstMappings") as ListBox;
            Controller.DeleteMappings (new List<ProjectionMapping> ( lstMappings.SelectedItems.Cast<ProjectionMapping>()));
        }

        private void comboOutputPropLoaded(object sender, RoutedEventArgs e)
        {
            var asCombo = sender as ComboBox;
            if (asCombo != null)
                asCombo.ItemsSource = Controller.OutputTypeProperties;
        }



        

    }
}
