﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VLinq.WPFControls;
using System.Windows;
using VLinq.Processing;

namespace VLinq.Editor
{
    /// <summary>
    /// TreeViewItem for DirectProjection (and base class of MappedProjectionItem)
    /// </summary>
    public class ProjectionItem : TreeListViewItem, IVLinqComponent
    {
        
        private ProjectionController m_controller;
        protected ProjectionController Controller
        {
            get { return m_controller; }
        }


        public Projection Projection
        {
            get { return (Projection)GetValue(ProjectionProperty); }
            private set { SetValue(ProjectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Projection.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProjectionProperty =
            DependencyProperty.Register("Projection", typeof(Projection), typeof(ProjectionItem), new UIPropertyMetadata());

        /// <summary>
        /// When the projection is set, we verify if the current item should be checked
        /// </summary>
        /// <param name="projection"></param>
        public virtual void SetProjection(Projection projection)
        {
            Projection = projection;
            var dp = projection as DirectProjection;
            if (dp != null)
            {
                UpdateDirectProjectionCheckedState();
                dp.Changed += delegate
                {
                    UpdateDirectProjectionCheckedState();
                };
                
            }
        }
        /// <summary>
        /// Look at the current projected operand and verify if it matches the current item
        /// </summary>
        private void UpdateDirectProjectionCheckedState()
        {
            var dp = Projection as DirectProjection;
            var dsOperand = dp.Operand as DataSourceOperand;
            if (dsOperand == null)
            {
                Checked = false;
            }
            else
            {
                Checked = dsOperand.DataSourceName == DataSource.Name &&
                    string.IsNullOrEmpty(dsOperand.DataSourceProperty) ? (Property == null || Property.Length == 0) :
                                                                         (Property != null && string.Join(".", Property.Select(p => p.Name).ToArray()) == dsOperand.DataSourceProperty);
                if (!Checked)
                {
                    if (!string.IsNullOrEmpty(dsOperand.DataSourceProperty)
                        && dsOperand.DataSourceName == DataSource.Name
                        && ((Property == null || Property.Length == 0)
                           || (Property !=null && dsOperand.DataSourceProperty.StartsWith(
                               string.Join(".", Property.Select(o=>o.Name).ToArray())
                                ))))
                    {
                        this.IsExpanded = true;
                    }
                }
            }
        }

        public DataSource DataSource
        {
            get { return (DataSource)GetValue(DataSourceProperty); }
            set { SetValue(DataSourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DataSource.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty DataSourceProperty =
            DependencyProperty.Register("DataSource", typeof(DataSource), typeof(ProjectionItem), new UIPropertyMetadata(null, OnDataSourceChanged));

        private static void OnDataSourceChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ProjectionItem elem = obj as ProjectionItem;
            if (elem != null)
            {
                elem.OnDataSourceChanged(args.OldValue == null ? default(DataSource) : (DataSource)args.OldValue, args.NewValue == null ? default(DataSource) : (DataSource)args.NewValue);
            }
        }

        /// <summary>
        /// set the header of the item given its related DataSource / Property (will be replaced, to handle Detailed / Simple view modes)
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected virtual void OnDataSourceChanged(DataSource oldValue, DataSource newValue)
        {
            if (newValue != null)
            {
                if (Property == null)
                {
                    var dsType= ValidTimeProperties.GetReturnType(newValue);
                    Header = string.Format("{0} ({1})", newValue.Name, dsType == null ? "?" : dsType.CSharpTypeName);

                }

                newValue.Changed += new EventHandler<NotifyChangedEventArgs>(CurrentDataSourcePropertyChanged);
            }
        }
        /// <summary>
        /// set the header of the item given its related DataSource / Property (will be replaced, to handle Detailed / Simple view modes)
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        void CurrentDataSourcePropertyChanged(object sender, NotifyChangedEventArgs e)
        {
            if (DataSource != null)
            {
                if (Property == null)
                {
                    Header = DataSource.Name;
                }
            }
            
        }




        /// <summary>
        /// Chain of PropertyDescriptions defining the related property path
        /// </summary>
        public PropertyDescription[] Property
        {
            get { return (PropertyDescription[])GetValue(PropertyProperty); }
            set { SetValue(PropertyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Property.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty PropertyProperty =
            DependencyProperty.Register("Property", typeof(PropertyDescription[]), typeof(ProjectionItem), new UIPropertyMetadata(null, OnPropertyChanged));

        private static void OnPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ProjectionItem elem = obj as ProjectionItem;
            if (elem != null)
            {
                elem.OnPropertyChanged(args.OldValue == null ? default(PropertyDescription[]) : (PropertyDescription[])args.OldValue, args.NewValue == null ? default(PropertyDescription[]) : (PropertyDescription[])args.NewValue);
            }
        }
        /// <summary>
        /// set the header of the item given its related DataSource / Property (will be replaced, to handle Detailed / Simple view modes)
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected virtual void OnPropertyChanged(PropertyDescription[] oldValue, PropertyDescription[] newValue)
        {
            if (newValue != null)
            {
                var last = newValue.Last();
                Header = string.Format("{0} ({1})", last.Name, last.TypeDescription == null ? "?" : last.TypeDescription.CSharpTypeName);
            }
        }





        /// <summary>
        /// Indicates if the item is part of the projection
        /// </summary>
        public bool Checked
        {
            get { return (bool)GetValue(CheckedProperty); }
            set { SetValue(CheckedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Checked.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CheckedProperty =
            DependencyProperty.Register("Checked", typeof(bool), typeof(ProjectionItem), new UIPropertyMetadata(false, OnCheckedChanged));

        private static void OnCheckedChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            ProjectionItem elem = obj as ProjectionItem;
            if (elem != null)
            {
                elem.OnCheckedChanged(args.OldValue == null ? default(bool) : (bool)args.OldValue, args.NewValue == null ? default(bool) : (bool)args.NewValue);
            }
        }
        /// <summary>
        /// Affect the related DirectProjection
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected virtual void OnCheckedChanged(bool oldValue, bool newValue)
        {
            var dp = Projection as DirectProjection;
            if (dp != null && newValue)
            {
                dp.Operand = new DataSourceOperand
                {
                    DataSourceName = DataSource.Name,
                    DataSourceProperty = Property == null ? string.Empty : string.Join(".", Property.Select(o => o.Name).ToArray())
                };
            }
        }



        public void UncheckItAndChildren()
        {
            Checked = false;
            foreach (var item in Items)
            {
                var projItem = item as ProjectionItem;
                if (projItem != null)
                    projItem.UncheckItAndChildren();
            }
        }

        public ProjectionItem(ProjectionController controller)
        {
            m_controller = controller;
            // the children are generated at first-expanding.
            //to show the Expand / Collapse button, we initially add a "Loading" treeview item to children collection
            this.Items.Add( new TreeListViewItem { Header = new { Label = "Loading..." } } );
        }
        private bool m_alreadyFilled = false;

        protected virtual ProjectionItem CreateSubItem(DataSource dataSource, PropertyDescription[] propDescs)
        {
            var projItem = (new ProjectionItem(Controller) { DataSource = dataSource, Property = propDescs });
            projItem.SetProjection(Projection);
            return projItem;
        }

        /// <summary>
        /// The children are loaded at first expanding.
        /// So OnExpanded is overriden
        /// </summary>
        /// <param name="e"></param>
        protected override void OnExpanded(System.Windows.RoutedEventArgs e)
        {
            base.OnExpanded(e);
            if (!m_alreadyFilled)
            {
                if (Property == null && DataSource != null)
                {
                    var td = ValidTimeProperties.GetReturnType(DataSource);
                    if (td != null)
                    {
                        foreach (var prop in td.Properties)
                        {
                            var projItem = CreateSubItem(DataSource, new PropertyDescription[] { prop });
                            
                            projItem.SetOwner(this, null);
                            Items.Add(projItem);
                        }
                    }
                }
                else if (Property != null && DataSource != null)
                {
                    var td = Property.Last().TypeDescription;
                    if (td != null)
                    {
                        foreach (var prop in td.Properties)
                        {
                            PropertyDescription[] propArray = new PropertyDescription[Property.Length + 1];
                            Array.Copy(Property, propArray, Property.Length);
                            propArray[Property.Length] = prop;
                            var projItem = CreateSubItem( DataSource, propArray);
                            projItem.SetOwner(this,null);
                            Items.Add(projItem);
                        }
                    }
                }
                Items.RemoveAt(0);
                m_alreadyFilled = true;
            }
        }



        #region INotifyChanged Members
        DependencyProperty m_ownerProperty;
        public DependencyProperty GetOwnerProperty()
        {
            return m_ownerProperty;
        }
        public IVLinqComponent GetOwner()
        {
            return m_owner;
        }
        private IVLinqComponent m_owner;
        public event EventHandler<NotifyChangedEventArgs> Changed;

        public void NotifyChanged(DependencyProperty property)
        {
            BubbleChangedEvent(new NotifyChangedEventArgs(), property);
        }

        public void SetOwner(IVLinqComponent owner,DependencyProperty ownerProperty)
        {

            m_owner = owner;
            m_ownerProperty = ownerProperty;
        }





        public void BubbleChangedEvent(NotifyChangedEventArgs args, DependencyProperty property)
        {
            args.ChangedStack.Push(new ChangeNotificationEntry { ChangedObject = this, ChangedProperty = property });
            if (Changed != null)
                Changed(this, args);
            if (m_owner != null)
            {
                m_owner.BubbleChangedEvent(args,m_ownerProperty);
            }
        }

        #endregion

        #region INotifyChanged Members


        public IEnumerable<TextFragment> ToInlines()
        {
            yield break;
        }

        #endregion
    }
}
