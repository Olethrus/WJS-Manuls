﻿using System;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Markup;
using System.IO;
using System.Windows.Controls.Primitives;
using System.Windows.Media.Animation;
using System.ComponentModel;
using System.Globalization;
using VLinq.Editor.Preview;
using System.Diagnostics;
using System.Xml;
using Microsoft.VisualStudio.Modeling.Shell;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for QueryBagDesigner.xaml
    /// </summary>
    public partial class QueryBagDesigner : System.Windows.Controls.UserControl
    {
        private class QueryGroupConverter : IValueConverter
        {
            #region IValueConverter Members

            public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
            {
                if (value is CustomQuery)
                    return Messages.CustomQueryGroupLabel;
                else
                    return Messages.VLinqQueryGroupLabel;
            }

            public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
            {
                throw new NotImplementedException();
            }

            #endregion
        }
        private class DragDropAdorner : Adorner
        {
            public DragDropAdorner(UIElement elem) : base(elem) {
                this.IsHitTestVisible = false;
            }
            public IDataObject DataObject { get; set; }
            protected override void OnRender(DrawingContext drawingContext)
            {
                
                base.OnRender(drawingContext);
                if (DataObject != null)
                {
                    var rectPos = new Point(MousePosition.X + 5, MousePosition.Y + 10);
                    var textPos = new Point(rectPos.X + 4, rectPos.Y + 4);

                    if (DataObject.GetDataPresent(DataSourceController.DataSourcePropertyFormat))
                    {
                        FormattedText ftext = null;
                        var parts = DataObject.GetData(DataSourceController.DataSourcePropertyFormat).ToString().Split('|');
                        if (parts.Length == 1 || parts[1].Length == 0)
                        {
                            ftext = new FormattedText(string.Format(CultureInfo.InvariantCulture,"{0}\n{1}", parts[0], Messages.DraggingEntitySourceHelpText),
                                CultureInfo.InvariantCulture,
                                FlowDirection.LeftToRight,
                                new Typeface("Verdana"),
                                12,
                                new SolidColorBrush(Color.FromArgb(200, 0, 0, 0)));
                        }
                        else
                        {
                            ftext = new FormattedText(string.Format(CultureInfo.InvariantCulture,"{0}.{1}\n{2}", parts[0] ,parts[1],Messages.DraggingEntitySourcePropertyHelpText) ,
                                CultureInfo.InvariantCulture,
                                FlowDirection.LeftToRight,
                                new Typeface("Verdana"),
                                12,
                                new SolidColorBrush(Color.FromArgb(200, 0, 0, 0)));
                        }


                        
                        drawingContext.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)),
                            new Pen(new SolidColorBrush(Color.FromArgb(200, 0, 0, 0)),1.0),
                            new Rect(rectPos,new Size(ftext.Width+8, ftext.Height+8)),4,4);
                        drawingContext.DrawText(ftext, textPos);
                        return;
                    }
                    var winformDO = new System.Windows.Forms.DataObject(DataObject);
                    if (ClassViewNavigationInfo.IsDataPresent(winformDO, ClassViewNavigationInfoTypes.Class, true, false))
                    {
                        StringBuilder sbuilder = new StringBuilder();
                        bool first = true;
                        foreach (ClassViewNavigationInfoNode node in ClassViewNavigationInfo.GetData(winformDO).Where(o=>o.InfoType == ClassViewNavigationInfoTypes.Class))
                        {
                            if(first)
                                first = false;
                            else
                                sbuilder.AppendLine();
                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, "{0} {1}", node.FullName, Messages.DraggingFromClassViewHelpText);

                        }

                        FormattedText ftext = new FormattedText(sbuilder.ToString(),
                                CultureInfo.InvariantCulture,
                                FlowDirection.LeftToRight,
                                new Typeface("Verdana"),
                                12,
                                new SolidColorBrush(Color.FromArgb(200, 0, 0, 0)));

                        drawingContext.DrawRoundedRectangle(new SolidColorBrush(Color.FromArgb(200, 255, 255, 255)),
                            new Pen(new SolidColorBrush(Color.FromArgb(200, 0, 0, 0)),1.0),
                            new Rect(rectPos,new Size(ftext.Width+8, ftext.Height+8)),4,4);
                        drawingContext.DrawText(ftext, textPos);
                    }
                }
            }
            public Point MousePosition { get; set; }
        }
        public QueryBagDesigner()
        {
            InitializeComponent();
            m_groupDescription = new PropertyGroupDescription { Converter = new QueryGroupConverter() };
            Controller.QueryBagSet += new EventHandler(Controller_QueryBagChanged);
            this.AddHandler(VLinqBeginDragDropEvent, new VLinqBeginDragDropEventHandler( OnVLinqBeginDragDrop));
            this.AddHandler(VLinqEndDragDropEvent, new RoutedEventHandler( OnVLinqEndDragDrop));
            m_adorner = new DragDropAdorner(this);
            this.AllowDrop = true;

        }

        private DragDropAdorner m_adorner;
        bool m_adorning = false;
        protected override void OnPreviewDragEnter(DragEventArgs e)
        {

            base.OnPreviewDragEnter(e);
                if (!e.Handled)
                    e.Effects = DragDropEffects.None;
                m_adorner.DataObject = e.Data;
                AdornerLayer.GetAdornerLayer(this).Add(m_adorner);
                m_adorning = true;
            
        }
        protected override void OnPreviewDragOver(DragEventArgs e)
        {
            base.OnPreviewDragOver(e);
            if (!e.Handled)
                e.Effects = DragDropEffects.None;
            if (m_adorning)
            {
                m_adorner.MousePosition = e.GetPosition(this);
                m_adorner.InvalidateVisual();
            }
        }
        protected override void OnPreviewDrop(DragEventArgs e)
        {
            base.OnPreviewDrop(e);
            if (m_adorning)
            {
                m_adorning = false;
                AdornerLayer.GetAdornerLayer(this).Remove(m_adorner);
            }
        }
        protected override void OnPreviewDragLeave(DragEventArgs e)
        {
            base.OnPreviewDragLeave(e);
                m_adorner.DataObject = null;
                m_adorning = false;
                AdornerLayer.GetAdornerLayer(this).Remove(m_adorner);
        }
        private void OnVLinqBeginDragDrop(object sender, VLinqBeginDragDropEventArgs args)
        {
            Debug.WriteLine("QueryBag : begin drag drop received");
        }
        private void OnVLinqEndDragDrop(object sender, RoutedEventArgs args)
        {
            Debug.WriteLine("QueryBag : end drag drop received");
        }

        /// <summary>
        /// When the querybag of the controller is set, we create a collection view for the query list
        /// It is used for instant searching
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void Controller_QueryBagChanged(object sender, EventArgs e)
        {
            var ctrl = Controller;
            if (Controller != null)
            {
                m_collectionView = CollectionViewSource.GetDefaultView(Controller.Queries);
                m_collectionView.SortDescriptions.Add( new SortDescription { Direction = ListSortDirection.Ascending, PropertyName = "Name" } );
                this.btnGroupQueries.IsChecked = Controller.Queries.OfType<CustomQuery>().Any();
            }
        }

        private GroupDescription m_groupDescription;

        private ICollectionView m_collectionView;

        /// <summary>
        /// when the text of the searchbox changed, we update the queries collection view to filter them
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void searchBox_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            if (m_collectionView != null)
            {
                if (string.IsNullOrEmpty(searchBox.Text))
                {
                    m_collectionView.Filter = null;
                }
                else
                {
                    m_collectionView.Filter = new Predicate<object>((object o)=> (o as INamed).Name.ToLower().Contains(searchBox.Text.ToLower()));
                }
            }
        }

        public QueryBagDesignerController Controller
        {
            get { return DataContext as QueryBagDesignerController; }
        }

        private void ShowPreview(Preview.PreviewInfoItem previewInfoSource)
        {
            var previewer = new PreviewerController();
            previewDesigner.DataContext = previewer;
            previewer.PreviewInfoItems = new Preview.PreviewInfoItem[] { previewInfoSource };
            previewDesigner.BeforeRunningPreviewPanel = Visibility.Hidden;
        }

        private void customQueryParameterLoaded(object sender, RoutedEventArgs e)
        {
            FrameworkElement templateRoot = sender as FrameworkElement;
            FrameworkElement comma = templateRoot.FindName("comma") as FrameworkElement;
            var itemsControl = templateRoot.FindFirstVisualAncestorOf<ItemsControl>();
            var itemContainer = itemsControl.ItemContainerGenerator.ContainerFromItem(templateRoot.DataContext);
            var itemIndex = itemsControl.ItemContainerGenerator.IndexFromContainer(itemContainer);
            if (itemIndex == 0)
                comma.Visibility = Visibility.Collapsed;
        }

        private void PreviewAll_Click(object sender, RoutedEventArgs e)
        {
            if (!Controller.QueryBag.TestConnectionString())
            {
                MessageBox.Show(Messages.ConnectionStringNotSet, Messages.PreviewUnavailableCaption, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return;
            }

            try
            {
                var previewInfoSource = Controller.GetAllPreviewInfos().ToList();
                var ctrl = new PreviewerController();
                ctrl.PreviewInfoItems = previewInfoSource;
            }
            catch (Preview.VLinqQueryPreviewMethodResolverException vqpe)
            {
                MessageBox.Show(Messages.VLinqQueryNotCompiled.Replace("{QueryName}", vqpe.Query.Name), Messages.PreviewGenerationErrorCaption, MessageBoxButton.OK);
            }
            catch (Preview.CustomQueryPreviewMethodResolverException cqpe)
            {
                MessageBox.Show(Messages.CustomQueryNotResolved.Replace("{QueryName}", cqpe.Query.Name), Messages.PreviewGenerationErrorCaption, MessageBoxButton.OK);
            }
        }

        private bool CheckPreviewReady()
        {
            if (Controller.IsProjectDirty)
            {
                MessageBox.Show(Messages.ProjectMustBeCompiled, Messages.PreviewUnavailableCaption, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return false;
            }
            if (!Controller.QueryBag.TestConnectionString())
            {
                MessageBox.Show(Messages.ConnectionStringNotSet, Messages.PreviewUnavailableCaption, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                return false;
            }
            return true;
        }

        private void PreviewQuery_Click(object sender, RoutedEventArgs e)
        {
            if (CheckPreviewReady() && lstQueries.SelectedItem != null)
            {
                try
                {
                    var query = lstQueries.SelectedItem as Query;
                    Preview.PreviewInfoItem previewInfoSource = null;
                    if (query != null)
                        previewInfoSource = Controller.GetVLinqQueryPreviewInfo(query);
                    else
                        previewInfoSource = Controller.GetCustomQueryPreviewInfo(lstQueries.SelectedItem as CustomQuery);
                    ShowPreview(previewInfoSource);
                }
                catch (Preview.VLinqQueryPreviewMethodResolverException vqpe)
                {
                    MessageBox.Show(Messages.VLinqQueryNotCompiled.Replace("{QueryName}", vqpe.Query.Name), Messages.PreviewGenerationErrorCaption, MessageBoxButton.OK);
                }
                catch (Preview.CustomQueryPreviewMethodResolverException cqpe)
                {
                    MessageBox.Show(Messages.CustomQueryNotResolved.Replace("{QueryName}", cqpe.Query.Name), Messages.PreviewGenerationErrorCaption, MessageBoxButton.OK);
                }
            }
        }

        private void queryDesigner_Click(object sender, MouseButtonEventArgs e)
        {
            var elem = sender as ListView;
            if (elem != null)
            {
                var query = elem.FindItemAtPostion<Query, ListBoxItem>(e.GetPosition(elem));
                if (query != null)
                {
                    if (Controller.IsDirty)
                    {
                        if (MessageBox.Show(Messages.QueryBagIsNotSaved, "", MessageBoxButton.OKCancel, MessageBoxImage.Question, MessageBoxResult.OK) != MessageBoxResult.OK)
                            return;
                        else
                            Controller.Save();
                    }
                    EditQuery(query);
                }
            }
        }

        private void EditQuery(Query query)
        {
            EditQuery(query, false);
        }

        private void EditQuery(Query query, bool newQuery)
        {
            this.Cursor = Cursors.Wait;
            var strBackup = XamlWriter.Save(query);
            var qBackup = XamlReader.Load(XmlTextReader.Create(new StringReader(strBackup))) as Query;
            var queryDesigner = new QueryDesigner();

            queryDesigner.IsNewQuery = newQuery;

            queryDesigner.DataContext = queryDesigner.Controller = query.GetValue(QueryBagDesignerController.AttachedQueryControllerProperty) as QueryDesignerController;
            queryDesigner.Controller.Backup = qBackup;
            queryDesigner.Controller.RollbackToBackup = false;
            QueryDesignerContainer.Child = queryDesigner;
            QueryDesignerContainer.RenderTransform.SetValue(TranslateTransform.XProperty, ActualWidth);
            QueryDesignerContainer.IsHitTestVisible = false;
            currentView.IsHitTestVisible = false;

            WPFHelpers.WaitForPriority(System.Windows.Threading.DispatcherPriority.Background);
            
            var currentViewAnim = WPFHelpers.CreateDeceleratingDoubleAnimation(
                0, -ActualWidth, Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

            var newViewAnim = WPFHelpers.CreateDeceleratingDoubleAnimation(
                ActualWidth, 0, Constants.SplineDeceleration, Constants.ShiftAnimationDuration);
            newViewAnim.Completed+=delegate
            {
                this.ClearValue(CursorProperty);
                QueryDesignerContainer.RenderTransform.SetValue(TranslateTransform.XProperty, 0.0);
                QueryDesignerContainer.IsHitTestVisible = true;
                currentView.IsHitTestVisible = true;
            };

            currentView.RenderTransform.BeginAnimation(TranslateTransform.XProperty, currentViewAnim);
            QueryDesignerContainer.RenderTransform.BeginAnimation(TranslateTransform.XProperty, newViewAnim);
           
            queryDesigner.CloseClicked += delegate
            {
                if (queryDesigner.Controller.RollbackToBackup)
                {
                    if (queryDesigner.IsNewQuery)
                    {
                        Controller.DeleteQuery.Execute(query);
                        Controller.IsDirty = false;
                    }
                    else
                    {
                        Controller.DeleteQuery.Execute(query);
                        Controller.QueryBag.Queries.Add(queryDesigner.Controller.Backup);
                        Controller.IsDirty = false;
                    }
                }
                QueryDesignerContainer.IsHitTestVisible = false;
                currentView.IsHitTestVisible = false;

                var currentViewBackAnim =
                    WPFHelpers.CreateDeceleratingDoubleAnimation(-ActualWidth, 0, Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

                var newViewBackAnim =
                    WPFHelpers.CreateDeceleratingDoubleAnimation(0, ActualWidth, Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

                newViewBackAnim.Completed += delegate
                {
                    QueryDesignerContainer.Child = null;
                    QueryDesignerContainer.IsHitTestVisible = true;
                    currentView.IsHitTestVisible = true;
                };
                currentView.RenderTransform.BeginAnimation(TranslateTransform.XProperty, currentViewBackAnim);
                QueryDesignerContainer.RenderTransform.BeginAnimation(TranslateTransform.XProperty, newViewBackAnim);
            };
        }

        private void editBtnClick(object sender, RoutedEventArgs e)
        {
            if (Controller.IsDirty)
            {
                if (MessageBox.Show(Messages.QueryBagIsNotSaved, "", MessageBoxButton.OKCancel, MessageBoxImage.Question, MessageBoxResult.OK) != MessageBoxResult.OK)
                    return;
                else
                    Controller.Save();
            }
            var query = lstQueries.SelectedItem as Query;
            if (query != null)
                EditQuery(query);
        }

        private void lstQueries_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            RefreshPreviewButtonState();

            previewDesigner.DataContext = null;
            var tabctl = previewDesigner.FindFirstVisualDescendantOf<TabControl>(VisualChildExplorationMode.Horizontal);
            if (tabctl != null)
                tabctl.SelectedIndex = 0;
            if (lstQueries.SelectedItem == null)
            {
                btnEdit.Visibility = Visibility.Collapsed;
                previewDesigner.BeforeRunningPreviewPanel = Visibility.Visible;
                btnRemove.Visibility = Visibility.Collapsed;
            }
            else
            {
                bool isVLinqQuery = lstQueries.SelectedItem is Query;
                if (isVLinqQuery)
                {
                    btnEdit.Visibility = Visibility.Visible;
                    btnRemove.Visibility = Visibility.Visible;
                }
                else
                {
                    btnEdit.Visibility = Visibility.Collapsed;
                    btnRemove.Visibility = Visibility.Collapsed;
                }
                
                previewDesigner.BeforeRunningPreviewPanel = Visibility.Visible;
            }
            Controller.ResetSelection(lstQueries.SelectedItem as DependencyObject);
        }

        private void groupCheckedChanged(object sender, RoutedEventArgs e)
        {
            if (m_collectionView != null)
            {
                if (btnGroupQueries.IsChecked.HasValue && btnGroupQueries.IsChecked.Value)
                    m_collectionView.GroupDescriptions.Add(m_groupDescription);
                else
                    m_collectionView.GroupDescriptions.Clear();
            }
        }

        private void addNewQuery_Click(object sender, RoutedEventArgs e)
        {
            var newQuery = Controller.AddNewQuery();
            Controller.Selection = new QueryTypeDescriptor(newQuery as DependencyObject, Controller.QueryBag, null);
            EditQuery(newQuery, true);
        }

        public static readonly RoutedEvent VLinqBeginDragDropEvent = EventManager.RegisterRoutedEvent("VLinqBeginDragDrop", RoutingStrategy.Bubble, typeof(VLinqBeginDragDropEventHandler), typeof(QueryBagDesigner));
        public static readonly RoutedEvent VLinqEndDragDropEvent = EventManager.RegisterRoutedEvent("VLinqEndDragDrop", RoutingStrategy.Bubble, typeof(RoutedEventHandler), typeof(QueryBagDesigner));

        private void back_Clicked(object sender, RoutedEventArgs e)
        {
            lstQueries.SelectedIndex = -1;
        }

        private void btnRemove_Click(object sender, RoutedEventArgs e)
        {
            if (lstQueries.SelectedItem is Query)
                if (MessageBox.Show(Messages.ConfirmDeleteQuery, Messages.ConfirmDeleteQueryCaption, MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                    Controller.DeleteQuery.Execute(lstQueries.SelectedItem);
        }

        public byte[] PreviewIcon
        {
            get { return Properties.Resources.Preview; }
        }

        public byte[] PreviewAllIcon
        {
            get { return Properties.Resources.PreviewAll; }
        }

        public byte[] NewIcon
        {
            get { return Properties.Resources.New; }
        }
        
        public byte[] GroupQueriesIcon
        {
            get { return Properties.Resources.GroupQueries; }
        }
        
        public byte[] DeleteIcon
        {
            get { return Properties.Resources.Delete; }
        }
        
        public byte[] OpenIcon
        {
            get { return Properties.Resources.Open; }
        }

        private void CheckAll_Click(object sender, RoutedEventArgs e)
        {
            foreach (var query in Controller.Queries)
                (query as DependencyObject).SetValue(PreviewConfigController.IncludeInPreviewBatchProperty, true);
        }

        private void UnCheckAll_Click(object sender, RoutedEventArgs e)
        {
            foreach (var query in Controller.Queries)
                (query as DependencyObject).SetValue(PreviewConfigController.IncludeInPreviewBatchProperty, false);
        }

        private void previewState_Click(object sender, MouseButtonEventArgs e)
        {
            var asFe = sender as FrameworkElement;
            if (asFe != null)
            {
                var query = asFe.DataContext as DependencyObject;
                if (query != null && PreviewerController.GetPreviewState(query) == QueryPreviewState.Failed)
                    TextDialog.ShowDialog(PreviewerController.GetQueryResult(query).ToString());
            }
        }

        private double savePreviewHeight = 150;
        private NonUIElementProxy<double> _previewRowHeightProxy = null;
        public NonUIElementProxy<double> PreviewRowHeightProxy
        {
            get
            {
                if (_previewRowHeightProxy == null)
                    _previewRowHeightProxy = new NonUIElementProxy<double>(value => previewRow.Height = new GridLength(value));
                return _previewRowHeightProxy;
            }
        }

        private void PreviewChecked(object sender, RoutedEventArgs e)
        {
            RefreshPreviewButtonState();
            var anim =
                WPFHelpers.CreateDeceleratingDoubleAnimation(
                    previewRow.Height.Value, savePreviewHeight,
                    Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

            anim.Completed += delegate { previewRow.Height = new GridLength(savePreviewHeight); };

            PreviewRowHeightProxy.BeginAnimation(NonUIElementProxy<double>.Property, anim);
        }

        private void PreviewUnchecked(object sender, RoutedEventArgs e)
        {
            RefreshPreviewButtonState();
            var anim =
                WPFHelpers.CreateDeceleratingDoubleAnimation(
                    previewRow.Height.Value, 0,
                    Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

            anim.Completed += delegate { previewRow.Height = new GridLength(0); };

            //if (!PreviewRowHeightProxy.HasAnimatedProperties)
                savePreviewHeight = previewRow.Height.Value;

            PreviewRowHeightProxy.BeginAnimation(NonUIElementProxy<double>.Property, anim);
        }

        private void RefreshPreviewButtonState()
        {
            btnPreview.Visibility =
                (tbPreview.IsChecked.Value) && (lstQueries.SelectedIndex >= 0) ? Visibility.Visible : Visibility.Collapsed;
            toolbarPreview.Visibility =
                lstQueries.SelectedIndex >= 0 ? Visibility.Visible : Visibility.Collapsed;
        }
        
        private double saveTestingColumnWidth = 100;
        private NonUIElementProxy<double> _testingColumnWidthProxy = null;
        public NonUIElementProxy<double> TestingColumnWidthProxy
        {
            get
            {
                if (_testingColumnWidthProxy == null)
                    _testingColumnWidthProxy = new NonUIElementProxy<double>(value => testingColumn.Width = value);
                return _testingColumnWidthProxy;
            }
        }

        private void TestingChecked(object sender, RoutedEventArgs e)
        {
            var anim =
                WPFHelpers.CreateDeceleratingDoubleAnimation(
                    testingColumn.Width, saveTestingColumnWidth,
                    Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

            anim.Completed += delegate { testingColumn.Width = saveTestingColumnWidth; };

            TestingColumnWidthProxy.BeginAnimation(NonUIElementProxy<double>.Property, anim);
        }

        private void TestingUnchecked(object sender, RoutedEventArgs e)
        {
            var anim =
                WPFHelpers.CreateDeceleratingDoubleAnimation(
                    testingColumn.Width, 0,
                    Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

            anim.Completed += delegate { testingColumn.Width = 0; };

            //if (!TestingColumnWidthProxy.HasAnimatedProperties)
                saveTestingColumnWidth = testingColumn.Width;

            TestingColumnWidthProxy.BeginAnimation(NonUIElementProxy<double>.Property, anim);
        }
    }

    public delegate void VLinqBeginDragDropEventHandler(object sender, VLinqBeginDragDropEventArgs args);
    
    public class VLinqBeginDragDropEventArgs : RoutedEventArgs
    {
        public string Data { get; set; }
    }
}
