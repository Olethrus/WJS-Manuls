﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Markup;
using System.IO;
using VLinq.Processing;
using VLinq.WPFControls;
using EnvDTE;
using System.ComponentModel.Design;
using VLinq.Editor.Preview;
using System.Globalization;
using Microsoft.VisualStudio.Shell.Interop;
using VLinq.VSIntegration;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell;
using System.Collections.ObjectModel;
using System.ComponentModel;

namespace VLinq.Editor
{
    /// <summary>
    /// Controller for the whole query bag
    /// </summary>
    public class QueryBagDesignerController : DependencyObject
    {
        /// <summary>
        /// Dependency property used to attach a QueryController to a Query
        /// </summary>
        public static readonly DependencyProperty AttachedQueryControllerProperty = DependencyProperty.Register("AttachedQueryController", typeof(QueryDesignerController), typeof(QueryBagDesignerController));

        private TypeDescriptionBuilder m_TypeDescriptionBuilder;
        /// <summary>
        /// Type description builder used for the whole QueryBag (common TypeDescription cache / repository for all queries for better performances)
        /// </summary>
        public TypeDescriptionBuilder TypeDescriptionBuilder
        {
            get { return m_TypeDescriptionBuilder; }
            set { m_TypeDescriptionBuilder = value; }
        }

        #region QueryBag state
        
        /// <summary>
        /// used to handle changes from the whole QUeryBag tree
        /// </summary>
        private EventHandler<NotifyChangedEventArgs> m_queryBagChangedHandler;
        /// <summary>
        /// used to handle adding / removing of queries
        /// </summary>
        private System.Collections.Specialized.NotifyCollectionChangedEventHandler m_queryCollectionChangedHandler;





        public ObservableCollection<INamed> Queries
        {
            get { return (ObservableCollection<INamed>)GetValue(QueriesProperty); }
            private set { SetValue(QueriesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Queries.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueriesProperty =
            DependencyProperty.Register("Queries", typeof(ObservableCollection<INamed>), typeof(QueryBagDesignerController), new UIPropertyMetadata(null));





        public bool IsDirty
        {
            get { return (bool)GetValue(IsDirtyProperty); }
            set { SetValue(IsDirtyProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsDirty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsDirtyProperty =
            DependencyProperty.Register("IsDirty", typeof(bool), typeof(QueryBagDesignerController), new UIPropertyMetadata(false, OnIsDirtyChanged));

        private static void OnIsDirtyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            QueryBagDesignerController elem = obj as QueryBagDesignerController;
            if (elem != null)
            {
                elem.OnIsDirtyChanged(args.OldValue == null ? default(bool) : (bool)args.OldValue, args.NewValue == null ? default(bool) : (bool)args.NewValue);
            }
        }
        protected virtual void OnIsDirtyChanged(bool oldValue, bool newValue)
        {
            if (IsDirtyChanged != null)
                IsDirtyChanged(oldValue, newValue);
        }

        public event Action<bool, bool> IsDirtyChanged;

        public QueryBagDesignerController()
        {
            CustomQueries = new CustomQueryCollection();
            
            Queries = new ObservableCollection<INamed>();

            CustomQueries.CollectionChanged += delegate(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
            {
                switch (e.Action)
                {
                    case System.Collections.Specialized.NotifyCollectionChangedAction.Add:
                        foreach (CustomQuery q in e.NewItems)
                        {
                            Queries.Add(q);
                        }
                        break;
                    case System.Collections.Specialized.NotifyCollectionChangedAction.Remove:
                        foreach (CustomQuery q in e.OldItems)
                        {
                            if(Queries.Contains(q))
                                Queries.Remove(q);
                        }
                        break;
                }
            };
            m_queryBagChangedHandler = delegate(object sender, NotifyChangedEventArgs args)
            {
                if (QueryBagChanged != null)
                    QueryBagChanged(this, EventArgs.Empty);
                
            };



            m_queryCollectionChangedHandler = delegate(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
            {
                switch (e.Action)
                {
                    case System.Collections.Specialized.NotifyCollectionChangedAction.Add:
                        foreach (Query q in e.NewItems)
                        {
                            q.SetValue(AttachedQueryControllerProperty,
                                new QueryDesignerController(q, this, new QueryValidator(q, this.TypeDescriptionBuilder, QueryValidatorOptions.VerifyCSIdentifiers))
                                );
                            Queries.Add(q);
                        }
                        break;
                    case System.Collections.Specialized.NotifyCollectionChangedAction.Remove:
                        foreach (Query q in e.OldItems)
                        {
                            q.ClearValue(AttachedQueryControllerProperty);
                            if (Queries.Contains(q))
                                Queries.Remove(q);
                        }
                        break;
                }
            };

            if (System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))
            {
                this.QueryBag = XamlReader.Load(new MemoryStream(Properties.Resources.SampleQueries)) as QueryBag;
                CustomQueries.Add(new CustomQuery { Name = "GetSimpleText", MethodInfo = typeof(FakeCustomQueries).GetMethod("GetSimpleText",new Type[]{typeof (System.Data.Linq.DataContext),typeof(string)}) });
            }

            #region Commands event handlers
            DeleteQuery.Executing += new EventHandler<ParameterizedCommandEventArgs<Query>>(DeleteQuery_Executing);
            NewQuery = new CustomCommand { IsEnabled = true };
            NewQuery.Executing += new EventHandler(NewQuery_Executing);
            #endregion
        }

        private class FakeCustomQueries
        {
            public static string GetSimpleText(System.Data.Linq.DataContext ctx, string val)
            {
                return val;
            }
        }

       
        /// <summary>
        /// QUeryBag associated with the controller
        /// </summary>
        public QueryBag QueryBag
        {
            get { return (QueryBag)GetValue(QueryBagProperty); }
            set { SetValue(QueryBagProperty, value); }
        }

        // Using a DependencyProperty as the backing store for QueryBag.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryBagProperty =
            DependencyProperty.Register("QueryBag", typeof(QueryBag), typeof(QueryBagDesignerController), new PropertyMetadata(new PropertyChangedCallback(OnQueryBagPropertyChanged)));
        /// <summary>
        /// When a QueryBag is associated, we detach event handler from the old QueryBag and attach them to the new one
        /// And do the same for the associated QueryControllers of each Query of the QueryBag
        /// </summary>
        /// <param name="obj"></param>
        /// <param name="args"></param>
        private static void OnQueryBagPropertyChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            QueryBagDesignerController ctrl = obj as QueryBagDesignerController;
            if (ctrl != null)
            {
                var oldBag = args.OldValue as QueryBag;
                var newBag = args.NewValue as QueryBag;
                if (oldBag != null)
                {
                    oldBag.Changed -= ctrl.m_queryBagChangedHandler;
                    if (oldBag.Queries != null)
                    {
                        foreach (Query q in oldBag.Queries)
                            q.ClearValue(AttachedQueryControllerProperty);
                        oldBag.Queries.CollectionChanged -= ctrl.m_queryCollectionChangedHandler;
                    }
                }
                if (newBag != null)
                {
                    newBag.Changed += ctrl.m_queryBagChangedHandler;
                    if (newBag.Queries != null)
                    {
                        foreach (Query q in newBag.Queries)
                            q.SetValue(AttachedQueryControllerProperty,
                                new QueryDesignerController(q, ctrl, new QueryValidator(q, ctrl.TypeDescriptionBuilder, QueryValidatorOptions.VerifyCSIdentifiers))
                                );

                        newBag.Queries.CollectionChanged += ctrl.m_queryCollectionChangedHandler;
                    }
                }
                
                ctrl.Selection = new QueryBagTypeDescriptor( ctrl.QueryBag);
                ctrl.RefreshCustomQueries();

                ctrl.Queries.Clear();
                foreach (var q in ctrl.QueryBag.Queries.Cast<INamed>().Concat(ctrl.CustomQueries.Cast<INamed>()))
                {
                    ctrl.Queries.Add(q);
                }
                if (ctrl.QueryBagSet != null)
                    ctrl.QueryBagSet(ctrl, EventArgs.Empty);
            }
        }



        public event EventHandler QueryBagSet;
        public event EventHandler QueryBagChanged;
        #endregion

        #region Custom commands
        /// <summary>
        /// Create a new Query
        /// </summary>
        public CustomCommand NewQuery { get; private set; }
        private CustomParameterizedCommand<Query> m_deleteQuery = new CustomParameterizedCommand<Query> { IsEnabled = true };
        /// <summary>
        /// Delete a query
        /// </summary>
        public CustomParameterizedCommand<Query> DeleteQuery
        {
            get { return m_deleteQuery; }
        }
        void DeleteQuery_Executing(object sender, ParameterizedCommandEventArgs<Query> e)
        {
            QueryBag.Queries.Remove(e.Parameter);
        }
        void NewQuery_Executing(object sender, EventArgs e)
        {
            AddNewQuery();
        }

        public Query AddNewQuery()
        {
            var unallowedNames = from q in this.QueryBag.Queries
                                 select q.Name;
            string baseName = "NewQuery";
            string name = baseName;
            int counter = 0;
            while (unallowedNames.Contains(name))
                name = baseName + (++counter).ToString();
            var newQ = new Query { Name = name };
            QueryBag.Queries.Add(newQ);
            return newQ;
        }
        #endregion

        public void Save()
        {
            if (SaveRequested != null)
                SaveRequested(this, EventArgs.Empty);
        }
        public event EventHandler SaveRequested;


        public object Selection
        {
            get { return (object)GetValue(SelectionProperty); }
            set { SetValue(SelectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Selection.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SelectionProperty =
            DependencyProperty.Register("Selection", typeof(object), typeof(QueryBagDesignerController), new UIPropertyMetadata(null, OnSelectionChanged));

        private static void OnSelectionChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            QueryBagDesignerController elem = obj as QueryBagDesignerController;
            if (elem != null)
            {
                elem.OnSelectionChanged(args.OldValue == null ? default(object) : (object)args.OldValue, args.NewValue == null ? default(object) : (object)args.NewValue);
            }
        }
        protected virtual void OnSelectionChanged(object oldValue, object newValue)
        {
            if (SelectionChanged != null)
                SelectionChanged(this, EventArgs.Empty);
        }

        public event EventHandler SelectionChanged;



        public CustomQueryCollection CustomQueries
        {
            get { return (CustomQueryCollection)GetValue(CustomQueriesProperty); }
            private set { SetValue(CustomQueriesProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CustomQueries.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CustomQueriesProperty =
            DependencyProperty.Register("CustomQueries", typeof(CustomQueryCollection), typeof(QueryBagDesignerController), new UIPropertyMetadata(null));


        private Project m_project;
        private string m_itemPath;
        private DTE m_dte;
        private ITypeResolutionService m_resolutionService;
        private BuildEvents m_buildEvents;


        public void SetDTEInfos(DTE dte, Project project,string itemPath, ITypeResolutionService typeResolutionService)
        {
            m_dte = dte;
            m_project = project;
            m_resolutionService = typeResolutionService;
            m_itemPath = itemPath;
            m_buildEvents = m_dte.Events.BuildEvents;
            m_buildEvents.OnBuildDone += BuildEvents_OnBuildDone;
            RefreshCustomQueries();
        }

        void BuildEvents_OnBuildDone(vsBuildScope Scope, vsBuildAction Action)
        {
            if (Action == vsBuildAction.vsBuildActionBuild || Action == vsBuildAction.vsBuildActionRebuildAll)
            {
                RefreshCustomQueries();
                var oldSelection = Selection;
                var asQuerySelection = oldSelection as QueryTypeDescriptor;
                if (asQuerySelection != null)
                    ResetSelection(asQuerySelection.Query);
                else ResetSelection(null);

                foreach (var q in Queries.OfType<Query>())
                {
                    var ctrl = q.GetValue(AttachedQueryControllerProperty) as QueryDesignerController;
                    if (ctrl != null)
                    {
                        ctrl.Validator.ResetCache();
                        ctrl.Validator.Validate();
                    }
                }
            }
        }
        public void ResetSelection(DependencyObject query)
        {
            if (query == null)
                Selection = new QueryBagTypeDescriptor(QueryBag);
            else
            {
                bool isVLinqQuery = query is Query;
                PreviewInfoItem infoItem = null;
                if (isVLinqQuery)
                {
                    
                    try
                    {
                        infoItem = GetVLinqQueryPreviewInfo(query as Query);
                    }
                    catch { }
                }
                else
                {
                    
                    try
                    {
                        infoItem = GetCustomQueryPreviewInfo(query as CustomQuery);
                    }
                    catch { }
                }
                if (infoItem == null)
                    Selection = new QueryTypeDescriptor(query, QueryBag, null);
                else
                    Selection = new QueryTypeDescriptor(query, QueryBag, infoItem.MethodParametersInfo);
            }
        }
        private ProjectItem GetProjectItemFromPath(string path)
        {
            try
            {
                foreach (var pi in m_project.ProjectItems.Cast<ProjectItem>())
                {
                    if (pi.get_FileNames(1) == path)
                        return pi;
                }
            }
            catch { }
            return null;
        }
        private string GetItemNamespace()
        {
            var itemNamespace = "";
            foreach (Property prop in m_project.Properties)
            {
                if (prop.Name == "RootNamespace")
                {
                    itemNamespace = prop.Value.ToString();
                    break;
                }
            }
            if (m_project.CodeModel.Language == CodeModelLanguageConstants.vsCMLanguageCSharp)
            {
                var projectFolder = Path.GetDirectoryName(m_project.FileName);
                var itemFolder = Path.GetDirectoryName(m_itemPath);
                if (projectFolder != itemFolder)
                {
                    itemFolder = itemFolder.Remove(0, projectFolder.Length);
                    if (!itemFolder.StartsWith("\\"))
                        itemFolder = itemFolder.Insert(0, "\\");
                    if (itemFolder.EndsWith("\\"))
                        itemFolder = itemFolder.Remove(itemFolder.Length - 1);
                    itemNamespace += itemFolder.Replace('\\', '.');
                }
            }
            var projectItem = GetProjectItemFromPath(m_itemPath);
            if (projectItem != null)
            {
                foreach (Property prop in projectItem.Properties)
                {
                    if (prop.Name == "CustomToolNamespace")
                    {
                        var val = prop.Value as string;
                        if (!String.IsNullOrEmpty(val))
                            itemNamespace = val;
                        break;
                    }
                }
            }
            return itemNamespace;
        }

        private void RefreshCustomQueries()
        {
            if (m_project != null  && m_resolutionService != null && m_dte != null)
            {
                foreach (var cq in CustomQueries)
                {
                    if (Queries.Contains(cq))
                        Queries.Remove(cq);
                }
                CustomQueries.Clear();
                var ns = GetItemNamespace();
                Type qbagType = null;
                if (QueryBag != null)
                {
                    qbagType = GetQuerybagGeneratedType(ns);
                    if (qbagType != null)
                    {
                        var potentialQueries = qbagType.GetMethods(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.Static);
                        var toSkip = (from method in potentialQueries
                                      from query in QueryBag.Queries
                                      where method.Name == query.Name
                                      || method.GetParameters().Length == 0 || method.GetParameters()[0].ParameterType != typeof(System.Data.Linq.DataContext)
                                      || method.GetCustomAttributes(typeof(BrowsableAttribute), false).Length == 0
                                      || !(method.GetCustomAttributes(typeof(BrowsableAttribute), false)[0] as BrowsableAttribute).Browsable
                                      select method).Distinct();
                        var customQueries = potentialQueries.Except(toSkip);

                        foreach (var method in customQueries)
                        {
                            this.CustomQueries.Add(new CustomQuery { Name = method.Name, MethodInfo = method });
                        }
                    }
                }
            }
        }

        private Type GetQuerybagGeneratedType(string ns)
        {
            Type qbagType = null;
            if (string.IsNullOrEmpty(ns))
            {
                qbagType = m_resolutionService.GetType(QueryBag.ClassName, false);
            }
            else
            {
                qbagType = m_resolutionService.GetType(string.Format(CultureInfo.InvariantCulture, "{0}.{1}", ns, QueryBag.ClassName), false);
            }
            return qbagType;
        }


        public bool IsProjectDirty
        {
            get
            {
                return !ProjectUptoDate(m_project);
            }
        }

        //TODO: Correct it... maybe orcas Beta 2 / SDK bug 
        private bool ProjectUptoDate(Project project)
        {
            IVsBuildableProjectCfg cfg1;
            IVsHierarchy hierarchy1 = VSHelpers.ToHierarchy(project);
            IVsProjectCfg2[] cfgArray1 = new IVsProjectCfg2[1];

            var svcProvider = new ServiceProvider(m_dte as Microsoft.VisualStudio.OLE.Interop.IServiceProvider);
            IVsSolutionBuildManager m_currBuildManager = svcProvider.GetService(typeof(IVsSolutionBuildManager)) as IVsSolutionBuildManager;

            m_currBuildManager.FindActiveProjectCfg(IntPtr.Zero, IntPtr.Zero, hierarchy1, cfgArray1);
            if (cfgArray1[0] == null)
            {
                return false;
            }
            cfgArray1[0].get_BuildableProjectCfg(out cfg1);
            if (cfg1 == null)
            {
                return false;
            }
            int[] numArray1 = new int[1];
            int[] numArray2 = new int[1];
            int num1 = cfg1.QueryStartUpToDateCheck(1, numArray1, numArray2);
            if ((numArray1[0] != 0) && !ErrorHandler.Failed(num1))
            {
                //http://msdn2.microsoft.com/en-us/library/microsoft.visualstudio.shell.interop.ivsbuildableprojectcfg.startuptodatecheck(VS.80).aspx
                num1 = cfg1.StartUpToDateCheck(null, 1);
                if (ErrorHandler.Failed(num1))
                {
                    return false;
                }
            }
            return true;
        }


        public PreviewInfoItem GetCustomQueryPreviewInfo(CustomQuery query)
        {
            return PreviewInfoBuilder.BuildPreviewInfoFromCustomQuery(query, QueryBag);            
        }

        public PreviewInfoItem GetVLinqQueryPreviewInfo(Query query)
        {
            return PreviewInfoBuilder.BuildPreviewInfoFromQuery(query, QueryBag, GetQuerybagGeneratedType(GetItemNamespace()), m_resolutionService);
        }

        public IEnumerable<PreviewInfoItem> GetAllPreviewInfos()
        {
            var queryBagGeneratedType = GetQuerybagGeneratedType(GetItemNamespace());
            var result = (from query in QueryBag.Queries
                          where ValidTimeProperties.GetIsValid(query) && PreviewConfigController.GetIncludeInPreviewBatch(query)
                          select PreviewInfoBuilder.BuildPreviewInfoFromQuery(query, QueryBag, queryBagGeneratedType, m_resolutionService)).Union(
                          from query in CustomQueries
                          where PreviewConfigController.GetIncludeInPreviewBatch(query)
                          select PreviewInfoBuilder.BuildPreviewInfoFromCustomQuery(query, QueryBag));
            return result;
        }
    }
}
