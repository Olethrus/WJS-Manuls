﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;
using VLinq.WPFControls;
using VLinq.Editor.Preview;
using System.Threading;
using System.Windows.Media.Animation;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for QueryDesigner.xaml
    /// </summary>
    public partial class QueryDesigner : System.Windows.Controls.UserControl
    {
        public QueryDesigner()
        {
            InitializeComponent();

            comboZoom.ItemsSource = new string[] { "25 %", "50 %", "75 %", "100 %", "200 %", "300 %", "400 %" };
        }

        public bool IsNewQuery { get; set; }

        private void btnClose_Click(object sender, System.Windows.RoutedEventArgs e)
        {
            if (Controller.ParentController.IsDirty)
            {
                var result = MessageBox.Show(Messages.DoYouWantToSaveQuery, "", MessageBoxButton.YesNoCancel, MessageBoxImage.Question);
                switch (result)
                {
                    case MessageBoxResult.Yes:
                        Controller.ParentController.Save();
                        break;
                    case MessageBoxResult.No:
                        Controller.RollbackToBackup = true;
                        break;
                    default:
                        return;
                }
            }
            if (CloseClicked != null)
                CloseClicked(this, EventArgs.Empty);
        }

        public event EventHandler CloseClicked;

        /// <summary>
        /// Controller of the designer
        /// when it is set, the child designers DataContexts are replaced by the proper sub-controllers
        /// </summary>
        public QueryDesignerController Controller
        {
            get { return (QueryDesignerController)GetValue(ControllerProperty); }
            set { SetValue(ControllerProperty, value); }
        }

        public void EditSubQuery(ChildQueryResultSource cqrs)
        {
            //cqrs.Query.Name = cqrs.Name;
            //var queryDesigner = new SubQueryDesigner();
            //queryDesigner.DataContext = queryDesigner.Controller = Controller.CreateSubQueryController(cqrs);
            //ChildQueryContainer.Child = queryDesigner;
            //queryDesigner.StepContainer.Zoom = StepContainer.Zoom;
            //var currentViewAnim = new DoubleAnimation(0, -ActualWidth, new Duration(TimeSpan.FromSeconds(1)), FillBehavior.Stop);
            //var newViewAnim = new DoubleAnimation(ActualWidth, 0, new Duration(TimeSpan.FromSeconds(1)), FillBehavior.Stop);

            //currentViewAnim.AccelerationRatio = 0.5;
            //currentViewAnim.DecelerationRatio = 0.5;
            //newViewAnim.AccelerationRatio = 0.5;
            //newViewAnim.DecelerationRatio = 0.5;
            //CurrentView.RenderTransform.BeginAnimation(TranslateTransform.XProperty, currentViewAnim);
            //ChildQueryContainer.RenderTransform.BeginAnimation(TranslateTransform.XProperty, newViewAnim);
            //Controller.ParentController.Selection = new QueryTypeDescriptor(cqrs.Query);
            //queryDesigner.CloseClicked += delegate
            //{
            //    var currentViewBackAnim = new DoubleAnimation(-ActualWidth, 0, new Duration(TimeSpan.FromSeconds(1)), FillBehavior.Stop);
            //    var newViewBackAnim = new DoubleAnimation(0, ActualWidth, new Duration(TimeSpan.FromSeconds(1)), FillBehavior.Stop);

            //    currentViewBackAnim.AccelerationRatio = 0.5;
            //    currentViewBackAnim.DecelerationRatio = 0.5;
            //    newViewBackAnim.AccelerationRatio = 0.5;
            //    newViewBackAnim.DecelerationRatio = 0.5;
            //    newViewBackAnim.Completed += delegate
            //    {
            //        ChildQueryContainer.Child = null;
            //    };
            //    StepContainer.Zoom = queryDesigner.StepContainer.Zoom;
            //    CurrentView.RenderTransform.BeginAnimation(TranslateTransform.XProperty, currentViewBackAnim);
            //    ChildQueryContainer.RenderTransform.BeginAnimation(TranslateTransform.XProperty, newViewBackAnim);
            //    Controller.ParentController.Selection = new QueryTypeDescriptor(Controller.Query);

            //};

        }

        // Using a DependencyProperty as the backing store for Controller.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ControllerProperty =
            DependencyProperty.Register("Controller", typeof(QueryDesignerController), typeof(QueryDesigner), new PropertyMetadata(new PropertyChangedCallback(
                delegate(DependencyObject obj, DependencyPropertyChangedEventArgs args)
                {
                    var designer = obj as QueryDesigner;
                    if (args.NewValue != null)
                    {
                        designer.dataSourcesDesigner.DataContext = (args.NewValue as QueryDesignerController).EntitySourceController;
                        designer.parameterSourceDesigner.DataContext = (args.NewValue as QueryDesignerController).ParameterSourceController;
                        designer.childQueriesDesigner.DataContext = (args.NewValue as QueryDesignerController).SubQueriesController;
                        designer.projectionDesigner.DataContext = (args.NewValue as QueryDesignerController).ProjectionController;
                        designer.orderByDesigner.DataContext = (args.NewValue as QueryDesignerController).Query;
                        designer.whereDesigner.Controller.Query = (args.NewValue as QueryDesignerController).Query;
                        designer.groupByDesigner.DataContext = (args.NewValue as QueryDesignerController).GroupByController;
                        designer.havingDesigner.Controller.Query = (args.NewValue as QueryDesignerController).Query;
                        designer.dsSummary.Controller.Query = (args.NewValue as QueryDesignerController).Query;
                        designer.OnControllerChanged(args.OldValue as QueryDesignerController, args.NewValue as QueryDesignerController);
                        designer.aeFrom_Collapsed(null, null);
                        designer.aeGroupBy_Collapsed(null, null);
                        designer.aeHaving_Collapsed(null, null);
                        designer.aeOrderBy_Collapsed(null, null);
                        designer.aeQueryParameters_Collapsed(null, null);
                        designer.aeSelect_Collapsed(null, null);
                        designer.aeSubQueries_Collapsed(null, null);
                        designer.aeWhere_Collapsed(null, null);
                    }
                    else
                    {
                        designer.dsSummary.Controller.Query = null;
                        designer.dataSourcesDesigner.DataContext = null;
                        designer.parameterSourceDesigner.DataContext = null;
                        designer.childQueriesDesigner.DataContext = null;
                        designer.projectionDesigner.DataContext = null;
                        designer.orderByDesigner.DataContext = null;
                        designer.whereDesigner.Controller.Query = null;
                        designer.groupByDesigner.DataContext = null;
                        designer.havingDesigner.Controller.Query = null;
                    }
                })));


        protected virtual void OnControllerChanged(QueryDesignerController oldValue, QueryDesignerController newValue)
        {
            if (newValue != null)
            {
                validVisibilityController.Visibility = Controller.IsQueryValid ? Visibility.Collapsed : Visibility.Visible;
                newValue.IsQueryValidChanged += new EventHandler(newValue_IsQueryValidChanged);
                newValue.Query.Changed += new EventHandler<NotifyChangedEventArgs>(Query_Changed);
            }
        }

        void Query_Changed(object sender, NotifyChangedEventArgs e)
        {
            var topOfChangeStack = e.ChangedStack.Peek();

            UpdateExpandersVisibility();
            if (topOfChangeStack.ChangedProperty == Query.DataSourcesProperty)
            {
                if (!aeFrom.IsExpanded)
                    aeFrom_Collapsed(null, null);
                if (!aeQueryParameters.IsExpanded)
                    aeQueryParameters_Collapsed(null, null);
                if (!aeSubQueries.IsExpanded)
                    aeSubQueries_Collapsed(null, null);
            }
            else if (topOfChangeStack.ChangedProperty == Query.GroupByProperty && !aeGroupBy.IsExpanded)
                aeGroupBy_Collapsed(null, null);
            else if (topOfChangeStack.ChangedProperty == Query.HavingProperty && !aeHaving.IsExpanded)
                aeHaving_Collapsed(null, null);
            else if (topOfChangeStack.ChangedProperty == Query.JoinsProperty && !aeFrom.IsExpanded)
                aeFrom_Collapsed(null, null);
            else if (topOfChangeStack.ChangedProperty == Query.OrderByProperty && !aeOrderBy.IsExpanded)
                aeOrderBy_Collapsed(null, null);
            else if (topOfChangeStack.ChangedProperty == Query.SelectProperty && !aeSelect.IsExpanded)
                aeSelect_Collapsed(null, null);
            else if (topOfChangeStack.ChangedProperty == Query.WhereProperty && !aeWhere.IsExpanded)
                aeWhere_Collapsed(null, null);
        }

        void newValue_IsQueryValidChanged(object sender, EventArgs e)
        {
            if (Controller.IsQueryValid && validVisibilityController.IsChecked.HasValue && validVisibilityController.IsChecked.Value)
                validVisibilityController.IsChecked = false;
            validVisibilityController.Visibility = Controller.IsQueryValid ? Visibility.Collapsed : Visibility.Visible;
        }

        private void expandAll_Click(object sender, RoutedEventArgs e)
        {
            foreach (AnimatedExpander elem in StepContainer.Items)
                elem.IsExpanded = true;
        }

        private void collapseAll_Click(object sender, RoutedEventArgs e)
        {
            foreach (AnimatedExpander elem in StepContainer.Items)
                elem.IsExpanded = false;
        }

        private void showAll_Click(object sender, RoutedEventArgs e)
        {
            UpdateExpandersVisibility();
        }

        private void UpdateExpandersVisibility()
        {
            if (Controller.Query.OrderBy.Count > 0)
            {
                titleOrderBy.Foreground = Brushes.Blue;
                aeOrderBy.Visibility = Visibility.Visible;
            }
            else
            {
                titleOrderBy.Foreground = SystemColors.GrayTextBrush;
                aeOrderBy.Visibility = showAll.IsChecked.Value ? Visibility.Visible : Visibility.Collapsed;
            }

            if (Controller.Query.GroupBy != null)
            {
                titleGroupBy.Foreground = Brushes.Blue;
                aeGroupBy.Visibility = Visibility.Visible;
            }
            else
            {
                titleGroupBy.Foreground = SystemColors.GrayTextBrush;
                aeGroupBy.Visibility = showAll.IsChecked.Value ? Visibility.Visible : Visibility.Collapsed;
            }
            
            if (!IsEmpty(Controller.Query.Having))
            {
                titleHaving.Foreground = Brushes.Blue;
                aeHaving.Visibility = Visibility.Visible;
            }
            else
            {
                titleHaving.Foreground = SystemColors.GrayTextBrush;
                aeHaving.Visibility = showAll.IsChecked.Value ? Visibility.Visible : Visibility.Collapsed;
            }
            
            if (Controller.Query.DataSources.OfType<ChildQueryResultSource>().Count() > 0)
            {
                titleSubQueries.Foreground = Brushes.Blue;
                aeSubQueries.Visibility = Visibility.Visible;
            }
            else
            {
                titleSubQueries.Foreground = SystemColors.GrayTextBrush;
                aeSubQueries.Visibility = showAll.IsChecked.Value ? Visibility.Visible : Visibility.Collapsed;
            }
            
            if (Controller.Query.DataSources.OfType<ParameterSource>().Count() > 0)
                titleQueryParameters.Foreground = Brushes.Blue;
            else
                titleQueryParameters.Foreground = SystemColors.GrayTextBrush;
        }

        private bool IsEmpty(Constraint constraint)
        {
            if (constraint == null)
                return true;
            var logical = constraint as LogicalOperatorConstraint;
            return (logical != null) && (logical.IsEmpty);
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
            UpdateExpandersVisibility();
        }

        private void aeFrom_Expanded(object sender, RoutedEventArgs e)
        {
            txtFromDesc.Text = Messages.FromDragAndDropTip;
            txtFromDesc.Foreground = SystemColors.GrayTextBrush;
        }

        private Inline ToInline(TextFragment tf)
        {
            var run = new Run { Text = tf.Text, ToolTip = tf.ToolTip };
            switch (tf.FragmentKind)
            {
                case FragmentKind.DataType:
                    run.Foreground = new SolidColorBrush(Color.FromRgb(43, 145, 175));
                    break;
                case FragmentKind.Keyword:
                    run.Foreground = Brushes.Blue;
                    break;
                case FragmentKind.String:
                    run.Foreground = new SolidColorBrush(Color.FromRgb(163, 21, 21));
                    break;
            }
            return run;
        }
        
        private void aeFrom_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                var inlines = new List<Inline>();

                bool first = true;
                foreach (var ds in Controller.Query.DataSources)
                {
                    if ((ds is EntitySource) || (ds is ChildEntitySource))
                    {
                        if (first)
                            first = false;
                        else
                            inlines.Add(new LineBreak());
                        inlines.AddRange(ds.ToInlines().Select(frag => ToInline(frag)));
                    }
                }
                new Thread(delegate()
                    {
                        Thread.Sleep(300);
                        Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.DataBind, (ThreadStart)delegate()
                        {
                            try
                            {
                                txtFromDesc.Inlines.Clear();
                                txtFromDesc.ClearValue(TextBlock.ForegroundProperty);
                                txtFromDesc.Inlines.AddRange(inlines);
                            }
                            catch { }
                        });
                    }).Start();
            }
            catch { }
        }

        private void aeQueryParameters_Expanded(object sender, RoutedEventArgs e)
        {
            txtParamsDesc.Text = string.Empty;
        }

        private void aeQueryParameters_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                var inlines = new List<Inline>();

                inlines.Add(new Run(Controller.Query.Name + "("));
                inlines.Add(new Run("DataContext") { Foreground = new SolidColorBrush(Color.FromRgb(43, 145, 175)) });
                inlines.Add(new Run(" context"));
                foreach (var ds in Controller.Query.DataSources)
                {
                    if (ds is ParameterSource)
                    {
                        inlines.Add(new Run(", "));
                        inlines.AddRange(ds.ToInlines().Select(frag => ToInline(frag)));
                    }
                }
                inlines.Add(new Run(")"));
                new Thread(delegate()
                    {
                        Thread.Sleep(300);
                        Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.DataBind, (ThreadStart)delegate()
                        {
                            try
                            {
                                txtParamsDesc.Inlines.Clear();
                                txtParamsDesc.Inlines.AddRange(inlines);
                            }
                            catch { }
                        });
                    }).Start();
            }
            catch { }
        }

        private void aeSubQueries_Expanded(object sender, RoutedEventArgs e)
        {
            txtSubQueriesDesc.Text = string.Empty;
        }

        private void aeSubQueries_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                var inlines = new List<Inline>();

                bool first = true;
                foreach (var ds in Controller.Query.DataSources)
                {
                    if (ds is ChildQueryResultSource)
                    {
                        if (first)
                            first = false;
                        else
                            inlines.Add(new LineBreak());
                        inlines.AddRange(ds.ToInlines().Select(frag => ToInline(frag)));
                    }
                }
                new Thread(delegate()
                    {
                        Thread.Sleep(300);
                        Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.DataBind, (ThreadStart)delegate()
                        {
                            try
                            {
                                txtSubQueriesDesc.Inlines.Clear();
                                txtSubQueriesDesc.Inlines.AddRange(inlines);
                            }
                            catch { }
                        });
                    }).Start();
            }
            catch { }
        }

        private void aeOrderBy_Expanded(object sender, RoutedEventArgs e)
        {
            txtOrderByDescription.Text = Messages.OrderByDragAndDropTip;
            txtOrderByDescription.Foreground = SystemColors.GrayTextBrush;
        }

        private void aeOrderBy_Collapsed(object sender, RoutedEventArgs e)
        {
            txtOrderByDescription.ClearValue(TextBlock.ForegroundProperty);

            new Thread(delegate()
            {
                Thread.Sleep(300);
                Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.DataBind, (ThreadStart)delegate()
                {
                    try
                    {
                        txtOrderByDescription.Inlines.Clear();
                        txtOrderByDescription.Inlines.AddRange(Controller.Query.OrderBy.ToInlines().Select(frag => ToInline(frag)));
                    }
                    catch { }
                });
            }).Start();
        }

        private void aeWhere_Expanded(object sender, RoutedEventArgs e)
        {
            txtWhereDesc.Text = string.Empty;
        }

        private void aeWhere_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                new Thread(delegate()
                {
                    Thread.Sleep(300);
                    Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.DataBind, (ThreadStart)delegate()
                    {
                        try
                        {
                            txtWhereDesc.Inlines.Clear();
                            txtWhereDesc.Inlines.AddRange(Controller.Query.Where.ToInlines().Select(frag => ToInline(frag)));
                        }
                        catch { }
                    });
                }).Start();
            }
            catch { }
        }

        private void aeGroupBy_Expanded(object sender, RoutedEventArgs e)
        {
            txtGroupByDesc.Text = string.Empty;
        }

        private void aeGroupBy_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                new Thread(delegate()
                {
                    Thread.Sleep(300);
                    Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.DataBind, (ThreadStart)delegate()
                    {
                        try
                        {
                            txtGroupByDesc.Inlines.Clear();
                            if (Controller.Query.GroupBy != null)
                                txtGroupByDesc.Inlines.AddRange(Controller.Query.GroupBy.ToInlines().Select(frag => ToInline(frag)));
                        }
                        catch { }
                    });
                }).Start();
            }
            catch { }
        }

        private void aeHaving_Expanded(object sender, RoutedEventArgs e)
        {
            txtHavingDesc.Text = string.Empty;
        }

        private void aeHaving_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                new Thread(delegate()
                {
                    Thread.Sleep(300);
                    Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.DataBind, (ThreadStart)delegate()
                    {
                        try
                        {
                            txtHavingDesc.Inlines.Clear();
                            txtHavingDesc.Inlines.AddRange(Controller.Query.Having.ToInlines().Select(frag => ToInline(frag)));
                        }
                        catch { }
                    });
                }).Start();
            }
            catch { }
        }

        private void aeSelect_Expanded(object sender, RoutedEventArgs e)
        {
            txtSelectDesc.Text = string.Empty;
        }

        private void aeSelect_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                new Thread(delegate()
                {
                    Thread.Sleep(300);
                    Dispatcher.Invoke(System.Windows.Threading.DispatcherPriority.DataBind, (ThreadStart)delegate()
                    {
                        try
                        {
                            txtSelectDesc.Inlines.Clear();
                            txtSelectDesc.Inlines.AddRange(Controller.Query.Select.ToInlines().Select(frag => ToInline(frag)));
                        }
                        catch { }
                    });
                }).Start();
            }
            catch { }
        }

        public byte[] ShowAllIcon
        {
            get { return Properties.Resources.ShowAll; }
        }
        public byte[] ExpandAllIcon
        {
            get { return Properties.Resources.ExpandAll; }

        }
        public byte[] CollapseAllIcon
        {
            get { return Properties.Resources.CollapseAll; }
        }
        public byte[] PreviewIcon
        {
            get { return Properties.Resources.Preview; }
        }

        private void preview_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Controller.ParentController.IsProjectDirty)
                {
                    MessageBox.Show(Messages.ProjectMustBeCompiled, Messages.PreviewUnavailableCaption, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                if (!Controller.ParentController.QueryBag.TestConnectionString())
                {
                    MessageBox.Show(Messages.ConnectionStringNotSet, Messages.PreviewUnavailableCaption, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                var connectionError = Controller.ParentController.QueryBag.TestConnection();
                if (!string.IsNullOrEmpty(connectionError))
                {
                    MessageBox.Show(Messages.ConnectionFailed, Messages.PreviewUnavailableCaption, MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                var previewInfoSource = Controller.ParentController.GetVLinqQueryPreviewInfo(Controller.Query);

                var previewer = new PreviewerController();
                previewDesigner.DataContext = previewer;
                previewer.PreviewInfoItems = new Preview.PreviewInfoItem[] { previewInfoSource };

                previewDesigner.BeforeRunningPreviewPanel = Visibility.Hidden;
            }
            catch (Preview.VLinqQueryPreviewMethodResolverException vqpe)
            {
                MessageBox.Show(Messages.VLinqQueryNotCompiled.Replace("{QueryName}", vqpe.Query.Name), Messages.PreviewGenerationErrorCaption, MessageBoxButton.OK);
            }
        }
 
        private void clearParams(object sender, RoutedEventArgs e)
        {
            parameterSourceDesigner.Controller.Clear.Execute(null);
        }

        private void clearEntitySources(object sender, RoutedEventArgs e)
        {
            dataSourcesDesigner.Controller.Clear.Execute(null);
        }

        private void clearChildQueries(object sender, RoutedEventArgs e)
        {
            childQueriesDesigner.Controller.Clear.Execute(null);
        }

        private void clearOrderBy(object sender, RoutedEventArgs e)
        {
            orderByDesigner.Clear.Execute(null);
        }

        private void clearWhere(object sender, RoutedEventArgs e)
        {
            whereDesigner.Controller.Clear.Execute(null);
        }

        private void clearGroupBy(object sender, RoutedEventArgs e)
        {
            groupByDesigner.Controller.Clear.Execute(null);
        }

        private void clearHaving(object sender, RoutedEventArgs e)
        {
            havingDesigner.Controller.Clear.Execute(null);
        }

        private void clearProjection(object sender, RoutedEventArgs e)
        {
            projectionDesigner.Controller.Clear.Execute(null);
        }

        private double savePreviewHeight = 150;

        private NonUIElementProxy<double> _previewRowHeightProxy = null;
        public NonUIElementProxy<double> PreviewRowHeightProxy
        {
            get
            {
                if (_previewRowHeightProxy == null)
                    _previewRowHeightProxy = new NonUIElementProxy<double>(value => previewRow.Height = new GridLength(value));
                return _previewRowHeightProxy;
            }
        }

        private void PreviewChecked(object sender, RoutedEventArgs e)
        {
            var anim =
                WPFHelpers.CreateDeceleratingDoubleAnimation(
                    previewRow.Height.Value, savePreviewHeight,
                    Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

            anim.Completed += delegate { previewRow.Height = new GridLength(savePreviewHeight); };

            PreviewRowHeightProxy.BeginAnimation(NonUIElementProxy<double>.Property, anim);
        }

        private void PreviewUnchecked(object sender, RoutedEventArgs e)
        {
            var anim =
                WPFHelpers.CreateDeceleratingDoubleAnimation(
                    previewRow.Height.Value, 0,
                    Constants.SplineDeceleration, Constants.ShiftAnimationDuration);

            anim.Completed += delegate { previewRow.Height = new GridLength(0); };

            //if (!PreviewRowHeightProxy.HasAnimatedProperties)
                savePreviewHeight = previewRow.Height.Value;

            PreviewRowHeightProxy.BeginAnimation(NonUIElementProxy<double>.Property, anim);
        }
    }
}
