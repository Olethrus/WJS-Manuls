﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.Processing;

namespace VLinq.Editor
{
    /// <summary>
    /// Expose data sources to the QueryDesigner, and manage sub-controllers
    /// </summary>
    public class QueryDesignerController : DependencyObject
    {
        public Query Backup { get; set; }
        public bool RollbackToBackup { get; set; }
        private Query m_query;
        private QueryBagDesignerController m_parentController;
        public QueryBagDesignerController ParentController
        {
            get { return m_parentController; }
        }
        private QueryValidator m_validator;

        /// <summary>
        /// QueryValidator used for instant-validation of the query
        /// </summary>
        public QueryValidator Validator
        {
            get { return m_validator; }
        }
        /// <summary>
        /// Query to be edited
        /// </summary>
        public Query Query
        {
            get { return m_query; }
        }
        /// <summary>
        /// Handles validation, and creates sub-controllers
        /// </summary>
        /// <param name="query"></param>
        /// <param name="parentController"></param>
        /// <param name="validator"></param>
        public QueryDesignerController(Query query, QueryBagDesignerController parentController, QueryValidator validator)
        {
            m_query = query;
            m_parentController = parentController;
            if (!System.ComponentModel.DesignerProperties.GetIsInDesignMode(this))
            {
                m_validator = validator;
                m_query.Changed += new EventHandler<NotifyChangedEventArgs>(m_query_Changed);
                m_validator.Validate();
            }
            EntitySourceController = new DataSourceController(this);
            ParameterSourceController = new DataSourceController(this);
            ParameterSourceController.Mode = DataSourceControllerMode.Parameters;
            SubQueriesController = new DataSourceController(this);
            SubQueriesController.Mode = DataSourceControllerMode.ChildQueries;
            ProjectionController = new ProjectionController(this);
            GroupByController = new GroupByController(this);
            //ComparisonController = new ComparisonController(this);
            query.NamePathChanged += new EventHandler(query_NamePathChanged);
            SetNamePath();
            m_query.DependencyPropertyChanged += delegate(object sender, DependencyPropertyChangedEventArgs args)
            {
                if (args.Property == ValidTimeProperties.IsValidProperty)
                    IsQueryValid = (bool)args.NewValue;
            };
            IsQueryValid = ValidTimeProperties.GetIsValid(Query);
        }

        public bool IsQueryValid
        {
            get { return (bool)GetValue(IsQueryValidProperty); }
            set { SetValue(IsQueryValidProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsQueryValid.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsQueryValidProperty =
            DependencyProperty.Register("IsQueryValid", typeof(bool), typeof(QueryDesignerController), new UIPropertyMetadata(true, OnIsQueryValidChanged));

        private static void OnIsQueryValidChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            QueryDesignerController elem = obj as QueryDesignerController;
            if (elem != null)
            {
                elem.OnIsQueryValidChanged(args.OldValue == null ? default(bool) : (bool)args.OldValue, args.NewValue == null ? default(bool) : (bool)args.NewValue);
            }
        }
        protected virtual void OnIsQueryValidChanged(bool oldValue, bool newValue)
        {
            if (IsQueryValidChanged != null)
                IsQueryValidChanged(this, EventArgs.Empty);
        }

        public event EventHandler IsQueryValidChanged;


        void query_NamePathChanged(object sender, EventArgs e)
        {
            SetNamePath();
        }

        void SetNamePath()
        {
            Stack<string> namePath = new Stack<string>();
            namePath.Push(m_query.Name);
            var parent = m_query.ParentQuery;
            while (parent != null)
            {
                namePath.Push(parent.Name);
                parent = parent.ParentQuery;
            }
           QueryPath = namePath.ToArray();
        }



        public string[] QueryPath
        {
            get { return (string[])GetValue(QueryPathProperty); }
            set { SetValue(QueryPathProperty, value); }
        }

        // Using a DependencyProperty as the backing store for QueryPath.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty QueryPathProperty =
            DependencyProperty.Register("QueryPath", typeof(string[]), typeof(QueryDesignerController), new UIPropertyMetadata(null));


        


        /// <summary>
        /// Used for projection
        /// </summary>
        public ProjectionController ProjectionController
        {
            get { return (ProjectionController)GetValue(ProjectionControllerProperty); }
            set { SetValue(ProjectionControllerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ProjectionController.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ProjectionControllerProperty =
            DependencyProperty.Register("ProjectionController", typeof(ProjectionController), typeof(QueryDesignerController));



        /// <summary>
        /// used to generate "from" statements
        /// </summary>
        public DataSourceController EntitySourceController
        {
            get { return (DataSourceController)GetValue(EntitySourceControllerProperty); }
            set { SetValue(EntitySourceControllerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for DataSourceController.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty EntitySourceControllerProperty =
            DependencyProperty.Register("EntitySourceController", typeof(DataSourceController), typeof(QueryDesignerController));

        /// <summary>
        /// used to create query parameters
        /// </summary>
        public DataSourceController ParameterSourceController
        {
            get { return (DataSourceController)GetValue(ParameterSourceControllerProperty); }
            set { SetValue(ParameterSourceControllerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for OtherDataSourcesController.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ParameterSourceControllerProperty =
            DependencyProperty.Register("ParameterSourceController", typeof(DataSourceController), typeof(QueryDesignerController));



        public DataSourceController SubQueriesController
        {
            get { return (DataSourceController)GetValue(SubQueriesControllerProperty); }
            set { SetValue(SubQueriesControllerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SubQueriesController.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SubQueriesControllerProperty =
            DependencyProperty.Register("SubQueriesController", typeof(DataSourceController), typeof(QueryDesignerController));




        public GroupByController GroupByController
        {
            get { return (GroupByController)GetValue(GroupByControllerProperty); }
            set { SetValue(GroupByControllerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for GroupByController.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GroupByControllerProperty =
            DependencyProperty.Register("GroupByController", typeof(GroupByController), typeof(QueryDesignerController));


        /// <summary>
        /// to be removed (testing puropose only)
        /// </summary>
        //public ComparisonController ComparisonController
        //{
        //    get { return (ComparisonController)GetValue(ComparisonControllerProperty); }
        //    set { SetValue(ComparisonControllerProperty, value); }
        //}

        //// Using a DependencyProperty as the backing store for ConstraintController.  This enables animation, styling, binding, etc...
        //public static readonly DependencyProperty ComparisonControllerProperty =
        //    DependencyProperty.Register("ComparisonController", typeof(ComparisonController), typeof(QueryBagDesignerController));


        void m_query_Changed(object sender, NotifyChangedEventArgs e)
        {
            m_validator.Validate();
            
        }

        public QueryDesignerController CreateSubQueryController(ChildQueryResultSource cqrs)
        {
            return new QueryDesignerController(cqrs.Query, m_parentController, cqrs.GetValue(QueryValidator.AttachedValidatorProperty) as QueryValidator);
        }
    }
}
