﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Editor
{
    public static class QueryHelpers
    {
        public static bool IsSelectEmpty(this Query query)
        {
            if (query.Select == null)
                return true;
            var asDp = query.Select as DirectProjection;
            if (asDp != null)
            {
                if (asDp.Operand == null)
                    return true;
                var asDSO = asDp.Operand as DataSourceOperand;
                if (asDSO != null)
                {
                    if (string.IsNullOrEmpty(asDSO.DataSourceName)
                        && string.IsNullOrEmpty(asDSO.DataSourceProperty)
                        && asDSO.Transform == null)
                        return true;
                }
                else
                {
                    var asConstant = asDp.Operand as ConstantOperand;
                    if (asConstant != null)
                    {
                        if (asConstant.ConstantValue == null)
                            return true;
                        if (string.IsNullOrEmpty(asConstant.ConstantValue.ToString()))
                            return true;
                    }
                }
            }


            return false;
        }
    }
}
