﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using VLinq.Editor.Preview;
using System.Reflection;
using System.ComponentModel;

namespace VLinq.Editor
{
    public class QueryParametersPropertyDescriptorProvider
    {
        private DependencyObject m_query;
        ParameterInfo[] m_paramInfos;
        private object[] m_values;
        public QueryParametersPropertyDescriptorProvider(DependencyObject query, ParameterInfo[] paramInfos)
        {
           
            m_query = query;
            m_paramInfos = paramInfos;
            var currentValues = PreviewProperties.GetParametersValues(m_query);
            if (currentValues == null)
            {
                m_values = new object[m_paramInfos.Length];
            }
            else
            {
                if (currentValues.Length != m_paramInfos.Length)
                {
                    m_values = new object[m_paramInfos.Length];
                    if (currentValues.Length < m_paramInfos.Length)
                        Array.Copy(currentValues, m_values, currentValues.Length);
                    else
                        Array.Copy(currentValues, m_values, m_values.Length);
                }
                else
                    m_values = currentValues;
            }
            PropertyDescriptors = new List<PropertyDescriptor>();
            PreviewProperties.SetParametersValues(m_query, m_values);
            for (int i = 0; i < m_values.Length; i++)
            {
                if (m_values[i] == null)
                    m_values[i] = m_paramInfos[i].ParameterType.GetDefaultValue();
                PropertyDescriptors.Add(new IndexBasedPropertyDescriptor(this, i));
            }

            var asQuery = query as Query;
            if (asQuery != null)
            {
                if (asQuery.GeneratePaginatedVersion)
                {
                    PropertyDescriptors.Add(new AttachedPropertyDescriptor(PreviewConfigController.PreviewPaginatedVersionProperty,new Attribute[]{new DisplayNameAttribute("Preview paginated version"), new CategoryAttribute("Query preview parameters")}));
                    PropertyDescriptors.Add(new AttachedPropertyDescriptor(PreviewConfigController.FirstRowIndexProperty, new Attribute[] { new DisplayNameAttribute("Paginated version : first row"), new CategoryAttribute("Query preview parameters") }));
                    PropertyDescriptors.Add(new AttachedPropertyDescriptor(PreviewConfigController.PageSizeProperty, new Attribute[] { new DisplayNameAttribute("Paginated version : page size"), new CategoryAttribute("Query preview parameters") }));
                }
            }
            
        }

        public List<PropertyDescriptor> PropertyDescriptors { get; private set; }

        private class IndexBasedPropertyDescriptor : PropertyDescriptor
        {
            private QueryParametersPropertyDescriptorProvider m_provider;
            private int m_index;
            public IndexBasedPropertyDescriptor(QueryParametersPropertyDescriptorProvider provider, int index)
                : base(provider.m_paramInfos[index].Name,new Attribute[]{new CategoryAttribute("Query preview parameters")})
            {
                m_provider = provider;
                m_index = index;
            }

            public override bool CanResetValue(object component)
            {
                return false;
            }

            public override Type ComponentType
            {
                get { return typeof(DependencyObject); }
            }

            public override object GetValue(object component)
            {
                return m_provider.m_values[m_index];
            }

            public override bool IsReadOnly
            {
                get { return false; }
            }

            public override Type PropertyType
            {
                get { return m_provider.m_paramInfos[m_index].ParameterType; }
            }

            public override void ResetValue(object component)
            {
                
            }

            public override void SetValue(object component, object value)
            {
                m_provider.m_values[m_index] = value;
            }

            public override bool ShouldSerializeValue(object component)
            {
                return true;
            }
        }
    }
}
