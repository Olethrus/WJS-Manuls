﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Drawing.Design;
using System.Reflection;
using System.Windows;

namespace VLinq.Editor
{
    public class QueryBagTypeDescriptor : ICustomTypeDescriptor
    {
        private QueryBag m_queryBag;
        public QueryBagTypeDescriptor(QueryBag queryBag)
        {
            m_queryBag = queryBag;
        }

        public QueryBag QueryBag
        {
            get { return m_queryBag; }
        }

        #region ICustomTypeDescriptor Members

        public AttributeCollection GetAttributes()
        {
            return new AttributeCollection();
        }

        public string GetClassName()
        {
            return "Query Bag";
        }

        public string GetComponentName()
        {
            return m_queryBag.ClassName;
        }

        public TypeConverter GetConverter()
        {
            return TypeDescriptor.GetConverter(m_queryBag, true);
        }

        public EventDescriptor GetDefaultEvent()
        {
            return null;
        }

        public PropertyDescriptor GetDefaultProperty()
        {
            return TypeDescriptor.GetDefaultProperty(m_queryBag, true);
        }

        public object GetEditor(Type editorBaseType)
        {
            return TypeDescriptor.GetEditor(m_queryBag, editorBaseType, true);
        }

        public EventDescriptorCollection GetEvents(Attribute[] attributes)
        {
            return new EventDescriptorCollection(new EventDescriptor[] { });
        }

        public EventDescriptorCollection GetEvents()
        {
            return new EventDescriptorCollection(new EventDescriptor[] { });
        }

        public PropertyDescriptorCollection GetProperties(Attribute[] attributes)
        {
            var descrs = new List<PropertyDescriptor>();
            foreach (PropertyDescriptor pd in TypeDescriptor.GetProperties(m_queryBag, attributes, true))
            {
                if (pd.Name == "ClassName")
                    descrs.Add(pd);
            }
            descrs.Add(
                new AttachedPropertyDescriptor(Preview.PreviewProperties.ConnectionStringProviderProperty, "ConnectionString"
                    , new Attribute[]{new DisplayNameAttribute("Connection string"),
                        new CategoryAttribute("Preview configuration"),
                        new EditorAttribute(typeof(ConnectionStringEditor), typeof(UITypeEditor)),
                        new DescriptionAttribute("Connection string used to preview queries")}));
            descrs.Add(
                new AttachedPropertyDescriptor(Preview.PreviewProperties.ExternalMappingSourceProperty, "ExternalMappingSource"
                    , new Attribute[]{new DisplayNameAttribute("Xml mapping file"),
                        new CategoryAttribute("Preview configuration"),
                        new EditorAttribute(typeof(BrowseFileEditor), typeof(UITypeEditor)),
                        new DescriptionAttribute("Optional extern XML mapping file")}));
            return new PropertyDescriptorCollection(descrs.ToArray());
        }

        public PropertyDescriptorCollection GetProperties()
        {
            var descrs = new List<PropertyDescriptor>();
            foreach (PropertyDescriptor pd in TypeDescriptor.GetProperties(m_queryBag, true))
            {
                if (pd.Name == "ClassName")
                    descrs.Add(pd);
            }
            descrs.Add(
                new AttachedPropertyDescriptor(Preview.PreviewProperties.ConnectionStringProviderProperty, "ConnectionString"
                    , new Attribute[]{new DisplayNameAttribute("Connection string"),
                        new CategoryAttribute("Preview configuration"),
                        new EditorAttribute(typeof(ConnectionStringEditor), typeof(UITypeEditor)),
                        new DescriptionAttribute("Connection string used to preview queries")}));
            descrs.Add(
                new AttachedPropertyDescriptor(Preview.PreviewProperties.ExternalMappingSourceProperty, "ExternalMappingSource"
                    , new Attribute[]{new DisplayNameAttribute("Xml mapping file"),
                        new CategoryAttribute("Preview configuration"),
                        new EditorAttribute(typeof(BrowseFileEditor), typeof(UITypeEditor)),
                        new DescriptionAttribute("Optional extern XML mapping file")}));
            return new PropertyDescriptorCollection(descrs.ToArray());
        }

        public object GetPropertyOwner(PropertyDescriptor pd)
        {
            return m_queryBag;
        }

        #endregion
    }

    public class RedirectTargetPropertyDescriptor : PropertyDescriptor
    {
        private object m_target;
        private PropertyDescriptor m_baseDescriptor;
        public RedirectTargetPropertyDescriptor(PropertyDescriptor baseDescriptor, object target)
           : base(baseDescriptor.Category, baseDescriptor.Attributes.OfType<Attribute>().ToArray() )
        {
            m_target = target;
            m_baseDescriptor = baseDescriptor;
        }

        public override bool CanResetValue(object component)
        {
            return m_baseDescriptor.CanResetValue(m_target);
        }

        public override Type ComponentType
        {
            get { return typeof(object); }
        }

        public override object GetValue(object component)
        {
            return m_baseDescriptor.GetValue(m_target);
        }

        public override bool IsReadOnly
        {
            get { return m_baseDescriptor.IsReadOnly; }
        }

        public override Type PropertyType
        {
            get { return m_baseDescriptor.PropertyType; }
        }

        public override void ResetValue(object component)
        {
            m_baseDescriptor.ResetValue(m_target);
        }

        public override void SetValue(object component, object value)
        {
            m_baseDescriptor.SetValue(m_target, value);
        }

        public override bool ShouldSerializeValue(object component)
        {
            return m_baseDescriptor.ShouldSerializeValue(m_target);
        }
    }

    public class QueryTypeDescriptor : ICustomTypeDescriptor
    {
        private DependencyObject m_query;
        public DependencyObject Query { get { return m_query; } }
        private QueryBag m_queryBag;
        private ParameterInfo[] m_paramInfos;
        public QueryTypeDescriptor(DependencyObject query,QueryBag queryBag, ParameterInfo[] paramInfos)
        {
            m_query = query;
            m_queryBag = queryBag;
            m_paramInfos = paramInfos == null ? new ParameterInfo[0] : paramInfos;
        }
        public QueryBag QueryBag
        {
            get { return m_queryBag; }
        }
        #region ICustomTypeDescriptor Members

        public AttributeCollection GetAttributes()
        {
            return new AttributeCollection();
        }

        public string GetClassName()
        {
            return "VLinq query";
        }

        public string GetComponentName()
        {
            var asNamed = m_query as INamed;
            if (asNamed != null)
                return asNamed.Name;
            else
                return string.Empty;
        }

        public TypeConverter GetConverter()
        {
            return TypeDescriptor.GetConverter(m_query, true);
        }

        public EventDescriptor GetDefaultEvent()
        {
            return null;
        }

        public PropertyDescriptor GetDefaultProperty()
        {
            return TypeDescriptor.GetDefaultProperty(m_query, true);
        }

        public object GetEditor(Type editorBaseType)
        {
            return TypeDescriptor.GetEditor(m_query, editorBaseType, true);
        }

        public EventDescriptorCollection GetEvents(Attribute[] attributes)
        {
            return new EventDescriptorCollection(new EventDescriptor[] { });
        }

        public EventDescriptorCollection GetEvents()
        {
            return new EventDescriptorCollection(new EventDescriptor[] { });
        }

        public PropertyDescriptorCollection GetProperties(Attribute[] attributes)
        {
            var descrs = new List<PropertyDescriptor>();
            foreach (PropertyDescriptor pd in TypeDescriptor.GetProperties(m_query, attributes, true))
            {
                switch (pd.Name)
                {
                    case "Compiled":
                    case "GeneratePaginatedVersion":
                    case "Name":
                    case "OnlyDistinctRows":
                        descrs.Add(pd);
                        break;
                }


            }
            if (m_queryBag != null)
            {

                descrs.AddRange(new QueryBagTypeDescriptor(m_queryBag).GetProperties().OfType<PropertyDescriptor>().Select(pd => new RedirectTargetPropertyDescriptor(pd, m_queryBag)).OfType<System.ComponentModel.PropertyDescriptor>());
            }
            descrs.Add(new DescriptionPropertyDescriptor());
            var propProvider = new QueryParametersPropertyDescriptorProvider(m_query, m_paramInfos);
            descrs.AddRange(propProvider.PropertyDescriptors);
            return new PropertyDescriptorCollection(descrs.ToArray());
        }

        public PropertyDescriptorCollection GetProperties()
        {
            var descrs = new List<PropertyDescriptor>();
            foreach (PropertyDescriptor pd in TypeDescriptor.GetProperties(m_query, true))
            {
                switch (pd.Name)
                {
                    case "Compiled":
                    case "GeteratePaginatedVersion":
                    case "Name":
                    case "OnlyDistinctRows":
                        descrs.Add(pd);
                        break;
                }

            }
            if (m_queryBag != null)
            {

                descrs.AddRange(new QueryBagTypeDescriptor(m_queryBag).GetProperties().OfType<PropertyDescriptor>().Select(pd => new RedirectTargetPropertyDescriptor(pd, m_queryBag)).OfType<System.ComponentModel.PropertyDescriptor>());
            }
            descrs.Add(new DescriptionPropertyDescriptor());
            var propProvider = new QueryParametersPropertyDescriptorProvider(m_query, m_paramInfos);
            descrs.AddRange(propProvider.PropertyDescriptors);
            return new PropertyDescriptorCollection(descrs.ToArray());
        }

        public object GetPropertyOwner(PropertyDescriptor pd)
        {
            return m_query;
        }

        #endregion
    }
}
