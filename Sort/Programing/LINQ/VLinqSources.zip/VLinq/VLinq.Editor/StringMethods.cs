﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Editor
{
    public static class StringMethods
    {
        public static string ToCamlCase(this string str)
        {
            if (str.Length >0 && char.IsUpper(str, 0))
                return char.ToUpperInvariant(str[0]) + str.Substring(1);
            return str;
        }
    }
}
