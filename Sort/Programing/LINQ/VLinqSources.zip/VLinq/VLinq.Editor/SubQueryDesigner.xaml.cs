﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for SubQueryDesigner.xaml
    /// </summary>
    public partial class SubQueryDesigner : UserControl
    {
        public SubQueryDesigner()
        {
            InitializeComponent();
            DataContextChanged += new DependencyPropertyChangedEventHandler(SubQueryDesigner_DataContextChanged);
        }

        void SubQueryDesigner_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            Controller = DataContext as QueryDesignerController;
        }

        /// <summary>
        /// Controller of the designer
        /// when it is set, the child designers DataContexts are replaced by the proper sub-controllers
        /// </summary>
        public QueryDesignerController Controller
        {
            get { return (QueryDesignerController)GetValue(ControllerProperty); }
            set { SetValue(ControllerProperty, value); }
        }
        public static readonly DependencyProperty ControllerProperty =
            DependencyProperty.Register("Controller", typeof(QueryDesignerController), typeof(SubQueryDesigner), new PropertyMetadata(new PropertyChangedCallback(
                delegate(DependencyObject obj, DependencyPropertyChangedEventArgs args)
                {
                    var designer = obj as SubQueryDesigner;
                    if (args.NewValue != null)
                    {
                        designer.DataSourcesDesigner.DataContext = (args.NewValue as QueryDesignerController).EntitySourceController;
                        designer.ChildQueriesDesigner.DataContext = (args.NewValue as QueryDesignerController).SubQueriesController;
                        designer.ProjectionDesigner.DataContext = (args.NewValue as QueryDesignerController).ProjectionController;
                        designer.OrderByDesigner.DataContext = (args.NewValue as QueryDesignerController).Query;
                        designer.WhereDesigner.Controller.Query = (args.NewValue as QueryDesignerController).Query;
                        designer.GroupByDesigner.DataContext = (args.NewValue as QueryDesignerController).GroupByController;
                        designer.HavingDesigner.Controller.Query = (args.NewValue as QueryDesignerController).Query;

                        designer.aeFrom_Collapsed(null, null);
                        designer.aeGroupBy_Collapsed(null, null);
                        designer.aeHaving_Collapsed(null, null);
                        designer.aeOrderBy_Collapsed(null, null);
                        designer.aeSelect_Collapsed(null, null);
                        designer.aeSubQueries_Collapsed(null, null);
                        designer.aeWhere_Collapsed(null, null);

                        //    (obj as QueryDesigner).CompareEditor.DataContext = (args.NewValue as QueryDesignerController).ComparisonController;
                    }
                    else
                    {
                        designer.DataSourcesDesigner.DataContext = null;
                        designer.ChildQueriesDesigner.DataContext = null;
                        designer.ProjectionDesigner.DataContext = null;
                        designer.OrderByDesigner.DataContext = null;
                        designer.WhereDesigner.Controller.Query = null;
                        designer.GroupByDesigner.DataContext = null;
                        designer.HavingDesigner.Controller.Query = null;
                        //      (obj as QueryDesigner).CompareEditor.DataContext = null;
                    }
                })));

        

        private Inline ToInline(TextFragment tf)
        {
            var run = new Run { Text = tf.Text, ToolTip = tf.ToolTip };
            switch (tf.FragmentKind)
            {
                case FragmentKind.DataType:
                    run.Foreground = new SolidColorBrush(Color.FromRgb(43, 145, 175));
                    break;
                case FragmentKind.Keyword:
                    run.Foreground = Brushes.Blue;
                    break;
                case FragmentKind.String:
                    run.Foreground = new SolidColorBrush(Color.FromRgb(163, 21, 21));
                    break;
            }
            return run;
        }
        private void aeFrom_Expanded(object sender, RoutedEventArgs e)
        {

            txtFromDesc.Text = Messages.FromDragAndDropTip;
            txtFromDesc.Foreground = SystemColors.GrayTextBrush;
        }
        private void aeFrom_Collapsed(object sender, RoutedEventArgs e)
        {

            txtFromDesc.ClearValue(TextBlock.ForegroundProperty);
            try
            {
                var inlines = new List<Inline>();
                txtFromDesc.Inlines.Clear();
                bool first = true;
                foreach (var ds in Controller.Query.DataSources)
                {
                    if ((ds is EntitySource) || (ds is ChildEntitySource))
                    {
                        if (first)
                            first = false;
                        else
                            inlines.Add(new LineBreak());
                        inlines.AddRange(ds.ToInlines().Select(frag => ToInline(frag)));
                    }
                }
                txtFromDesc.Inlines.AddRange(inlines);
            }
            catch { }
        }

        

        private void aeSubQueries_Expanded(object sender, RoutedEventArgs e)
        {
            txtSubQueriesDesc.Text = string.Empty;
        }

        private void aeSubQueries_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                var inlines = new List<Inline>();
                txtSubQueriesDesc.Inlines.Clear();
                bool first = true;
                foreach (var ds in Controller.Query.DataSources)
                {
                    if (ds is ChildQueryResultSource)
                    {
                        if (first)
                            first = false;
                        else
                            inlines.Add(new LineBreak());
                        inlines.AddRange(ds.ToInlines().Select(frag => ToInline(frag)));
                    }
                }
                txtSubQueriesDesc.Inlines.AddRange(inlines);
            }
            catch { }
        }

        private void aeOrderBy_Expanded(object sender, RoutedEventArgs e)
        {

            txtOrderByDescription.Text = Messages.OrderByDragAndDropTip;
            txtOrderByDescription.Foreground = SystemColors.GrayTextBrush;
        }

        private void aeOrderBy_Collapsed(object sender, RoutedEventArgs e)
        {
            txtOrderByDescription.ClearValue(TextBlock.ForegroundProperty);
            txtOrderByDescription.Inlines.Clear();
            txtOrderByDescription.Inlines.AddRange(Controller.Query.OrderBy.ToInlines().Select(frag => ToInline(frag)));
        }

        private void aeWhere_Expanded(object sender, RoutedEventArgs e)
        {
            txtWhereDesc.Text = string.Empty;
        }

        private void aeWhere_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                txtWhereDesc.Inlines.Clear();
                txtWhereDesc.Inlines.AddRange(Controller.Query.Where.ToInlines().Select(frag => ToInline(frag)));
            }
            catch { }
        }

        private void aeGroupBy_Expanded(object sender, RoutedEventArgs e)
        {
            txtGroupByDesc.Text = string.Empty;
        }

        private void aeGroupBy_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                txtGroupByDesc.Inlines.Clear();
                if(Controller.Query.GroupBy!=null)
                    txtGroupByDesc.Inlines.AddRange(Controller.Query.GroupBy.ToInlines().Select(frag => ToInline(frag)));
            }
            catch { }
        }

        private void aeHaving_Expanded(object sender, RoutedEventArgs e)
        {
            txtHavingDesc.Text = string.Empty;
        }

        private void aeHaving_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                txtHavingDesc.Inlines.Clear();
                if(Controller.Query.Having != null)
                    txtHavingDesc.Inlines.AddRange(Controller.Query.Having.ToInlines().Select(frag => ToInline(frag)));
            }
            catch { }
        }

        private void aeSelect_Expanded(object sender, RoutedEventArgs e)
        {
            txtSelectDesc.Text = string.Empty;
        }

        private void aeSelect_Collapsed(object sender, RoutedEventArgs e)
        {
            try
            {
                txtSelectDesc.Inlines.Clear();
                txtSelectDesc.Inlines.AddRange(Controller.Query.Select.ToInlines().Select(frag => ToInline(frag)));
            }
            catch { }
        }


    }
}
