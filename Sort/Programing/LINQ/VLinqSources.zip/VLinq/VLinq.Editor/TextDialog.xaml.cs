﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for TextDialog.xaml
    /// </summary>
    public partial class TextDialog : Window
    {
        private TextDialog()
        {

            InitializeComponent();
        }
        public static void ShowDialog(string text)
        {
            var dlg = new TextDialog();
            dlg.txtShow.Text = text;
            dlg.ShowDialog();
        }
        

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Clipboard.SetText(txtShow.Text);
        }
    }
}
