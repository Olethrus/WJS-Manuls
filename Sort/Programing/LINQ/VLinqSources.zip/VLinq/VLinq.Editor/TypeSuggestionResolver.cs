﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VLinq.WPFControls;
using EnvDTE;
using Microsoft.VisualStudio.Shell;
using VLinq.VSIntegration;
using Microsoft.VisualStudio.Shell.Design;
using System.ComponentModel.Design;
using System.Reflection;
using Microsoft.VisualStudio.Shell.Interop;

namespace VLinq.Editor
{
    public class TypeSuggestionResolver : SuggestionResolverBase
    {
        TypeResolver m_resolver;
        public TypeSuggestionResolver()
        {
            m_resolver = TypeResolver.GetCurrentProjectTypeResolver();
        }

        string m_lastHandled = null;
        protected override void OnSuggestBoxSet()
        {
        }

        protected override void OnSuggestionsRequested()
        {
            if (m_lastHandled == null || m_lastHandled != this.SuggestionContext)
            {
                ResetSuggestions();
            }
        }

        private void ResetSuggestions()
        {
            Suggestions.Clear();
            var ctx = this.SuggestionContext;
            if (m_resolver.Namespaces.ContainsKey(ctx))
            {
                foreach (var ns in m_resolver.Namespaces[ctx])
                {
                    Suggestions.Add(new Suggestion { Label = ns.Substring(ctx.Length>0?ctx.Length+1:0), CaretPosition = ns.Length, GeneratedText = ns, IconSource=VLinq.Editor.Properties.Resources.Namespace });

                }
            }
            if (m_resolver.NamespacesTypes.ContainsKey(ctx))
            {
                foreach (var t in m_resolver.NamespacesTypes[ctx])
                {
                    Suggestions.Add(new Suggestion { Label = t.Name, GeneratedText = t.FullName, CaretPosition = t.FullName.Length , IconSource=t.IsValueType? VLinq.Editor.Properties.Resources._struct : VLinq.Editor.Properties.Resources._class});
                }
            }
            m_lastHandled = ctx;
        }

        protected override void OnSuggestionContextChanged()
        {
            if (this.SuggestBox.ShowingSuggestions)
                ResetSuggestions();
        }

        protected override void OnCaretIndexChanged()
        {
        }

        protected override void OnTextChanged(object e) { }
    }
}
