﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.VSIntegration;
using System.Data.Linq;
using System.Reflection;
using VLinq.WPFControls;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for TypesTreeSelectorControl.xaml
    /// </summary>
    public partial class TypesTreeSelectorControl : UserControl
    {
        public TypesTreeSelectorControl()
        {
            InitializeComponent();
        }

        private void UserControl_Loaded(object sender, RoutedEventArgs e)
        {
        }

        private bool isForDataContext;
        public bool IsForDataContext {
            get { return isForDataContext; }
            set
            {
                isForDataContext = value;
                if (isForDataContext)
                    InitWithDataContexts();
                else
                    Init();
            }
        }

        public void Init()
        {
            var resolver = TypeResolver.GetCurrentProjectTypeResolver();
            tvTypes.ItemsSource = GetNamespaces(resolver, false);
        }

        public void InitWithDataContexts()
        {
            var resolver = TypeResolver.GetCurrentProjectTypeResolver();
            tvTypes.ItemsSource = GetNamespaces(resolver, true);
        }

        private bool DerivesFrom(Type type, Type baseType)
        {
            while ((type != null) && (type != typeof(object)))
            {
                if (type.BaseType == baseType)
                    return true;
                else
                    type = type.BaseType;
            }
            return false;
        }

        private List<NodeInfo> GetNamespaces(TypeResolver resolver, bool forDataContexts)
        {
            var namespaces = new List<NodeInfo>();

            foreach (var ns in resolver.NamespacesTypes.Keys)
            {
                if (string.IsNullOrEmpty(ns) || (ns == "System") || ns.StartsWith("System.") || (ns.StartsWith("Microsoft.")))
                    continue;
                
                var nodeChildren = new List<NodeInfo>();
                var node = new NodeInfo { Text = ns, Icon = NamespaceIcon, Type = null, Children = nodeChildren };

                foreach (var type in resolver.NamespacesTypes[ns].Distinct())
                {
                    if (forDataContexts)
                    {
                        if (DerivesFrom(type, typeof(DataContext)))
                        {
                            var typeNodeChildren = new List<NodeInfo>();
                            var typeNode = 
                                new NodeInfo { Text = type.Name, Icon = ClassIcon, Type = null, Children = typeNodeChildren };

                            var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty);
                            foreach (var property in properties)
                            {
                                if (property.PropertyType.IsGenericType)
                                {
                                    var baseType = property.PropertyType.GetGenericTypeDefinition();
                                    if (baseType == typeof(Table<>))
                                    {
                                        var entityType = property.PropertyType.GetGenericArguments()[0];
                                        var entityNode = 
                                            new NodeInfo { Text = property.Name, Icon = ClassIcon, Type = entityType, IsSelectable = true };
                                        typeNodeChildren.Add(entityNode);
                                    }
                                }
                            }
                            if (typeNodeChildren.Count > 0)
                                nodeChildren.Add(typeNode);
                        }
                    }
                    else
                    {
                        var typeNode = new NodeInfo { Text = type.Name, Type = type, Icon = ClassIcon, IsSelectable = true };
                        nodeChildren.Add(typeNode);
                    }
                }
                if (nodeChildren.Count > 0)
                    namespaces.Add(node);
            }
            return namespaces;
        }
        public byte[] NamespaceIcon
        {
            get { return Properties.Resources.Namespace; }
        }
        public byte[] ClassIcon
        {
            get { return Properties.Resources._class; }
        }

        public event RoutedPropertyChangedEventHandler<object> SelectedItemChanged
        {
            add { tvTypes.SelectedItemChanged += value; }
            remove { tvTypes.SelectedItemChanged -= value; }
        }
    }
    public class NodeInfo
    {
        public string Text { get; set; }
        public Type Type { get; set; }
        public byte[] Icon { get; set; }
        public List<NodeInfo> Children { get; set; }
        public bool IsSelectable { get; set; }
    }
}
