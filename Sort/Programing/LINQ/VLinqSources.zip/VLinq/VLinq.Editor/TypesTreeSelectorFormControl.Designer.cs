﻿namespace VLinq.Editor
{
    partial class TypesTreeSelectorFormControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tvTypes = new System.Windows.Forms.TreeView();
            this.imageList1 = new System.Windows.Forms.ImageList(this.components);
            this.SuspendLayout();
            // 
            // tvTypes
            // 
            this.tvTypes.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tvTypes.Location = new System.Drawing.Point(0, 0);
            this.tvTypes.Name = "tvTypes";
            this.tvTypes.Size = new System.Drawing.Size(346, 318);
            this.tvTypes.TabIndex = 0;
            // 
            // imageList1
            // 
            this.imageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit;
            this.imageList1.ImageSize = new System.Drawing.Size(16, 16);
            this.imageList1.TransparentColor = System.Drawing.Color.Transparent;
            // 
            // TypesTreeSelectorFormControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tvTypes);
            this.Name = "TypesTreeSelectorFormControl";
            this.Size = new System.Drawing.Size(346, 318);
            this.Load += new System.EventHandler(this.TypesTreeSelectorFormControl_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TreeView tvTypes;
        private System.Windows.Forms.ImageList imageList1;
    }
}
