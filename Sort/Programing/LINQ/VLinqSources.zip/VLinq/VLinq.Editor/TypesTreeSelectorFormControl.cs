﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using VLinq.VSIntegration;
using System.Data.Linq;
using System.Reflection;

namespace VLinq.Editor
{
    public partial class TypesTreeSelectorFormControl : UserControl
    {
        public TypesTreeSelectorFormControl()
        {
            InitializeComponent();
        }

        private void TypesTreeSelectorFormControl_Load(object sender, EventArgs e)
        {
            if (IsForDataContext)
                InitWithDataContexts();
            else
                Init();
        }

        public bool IsForDataContext { get; set; }

        public void Init()
        {
            var resolver = TypeResolver.GetCurrentProjectTypeResolver();
            tvTypes.Nodes.Clear();
            FillTypes(GetNamespaces(resolver, false), tvTypes.Nodes);
            //tvTypes.ItemsSource = GetNamespaces(resolver, false);
        }

        private void FillTypes(IEnumerable<NodeInfo> source, TreeNodeCollection nodes)
        {
            foreach (var info in source)
            {
                var newNode = new TreeNode(info.Text);
                newNode.Tag = info.Type;
            }
        }

        public void InitWithDataContexts()
        {
            var resolver = TypeResolver.GetCurrentProjectTypeResolver();
            tvTypes.Nodes.Clear();
            //tvTypes.ItemsSource = GetNamespaces(resolver, true);
        }

        private bool DerivesFrom(Type type, Type baseType)
        {
            while ((type != null) && (type != typeof(object)))
            {
                if (type.BaseType == baseType)
                    return true;
                else
                    type = type.BaseType;
            }
            return false;
        }

        private List<NodeInfo> GetNamespaces(TypeResolver resolver, bool forDataContexts)
        {
            var namespaces = new List<NodeInfo>();

            foreach (var ns in resolver.NamespacesTypes.Keys)
            {
                if (string.IsNullOrEmpty(ns))
                    continue;
                
                var nodeChildren = new List<NodeInfo>();
                var node = new NodeInfo { Text = ns, Icon = NamespaceIcon, Type = null, Children = nodeChildren };

                foreach (var type in resolver.NamespacesTypes[ns].Distinct())
                {
                    if (forDataContexts)
                    {
                        if (DerivesFrom(type, typeof(DataContext)))
                        {
                            var typeNodeChildren = new List<NodeInfo>();
                            var typeNode = 
                                new NodeInfo { Text = type.Name, Icon = ClassIcon, Type = type, Children = typeNodeChildren };

                            var properties = type.GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty);
                            foreach (var property in properties)
                            {
                                if (property.PropertyType.IsGenericType)
                                {
                                    var baseType = property.PropertyType.GetGenericTypeDefinition();
                                    if (baseType == typeof(Table<>))
                                    {
                                        var entityType = property.PropertyType.GetGenericArguments()[0];
                                        var entityNode = 
                                            new NodeInfo { Text = property.Name, Icon = ClassIcon, Type = entityType };
                                        typeNodeChildren.Add(entityNode);
                                    }
                                }
                            }
                            if (typeNodeChildren.Count > 0)
                                nodeChildren.Add(typeNode);
                        }
                    }
                    else
                    {
                        var typeNode = new NodeInfo { Text = type.Name, Type = type, Icon = ClassIcon };
                        nodeChildren.Add(typeNode);
                    }
                }
                if (nodeChildren.Count > 0)
                    namespaces.Add(node);
            }
            return namespaces;
        }
        public byte[] NamespaceIcon
        {
            get { return Properties.Resources.Namespace; }
        }
        public byte[] ClassIcon
        {
            get { return Properties.Resources._class; }
        }
    }
    //public class NodeInfo
    //{
    //    public string Text { get; set; }
    //    public Type Type { get; set; }
    //    public byte[] Icon { get; set; }
    //    public List<NodeInfo> Children { get; set; }
    //}
}
