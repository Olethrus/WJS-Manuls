﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;

namespace VLinq.Editor
{
    public class VLinqComponentToInlineConverter : IValueConverter
    {
        #region IValueConverter Members

        public static Inline ToInline(TextFragment tf)
        {
            var run = new Run { Text = tf.Text, ToolTip = tf.ToolTip };
            switch (tf.FragmentKind)
            {
                case FragmentKind.DataType:
                    run.Foreground = new SolidColorBrush(Color.FromRgb(43, 145, 175));
                    break;
                case FragmentKind.Keyword:
                    run.Foreground = Brushes.Blue;
                    break;
                case FragmentKind.String:
                    run.Foreground = new SolidColorBrush(Color.FromRgb(163, 21, 21));
                    break;
            }
            return run;
        }

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            var asVLinqComponent = value as VLinqComponentBase;
            if (asVLinqComponent != null)
            {
                return asVLinqComponent.ToInlines().Select(tf => ToInline(tf));
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
