﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using VLinq.Processing;
using VLinq.WPFControls;
using System.Diagnostics;

namespace VLinq.Editor
{
    /// <summary>
    /// Interaction logic for ValidationResume.xaml
    /// </summary>
    public partial class ValidationResume : UserControl
    {
        public ValidationResume()
        {
            InitializeComponent();
            
        }
        private IInputElement m_qd;
        /// <summary>
        /// navigate trough the visual tree to find the parent QueryDesigner
        /// </summary>
        protected IInputElement QueryDesigner
        {
            get
            {
                if (m_qd == null)
                {
                    var elem = VisualTreeHelper.GetParent(this);
                    while (elem != null)
                    {
                        if (elem is QueryDesigner)
                        {
                            m_qd = elem as IInputElement;
                            break;
                        }
                       
                           
                        elem = VisualTreeHelper.GetParent(elem);
                    }
                    
                }
                return m_qd;
            }
        }

        //#region Sizing
        //Point m_lastPosition;
        //bool m_resizing;
        //private void Rectangle_MouseLeftButtonDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        //{

        //    m_lastPosition = e.GetPosition(QueryDesigner);
        //    m_resizing = true;
        //    rectResize.CaptureMouse();
        //}
        //private void Rectangle_MouseLeftButtonUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        //{
        //    m_resizing = false;
        //    rectResize.ReleaseMouseCapture();
        //}
        //private void Rectangle_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        //{
        //    if (m_resizing)
        //    {
        //        var newPos = e.GetPosition(QueryDesigner);
        //        var offset = m_lastPosition.X - newPos.X;
        //        var newWidth = lstErrors.ActualWidth + offset;
        //        if (newWidth >= lstErrors.MinWidth)
        //        {
        //            m_lastPosition = newPos;
        //            lstErrors.Width = newWidth;
                    
        //        }
        //    }
        //}
        //#endregion
        /// <summary>
        /// Using attached properties and triggers, we indicate to the editor of the source of the error, that it must be highlighted
        /// Depending of the type of the editor, the highlighting can be different kind of animations
        /// We also ask the StepContainer to scroll to the highlighted editor
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void error_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount > 1 && e.ChangedButton == MouseButton.Left)
            {
                var container = ItemsControl.ContainerFromElement(lstErrors, sender as DependencyObject);
                var query = DataContext as Query;
                if (query != null)
                {
                    var validResult = ValidTimeProperties.GetValidationError(query) as VLinq.Processing.ValidationResult;
                    if (validResult != null)
                    {
                        var error = validResult.Errors[lstErrors.ItemContainerGenerator.IndexFromContainer(container)];
                        if (error.ErrorSource != null)
                        {
                            var editor = DesignTimeProperties.GetEditorFor(error.ErrorSource);
                            if (editor != null)
                            {
                                var parentExpander = editor.FindFirstVisualAncestorOf<AnimatedExpander>();
                                while (parentExpander != null)
                                {
                                    parentExpander.IsExpanded = true;
                                    parentExpander = parentExpander.FindFirstVisualAncestorOf<AnimatedExpander>();
                                }
                                var qd = QueryDesigner as QueryDesigner;
                                if (qd != null)
                                    qd.StepContainer.HighlighElement(editor);
                                
                                DesignTimeProperties.SetHighLight(error.ErrorSource, true);
                                DesignTimeProperties.SetHighLight(error.ErrorSource, false);
                            }
                        }
                        else
                        {
                            Debug.Fail("Validation error with no Error Source");
                        }
                    }
                }
            }
        }


    }
}
