﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace VLinq.Processing
{
    /// <summary>
    /// Base class for all C# formatters (query bag or in line)
    /// </summary>
    /// <typeparam name="TDescriptionBuilder"></typeparam>
    public abstract class CSharpQueryFormatterBase<TDescriptionBuilder> : QueryFormatter<string,TDescriptionBuilder> where TDescriptionBuilder:Processing.TypeDescriptionBuilder, new()
    {


        /// <summary>
        /// Get the type name of a property, giving its property path (ie: "ProductName.Length") and its declaring type TypeDescription
        /// </summary>
        /// <param name="propertyPath"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        protected string GetPropertyTypeName(string propertyPath, TypeDescription description)
        {
            description = GetPropertyDescription(propertyPath, description);
            if (description == null)
                return null;
            else
                return description.CSharpTypeName;
        }

        /// <summary>
        /// Apply a transform to a given value
        /// </summary>
        /// <param name="value"></param>
        /// <param name="transform"></param>
        /// <param name="finalbuilder"></param>
        protected void CreateTransformedValue(string value, Transform transform, StringBuilder finalbuilder, Query query)
        {
            ChangeTypeTransform ctt = null;
            CustomExpressionTransform cet = null;
            EntitySetTransform est = null;
            StringBuilder sbuilder = new StringBuilder();
            if (transform is ToStringTransform)
            {
                sbuilder.AppendFormat("{0}.ToString()", value);

            }
            else if (null != (cet = transform as CustomExpressionTransform))
            {
                sbuilder.Append("(");
                sbuilder.AppendFormat(cet.ExpressionText,
                    value);

                sbuilder.Append(")");
            }
            else if (null != (ctt = transform as ChangeTypeTransform))
            {
                sbuilder.AppendFormat("(({0}) Convert.ChangeType({1}, typeof({0})))",
                    (DescriptionBuilder.BuildTypeDescription(ctt.OutputTypeName) as TypeDescription).CSharpTypeName,
                    value);

            }
            else if (null != (est = transform as EntitySetTransform))
            {
                var tempVarBaseName = "o";
                int counter = 1;
                var tempVarName = tempVarBaseName;
                while (query.FindDataSource(tempVarName) != null)
                    tempVarName = tempVarBaseName + (counter++).ToString(CultureInfo.InvariantCulture);
                sbuilder.AppendFormat("{0}.{1}(", value, est.Operation);
                if (!string.IsNullOrEmpty(est.ProjectionProperty ))
                    sbuilder.AppendFormat("{1} => {1}.{0}", est.ProjectionProperty, tempVarName);
                sbuilder.Append(")");
            }
            if (!string.IsNullOrEmpty(transform.OutputProperty ))
                sbuilder.AppendFormat(".{0}", transform.OutputProperty);
            if (transform.ChainedTransform != null)
            {
                var currentVal = sbuilder.ToString();
                sbuilder = new StringBuilder();
                CreateTransformedValue(currentVal, transform.ChainedTransform, sbuilder, query);
               
            }
            finalbuilder.Append(sbuilder.ToString());
        }

        /// <summary>
        /// Generates the order by statements
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        protected void CreateOrderClause(Query query, StringBuilder sbuilder,int indentLevel)
        {
            if (query.OrderBy.Count > 0)
            {
                bool first = true;
                WriteIndent(indentLevel, sbuilder);
                sbuilder.Append("orderby ");
                foreach (var orderEntry in query.OrderBy)
                {
                    if (!first)
                    {
                        sbuilder.Append("\n");
                        WriteIndent(indentLevel+1, sbuilder);
                        sbuilder.Append(", ");
                    }
                    sbuilder.AppendFormat("{0} {1}\n", string.IsNullOrEmpty( orderEntry.DataSourceProperty ) ? orderEntry.DataSourceName : orderEntry.DataSourceName + "." + orderEntry.DataSourceProperty
                        , orderEntry.Descending ? "descending" : string.Empty);
                    first = false;
                }
            }
        }

        /// <summary>
        /// If not null, render the output transform of the query
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        protected void CreateOutputGrouping(Query query, StringBuilder sbuilder)
        {
            if (string.IsNullOrEmpty (query.OutputTransform.ProjectionProperty))
                sbuilder.AppendFormat(".{0}()", query.OutputTransform.Operation);
            else
                sbuilder.AppendFormat(".{0}(o => o.{1})", query.OutputTransform.Operation, query.OutputTransform.ProjectionProperty);
        }

        /// <summary>
        /// render an operand 
        /// </summary>
        /// <param name="o"></param>
        /// <param name="sbuilder"></param>
        protected void CreateOperand(Operand o, StringBuilder sbuilder, Query query)
        {
            ConstantOperand co;
            DataSourceOperand dso;
            NumericOperationOperand noo;
            ConcatOperationOperand coo;
            MethodCallOperand mco;
            if (null != (dso = o as DataSourceOperand))
            {
                if (dso.Transform != null)
                {
                    CreateTransformedValue(string.IsNullOrEmpty(dso.DataSourceProperty) ? dso.DataSourceName : dso.DataSourceName + "." + dso.DataSourceProperty, dso.Transform, sbuilder, query);
                }
                else
                {
                    sbuilder.Append(dso.DataSourceName);
                    if (!string.IsNullOrEmpty(dso.DataSourceProperty))
                        sbuilder.AppendFormat(".{0}", dso.DataSourceProperty);
                }

            }

            else if (null != (co = o as ConstantOperand))
            {
                if (co.ConstantValue == null)
                {
                    sbuilder.Append("null");
                }
                else
                {
                    var descr = DescriptionBuilder.BuildTypeDescription(co.TypeName);
                    if (descr.IsString)
                        sbuilder.Append(string.Format(CultureInfo.InvariantCulture, "\"{0}\"", co.ConstantValue.ToString().Replace("\\", "\\\\").Replace("\"", "\\\"").Replace("\n", "\\n").Replace("\r", "\\r").Replace("\t", "\\t")));
                    else if (descr.IsBoolean)
                    {
                        bool val = (bool)co.ConstantValue;
                        if (val)
                            sbuilder.Append("true");
                        else
                            sbuilder.Append("false");
                    }
                    else
                    {
                        sbuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}", co.ConstantValue);
                    }
                }
            }
            else if (null != (noo = o as NumericOperationOperand))
            {
                string separator = null;
                switch (noo.Operation)
                {
                    case NumericOperation.Divide:
                        separator = "/";
                        break;
                    case NumericOperation.Minus:
                        separator = "-";
                        break;
                    case NumericOperation.Modulo:
                        separator = "%";
                        break;
                    case NumericOperation.Multiply:
                        separator = "*";
                        break;
                    case NumericOperation.Plus:
                        separator = "+";
                        break;
                }
                bool first = true;
                sbuilder.Append("(");
                foreach (var subOp in noo.Operands)
                {
                    if (first)
                        first = false;
                    else
                        sbuilder.Append(separator);

                    CreateOperand(subOp, sbuilder, query);
                }
                sbuilder.Append(")");
            }
            else if (null != (coo = o as ConcatOperationOperand))
            {
                bool first = true;
                sbuilder.Append("(");
                foreach (var subOp in coo.Operands)
                {
                    if (first)
                        first = false;
                    else
                        sbuilder.Append("+");

                    CreateOperand(subOp, sbuilder, query);
                }
                sbuilder.Append(")");
            }
            else if (null != (mco = o as MethodCallOperand))
            {
                if (mco.IsStaticMethod)
                {
                    sbuilder.Append(DescriptionBuilder.BuildTypeDescription(mco.CallerTypeName).CSharpTypeName);
                }
                else
                {
                    CreateOperand(mco.InstanceMethodCaller, sbuilder, query);
                }
                sbuilder.AppendFormat(".{0}(", mco.MethodName);
                bool first = true;
                foreach (var subOp in mco.MethodParameters)
                {
                    if (first)
                        first = false;
                    else
                        sbuilder.Append(", ");
                    CreateOperand(subOp, sbuilder, query);
                }
                sbuilder.Append(")");
            }

        }


        /// <summary>
        /// Render the where clause
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        protected void CreateWhereClause(Query query, StringBuilder sbuilder,int indentLevel)
        {
            WriteIndent(indentLevel, sbuilder);
            sbuilder.Append("where ");
            CreateConstraint(query.Where, query, sbuilder,indentLevel+1);
        }

        protected void CreateHavingClause(Query query, StringBuilder sbuilder, int indentLevel)
        {
            WriteIndent(indentLevel, sbuilder);
            sbuilder.Append("where ");
            CreateConstraint(query.Having, query, sbuilder,indentLevel+1);
        }

        /// <summary>
        /// Render the projection (branches to CreateDirectProjection or CreateMappendProjection)
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        protected void CreateProjection(Query query, StringBuilder sbuilder,int indentLevel)
        {
            if (query.Select is DirectProjection)
            {
                CreateDirectProjection(sbuilder, query.Select as DirectProjection, query,indentLevel);
            }
            else
            {
                CreateMappedProjection(sbuilder, query.Select as MappedProjection, query,indentLevel);
            }
        }

        protected void CreateMappedProjection(StringBuilder sbuilder, MappedProjection mp, Query query,int indentLevel)
        {
            string type = mp.OutputTypeName;
            if (!mp.GenerateOutputType &&! string.IsNullOrEmpty(mp.OutputTypeName))
            {
                var descr = DescriptionBuilder.BuildTypeDescription(type);
                type = descr.NonAssemblyQualifiedTypeName;
            }
            WriteIndent(indentLevel, sbuilder);
            sbuilder.AppendFormat("select new {0} ", type);
            sbuilder.Append("{");
            bool first = true;
            foreach (ProjectionMapping mapping in mp.Mappings)
            {
                if (!first)
                {
                    sbuilder.Append("\n");
                    WriteIndent(indentLevel+1, sbuilder);
                    sbuilder.Append(",");
                }
                first = false;
                sbuilder.AppendFormat("{0} = ", mapping.OutputProperty);
                CreateOperand(mapping.Operand, sbuilder, query);
            }
            sbuilder.Append("})");
        }
        protected void CreateDirectProjection(StringBuilder sbuilder, DirectProjection dp, Query query,int indentLevel)
        {
            WriteIndent(indentLevel, sbuilder);
            sbuilder.Append("select ");
            CreateOperand(dp.Operand, sbuilder, query);
            sbuilder.Append(")");
        }
        protected void CreateConstraint(Constraint constraint, Query query, StringBuilder sbuilder,int indentLevel)
        {
            var loc = constraint as LogicalOperatorConstraint;
            var bc = constraint as ComparisonConstraint;
            
            if (loc != null && !loc.IsEmpty)
            {
                sbuilder.Append("(");
                bool first = true;
                foreach (Constraint c in loc.Constraints)
                {
                    if (!first)
                    {
                        sbuilder.Append("\n");
                        WriteIndent(indentLevel, sbuilder);
                        if (loc.Operator == LogicalOperator.And)
                            sbuilder.Append(" && ");
                        else
                            sbuilder.Append(" || ");
                    }
                    first = false;
                    CreateConstraint(c, query, sbuilder, indentLevel+1);
                }
                sbuilder.Append(")");
            }
            else if (bc != null)
            {
                sbuilder.Append("(");
                switch (bc.Operator)
                {
                    case Comparison.Contains:
                    case Comparison.EndsWith:
                    case Comparison.StartsWith:
                        CreateOperand(bc.Left, sbuilder, query);
                        sbuilder.AppendFormat(".{0}(", bc.Operator);
                        CreateOperand(bc.Right, sbuilder, query);
                        sbuilder.Append(")");
                        break;
                    case Comparison.NotContains:
                        sbuilder.Append("!");
                        CreateOperand(bc.Left, sbuilder, query);
                        sbuilder.Append(".Contains(");
                        CreateOperand(bc.Right, sbuilder, query);
                        sbuilder.Append(")");
                        break;
                    case Comparison.Equals:
                    case Comparison.Greater:
                    case Comparison.GreaterOrEquals:
                    case Comparison.Lower:
                    case Comparison.LowerOrEquals:
                    case Comparison.NotEquals:
                        CreateOperand(bc.Left, sbuilder, query);
                        string op = string.Empty;
                        switch (bc.Operator)
                        {
                            case Comparison.Equals:
                                op = "==";
                                break;
                            case Comparison.Greater:
                                op = ">";
                                break;
                            case Comparison.GreaterOrEquals:
                                op = ">=";
                                break;
                            case Comparison.Lower:
                                op = "<";
                                break;
                            case Comparison.LowerOrEquals:
                                op = "<=";
                                break;
                            case Comparison.NotEquals:
                                op = "!=";
                                break;
                        }
                        sbuilder.AppendFormat(" {0} ", op);
                        CreateOperand(bc.Right, sbuilder, query);
                        break;
                }
                sbuilder.Append(")");
            }

            
        }
        protected void WriteIndent(int indent, StringBuilder sbuilder)
        {
            for (int i = 0; i < indent; i++)
                sbuilder.Append("\t");
        }
        protected void CreateQuery(Query query, StringBuilder sbuilder, bool paginated)
        {
            CreateQuery(query, sbuilder, paginated, 1);
        }
        protected void CreateQuery(Query query, StringBuilder sbuilder, bool paginated, int indentLevel)
        {
            sbuilder.Append("(");
            int joinCount = 0;
            foreach (DataSource ds in query.DataSources)
            {
                ChildEntitySource ces;
                ChildQueryResultSource cqrs;
                EntitySource es;
                if (null != (cqrs = ds as ChildQueryResultSource))
                {
                    WriteIndent(indentLevel,sbuilder);
                    sbuilder.AppendFormat("let {0} = ", cqrs.Name);
                    CreateQuery(cqrs.Query, sbuilder, false,indentLevel+1);
                    sbuilder.Append("\n");
                }
                else if (null != (ces = ds as ChildEntitySource))
                {
                    DataSource parent = query.FindDataSource(ces.ParentEntitySourceName);
                    WriteIndent(indentLevel, sbuilder);
                    sbuilder.AppendFormat("from {0} in {1}", ds.Name, parent.Name);
                    if (!string.IsNullOrEmpty(ces.ParentEntitySourceProperty))
                        sbuilder.Append("." + ces.ParentEntitySourceProperty);
                    sbuilder.Append("\n");
                }
                else if (null != (es = ds as EntitySource))
                {
                    WriteIndent(indentLevel, sbuilder);
                    var join = query.Joins.Where(j => j.RightEntitySource == ds.Name).SingleOrDefault();
                    if (join == null)
                    {
                        sbuilder.AppendFormat("from {0} in context.GetTable<{1}>()\n", ds.Name, (es.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription).CSharpTypeName);
                    }
                    else
                    {
                        var leftEntityTD = query.DataSources.Where(source => source.Name == join.LeftEntitySource).Select(source => ValidTimeProperties.GetReturnType(source)).Single();
                        var rightEntityTD = query.DataSources.Where(source => source.Name == join.RightEntitySource).Select(source => ValidTimeProperties.GetReturnType(source)).Single();

                        sbuilder.AppendFormat("join {0} in context.GetTable<{1}>()\n", ds.Name, (es.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription).CSharpTypeName);
                        WriteIndent(indentLevel+1, sbuilder);
                        sbuilder.Append("on ");
                        if (join.LeftProperties.Count == 1)
                        {
                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}.{1}", join.LeftEntitySource, join.LeftProperties[0]);

                        }
                        else
                        {
                            sbuilder.Append("new {");
                            for (int i = 0; i < join.LeftProperties.Count; i++)
                            {
                                var leftPropDesc = leftEntityTD.GetProperty(join.LeftProperties[i].Value);
                                var rightPropDesc = rightEntityTD.GetProperty(join.RightProperties[i].Value);

                                if (i > 0)
                                    sbuilder.Append(", ");
                                if (!leftPropDesc.TypeDescription.IsNullableValueType && rightPropDesc.TypeDescription.IsNullableValueType)
                                {
                                    sbuilder.AppendFormat(CultureInfo.InvariantCulture, "part{0}=({3}){1}.{2}", i, join.LeftEntitySource, join.LeftProperties[i], rightPropDesc.TypeDescription.CSharpTypeName);
                                }
                                else
                                    sbuilder.AppendFormat(CultureInfo.InvariantCulture, "part{0}={1}.{2}", i, join.LeftEntitySource, join.LeftProperties[i]);

                            }
                            sbuilder.Append("}");
                        }
                        sbuilder.Append(" equals ");
                        if (join.LeftProperties.Count == 1)
                        {
                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}.{1}", join.RightEntitySource, join.RightProperties[0]);

                        }
                        else
                        {
                            sbuilder.Append("new {");
                            for (int i = 0; i < join.LeftProperties.Count; i++)
                            {
                                var leftPropDesc = leftEntityTD.GetProperty(join.LeftProperties[i].Value);
                                var rightPropDesc = rightEntityTD.GetProperty(join.RightProperties[i].Value);

                                if (i > 0)
                                    sbuilder.Append(", ");
                                if (!rightPropDesc.TypeDescription.IsNullableValueType && leftPropDesc.TypeDescription.IsNullableValueType)
                                {
                                    sbuilder.AppendFormat(CultureInfo.InvariantCulture, "part{0}=({3}){1}.{2}", i, join.RightEntitySource, join.RightProperties[i], leftPropDesc.TypeDescription.CSharpTypeName);
                                }
                                else
                                    sbuilder.AppendFormat(CultureInfo.InvariantCulture, "part{0}={1}.{2}", i, join.RightEntitySource, join.RightProperties[i]);

                            }
                            sbuilder.Append("}");
                        }
                        if (join.IsLeftOutter)
                        {
                            joinCount++;
                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, " into join{0}\n", joinCount);
                            WriteIndent(indentLevel + 1, sbuilder);

                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, "from {0} in join{1}.DefaultIfEmpty()\n", ds.Name, joinCount);

                        }
                        else
                        {
                            sbuilder.AppendLine();
                        }
                    }
                }


            }
            if (query.Where != null
                && (!(query.Where is LogicalOperatorConstraint)
                     || !(query.Where as LogicalOperatorConstraint).IsEmpty)
                    )
            {
                CreateWhereClause(query, sbuilder, indentLevel);
                sbuilder.AppendLine();
            }
            
            CreateOrderClause(query, sbuilder,indentLevel);
            if (query.GroupBy != null)
            {
                CreateGroupBy(query.GroupBy, sbuilder,indentLevel, query);
                if (query.Having != null && (!(query.Having is LogicalOperatorConstraint)
                     || !(query.Having as LogicalOperatorConstraint).IsEmpty))
                {
                    CreateHavingClause(query, sbuilder,indentLevel);
                    sbuilder.Append("\n");
                }
            }
            CreateProjection(query, sbuilder,indentLevel);
            if (query.OnlyDistinctRows)
                sbuilder.Append(".Distinct()");
            if (paginated)
                sbuilder.Append(".Skip(zeroBasedFirstRow).Take(pageSize)");
            if (query.OutputTransform != null)
            {
                CreateOutputGrouping(query, sbuilder);
            }
        }
        protected void CreateGroupPart(GroupPart part, StringBuilder sbuilder, Query query)
        {
            var simplePart = part as SimpleGroupPart;
            if (simplePart != null)
                CreateSimpleGroupPart(simplePart, sbuilder, query);
            else
                CreateComposedGroupPart(part as ComposedGroupPart, sbuilder, query);
        }
        protected void CreateSimpleGroupPart(SimpleGroupPart part, StringBuilder sbuilder, Query query)
        {
            //sbuilder.Append(part.EntityRef.DataSourceName);
            //if (!string.IsNullOrEmpty(part.EntityRef.DataSourceProperty))
            //{
            //    sbuilder.AppendFormat(".{0}", part.EntityRef.DataSourceProperty);
            //}
            CreateOperand(part.EntityRef, sbuilder,query);
        }
        protected void CreateComposedGroupPart(ComposedGroupPart part, StringBuilder sbuilder, Query query)
        {
            sbuilder.AppendFormat(CultureInfo.InvariantCulture,"new {0} ",  ValidTimeProperties.GetReturnType( part).CSharpTypeName);
            sbuilder.Append("{");
            bool first = true;
            foreach (var entityRef in part.EntityRefs)
            {
                if (!first)
                {
                    sbuilder.Append(", ");
                    
                }
                sbuilder.AppendFormat(entityRef.Name);
                sbuilder.Append(" = ");
                CreateOperand(entityRef.Operand, sbuilder, query);


                first = false;

            }
            sbuilder.Append("}");

        }
        protected void CreateGroupBy(Group group, StringBuilder sbuilder, int indentLevel, Query query)
        {
            WriteIndent(indentLevel, sbuilder);
            sbuilder.Append("group ");
            CreateGroupPart(group.Value, sbuilder, query);
            sbuilder.Append(" by ");
            CreateGroupPart(group.Key, sbuilder, query);
            sbuilder.Append(" into ");
            sbuilder.AppendLine(group.GroupName);
        }
    }
}
