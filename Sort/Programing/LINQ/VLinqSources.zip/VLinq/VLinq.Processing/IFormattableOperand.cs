﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Processing
{
    /// <summary>
    /// Will be used for extensibility
    /// </summary>
    public interface IFormattableOperand
    {
        Operand AsKnownOperandType();
    }
}
