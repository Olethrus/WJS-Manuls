﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Processing
{
    /// <summary>
    /// Numeric types sorted in implicit conversion rules order
    /// (if val1 > val2, then val1 is implicitly castable to val2)
    /// </summary>
    public enum NumericTypes
    {
        Byte,
        Short,
        Int,
        Long,
        Float,
        Double,
        Decimal
    }
}
