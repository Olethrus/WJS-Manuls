﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Processing
{
    /// <summary>
    /// Provide a way to describe a property
    /// </summary>
    public class PropertyDescription 
    {
        private string m_name;
        /// <summary>
        /// get or set the name of the property
        /// </summary>
        public string Name
        {
            get { return m_name; }
            set { m_name = value; }
        }
        private TypeDescription m_typeDescription;
        /// <summary>
        /// get or set the Type Description of the property
        /// </summary>
        public TypeDescription TypeDescription
        {
            get { return m_typeDescription; }
            set { m_typeDescription = value; }
        }

    }
}
