﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Permissions;

namespace VLinq.Processing
{

    /// <summary>
    /// Provides a base for specific query formatters
    /// </summary>
    /// <typeparam name="TOutput">Type of the formatter output</typeparam>
    /// <typeparam name="TDescriptionBuilder">Type of the TypeDescriptionBuilder to use</typeparam>
    public abstract class QueryFormatter<TOutput, TDescriptionBuilder> where TDescriptionBuilder : TypeDescriptionBuilder, new()
    {

        TDescriptionBuilder m_descriptionBuilder = new TDescriptionBuilder();
        protected TDescriptionBuilder DescriptionBuilder
        {
            get { return m_descriptionBuilder; }
        }


        /// <summary>
        /// Get the TypeDescription of a property, giving its property path (ie: "ProductName.Length") and its declaring type TypeDescription
        /// </summary>
        /// <param name="propertyPath"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        protected TypeDescription GetPropertyDescription(string propertyPath, TypeDescription description)
        {
            string[] parts = propertyPath.Split('.');
            for (int i = 0; i < parts.Length; i++)
            {
                PropertyDescription matched = description.GetProperty(parts[i]);

                description = matched.TypeDescription;
                if (i == parts.Length - 1)
                {
                    return description;
                }
            }
            return null;
        }

        /// <summary>
        /// Validate and Format the query
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        public TOutput FormatQuery(Query query, QueryValidatorOptions validationOptions)
        {
            QueryValidator validator = new QueryValidator(query, m_descriptionBuilder, validationOptions);
            ValidationResult vresult = validator.Validate();
            if (vresult.Succeeded)
                return BuildQueryOutput(query);
            else
            {
                var ex = new InvalidQueryException();
                ex.ValidationResult = vresult;
                throw ex;
            }
        }

        public TOutput FormatQuery(Query query)
        {
            return FormatQuery(query, QueryValidatorOptions.VerifyCSIdentifiers);
        }

        /// <summary>
        /// Method of the concrete class called after validation
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        protected abstract TOutput BuildQueryOutput(Query query);
    }

    [global::System.Serializable]
    public class InvalidQueryException : Exception
    {
        //
        // For guidelines regarding the creation of new exception types, see
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/cpgenref/html/cpconerrorraisinghandlingguidelines.asp
        // and
        //    http://msdn.microsoft.com/library/default.asp?url=/library/en-us/dncscol/html/csharp07192001.asp
        //

        public InvalidQueryException() { }
        public InvalidQueryException(string message) : base(message) { }
        public InvalidQueryException(string message, Exception inner) : base(message, inner) { }
        protected InvalidQueryException(
          System.Runtime.Serialization.SerializationInfo info,
          System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { }

        private ValidationResult m_validationResult;

        public ValidationResult ValidationResult
        {
            get { return m_validationResult; }
            set { m_validationResult = value; }
        }

        [SecurityPermission(SecurityAction.LinkDemand, Flags=SecurityPermissionFlag.SerializationFormatter)]
        public override void GetObjectData(System.Runtime.Serialization.SerializationInfo info, System.Runtime.Serialization.StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("m_validationResult", m_validationResult);
        }

    }
}
