﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows;
using System.Globalization;

namespace VLinq.Processing
{
    [Flags]
    public enum ValidDirtyState
    {
        None = 0x0,
        Select = 0x1,
        Having = 0x2,
        GroupBy = 0x4,
        Where = 0x8,
        OrderBy = 0x10,
        Joins = 0x20,
        DataSources = 0x40,

        DataSourcesAndDependencies = 0x7f,
        GroupByAndDependencies = 0x7

    }
    /// <summary>
    /// Handles syntaxic and type resolving validation of a query
    /// TODO: QueryBag scope validation (generated types conflicts...)
    /// </summary>
    public class QueryValidator
    {
        private static readonly System.Text.RegularExpressions.Regex s_csIdentifierRegEx = new System.Text.RegularExpressions.Regex("^([a-z]|[A-Z]|_)+([a-z]|[A-Z]|[0-9]|_)*$");
        public static readonly DependencyProperty AttachedValidatorProperty = DependencyProperty.Register("AttachedValidator", typeof(QueryValidator), typeof(QueryValidator));

        private Query m_query;
        private TypeDescriptionBuilder m_descriptionBuilder;
        /// <summary>
        /// Used to get info about types
        /// </summary>
        public TypeDescriptionBuilder TypeDescriptionBuilder
        {
            get { return m_descriptionBuilder; }
        }
        private ObservableCollection<DataSource> m_invalidDataSources;
        private List<ValidationError> m_dataSourceValidationErrors = new List<ValidationError>();
        private List<ValidationError> m_whereValidationErrors = new List<ValidationError>();
        private List<ValidationError> m_havingValidationErrors = new List<ValidationError>();
        private List<ValidationError> m_orderValidationErrors = new List<ValidationError>();
        private List<ValidationError> m_projectionValidationErrors = new List<ValidationError>();
        private List<ValidationError> m_groupingValidationErrors = new List<ValidationError>();
        private TypeDescription m_projectionTypeDescription;
        private QueryValidatorOptions m_options;

        private ValidDirtyState m_validDirtyState = ValidDirtyState.DataSourcesAndDependencies;


        public void ResetCache()
        {
            m_validDirtyState = ValidDirtyState.DataSourcesAndDependencies;
            TypeDescriptionBuilder.ResetCache();
        }


        void m_query_Changed(object sender, NotifyChangedEventArgs e)
        {
            var topOfChangedStack = e.ChangedStack.Peek();

            if (topOfChangedStack.ChangedProperty == Query.DataSourcesProperty)
            {
                #region datasource

                var sourceChildQueryResult = e.ChangedStack.Where(entry => entry.ChangedObject is ChildQueryResultSource).FirstOrDefault();
                if (sourceChildQueryResult == null)
                {
                    m_validDirtyState = ValidDirtyState.DataSourcesAndDependencies;
                    foreach (var cqrs in m_query.DataSources.OfType<ChildQueryResultSource>())
                    {
                        var validator = cqrs.GetValue(AttachedValidatorProperty) as QueryValidator;
                        if (validator != null)
                            validator.m_validDirtyState = ValidDirtyState.DataSourcesAndDependencies;
                    }
                }
                else
                {
                    var ds = sourceChildQueryResult.ChangedObject as ChildQueryResultSource;
                    if (sourceChildQueryResult.ChangedProperty == ChildQueryResultSource.NameProperty)
                        m_validDirtyState = ValidDirtyState.DataSourcesAndDependencies;
                    else
                    {
                        var oldErrorStatus = ValidTimeProperties.GetIsValid(ds);
                        var oldReturnType = ValidTimeProperties.GetReturnType(ds);
                        ValidateChildQueryResultSource(ds);
                        var newErrorStatus = ValidTimeProperties.GetIsValid(ds);
                        var newReturnType = ValidTimeProperties.GetReturnType(ds);
                        if (newErrorStatus != oldErrorStatus || oldReturnType == null || newReturnType == null
                            || !TypeDescriptionBuilder.Equals(oldReturnType, newReturnType))
                            m_validDirtyState = ValidDirtyState.DataSourcesAndDependencies;
                    }
                }

                #endregion
            }
            else if (topOfChangedStack.ChangedProperty == Query.GroupByProperty)
            {
                #region group by
                m_validDirtyState |= ValidDirtyState.GroupByAndDependencies;
                #endregion
            }
            else if (topOfChangedStack.ChangedProperty == Query.HavingProperty)
            {
                #region having
                m_validDirtyState |= ValidDirtyState.Having;
                #endregion
            }
            else if (topOfChangedStack.ChangedProperty == Query.JoinsProperty)
            {
                #region joins
                m_validDirtyState |= ValidDirtyState.DataSources;
                #endregion
            }
            else if (topOfChangedStack.ChangedProperty == Query.OrderByProperty)
            {
                #region order by
                m_validDirtyState |= ValidDirtyState.OrderBy;
                #endregion
            }
            else if (topOfChangedStack.ChangedProperty == Query.SelectProperty)
            {
                #region select
                m_validDirtyState |= ValidDirtyState.Select;
                #endregion
            }
            else if (topOfChangedStack.ChangedProperty == Query.WhereProperty)
            {
                #region where
                m_validDirtyState |= ValidDirtyState.Where;
                #endregion
            }
        }

        /// <summary>
        /// Contains the list of invalid DataSource declarations
        /// </summary>
        public ObservableCollection<DataSource> InvalidDataSources
        {
            get { return m_invalidDataSources; }
        }
        /// <summary>
        /// Indicates if the Query has child queries
        /// </summary>
        public bool HasChildQueries
        {
            get
            {
                foreach (var ds in m_query.DataSources)
                {
                    if (ds is ChildQueryResultSource)
                        return true;
                }
                return false;
            }
        }
        /// <summary>
        /// Indicates if the query has a group operation
        /// </summary>
        public bool IsGrouped
        {
            get
            {
                return m_query.GroupBy != null;
            }
        }

        #region Validation options
        public bool AuthorizeAnonymousOutput
        {
            get { return (m_options & QueryValidatorOptions.AuthorizeAnonymousOutput) == QueryValidatorOptions.AuthorizeAnonymousOutput; }
        }
        public bool ChildQueryMode
        {
            get { return (m_options & QueryValidatorOptions.ChildQueryMode) == QueryValidatorOptions.ChildQueryMode; }
        }
        public bool VerifyCSIdentifiers
        {
            get { return (m_options & QueryValidatorOptions.VerifyCSIdentifiers) == QueryValidatorOptions.VerifyCSIdentifiers; }
        }
        #endregion


        #region Constructors
        public QueryValidator(Query query, TypeDescriptionBuilder descriptionBuilder, QueryValidatorOptions options)
            : this(query, descriptionBuilder, options, new ObservableCollection<DataSource>())
        {
        }

        /// <summary>
        /// Expose the list of invalid data sources for sub-query validators creation only
        /// </summary>
        /// <param name="query"></param>
        /// <param name="descriptionBuilder"></param>
        /// <param name="options"></param>
        /// <param name="invalidDataSources"></param>
        private QueryValidator(Query query, TypeDescriptionBuilder descriptionBuilder, QueryValidatorOptions options, ObservableCollection<DataSource> invalidDataSources)
        {
            m_options = options;
            m_query = query;
            m_descriptionBuilder = descriptionBuilder;
            m_invalidDataSources = invalidDataSources;

            m_query.Changed += new EventHandler<NotifyChangedEventArgs>(m_query_Changed);
            query.SetValue(AttachedValidatorProperty, this);
        }
        #endregion


        /// <summary>
        /// Validate the whole query (if not modified since last-validation, returns the last validation result)
        /// </summary>
        /// <returns></returns>
        public ValidationResult Validate()
        {

            var result = new ValidationResult();
            if (!this.ChildQueryMode)
            {
                if (this.VerifyCSIdentifiers && (m_query.Name == null || !s_csIdentifierRegEx.Match(m_query.Name).Success))
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidIdentifier, Message = ValidationStrings.QueryHasAnInvalidIdentifier, ErrorSource = m_query };
                    result.Errors.Add(error);
                }
            }
            if ((m_validDirtyState & ValidDirtyState.DataSources) == ValidDirtyState.DataSources)
                ValidateDataSources();
            result.Errors.AddRange(m_dataSourceValidationErrors);

            if ((m_validDirtyState & ValidDirtyState.Where) == ValidDirtyState.Where)
                ValidateWhere();
            result.Errors.AddRange(m_whereValidationErrors);
            if ((m_validDirtyState & ValidDirtyState.OrderBy) == ValidDirtyState.OrderBy)
                ValidateOrderBy();
            result.Errors.AddRange(m_orderValidationErrors);
            if (IsGrouped)
            {
                if ((m_validDirtyState & ValidDirtyState.GroupBy) == ValidDirtyState.GroupBy)
                    ValidateGrouping();
                result.Errors.AddRange(m_groupingValidationErrors);
                if (m_query.Having != null)
                {
                    if ((m_validDirtyState & ValidDirtyState.Having) == ValidDirtyState.Having)
                        ValidateHaving();
                    result.Errors.AddRange(m_havingValidationErrors);
                }
            }

            if ((m_validDirtyState & ValidDirtyState.Select) == ValidDirtyState.Select)
                ValidateProjection();
            result.Errors.AddRange(m_projectionValidationErrors);

            if (m_projectionTypeDescription != null)
            {
                if (m_query.GetValue(Query.ParentQueryProperty) == null)
                    m_query.SetValue(ValidTimeProperties.ReturnTypeProperty, m_descriptionBuilder.BuildQueryableOf(m_projectionTypeDescription));
                else
                    m_query.SetValue(ValidTimeProperties.ReturnTypeProperty, m_descriptionBuilder.BuildEnumerableOf(m_projectionTypeDescription));

            }
            if (m_query.OutputTransform != null && result.Succeeded)
            {
                foreach (var error in ValidateOutputGrouping())
                    result.Errors.Add(error);

            }
            //if (m_query.GeneratePaginatedVersion && HasChildQueries)
            //    result.Errors.Add(new ValidationError { Kind = ValidationErrorKind.UnsupportedFeature, Message = ValidationStrings.LinqToSQLDoesNotSupportPaginationWithSubqueries, ErrorSource=m_query });



            m_query.SetValue(ValidTimeProperties.IsValidProperty, result.Succeeded);
            m_query.SetValue(ValidTimeProperties.ValidationErrorProperty, result);
            m_validDirtyState = ValidDirtyState.None;
            return result;
        }
        /// <summary>
        /// Validate a group operation for the specified type (for instance, Average() can only be applied on numeric values)
        /// </summary>
        /// <param name="type"></param>
        /// <param name="operation"></param>
        /// <returns></returns>
        private static bool ValidateGroupOperation(TypeDescription type, GroupOperation operation)
        {
            switch (operation)
            {
                case GroupOperation.Count:
                case GroupOperation.CountDistinct:
                case GroupOperation.First:
                case GroupOperation.Last:
                case GroupOperation.Select:
                    return true;
                case GroupOperation.Max:
                case GroupOperation.Min:
                    return type.IsScalar;
                case GroupOperation.Sum:
                case GroupOperation.Average:
                    return type.IsNumeric;
                default:
                    return false;
            }
        }

        /// <summary>
        /// Validate the output transform of the query (and modify the ValidTimeProperties.ReturnType of the query if needed)
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ValidationError> ValidateOutputGrouping()
        {
            if (m_query.OutputTransform != null)
            {
                TypeDescription outputType = m_projectionTypeDescription;
                if (m_query.OutputTransform.ProjectionProperty != null)
                {
                    switch (m_query.OutputTransform.Operation)
                    {
                        case GroupOperation.Count:
                        case GroupOperation.CountDistinct:
                        case GroupOperation.First:
                        case GroupOperation.Last:
                            yield return new ValidationError { Kind = ValidationErrorKind.InvalidOutputGrouping, Message = ValidationStrings.GroupingOperationDoesNotSupportSelector.Replace("{GroupingOperationMethod}", m_query.OutputTransform.Operation.ToString()), ErrorSource = m_query.OutputTransform };
                            yield break;
                    }
                    var propDesc = GetPropertyDescription(m_query.OutputTransform.ProjectionProperty, m_projectionTypeDescription);
                    if (propDesc == null)
                    {
                        yield return new ValidationError { Kind = ValidationErrorKind.InvalidOutputGrouping, Message = ValidationStrings.UnknownProjPropInOutputGrouping.Replace("{PropertyName}", m_query.OutputTransform.ProjectionProperty), ErrorSource = m_query.OutputTransform };
                        yield break;
                    }
                    outputType = propDesc.TypeDescription;

                }
                if (!ValidateGroupOperation(outputType, m_query.OutputTransform.Operation))
                    yield return new ValidationError { Kind = ValidationErrorKind.InvalidOutputGrouping, Message = ValidationStrings.GroupOperationNotAllowedForType.Replace("{GroupOperation}", m_query.OutputTransform.Operation.ToString()).Replace("{Type}", outputType.CSharpTypeName), ErrorSource = m_query.OutputTransform };
                switch (m_query.OutputTransform.Operation)
                {
                    case GroupOperation.Count:
                    case GroupOperation.CountDistinct:
                        m_query.SetValue(ValidTimeProperties.ReturnTypeProperty, m_descriptionBuilder.BuildTypeDescription("System.Int32"));
                        break;
                    default:

                        if (m_query.OutputTransform.Operation != GroupOperation.Average)
                            m_query.SetValue(ValidTimeProperties.ReturnTypeProperty, outputType);
                        else
                        {
                            var decimalDesc = m_descriptionBuilder.BuildTypeDescription("System.Decimal");
                            var nullableDecimalDesc = m_descriptionBuilder.BuildNullableOf("System.Decimal");
                            var doubleDesc = m_descriptionBuilder.BuildTypeDescription("System.Double");
                            var nullableDoubleDesc = m_descriptionBuilder.BuildNullableOf("System.Double");
                            if (m_descriptionBuilder.Equals(outputType, decimalDesc))
                                m_query.SetValue(ValidTimeProperties.ReturnTypeProperty, decimalDesc);
                            else if (m_descriptionBuilder.Equals(outputType, nullableDecimalDesc))
                                m_query.SetValue(ValidTimeProperties.ReturnTypeProperty, nullableDecimalDesc);
                            else if (outputType.IsNullableValueType)
                                m_query.SetValue(ValidTimeProperties.ReturnTypeProperty, nullableDoubleDesc);
                            else
                                m_query.SetValue(ValidTimeProperties.ReturnTypeProperty, doubleDesc);
                        }
                        break;
                }
            }
        }

        #region DataSources

        /// <summary>
        /// Validate the data sources of the query
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ValidationError> ValidateDataSources()
        {


            m_dataSourceValidationErrors.Clear();
            ClearDataSourcesValidationInfo();
            foreach (var dataSource in m_query.DataSources)
            {

                EntitySource entitySource = null;
                ChildEntitySource childEntitySource = null;
                ChildQueryResultSource childQueryResultSource = null;
                ParameterSource parameterSource = null;
                if (null != (entitySource = dataSource as EntitySource))
                {
                    ValidateEntitySource(entitySource);
                }
                else if (null != (parameterSource = dataSource as ParameterSource))
                {
                    ValidateParameterSource(parameterSource);
                }
                else if (null != (childEntitySource = dataSource as ChildEntitySource))
                {
                    ValidateChildEntitySource(childEntitySource);
                }
                else if (null != (childQueryResultSource = dataSource as ChildQueryResultSource))
                {
                    ValidateChildQueryResultSource(childQueryResultSource);
                }
                if (this.VerifyCSIdentifiers && !s_csIdentifierRegEx.Match(dataSource.Name).Success)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidIdentifier, InvolvedDataSources = { dataSource }, Message = ValidationStrings.InvalidIdentifier.Replace("{Identifier}", dataSource.Name), ErrorSource = dataSource };
                    SetDataSourceError(dataSource, error);

                }
            }

            List<string> rightParts = new List<string>(m_query.Joins.Count);
            foreach (var j in m_query.Joins)
            {
                if (rightParts.Contains(j.RightEntitySource))
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.JoinPartsMismatch, ErrorSource = j, Message = ValidationStrings.EntityAlreadyARightPart.Replace("{Entity}", j.RightEntitySource) };
                    ValidTimeProperties.SetIsValid(j, false);
                    ValidTimeProperties.SetValidationError(j, error);
                    m_dataSourceValidationErrors.Add(error);

                }
                else
                {
                    rightParts.Add(j.RightEntitySource);
                    ValidateJoin(j);
                }
            }
            return m_dataSourceValidationErrors;
        }
        private void ValidateJoin(JoinDeclaration join)
        {
            var leftDS = m_query.DataSources.Where(ds => ds.Name == join.LeftEntitySource).SingleOrDefault();
            if (leftDS == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.DataSourceNotFound, ErrorSource = join, Message = ValidationStrings.LeftDataSourceOfAJoinNotFound.Replace("{leftDS}", join.LeftEntitySource) };
                ValidTimeProperties.SetIsValid(join, false);
                ValidTimeProperties.SetValidationError(join, error);
                m_dataSourceValidationErrors.Add(error);
                return;
            }
            else if (!(leftDS is EntitySource) || !ValidTimeProperties.GetIsValid(leftDS))
            {
                var error = new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, ErrorSource = join, Message = ValidationStrings.LeftDataSourceOfAJoinInvalid.Replace("{leftDS}", join.LeftEntitySource) };
                ValidTimeProperties.SetIsValid(join, false);
                ValidTimeProperties.SetValidationError(join, error);
                m_dataSourceValidationErrors.Add(error);
                return;
            }
            var rightDS = m_query.DataSources.Where(ds => ds.Name == join.RightEntitySource).SingleOrDefault();
            if (rightDS == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.DataSourceNotFound, ErrorSource = join, Message = ValidationStrings.RightDataSourceOfAJoinNotFound.Replace("{rightDS}", join.RightEntitySource) };
                ValidTimeProperties.SetIsValid(join, false);
                ValidTimeProperties.SetValidationError(join, error);
                m_dataSourceValidationErrors.Add(error);
                return;
            }
            else if (!(rightDS is EntitySource) || !ValidTimeProperties.GetIsValid(rightDS))
            {
                var error = new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, ErrorSource = join, Message = ValidationStrings.LeftDataSourceOfAJoinInvalid.Replace("{rightDS}", join.RightEntitySource) };
                ValidTimeProperties.SetIsValid(join, false);
                ValidTimeProperties.SetValidationError(join, error);
                m_dataSourceValidationErrors.Add(error);
                return;
            }

            var leftIndex = m_query.DataSources.IndexOf(leftDS);
            var rightIndex = m_query.DataSources.IndexOf(rightDS);

            if (leftIndex >= rightIndex)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.MisorderedSources, ErrorSource = join, Message = ValidationStrings.LeftDataSourceOfAJoinIsDefinedAfterRight.Replace("{rightDS}", join.RightEntitySource).Replace("{leftDS}", join.LeftEntitySource) };
                ValidTimeProperties.SetIsValid(join, false);
                ValidTimeProperties.SetValidationError(join, error);
                m_dataSourceValidationErrors.Add(error);
                return;
            }

            if (join.LeftProperties == null || join.LeftProperties.Count == 0)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.JoinPartMissing, ErrorSource = join, Message = ValidationStrings.LeftPartOfJoinMissing };
                ValidTimeProperties.SetIsValid(join, false);
                ValidTimeProperties.SetValidationError(join, error);
                m_dataSourceValidationErrors.Add(error);
                return;
            }
            if (join.RightProperties == null || join.RightProperties.Count == 0)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.JoinPartMissing, ErrorSource = join, Message = ValidationStrings.RightPartOfJoinMissing };
                ValidTimeProperties.SetIsValid(join, false);
                ValidTimeProperties.SetValidationError(join, error);
                m_dataSourceValidationErrors.Add(error);
                return;
            }

            if (join.LeftProperties.Count != join.RightProperties.Count)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.JoinPartsMismatch, ErrorSource = join, Message = ValidationStrings.LeftAndRightPartOfJoinMisMatch };
                ValidTimeProperties.SetIsValid(join, false);
                ValidTimeProperties.SetValidationError(join, error);
                m_dataSourceValidationErrors.Add(error);
                return;
            }

            var leftDSTypeDesc = ValidTimeProperties.GetReturnType(leftDS);
            var rightDSTypeDesc = ValidTimeProperties.GetReturnType(rightDS);



            for (int i = 0; i < join.LeftProperties.Count; i++)
            {
                var leftPropName = join.LeftProperties[i].Value;
                var leftPropDesc = leftDSTypeDesc.GetProperty(leftPropName);
                if (leftPropDesc == null)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.DataSourcePropertyNotFound, ErrorSource = join, Message = ValidationStrings.PropertyOfDSDoesNotExists.Replace("{Property}", leftPropName).Replace("{DataSource}", join.LeftEntitySource) };
                    ValidTimeProperties.SetIsValid(join, false);
                    ValidTimeProperties.SetValidationError(join, error);
                    m_dataSourceValidationErrors.Add(error);
                    return;
                }
                if (!leftPropDesc.TypeDescription.IsScalar)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.TypeMismatch, ErrorSource = join, Message = ValidationStrings.InvalidJoinPartType.Replace("{Property}", leftPropName) };
                    ValidTimeProperties.SetIsValid(join, false);
                    ValidTimeProperties.SetValidationError(join, error);
                    m_dataSourceValidationErrors.Add(error);
                    return;
                }
                var rightPropName = join.RightProperties[i].Value;

                var rightPropDesc = rightDSTypeDesc.GetProperty(rightPropName);
                if (rightPropDesc == null)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.DataSourcePropertyNotFound, ErrorSource = join, Message = ValidationStrings.PropertyOfDSDoesNotExists.Replace("{Property}", rightPropName).Replace("{DataSource}", join.RightEntitySource) };
                    ValidTimeProperties.SetIsValid(join, false);
                    ValidTimeProperties.SetValidationError(join, error);
                    m_dataSourceValidationErrors.Add(error);
                    return;
                }
                if (!rightPropDesc.TypeDescription.IsScalar)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.TypeMismatch, ErrorSource = join, Message = ValidationStrings.InvalidJoinPartType.Replace("{Property}", rightPropName) };
                    ValidTimeProperties.SetIsValid(join, false);
                    ValidTimeProperties.SetValidationError(join, error);
                    m_dataSourceValidationErrors.Add(error);
                    return;
                }

                var leftNonNullableType = leftPropDesc.TypeDescription.IsNullableValueType ? leftPropDesc.TypeDescription.TypeParameters[0] : leftPropDesc.TypeDescription;
                var rightNonNullableType = rightPropDesc.TypeDescription.IsNullableValueType ? rightPropDesc.TypeDescription.TypeParameters[0] : rightPropDesc.TypeDescription;

                if (!TypeDescriptionBuilder.Equals(leftNonNullableType, rightNonNullableType))
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.JoinPartsMismatch, ErrorSource = join, Message = ValidationStrings.LeftAndRightPartOfJoinMisMatch };
                    ValidTimeProperties.SetIsValid(join, false);
                    ValidTimeProperties.SetValidationError(join, error);
                    m_dataSourceValidationErrors.Add(error);
                    return;
                }

                ValidTimeProperties.SetValidationError(join, null);
                ValidTimeProperties.SetIsValid(join, true);

            }

        }

        /// <summary>
        /// Validate a subquery (by calling a child QueryValidator) and set its ValidTimeProperties.ReturnType value
        /// </summary>
        /// <param name="childQueryResultSource"></param>
        private void ValidateChildQueryResultSource(ChildQueryResultSource childQueryResultSource)
        {
            var subValidator = childQueryResultSource.GetValue(AttachedValidatorProperty) as QueryValidator;
            if (subValidator == null)
            {
                subValidator = new QueryValidator(childQueryResultSource.Query, m_descriptionBuilder, m_options | QueryValidatorOptions.ChildQueryMode, m_invalidDataSources);
                childQueryResultSource.SetValue(AttachedValidatorProperty, subValidator);
            }
            var subResult = subValidator.Validate();
            if (subResult.Succeeded)
            {
                SetDataSourceValid(childQueryResultSource, childQueryResultSource.Query.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription);

            }
            else
            {
                var error = new ValidationError { Kind = ValidationErrorKind.InvalidChildQuery, ChildQueryValidationResult = subResult, InvolvedDataSources = { childQueryResultSource }, Message = ValidationStrings.InvalidChildQuery.Replace("{Name}", childQueryResultSource.Name), ErrorSource = childQueryResultSource };
                SetDataSourceError(childQueryResultSource, error);
            }
        }
        /// <summary>
        /// Validate a child entity source (if its parent is invalid, it will be invalid to)
        /// Also set its ValidTimeProperties.ReturnType value
        /// </summary>
        /// <param name="childEntitySource"></param>
        private void ValidateChildEntitySource(ChildEntitySource childEntitySource)
        {
            var parentSource = m_query.FindDataSource(childEntitySource.ParentEntitySourceName);
            if (parentSource == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.ParentDataSourceNotFound, InvolvedDataSources = { childEntitySource }, Message = ValidationStrings.ParentDataSourceNotFound.Replace("{Child}", childEntitySource.Name).Replace("{Parent}", childEntitySource.ParentEntitySourceName), ErrorSource = childEntitySource };
                SetDataSourceError(childEntitySource, error);
                return;
            }

            if (m_invalidDataSources.Contains(parentSource))
            {
                var error = new ValidationError { Kind = ValidationErrorKind.InvalidParentDataSource, InvolvedDataSources = { childEntitySource, parentSource }, Message = ValidationStrings.ParentDataSourceInvalid.Replace("{Child}", childEntitySource.Name).Replace("{Parent}", childEntitySource.ParentEntitySourceName), ErrorSource = childEntitySource };
                SetDataSourceError(childEntitySource, error);
                return;
            }

            var sourceDescription = parentSource.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription;
            if (sourceDescription == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.ParentDataSourceNotFound, InvolvedDataSources = { childEntitySource, parentSource }, Message = ValidationStrings.ParentDataSourceNotAlreadyDefined.Replace("{Child}", childEntitySource.Name).Replace("{Parent}", childEntitySource.ParentEntitySourceName), ErrorSource = childEntitySource };
                SetDataSourceError(childEntitySource, error);
                return;
            }

            if (childEntitySource.ParentEntitySourceProperty != null)
            {
                var propDesc = GetPropertyDescription(childEntitySource.ParentEntitySourceProperty, sourceDescription);
                if (propDesc == null)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.ParentDataSourcePropertyNotFound, InvolvedDataSources = { childEntitySource, parentSource }, Message = ValidationStrings.PropertyOfDSDoesNotExists.Replace("{Property}",childEntitySource.ParentEntitySourceProperty).Replace("{DataSource}" ,childEntitySource.ParentEntitySourceName), ErrorSource = childEntitySource };
                    SetDataSourceError(childEntitySource, error);
                    return;
                }
                sourceDescription = propDesc.TypeDescription;
            }
            if (!sourceDescription.IsEnumerable)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.ParentDataSourcePropertyNotEnumerable, InvolvedDataSources = { childEntitySource, parentSource }, Message = ValidationStrings.ChildEntitySourceParentIsNotEnumerable.Replace("{Name}", childEntitySource.Name), ErrorSource = childEntitySource };
                SetDataSourceError(childEntitySource, error);
                return;
            }
            SetDataSourceValid(childEntitySource, sourceDescription.IsGroup ? sourceDescription.TypeParameters[1] : sourceDescription.TypeParameters[0]);
        }

        /// <summary>
        /// Validate an entity source and set its ValidTimeProperties.ReturnType value
        /// </summary>
        /// <param name="entitySource"></param>
        private void ValidateEntitySource(EntitySource entitySource)
        {
            var dsTypeDesc = m_descriptionBuilder.BuildTypeDescription(entitySource.EntityTypeName);
            if (dsTypeDesc == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.TypeResolution, InvolvedDataSources = { entitySource }, Message = ValidationStrings.UnresolvableType.Replace("{Name}", entitySource.EntityTypeName), ErrorSource = entitySource };
                SetDataSourceError(entitySource, error);
            }
            else
            {
                SetDataSourceValid(entitySource, dsTypeDesc);
            }
        }

        /// <summary>
        /// Validate a query parameter and set its ValidTimeProperties.ReturnType value
        /// </summary>
        /// <param name="parameterSource"></param>
        private void ValidateParameterSource(ParameterSource parameterSource)
        {
            var dsTypeDesc = m_descriptionBuilder.BuildTypeDescription(parameterSource.TypeName);
            if (dsTypeDesc == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.TypeResolution, InvolvedDataSources = { parameterSource }, Message = ValidationStrings.UnresolvableType.Replace("{Name}", parameterSource.TypeName), ErrorSource = parameterSource };
                SetDataSourceError(parameterSource, error);
            }
            else
            {
                SetDataSourceValid(parameterSource, dsTypeDesc);
            }
        }

        private void ClearDataSourcesValidationInfo()
        {
            foreach (var dataSource in m_query.DataSources)
            {
                dataSource.ClearValue(ValidTimeProperties.ReturnTypeProperty);
                dataSource.ClearValue(ValidTimeProperties.ValidationErrorProperty);
            }
        }
        /// <summary>
        /// Helper method for data source validation
        /// </summary>
        /// <param name="dataSource"></param>
        /// <param name="error"></param>
        private void SetDataSourceError(DataSource dataSource, ValidationError error)
        {
            dataSource.SetValue(ValidTimeProperties.ValidationErrorProperty, error);
            dataSource.SetValue(ValidTimeProperties.IsValidProperty, false);
            if (!m_invalidDataSources.Contains(dataSource))
                m_invalidDataSources.Add(dataSource);
            m_dataSourceValidationErrors.Add(error);
        }
        /// <summary>
        /// helper method for data source validation
        /// </summary>
        /// <param name="dataSource"></param>
        /// <param name="returnTypeDescription"></param>
        private void SetDataSourceValid(DataSource dataSource, TypeDescription returnTypeDescription)
        {
            dataSource.SetValue(ValidTimeProperties.IsValidProperty, true);
            dataSource.SetValue(ValidTimeProperties.ReturnTypeProperty, returnTypeDescription);
            if (m_invalidDataSources.Contains(dataSource))
                m_invalidDataSources.Remove(dataSource);
        }

        #endregion

        #region Having
        /// <summary>
        /// Validate the having constraint tree
        /// </summary>
        /// <returns></returns>
        public void ValidateHaving()
        {

            m_havingValidationErrors.Clear();

            ValidateConstraint(m_query.Having, true);

        }
        #endregion
        #region Where
        /// <summary>
        /// Validate the where constraint tree
        /// </summary>
        /// <returns></returns>
        public void ValidateWhere()
        {

            m_whereValidationErrors.Clear();

            ValidateConstraint(m_query.Where, false);

        }
        /// <summary>
        /// Validate a constraint (branches to ValidateCompositeConstraint and ValidateComparisonConstraint)
        /// </summary>
        /// <param name="constraint"></param>
        /// <param name="afterGrouping"></param>
        private void ValidateConstraint(Constraint constraint, bool afterGrouping)
        {
            LogicalOperatorConstraint loc = null;
            ComparisonConstraint comp = null;
            if (null != (loc = constraint as LogicalOperatorConstraint))
            {
                ValidateCompositeConstraint(loc, afterGrouping);
            }
            else if (null != (comp = constraint as ComparisonConstraint))
            {
                ValidateComparisonConstraint(comp, afterGrouping);
            }
        }
        /// <summary>
        /// Validate a logical operator constraint (only call ValidateConstraint on its children)
        /// </summary>
        /// <param name="compositeConstraint"></param>
        /// <param name="afterGrouping"></param>
        private void ValidateCompositeConstraint(LogicalOperatorConstraint compositeConstraint, bool afterGrouping)
        {
            foreach (var constraint in compositeConstraint.Constraints)
                ValidateConstraint(constraint, afterGrouping);
        }

        /// <summary>
        /// Validate a comparison constraint
        /// (validates the operands, verify types compatibility with the comparer)
        /// </summary>
        /// <param name="comparison"></param>
        /// <param name="afterGrouping"></param>
        private void ValidateComparisonConstraint(ComparisonConstraint comparison, bool afterGrouping)
        {
            if (comparison.Left == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.OperandNotSet, InvolvedConstraints = { comparison }, Message = ValidationStrings.LeftOperandNotSet, ErrorSource = comparison };
                if (afterGrouping)
                    m_havingValidationErrors.Add(error);
                else
                    m_whereValidationErrors.Add(error);
                comparison.SetValue(ValidTimeProperties.IsValidProperty, false);
            }
            if (comparison.Right == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.OperandNotSet, InvolvedConstraints = { comparison }, Message = ValidationStrings.RightOperandNotSet, ErrorSource = comparison };
                if (afterGrouping)
                    m_havingValidationErrors.Add(error);
                else
                    m_whereValidationErrors.Add(error);
                comparison.SetValue(ValidTimeProperties.IsValidProperty, false);
            }

            bool leftValid = comparison.Left != null, rightValid = comparison.Right != null;

            if (leftValid)
            {
                var error = ValidateOperand(comparison.Left, afterGrouping);
                if (error != null)
                {
                    leftValid = false;
                    if (afterGrouping)
                        m_havingValidationErrors.Add(error);
                    else
                        m_whereValidationErrors.Add(error);
                }
            }
            if (rightValid)
            {
                var error = ValidateOperand(comparison.Right, afterGrouping);
                if (error != null)
                {
                    rightValid = false;
                    if (afterGrouping)
                        m_havingValidationErrors.Add(error);
                    else
                        m_whereValidationErrors.Add(error);
                }
            }

            if (leftValid && rightValid)
            {
                if (!ValidateComparison(comparison.Operator,
                        comparison.Left.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription,
                        comparison.Right.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription))
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidBinaryConstraint, InvolvedConstraints = { comparison }, InvolvedOperands = { comparison.Left, comparison.Right }, Message = ValidationStrings.ComparisonNotPossibleForTheseOperands, ErrorSource = comparison };
                    comparison.SetValue(ValidTimeProperties.IsValidProperty, false);
                    if (afterGrouping)
                        m_havingValidationErrors.Add(error);
                    else
                        m_whereValidationErrors.Add(error);
                }
                else
                {
                    comparison.SetValue(ValidTimeProperties.IsValidProperty, true);
                }
            }
        }
        /// <summary>
        /// Indicates if the comparison operator is compatible with the given types
        /// (the order of typeLeft and typeRight as "list contains object" is valid but not "object contains list")
        /// </summary>
        /// <param name="comparison"></param>
        /// <param name="typeLeft"></param>
        /// <param name="typeRight"></param>
        /// <returns></returns>
        private bool ValidateComparison(Comparison comparison, TypeDescription typeLeft, TypeDescription typeRight)
        {
            switch (comparison)
            {

                case Comparison.Greater:
                case Comparison.GreaterOrEquals:
                case Comparison.Lower:
                case Comparison.LowerOrEquals:
                    return (typeLeft.IsNumeric && typeRight.IsNumeric)
                        || (typeLeft.IsString && typeRight.IsString)
                        || (typeLeft.IsDateTime && typeRight.IsDateTime);

                case Comparison.Equals:
                case Comparison.NotEquals:
                    return (typeLeft.IsNumeric && typeRight.IsNumeric)
                        || (typeLeft.IsString && typeRight.IsString)
                        || (typeLeft.IsDateTime && typeRight.IsDateTime)
                        || (typeLeft.IsBoolean && typeRight.IsBoolean);
                case Comparison.StartsWith:
                case Comparison.EndsWith:
                case Comparison.Contains:
                case Comparison.NotContains:
                    return (typeLeft.IsString && typeRight.IsString)
                        || (typeLeft.IsEnumerable && m_descriptionBuilder.IsAssignableFrom(typeLeft.IsGroup ? typeLeft.TypeParameters[1] : typeLeft.TypeParameters[0], typeRight));
                default:
                    return false;
            }
        }

        /// <summary>
        /// Validate an operand and set its ValidTimeProperties.ReturnType value (branches to specific validation method for different kinds of operands)
        /// </summary>
        /// <param name="operand"></param>
        /// <param name="afterGrouping"></param>
        /// <returns></returns>
        private ValidationError ValidateOperand(Operand operand, bool afterGrouping)
        {
            ConstantOperand constant = operand as ConstantOperand;
            if (constant != null)
            {
                var dsTypeDesc = m_descriptionBuilder.BuildTypeDescription(constant.TypeName);
                if (dsTypeDesc == null)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.TypeResolution, InvolvedOperands = { operand }, Message = ValidationStrings.OperandTypeNotResolved, ErrorSource = operand };

                    operand.SetValue(ValidTimeProperties.IsValidProperty, false);
                    return error;
                }
                else
                {
                    operand.SetValue(ValidTimeProperties.IsValidProperty, true);
                    operand.SetValue(ValidTimeProperties.ReturnTypeProperty, dsTypeDesc);
                    return null;
                }
            }
            else
            {
                DataSourceOperand dsOperand = operand as DataSourceOperand;
                if (dsOperand != null)
                {
                    return ValidateDataSourceOperand(afterGrouping, dsOperand);
                }
                else
                {
                    var numOperand = operand as NumericOperationOperand;
                    if (numOperand != null)
                    {
                        return ValidateNumericOperationOperand(afterGrouping, numOperand);
                    }
                    else
                    {
                        var concatOperand = operand as ConcatOperationOperand;
                        if (concatOperand != null)
                            return ValidateConcatOperand(afterGrouping, concatOperand);
                        else
                        {
                            var methodCall = operand as MethodCallOperand;
                            if (methodCall != null)
                                return ValidateMethodCallOperand(methodCall, afterGrouping);
                            return new ValidationError();
                        }
                    }
                }

                //return false;

            }
        }

        private ValidationError ValidateMethodCallOperand(MethodCallOperand operand, bool afterGrouping)
        {
            ValidationResult res = new ValidationResult();
            if (!operand.IsStaticMethod)
            {
                if (operand.InstanceMethodCaller == null)
                {
                    res.Errors.Add(new ValidationError { Kind = ValidationErrorKind.OperandNotSet, InvolvedOperands = { operand }, Message = ValidationStrings.MethodCallerNotSet, ErrorSource = operand });

                }
                else
                {
                    var error = ValidateOperand(operand.InstanceMethodCaller, afterGrouping);
                    if (error != null)
                    {
                        error.InvolvedOperands.Add(operand);
                        res.Errors.Add(error);
                    }
                    else
                    {
                        if (!m_descriptionBuilder.Equals(ValidTimeProperties.GetReturnType(operand.InstanceMethodCaller), m_descriptionBuilder.BuildTypeDescription(operand.CallerTypeName)))
                        {
                            res.Errors.Add(new ValidationError { Kind = ValidationErrorKind.TypeMismatch, InvolvedOperands = { operand, operand.InstanceMethodCaller }, Message = ValidationStrings.MethodCallerIncorrectType, ErrorSource = operand });

                        }

                    }
                }
            }
            int i = 0;
            for (; i < operand.MethodParameters.Count; i++)
            {
                var error = ValidateOperand(operand.MethodParameters[i], afterGrouping);
                if (error != null)
                {
                    error.InvolvedOperands.Add(operand);
                    res.Errors.Add(error);
                }
                else
                {
                    if (!m_descriptionBuilder.IsAssignableFrom(m_descriptionBuilder.BuildTypeDescription(operand.ParametersTypes[i].TypeName), ValidTimeProperties.GetReturnType(operand.MethodParameters[i])))
                    {
                        res.Errors.Add(new ValidationError { Kind = ValidationErrorKind.TypeMismatch, InvolvedOperands = { operand, operand.MethodParameters[i] }, Message = ValidationStrings.MethodParamIncorectType, ErrorSource = operand });

                    }

                }
            }
            for (; i < operand.ParametersTypes.Count(); i++)
            {
                if (!operand.ParametersTypes[i].IsOptionnal)
                {
                    res.Errors.Add(new ValidationError { Kind = ValidationErrorKind.OperandNotSet, InvolvedOperands = { operand }, Message = ValidationStrings.NonOptionalParamNotSet, ErrorSource = operand });

                }
            }
            if (!res.Succeeded)
            {
                ValidTimeProperties.SetIsValid(operand, false);
                ValidTimeProperties.SetValidationError(operand, res);
                return res;
            }
            else
            {
                ValidTimeProperties.SetIsValid(operand, true);
                ValidTimeProperties.SetReturnType(operand, m_descriptionBuilder.BuildTypeDescription(operand.ReturnType));
                return null;
            }
        }
        private static NumericTypes NumericTypeFromTypeDescription(TypeDescription td)
        {
            if (td.IsByte)
                return NumericTypes.Byte;
            else if (td.IsShort)
                return NumericTypes.Short;
            else if (td.IsInt)
                return NumericTypes.Int;
            else if (td.IsLong)
                return NumericTypes.Long;
            else if (td.IsFloat)
                return NumericTypes.Float;
            else if (td.IsDouble)
                return NumericTypes.Double;
            else
                return NumericTypes.Decimal;

        }

        private TypeDescription TypeDescriptionFromNumericType(NumericTypes type, bool nullable)
        {
            switch (type)
            {
                case NumericTypes.Byte:
                    if (nullable)
                        return m_descriptionBuilder.BuildNullableOf("System.Byte");
                    else
                        return m_descriptionBuilder.BuildTypeDescription("System.Byte");

                case NumericTypes.Decimal:
                    if (nullable)
                        return m_descriptionBuilder.BuildNullableOf("System.Decimal");
                    else
                        return m_descriptionBuilder.BuildTypeDescription("System.Decimal");

                case NumericTypes.Double:
                    if (nullable)
                        return m_descriptionBuilder.BuildNullableOf("System.Double");
                    else
                        return m_descriptionBuilder.BuildTypeDescription("System.Double");

                case NumericTypes.Float:
                    if (nullable)
                        return m_descriptionBuilder.BuildNullableOf("System.Single");
                    else
                        return m_descriptionBuilder.BuildTypeDescription("System.Single");

                case NumericTypes.Int:
                    if (nullable)
                        return m_descriptionBuilder.BuildNullableOf("System.Int32");
                    else
                        return m_descriptionBuilder.BuildTypeDescription("System.Int32");

                case NumericTypes.Long:
                    if (nullable)
                        return m_descriptionBuilder.BuildNullableOf("System.Int64");
                    else
                        return m_descriptionBuilder.BuildTypeDescription("System.Int64");

                case NumericTypes.Short:
                    if (nullable)
                        return m_descriptionBuilder.BuildNullableOf("System.Int16");
                    else
                        return m_descriptionBuilder.BuildTypeDescription("System.Int16");


            }
            return null;
        }
        private ValidationError ValidateConcatOperand(bool afterGrouping, ConcatOperationOperand operand)
        {
            ValidationResult res = new ValidationResult();
            if (operand.Operands.Count == 0)
            {
                res.Errors.Add(new ValidationError { Kind = ValidationErrorKind.OperandNotSet, InvolvedOperands = { operand }, Message = ValidationStrings.ConcatOperationHasNoChild, ErrorSource = operand });
            }
            foreach (var subOp in operand.Operands)
            {
                var error = ValidateOperand(subOp, afterGrouping);
                if (error != null)
                {
                    res.Errors.Add(error);
                }
                else
                {
                    var subOpType = ValidTimeProperties.GetReturnType(subOp);
                    if (!subOpType.IsString)
                    {
                        var subOpAsDSOperand = subOp as DataSourceOperand;
                        if (subOpAsDSOperand == null)
                        {
                            res.Errors.Add(new ValidationError { Kind = ValidationErrorKind.TypeMismatch, InvolvedOperands = { operand, subOp }, Message = ValidationStrings.ConcatOperandsMusBeStrings, ErrorSource = operand });

                        }

                        else
                        {
                            if (subOpAsDSOperand.Transform == null)
                            {
                                subOpAsDSOperand.Transform = new ToStringTransform();
                            }
                            else
                            {
                                Transform lastTransform = subOpAsDSOperand.Transform;
                                while (lastTransform.ChainedTransform != null)
                                    lastTransform = lastTransform.ChainedTransform;
                                lastTransform.ChainedTransform = new ToStringTransform();
                            }
                            var suberr = ValidateDataSourceOperand(afterGrouping, subOpAsDSOperand);
                            if (suberr != null)
                                res.Errors.Add(suberr);
                        }
                    }

                }
            }
            if (res.Succeeded)
            {
                ValidTimeProperties.SetIsValid(operand, true);
                ValidTimeProperties.SetReturnType(operand, m_descriptionBuilder.BuildTypeDescription("System.String"));
                return null;
            }
            else
            {
                ValidTimeProperties.SetIsValid(operand, false);
                ValidTimeProperties.SetValidationError(operand, res);
                res.ErrorSource = operand;
                return res;
            }
        }
        private ValidationError ValidateNumericOperationOperand(bool afterGrouping, NumericOperationOperand operand)
        {
            ValidationResult res = new ValidationResult();
            bool isNullable = false;
            NumericTypes numType = NumericTypes.Byte;
            if (operand.Operands.Count == 0)
            {
                res.Errors.Add(new ValidationError { Kind = ValidationErrorKind.OperandNotSet, InvolvedOperands = { operand }, Message = ValidationStrings.NumericOperationHasNoChild, ErrorSource = operand });
            }
            foreach (var subOp in operand.Operands)
            {
                var error = ValidateOperand(subOp, afterGrouping);
                if (error != null)
                {
                    res.Errors.Add(error);
                }
                else
                {
                    var subOpType = ValidTimeProperties.GetReturnType(subOp);
                    if (!subOpType.IsNumeric)
                    {
                        res.Errors.Add(new ValidationError { Kind = ValidationErrorKind.TypeMismatch, InvolvedOperands = { operand, subOp }, Message = ValidationStrings.NumericSubOpsNotNumeric, ErrorSource = operand });

                    }
                    else
                    {
                        isNullable |= subOpType.IsNullableValueType;
                        NumericTypes subNumType = NumericTypeFromTypeDescription(subOpType);
                        if (subNumType > numType)
                            numType = subNumType;
                    }
                }
            }
            if (res.Succeeded)
            {
                ValidTimeProperties.SetIsValid(operand, true);
                ValidTimeProperties.SetReturnType(operand, TypeDescriptionFromNumericType(numType, isNullable));
                return null;
            }
            else
            {
                ValidTimeProperties.SetIsValid(operand, false);
                ValidTimeProperties.SetValidationError(operand, res);
                res.ErrorSource = operand;
                return res;
            }
        }
        private ValidationError ValidateDataSourceOperand(bool afterGrouping, DataSourceOperand dsOperand)
        {

            TypeDescription returnTypeDescription = null;

            //
            //if (dsOperand.DataSourceName.Contains(".") && dsOperand.DataSourceName.EndsWith("."))
            //{
            //    string[] parts = dsOperand.DataSourceName.Split('.');

            //    var ds = m_query.FindDataSource(parts[0]);
            //    if (ds == null)
            //    {
            //        var error = new ValidationError { Kind = ValidationErrorKind.DataSourceNotFound, InvolvedOperands = { dsOperand }, Message = string.Format(System.Globalization.CultureInfo.InvariantCulture, ValidationStrings.OperandDSDoesNotExist, dsOperand.DataSourceName), ErrorSource = dsOperand };

            //        dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
            //        return error;
            //    }
            //    returnTypeDescription = ds.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription;
            //    if (returnTypeDescription != null)
            //    {
            //        for (int i = 1; i < parts.Length; i++)
            //        {
            //            var propd = returnTypeDescription.GetProperty(parts[i]);
            //            if (propd == null)
            //                return;

            //            returnTypeDescription = propd.TypeDescription;
            //            if (td == null)
            //                return;
            //        }
            //    }
            //}
            ////

            if (!afterGrouping)
            {
                var ds = m_query.FindDataSource(dsOperand.DataSourceName);
                if (ds == null)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.DataSourceNotFound, InvolvedOperands = { dsOperand }, Message = ValidationStrings.OperandDSDoesNotExist.Replace("{DataSource}", dsOperand.DataSourceName), ErrorSource = dsOperand };

                    dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                    return error;
                }
                if (m_invalidDataSources.Contains(ds))
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, InvolvedOperands = { dsOperand }, InvolvedDataSources = { ds }, Message = ValidationStrings.OperandDSInvalid.Replace("{DataSource}", dsOperand.DataSourceName), ErrorSource = dsOperand };

                    dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                    return error;
                }
                returnTypeDescription = ds.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription;
                if (!string.IsNullOrEmpty(dsOperand.DataSourceProperty))
                {
                    var propDesc = GetPropertyDescription(dsOperand.DataSourceProperty, returnTypeDescription);
                    if (propDesc == null)
                    {
                        var error = new ValidationError { Kind = ValidationErrorKind.DataSourcePropertyNotFound, InvolvedOperands = { dsOperand }, InvolvedDataSources = { ds }, Message = ValidationStrings.PropertyOfDSDoesNotExists.Replace("{Property}", dsOperand.DataSourceProperty).Replace("{DataSource}", dsOperand.DataSourceName), ErrorSource = dsOperand };

                        dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                        return error;
                    }
                    returnTypeDescription = propDesc.TypeDescription;
                }
                ds.NameChanged += delegate
                {
                    dsOperand.DataSourceName = ds.Name;
                };
            }
            else
            {
                if (dsOperand.DataSourceName != m_query.GroupBy.GroupName)
                {

                    var ds = m_query.FindDataSource(dsOperand.DataSourceName);
                    if (ds == null)
                    {
                        var error = new ValidationError { Kind = ValidationErrorKind.DataSourceNotFound, InvolvedOperands = { dsOperand }, Message = ValidationStrings.OperandDSDoesNotExist.Replace("{DataSource}", dsOperand.DataSourceName), ErrorSource = dsOperand };

                        dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                        return error;
                    }
                    if (m_invalidDataSources.Contains(ds))
                    {
                        var error = new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, InvolvedOperands = { dsOperand }, InvolvedDataSources = { ds }, Message = ValidationStrings.OperandDSInvalid.Replace("{DataSource}", dsOperand.DataSourceName), ErrorSource = dsOperand };

                        dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                        return error;
                    }
                    if (!(ds is ParameterSource))
                    {
                        var error = new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, InvolvedOperands = { dsOperand }, InvolvedDataSources = { ds }, Message = ValidationStrings.DSNotAvailableAfterGrouping.Replace("{DataSource}", dsOperand.DataSourceName), ErrorSource = dsOperand };

                        dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                        return error;
                    }
                    else
                    {
                        returnTypeDescription = ValidTimeProperties.GetReturnType(ds);
                    }
                }
                else
                {
                    if (m_groupingValidationErrors.Count > 0)
                    {
                        dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                        return new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, Message = ValidationStrings.CannotValidateOperandBecauseOfGroup, ErrorSource = dsOperand };
                    }
                    if (dsOperand.DataSourceProperty != null && (dsOperand.DataSourceProperty == "Key" || dsOperand.DataSourceProperty.StartsWith("Key.")))
                    {
                        returnTypeDescription = ValidTimeProperties.GetReturnType(m_query.GroupBy.Key);
                        var parts = dsOperand.DataSourceProperty.Split('.');
                        if (parts.Length > 1)
                        {
                            var propDesc = GetPropertyDescription(string.Join(".", parts, 1, parts.Length - 1), returnTypeDescription);
                            if (propDesc == null)
                            {
                                dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                                return new ValidationError { Kind = ValidationErrorKind.DataSourcePropertyNotFound, Message = ValidationStrings.GroupKeyDosNotContainsProp.Replace("{Property}", string.Join(".", parts, 1, parts.Length - 1)), ErrorSource = dsOperand };

                            }
                            returnTypeDescription = propDesc.TypeDescription;
                        }
                    }
                    else if (!string.IsNullOrEmpty(dsOperand.DataSourceProperty))
                    {
                        return new ValidationError { Kind = ValidationErrorKind.DataSourcePropertyNotFound, Message = ValidationStrings.InvalidPropertyAfterGrouping, ErrorSource = dsOperand };

                    }
                    else
                    {

                        returnTypeDescription = ValidTimeProperties.GetReturnType(m_query.GroupBy);
                    }
                }
            }
            if (dsOperand.Transform != null)
            {
                var error = ValidateTransform(dsOperand.Transform, ref returnTypeDescription);
                if (error != null)
                {
                    error.InvolvedOperands.Add(dsOperand);
                    dsOperand.SetValue(ValidTimeProperties.IsValidProperty, false);
                    return error;
                }
            }
            dsOperand.SetValue(ValidTimeProperties.ReturnTypeProperty, returnTypeDescription);

            dsOperand.SetValue(ValidTimeProperties.IsValidProperty, true);

            return null;
        }

        /// <summary>
        /// Validate a transformation and modify the original return type description
        /// </summary>
        /// <param name="transform"></param>
        /// <param name="returnTypeDescription"></param>
        /// <returns></returns>
        private ValidationError ValidateTransform(Transform transform, ref TypeDescription returnTypeDescription)
        {
            ChangeTypeTransform ctt = null;
            CustomExpressionTransform cet = null;
            EntitySetTransform est = null;

            if (transform is ToStringTransform)
            {
                returnTypeDescription = m_descriptionBuilder.BuildTypeDescription("System.String");
            }
            else if (null != (cet = transform as CustomExpressionTransform))
            {
                // Should not appear anymore, used at an early develoment stage
                return new ValidationError { Kind = ValidationErrorKind.InvalidTransform, Message = "CustomExpressionTransform is no more allowed", InvolvedTransforms = { cet }, ErrorSource = cet };

            }
            else if (null != (ctt = transform as ChangeTypeTransform))
            {

                returnTypeDescription = m_descriptionBuilder.BuildTypeDescription(ctt.OutputTypeName);

                if (returnTypeDescription == null)
                {
                    return new ValidationError { Kind = ValidationErrorKind.InvalidTransform, InvolvedTransforms = { ctt }, Message = ValidationStrings.ChangeTypeTransfromUnknownType.Replace("{Type}", ctt.OutputTypeName), ErrorSource = transform };

                }


            }
            if (null != (est = transform as EntitySetTransform))
            {
                if (!returnTypeDescription.IsEnumerable)
                {
                    return new ValidationError { Kind = ValidationErrorKind.InvalidTransform, InvolvedTransforms = { transform }, Message = ValidationStrings.EntitySetTransformOnNonEnumerable, ErrorSource = transform };
                }
                returnTypeDescription = returnTypeDescription.IsGroup ? returnTypeDescription.TypeParameters[1] : returnTypeDescription.TypeParameters[0];
                if (est.ProjectionProperty != null)
                {
                    switch (est.Operation)
                    {
                        case GroupOperation.Count:
                        case GroupOperation.CountDistinct:
                        case GroupOperation.First:
                        case GroupOperation.Last:
                            return new ValidationError { Kind = ValidationErrorKind.InvalidTransform, InvolvedTransforms = { transform }, Message = ValidationStrings.GroupingOperationDoesNotSupportSelector.Replace("{GroupingOperationMethod}", est.Operation.ToString()), ErrorSource = transform };
                           

                    }
                    var propDesc = GetPropertyDescription(est.ProjectionProperty, returnTypeDescription);
                    if (propDesc == null)
                    {
                        return new ValidationError { Kind = ValidationErrorKind.InvalidTransform, Message = ValidationStrings.UnknownProjPropInOutputGrouping, ErrorSource = transform };

                    }
                    returnTypeDescription = propDesc.TypeDescription;
                }

                if (!ValidateGroupOperation(returnTypeDescription, est.Operation))
                    return new ValidationError { Kind = ValidationErrorKind.InvalidTransform, Message = ValidationStrings.GroupOperationNotAllowedForType.Replace("{GroupOperation}", est.Operation.ToString()).Replace("{Type}", returnTypeDescription.CSharpTypeName), ErrorSource = transform };
                switch (est.Operation)
                {
                    case GroupOperation.Count:
                    case GroupOperation.CountDistinct:
                        returnTypeDescription = m_descriptionBuilder.BuildTypeDescription("System.Int32");
                        break;
                    case GroupOperation.Select:
                        returnTypeDescription = m_descriptionBuilder.BuildEnumerableOf(returnTypeDescription);
                        break;
                    case GroupOperation.Average:


                        var decimalDesc = m_descriptionBuilder.BuildTypeDescription("System.Decimal");
                        var nullableDecimalDesc = m_descriptionBuilder.BuildNullableOf("System.Decimal");
                        var doubleDesc = m_descriptionBuilder.BuildTypeDescription("System.Double");
                        var nullableDoubleDesc = m_descriptionBuilder.BuildNullableOf("System.Double");
                        if (m_descriptionBuilder.Equals(returnTypeDescription, decimalDesc))
                            returnTypeDescription = decimalDesc;
                        else if (m_descriptionBuilder.Equals(returnTypeDescription, nullableDecimalDesc))
                            returnTypeDescription = nullableDecimalDesc;
                        else if (returnTypeDescription.IsNullableValueType)
                            returnTypeDescription = nullableDoubleDesc;
                        else
                            returnTypeDescription = doubleDesc;

                        break;
                    case GroupOperation.Sum:
                        var shortDesc = m_descriptionBuilder.BuildTypeDescription("System.Int16");
                        var nullableShortDesc = m_descriptionBuilder.BuildNullableOf("System.Int16");
                        if (m_descriptionBuilder.Equals(returnTypeDescription, shortDesc))
                            returnTypeDescription = m_descriptionBuilder.BuildNullableOf("System.Int32");
                        else if (m_descriptionBuilder.Equals(returnTypeDescription, nullableShortDesc))
                            returnTypeDescription = m_descriptionBuilder.BuildNullableOf("System.Int32");

                        if (!returnTypeDescription.IsNullableValueType)
                            returnTypeDescription = m_descriptionBuilder.BuildNullableOf(returnTypeDescription.TypeName);
                        break;
                }
            }

            if (!string.IsNullOrEmpty(transform.OutputProperty))
            {
                var propDesc = GetPropertyDescription(transform.OutputProperty, returnTypeDescription);
                if (propDesc == null)
                {
                    return new ValidationError { Kind = ValidationErrorKind.InvalidTransform, InvolvedTransforms = { ctt }, Message = ValidationStrings.UnknownTransformProperty.Replace("{Property}", transform.OutputProperty), ErrorSource = transform };

                }
                returnTypeDescription = propDesc.TypeDescription;
            }
            if (transform.ChainedTransform != null)
            {
                return ValidateTransform(transform.ChainedTransform, ref returnTypeDescription);
            }
            return null;
        }





        #endregion

        #region Order by
        /// <summary>
        /// Validate the order entries
        /// </summary>
        /// <returns></returns>
        public void ValidateOrderBy()
        {


            m_orderValidationErrors.Clear();

            foreach (var orderEntry in m_query.OrderBy)
            {
                DataSource dataSource = m_query.FindDataSource(orderEntry.DataSourceName);
                if (dataSource == null)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.DataSourceNotFound, InvolvedOrderEntries = { orderEntry }, Message =ValidationStrings.DataSourceNotFound.Replace("{Name}", orderEntry.DataSourceName), ErrorSource = orderEntry };
                    orderEntry.SetValue(ValidTimeProperties.IsValidProperty, false);
                    m_orderValidationErrors.Add(error);
                    continue;
                }
                if (m_invalidDataSources.Contains(dataSource))
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, InvolvedDataSources = { dataSource }, InvolvedOrderEntries = { orderEntry }, Message = ValidationStrings.InvalidDataSource.Replace("{Name}", orderEntry.DataSourceName), ErrorSource = orderEntry };
                    orderEntry.SetValue(ValidTimeProperties.IsValidProperty, false);
                    m_orderValidationErrors.Add(error);
                    continue;
                }
                if (!(dataSource is EntitySource) && !(dataSource is ChildEntitySource))
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, InvolvedDataSources = { dataSource }, InvolvedOrderEntries = { orderEntry }, Message = ValidationStrings.DataSourceIsNotEntity, ErrorSource = orderEntry };
                    orderEntry.SetValue(ValidTimeProperties.IsValidProperty, false);
                    m_orderValidationErrors.Add(error);
                    continue;
                }

                TypeDescription orderEntryType = dataSource.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription;
                if (orderEntry.DataSourceProperty != null)
                {
                    var propDesc = GetPropertyDescription(orderEntry.DataSourceProperty, orderEntryType);
                    if (propDesc == null)
                    {
                        var error = new ValidationError { Kind = ValidationErrorKind.DataSourcePropertyNotFound, InvolvedDataSources = { dataSource }, InvolvedOrderEntries = { orderEntry }, Message = ValidationStrings.PropertyOfDSDoesNotExists.Replace("{Property}", orderEntry.DataSourceProperty).Replace("{DataSource}", orderEntry.DataSourceName), ErrorSource = orderEntry };
                        orderEntry.SetValue(ValidTimeProperties.IsValidProperty, false);
                        m_orderValidationErrors.Add(error);
                        continue;
                    }
                    orderEntryType = propDesc.TypeDescription;
                }
                if (!orderEntryType.IsNumeric && !orderEntryType.IsString && !orderEntryType.IsDateTime)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.TypeMismatch, InvolvedDataSources = { dataSource }, InvolvedOrderEntries = { orderEntry }, Message = ValidationStrings.OrderEntryPropertyIsNotOrderable, ErrorSource = orderEntry };
                    orderEntry.SetValue(ValidTimeProperties.IsValidProperty, false);
                    m_orderValidationErrors.Add(error);
                    continue;
                }
                orderEntry.SetValue(ValidTimeProperties.IsValidProperty, true);
            }

        }

        #endregion

        #region Group
        /// <summary>
        /// Validate the group operation (and set its ValidTimeProperties.ReturnType value)
        /// </summary>
        /// <returns></returns>
        public void ValidateGrouping()
        {

            m_groupingValidationErrors.Clear();
            
            var simpleKey = m_query.GroupBy.Key as SimpleGroupPart;
            ComposedGroupPart composedKey = null;
            if (simpleKey != null)
            {
                ValidateSimpleGroupPart(simpleKey, true);
            }
            else if (null != (composedKey = m_query.GroupBy.Key as ComposedGroupPart))
            {
                ValidateComposedGroupPart(composedKey, true);
            }
            else
            {
                ValidTimeProperties.SetIsValid(m_query.GroupBy, false);
                m_groupingValidationErrors.Add(new ValidationError { ErrorSource = m_query.GroupBy, Message = ValidationStrings.NoGroupByKey, Kind = ValidationErrorKind.GroupingKeyNotSet });
            }
            var simpleValue = m_query.GroupBy.Value as SimpleGroupPart;
            ComposedGroupPart composedValue = null;
            if (simpleValue != null)
            {
                ValidateSimpleGroupPart(simpleValue, false);
            }
            else if (null != (composedValue = m_query.GroupBy.Value as ComposedGroupPart))
            {
                ValidateComposedGroupPart(composedValue, false);
            }
            else
            {
                ValidTimeProperties.SetIsValid(m_query.GroupBy, false);
                m_groupingValidationErrors.Add(new ValidationError { ErrorSource = m_query.GroupBy, Message = ValidationStrings.NoGroupByValue, Kind = ValidationErrorKind.GroupingValueNotSet });
            }

            var valid = m_query.GroupBy.Key != null && m_query.GroupBy.Value != null && ValidTimeProperties.GetIsValid(m_query.GroupBy.Key) && ValidTimeProperties.GetIsValid(m_query.GroupBy.Value);
            if (!s_csIdentifierRegEx.IsMatch(m_query.GroupBy.GroupName))
            {
                valid = false;
                var error = new ValidationError { Kind = ValidationErrorKind.InvalidIdentifier, Message = ValidationStrings.InvalidIdentifier.Replace("{Identifier}", m_query.GroupBy.GroupName) };
                ValidTimeProperties.SetValidationError(m_query.GroupBy, error);
                m_groupingValidationErrors.Add(error);
            }
            ValidTimeProperties.SetIsValid(m_query.GroupBy, valid);
            if (valid)
            {
                ValidTimeProperties.SetValidationError(m_query.GroupBy, null);
                ValidTimeProperties.SetReturnType(m_query.GroupBy,
                    m_descriptionBuilder.BuildGroupOf(ValidTimeProperties.GetReturnType(m_query.GroupBy.Key),
                        ValidTimeProperties.GetReturnType(m_query.GroupBy.Value)));

            }


        }


        private void ValidateComposedGroupPart(ComposedGroupPart groupPart, bool isKeyPart)
        {
            if (groupPart.EntityRefs.Count == 0)
            {
                var nullerror = new ValidationError
                {
                    Kind = isKeyPart ? ValidationErrorKind.GroupingKeyNotSet : ValidationErrorKind.GroupingValueNotSet,
                    Message = isKeyPart ? ValidationStrings.GroupKeyNotSet : ValidationStrings.GroupValueNotSet,
                    ErrorSource = groupPart
                };
                ValidTimeProperties.SetIsValid(groupPart, false);
                ValidTimeProperties.SetValidationError(groupPart, nullerror);
                m_groupingValidationErrors.Add(nullerror);
                return;
            }
            bool existingType = !groupPart.GenerateGroupPartType && !string.IsNullOrEmpty(groupPart.TypeName);
            ValidationResult errorSummary = new ValidationResult();
            TypeDescription typeDesc = null;
            if (existingType)
            {
                typeDesc = m_descriptionBuilder.BuildTypeDescription(groupPart.TypeName);
            }
            else
            {
                typeDesc = new TypeDescription
                {
                    IsAnonymous = String.IsNullOrEmpty(groupPart.TypeName),
                    NonAssemblyQualifiedTypeName = String.IsNullOrEmpty(groupPart.TypeName) ? string.Empty : (from s in groupPart.TypeName.Split('.') select s).Last(),
                    TypeName = groupPart.TypeName
                };
            }
            List<string> usedNames = new List<string>();
            foreach (var entityRef in groupPart.EntityRefs)
            {
                if (usedNames.Contains(entityRef.Name))
                {
                    var identifierError = new ValidationError
                    {
                        Kind = ValidationErrorKind.InvalidIdentifier,
                        Message = ValidationStrings.GroupPropertyAlreadySet.Replace("{Property}", entityRef.Name),
                        ErrorSource = entityRef
                    };
                    errorSummary.Errors.Add(identifierError);
                    m_groupingValidationErrors.Add(identifierError);
                    ValidTimeProperties.SetValidationError(entityRef, identifierError);
                    ValidTimeProperties.SetIsValid(entityRef, false);
                    continue;
                }
                else if (string.IsNullOrEmpty(entityRef.Name) || !s_csIdentifierRegEx.IsMatch(entityRef.Name))
                {
                    var identifierError = new ValidationError
                    {
                        Kind = ValidationErrorKind.InvalidIdentifier,
                        Message = ValidationStrings.GroupPropertyNameInvalid.Replace("{Property}", entityRef.Name),
                        ErrorSource = entityRef
                    };
                    errorSummary.Errors.Add(identifierError);
                    m_groupingValidationErrors.Add(identifierError);
                    ValidTimeProperties.SetValidationError(entityRef, identifierError);
                    ValidTimeProperties.SetIsValid(entityRef, false);
                    continue;
                }
                else
                {
                    ValidTimeProperties.SetIsValid(entityRef, true);
                }
                var error = ValidateOperand(entityRef.Operand, false);
                if (error != null)
                {
                    errorSummary.Errors.Add(error);
                    m_groupingValidationErrors.Add(error);
                }
                else
                {
                    if (!existingType)
                    {
                        typeDesc.Properties.Add(new PropertyDescription { Name = entityRef.Name, TypeDescription = ValidTimeProperties.GetReturnType(entityRef.Operand) });

                    }
                    else
                    {
                        // unused, should be removed
                        var propDesc = GetPropertyDescription(entityRef.Name, typeDesc);
                        if (propDesc == null)
                        {
                            var propError = new ValidationError
                            {
                                Kind = ValidationErrorKind.DataSourcePropertyNotFound,
                                Message = ValidationStrings.PropertyOfDSDoesNotExists.Replace("{Property}", entityRef.Name),
                                ErrorSource = entityRef
                            };
                            errorSummary.Errors.Add(propError);
                            m_groupingValidationErrors.Add(propError);
                            ValidTimeProperties.SetValidationError(entityRef, propError);
                            ValidTimeProperties.SetIsValid(entityRef, false);
                        }
                        if (propDesc.TypeDescription != ValidTimeProperties.GetReturnType(entityRef))
                        {
                            var propError = new ValidationError
                            {
                                Kind = ValidationErrorKind.TypeMismatch,
                                Message = ValidationStrings.PropertyTypeDoesNotMatch.Replace("{Property}", entityRef.Name),
                                ErrorSource = entityRef
                            };
                            errorSummary.Errors.Add(propError);
                            m_groupingValidationErrors.Add(propError);
                            ValidTimeProperties.SetValidationError(entityRef, propError);
                            ValidTimeProperties.SetIsValid(entityRef, false);
                        }
                    }
                }
            }
            if (errorSummary.Succeeded)
            {
                ValidTimeProperties.SetIsValid(groupPart, true);
                ValidTimeProperties.SetReturnType(groupPart, typeDesc);
                ValidTimeProperties.SetValidationError(groupPart, null);
            }
            else
            {
                ValidTimeProperties.SetIsValid(groupPart, false);
                ValidTimeProperties.SetValidationError(groupPart, errorSummary);
            }
        }

        private void ValidateSimpleGroupPart(SimpleGroupPart groupPart, bool isKeyPart)
        {
            if (groupPart.EntityRef == null)
            {
                var nullerror = new ValidationError
                {
                    Kind = isKeyPart ? ValidationErrorKind.GroupingKeyNotSet : ValidationErrorKind.GroupingValueNotSet,
                    Message = isKeyPart ? ValidationStrings.GroupKeyNotSet : ValidationStrings.GroupValueNotSet,
                    ErrorSource = groupPart
                };
                ValidTimeProperties.SetIsValid(groupPart, false);
                ValidTimeProperties.SetValidationError(groupPart, nullerror);
                m_groupingValidationErrors.Add(nullerror);
                return;
            }
            var error = ValidateOperand(groupPart.EntityRef, false);
            if (error == null)
            {
                ValidTimeProperties.SetIsValid(groupPart, true);
                ValidTimeProperties.SetReturnType(groupPart,
                    ValidTimeProperties.GetReturnType(groupPart.EntityRef));
                ValidTimeProperties.SetValidationError(groupPart, null);
            }
            else
            {
                ValidTimeProperties.SetIsValid(groupPart, false);
                m_groupingValidationErrors.Add(error);

                var rootError = new ValidationError
                {
                    Kind = isKeyPart ? ValidationErrorKind.InvalidGroupingKey : ValidationErrorKind.InvalidGroupingValue,
                    Message = isKeyPart ? ValidationStrings.InvalidGroupKey : ValidationStrings.InvalidGroupValue,
                    ErrorSource = groupPart
                };
                m_groupingValidationErrors.Add(rootError);
                ValidTimeProperties.SetValidationError(groupPart, rootError);
            }
        }

        //public ValidationError ValidateEntityRef(EntityRef entityRef)
        //{
        //    if (entityRef.DataSourceName == null)
        //    {
        //        var error = new ValidationError
        //        {
        //            Kind = ValidationErrorKind.DataSourceNotFound,
        //            Message = string.Format("Data source of the entity ref not set")
        //        };
        //        ValidTimeProperties.SetValidationError(entityRef, error);
        //        ValidTimeProperties.SetIsValid(entityRef, false);
        //        return error;
        //    }

        //    var entitySource = m_query.FindDataSource(entityRef.DataSourceName);
        //    if(entitySource == null)
        //    {
        //        var error = new ValidationError
        //        {
        //            Kind = ValidationErrorKind.DataSourceNotFound,                    
        //            Message = string.Format("Data source \"{0}\" not found", entityRef.DataSourceName)
        //        };
        //        ValidTimeProperties.SetValidationError(entityRef, error);
        //        ValidTimeProperties.SetIsValid(entityRef, false);
        //        return error;
        //    }
        //    if(InvalidDataSources.Contains( entitySource))
        //    {
        //        var error = new ValidationError
        //        {
        //            Kind = ValidationErrorKind.InvalidDataSource,                    
        //            Message = string.Format("Data source \"{0}\" is invalid", entityRef.DataSourceName)
        //        };
        //        ValidTimeProperties.SetValidationError(entityRef, error);
        //        ValidTimeProperties.SetIsValid(entityRef, false);
        //        return error;
        //    }
        //    if (!(entitySource is EntitySource) && !(entitySource is ChildEntitySource))
        //    {
        //        var error = new ValidationError
        //        {
        //            Kind = ValidationErrorKind.InvalidDataSource,
        //            InvolvedDataSources = { entitySource },
        //            Message = "Data source of a grouping entity ref must be an EntitySource or ChildEntitySource"
        //        };
        //        ValidTimeProperties.SetValidationError(entityRef, error);
        //        ValidTimeProperties.SetIsValid(entityRef, false);
        //        return error;
        //    }

        //    var typeDesc = ValidTimeProperties.GetReturnType(entitySource);

        //    if(entityRef.DataSourceProperty != null)
        //    {
        //        var propDesc = GetPropertyDescription(entityRef.DataSourceProperty, typeDesc);
        //        if (propDesc == null)
        //        {
        //            var error = new ValidationError
        //            {
        //                Kind = ValidationErrorKind.DataSourcePropertyNotFound,
        //                InvolvedDataSources = { entitySource },
        //                Message = string.Format("Property \"{0}\" of DataSource \"{1}\" not found", entityRef.DataSourceProperty, entityRef.DataSourceName)
        //            };
        //            ValidTimeProperties.SetValidationError(entityRef, error);
        //            ValidTimeProperties.SetIsValid(entityRef, false);
        //            return error;
        //        }
        //        typeDesc = propDesc.TypeDescription;
        //    }
        //    if (entityRef.Name == null)
        //        entityRef.Name = entityRef.DataSourceProperty == null? entityRef.DataSourceName: entityRef.DataSourceProperty;
        //    ValidTimeProperties.SetValidationError(entityRef, null);
        //    ValidTimeProperties.SetIsValid(entityRef, true);
        //    ValidTimeProperties.SetReturnType(entityRef, typeDesc);
        //    return null;
        //}

        #endregion

        #region Projection

        /// <summary>
        /// Validate a projection, set its ValidTimeProperties.ReturnType value, and set m_projectionTypeDescription
        /// (branches to specific method for Direct / Mapped projections
        /// </summary>
        /// <returns></returns>
        public IEnumerable<ValidationError> ValidateProjection()
        {

            m_projectionValidationErrors.Clear();
            if (m_query.Select == null)
            {
                m_projectionValidationErrors.Add(
                    new ValidationError { Kind = ValidationErrorKind.ProjectionNotSet, Message = ValidationStrings.ProjectionNotSet, ErrorSource = m_query });
            }
            else
            {
                var directProj = m_query.Select as DirectProjection;
                if (directProj != null)
                    ValidateDirectProjection(directProj);
                else
                    ValidateMappedProjection(m_query.Select as MappedProjection);

                if (m_projectionValidationErrors.Count == 0)
                {
                    if (!this.AuthorizeAnonymousOutput && !this.ChildQueryMode && m_projectionTypeDescription.IsOrHasAnonymous)
                    {
                        m_projectionValidationErrors.Add(new ValidationError { Kind = ValidationErrorKind.TypeResolution, Message = ValidationStrings.OutputIsAnonymous, ErrorSource = m_query.Select });
                        ValidTimeProperties.SetIsValid(m_query.Select, false);
                        ValidTimeProperties.SetValidationError(m_query.Select, m_projectionValidationErrors[0]);
                    }
                }

                ValidTimeProperties.SetReturnType(m_query.Select, m_projectionTypeDescription);

            }


            return m_projectionValidationErrors;
        }

        private void ValidateDirectProjection(DirectProjection projection)
        {
            if (projection.Operand == null)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.OperandNotSet, Message = ValidationStrings.ProjectionOperandNotSet, ErrorSource = m_query.Select };
                m_projectionValidationErrors.Add(error);
                ValidTimeProperties.SetIsValid(projection, false);
                ValidTimeProperties.SetValidationError(projection, error);
                return;

            }
            else
            {
                var error = ValidateOperand(projection.Operand, IsGrouped);
                if (error != null)
                {
                    m_projectionValidationErrors.Add(error);
                    ValidTimeProperties.SetIsValid(projection, false);
                    ValidTimeProperties.SetValidationError(projection, error);
                    return;
                }
                else
                {
                    ValidTimeProperties.SetIsValid(projection, true);
                    m_projectionTypeDescription = ValidTimeProperties.GetReturnType(projection.Operand);

                }
            }
            //if (!IsGrouped)
            //{
            //    DataSource dataSource = m_query.FindDataSource(projection.DataSourceName);
            //    if (dataSource == null)
            //    {
            //        var error = new ValidationError { Kind = ValidationErrorKind.DataSourceNotFound, Message = "Projection referencing an unknown DataSource" };

            //        m_projectionValidationErrors.Add(error);
            //        return;
            //    }
            //    if (m_invalidDataSources.Contains(dataSource))
            //    {
            //        var error = new ValidationError { Kind = ValidationErrorKind.InvalidDataSource, InvolvedDataSources = { dataSource }, Message = "Projection referencing an invalid DataSource" };

            //        m_projectionValidationErrors.Add(error);
            //        return;
            //    }

            //    var descr = dataSource.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription;
            //    if (projection.DataSourceProperty != null)
            //    {

            //        var propDescr = GetPropertyDescription(projection.DataSourceProperty, descr);
            //        if (propDescr == null)
            //        {
            //            var error = new ValidationError { Kind = ValidationErrorKind.DataSourcePropertyNotFound, InvolvedDataSources = { dataSource }, Message = "Projection data source property not found" };
            //            m_projectionValidationErrors.Add(error);
            //            return;
            //        }
            //        else
            //        {
            //            m_projectionTypeDescription = propDescr.TypeDescription;
            //        }
            //    }
            //    else
            //    {
            //        m_projectionTypeDescription = descr;

            //    }
            //    if (projection.Transform != null)
            //    {
            //        var valError = ValidateTransform(projection.Transform, ref m_projectionTypeDescription);
            //        if (valError != null)
            //        {
            //            m_projectionValidationErrors.Add(valError);
            //        }
            //    }
            //}
            //else
            //{
            //    m_projectionTypeDescription = ValidTimeProperties.GetReturnType(m_query.GroupBy);
            //}
        }

        private void ValidateMappedProjection(MappedProjection projection)
        {

            m_projectionTypeDescription = new TypeDescription { IsNumeric = false, IsScalar = false, IsString = false, TypeName = projection.OutputTypeName, NonAssemblyQualifiedTypeName = projection.OutputTypeName };
            if (string.IsNullOrEmpty(projection.OutputTypeName))
                m_projectionTypeDescription.IsAnonymous = true;
            if (m_projectionTypeDescription.IsAnonymous && !AuthorizeAnonymousOutput && !this.ChildQueryMode)
            {
                var error = new ValidationError { Kind = ValidationErrorKind.InvalidIdentifier, Message = ValidationStrings.AnonymousOutputUnavailableForRootQueries, ErrorSource = m_query.Select };
                ValidTimeProperties.SetIsValid(projection, false);
                ValidTimeProperties.SetValidationError(projection, error);
                m_projectionValidationErrors.Add(error);
                return;
            }
            if (!projection.GenerateOutputType && !m_projectionTypeDescription.IsAnonymous)
            {
                m_projectionTypeDescription = m_descriptionBuilder.BuildTypeDescription(projection.OutputTypeName);

                if (m_projectionTypeDescription == null)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.TypeResolution, Message = ValidationStrings.UnresolvableType.Replace("{Name}",projection.OutputTypeName), ErrorSource = m_query.Select };
                    ValidTimeProperties.SetIsValid(projection, false);
                    ValidTimeProperties.SetValidationError(projection, error);
                    m_projectionValidationErrors.Add(error);
                    return;
                }

            }
            else if (this.VerifyCSIdentifiers && !m_projectionTypeDescription.IsAnonymous)
            {
                if (!s_csIdentifierRegEx.Match(projection.OutputTypeName).Success)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidIdentifier, Message = ValidationStrings.InvalidOutputProjectionType, ErrorSource = m_query.Select };
                    ValidTimeProperties.SetIsValid(projection, false);
                    ValidTimeProperties.SetValidationError(projection, error);
                    m_projectionValidationErrors.Add(error);
                    return;
                }
            }
            ValidTimeProperties.SetIsValid(projection, true);
            foreach (ProjectionMapping mapping in projection.Mappings)
            {
                if (mapping.Operand == null)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.OperandNotSet, InvolvedMappings = { mapping }, Message = ValidationStrings.MappingOperandNotSet, ErrorSource = mapping };
                    m_projectionValidationErrors.Add(error);
                    ValidTimeProperties.SetIsValid(mapping, false);
                    ValidTimeProperties.SetValidationError(mapping, error);
                    continue;
                }
                if (string.IsNullOrEmpty(mapping.OutputProperty))
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidIdentifier, InvolvedMappings = { mapping }, Message = ValidationStrings.MappingPropertyNameNotSet, ErrorSource = mapping };
                    m_projectionValidationErrors.Add(error);
                    ValidTimeProperties.SetIsValid(mapping, false);
                    ValidTimeProperties.SetValidationError(mapping, error);
                    continue;
                }
                else if (VerifyCSIdentifiers && !s_csIdentifierRegEx.Match(mapping.OutputProperty).Success)
                {
                    var error = new ValidationError { Kind = ValidationErrorKind.InvalidIdentifier, InvolvedMappings = { mapping }, Message = ValidationStrings.InvalidIdentifier.Replace("{Identifier}", mapping.OutputProperty), ErrorSource = mapping };
                    m_projectionValidationErrors.Add(error);
                    ValidTimeProperties.SetIsValid(mapping, false);
                    ValidTimeProperties.SetValidationError(mapping, error);
                    continue;
                }

                var operror = ValidateOperand(mapping.Operand, IsGrouped);
                if (operror != null)
                {
                    m_projectionValidationErrors.Add(operror);
                    ValidTimeProperties.SetIsValid(mapping, false);
                    ValidTimeProperties.SetValidationError(mapping, operror);
                    continue;
                }
                var desc = ValidTimeProperties.GetReturnType(mapping.Operand);
                if (desc.IsGroup)
                    desc = m_descriptionBuilder.BuildEnumerableOf(desc.TypeParameters[1]);
                ValidTimeProperties.SetReturnType(mapping, desc);
                if (!projection.GenerateOutputType && !m_projectionTypeDescription.IsAnonymous)
                {
                    var targetPropertyDesc = GetPropertyDescription(mapping.OutputProperty, m_projectionTypeDescription);

                    if (targetPropertyDesc == null || !m_descriptionBuilder.IsAssignableFrom(targetPropertyDesc.TypeDescription, ValidTimeProperties.GetReturnType(mapping)))
                    {
                        var mapError = new ValidationError { Kind = ValidationErrorKind.TypeMismatch, InvolvedMappings = { mapping }, Message = ValidationStrings.MappingOutputTypeDoesNotMatch, ErrorSource = mapping };
                        m_projectionValidationErrors.Add(mapError);
                        ValidTimeProperties.SetIsValid(mapping, false);
                        ValidTimeProperties.SetValidationError(mapping, operror);
                        continue;
                    }
                }
                else
                {

                    m_projectionTypeDescription.Properties.Add(new PropertyDescription { Name = mapping.OutputProperty, TypeDescription = ValidTimeProperties.GetReturnType(mapping) });
                }
                ValidTimeProperties.SetIsValid(mapping, true);
                ValidTimeProperties.SetValidationError(mapping, null);


            }
        }
        #endregion
        /// <summary>
        /// Get a property description
        /// </summary>
        /// <param name="property"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        private static PropertyDescription GetPropertyDescription(string property, TypeDescription description)
        {
            string[] parts = property.Split('.');
            for (int i = 0; i < parts.Length; i++)
            {
                PropertyDescription matched = description.GetProperty(parts[i]);
                if (matched == null)
                {
                    return null;

                }
                if (i == parts.Length - 1)
                    return matched;
                description = matched.TypeDescription;

            }
            return null;
        }


    }
}
