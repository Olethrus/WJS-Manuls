﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Processing
{
    [Flags]
    public enum QueryValidatorOptions
    {
        None = 0,
        AuthorizeAnonymousOutput = 1,
        ChildQueryMode=2,
        VerifyCSIdentifiers=4
    }
}
