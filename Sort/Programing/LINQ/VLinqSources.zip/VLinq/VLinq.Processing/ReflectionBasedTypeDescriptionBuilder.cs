﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.Globalization;

namespace VLinq.Processing
{
    /// <summary>
    /// Implementation of TypeDescriptionBuilder using Reflection (used for Runtime components)
    /// </summary>
    public class ReflectionBasedTypeDescriptionBuilder : TypeDescriptionBuilder
    {
        /// <summary>
        /// Customized TypeDescription
        /// </summary>
        private class ReflectionBasedTypeDescription : TypeDescription
        {
            private ReflectionBasedTypeDescriptionBuilder m_builder;
            private Type m_resolvedType;
            public Type ResolvedType
            {
                get { return m_resolvedType; }
            }
            public ReflectionBasedTypeDescription(ReflectionBasedTypeDescriptionBuilder builder, Type resolvedType)
            {
                m_builder = builder;
                m_resolvedType = resolvedType;
            }
            private bool m_propertiesLoaded;
            private void LoadProperties()
            {
                foreach (PropertyInfo pi in m_resolvedType.GetProperties())
                {
                    if (pi.CanRead  && (pi.GetIndexParameters() == null || pi.GetIndexParameters().Length == 0))
                    {
                        PropertyDescription pd = new PropertyDescription { Name = pi.Name };

                        var desc = m_builder.BuildTypeDescription(pi.PropertyType.FullName);
                        
                        pd.TypeDescription = desc;
                        base.Properties.Add(pd);
                    }
                }
                m_propertiesLoaded = true;
            }

            public override List<PropertyDescription> Properties
            {
                get
                {
                    if (!m_propertiesLoaded)
                        LoadProperties();
                    return base.Properties;
                }
            }
            public override PropertyDescription GetProperty(string name)
            {
                if (!m_propertiesLoaded)
                    LoadProperties();
                return base.GetProperty(name);
            }
        }
       


        

        public ReflectionBasedTypeDescriptionBuilder()
        {
            
        }

        /// <summary>
        /// Resolve a type using reflection
        /// </summary>
        /// <param name="typeName"></param>
        /// <returns></returns>
        protected virtual Type  ResolveType(string typeName)
        {
            var resolvedType = Type.GetType(typeName, false);
            return resolvedType;           
        }
        

       
        /// <summary>
        /// Array of BCL scalar types
        /// </summary>
        private static Type[] s_scalarTypes = new Type[] { typeof(byte), typeof(short), typeof(int), typeof(long), typeof(float), typeof(double), typeof(decimal), typeof(string), typeof(DateTime), typeof(byte[]), typeof(bool) };
        /// <summary>
        /// Array of BCL numeric types
        /// </summary>
        private static Type[] s_numericTypes = new Type[] { typeof(byte), typeof(short), typeof(int), typeof(long), typeof(float), typeof(double), typeof(decimal) };

        /// <summary>
        /// Cache of TypeDescriptions
        /// </summary>
        private Dictionary<string, TypeDescription> m_descriptionCache = new Dictionary<string, TypeDescription>();

        /// <summary>
        /// Build a type description (or retrieve it from cache)
        /// </summary>
        /// <param name="typeName"></param>
        /// <returns></returns>
        public override TypeDescription BuildTypeDescription(string typeName)
        {
            if (typeName == null)
                return null;
            if (m_descriptionCache.ContainsKey(typeName))
                return m_descriptionCache[typeName];
            Type resolvedType = ResolveType(typeName);
            if (resolvedType == null)
                return null;
            var td = new ReflectionBasedTypeDescription(this,resolvedType);
            FillTypeDescription(td, resolvedType);
            m_descriptionCache.Add(typeName, td);
            return td;
        }

        
        /// <summary>
        /// Fill a Type Description with resolved type infos
        /// </summary>
        /// <param name="description"></param>
        /// <param name="resolvedType"></param>
        private  void FillTypeDescription( TypeDescription description, Type resolvedType)
        {
            description.TypeName = resolvedType.AssemblyQualifiedName;
            Type nullableValueType = null;
            if (resolvedType.IsGenericType && resolvedType.GetGenericTypeDefinition() == typeof(Nullable<>))
            {
                description.IsNullableValueType = true;
                nullableValueType = resolvedType.GetGenericArguments()[0];
            }
            description.IsGenericTypeDefinition = resolvedType.IsGenericTypeDefinition;
            description.IsBoolean = description.IsNullableValueType ?
                nullableValueType == typeof(bool) : resolvedType == typeof(bool);
            description.IsDateTime = description.IsNullableValueType ?
                nullableValueType == typeof(DateTime) : resolvedType == typeof(DateTime);
            description.IsGeneric = resolvedType.IsGenericType;
            description.IsNumeric = description.IsNullableValueType ?
                s_numericTypes.Contains(nullableValueType) : s_numericTypes.Contains(resolvedType);
            if (description.IsNumeric)
            {
                description.IsByte = resolvedType == typeof(byte) || resolvedType == typeof(byte?);
                description.IsShort = resolvedType == typeof(short) || resolvedType == typeof(short?);
                description.IsInt = resolvedType == typeof(int) || resolvedType == typeof(int?);
                description.IsLong = resolvedType == typeof(long) || resolvedType == typeof(long?);
                description.IsFloat = resolvedType == typeof(float) || resolvedType == typeof(float?);
                description.IsDouble = resolvedType == typeof(double) || resolvedType == typeof(double?);
                description.IsDecimal = resolvedType == typeof(decimal) || resolvedType == typeof(decimal?);
            }
            description.IsScalar = description.IsNullableValueType ?
                s_scalarTypes.Contains(nullableValueType) : s_scalarTypes.Contains(resolvedType);
            description.IsString = resolvedType == typeof(string);
            description.NonAssemblyQualifiedTypeName = resolvedType.FullName;
            description.IsDataContext = resolvedType.IsSubclassOf(typeof(System.Data.Linq.DataContext));
            if (description.IsGeneric)
            {
                description.GenericTypeDefinitionPartOfName = description.TypeName.Substring(0, description.TypeName.IndexOf('`'));
                foreach (var argType in resolvedType.GetGenericArguments())
                {
                    description.TypeParameters.Add(BuildTypeDescription(argType.AssemblyQualifiedName));
                }
                if (resolvedType.GetGenericTypeDefinition() == typeof(IEnumerable<>))
                    description.IsEnumerable = true;
                foreach (Type iface in resolvedType.GetInterfaces())
                {
                    if (iface.IsGenericType && iface.GetGenericTypeDefinition() == typeof(IEnumerable<>))
                        description.IsEnumerable = true;
                }
            }
        }

        public override bool Equals(TypeDescription ti1, TypeDescription ti2)
        {
            ReflectionBasedTypeDescription asRB1 = ti1 as ReflectionBasedTypeDescription;
            ReflectionBasedTypeDescription asRB2 = ti2 as ReflectionBasedTypeDescription;
            if (asRB1 != null && asRB2 != null)
                return asRB1.ResolvedType == asRB2.ResolvedType;
            else
                return ti1.TypeName == ti2.TypeName;
        }

        public override bool IsAssignableFrom(TypeDescription tdTo, TypeDescription tdFrom)
        {
            var retval = Equals(tdTo, tdFrom);
            if (!retval)
            {
                ReflectionBasedTypeDescription rbTo = tdTo as ReflectionBasedTypeDescription;
                ReflectionBasedTypeDescription rbFrom = tdFrom as ReflectionBasedTypeDescription;
                if (rbTo != null && rbFrom != null)
                {
                    retval = rbTo.ResolvedType.IsAssignableFrom(rbFrom.ResolvedType);
                }
            }
            return retval;
        }

        public override TypeDescription BuildQueryableOf(TypeDescription typeDescription)
        {
            var asRb = typeDescription as ReflectionBasedTypeDescription;
            if (asRb != null)
            {
                Type queryableOfNothing = typeof(IQueryable<>);
                Type queryableOfTD = queryableOfNothing.MakeGenericType(asRb.ResolvedType);
                ReflectionBasedTypeDescription td = new ReflectionBasedTypeDescription(this, queryableOfTD);
                FillTypeDescription(td, queryableOfTD);
                return td;
            }
            else
            {
                var descOfInt = BuildTypeDescription("System.Int32");
                Type queryable = typeof(IQueryable<int>);
                TypeDescription td = new TypeDescription();
                FillTypeDescription(td, queryable);
                td.TypeName = td.TypeName.Replace(descOfInt.TypeName, typeDescription.TypeName);
                td.TypeParameters.Clear();
                td.TypeParameters.Add(typeDescription);
                foreach (PropertyInfo pi in queryable.GetProperties())
                {
                    PropertyDescription pd = new PropertyDescription { Name = pi.Name };
                    ReflectionBasedTypeDescription desc = new ReflectionBasedTypeDescription(this, pi.PropertyType);
                    this.FillTypeDescription(desc, pi.PropertyType);
                    pd.TypeDescription = desc;
                    td.Properties.Add(pd);
                }
                return td;
            }
            
        }
        public override TypeDescription BuildEnumerableOf(TypeDescription typeDescription)
        {
            var asRb = typeDescription as ReflectionBasedTypeDescription;
            if (asRb != null)
            {
                Type queryableOfNothing = typeof(IEnumerable<>);
                Type queryableOfTD = queryableOfNothing.MakeGenericType(asRb.ResolvedType);
                ReflectionBasedTypeDescription td = new ReflectionBasedTypeDescription(this, queryableOfTD);
                FillTypeDescription(td, queryableOfTD);
                return td;
            }
            else
            {
                var descOfInt = BuildTypeDescription("System.Int32");
                Type queryable = typeof(IEnumerable<int>);
                TypeDescription td = new TypeDescription();
                FillTypeDescription(td, queryable);
                td.TypeName = td.TypeName.Replace(descOfInt.TypeName, typeDescription.TypeName);
                td.TypeParameters.Clear();
                td.TypeParameters.Add(typeDescription);
                foreach (PropertyInfo pi in queryable.GetProperties())
                {
                    PropertyDescription pd = new PropertyDescription { Name = pi.Name };
                    ReflectionBasedTypeDescription desc = new ReflectionBasedTypeDescription(this, pi.PropertyType);
                    this.FillTypeDescription(desc, pi.PropertyType);
                    pd.TypeDescription = desc;
                    td.Properties.Add(pd);
                }
                return td;
            }
        }

        public override TypeDescription BuildNullableOf(string typeName)
        {
            Type nullable = typeof(Nullable<>);
            Type t = ResolveType(typeName);
            nullable = nullable.MakeGenericType(t);
            var retval = new ReflectionBasedTypeDescription(this, nullable);
            FillTypeDescription(retval, nullable);
            return retval;
        }

        public override void ResetCache()
        {
            this.m_descriptionCache.Clear();
        }
    }
}
