﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Processing
{
    /// <summary>
    /// Provide a way to describe a type
    /// </summary>
    public class TypeDescription
    {
        public string CSharpShortTypeName
        {
            get 
            {
                Func<string, string> GetShortName = n => string.IsNullOrEmpty(n) ? "" : n.Split('.').Last();

                string csTypeName = this.NonAssemblyQualifiedTypeName;

                if (this.IsGeneric)
                {
                    StringBuilder typeBuilder = new StringBuilder();
                    typeBuilder.Append(GetShortName(this.GenericTypeDefinitionPartOfName));
                    typeBuilder.Append('<');
                    typeBuilder.Append(string.Join(",", this.TypeParameters.Select(p => p.CSharpShortTypeName).ToArray()));

                    typeBuilder.Append('>');
                    csTypeName = typeBuilder.ToString();
                }
                return GetShortName(csTypeName);
            }
        }

        public string CSharpTypeName
        {
            get
            {
                string csTypeName = this.NonAssemblyQualifiedTypeName;

                if (this.IsGeneric)
                {
                    StringBuilder typeBuilder = new StringBuilder();
                    typeBuilder.Append(this.GenericTypeDefinitionPartOfName);
                    typeBuilder.Append('<');
                    bool first = true;
                    foreach (var type in this.TypeParameters)
                    {
                        if (!first)
                            typeBuilder.Append(',');

                        typeBuilder.Append(type.CSharpTypeName);
                        first = false;
                    }
                    typeBuilder.Append('>');
                    csTypeName = typeBuilder.ToString();
                }
                return csTypeName;
            }
        }
        public string VBTypeName
        {
            get
            {
                string vbTypeName = this.NonAssemblyQualifiedTypeName;

                if (this.IsGeneric)
                {
                    StringBuilder typeBuilder = new StringBuilder();
                    typeBuilder.Append(this.GenericTypeDefinitionPartOfName);
                    typeBuilder.Append("(Of ");
                    bool first = true;
                    foreach (var type in this.TypeParameters)
                    {
                        if (!first)
                            typeBuilder.Append(',');

                        typeBuilder.Append(type.VBTypeName);
                        first = false;
                    }
                    typeBuilder.Append(')');
                    vbTypeName = typeBuilder.ToString();
                }
                return vbTypeName;
            }
        }
        public bool IsGroup { get; set; }
        public TypeDescription GroupKeyType { get; set; }
        public TypeDescription GroupValueType { get; set; }
        private string m_genericDefinitionPartOfName;

        /// <summary>
        /// For generic type, get or set the name of the generic type definition
        /// </summary>
        public string GenericTypeDefinitionPartOfName
        {
            get { return m_genericDefinitionPartOfName; }
            set { m_genericDefinitionPartOfName = value; }
        }

        private string m_nonAssemblyQualifiedTypeName;

        /// <summary>
        /// Get or set the full type name without assembly information (used by the formatters)
        /// </summary>
        public string NonAssemblyQualifiedTypeName
        {
            get { return m_nonAssemblyQualifiedTypeName; }
            set { m_nonAssemblyQualifiedTypeName = value; }
        }

        private bool m_isBoolean;

        /// <summary>
        /// Get or set a value indicating if the type is boolean
        /// </summary>
        public bool IsBoolean
        {
            get { return m_isBoolean; }
            set { m_isBoolean = value; }
        }

        public bool IsGenericTypeDefinition { get; set; }

        private bool m_isGeneric;

        /// <summary>
        /// Get or set a value indicating if the type is generic
        /// </summary>
        public bool IsGeneric
        {
            get { return m_isGeneric; }
            set { m_isGeneric = value; }
        }


        private String m_typeName;

        /// <summary>
        /// Get or set the type name (in a format that is comprehensible to the used TypeDescriptionBuilder)
        /// </summary>
        public String TypeName
        {
            get { return m_typeName; }
            set { m_typeName = value; }
        }

        private bool m_isEnumerable;

        /// <summary>
        /// Get or set a value indicating if the type is enumerable
        /// </summary>
        public bool IsEnumerable
        {
            get { return m_isEnumerable; }
            set { m_isEnumerable = value; }
        }



        private bool m_isScalar;

        /// <summary>
        /// Get or set a value indicating if the type is scalar
        /// </summary>
        public bool IsScalar
        {
            get { return m_isScalar; }
            set { m_isScalar = value; }
        }

        private bool m_isString;

        /// <summary>
        /// Get or set a value indicating if the type is string
        /// </summary>
        public bool IsString
        {
            get { return m_isString; }
            set { m_isString = value; }
        }
        private bool m_isNumeric;

        /// <summary>
        /// Get or set a value indicating if the type is numeric
        /// </summary>
        public bool IsNumeric
        {
            get { return m_isNumeric; }
            set { m_isNumeric = value; }
        }

        private bool m_isNullableValueType;

        /// <summary>
        /// Get or set a value indicating if the type is a nullable value type
        /// </summary>
        public bool IsNullableValueType
        {
            get { return m_isNullableValueType; }
            set { m_isNullableValueType = value; }
        }
        private bool m_isDataContext;

        /// <summary>
        /// Get or set a value indicating if the type is a Linq to SQL DataContext type
        /// </summary>
        public bool IsDataContext
        {
            get { return m_isDataContext; }
            set { m_isDataContext = value; }
        }


        private List<TypeDescription> m_typeParameters = new List<TypeDescription>();

        /// <summary>
        /// For a generic type, get the list of type parameters
        /// </summary>
        public List<TypeDescription> TypeParameters
        {
            get { return m_typeParameters; }
        }


        private List<PropertyDescription> m_properties = new List<PropertyDescription>();

        /// <summary>
        /// Get the list of properties
        /// </summary>
        public virtual List<PropertyDescription> Properties
        {
            get { return m_properties; }
        }
        private bool m_isAnonymous;

        public bool IsAnonymous
        {
            get { return m_isAnonymous; }
            set { m_isAnonymous = value; }
        }
        private bool m_isDateTime;

        public bool IsDateTime
        {
            get { return m_isDateTime; }
            set { m_isDateTime = value; }
        }

        public bool IsOrHasAnonymous
        {
            get
            {
                return CheckIsOrHasAnonymous(new List<TypeDescription>());
            }
        }

        private bool CheckIsOrHasAnonymous(List<TypeDescription> alreadyDone)
        {
            alreadyDone.Add(this);
            if (IsAnonymous)
                return true;
            foreach (var td in TypeParameters)
            {
                if (!alreadyDone.Contains(td))
                {
                    alreadyDone.Add(td);
                    if (td.CheckIsOrHasAnonymous(alreadyDone))
                        return true;
                }
            }
            foreach (var p in Properties)
            {
                if (p.TypeDescription != null&&!alreadyDone.Contains(p.TypeDescription))
                {
                    alreadyDone.Add(p.TypeDescription);
                    if (p.TypeDescription != null && p.TypeDescription.CheckIsOrHasAnonymous(alreadyDone))
                        return true;
                }
                
            }
            return false;
        }

        public bool IsByte { get; set; }
        public bool IsShort { get; set; }
        public bool IsInt { get; set; }
        public bool IsLong { get; set; }
        public bool IsFloat { get; set; }
        public bool IsDouble { get; set; }
        public bool IsDecimal { get; set; }

        /// <summary>
        /// Get a property description giving its name
        /// </summary>
        /// <param name="name">Name of the property</param>
        /// <returns></returns>
        public virtual PropertyDescription GetProperty(string name)
        {
            foreach (var p in m_properties)
            {
                if (p.Name == name)
                    return p;
            }
            return null;
        }

    }
}
