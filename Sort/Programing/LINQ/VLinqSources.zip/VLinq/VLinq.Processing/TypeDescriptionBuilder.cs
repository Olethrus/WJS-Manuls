﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace VLinq.Processing
{
    /// <summary>
    /// Base class of specific type description builders
    /// </summary>
    public abstract class TypeDescriptionBuilder
    {
        public abstract void ResetCache();
        /// <summary>
        /// Build a type description of queryable source of the specified type name
        /// </summary>
        /// <param name="typeName"></param>
        /// <returns></returns>
        public abstract TypeDescription BuildQueryableOf(TypeDescription typeDescription);

        /// <summary>
        /// Generates a TypeDescription for the result of a "group by" statement
        /// </summary>
        /// <param name="typeKey"></param>
        /// <param name="typeValue"></param>
        /// <returns></returns>
        public virtual TypeDescription BuildGroupOf(TypeDescription typeKey, TypeDescription typeValue)
        {
            var desc = new TypeDescription
            {
                GenericTypeDefinitionPartOfName = "System.Linq.IGrouping",
                GroupKeyType = typeKey,
                GroupValueType = typeValue,
                IsGroup = true,
                IsEnumerable=true,
                IsGeneric = true,
                NonAssemblyQualifiedTypeName = string.Format(CultureInfo.InvariantCulture,"System.Linq.IGrouping`2[{0},{1}]", typeKey.NonAssemblyQualifiedTypeName, typeValue.NonAssemblyQualifiedTypeName),
                TypeName = string.Format(CultureInfo.InvariantCulture, "System.Linq.IGrouping`2[{0},{1}]", typeKey.TypeName, typeValue.TypeName),
                TypeParameters = { typeKey, typeValue },
                Properties = { new PropertyDescription{Name = "Key", TypeDescription = typeKey }}
            };
            return desc;
        }

        /// <summary>
        /// Build a type description of enumerable source of the specified type name
        /// </summary>
        /// <param name="typeName"></param>
        /// <returns></returns>
        public abstract TypeDescription BuildEnumerableOf(TypeDescription typeDescription);

        /// <summary>
        /// Build a type description of a nullable version of the specified type name
        /// </summary>
        /// <param name="typeName"></param>
        /// <returns></returns>
        public abstract TypeDescription BuildNullableOf(string typeName);

        /// <summary>
        /// Build a type description giving its name
        /// </summary>
        /// <param name="typeName"></param>
        /// <returns></returns>
        public abstract TypeDescription BuildTypeDescription(string typeName);
        /// <summary>
        /// Compare two type descriptions
        /// </summary>
        /// <param name="ti1"></param>
        /// <param name="ti2"></param>
        /// <returns></returns>
        public abstract bool Equals(TypeDescription ti1, TypeDescription ti2);

        public abstract bool IsAssignableFrom(TypeDescription tdTo, TypeDescription tdFrom);
    }
}
