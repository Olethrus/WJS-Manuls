﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace VLinq.Processing
{
    public class VBQueryFormatter<TDescriptionBuilder> : VBQueryFormatterBase<TDescriptionBuilder> where TDescriptionBuilder : Processing.TypeDescriptionBuilder, new()
    {

        /// <summary>
        /// append to the string builder the return type of the query (space post-fixed)
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        private static void CreateReturnType(Query query, StringBuilder sbuilder)
        {
            sbuilder.Append((query.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription).VBTypeName + " ");
        }

        /// <summary>
        /// Generate the output type of the Mapped projection of the query
        /// 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        private static void CreateGeneratedType(Query query, StringBuilder sbuilder)
        {
            MappedProjection mp = query.Select as MappedProjection;

            sbuilder.AppendFormat("Public Class {0}\n", mp.OutputTypeName);

            foreach (ProjectionMapping mapping in mp.Mappings)
            {
                string type = (mapping.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription).VBTypeName;
                sbuilder.AppendFormat("\tPrivate m_{1} As {0}\n", type, mapping.OutputProperty);
                sbuilder.AppendFormat("\tPublic Property {1}() As  {0} \n", type, mapping.OutputProperty);
                sbuilder.AppendFormat("\t\tGet \n\t\t\tReturn m_{1}\n\t\tEnd Get\n\t\tSet(ByVal value As {0})\n\t\t\tm_{1} = value\n\t\tEnd Set\n", type, mapping.OutputProperty);
                sbuilder.Append("\tEnd Property\n");
                
            }

            sbuilder.Append("End Class\n\n");
        }

        /// <summary>
        /// Generate the type of a group part
        /// </summary>
        /// <param name="groupPart"></param>
        /// <param name="sbuilder"></param>
        private static void CreateGeneratedType(ComposedGroupPart groupPart, StringBuilder sbuilder)
        {
           

            sbuilder.AppendFormat("Public Class {0}\n", groupPart.TypeName);

            foreach (var entityRef in groupPart.EntityRefs)
            {
                string type = (entityRef.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription).VBTypeName;
                sbuilder.AppendFormat("\tPrivate m_{1} As {0}\n", type, entityRef.Name);
                sbuilder.AppendFormat("\tPublic Property {1}() As  {0} \n", type, entityRef.Name);
                sbuilder.AppendFormat("\t\tGet \n\t\t\tReturn m_{1}\n\t\tEnd Get\n\t\tSet(ByVal value As {0})\n\t\t\tm_{1} = value\n\t\tEnd Set\n", type, entityRef.Name);
                sbuilder.Append("\tEnd Property\n\n");

            }

            sbuilder.Append("End Class\n");
        }


        /// <summary>
        /// In case of compiled query,
        /// generates the output projection type (if needed) and the signature of the Compiled Query :
        ///  public static readonly Func&lt;DataContext, ... &gt; [QueryName] = CompiledQuery.Compile((context,...) => 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        /// <param name="paginated">indicates if the signature must contains parameters for pagination</param>
        private void CreateCompiledSignatureAndProjectionType(Query query, StringBuilder sbuilder, bool paginated)
        {

            if (query.Select is MappedProjection && (query.Select as MappedProjection).GenerateOutputType && !paginated)
                CreateGeneratedType(query, sbuilder);
            if (!paginated)
                CheckGroupByTypes(query, sbuilder);

            sbuilder.Append("Private Shared  ReadOnly  ");
            if (paginated)
            {
                sbuilder.Append(query.Name + "__implPaginated");
            }
            else
            {
                sbuilder.Append(query.Name+"__impl");
            }
            sbuilder.Append(" As Func(Of ");

            sbuilder.Append("System.Data.Linq.DataContext");

            foreach (DataSource ds in query.DataSources)
            {
                if (ds is ParameterSource)
                {

                    sbuilder.AppendFormat(", {0}", GetDataSourceMethodParameterType(ds));
                }
            }

            if (paginated)
            {
                sbuilder.Append(", Integer, Integer");
            }
            sbuilder.Append(",");
            CreateReturnType(query, sbuilder);
            sbuilder.Append(") ");
            
            sbuilder.Append("= CompiledQuery.Compile(Function");
            BuildQueryParameterList(query, sbuilder, paginated, false);
            sbuilder.Append(" ");
        }

        /// <summary>
        /// Check if a group part have a type to be generated
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        private void CheckGroupByTypes(Query query, StringBuilder sbuilder)
        {
            if (query.GroupBy != null)
            {
                var composedPart = query.GroupBy.Key as ComposedGroupPart;
                if (composedPart != null && composedPart.GenerateGroupPartType)
                    CreateGeneratedType(composedPart, sbuilder);
                composedPart = query.GroupBy.Value as ComposedGroupPart;
                if (composedPart != null && composedPart.GenerateGroupPartType)
                    CreateGeneratedType(composedPart, sbuilder);
            }
        }


        /// <summary>
        /// In case of a non-compiled querry,
        /// generates the output projection type (if needed) and the signature of the Compiled Query :
        ///  public static readonly Func&lt;DataContext, ... &gt; [QueryName] = CompiledQuery.Compile((context,...) => 
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        /// <param name="paginated"></param>
        private void CreateMethodSignatureAndProjectionType(Query query, StringBuilder sbuilder, bool paginated)
        {
            if (query.Select is MappedProjection && (query.Select as MappedProjection).GenerateOutputType && !paginated)

                CreateGeneratedType(query, sbuilder);
            if (!paginated)
                CheckGroupByTypes(query, sbuilder);
            sbuilder.Append("Public Shared Function ");
            sbuilder.Append(query.Name);
            BuildQueryParameterList(query, sbuilder, paginated,true);
            sbuilder.Append(" As ");
            CreateReturnType(query, sbuilder);
            sbuilder.AppendLine();
            
        }

        /// <summary>
        /// Create the list of parameters of the query (with DataContext)
        /// used in both compiled and non-compiled queries
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        /// <param name="paginated"></param>
        private void BuildQueryParameterList(Query query, StringBuilder sbuilder, bool paginated, bool withByVal)
        {
            sbuilder.Append("(");
            if (withByVal)
                sbuilder.Append("ByVal ");
            sbuilder.Append("context As System.Data.Linq.DataContext ");
            foreach (DataSource ds in query.DataSources)
            {
                if (ds is ParameterSource)
                {
                    sbuilder.Append(", ");
                    if (withByVal)
                        sbuilder.Append("ByVal ");
                    sbuilder.AppendFormat("{1} As {0}", GetDataSourceMethodParameterType(ds), GetDataSourceMethodParameterName(ds));
                }
            }
            if (paginated)
            {
                if(withByVal)
                    sbuilder.Append(",ByVal zeroBasedFirstRow As Integer,ByVal pageSize As Integer");
                else
                    sbuilder.Append(", zeroBasedFirstRow As Integer, pageSize As Integer");
            }
            sbuilder.Append(")");
        }


        /// <summary>
        /// Create the body and end of a compiled query (closes the parenthesis and add a semicolon)
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        /// <param name="paginated"></param>
        private void CreateCompiledBody(Query query, StringBuilder sbuilder, bool paginated)
        {
            CreateQuery(query, sbuilder, paginated);
            sbuilder.AppendLine(")");
        }


        /// <summary>
        /// Create the body of a method (open the accolade but don't close it
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        /// <param name="paginated"></param>
        private void CreateMethodBody(Query query, StringBuilder sbuilder, bool paginated)
        {
            sbuilder.AppendLine();

            sbuilder.Append("Return ");
            CreateQuery(query, sbuilder, paginated);
            sbuilder.AppendLine();
            sbuilder.AppendLine("End Function");
        }


        /// <summary>
        /// Root of the generation process
        /// </summary>
        /// <param name="query"></param>
        /// <returns></returns>
        protected override string BuildQueryOutput(Query query)
        {
            StringBuilder queryString = new StringBuilder();
            if (!query.Compiled)
                CreateQueryMethod(query, queryString);
            else
                CreateQueryCompiled(query, queryString);
            if (GeneratesMemberMethods)
            {
                CreateMemberMethods(query, queryString);
            }
            return queryString.ToString();
        }

        private void CreateMemberMethods(Query query, StringBuilder queryString)
        {
            queryString.Append("Public Function ");
            
            queryString.Append(query.Name);
            if (query.Compiled)
                queryString.Append("Inst");
            queryString.Append("(");
            bool first = true;
            foreach (var ps in query.DataSources.OfType<ParameterSource>())
            {
                if (first)
                    first = false;
                else
                    queryString.Append(", ");
                queryString.AppendFormat("ByVal {1} As {0}", GetDataSourceMethodParameterType(ps), GetDataSourceMethodParameterName(ps));
            }
            queryString.Append(")");
            queryString.Append(" As ");
            CreateReturnType(query, queryString);
            queryString.AppendLine();
            queryString.Append("Return ");
            queryString.Append(query.Name);
            queryString.Append("(Me");
            foreach (var ps in query.DataSources.OfType<ParameterSource>())
            {
                queryString.AppendFormat(", {0}", GetDataSourceMethodParameterName(ps));
            }
            queryString.AppendLine(")");
            queryString.AppendLine("End Function");

            if (query.GeneratePaginatedVersion)
            {

                queryString.Append("Public Function ");
                
                queryString.Append(query.Name);
                if (query.Compiled)
                    queryString.Append("Inst");
                queryString.Append("(");
                first = true;
                foreach (var ps in query.DataSources.OfType<ParameterSource>())
                {
                    if (first)
                        first = false;
                    else
                        queryString.Append(", ");
                    queryString.AppendFormat("ByVal {1} As {0}", GetDataSourceMethodParameterType(ps), GetDataSourceMethodParameterName(ps));
                }
                queryString.Append(",ByVal zeroBasedFirstRow As Int,ByVal pageSize As Int)");
                queryString.Append(" As ");
                CreateReturnType(query, queryString);
                queryString.AppendLine();
                queryString.Append("return ");

                queryString.Append(query.Name);
                if (query.Compiled)
                    queryString.Append("Paginated");
                queryString.Append("(Me");
                foreach (var ps in query.DataSources.OfType<ParameterSource>())
                {
                    queryString.AppendFormat(", {0}", GetDataSourceMethodParameterName(ps));
                }
                queryString.AppendLine(", zeroBasedFirstRow, pageSize)");
                queryString.AppendLine("End Function");
            }
        }
        public bool GeneratesMemberMethods { get; set; }
        /// <summary>
        /// Build a compiled query
        /// </summary>
        /// <param name="query"></param>
        /// <param name="queryString"></param>
        private void CreateQueryCompiled(Query query, StringBuilder queryString)
        {
            CreateCompiledSignatureAndProjectionType(query, queryString, false);
            queryString.AppendLine("_");
            CreateCompiledBody(query, queryString, false);

            queryString.Append("Public Shared Function ");
            
            queryString.Append(query.Name);
            BuildQueryParameterList(query, queryString, false,true);
            queryString.Append(" As ");
            CreateReturnType(query, queryString);

            queryString.AppendLine();
            
            queryString.Append("Return ");
            queryString.Append(query.Name);
            queryString.Append("__impl(context");
            foreach (var p in query.DataSources.OfType<ParameterSource>())
            {
                queryString.Append(", ");
                queryString.Append(p.Name);
            }
            queryString.AppendLine(")");
            queryString.AppendLine("End Function");

            if (query.GeneratePaginatedVersion)
            {
                CreateCompiledSignatureAndProjectionType(query, queryString, true);
                queryString.AppendLine("_");
                CreateCompiledBody(query, queryString, true);

                queryString.Append("Public Shared Function ");
                queryString.Append(query.Name);
                BuildQueryParameterList(query, queryString, true, true);
                queryString.Append(" As ");
                CreateReturnType(query, queryString);
                queryString.AppendLine();

                queryString.Append("Return ");
                queryString.Append(query.Name);
                queryString.Append("__implPaginated(context");
                foreach (var p in query.DataSources.OfType<ParameterSource>())
                {
                    queryString.Append(", ");
                    queryString.Append(p.Name);
                }
                queryString.AppendLine(", zeroBasedFirstRow, pageSize)");
                queryString.AppendLine("End Function");
            }
        }
        /// <summary>
        /// Build a non-compiled query
        /// </summary>
        /// <param name="query"></param>
        /// <param name="queryString"></param>
        private void CreateQueryMethod(Query query, StringBuilder queryString)
        {
            CreateMethodSignatureAndProjectionType(query, queryString, false);
            queryString.AppendLine();
            CreateMethodBody(query, queryString, false);
            if (query.GeneratePaginatedVersion)
            {
                CreateMethodSignatureAndProjectionType(query, queryString, true);
                queryString.AppendLine();
                CreateMethodBody(query, queryString, true);
            }
        }

        /// <summary>
        /// Not used in the current generation procces
        /// Keep here if we want to create a more general editor (ie: not taking a DataContext as parameter, but directly IQueryable)
        /// </summary>
        /// <param name="dataSource"></param>
        /// <returns></returns>
        private static string GetDataSourceMethodParameterName(DataSource dataSource)
        {
            if (dataSource is EntitySource)
                return dataSource.Name + "s";
            else
                return dataSource.Name;

        }


        /// <summary>
        /// Not used in the current generation procces
        /// Keep here if we want to create a more general editor (ie: not taking a DataContext as parameter, but directly IQueryable)
        /// </summary>
        /// <param name="dataSource"></param>
        /// <returns></returns>
        private static string GetDataSourceMethodParameterType(DataSource dataSource)
        {
            var descr = dataSource.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription;
            string vbTypeName = descr.VBTypeName;
            if (dataSource is EntitySource)
                vbTypeName = string.Format(CultureInfo.InvariantCulture, "System.Linq.IQueryable(Of {0})", vbTypeName);
            return vbTypeName;
        }
    }





}
