﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Globalization;

namespace VLinq.Processing
{
    public abstract class VBQueryFormatterBase<TDescriptionBuilder> : QueryFormatter<string, TDescriptionBuilder> where TDescriptionBuilder : Processing.TypeDescriptionBuilder, new()
    {
        /// <summary>
        /// Get the type name of a property, giving its property path (ie: "ProductName.Length") and its declaring type TypeDescription
        /// </summary>
        /// <param name="propertyPath"></param>
        /// <param name="description"></param>
        /// <returns></returns>
        protected string GetPropertyTypeName(string propertyPath, TypeDescription description)
        {
            description = GetPropertyDescription(propertyPath, description);
            if (description == null)
                return null;
            else
                return description.VBTypeName;
        }


        /// <summary>
        /// Apply a transform to a given value
        /// </summary>
        /// <param name="value"></param>
        /// <param name="transform"></param>
        /// <param name="finalbuilder"></param>
        protected void CreateTransformedValue(string value, Transform transform, StringBuilder finalbuilder)
        {
            ChangeTypeTransform ctt = null;
            CustomExpressionTransform cet = null;
            EntitySetTransform est = null;
            StringBuilder sbuilder = new StringBuilder();
            if (transform is ToStringTransform)
            {
                sbuilder.AppendFormat("{0}.ToString", value);

            }
            else if (null != (cet = transform as CustomExpressionTransform))
            {
                sbuilder.Append("(");
                sbuilder.AppendFormat(cet.ExpressionText,
                    value);

                sbuilder.Append(")");
            }
            else if (null != (ctt = transform as ChangeTypeTransform))
            {
                sbuilder.AppendFormat("(DirectCast( Convert.ChangeType({1}, GetType({0})),{0})",
                    (DescriptionBuilder.BuildTypeDescription(ctt.OutputTypeName) as TypeDescription).VBTypeName,
                    value);

            }
            else if (null != (est = transform as EntitySetTransform))
            {
                sbuilder.AppendFormat("{0}.{1}(", value, est.Operation);
                if (!string.IsNullOrEmpty(est.ProjectionProperty))
                    sbuilder.AppendFormat("Function(o)  (o.{0})", est.ProjectionProperty);
                sbuilder.Append(")");
            }
            if (!string.IsNullOrEmpty(transform.OutputProperty))
                sbuilder.AppendFormat(".{0}", transform.OutputProperty);
            if (transform.ChainedTransform != null)
            {
                var currentVal = sbuilder.ToString();
                sbuilder = new StringBuilder();
                CreateTransformedValue(currentVal, transform.ChainedTransform, sbuilder);

            }
            finalbuilder.Append(sbuilder.ToString());
        }


        /// <summary>
        /// Generates the order by statements
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        protected void CreateOrderClause(Query query, StringBuilder sbuilder)
        {
            if (query.OrderBy.Count > 0)
            {
                bool first = true;
                sbuilder.Append("Order By ");
                foreach (var orderEntry in query.OrderBy)
                {
                    if (!first)
                        sbuilder.Append(", ");
                    sbuilder.AppendFormat("{0} {1} _\n", string.IsNullOrEmpty(orderEntry.DataSourceProperty) ? orderEntry.DataSourceName : orderEntry.DataSourceName + "." + orderEntry.DataSourceProperty
                        , orderEntry.Descending ? "Descending" : string.Empty);
                    first = false;
                }
            }
        }


        /// <summary>
        /// If not null, render the output transform of the query
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        protected void CreateOutputGrouping(Query query, StringBuilder sbuilder)
        {
            if (string.IsNullOrEmpty(query.OutputTransform.ProjectionProperty))
                sbuilder.AppendFormat(".{0}()", query.OutputTransform.Operation);
            else
                sbuilder.AppendFormat(".{0}(Function(o)  (o.{1}))", query.OutputTransform.Operation, query.OutputTransform.ProjectionProperty);
        }


        /// <summary>
        /// render an operand 
        /// </summary>
        /// <param name="o"></param>
        /// <param name="sbuilder"></param>
        protected void CreateOperand(Query q, Operand o, StringBuilder sbuilder)
        {
            ConstantOperand co;
            DataSourceOperand dso;
            NumericOperationOperand noo;
            ConcatOperationOperand coo;
            MethodCallOperand mco;
            if (null != (dso = o as DataSourceOperand))
            {
                string dsoValue = string.IsNullOrEmpty(dso.DataSourceProperty) ? dso.DataSourceName : dso.DataSourceName + "." + dso.DataSourceProperty;
                if (q.GroupBy != null && q.GroupBy.GroupName == dso.DataSourceName)
                {
                    if (dso.DataSourceProperty != null && dso.DataSourceProperty.StartsWith("Key"))
                        dsoValue = string.Format(CultureInfo.InvariantCulture,"__groupKey{0}", dso.DataSourceProperty.Substring(3));
                }
                if (dso.Transform != null)
                {
                    CreateTransformedValue(dsoValue, dso.Transform, sbuilder);
                }
                else
                {
                    sbuilder.Append(dsoValue);
                    
                }

            }

            else if (null != (co = o as ConstantOperand))
            {
                if (co.ConstantValue == null)
                {
                    sbuilder.Append("Null");
                }
                else
                {
                    var descr = DescriptionBuilder.BuildTypeDescription(co.TypeName);
                    if (descr.IsString)
                        sbuilder.Append(string.Format(CultureInfo.InvariantCulture, "\"{0}\"", co.ConstantValue.ToString().Replace("\"", "\" & chr(34) & \"").Replace("\n", "\" & vbLf & \"").Replace("\r", "\" & vbCr & \"").Replace("\t", "\" & vbTab & \"")));
                    else if (descr.IsBoolean)
                    {
                        bool val = (bool)co.ConstantValue;
                        if (val)
                            sbuilder.Append("True");
                        else
                            sbuilder.Append("False");
                    }
                    else
                    {
                        sbuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}", co.ConstantValue);
                    }
                }
            }
            else if (null != (noo = o as NumericOperationOperand))
            {
                string separator = null;
                switch (noo.Operation)
                {
                    case NumericOperation.Divide:
                        separator = " / ";
                        break;
                    case NumericOperation.Minus:
                        separator = " - ";
                        break;
                    case NumericOperation.Modulo:
                        separator = " Mod ";
                        break;
                    case NumericOperation.Multiply:
                        separator = " * ";
                        break;
                    case NumericOperation.Plus:
                        separator = " + ";
                        break;
                }
                bool first = true;
                sbuilder.Append("(");
                foreach (var subOp in noo.Operands)
                {
                    if (first)
                        first = false;
                    else
                        sbuilder.Append(separator);

                    CreateOperand(q, subOp, sbuilder);
                }
                sbuilder.Append(")");
            }
            else if (null != (coo = o as ConcatOperationOperand))
            {
                bool first = true;
                sbuilder.Append("(");
                foreach (var subOp in coo.Operands)
                {
                    if (first)
                        first = false;
                    else
                        sbuilder.Append(" & ");

                    CreateOperand(q,subOp, sbuilder);
                }
                sbuilder.Append(")");
            }
            else if (null != (mco = o as MethodCallOperand))
            {
                if (mco.IsStaticMethod)
                {
                    sbuilder.Append(DescriptionBuilder.BuildTypeDescription(mco.CallerTypeName).VBTypeName);
                }
                else
                {
                    CreateOperand(q,mco.InstanceMethodCaller, sbuilder);
                }
                sbuilder.AppendFormat(".{0}(", mco.MethodName);
                bool first = true;
                foreach (var subOp in mco.MethodParameters)
                {
                    if (first)
                        first = false;
                    else
                        sbuilder.Append(", ");
                    CreateOperand(q,subOp, sbuilder);
                }
                sbuilder.Append(")");
            }

        }



        /// <summary>
        /// Render the where clause
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        protected void CreateWhereClause(Query query, StringBuilder sbuilder, int indentLevel)
        {
            WriteIndent(indentLevel, sbuilder);
            sbuilder.Append("Where ");
            CreateConstraint(query.Where, query, sbuilder);
        }

        protected void CreateHavingClause(Query query, StringBuilder sbuilder, int indentLevel)
        {
            WriteIndent(indentLevel, sbuilder);
            sbuilder.Append("\twhere ");
            CreateConstraint(query.Having, query, sbuilder);
        }


        /// <summary>
        /// Render the projection (branches to CreateDirectProjection or CreateMappendProjection)
        /// </summary>
        /// <param name="query"></param>
        /// <param name="sbuilder"></param>
        protected void CreateProjection(Query query, StringBuilder sbuilder, int indentLevel)
        {
            if (query.Select is DirectProjection)
            {
                CreateDirectProjection(sbuilder, query.Select as DirectProjection, query, indentLevel);
            }
            else
            {
                CreateMappedProjection(sbuilder, query.Select as MappedProjection, query, indentLevel);
            }
        }


        protected void CreateMappedProjection(StringBuilder sbuilder, MappedProjection mp, Query query, int indentLevel)
        {
            string type = mp.OutputTypeName;
            if (!mp.GenerateOutputType && !string.IsNullOrEmpty(mp.OutputTypeName))
            {
                var descr = DescriptionBuilder.BuildTypeDescription(type);
                type = descr.NonAssemblyQualifiedTypeName;
            }
            if (type.Length > 0)
            {
                WriteIndent(indentLevel, sbuilder);
                sbuilder.AppendFormat("Select New {0} With ", type);
                sbuilder.Append("{");
                bool first = true;
                foreach (ProjectionMapping mapping in mp.Mappings)
                {
                    if (!first)
                        sbuilder.Append(",");
                    first = false;
                    sbuilder.AppendFormat(".{0} = ", mapping.OutputProperty);
                    CreateOperand(query, mapping.Operand, sbuilder);
                }
                sbuilder.Append("})");
            }
            else
            {
                WriteIndent(indentLevel, sbuilder);
                sbuilder.Append("Select ");
                bool first = true;
                foreach (ProjectionMapping mapping in mp.Mappings)
                {
                    if (!first)
                        sbuilder.Append(",");
                    first = false;
                    sbuilder.AppendFormat(".{0} = ", mapping.OutputProperty);
                    CreateOperand(query, mapping.Operand, sbuilder);
                }
                sbuilder.Append(")");
            }
        }

        protected void CreateDirectProjection(StringBuilder sbuilder, DirectProjection dp, Query query, int indentLevel)
        {
            WriteIndent(indentLevel, sbuilder);
            sbuilder.Append("Select ");
            CreateOperand(query, dp.Operand, sbuilder);
            sbuilder.Append(")");
        }

        protected void CreateConstraint(Constraint constraint, Query query, StringBuilder sbuilder)
        {
            var loc = constraint as LogicalOperatorConstraint;
            var bc = constraint as ComparisonConstraint;

            if (loc != null && !loc.IsEmpty)
            {
                sbuilder.Append("(");
                bool first = true;
                foreach (Constraint c in loc.Constraints)
                {
                    if (!first)
                    {
                        if (loc.Operator == LogicalOperator.And)
                            sbuilder.Append(" AndAlso ");
                        else
                            sbuilder.Append(" OrElse ");
                    }
                    first = false;
                    CreateConstraint(c, query, sbuilder);
                }
                sbuilder.Append(")");
            }
            else if (bc != null)
            {
                sbuilder.Append("(");
                switch (bc.Operator)
                {
                    case Comparison.Contains:
                    case Comparison.EndsWith:
                    case Comparison.StartsWith:
                        CreateOperand(query, bc.Left, sbuilder);
                        sbuilder.AppendFormat(".{0}(", bc.Operator);
                        CreateOperand(query, bc.Right, sbuilder);
                        sbuilder.Append(")");
                        break;
                    case Comparison.NotContains:
                        sbuilder.Append("Not ");
                        CreateOperand(query,bc.Left, sbuilder);
                        sbuilder.Append(".Contains(");
                        CreateOperand(query, bc.Right, sbuilder);
                        sbuilder.Append(")");
                        break;
                    case Comparison.Equals:
                    case Comparison.Greater:
                    case Comparison.GreaterOrEquals:
                    case Comparison.Lower:
                    case Comparison.LowerOrEquals:
                    case Comparison.NotEquals:
                        CreateOperand(query, bc.Left, sbuilder);
                        string op = string.Empty;
                        switch (bc.Operator)
                        {
                            case Comparison.Equals:
                                op = "=";
                                break;
                            case Comparison.Greater:
                                op = ">";
                                break;
                            case Comparison.GreaterOrEquals:
                                op = ">=";
                                break;
                            case Comparison.Lower:
                                op = "<";
                                break;
                            case Comparison.LowerOrEquals:
                                op = "<=";
                                break;
                            case Comparison.NotEquals:
                                op = "<>";
                                break;
                        }
                        sbuilder.AppendFormat(" {0} ", op);
                        CreateOperand(query, bc.Right, sbuilder);
                        break;
                }
                sbuilder.Append(")");
            }


        }
        protected void WriteIndent(int indent, StringBuilder sbuilder)
        {
            for (int i = 0; i < indent; i++)
                sbuilder.Append("\t");
        }
        protected void CreateQuery(Query query, StringBuilder sbuilder, bool paginated)
        {
            CreateQuery(query, sbuilder, paginated, 1);
        }
        protected void CreateQuery(Query query, StringBuilder sbuilder, bool paginated, int indentLevel)
        {
            sbuilder.Append("(");
            int joinCount = 0;
            foreach (DataSource ds in query.DataSources)
            {
                ChildEntitySource ces;
                ChildQueryResultSource cqrs;
                EntitySource es;
                if (null != (cqrs = ds as ChildQueryResultSource))
                {
                    WriteIndent(indentLevel, sbuilder);
                    sbuilder.AppendFormat("Let {0} = ", cqrs.Name);
                    CreateQuery(cqrs.Query, sbuilder, false, indentLevel+1);
                    sbuilder.Append(" _\n");
                }
                else if (null != (ces = ds as ChildEntitySource))
                {
                    DataSource parent = query.FindDataSource(ces.ParentEntitySourceName);
                    WriteIndent(indentLevel, sbuilder);
                    sbuilder.AppendFormat("From {0} In {1}", ds.Name, parent.Name);
                    if (!string.IsNullOrEmpty(ces.ParentEntitySourceProperty))
                        sbuilder.Append("." + ces.ParentEntitySourceProperty);
                    sbuilder.Append(" _\n");
                }
                else if (null != (es = ds as EntitySource))
                {

                    WriteIndent(indentLevel, sbuilder);
                    var join = query.Joins.Where(j => j.RightEntitySource == ds.Name).SingleOrDefault();
                    if (join == null)
                    {
                        sbuilder.AppendFormat("From {0} In context.GetTable(Of {1})()  _\n", ds.Name, (es.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription).VBTypeName);
                    }
                    else
                    {
                        // TODO: Translate this generation to VB
                        var leftEntityTD = query.DataSources.Where(source => source.Name == join.LeftEntitySource).Select(source => ValidTimeProperties.GetReturnType(source)).Single();
                        var rightEntityTD = query.DataSources.Where(source => source.Name == join.RightEntitySource).Select(source => ValidTimeProperties.GetReturnType(source)).Single();

                        if (join.IsLeftOutter)
                        {
                            sbuilder.Append("Group ");
                        }
                        sbuilder.AppendFormat("Join {0} In context.GetTable(Of {1})() _\n", ds.Name, (es.GetValue(ValidTimeProperties.ReturnTypeProperty) as TypeDescription).VBTypeName);
                        WriteIndent(indentLevel + 1, sbuilder);
                        sbuilder.Append("On ");
                        if (join.LeftProperties.Count == 1)
                        {
                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}.{1}", join.LeftEntitySource, join.LeftProperties[0]);

                        }
                        else
                        {
                            sbuilder.Append("New With {");
                            for (int i = 0; i < join.LeftProperties.Count; i++)
                            {
                                var leftPropDesc = leftEntityTD.GetProperty(join.LeftProperties[i].Value);
                                var rightPropDesc = rightEntityTD.GetProperty(join.RightProperties[i].Value);

                                if (i > 0)
                                    sbuilder.Append(", ");
                                if (!leftPropDesc.TypeDescription.IsNullableValueType && rightPropDesc.TypeDescription.IsNullableValueType)
                                {
                                    sbuilder.AppendFormat(CultureInfo.InvariantCulture, ".part{0}=CType({1}.{2},{3})", i, join.LeftEntitySource, join.LeftProperties[i], rightPropDesc.TypeDescription.VBTypeName);
                                }
                                else
                                    sbuilder.AppendFormat(CultureInfo.InvariantCulture, ".part{0}={1}.{2}", i, join.LeftEntitySource, join.LeftProperties[i]);

                            }
                            sbuilder.Append("}");
                        }
                        sbuilder.Append(" Equals ");
                        if (join.LeftProperties.Count == 1)
                        {
                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, "{0}.{1}", join.RightEntitySource, join.RightProperties[0]);

                        }
                        else
                        {
                            sbuilder.Append("New With {");
                            for (int i = 0; i < join.LeftProperties.Count; i++)
                            {
                                var leftPropDesc = leftEntityTD.GetProperty(join.LeftProperties[i].Value);
                                var rightPropDesc = rightEntityTD.GetProperty(join.RightProperties[i].Value);

                                if (i > 0)
                                    sbuilder.Append(", ");
                                if (!rightPropDesc.TypeDescription.IsNullableValueType && leftPropDesc.TypeDescription.IsNullableValueType)
                                {
                                    sbuilder.AppendFormat(CultureInfo.InvariantCulture, "part{0}=CType({1}.{2},{3})", i, join.RightEntitySource, join.RightProperties[i], leftPropDesc.TypeDescription.VBTypeName);
                                }
                                else
                                    sbuilder.AppendFormat(CultureInfo.InvariantCulture, "part{0}={1}.{2}", i, join.RightEntitySource, join.RightProperties[i]);

                            }
                            sbuilder.Append("}");
                        }
                        if (join.IsLeftOutter)
                        {
                            joinCount++;
                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, " Into join{0} = Group _\n", joinCount);
                            WriteIndent(indentLevel + 1, sbuilder);

                            sbuilder.AppendFormat(CultureInfo.InvariantCulture, "From {0} in join{1}.DefaultIfEmpty() _\n", ds.Name, joinCount);

                        }
                        else
                        {
                            sbuilder.AppendLine(" _");
                        }
                    }
                }


            }
            if (query.Where != null
                && (!(query.Where is LogicalOperatorConstraint)
                     || !(query.Where as LogicalOperatorConstraint).IsEmpty)
                    )
            {
                CreateWhereClause(query, sbuilder,indentLevel+1);
                sbuilder.AppendLine(" _");
            }
            CreateOrderClause(query, sbuilder);
            if (query.GroupBy != null)
            {
                CreateGroupBy(query, query.GroupBy, sbuilder, indentLevel + 1);
                if (query.Having != null && (!(query.Having is LogicalOperatorConstraint)
                     || !(query.Having as LogicalOperatorConstraint).IsEmpty))
                {
                    CreateHavingClause(query, sbuilder, indentLevel + 1);
                }
            }
            CreateProjection(query, sbuilder, indentLevel + 1);
            if (query.OnlyDistinctRows)
                sbuilder.Append(".Distinct()");
            if (paginated)
                sbuilder.Append(".Skip(zeroBasedFirstRow).Take(pageSize)");
            if (query.OutputTransform != null)
            {
                CreateOutputGrouping(query, sbuilder);
            }
        }

        protected void CreateGroupPart(Query query,GroupPart part, StringBuilder sbuilder)
        {
            var simplePart = part as SimpleGroupPart;
            if (simplePart != null)
                CreateSimpleGroupPart(query,simplePart, sbuilder);
            else
                CreateComposedGroupPart(query,part as ComposedGroupPart, sbuilder);
        }
        protected void CreateSimpleGroupPart(Query query,SimpleGroupPart part, StringBuilder sbuilder)
        {
            //sbuilder.Append(part.EntityRef.DataSourceName);
            //if (!string.IsNullOrEmpty(part.EntityRef.DataSourceProperty))
            //{
            //    sbuilder.AppendFormat(".{0}", part.EntityRef.DataSourceProperty);
            //}
            CreateOperand(query,part.EntityRef, sbuilder);
        }

        protected void CreateComposedGroupPart(Query query, ComposedGroupPart part, StringBuilder sbuilder)
        {
            string type = ValidTimeProperties.GetReturnType(part).VBTypeName;
            
                sbuilder.AppendFormat("New {0} With ", type);
                sbuilder.Append("{");
                bool first = true;
                foreach (var entityRef in part.EntityRefs)
                {
                    if (!first)
                    {
                        sbuilder.Append(", ");

                    }
                    sbuilder.AppendFormat(".{0} ", entityRef.Name);
                    sbuilder.Append(" = ");
                    CreateOperand(query,entityRef.Operand, sbuilder);


                    first = false;

                }
                sbuilder.Append("}");

        }
        protected void CreateGroupBy(Query query,Group group, StringBuilder sbuilder,int indentLevel)
        {
            WriteIndent(indentLevel, sbuilder);
            sbuilder.Append("Group ");
            CreateGroupPart(query, group.Value, sbuilder);
            sbuilder.Append(" By __groupKey = ");
            CreateGroupPart(query, group.Key, sbuilder);
            sbuilder.Append(" Into ");
            sbuilder.Append(group.GroupName);
            sbuilder.Append(" = Group _\n");
        }

    }
}
