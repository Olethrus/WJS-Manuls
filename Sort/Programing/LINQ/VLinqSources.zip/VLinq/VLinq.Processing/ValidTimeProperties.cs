﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.ComponentModel;

namespace VLinq.Processing
{
    public  class ValidTimeProperties : DependencyObject
    {
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static readonly DependencyProperty IsValidProperty = DependencyProperty.RegisterAttached(
  "IsValid",
  typeof(Boolean),
  typeof(ValidTimeProperties),
  new PropertyMetadata(true)
);
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static void SetIsValid(DependencyObject element, Boolean value)
        {
            element.SetValue(IsValidProperty, value);
        }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static Boolean GetIsValid(DependencyObject element)
        {
            return (Boolean)element.GetValue(IsValidProperty);
        }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static readonly DependencyProperty ReturnTypeProperty = DependencyProperty.RegisterAttached("ReturnType", typeof(TypeDescription), typeof(ValidTimeProperties));
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static void SetReturnType(DependencyObject element, TypeDescription value)
        {
            element.SetValue(ReturnTypeProperty, value);
        }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static TypeDescription GetReturnType(DependencyObject element)
        {
            return (TypeDescription)element.GetValue(ReturnTypeProperty);
        }

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static readonly DependencyProperty ValidationErrorProperty = DependencyProperty.RegisterAttached("ValidationError", typeof(ValidationError), typeof(ValidTimeProperties));
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static void SetValidationError(DependencyObject element, ValidationError value)
        {
            element.SetValue(ValidationErrorProperty, value);
        }
        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static ValidationError GetValidationError(DependencyObject element)
        {
            return (ValidationError)element.GetValue(ValidationErrorProperty);
        }


        [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
        public static string[] GetGeneratedIdentifiers(DependencyObject obj)
        {
            return (string[])obj.GetValue(GeneratedIdentifiersProperty);
        }

        public static void SetGeneratedIdentifiers(DependencyObject obj, string[] value)
        {
            obj.SetValue(GeneratedIdentifiersProperty, value);
        }

        // Using a DependencyProperty as the backing store for GeneratedIdentifiers.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty GeneratedIdentifiersProperty =
            DependencyProperty.RegisterAttached("GeneratedIdentifiers", typeof(string[]), typeof(ValidTimeProperties), new PropertyMetadata());


    }
}
