﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq.Processing
{
    /// <summary>
    /// Represent a validation error (will be used by the designer to identify invalid query components)
    /// </summary>
    [Serializable]
    public class ValidationError
    {
        

        private ValidationErrorKind m_kind;

        /// <summary>
        /// Get or set the error kind
        /// </summary>
        public ValidationErrorKind Kind
        {
            get { return m_kind; }
            set { m_kind = value; }
        }

        private List<Constraint> m_constraints = new List<Constraint>();

        /// <summary>
        /// get or set the constraint involved in the error
        /// </summary>
        public List<Constraint> InvolvedConstraints
        {
            get { return m_constraints; }
        }

        private List<DataSource> m_involvedDataSources = new List<DataSource>();
        /// <summary>
        /// get or set the data source involved in the error
        /// </summary>
        public List<DataSource> InvolvedDataSources
        {
            get { return m_involvedDataSources; }
        }

        private List<Operand> m_involvedOperands = new List<Operand>();
        /// <summary>
        /// get or set the involved operand in the error
        /// </summary>
        public List<Operand> InvolvedOperands
        {
            get { return m_involvedOperands; }
        }

        private string m_message;
        /// <summary>
        /// get or set the message of the error
        /// </summary>
        public virtual string Message
        {
            get { return m_message; }
            set { m_message = value; }
        }
        
        private List<ProjectionMapping> m_involvedMappings = new List<ProjectionMapping>();
        /// <summary>
        /// Get or set the projection mapping involved in the error
        /// </summary>
        public List<ProjectionMapping> InvolvedMappings
        {
            get { return m_involvedMappings; }
        }

        private List<OrderEntry> m_involvedOrderEntries = new List<OrderEntry>();

        public List<OrderEntry> InvolvedOrderEntries
        {
            get { return m_involvedOrderEntries; }
        }
        private List<Transform> m_involvedTransforms = new List<Transform>();

        public List<Transform> InvolvedTransforms
        {
            get { return m_involvedTransforms; }
        }


        private ValidationResult m_childQueryValidationResult;

        public ValidationResult ChildQueryValidationResult
        {
            get { return m_childQueryValidationResult; }
            set { m_childQueryValidationResult = value; }
        }

        public DependencyObject ErrorSource { get; set; }
    }
}
