using System;
namespace VLinq.Processing
{
    public enum ValidationErrorKind
    {
        ParentDataSourceNotFound,
        InvalidParentDataSource,
        ParentDataSourcePropertyNotEnumerable,
        ParentDataSourcePropertyNotFound,
        InvalidDataSource,
        DataSourceNotFound,
        ProjectionNotSet,
        TypeResolution,
        DataSourcePropertyNotFound,
        TypeMismatch,
        OperandNotSet,
        InvalidBinaryConstraint,
        InvalidOutputGrouping,
        InvalidDataContext,
        UnsupportedFeature,
        InvalidOrderEntry,
        InvalidTransform,
        InvalidChildQuery,
        InvalidIdentifier,
        GroupingKeyNotSet,
        GroupingValueNotSet,
        InvalidGroupingKey,
        InvalidGroupingValue,
        MisorderedSources,
        JoinPartMissing,
        JoinPartsMismatch
    }
}