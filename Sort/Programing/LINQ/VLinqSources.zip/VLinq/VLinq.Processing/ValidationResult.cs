﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace VLinq.Processing
{
    /// <summary>
    /// Query validation summary
    /// </summary>
    [Serializable]
    public class ValidationResult : ValidationError
    {
        public ValidationResult()
        {
            m_errors = new List<ValidationError>();
        }
        private List<ValidationError> m_errors;

        public List<ValidationError> Errors
        {
            get { return m_errors; }
        }

        public bool Succeeded
        {
            get { return m_errors.Count == 0; }
        }
        public override string Message
        {
            get
            {
                return string.Join("\n", (from error in Errors
                                          select error.Message).ToArray());
            }
            set
            {
               
            }
        }
    }
}
