﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VLinq.Processing;
using Microsoft.VisualStudio.Shell;
using EnvDTE80;
using Microsoft.VisualStudio.Shell.Design;
using System.ComponentModel.Design;
using EnvDTE;
using System.Globalization;

namespace VLinq.VSIntegration
{
    public class DynamicTypeServiceDescriptionBuilder : ReflectionBasedTypeDescriptionBuilder
    {
        ITypeResolutionService m_trs;
        DTE m_dte;
        Project m_currentProject;
        public DynamicTypeServiceDescriptionBuilder()
        {
            m_dte = (DTE)Package.GetGlobalService(typeof(DTE));
            InitializeTypeResolver(m_dte);
            m_currentProject = m_dte.SelectedItems.Item(1).ProjectItem.ContainingProject;
        }
        public DynamicTypeServiceDescriptionBuilder(DTE serviceProvider)
        {
            InitializeTypeResolver(serviceProvider);
        }

        private void InitializeTypeResolver(DTE serviceProvider)
        {
            if (serviceProvider == null)
                throw new ArgumentNullException("serviceProvider");
            ServiceProvider provider = new ServiceProvider(serviceProvider as Microsoft.VisualStudio.OLE.Interop.IServiceProvider);
            var dts = (DynamicTypeService)provider.GetService(typeof(DynamicTypeService));
            if (dts == null)
                throw new NullReferenceException("The DynamicTypeService cannot be initialized");
            m_trs = dts.GetTypeResolutionService(VSHelpers.GetCurrentHierarchy(provider));
            if (m_trs == null)
                throw new NullReferenceException("The type resolution service cannot be initialized");
        }
        protected override Type ResolveType(string typeName)
        {

            typeName = new BracketScope(typeName).Resolve();
            var    type = m_trs.GetType(typeName);
           
            return type;
            
        }
        

        private class BracketScope
        {
            private string m_resolveString;
            public List<BracketScope> NestedScopes { get; set; }

            public BracketScope(string inner)
            {
                NestedScopes = new List<BracketScope>();
                m_resolveString = inner;

                
                while (m_resolveString.Contains('['))
                {
                    var openingIndex = m_resolveString.IndexOf('[');
                    var closing = -1;
                    var stacked = 0;
                    for (int i = openingIndex+1; i < m_resolveString.Length; i++)
                    {
                        if (m_resolveString[i] == '[')
                            stacked++;
                        else if (m_resolveString[i] == ']')
                        {
                            if (stacked > 0)
                                stacked--;
                            else
                            {
                                closing = i;
                                break;
                            }
                        }
                    }

                    if (closing == -1)
                        throw new InvalidOperationException("The input string is invalid");
                    // System.IDictionnary[[tut],[tot]]
                    // opening : 18
                    // closing : 30

                    // start : 18, length : 13

                    var nestedString = m_resolveString.Substring(openingIndex + 1, closing - openingIndex - 1);
                    m_resolveString = m_resolveString.Remove(openingIndex , closing - openingIndex + 1);
                    NestedScopes.Add(new BracketScope(nestedString));
                    m_resolveString = m_resolveString.Insert(openingIndex, "{" + (NestedScopes.Count-1).ToString(CultureInfo.InvariantCulture) + "}");
                }
                
            }
            public string Resolve()
            {
                var partsList =   m_resolveString.Split(',').ToList();
                var endList = new List<string>();
                for (int i = 0; i < partsList.Count; i++)
                {
                    if (i == 0 || partsList[i].Trim().StartsWith("{"))
                        endList.Add(partsList[i]);
                    
                }
                
                var result =  string.Join(",", endList.ToArray());
                for(int i=0; i< NestedScopes.Count;i++)
                {
                    result = result.Replace("{" + i.ToString(CultureInfo.InvariantCulture) + "}", "["+ NestedScopes[i].Resolve()+"]");
                }
                return result;
            }
        }
        public ITypeResolutionService TypeResolutionService
        {
            get { return m_trs; }
        }
    }
}
