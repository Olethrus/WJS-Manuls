﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Design;
using EnvDTE;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio.Shell.Design;
using Microsoft.VisualStudio.Shell.Interop;

namespace VLinq.VSIntegration
{
    public class TypeResolver
    {
        private Dictionary<string, List<string>> m_namespaces = new Dictionary<string, List<string>>();
        private Dictionary<string, List<Type>> m_namespacesTypes = new Dictionary<string, List<Type>>();
        private bool m_isDirty = true;
        ITypeDiscoveryService m_discoveryService;

        private object m_instanceSyncLock = new object();

        public Dictionary<string, List<string>> Namespaces
        {
            get
            {
                lock (m_instanceSyncLock)
                {
                    if (m_isDirty)
                    {
                        FillNamespacesAndTypes();
                    }
                }
                return m_namespaces;
            }
        }
        public Dictionary<string, List<Type>> NamespacesTypes
        {
            get
            {
                lock (m_instanceSyncLock)
                {
                    if (m_isDirty)
                        FillNamespacesAndTypes();
                }
                return m_namespacesTypes;
            }
        }
        private void FillNamespacesAndTypes()
        {

            m_namespaces.Clear();
            m_namespacesTypes.Clear();
            m_namespaces.Add(string.Empty, new List<string>());
            m_namespacesTypes.Add(string.Empty, new List<Type>());
            foreach (Type t in m_discoveryService.GetTypes(typeof(object), false))
            {
                HandleType(t);
                
                
            }
            //foreach (Type t in m_discoveryService.GetTypes(typeof(ValueType), false))
            //    HandleType(t);
            
            m_isDirty = false;
        }

        private void HandleType(Type t)
        {
            if (t.IsPublic && !t.IsGenericType && !t.IsGenericTypeDefinition)
            {
                if (t.Namespace != null && !m_namespaces.ContainsKey(t.Namespace))
                {
                    m_namespaces.Add(t.Namespace, new List<string>());
                    m_namespacesTypes.Add(t.Namespace, new List<Type> { t });

                    var ns = t.Namespace;
                    var lastNs = ns;
                    var lastDotIndex = -1;
                    do
                    {
                        lastDotIndex = ns.LastIndexOf(".");
                        if (lastDotIndex > -1)
                        {
                            ns = ns.Substring(0, lastDotIndex);
                            if (m_namespaces.ContainsKey(ns))
                            {
                                if (!m_namespaces[ns].Contains(lastNs))
                                    m_namespaces[ns].Add(lastNs);
                                break;
                            }
                            m_namespaces.Add(ns, new List<string> { lastNs });
                            m_namespacesTypes.Add(ns, new List<Type>());

                            lastNs = ns;
                        }
                        else if (!m_namespaces[string.Empty].Contains(ns))
                        {
                            m_namespaces[string.Empty].Add(ns);
                        }
                    }
                    while (lastDotIndex > -1);
                    m_namespacesTypes[t.Namespace].Add(t);
                }
                else if (t.Namespace == null)
                {
                    m_namespacesTypes[string.Empty].Add(t);
                }
                else
                {
                    m_namespacesTypes[t.Namespace].Add(t);
                }
            }
        }

        private TypeResolver(ITypeDiscoveryService tds)
        {
            m_discoveryService=tds;
            
        }

        //private static Dictionary<IVsHierarchy, TypeResolver> s_cachedResolvers = new Dictionary<IVsHierarchy, TypeResolver>();
        public static TypeResolver GetCurrentProjectTypeResolver()
        {
            DTE dte = (DTE)Package.GetGlobalService(typeof(DTE));
            if (dte == null)
                throw new ArgumentNullException("serviceProvider");
            ServiceProvider provider = new ServiceProvider(dte as Microsoft.VisualStudio.OLE.Interop.IServiceProvider);
            var hierarchy = VSHelpers.GetCurrentHierarchy(provider);
            //if (s_cachedResolvers.ContainsKey(hierarchy))
            //    return s_cachedResolvers[hierarchy];
            var dts = (DynamicTypeService)provider.GetService(typeof(DynamicTypeService));
            if (dts == null)
                throw new NullReferenceException("The DynamicTypeService cannot be initialized");
            var tds = dts.GetTypeDiscoveryService(hierarchy);
            
            if (tds == null)
                throw new NullReferenceException("The type resolution service cannot be initialized");
            var resolver = new TypeResolver(tds);
         //   s_cachedResolvers.Add(hierarchy, resolver);
            return resolver;
        }
        public static ITypeResolutionService GetCurrentProjectTypeResolutionService()
        {
            DTE dte = (DTE)Package.GetGlobalService(typeof(DTE));
            if (dte == null)
                throw new ArgumentNullException("serviceProvider");
            ServiceProvider provider = new ServiceProvider(dte as Microsoft.VisualStudio.OLE.Interop.IServiceProvider);
            var hierarchy = VSHelpers.GetCurrentHierarchy(provider);
            //if (s_cachedResolvers.ContainsKey(hierarchy))
            //    return s_cachedResolvers[hierarchy];
            return GetProjectTypeResolutionService(provider, hierarchy);
        }

        public static ITypeResolutionService GetProjectTypeResolutionService(ServiceProvider provider, IVsHierarchy hierarchy)
        {
            var dts = (DynamicTypeService)provider.GetService(typeof(DynamicTypeService));
            if (dts == null)
                throw new NullReferenceException("The DynamicTypeService cannot be initialized");
            var tds = dts.GetTypeResolutionService(hierarchy);

            if (tds == null)
                throw new NullReferenceException("The type resolution service cannot be initialized");
            return tds;
        }


    }
   
}
