﻿// Guids.cs
// MUST match guids.h
using System;

namespace Microsoft.VLinq_VSPackage
{
    static class GuidList
    {
        public const string guidVLinq_VSPackagePkgString = "1dcf0019-ef26-41f3-a5c2-8f835a7b1936";
        public const string guidVLinq_VSPackageCmdSetString = "d925cb83-b604-4e3e-b641-80935cdbbb22";
        public const string guidVLinq_VSPackageEditorFactoryString = "8e1f3924-3eb5-4e72-ab91-d91a1c5f772f";

        public static readonly Guid guidVLinq_VSPackagePkg = new Guid(guidVLinq_VSPackagePkgString);
        public static readonly Guid guidVLinq_VSPackageCmdSet = new Guid(guidVLinq_VSPackageCmdSetString);
        public static readonly Guid guidVLinq_VSPackageEditorFactory = new Guid(guidVLinq_VSPackageEditorFactoryString);
    };
}