﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;
using System.Windows.Media.Animation;
using System.Diagnostics;
using System.ComponentModel;

namespace VLinq.WPFControls
{
    [System.Windows.Markup.ContentProperty("Content")]
    public class AnimatedExpander : HeaderedContentControl
    {
        static AnimatedExpander()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(AnimatedExpander), new FrameworkPropertyMetadata(typeof(AnimatedExpander)));
            WidthProperty.OverrideMetadata(typeof(AnimatedExpander), new FrameworkPropertyMetadata(double.NaN));
            HorizontalAlignmentProperty.OverrideMetadata(typeof(AnimatedExpander), new FrameworkPropertyMetadata(HorizontalAlignment.Stretch));
            VerticalAlignmentProperty.OverrideMetadata(typeof(AnimatedExpander), new FrameworkPropertyMetadata(VerticalAlignment.Stretch));
        }

        



        public bool IsExpanded
        {
            get { return (bool)GetValue(IsExpandedProperty); }
            set { SetValue(IsExpandedProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IsExpanded.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IsExpandedProperty =
            DependencyProperty.Register("IsExpanded", typeof(bool), typeof(AnimatedExpander), new UIPropertyMetadata(false, OnIsExpandedChanged));

        private static void OnIsExpandedChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            AnimatedExpander elem = obj as AnimatedExpander;
            if (elem != null)
            {
                elem.OnIsExpandedChanged(args.OldValue == null ? default(bool) : (bool)args.OldValue, args.NewValue == null ? default(bool) : (bool)args.NewValue);
            }
        }
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            try
            {
                var container = Template.FindName("ContentContainer", this) as Panel;
                if (IsExpanded)
                {
                    container.Width = double.NaN;
                    container.Height = double.NaN;
                }
                else
                {
                    switch (ExpandDirection)
                    {
                        case ExpandDirection.Down:
                        case ExpandDirection.Up:
                            container.Height = 0;
                            break;
                        case ExpandDirection.Left:
                        case ExpandDirection.Right:
                            container.Width = 0;
                            break;
                    }
                }
            }
            catch
            {
                Debug.WriteLine("Control not already templated, or temlate has no content site or content container");
            }
            m_templated = true;
        }

        bool m_templated = false;
        protected virtual void OnIsExpandedChanged(bool oldValue, bool newValue)
        {
            if (!m_templated)
                return ;
            try
            {
                var container = Template.FindName("ContentContainer", this) as Panel;
                var content = Template.FindName("ContentSite", this) as ContentControl;
                DoubleAnimationUsingKeyFrames anim = null;
                if (newValue)
                {
                    //widthAnim.From = 0;
                    //widthAnim.To = content.ActualWidth;
                    //widthAnim.Duration = new Duration(TimeSpan.FromMilliseconds(500));
                    //widthAnim.FillBehavior = FillBehavior.Stop;
                    
                    //anim.From = 0;
                    double from = 0;
                    double to = 0;

                    content.Measure(new Size(container.MaxWidth, container.MaxHeight));
                    switch (ExpandDirection)
                    {
                        case ExpandDirection.Up:
                        case ExpandDirection.Down:
                            to = content.DesiredSize.Height;
                            break;
                        case ExpandDirection.Left:
                        case ExpandDirection.Right:
                            to = content.DesiredSize.Width;
                            break;
                    }
                    //anim.Duration = new Duration(TimeSpan.FromMilliseconds(300));
                    //anim.FillBehavior = FillBehavior.Stop;
                    anim =
                        WPFHelpers.CreateDeceleratingDoubleAnimation(
                            from, to, new KeySpline(0.1, 0.5, 0.1, 1), new Duration(TimeSpan.FromMilliseconds(1300)));

                    //widthAnim.Completed += delegate
                    //{
                    //    container.Width = double.NaN;
                    //};
                    anim.Completed += delegate
                    {
                        switch (ExpandDirection)
                        {
                            case ExpandDirection.Up:
                            case ExpandDirection.Down:
                                container.Height = double.NaN;
                                break;
                            case ExpandDirection.Left:
                            case ExpandDirection.Right:
                                container.Width = double.NaN;
                                break;
                                
                        }
                        InvalidateArrange();
                        InvalidateMeasure();
                        InvalidateVisual();
                    };
                    this.RaiseEvent(new RoutedEventArgs(ExpandedEvent));
                    //container.BeginAnimation(WidthProperty, widthAnim);
                }
                else
                {
                    //widthAnim.From = container.ActualWidth;
                    //widthAnim.To = 0;
                    //widthAnim.Duration = new Duration(TimeSpan.FromMilliseconds(500));
                    //widthAnim.FillBehavior = FillBehavior.Stop;
                    double from = 0;
                    double to = 0;

                    switch (ExpandDirection)
                    {
                        case ExpandDirection.Up:
                        case ExpandDirection.Down:
                            from = container.ActualHeight;
                            break;
                        case ExpandDirection.Left:
                        case ExpandDirection.Right:
                            from = container.ActualWidth;
                            break;
                    }
                    to = 0;
                    //anim.Duration = new Duration(TimeSpan.FromMilliseconds(300));
                    //anim.FillBehavior = FillBehavior.Stop;
                    anim =
                        WPFHelpers.CreateDeceleratingDoubleAnimation(
                            from, to, new KeySpline(0.1, 0.5, 0.1, 1), new Duration(TimeSpan.FromMilliseconds(1300)));

                    //widthAnim.Completed += delegate
                    //{
                    //    container.Width = 0;
                    //};
                    anim.Completed += delegate
                    {
                        switch (ExpandDirection)
                        {
                            case ExpandDirection.Up:
                            case ExpandDirection.Down:
                                container.Height = 0;
                                break;
                            case ExpandDirection.Left:
                            case ExpandDirection.Right:
                                container.Width = 0;
                                break;

                        }
                        InvalidateArrange();
                        InvalidateMeasure();
                        InvalidateVisual();
                    };
                    this.RaiseEvent(new RoutedEventArgs(CollapsedEvent));

                }
                switch (ExpandDirection)
                {
                    case ExpandDirection.Up:
                    case ExpandDirection.Down:
                        container.BeginAnimation(HeightProperty, anim);
                        break;
                    case ExpandDirection.Left:
                    case ExpandDirection.Right:
                        container.BeginAnimation(WidthProperty, anim);
                        break;
                }
            }
            catch
            {
                Debug.WriteLine("Control not already templated, or temlate has no content site or content container");
            }
        }




        public ExpandDirection ExpandDirection
        {
            get { return (ExpandDirection)GetValue(ExpandDirectionProperty); }
            set { SetValue(ExpandDirectionProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ExpandDirection.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ExpandDirectionProperty =
            DependencyProperty.Register("ExpandDirection", typeof(ExpandDirection), typeof(AnimatedExpander), new UIPropertyMetadata());


        public static readonly RoutedEvent ExpandedEvent = EventManager.RegisterRoutedEvent("Expanded", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(AnimatedExpander));
        public static readonly RoutedEvent CollapsedEvent = EventManager.RegisterRoutedEvent("Collapsed", RoutingStrategy.Direct, typeof(RoutedEventHandler), typeof(AnimatedExpander));

        public event RoutedEventHandler Expanded
        {
            add
            {
                this.AddHandler(ExpandedEvent, value);
            }
            remove
            {
                this.RemoveHandler(ExpandedEvent, value);
            }
        }

        public event RoutedEventHandler Collapsed
        {
            add
            {
                this.AddHandler(CollapsedEvent, value);
            }
            remove
            {
                this.RemoveHandler(CollapsedEvent, value);
            }
        }
    }
}
