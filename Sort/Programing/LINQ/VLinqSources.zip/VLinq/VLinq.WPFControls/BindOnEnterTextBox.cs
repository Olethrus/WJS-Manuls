﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;

namespace VLinq.WPFControls
{
    public class BindOnEnterTextBox : TextBox
    {
        protected override void OnKeyDown(System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == System.Windows.Input.Key.Enter)
            {
                var binding = GetBindingExpression(TextProperty);
                if (binding != null)
                {
                    binding.UpdateSource();
                    binding.UpdateTarget();
                }
                SelectAll();
            }
            else
                base.OnKeyDown(e);
        }
    }
}
