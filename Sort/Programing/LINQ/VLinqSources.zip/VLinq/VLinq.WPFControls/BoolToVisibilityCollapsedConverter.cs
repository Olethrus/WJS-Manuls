﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Globalization;
using System.Windows;

namespace VLinq.WPFControls
{
    public class NullToVisibilityCollapsedConverter : IValueConverter
    {
        private bool invertBoolean;

        // Methods
        public object Convert(object o, Type targetType, object parameter, CultureInfo culture)
        {
            Visibility collapsed = Visibility.Collapsed;
            if (Invert)
            {
                collapsed =  o == null? Visibility.Visible : Visibility.Collapsed;
            }
            else
                collapsed = o != null ? Visibility.Visible : Visibility.Collapsed;
            return collapsed;
        }

        public object ConvertBack(object o, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        // Properties
        public bool Invert
        {
            get
            {
                return this.invertBoolean;
            }
            set
            {
                this.invertBoolean = value;
            }
        }
    }
    public class BoolToVisibilityCollapsedConverter : IValueConverter
    {
        // Fields
        private bool invertBoolean;

        // Methods
        public object Convert(object o, Type targetType, object parameter, CultureInfo culture)
        {
            Visibility collapsed = Visibility.Collapsed;
            if (o is bool?)
            {
                bool? nullable = (bool?)o;
                if (nullable.Value ^ this.invertBoolean)
                {
                    collapsed = Visibility.Visible;
                }
                return collapsed;
            }
            if ((o is bool) && (((bool)o) ^ this.invertBoolean))
            {
                collapsed = Visibility.Visible;
            }
            return collapsed;
        }

        public object ConvertBack(object o, Type targetType, object parameter, CultureInfo culture)
        {
            Visibility visibility = (Visibility)o;
            return ((visibility == Visibility.Visible) ^ this.invertBoolean);
        }

        // Properties
        public bool InvertBoolean
        {
            get
            {
                return this.invertBoolean;
            }
            set
            {
                this.invertBoolean = value;
            }
        }
    }


}
