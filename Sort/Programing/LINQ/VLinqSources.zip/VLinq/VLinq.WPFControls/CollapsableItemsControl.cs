﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.Windows.Media.Animation;

namespace VLinq.WPFControls
{
    /// <summary>
    /// Follow steps 1a or 1b and then 2 to use this custom control in a XAML file.
    ///
    /// Step 1a) Using this custom control in a XAML file that exists in the current project.
    /// Add this XmlNamespace attribute to the root element of the markup file where it is 
    /// to be used:
    ///
    ///     xmlns:MyNamespace="clr-namespace:VLinq.WPFControls"
    ///
    ///
    /// Step 1b) Using this custom control in a XAML file that exists in a different project.
    /// Add this XmlNamespace attribute to the root element of the markup file where it is 
    /// to be used:
    ///
    ///     xmlns:MyNamespace="clr-namespace:VLinq.WPFControls;assembly=VLinq.WPFControls"
    ///
    /// You will also need to add a project reference from the project where the XAML file lives
    /// to this project and Rebuild to avoid compilation errors:
    ///
    ///     Right click on the target project in the Solution Explorer and
    ///     "Add Reference"->"Projects"->[Browse to and select this project]
    ///
    ///
    /// Step 2)
    /// Go ahead and use your control in the XAML file. Note that Intellisense in the
    /// XML editor does not currently work on custom controls and its child elements.
    ///
    ///     <MyNamespace:CollapsableItemsControl/>
    ///
    /// </summary>
    /// 
    [StyleTypedProperty(Property = "ItemContainerStyle", StyleTargetType = typeof(AnimatedExpander))]
    public class CollapsableItemsControl : ItemsControl
    {


        #region control state

        private ItemsPresenter m_itemsPresenter;
        private Panel m_itemsPanel;
        private Border m_sizeTester;
        protected Border SizeTester
        {
            get
            {
                if (m_sizeTester == null)
                {
                    try
                    {
                        m_sizeTester = Template.FindName("SizeTester", this) as Border;
                    }
                    catch
                    {
                        Debug.WriteLine("Control not already templated or template is invalid");
                    }
                }
                return m_sizeTester;
            }
        }
        protected ItemsPresenter ItemsPresenter
        {
            get
            {
                if (m_itemsPresenter == null)
                {
                    try
                    {
                        m_itemsPresenter = Template.FindName("itemsPresenter", this) as ItemsPresenter;
                    }
                    catch
                    {
                        Debug.WriteLine("Control not already templated or template is invalid");
                    }
                }
                return m_itemsPresenter;
            }
        }

        protected Panel Panel
        {
            get
            {
                if (m_itemsPanel == null)
                {
                    if (ItemsPresenter != null)
                    {
                        try
                        {
                            m_itemsPanel = ItemsPanel.FindName("itemsPanel", ItemsPresenter) as Panel;
                        }
                        catch
                        {
                            Debug.WriteLine("Control not already templated or template is invalid");
                        }
                    }
                }
                return m_itemsPanel;
            }
        }

        static CollapsableItemsControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CollapsableItemsControl), new FrameworkPropertyMetadata(typeof(CollapsableItemsControl)));
        }

        public CollapsableItemsControl()
        {
            this.Loaded += new RoutedEventHandler(CollapsableItemsControl_Loaded);
            
        }
        protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            base.OnPropertyChanged(e);
            if (e.Property == ActualWidthProperty || e.Property == ActualHeightProperty)
                ComputeMaxScrollValues();
        }

        void CollapsableItemsControl_Loaded(object sender, RoutedEventArgs e)
        {
            if (Panel != null && ItemsPresenter != null)
            {
                Panel.SizeChanged += PanelOrItemsControlSizeChanged;
                ItemsPresenter.SizeChanged += PanelOrItemsControlSizeChanged;
            }
        }

        void PanelOrItemsControlSizeChanged(object sender, SizeChangedEventArgs e)
        {
            ComputeMaxScrollValues();
            
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            var cornerMap = Template.FindName("CornerMap", this) as CornerMap;
            if(cornerMap!=null)
                cornerMap.MinimapRequested += new EventHandler(cornerMap_MinimapRequested);
        }

        void cornerMap_MinimapRequested(object sender, EventArgs e)
        {
            if (Panel != null)
            {
                ContentRectangle = new Rect(0, 0, Panel.ActualWidth, Panel.ActualHeight);
                
                    MinimapBrush = new VisualBrush(Panel);
            }
        }
        


        public Rect ContentRectangle
        {
            get { return (Rect)GetValue(ContentRectangleProperty); }
            set { SetValue(ContentRectangleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContentRectangle.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentRectangleProperty =
            DependencyProperty.Register("ContentRectangle", typeof(Rect), typeof(CollapsableItemsControl), new UIPropertyMetadata());




        public VisualBrush MinimapBrush
        {
            get { return (VisualBrush)GetValue(MinimapBrushProperty); }
            set { SetValue(MinimapBrushProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MinimapBrush.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MinimapBrushProperty =
            DependencyProperty.Register("MinimapBrush", typeof(VisualBrush), typeof(CollapsableItemsControl), new UIPropertyMetadata());





        public DataTemplate HeaderTemplate
        {
            get { return (DataTemplate)GetValue(HeaderTemplateProperty); }
            set { SetValue(HeaderTemplateProperty, value); }
        }
        public DataTemplateSelector HeaderTemplateSelector
        {
            get { return (DataTemplateSelector)GetValue(HeaderTemplateSelectorProperty); }
            set { SetValue(HeaderTemplateSelectorProperty, value); }
        }
        public DataTemplate ContentTemplate
        {
            get { return (DataTemplate)GetValue(ContentTemplateProperty); }
            set { SetValue(ContentTemplateProperty, value); }
        }
        public DataTemplateSelector ContentTemplateSelector
        {
            get { return (DataTemplateSelector)GetValue(ContentTemplateSelectorProperty); }
            set { SetValue(ContentTemplateSelectorProperty, value); }
        }

        public static DataTemplate GetHeaderTemplate(DependencyObject obj)
        {
            return (DataTemplate)obj.GetValue(HeaderTemplateProperty);
        }

        public static void SetHeaderTemplate(DependencyObject obj, DataTemplate value)
        {
            obj.SetValue(HeaderTemplateProperty, value);
        }

        // Using a DependencyProperty as the backing store for HeaderTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HeaderTemplateProperty =
            DependencyProperty.RegisterAttached("HeaderTemplate", typeof(DataTemplate), typeof(CollapsableItemsControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.Inherits));





        public static DataTemplate GetContentTemplate(DependencyObject obj)
        {
            return (DataTemplate)obj.GetValue(ContentTemplateProperty);
        }

        public static void SetContentTemplate(DependencyObject obj, DataTemplate value)
        {
            obj.SetValue(ContentTemplateProperty, value);
        }

        // Using a DependencyProperty as the backing store for ContentTemplate.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentTemplateProperty =
            DependencyProperty.RegisterAttached("ContentTemplate", typeof(DataTemplate), typeof(CollapsableItemsControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.Inherits));




        public static DataTemplateSelector GetHeaderTemplateSelector(DependencyObject obj)
        {
            return (DataTemplateSelector)obj.GetValue(HeaderTemplateSelectorProperty);
        }

        public static void SetHeaderTemplateSelector(DependencyObject obj, DataTemplateSelector value)
        {
            obj.SetValue(HeaderTemplateSelectorProperty, value);
        }

        // Using a DependencyProperty as the backing store for HeaderTemplateSelector.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HeaderTemplateSelectorProperty =
            DependencyProperty.RegisterAttached("HeaderTemplateSelector", typeof(DataTemplateSelector), typeof(CollapsableItemsControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.Inherits));



        public static DataTemplateSelector GetContentTemplateSelector(DependencyObject obj)
        {
            return (DataTemplateSelector)obj.GetValue(ContentTemplateSelectorProperty);
        }

        public static void SetContentTemplateSelector(DependencyObject obj, DataTemplateSelector value)
        {
            obj.SetValue(ContentTemplateSelectorProperty, value);
        }

        // Using a DependencyProperty as the backing store for ContentTemplateSelector.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentTemplateSelectorProperty =
            DependencyProperty.RegisterAttached("ContentTemplateSelector", typeof(DataTemplateSelector), typeof(CollapsableItemsControl), new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.Inherits));



        public double Zoom
        {
            get { return (double)GetValue(ZoomProperty); }
            set { SetValue(ZoomProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Zoom.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ZoomProperty =
            DependencyProperty.Register("Zoom", typeof(double), typeof(CollapsableItemsControl), new UIPropertyMetadata(1.0, OnZoomChanged));

        private static void OnZoomChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            CollapsableItemsControl elem = obj as CollapsableItemsControl;
            if (elem != null)
            {
                elem.OnZoomChanged(args.OldValue == null ? default(double) : (double)args.OldValue, args.NewValue == null ? default(double) : (double)args.NewValue);
            }
        }




        public double ScrollX
        {
            get { return (double)GetValue(ScrollXProperty); }
            set { SetValue(ScrollXProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ScrollX.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ScrollXProperty =
            DependencyProperty.Register("ScrollX", typeof(double), typeof(CollapsableItemsControl), new UIPropertyMetadata(0.0, OnScrollXChanged));

        private static void OnScrollXChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            CollapsableItemsControl elem = obj as CollapsableItemsControl;
            if (elem != null)
            {
                elem.OnScrollXChanged(args.OldValue == null ? default(double) : (double)args.OldValue, args.NewValue == null ? default(double) : (double)args.NewValue);
            }
        }




        public double ScrollY
        {
            get { return (double)GetValue(ScrollYProperty); }
            set { SetValue(ScrollYProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ScrollY.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ScrollYProperty =
            DependencyProperty.Register("ScrollY", typeof(double), typeof(CollapsableItemsControl), new UIPropertyMetadata(0.0, OnScrollYChanged));

        private static void OnScrollYChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            CollapsableItemsControl elem = obj as CollapsableItemsControl;
            if (elem != null)
            {
                elem.OnScrollYChanged(args.OldValue == null ? default(double) : (double)args.OldValue, args.NewValue == null ? default(double) : (double)args.NewValue);
            }
        }




        public double MaxScrollX
        {
            get { return (double)GetValue(MaxScrollXProperty); }
            set { SetValue(MaxScrollXProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MaxScrollX.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxScrollXProperty =
            DependencyProperty.Register("MaxScrollX", typeof(double), typeof(CollapsableItemsControl), new UIPropertyMetadata(0.0, OnMaxScrollXChanged));

        private static void OnMaxScrollXChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            CollapsableItemsControl elem = obj as CollapsableItemsControl;
            if (elem != null)
            {
                elem.OnMaxScrollXChanged(args.OldValue == null ? default(double) : (double)args.OldValue, args.NewValue == null ? default(double) : (double)args.NewValue);
            }
        }




        public double MaxScrollY
        {
            get { return (double)GetValue(MaxScrollYProperty); }
            set { SetValue(MaxScrollYProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MaxScrollY.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxScrollYProperty =
            DependencyProperty.Register("MaxScrollY", typeof(double), typeof(CollapsableItemsControl), new UIPropertyMetadata(0.0, OnMaxScrollYChanged));

        private static void OnMaxScrollYChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            CollapsableItemsControl elem = obj as CollapsableItemsControl;
            if (elem != null)
            {
                elem.OnMaxScrollYChanged(args.OldValue == null ? default(double) : (double)args.OldValue, args.NewValue == null ? default(double) : (double)args.NewValue);
            }
        }




        public ScaleTransform ContentScale
        {
            get { return (ScaleTransform)GetValue(ContentScaleProperty); }
            set { SetValue(ContentScaleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContentScale.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentScaleProperty =
            DependencyProperty.RegisterAttached("ContentScale", typeof(ScaleTransform), typeof(CollapsableItemsControl), new FrameworkPropertyMetadata(new ScaleTransform(1.0, 1.0), FrameworkPropertyMetadataOptions.Inherits));



        public TranslateTransform ContentXTranslation
        {
            get { return (TranslateTransform)GetValue(ContentXTranslationProperty); }
            set { SetValue(ContentXTranslationProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContentTranslation.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentXTranslationProperty =
            DependencyProperty.RegisterAttached("ContentXTranslation", typeof(TranslateTransform), typeof(CollapsableItemsControl), new FrameworkPropertyMetadata(new TranslateTransform(0.0, 0.0), FrameworkPropertyMetadataOptions.Inherits));



        public TranslateTransform ContentYTranslation
        {
            get { return (TranslateTransform)GetValue(ContentYTranslationProperty); }
            set { SetValue(ContentYTranslationProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContentYTranslation.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentYTranslationProperty =
            DependencyProperty.RegisterAttached("ContentYTranslation", typeof(TranslateTransform), typeof(CollapsableItemsControl), new FrameworkPropertyMetadata(new TranslateTransform(0.0, 0.0), FrameworkPropertyMetadataOptions.Inherits));




        #endregion

        #region control behavior

        public void HighlighElement(FrameworkElement visual)
        {
            var offset = visual.TransformToVisual(this);
            var upperLeft = offset.Transform(new Point(0, 0));
            var lowerRight = offset.Transform(new Point(visual.ActualWidth, visual.ActualHeight));



            var marginx = (ActualWidth - (visual.ActualWidth * Zoom)) / 2 + 10;
            var marginy = (ActualHeight - (visual.ActualHeight * Zoom)) / 2 + 10;

            var targetScrollX = upperLeft.X - marginx + ScrollX;
            var targetScrollY = upperLeft.Y - marginy + ScrollY;


            var scrollXAnim = new DoubleAnimation(ScrollX, targetScrollX > 0 ? targetScrollX : 0, new Duration(TimeSpan.FromMilliseconds(300)));
            var scrollYAnim = new DoubleAnimation(ScrollY, targetScrollY > 0 ? targetScrollY : 0, new Duration(TimeSpan.FromMilliseconds(300)));
            scrollXAnim.FillBehavior = FillBehavior.Stop;
            scrollYAnim.FillBehavior = FillBehavior.Stop;
            //if (animateZoom)
            //{
            //    var zoomAnim = new DoubleAnimation(Zoom,targetZoom, new Duration(TimeSpan.FromMilliseconds(300)));
            //    zoomAnim.FillBehavior = FillBehavior.Stop;
            //    zoomAnim.Completed += delegate
            //    {
            //        Zoom = targetZoom;
            //        m_zoomAffectScrolling = true;
            //    };
            //    this.BeginAnimation(ZoomProperty, zoomAnim);
            //}
            scrollXAnim.Completed += delegate
            {
                ScrollX = targetScrollX > 0 ? targetScrollX : 0;
            };
            scrollYAnim.Completed += delegate
            {
                ScrollY = targetScrollY > 0 ? targetScrollY : 0;
            };

            BeginAnimation(ScrollXProperty, scrollXAnim);
            BeginAnimation(ScrollYProperty, scrollYAnim);
            //var highlighter = Template.FindName("VisualHighlighter", this) as Rectangle;
            //if (highlighter != null)
            //{
            //    highlighter.Margin = new Thickness(upperLeft.X - 7, upperLeft.Y - 7, ActualWidth - lowerRight.X - 7, ActualHeight - lowerRight.Y - 7);

            //}
        }
        

        protected virtual void ComputeMaxScrollValues()
        {
            
            if (ItemsPresenter != null && ItemsPanel != null)
            {
                
                MaxScrollY = Panel.ActualHeight - SizeTester.ActualHeight;

                //var maxWidth = 0.0;
                //for (int i = 0; i < Items.Count; i++)
                //{
                //    var container = ItemContainerGenerator.ContainerFromIndex(i) as AnimatedExpander;
                //    var realContainer = container.Template.FindName("ContentSite", container) as FrameworkElement;

                //    maxWidth = realContainer.ActualWidth > maxWidth ? realContainer.ActualWidth : maxWidth;
                //}
                //Debug.WriteLine(maxWidth.ToString() + " - " + ItemsPresenter.ActualWidth.ToString());
                //MaxScrollX = maxWidth * Zoom - ItemsPresenter.ActualWidth;
                MaxScrollX = Panel.ActualWidth - SizeTester.ActualWidth;
            }
            
        }
        protected virtual void OnZoomChanged(double oldValue, double newValue)
        {
            if (newValue < 0.1)
                Zoom = 0.1;
            else
            {
                ContentScale = new ScaleTransform(newValue, newValue);
            }
        }
        
        protected virtual void OnScrollXChanged(double oldValue, double newValue)
        {
            if (newValue < 0.0)
                ScrollX = 0.0;
            else if (newValue > MaxScrollX)
                ScrollX = MaxScrollX;
            else
                ContentXTranslation = new TranslateTransform(-newValue, 0);
        }
        protected virtual void OnScrollYChanged(double oldValue, double newValue)
        {
            if (newValue < 0.0)
                ScrollY = 0.0;
            else if (newValue > MaxScrollY)
                ScrollY = MaxScrollY;
            else
                ContentYTranslation = new TranslateTransform(0, -newValue);
        }
        protected virtual void OnMaxScrollXChanged(double oldValue, double newValue)
        {
            if (newValue < 0.0)
                MaxScrollX = 0.0;
            else if (ScrollX > newValue)
                ScrollX = newValue;
        }
        protected virtual void OnMaxScrollYChanged(double oldValue, double newValue)
        {
            if (newValue < 0.0)
                MaxScrollY = 0.0;
            else if (ScrollY > newValue)
                ScrollY = newValue;
        }
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new AnimatedExpander { HeaderTemplate = HeaderTemplate, HeaderTemplateSelector = HeaderTemplateSelector, ContentTemplate = ContentTemplate, ContentTemplateSelector = ContentTemplateSelector };
        }

        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is AnimatedExpander;
        }

        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            var expander = element as AnimatedExpander;

            if (expander != null)
            {
                //expander.SetBinding(RenderTransformProperty, new Binding { Source = this, Path = new PropertyPath(ContentTranslationProperty) });
                //expander.SetBinding(LayoutTransformProperty, new Binding { Source = this, Path = new PropertyPath(ContentScaleProperty) });
                
                if (element != item)
                {

                    var hcc = item as HeaderedContentControl;
                    if (hcc != null)
                    {
                        expander.Header = hcc.Header;
                        expander.Content = hcc.Content;
                    }
                    else
                    {
                        expander.Content = item;
                    }
                }
            }
        }

        private bool m_panning = false;
        private Point m_lastPoint;
        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            if (e.MiddleButton == MouseButtonState.Pressed)
            {
                m_lastPoint = e.GetPosition(this);
                m_panning = true;
                CaptureMouse();
                e.Handled = true;
            }
            else
                e.Handled = false;
            base.OnPreviewMouseLeftButtonDown(e);
        }

        protected override void OnPreviewMouseUp(MouseButtonEventArgs e)
        {
            if (m_panning && e.MiddleButton == MouseButtonState.Released)
            {
                m_panning = false;
                ReleaseMouseCapture();
                e.Handled = true;
            }
            else
                e.Handled = false;
            base.OnMouseLeftButtonUp(e);
        }

        protected override void OnPreviewMouseMove(MouseEventArgs e)
        {
            if (m_panning)
            {
                var newPoint = e.GetPosition(this);
                ScrollX += m_lastPoint.X - newPoint.X;
                ScrollY += m_lastPoint.Y - newPoint.Y;
                m_lastPoint = newPoint;
                e.Handled = true;
            }
            else
                e.Handled = false;
            base.OnMouseMove(e);
        }
        
        protected override void  OnPreviewMouseWheel(MouseWheelEventArgs e)
        {
            if (Keyboard.Modifiers == ModifierKeys.Control)
            {
                var oldZoom = Zoom;
                Zoom += e.Delta / 2000.0;
                ScrollX = (ScrollX / oldZoom) * Zoom;
                ScrollY = (ScrollY / oldZoom) * Zoom;
            }
            else
            {
                ScrollY -= e.Delta / 3.0;
            }
            base.OnPreviewMouseWheel(e);
        }
        #endregion

    }
}
