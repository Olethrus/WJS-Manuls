﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq.WPFControls
{
    public class ContainerStyleWithItemTemplate
    {
        public DataTemplate ItemTemplate { get; set; }
        public Style ItemContainerStyle { get; set; }
        public Style ItemsControlStyle { get; set; }
    }
}
