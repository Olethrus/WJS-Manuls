﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Media.Animation;

namespace VLinq.WPFControls
{
    /// <summary>
    /// Follow steps 1a or 1b and then 2 to use this custom control in a XAML file.
    ///
    /// Step 1a) Using this custom control in a XAML file that exists in the current project.
    /// Add this XmlNamespace attribute to the root element of the markup file where it is 
    /// to be used:
    ///
    ///     xmlns:MyNamespace="clr-namespace:VLinq.WPFControls"
    ///
    ///
    /// Step 1b) Using this custom control in a XAML file that exists in a different project.
    /// Add this XmlNamespace attribute to the root element of the markup file where it is 
    /// to be used:
    ///
    ///     xmlns:MyNamespace="clr-namespace:VLinq.WPFControls;assembly=VLinq.WPFControls"
    ///
    /// You will also need to add a project reference from the project where the XAML file lives
    /// to this project and Rebuild to avoid compilation errors:
    ///
    ///     Right click on the target project in the Solution Explorer and
    ///     "Add Reference"->"Projects"->[Browse to and select this project]
    ///
    ///
    /// Step 2)
    /// Go ahead and use your control in the XAML file. Note that Intellisense in the
    /// XML editor does not currently work on custom controls and its child elements.
    ///
    ///     <MyNamespace:CornerMap/>
    ///
    /// </summary>
    public class CornerMap : Control
    {
        private Border m_mapView,m_sensibleCorner;
        private bool m_draggingRectangle = false;
        static CornerMap()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CornerMap), new FrameworkPropertyMetadata(typeof(CornerMap)));
        }
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            m_mapView = Template.FindName("MapView", this) as Border;
            m_sensibleCorner = Template.FindName("SensibleCorner", this) as Border;
            m_mapView.MouseDown += new MouseButtonEventHandler(m_mapView_MouseDown);
            m_mapView.MouseUp += new MouseButtonEventHandler(m_mapView_MouseUp);
            m_mapView.MouseMove += new MouseEventHandler(m_mapView_MouseMove);
        }


        public double IconWidth
        {
            get { return (double)GetValue(IconWidthProperty); }
            set { SetValue(IconWidthProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IconWidth.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IconWidthProperty =
            DependencyProperty.Register("IconWidth", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0));



        public double IconHeight
        {
            get { return (double)GetValue(IconHeightProperty); }
            set { SetValue(IconHeightProperty, value); }
        }

        // Using a DependencyProperty as the backing store for IconHeight.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IconHeightProperty =
            DependencyProperty.Register("IconHeight", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0));


        void m_mapView_MouseMove(object sender, MouseEventArgs e)
        {
            if (m_draggingRectangle)
            {
                var newPoint = e.GetPosition(this);
                var newScrollX = ScrollX + (newPoint.X - m_lastPoint.X)/m_minimapRatio;
                var newScrollY = ScrollY + (newPoint.Y - m_lastPoint.Y) / m_minimapRatio;
                if (newScrollX < 0)
                {
                    ScrollX = 0;
                    newPoint.X = m_lastPoint.X;
                }
                else if (newScrollX > MaxScrollX)
                {
                    ScrollX = MaxScrollX;
                    newPoint.X = m_lastPoint.X;
                }
                else
                {
                    ScrollX = newScrollX;
                }
                if (newScrollY < 0)
                {
                    ScrollY = 0;
                    newPoint.Y = m_lastPoint.Y;
                }
                else if (newScrollY > MaxScrollY)
                {
                    ScrollY = MaxScrollY;
                    newPoint.Y = m_lastPoint.Y;
                }
                else
                {
                    ScrollY = newScrollY;
                }
                m_lastPoint = newPoint;
            }
        }


        public double Zoom
        {
            get { return (double)GetValue(ZoomProperty); }
            set { SetValue(ZoomProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Zoom.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ZoomProperty =
            DependencyProperty.Register("Zoom", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0));


        void m_mapView_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (m_draggingRectangle)
            {
                m_draggingRectangle = false;
                m_mapView.ReleaseMouseCapture();
            }
        }

        void m_mapView_MouseDown(object sender, MouseButtonEventArgs e)
        {
            m_draggingRectangle = true;
            e.Handled = true;
            m_lastPoint = e.GetPosition(this);
            m_mapView.CaptureMouse();
        }

        Point m_lastPoint = new Point();

        public Size MinimapSize
        {
            get { return (Size)GetValue(MinimapSizeProperty); }
            set { SetValue(MinimapSizeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MinimapSize.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MinimapSizeProperty =
            DependencyProperty.Register("MinimapSize", typeof(Size), typeof(CornerMap), new UIPropertyMetadata(new Size(), OnComputeFocusMarginRequested));

        private static void OnComputeFocusMarginRequested(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var cornerMap = obj as CornerMap;
            if (cornerMap != null)
                cornerMap.ComputeFocusMargin();
        }
        public event EventHandler MinimapRequested;
        protected override void OnMouseEnter(MouseEventArgs e)
        {
            base.OnMouseEnter(e);
            if (m_mapView != null && m_sensibleCorner != null)
            {
                try
                {
                    if (MinimapRequested != null)
                        MinimapRequested(this, EventArgs.Empty);
                    var originalRatio = ContentOriginalRect.Width / ContentOriginalRect.Height;
                    var finalRatio = ViewportWidth / ViewportHeight;
                    var width = ViewportWidth * SizeFactor;
                    var height = ViewportHeight * SizeFactor;
                    if (finalRatio < originalRatio)
                    {
                        height = width / originalRatio;
                    }
                    else
                    {
                        width = height * originalRatio;
                    }
                    var widthAnim = new DoubleAnimation(width, new Duration(TimeSpan.FromMilliseconds(300)));
                    var heightAnim = new DoubleAnimation(height, new Duration(TimeSpan.FromMilliseconds(300)));
                    var opacityAnim = new DoubleAnimation(1.0, new Duration(TimeSpan.FromMilliseconds(300)));
                    m_mapView.BeginAnimation(Border.WidthProperty, widthAnim);
                    m_mapView.BeginAnimation(Border.HeightProperty, heightAnim);
                    m_mapView.BeginAnimation(Border.OpacityProperty, opacityAnim);
                    MinimapSize = new Size(width, height);
                }
                catch { }
            }
        }

        protected override void OnMouseLeave(MouseEventArgs e)
        {
            base.OnMouseLeave(e);
            if (m_mapView != null && m_sensibleCorner != null)
            {
                var widthAnim = new DoubleAnimation(m_sensibleCorner.ActualWidth, new Duration(TimeSpan.FromMilliseconds(300)));
                var heightAnim = new DoubleAnimation(m_sensibleCorner.ActualHeight, new Duration(TimeSpan.FromMilliseconds(300)));
                var opacityAnim = new DoubleAnimation(0.0, new Duration(TimeSpan.FromMilliseconds(300)));
                m_mapView.BeginAnimation(Border.WidthProperty, widthAnim);
                m_mapView.BeginAnimation(Border.HeightProperty, heightAnim);
                m_mapView.BeginAnimation(Border.OpacityProperty, opacityAnim);
            }
        }

        double m_minimapRatio = 0.0;
        private void ComputeFocusMargin()
        {
            var totalWidth = MaxScrollX + ViewportWidth;
            var totalHeight = MaxScrollY + ViewportHeight;

            var leftRatio = ScrollX / totalWidth;
            var rightRatio = (MaxScrollX - ScrollX) / totalWidth;

            var topRatio = ScrollY / totalHeight;
            var bottomRatio = (MaxScrollY - ScrollY) / totalHeight;
            m_minimapRatio = MinimapSize.Height / totalHeight;
            FocusMargin = new Thickness(leftRatio * MinimapSize.Width, topRatio * MinimapSize.Height, rightRatio * MinimapSize.Width, bottomRatio * MinimapSize.Height);

        }

        public Thickness FocusMargin
        {
            get { return (Thickness)GetValue(FocusMarginProperty); }
            set { SetValue(FocusMarginProperty, value); }
        }

        // Using a DependencyProperty as the backing store for FocusMargin.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty FocusMarginProperty =
            DependencyProperty.Register("FocusMargin", typeof(Thickness), typeof(CornerMap), new UIPropertyMetadata(new Thickness()));




        public double RectangleStroke
        {
            get { return (double)GetValue(RectangleStrokeProperty); }
            set { SetValue(RectangleStrokeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for RectangleStroke.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RectangleStrokeProperty =
            DependencyProperty.Register("RectangleStroke", typeof(double), typeof(CornerMap), new UIPropertyMetadata(2.0));




        public double ViewportWidth
        {
            get { return (double)GetValue(ViewportWidthProperty); }
            set { SetValue(ViewportWidthProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ViewportWidth.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ViewportWidthProperty =
            DependencyProperty.Register("ViewportWidth", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0, OnComputeFocusMarginRequested));



        public double ViewportHeight
        {
            get { return (double)GetValue(ViewportHeightProperty); }
            set { SetValue(ViewportHeightProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ViewPortHeight.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ViewportHeightProperty =
            DependencyProperty.Register("ViewportHeight", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0, OnComputeFocusMarginRequested));





        public double ScrollX
        {
            get { return (double)GetValue(ScrollXProperty); }
            set { SetValue(ScrollXProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ScrollX.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ScrollXProperty =
            DependencyProperty.Register("ScrollX", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0, OnComputeFocusMarginRequested));



        public double ScrollY
        {
            get { return (double)GetValue(ScrollYProperty); }
            set { SetValue(ScrollYProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ScrollY.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ScrollYProperty =
            DependencyProperty.Register("ScrollY", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0, OnComputeFocusMarginRequested));



        public double MaxScrollX
        {
            get { return (double)GetValue(MaxScrollXProperty); }
            set { SetValue(MaxScrollXProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MaxScrollX.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxScrollXProperty =
            DependencyProperty.Register("MaxScrollX", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0, OnComputeFocusMarginRequested));



        public double MaxScrollY
        {
            get { return (double)GetValue(MaxScrollYProperty); }
            set { SetValue(MaxScrollYProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MaxScrollY.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxScrollYProperty =
            DependencyProperty.Register("MaxScrollY", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.0, OnComputeFocusMarginRequested));



        public double SizeFactor
        {
            get { return (double)GetValue(SizeFactorProperty); }
            set { SetValue(SizeFactorProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SizeFactor.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SizeFactorProperty =
            DependencyProperty.Register("SizeFactor", typeof(double), typeof(CornerMap), new UIPropertyMetadata(0.5, OnComputeFocusMarginRequested));


        public Brush RectangleBorderBrush
        {
            get { return (Brush)GetValue(RectangleBorderBrushProperty); }
            set { SetValue(RectangleBorderBrushProperty, value); }
        }

        // Using a DependencyProperty as the backing store for RectangleBorderBrush.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RectangleBorderBrushProperty =
            DependencyProperty.Register("RectangleBorderBrush", typeof(Brush), typeof(CornerMap), new UIPropertyMetadata(new SolidColorBrush(Color.FromArgb(255,255,0,0))));



        public Brush MapViewBrush
        {
            get { return (Brush)GetValue(MapViewBrushProperty); }
            set { SetValue(MapViewBrushProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MapViewBrush.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MapViewBrushProperty =
            DependencyProperty.Register("MapViewBrush", typeof(Brush), typeof(CornerMap), new UIPropertyMetadata(new SolidColorBrush(Color.FromArgb(255, 255, 255, 255))));



        public Rect ContentOriginalRect
        {
            get { return (Rect)GetValue(ContentOriginalRectProperty); }
            set { SetValue(ContentOriginalRectProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContentOriginalRect.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentOriginalRectProperty =
            DependencyProperty.Register("ContentOriginalRect", typeof(Rect), typeof(CornerMap), new UIPropertyMetadata(new Rect(), OnComputeFocusMarginRequested));


    }
}
