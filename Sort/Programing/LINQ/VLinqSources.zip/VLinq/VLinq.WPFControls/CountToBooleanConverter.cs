﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Windows;
using System.Globalization;

namespace VLinq.WPFControls
{
    public class CountToVisibilityCollapsedConverter : IValueConverter
    {
        public bool InvertVisibility { get; set; }
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            int minimumValue = 1;
            if (parameter is int)
            {
                minimumValue = (int)parameter;
            }
            else if(parameter != null)
            {
                int tryValue;
                if (int.TryParse(parameter.ToString(), NumberStyles.Integer, CultureInfo.InvariantCulture, out tryValue))
                    minimumValue = tryValue;
            }
            if (!(value is int))
                return Visibility.Collapsed;
            int asInt = (int)value;
            if(InvertVisibility)
                return asInt < minimumValue ? Visibility.Visible : Visibility.Collapsed;
            else
                return asInt >= minimumValue ? Visibility.Visible : Visibility.Collapsed;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    public class CountToBooleanConverter : IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (!(value is int))
                return false;
            int asInt = (int)value;
            return asInt > 0;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
