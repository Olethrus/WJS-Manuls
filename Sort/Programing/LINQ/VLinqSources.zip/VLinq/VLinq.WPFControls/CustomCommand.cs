﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Windows;

namespace VLinq.WPFControls
{
    /// <summary>
    /// Custom WPF command, simplifying communication between Views and Controllers (buttons and menu items can be directly bound to commands)
    /// </summary>
    public class CustomCommand : FrameworkElement, ICommand
    {
        public CustomCommand()
        {
            IsEnabledChanged += new DependencyPropertyChangedEventHandler(CustomCommand_IsEnabledChanged);
            Visibility = Visibility.Collapsed;
        }

        void CustomCommand_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (CanExecuteChanged != null)
                CanExecuteChanged(this, EventArgs.Empty);
        }

        public event EventHandler Executing;

        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            return IsEnabled;
        }
        

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            if (Executing != null)
                Executing(this, EventArgs.Empty);
        }

        #endregion
    }
}
