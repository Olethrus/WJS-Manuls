﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Windows;

namespace VLinq.WPFControls
{
 /// <summary>
    /// Custom WPF command, simplifying communication between Views and Controllers (buttons and menu items can be directly bound to commands)
 /// </summary>
 /// <typeparam name="T">Type of the parameter of the command</typeparam>
    public class CustomParameterizedCommand<T> : FrameworkElement, ICommand
    {
        public event EventHandler<ParameterizedCommandEventArgs<T>> Executing;

        public CustomParameterizedCommand()
        {
            IsEnabledChanged += new DependencyPropertyChangedEventHandler(CustomParameterizedCommand_IsEnabledChanged);
            Visibility = Visibility.Collapsed;
        }

        void CustomParameterizedCommand_IsEnabledChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            if (CanExecuteChanged != null)
                CanExecuteChanged(this, EventArgs.Empty);
        }
        
       

        #region ICommand Members

        public bool CanExecute(object parameter)
        {
            if (parameter == null)
                return  IsEnabled;
            else
            {
                return IsEnabled && typeof(T).IsAssignableFrom(parameter.GetType());
            }
        }

        public event EventHandler CanExecuteChanged;

        public void Execute(object parameter)
        {
            if (Executing != null)
            {
                var args = new ParameterizedCommandEventArgs<T> { Parameter = (T)parameter };
                Executing(this, args);
            }
        }

        #endregion
    }
    public class ParameterizedCommandEventArgs<T> : EventArgs
    {
        private T m_parameter;

        public T Parameter
        {
            get { return m_parameter; }
            set { m_parameter = value; }
        }

    }
}
