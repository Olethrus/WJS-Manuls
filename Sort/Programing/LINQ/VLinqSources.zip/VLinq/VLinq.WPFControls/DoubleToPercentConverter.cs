﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;
using System.Globalization;

namespace VLinq.WPFControls
{
    public class DoubleToPercentConverter : IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null)
                return null;
            if (value is double)
            {
                var dVal = (double)value;
                var percentVal = dVal * 100;

                return string.Format(CultureInfo.InvariantCulture,"{0:0.##} %", percentVal);
            }
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value == null)
                return null;
            if (value is double)
            {
                return (double)value / 100;

            }
            else
            {
                string str = value.ToString();
                if (str.Contains('%'))
                    str = str.Replace("%", "").Trim();
                return double.Parse(str, CultureInfo.InvariantCulture) /100;
            }
        }

        #endregion
    }
}
