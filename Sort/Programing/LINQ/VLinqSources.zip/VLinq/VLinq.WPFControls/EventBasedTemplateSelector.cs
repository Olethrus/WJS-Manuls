﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows;

namespace VLinq.WPFControls
{
    public class EventBasedTemplateSelector : DataTemplateSelector
    {
        public override System.Windows.DataTemplate SelectTemplate(object item, System.Windows.DependencyObject container)
        {
            if (SelectingTemplate != null)
            {
                var args = new SelectTemplateEventArgs { Item = item, Container = container };
                SelectingTemplate(this, args);
                return args.Template;
            }
            return base.SelectTemplate(item, container);
        }
        public event EventHandler<SelectTemplateEventArgs> SelectingTemplate;
    }
    public class SelectTemplateEventArgs : EventArgs
    {
        public object Item { get; set; }
        public DependencyObject Container { get; set; }
        public DataTemplate Template { get; set; }
    }
}
