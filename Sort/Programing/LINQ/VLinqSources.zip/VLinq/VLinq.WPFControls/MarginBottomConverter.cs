﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows;
using System.Windows.Data;

namespace VLinq.WPFControls
{
    public class MarginBottomConverter : IValueConverter
    {  
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is double)
                return new Thickness(0, 0, 0, (double)value);
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
           
            if (value is Thickness)
            {
                return ((Thickness)value).Bottom;
            }
            return null;
        }

        #endregion

        
    }
    public class MarginRightConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is double)
                return new Thickness(0, 0, (double)value, 0);
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            if (value is Thickness)
            {
                return ((Thickness)value).Right;
            }
            return null;
        }

    }
    public class MarginLeftConverter : IValueConverter
    {

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is double)
                return new Thickness((double)value, 0, 0, 0);
            return null;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {

            if (value is Thickness)
            {
                return ((Thickness)value).Left;
            }
            return null;
        }

    }
}
