﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Collections.ObjectModel;
using System.Windows.Markup;
using System.Diagnostics;
using System.Windows.Media.Animation;

namespace VLinq.WPFControls
{
    /// <summary>
    /// Follow steps 1a or 1b and then 2 to use this custom control in a XAML file.
    ///
    /// Step 1a) Using this custom control in a XAML file that exists in the current project.
    /// Add this XmlNamespace attribute to the root element of the markup file where it is 
    /// to be used:
    ///
    ///     xmlns:MyNamespace="clr-namespace:VLinq.WPFControls"
    ///
    ///
    /// Step 1b) Using this custom control in a XAML file that exists in a different project.
    /// Add this XmlNamespace attribute to the root element of the markup file where it is 
    /// to be used:
    ///
    ///     xmlns:MyNamespace="clr-namespace:VLinq.WPFControls;assembly=VLinq.WPFControls"
    ///
    /// You will also need to add a project reference from the project where the XAML file lives
    /// to this project and Rebuild to avoid compilation errors:
    ///
    ///     Right click on the target project in the Solution Explorer and
    ///     "Add Reference"->"Projects"->[Browse to and select this project]
    ///
    ///
    /// Step 2)
    /// Go ahead and use your control in the XAML file. Note that Intellisense in the
    /// XML editor does not currently work on custom controls and its child elements.
    ///
    ///     <MyNamespace:MultiStepControl/>
    ///
    /// </summary>
    [StyleTypedProperty(Property="ItemContainerStyle",StyleTargetType=typeof(HeaderedContentControl))]
    public class MultiStepControl : ItemsControl
    {

        bool m_zoomAffectScrolling = true;
        public void HighlightElement(FrameworkElement visual)
        {
            var offset = visual.TransformToVisual(this);
            var upperLeft = offset.Transform(new Point(0, 0));
            var lowerRight = offset.Transform(new Point(visual.ActualWidth, visual.ActualHeight));

           

            var marginx = (ActualWidth - (visual.ActualWidth * Zoom)) / 2;
            var marginy = (ActualHeight - (visual.ActualHeight * Zoom)) / 2;

            var targetScrollX = upperLeft.X - marginx+ScrollX;
            var targetScrollY = upperLeft.Y - marginy+ScrollY;


            var scrollXAnim = new DoubleAnimation(ScrollX, targetScrollX > 0? targetScrollX:0, new Duration(TimeSpan.FromMilliseconds(300)));
            var scrollYAnim = new DoubleAnimation(ScrollY,targetScrollY>0? targetScrollY:0, new Duration(TimeSpan.FromMilliseconds(300)));
            scrollXAnim.FillBehavior = FillBehavior.Stop;
            scrollYAnim.FillBehavior = FillBehavior.Stop;
            //if (animateZoom)
            //{
            //    var zoomAnim = new DoubleAnimation(Zoom,targetZoom, new Duration(TimeSpan.FromMilliseconds(300)));
            //    zoomAnim.FillBehavior = FillBehavior.Stop;
            //    zoomAnim.Completed += delegate
            //    {
            //        Zoom = targetZoom;
            //        m_zoomAffectScrolling = true;
            //    };
            //    this.BeginAnimation(ZoomProperty, zoomAnim);
            //}
            scrollXAnim.Completed += delegate
            {
                ScrollX = targetScrollX > 0 ? targetScrollX : 0;
            };
            scrollYAnim.Completed += delegate
            {
                ScrollY = targetScrollY > 0 ? targetScrollY : 0;
            };

            BeginAnimation(ScrollXProperty, scrollXAnim);
            BeginAnimation(ScrollYProperty, scrollYAnim);
            //var highlighter = Template.FindName("VisualHighlighter", this) as Rectangle;
            //if (highlighter != null)
            //{
            //    highlighter.Margin = new Thickness(upperLeft.X - 7, upperLeft.Y - 7, ActualWidth - lowerRight.X - 7, ActualHeight - lowerRight.Y - 7);

            //}
        }
        bool m_resizeHandlerSet = false;

        private void SetResizeHandler()
        {
            var presenter = Template.FindName("itemsPresenter",this) as FrameworkElement;
            if (presenter != null && ItemsPanel != null)
            {
                try
                {
                    var panel = ItemsPanel.FindName("itemsPanel", presenter) as Panel;
                    panel.SizeChanged += delegate
                    {
                        UpdateMaxScrollY();
                        UpdateRealWidth();
                        ComputeMinimap();
                    };
                    m_resizeHandlerSet = true;
                }
                catch
                {
                    Debug.WriteLine("Not templated");
                }
            }
        }
        bool m_templated= false;
        protected override void AddChild(object value)
        {
            if (value is HeaderedContentControl)
                base.AddChild(value);
            else
                base.AddChild(new HeaderedContentControl { Content = value });
        }



        public static Rectangle GetRectangleForMinimap(DependencyObject obj)
        {
            return (Rectangle)obj.GetValue(RectangleForMinimapProperty);
        }

        public static void SetRectangleForMinimap(DependencyObject obj, Rectangle value)
        {
            obj.SetValue(RectangleForMinimapProperty, value);
        }

        // Using a DependencyProperty as the backing store for RectangleForMinimap.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty RectangleForMinimapProperty =
            DependencyProperty.RegisterAttached("RectangleForMinimap", typeof(Rectangle), typeof(MultiStepControl), new UIPropertyMetadata());

        

        private Canvas m_canvasForMinimap = new Canvas();
        private void ComputeMinimap()
        {
            if (m_templated)
            {
                if (!m_resizeHandlerSet)
                    SetResizeHandler();
                var itemsPresenter = (Template.FindName("itemsPresenter", this) as FrameworkElement);
                if (itemsPresenter != null)
                {
                    var itemsPanel = ItemsPanel.FindName("itemsPanel", itemsPresenter) as Panel;
                    if (itemsPanel != null)
                    {
                        double height=0.0, width=0.0;
                        foreach (HeaderedContentControl elem in itemsPanel.Children)
                        {
                            var contentSite = elem.Template.FindName("ContentSite", elem) as ContentControl;
                            if (contentSite != null)
                            {
                                var rect = GetRectangleForMinimap(contentSite);
                                if (rect == null)
                                {
                                    
                                    rect = new Rectangle {  Height = 0.0, Width = 0.0 };
                                    SetRectangleForMinimap(contentSite, rect);
                                    
                                    m_canvasForMinimap.Children.Add(rect);
                                    SetRectangleForMinimap(contentSite, rect);
                                    
                                }
                                

                                //rect.Width = contentSite.ActualWidth > rect.Width ? contentSite.ActualWidth : rect.Width;
                                //rect.Height = contentSite.ActualHeight > rect.Height ? contentSite.ActualHeight : rect.Height;
                                rect.Width = contentSite.ActualWidth;
                                rect.Height = contentSite.ActualHeight;
                                //rect.InvalidateArrange();
                                //rect.InvalidateMeasure();
                                //rect.InvalidateVisual();
                                var brush = new VisualBrush(VisualTreeHelper.GetChild( contentSite,0) as Visual);
                                brush.Stretch = Stretch.Fill;
                                brush.ViewboxUnits = BrushMappingMode.Absolute;
                                brush.Viewbox = new Rect(0, 0, rect.Width , rect.Height );
                                rect.Fill = brush;
                                rect.SetValue(Canvas.TopProperty, height);
                                height += contentSite.ActualHeight;
                                width = contentSite.ActualWidth > width ? contentSite.ActualWidth : width;
                               // panel.Children.Add(new Border { Height = contentSite.ActualHeight, Width = contentSite.ActualWidth, BorderThickness=new Thickness(2), BorderBrush=new SolidColorBrush(Color.FromArgb(255,255,0,0)), Background = new VisualBrush {   Stretch = Stretch.None, Visual = contentSite }, HorizontalAlignment = HorizontalAlignment.Stretch });

                            }
                        }
                        m_canvasForMinimap.Background = Brushes.White;
                        m_canvasForMinimap.Width = width;
                        m_canvasForMinimap.Height = height;
                        this.ContentRect = new Rect(new Size(width, height));
                        MapViewBrush = new VisualBrush { Visual = m_canvasForMinimap, Viewbox = ContentRect, ViewboxUnits=BrushMappingMode.Absolute };
                    }
                }
            }
        }
        
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();
            m_templated = Template != null;
            if (m_templated)
            {
                if (!m_resizeHandlerSet)
                    SetResizeHandler();
                var cornerMap = Template.FindName("CornerMap", this) as CornerMap;
                if (cornerMap != null)
                    cornerMap.MinimapRequested += delegate
                    {
                        ComputeMinimap();

                    };
                
                
                
            }
        }
        protected override void AddText(string text)
        {
            AddChild(new HeaderedContentControl { Content = text });
        }
        public void UpdateMaxScrollY()
        {
            if (m_templated)
            {
                if (!m_resizeHandlerSet)
                    SetResizeHandler();
                var itemsPresenter = (Template.FindName("itemsPresenter", this) as FrameworkElement);
                if (itemsPresenter != null)
                {
                    var itemsPanel = ItemsPanel.FindName("itemsPanel", itemsPresenter) as Panel;
                    if (itemsPanel != null)
                    {
                        var val = itemsPanel.ActualHeight - itemsPresenter.ActualHeight;
                        MaxScrollY = val >= 0 ? val : 0;
                    }
                }
            }
        }
        public void  UpdateRealWidth()
        {
            if (m_templated)
            {
                if (!m_resizeHandlerSet)
                    SetResizeHandler();
                var itemsPresenter = (Template.FindName("itemsPresenter", this) as FrameworkElement);
                if (itemsPresenter != null)
                {
                    var itemsPanel = ItemsPanel.FindName("itemsPanel", itemsPresenter) as Panel;
                    if (itemsPanel != null)
                    {
                        double currentMaxWidth = 0.0;
                        foreach (HeaderedContentControl child in Items)
                        {
                            //  var container = ContainerFromElement(child) as HeaderedContentControl;

                            var contentSite = child.Template.FindName("ContentSite", child) as Control;
                            if (contentSite != null)
                            {
                                var actualWidth = contentSite.ActualWidth;
                                var layoutTransform = contentSite.LayoutTransform as MatrixTransform;
                                if (layoutTransform != null)
                                {
                                    actualWidth *= layoutTransform.Matrix.M11;
                                }
                                currentMaxWidth = actualWidth > currentMaxWidth ? actualWidth : currentMaxWidth;
                            }
                        }


                        var val = currentMaxWidth + HeaderSize;


                        val -= itemsPanel.ActualWidth;
                        MaxScrollX = val > 0 ? val : 0;
                    }
                }
            }
        }





        public Rect ContentRect
        {
            get { return (Rect)GetValue(ContentRectProperty); }
            set { SetValue(ContentRectProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ContentRect.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentRectProperty =
            DependencyProperty.Register("ContentRect", typeof(Rect), typeof(MultiStepControl), new UIPropertyMetadata(new Rect()));




        public Brush MapViewBrush
        {
            get { return (Brush)GetValue(MapViewBrushProperty); }
            set { SetValue(MapViewBrushProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MapViewBrush.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MapViewBrushProperty =
            DependencyProperty.Register("MapViewBrush", typeof(Brush), typeof(MultiStepControl), new UIPropertyMetadata(new SolidColorBrush(Color.FromArgb(255,255,255,255))));


        public double MaxScrollY
        {
            get { return (double)GetValue(MaxScrollYProperty); }
            set { SetValue(MaxScrollYProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MaxScrollY.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxScrollYProperty =
            DependencyProperty.Register("MaxScrollY", typeof(double), typeof(MultiStepControl), new UIPropertyMetadata(0.0));

        public double MaxScrollX
        {
            get { return (double)GetValue(MaxScrollXProperty); }
            set { SetValue(MaxScrollXProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MaxScrollY.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MaxScrollXProperty =
            DependencyProperty.Register("MaxScrollX", typeof(double), typeof(MultiStepControl), new UIPropertyMetadata(0.0));


        protected override Size ArrangeOverride(Size arrangeBounds)
        {
            if (this.VisualChildrenCount > 0)
            {
                UIElement visualChild = (UIElement)this.GetVisualChild(0);
                if (visualChild != null)
                {
                    visualChild.Arrange(new Rect(arrangeBounds));
                }
            }
            
            
            UpdateRealWidth();
            UpdateMaxScrollY();
            ComputeMinimap();
            return arrangeBounds;
        }
        protected override void OnChildDesiredSizeChanged(UIElement child)
        {
            
            base.OnChildDesiredSizeChanged(child);
            
            UpdateRealWidth();
            UpdateMaxScrollY();
            ComputeMinimap();
        }
        protected override void ParentLayoutInvalidated(UIElement child)
        {
            base.ParentLayoutInvalidated(child);
            
            UpdateRealWidth();
            UpdateMaxScrollY();
            ComputeMinimap();
        }
        


        public double Zoom
        {
            get { return (double)GetValue(ZoomProperty); }
            set { SetValue(ZoomProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Zoom.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ZoomProperty =
            DependencyProperty.Register("Zoom", typeof(double), typeof(MultiStepControl), new UIPropertyMetadata(1.0,new PropertyChangedCallback(OnZoomChanged)));

        private static void OnZoomChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var ctl = obj as MultiStepControl;
            //var centerX = (ctl.RealWidth - ctl.HeaderSize)/2;
            
            double val = (double)args.NewValue;
            double oldVal = (double)args.OldValue;
            double oldXRatio = ctl.MaxScrollX == 0 ? 0 : ctl.ScrollX / ctl.MaxScrollX;
            double oldYRatio = ctl.MaxScrollY == 0 ? 0 : ctl.ScrollY / ctl.MaxScrollY;
            var layout = obj.GetValue(ContentLayoutTransformProperty) as MatrixTransform;
            var render = obj.GetValue(ContentRenderTransformProperty) as MatrixTransform;
            if (layout == null)
            {
                layout = new MatrixTransform();
            }
            if (render == null)
            {
                render = new MatrixTransform();
            }
            var newMatrix = new Matrix(layout.Matrix.M11,layout.Matrix.M12, layout.Matrix.M21, layout.Matrix.M22, layout.Matrix.OffsetX, layout.Matrix.OffsetY);
            newMatrix.M22 = val;
            newMatrix.M11 = val;
            obj.SetValue(ContentLayoutTransformProperty, new MatrixTransform(newMatrix));
            var a = (obj as MultiStepControl).MaxWidth;
            //newMatrix = new Matrix(render.Matrix.M11, render.Matrix.M12, render.Matrix.M21, render.Matrix.M22, render.Matrix.OffsetX, render.Matrix.OffsetY);
            //newMatrix.M11 = val;
            //obj.SetValue(ContentRenderTransformProperty, new MatrixTransform(newMatrix));

            ctl.InvalidateArrange();
            ctl.UpdateLayout();
            
            ctl.UpdateRealWidth();
            ctl.UpdateMaxScrollY();
            if ((-newMatrix.OffsetX) > ctl.MaxScrollX)
            {
                ctl.ScrollX = ctl.MaxScrollX > 0 ? ctl.MaxScrollX : 0;

            }
            else if(ctl.m_zoomAffectScrolling)
            {

                ctl.ScrollX = ctl.MaxScrollX * oldXRatio;
            }
            if ((-newMatrix.OffsetY) > ctl.MaxScrollY)
            {
                ctl.ScrollY = ctl.MaxScrollY > 0 ? ctl.MaxScrollY : 0;
            }
            else if (ctl.m_zoomAffectScrolling)
            {
                ctl.ScrollY = ctl.MaxScrollY * oldYRatio;
            }

            
            
        }


        public double ScrollX
        {
            get { return (double)GetValue(ScrollXProperty); }
            set { SetValue(ScrollXProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TranslateX.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ScrollXProperty =
            DependencyProperty.Register("ScrollX", typeof(double), typeof(MultiStepControl), new UIPropertyMetadata(0.0, new PropertyChangedCallback(OnTranslateXChanged)));
        
        private static void OnTranslateXChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var newVal = (double)args.NewValue;
            
            var ctl = obj as MultiStepControl;
            if (newVal < 0 || ctl.MaxScrollX <= 0)
            {
                ctl.ScrollX = 0;
                var render = obj.GetValue(ContentRenderTransformProperty) as MatrixTransform;
                if (render == null)
                {
                    render = new MatrixTransform();

                }
                var newMatrix = new Matrix(render.Matrix.M11, render.Matrix.M12, render.Matrix.M21, render.Matrix.M22, render.Matrix.OffsetX, render.Matrix.OffsetY);

                newMatrix.OffsetX = 0;
                obj.SetValue(ContentRenderTransformProperty, new MatrixTransform(newMatrix));
            }

            else if (ctl.MaxScrollX > 0 && ctl.MaxScrollX < newVal)
            {
                ctl.ScrollX = ctl.MaxScrollX;
            }
            else
            {
                var render = obj.GetValue(ContentRenderTransformProperty) as MatrixTransform;
                if (render == null)
                {
                    render = new MatrixTransform();

                    
                }
                var newMatrix = new Matrix(render.Matrix.M11,render.Matrix.M12, render.Matrix.M21, render.Matrix.M22,render.Matrix.OffsetX, render.Matrix.OffsetY);

                newMatrix.OffsetX = -newVal;
                obj.SetValue(ContentRenderTransformProperty, new MatrixTransform(newMatrix));
            }
                
        }



        public double ScrollY
        {
            get { return (double)GetValue(ScrollYProperty); }
            set { SetValue(ScrollYProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ScrollY.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ScrollYProperty =
            DependencyProperty.Register("ScrollY", typeof(double), typeof(MultiStepControl), new UIPropertyMetadata(0.0, new PropertyChangedCallback(OnScrollYChanged)));

        private static void OnScrollYChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            var newVal = (double)args.NewValue;
            var ctl = obj as MultiStepControl;

            if (newVal < 0 || ctl.MaxScrollY <= 0)
            {
                ctl.ScrollY = 0;
                

                obj.SetValue(ItemsPanelRenderTransformProperty, new TranslateTransform(0.0,0.0));
            }

            else if (ctl.MaxScrollY > 0 && ctl.MaxScrollY < newVal)
            {
                ctl.ScrollY = ctl.MaxScrollY;
            }
            else
            {

                obj.SetValue(ItemsPanelRenderTransformProperty, new TranslateTransform(0.0,-newVal));
            }
        }


      


      

        // Using a DependencyProperty as the backing store for ContentRenderTransform.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentRenderTransformProperty =
            DependencyProperty.Register("ContentRenderTransform", typeof(MatrixTransform), typeof(MultiStepControl));



        

        // Using a DependencyProperty as the backing store for ContentLayoutTransform.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ContentLayoutTransformProperty =
            DependencyProperty.Register("ContentLayoutTransform", typeof(MatrixTransform), typeof(MultiStepControl), new UIPropertyMetadata(MatrixTransform.Identity));





        // Using a DependencyProperty as the backing store for ItemsPanelRenderTransform.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ItemsPanelRenderTransformProperty =
            DependencyProperty.Register("ItemsPanelRenderTransform", typeof(TranslateTransform), typeof(MultiStepControl), new UIPropertyMetadata(new TranslateTransform()));




        protected override DependencyObject GetContainerForItemOverride()
        {
            return new HeaderedContentControl();
            
        }

       
        static MultiStepControl()
        {
            //This OverrideMetadata call tells the system that this element wants to provide a style that is different than its base class.
            //This style is defined in themes\generic.xaml
            DefaultStyleKeyProperty.OverrideMetadata(typeof(MultiStepControl), new FrameworkPropertyMetadata(typeof(MultiStepControl)));
            
        }

        public MultiStepControl()
        {
            this.PreviewMouseWheel += new MouseWheelEventHandler(MultiStepControl_MouseWheel);
            this.MouseDown += new MouseButtonEventHandler(MultiStepControl_MouseDown);
            this.MouseMove += new MouseEventHandler(MultiStepControl_MouseMove);
            this.MouseUp += new MouseButtonEventHandler(MultiStepControl_MouseUp);

            
            
        }

        void MultiStepControl_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (m_bIsPaning)
            { 
                m_bIsPaning = false;
                ReleaseMouseCapture();
                e.Handled = true;
            }
        }

        void MultiStepControl_MouseMove(object sender, MouseEventArgs e)
        {
            if (m_bIsPaning)
            {
                var newPos = e.GetPosition(this);
                this.ScrollX += m_lastPos.X - newPos.X;
                this.ScrollY += m_lastPos.Y - newPos.Y;
                m_lastPos = newPos;
                e.Handled = true;
            }
        }
        private bool m_bIsPaning;
        Point m_lastPos;
        void MultiStepControl_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                this.CaptureMouse();
                m_bIsPaning = true;
                m_lastPos = e.GetPosition(this);
                e.Handled = true;
            }
        }

        void MultiStepControl_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            this.Background = new SolidColorBrush(Color.FromArgb(0, 0, 0, 0));
            this.Zoom += e.Delta /2000.0;
            e.Handled = true;
        }



        public double HeaderSize
        {
            get { return (double)GetValue(HeaderSizeProperty); }
            set { SetValue(HeaderSizeProperty, value); }
        }

        // Using a DependencyProperty as the backing store for HeaderSize.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty HeaderSizeProperty =
            DependencyProperty.Register("HeaderSize", typeof(double), typeof(MultiStepControl), new UIPropertyMetadata(100.0));






       
    }
}
