﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;

namespace VLinq.WPFControls
{
    public class NonUIElementProxy<T> : UIElement
    {
        public NonUIElementProxy()
        {
        }
        public NonUIElementProxy(Action<T> propertyChangedHandler)
        {
            PropertyChanged = propertyChangedHandler;
        }

        public static DependencyProperty Property =
            DependencyProperty.Register("Property", typeof(T), typeof(NonUIElementProxy<T>),
                new PropertyMetadata(new PropertyChangedCallback(PropertyChangedCallback)));
        public static void PropertyChangedCallback(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var o = d as NonUIElementProxy<T>;
            o.OnPropertyChanged(d, e);
        }
        protected virtual void OnPropertyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            if (PropertyChanged != null)
                PropertyChanged((T) e.NewValue);
        }
        public event Action<T> PropertyChanged;
    }
}
