﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Diagnostics;
using System.ComponentModel;
using System.Collections.ObjectModel;
using System.Windows.Controls.Primitives;
using System.Globalization;

namespace VLinq.WPFControls
{
    /// <summary>
    /// Interaction logic for SuggestBox.xaml
    /// </summary>
    public partial class SuggestBox : UserControl
    {
        public event EventHandler TextCommited;
        public string Text
        {
            get { return (string)GetValue(TextProperty); }
            set { SetValue(TextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Text.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(SuggestBox), new UIPropertyMetadata(string.Empty, OnTextChanged));

        private static void OnTextChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            SuggestBox elem = obj as SuggestBox;
            if (elem != null)
            {
                elem.OnTextChanged(args.OldValue == null ? default(string) : (string)args.OldValue, args.NewValue == null ? default(string) : (string)args.NewValue);
            }
        }
        protected virtual void OnTextChanged(string oldValue, string newValue)
        {

            if (TextChanged != null)
                TextChanged(this, new DependencyPropertyChangedEventArgs(TextProperty, oldValue, newValue));
            UpdateSuggestionContext();
            UpdateSelectionByText();
            if (newValue != txtValue.Text)
                txtValue.Text = newValue;
        }



        public SuggestionResolverBase Resolver
        {
            get { return (SuggestionResolverBase)GetValue(ResolverProperty); }
            set { SetValue(ResolverProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Resolver.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ResolverProperty =
            DependencyProperty.Register("Resolver", typeof(SuggestionResolverBase), typeof(SuggestBox), new UIPropertyMetadata(null, OnResolverChanged));

        private static void OnResolverChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            SuggestBox elem = obj as SuggestBox;
            if (elem != null)
            {
                elem.OnResolverChanged(args.OldValue == null ? default(SuggestionResolverBase) : (SuggestionResolverBase)args.OldValue, args.NewValue == null ? default(SuggestionResolverBase) : (SuggestionResolverBase)args.NewValue);
            }
        }
        protected virtual void OnResolverChanged(SuggestionResolverBase oldValue, SuggestionResolverBase newValue)
        {
            if (oldValue != null)
                oldValue.SuggestBox = null;
            if (newValue != null)
                newValue.SuggestBox = this;
        }





        public int CaretIndex
        {
            get { return (int)GetValue(CaretIndexProperty); }
            set { SetValue(CaretIndexProperty, value); }
        }

        // Using a DependencyProperty as the backing store for CaretIndex.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty CaretIndexProperty =
            DependencyProperty.Register("CaretIndex", typeof(int), typeof(SuggestBox), new UIPropertyMetadata(0, OnCaretIndexChanged));

        private static void OnCaretIndexChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            SuggestBox elem = obj as SuggestBox;
            if (elem != null)
            {
                elem.OnCaretIndexChanged(args.OldValue == null ? default(int) : (int)args.OldValue, args.NewValue == null ? default(int) : (int)args.NewValue);
            }
        }
        protected virtual void OnCaretIndexChanged(int oldValue, int newValue)
        {
            if (CaretIndexChanged != null)
                CaretIndexChanged(this, new DependencyPropertyChangedEventArgs(CaretIndexProperty, oldValue, newValue));
            UpdateSuggestionContext();
            if (newValue != txtValue.CaretIndex)
                txtValue.CaretIndex = newValue;
        }

        public event DependencyPropertyChangedEventHandler CaretIndexChanged;



        public string SuggestionContext
        {
            get { return (string)GetValue(SuggestionContextProperty); }
            set { SetValue(SuggestionContextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for SuggestionContext.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SuggestionContextProperty =
            DependencyProperty.Register("SuggestionContext", typeof(string), typeof(SuggestBox), new UIPropertyMetadata(string.Empty, OnSuggestionContextChanged));

        private static void OnSuggestionContextChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            SuggestBox elem = obj as SuggestBox;
            if (elem != null)
            {
                elem.OnSuggestionContextChanged(args.OldValue == null ? default(string) : (string)args.OldValue, args.NewValue == null ? default(string) : (string)args.NewValue);
            }
        }
        protected virtual void OnSuggestionContextChanged(string oldValue, string newValue)
        {
            if (SuggestionContextChanged != null)
                SuggestionContextChanged(this, new DependencyPropertyChangedEventArgs(SuggestionContextProperty, oldValue, newValue));
        }

        public event DependencyPropertyChangedEventHandler SuggestionContextChanged;


        public event DependencyPropertyChangedEventHandler TextChanged;



        public bool ShowDropDownButton
        {
            get { return (bool)GetValue(ShowDropDownButtonProperty); }
            set { SetValue(ShowDropDownButtonProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ShowDropDownButton.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ShowDropDownButtonProperty =
            DependencyProperty.Register("ShowDropDownButton", typeof(bool), typeof(SuggestBox), new UIPropertyMetadata(false));





        public bool ShowingSuggestions
        {
            get { return (bool)GetValue(ShowingSuggestionsProperty); }
            set { SetValue(ShowingSuggestionsProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ShowingSuggestions.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ShowingSuggestionsProperty =
            DependencyProperty.Register("ShowingSuggestions", typeof(bool), typeof(SuggestBox), new UIPropertyMetadata(false, OnShowingSuggestionsChanged));

        private static void OnShowingSuggestionsChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            SuggestBox elem = obj as SuggestBox;
            if (elem != null)
            {
                elem.OnShowingSuggestionsChanged(args.OldValue == null ? default(bool) : (bool)args.OldValue, args.NewValue == null ? default(bool) : (bool)args.NewValue);
            }
        }
        protected virtual void OnShowingSuggestionsChanged(bool oldValue, bool newValue)
        {
            if (newValue)
            {
                if (SuggestionsRequested != null)
                    SuggestionsRequested(this, EventArgs.Empty);
                popup.PlacementTarget = txtValue;
                popup.Placement = System.Windows.Controls.Primitives.PlacementMode.Bottom;
                
                popup.IsOpen = true;
                if (lstSuggestions.Items.Count == 0)
                    ShowingSuggestions = false;
            }
            else
            {
                popup.IsOpen = false;
            }
        }

        public event EventHandler SuggestionsRequested;
        
        
        protected override void OnPreviewKeyDown(KeyEventArgs e)
        {
            if (e.Key == Key.Space && Keyboard.Modifiers == ModifierKeys.Control)
            {
                e.Handled = true;
                ShowingSuggestions = true;
            }
            else if (e.Key == Key.Enter && ShowingSuggestions)
            {
                var item = lstSuggestions.SelectedItem as Suggestion;
                if (item != null)
                {
                    this.Text = item.GeneratedText;
                    txtValue.CaretIndex = item.CaretPosition;
                }
                ShowingSuggestions = false;
                if (Text.EndsWith(".") || Text.EndsWith("("))
                    ShowingSuggestions = true;
                e.Handled = true;
                if (TextCommited != null)
                    TextCommited(this, EventArgs.Empty);
            }
            else if (e.Key == Key.Down && ShowingSuggestions && lstSuggestions.Items.Count > 0)
            {
                var newIndex = lstSuggestions.SelectedIndex + 1;
                if (newIndex < 0)
                    newIndex = 0;
                else if (newIndex >= lstSuggestions.Items.Count)
                {
                    newIndex = lstSuggestions.Items.Count - 1;
                }
                lstSuggestions.SelectedIndex = newIndex;
                e.Handled = true;
            }
            else if (e.Key == Key.Up && ShowingSuggestions && lstSuggestions.Items.Count > 0)
            {
                var newIndex = lstSuggestions.SelectedIndex - 1;
                if (newIndex < 0)
                    newIndex = 0;
                else if (newIndex >= lstSuggestions.Items.Count)
                {
                    newIndex = lstSuggestions.Items.Count - 1;
                }
                lstSuggestions.SelectedIndex = newIndex;
                e.Handled = true;
            }
            else if (e.Key == Key.Escape && ShowingSuggestions)
            {
                ShowingSuggestions = false;
                e.Handled = true;
            }
            
            base.OnPreviewKeyDown(e);
        }


        ICollectionView m_suggestionsView;



        public string WatermarkText
        {
            get { return (string)GetValue(WatermarkTextProperty); }
            set { SetValue(WatermarkTextProperty, value); }
        }

        // Using a DependencyProperty as the backing store for WatermarkText.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty WatermarkTextProperty =
            DependencyProperty.Register("WatermarkText", typeof(string), typeof(SuggestBox), new UIPropertyMetadata("< edit >"));



        public bool ShowWaterMark
        {
            get { return (bool)GetValue(ShowWaterMarkProperty); }
            set { SetValue(ShowWaterMarkProperty, value); }
        }

        // Using a DependencyProperty as the backing store for ShowWaterMark.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ShowWaterMarkProperty =
            DependencyProperty.Register("ShowWaterMark", typeof(bool), typeof(SuggestBox), new UIPropertyMetadata(true));
        

        public SuggestBox()
        {
            InitializeComponent();
            SetValue(SuggestionsProperty, new ObservableCollection<Suggestion>());
            m_suggestionsView = CollectionViewSource.GetDefaultView(Suggestions);
            m_suggestionsView.SortDescriptions.Add( new SortDescription { Direction = ListSortDirection.Ascending, PropertyName = "Label" } );
            Suggestions.CollectionChanged += new System.Collections.Specialized.NotifyCollectionChangedEventHandler(Suggestions_CollectionChanged);
            lstSuggestions.SelectionChanged += new SelectionChangedEventHandler(lstSuggestions_SelectionChanged);

            txtValue.PreviewMouseLeftButtonDown += delegate(object sender, MouseButtonEventArgs mea)
            {
                var listItem = this.FindFirstVisualAncestorOf<ListBoxItem>();
                if (listItem != null)
                {
                    listItem.RaiseEvent(new MouseButtonEventArgs(mea.MouseDevice, mea.Timestamp, mea.ChangedButton) { RoutedEvent = ListBoxItem.MouseLeftButtonDownEvent });
                }
            };

            this.IsKeyboardFocusWithinChanged+=delegate
            {

                if (this.IsKeyboardFocusWithin || popup.IsKeyboardFocusWithin)
                {
                    ShowingSuggestions = true;
                    ShowWaterMark = false;
                    
                }
                else
                {

                    ShowWaterMark = string.IsNullOrEmpty(Text);                    
                    Debug.WriteLine("Hiding suggestions");
                    
                    ShowingSuggestions = false;
                    if (TextCommited != null)
                        TextCommited(this, EventArgs.Empty);
                }
            };
            
           

            txtValue.SelectionChanged += new RoutedEventHandler(txtValue_SelectionChanged);
        }


       
        
        

        
        

        void txtValue_SelectionChanged(object sender, RoutedEventArgs e)
        {
            CaretIndex = txtValue.CaretIndex;
        }

        

        void lstSuggestions_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstSuggestions.SelectedIndex != -1)
            {
                lstSuggestions.ScrollIntoView(lstSuggestions.SelectedItem);
            }
            else
            {
                if (lstSuggestions.Items.Count > 0)
                    lstSuggestions.ScrollIntoView(lstSuggestions.Items[0]);
            }
        }

        void Suggestions_CollectionChanged(object sender, System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            UpdateSelectionByText();
        }

        void UpdateSelectionByText()
        {

            string currentText = CaretIndex >= Text.Length ? Text.ToLower(CultureInfo.InvariantCulture) : Text.Substring(0, CaretIndex).ToLower(CultureInfo.InvariantCulture);
            if (lstSuggestions.SelectedItem != null)
            {
                var item = lstSuggestions.SelectedItem as Suggestion;
                if (item != null && item.GeneratedText.ToLower(CultureInfo.InvariantCulture).StartsWith(currentText))
                {
                    return;
                }
            }
            Suggestion newlySelected = null;
            foreach (Suggestion item in lstSuggestions.Items)
            {
                if (item.GeneratedText.ToLower(CultureInfo.InvariantCulture).StartsWith(currentText))
                {
                    newlySelected = item;
                    break;
                }
            }
            if (newlySelected != null)
            {
                lstSuggestions.SelectedItem = newlySelected;
            }
            else
                lstSuggestions.SelectedIndex = -1;
            
        }

       

        protected override void OnPreviewTextInput(TextCompositionEventArgs e)
        {
            
            if (e.Text == "." || e.Text == "(" || e.Text == ")" || e.Text == " ")
            {
                e.Handled = true;
                var oldcaret = CaretIndex;
                var toInsert = e.Text;
                if (ShowingSuggestions && lstSuggestions.SelectedIndex!=-1)
                {
                    var item = lstSuggestions.SelectedItem as Suggestion;
                    if (item != null)
                    {
                        if (e.Text != ".")
                        {
                            if (item.GeneratedText.EndsWith(e.Text))
                            {
                                Text = item.GeneratedText;
                                txtValue.CaretIndex = item.CaretPosition;
                            }
                            else
                            {
                                Text = item.GeneratedText+ e.Text;
                                txtValue.CaretIndex = item.CaretPosition+1;
                            }
                        }
                        else
                        {
                            Text = item.GeneratedText+".";
                            txtValue.CaretIndex = item.CaretPosition+1;
                        }
                        if (e.Text != ")")
                        {
                            ShowingSuggestions = false;
                        }
                    }
                }
                else
                {
                    Text = Text.Insert(CaretIndex, toInsert);
                    txtValue.CaretIndex = oldcaret + toInsert.Length;
                }
                if (TextCommited != null)
                    TextCommited(this, EventArgs.Empty);
                ShowingSuggestions = true;
            }
            base.OnPreviewTextInput(e);
        }




        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public ObservableCollection<Suggestion> Suggestions
        {
            get { return (ObservableCollection<Suggestion>)GetValue(SuggestionsProperty); }
        }

        // Using a DependencyProperty as the backing store for Suggestions.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty SuggestionsProperty =
            DependencyProperty.Register("Suggestions", typeof(ObservableCollection<Suggestion>), typeof(SuggestBox), new UIPropertyMetadata());

        private void Bd_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ClickCount > 1)
            {
                var item = lstSuggestions.SelectedItem as Suggestion;
                if (item != null)
                {
                    this.Text = item.GeneratedText;
                    txtValue.CaretIndex = item.CaretPosition;
                }
                ShowingSuggestions = false;
                if (Text.EndsWith(".") || Text.EndsWith("("))
                    ShowingSuggestions = true;

                if (TextCommited != null)
                    TextCommited(this, EventArgs.Empty);
            }
        }

        private void showSuggestionsBtn_Click(object sender, RoutedEventArgs e)
        {
            ShowingSuggestions = !ShowingSuggestions;
        }


        private void UpdateSuggestionContext()
        {
            if (string.IsNullOrEmpty(Text) || CaretIndex ==0)
                SuggestionContext = string.Empty;
            else
            {
                var ctx = (CaretIndex>-1 && CaretIndex <=Text.Length)? Text.Substring(0, CaretIndex): Text;
                var lastDotIndex = ctx.LastIndexOf('.');
                var lastOpenIndex = ctx.LastIndexOf('(');
                if (lastOpenIndex >= 0)
                    lastOpenIndex++;
                var ctxEndIndex = lastDotIndex > lastOpenIndex ? lastDotIndex : lastOpenIndex;
                if (ctxEndIndex >= 0)
                {
                    SuggestionContext = ctx.Substring(0, ctxEndIndex);
                }
                else
                {
                    SuggestionContext = string.Empty;
                }
            }
        }

        private void txtValue_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (Text != txtValue.Text)
                Text = txtValue.Text;
            ShowWaterMark = string.IsNullOrEmpty(Text) && !IsKeyboardFocusWithin;
        }



        public void FocusTextBlock()
        {
            txtValue.Focus();
        }
    }

    public class Suggestion
    {
        public string Label { get; set; }

        public string GeneratedText { get; set; }

        public int CaretPosition { get; set; }

        public object IconSource { get; set; }
    }
}
