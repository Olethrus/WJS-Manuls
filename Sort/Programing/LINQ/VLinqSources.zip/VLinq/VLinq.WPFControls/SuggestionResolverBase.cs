﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

namespace VLinq.WPFControls
{
    public abstract class SuggestionResolverBase
    {
        private SuggestBox m_suggestBox;

        public ObservableCollection<Suggestion> Suggestions
        {
            get
            {
                return m_suggestBox == null ? null : m_suggestBox.Suggestions;
            }
        }
        public string Text
        {
            get
            {
                return m_suggestBox == null ? string.Empty : m_suggestBox.Text;
            }
        }
        public string SuggestionContext
        {
            get 
            {
                return m_suggestBox == null ? string.Empty : m_suggestBox.SuggestionContext;
            }
        }
        public int CaretIndex
        {
            get
            {
                return m_suggestBox == null ? -1 : m_suggestBox.CaretIndex;
            }
        }
        public SuggestBox SuggestBox
        {
            get { return m_suggestBox; }
            set 
            {
                if (m_suggestBox != null)
                {
                    m_suggestBox.TextChanged -= m_suggestBox_TextChanged;
                    m_suggestBox.CaretIndexChanged -= m_suggestBox_CaretIndexChanged;
                    m_suggestBox.SuggestionContextChanged -= m_suggestBox_SuggestionContextChanged;
                    m_suggestBox.SuggestionsRequested -= m_suggestBox_SuggestionsRequested;
                   
                }
                m_suggestBox = value;
                if (m_suggestBox != null)
                {
                    m_suggestBox.TextChanged += m_suggestBox_TextChanged;
                    m_suggestBox.CaretIndexChanged += m_suggestBox_CaretIndexChanged;
                    m_suggestBox.SuggestionContextChanged += m_suggestBox_SuggestionContextChanged;
                    m_suggestBox.SuggestionsRequested += m_suggestBox_SuggestionsRequested;
                    OnSuggestBoxSet();
                }
            }
        }

        protected abstract void OnSuggestBoxSet();

        protected abstract void OnSuggestionsRequested();
        protected abstract void OnSuggestionContextChanged();
        protected abstract void OnCaretIndexChanged();
        protected abstract void OnTextChanged(object e);

        void m_suggestBox_SuggestionsRequested(object sender, EventArgs e)
        {
            OnSuggestionsRequested();
        }

        void m_suggestBox_SuggestionContextChanged(object sender, System.Windows.DependencyPropertyChangedEventArgs e)
        {
            OnSuggestionContextChanged();
            if (!SuggestBox.ShowingSuggestions && SuggestBox.IsKeyboardFocusWithin)
            {
                SuggestBox.ShowingSuggestions = true;
            }
        }

        void m_suggestBox_CaretIndexChanged(object sender, System.Windows.DependencyPropertyChangedEventArgs e)
        {
            OnCaretIndexChanged();
        }

        void m_suggestBox_TextChanged(object sender, System.Windows.DependencyPropertyChangedEventArgs e)
        {
            OnTextChanged(e.NewValue);
        }
    }
}
