﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.ComponentModel;
using System.Windows.Data;
using System.Globalization;
using System.Collections.ObjectModel;
using System.Windows.Input;
using System.Windows.Media;

namespace VLinq.WPFControls
{
    public class TreeListView : TreeView
    {


        static TreeListView()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TreeListView), new FrameworkPropertyMetadata(typeof(TreeListView)));
        }
       

        


        public TreeListView()
        {
            var columns = new GridViewColumnCollection();
            SetValue(ColumnsProperty, columns);
           
        }



       
        private TreeListViewItem GetBoundItemFromPoint( Point point)
        {
            UIElement element = InputHitTest(point) as UIElement;
            while (element != null)
            {
                if (element == this)
                {
                    return null;
                }
                var item = element as TreeListViewItem;
                if (item != null)
                    return item;
                else
                {
                    element = VisualTreeHelper.GetParent(element) as UIElement;
                }
            }
            return null;
        }
        
       
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new TreeListViewItem();
        }

        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is TreeListViewItem;
        }

        #region Public Properties

        /// <summary> GridViewColumn List</summary>

        [DesignerSerializationVisibility(DesignerSerializationVisibility.Content)]
        public GridViewColumnCollection Columns
        {
            get { return (GridViewColumnCollection)GetValue(ColumnsProperty); }
        }

        // Using a DependencyProperty as the backing store for Columns.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty ColumnsProperty =
            DependencyProperty.Register("Columns", typeof(GridViewColumnCollection), typeof(TreeListView), new UIPropertyMetadata());



        #endregion
    }
    public enum TreeListViewSelectionMode
    {
        Single,
        Multiple,
        SameParent
    }
    public class TreeListViewItem : TreeViewItem
    {
        static TreeListViewItem()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(TreeListViewItem), new FrameworkPropertyMetadata(typeof(TreeListViewItem)));
        }
      


       



        public int Level
        {
            get { return (int)GetValue(LevelProperty); }
            set { SetValue(LevelProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Level.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty LevelProperty =
            DependencyProperty.Register("Level", typeof(int), typeof(TreeListViewItem), new UIPropertyMetadata(-1, OnLevelChanged));

        private static void OnLevelChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            TreeListViewItem elem = obj as TreeListViewItem;
            if (elem != null)
            {
                elem.OnLevelChanged(args.OldValue == null ? default(int) : (int)args.OldValue, args.NewValue == null ? default(int) : (int)args.NewValue);
            }
        }
        protected virtual void OnLevelChanged(int oldValue, int newValue)
        {
            foreach (object obj in Items)
            {
                var container = obj as TreeListViewItem;
                if (container == null)
                    container = this.ItemContainerGenerator.ContainerFromItem(obj)as TreeListViewItem;
                if (container != null)
                {
                    container.UpdateLevel();
                }
            }
        }



        protected override void OnVisualParentChanged(DependencyObject oldParent)
        {
            UpdateLevel();
            base.OnVisualParentChanged(oldParent);

        }

        private void UpdateLevel()
        {
            TreeListViewItem parent = ItemsControl.ItemsControlFromItemContainer(this) as TreeListViewItem;
            Level = (parent != null) ? parent.Level + 1 : 0;
        }


        protected override DependencyObject GetContainerForItemOverride()
        {
            return new TreeListViewItem();
        }

        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is TreeListViewItem;
        }

    }
    /// <summary>
    /// Convert Level to left margin
    /// Pass a prarameter if you want a unit length other than 19.0.
    /// </summary>
    public class LevelToIndentConverter : IValueConverter
    {
        public object Convert(object o, Type type, object parameter, CultureInfo culture)
        {
            return new Thickness((int)o * c_IndentSize, 0, 0, 0);
        }

        public object ConvertBack(object o, Type type, object parameter, CultureInfo culture)
        {
            throw new NotSupportedException();
        }

        private const double c_IndentSize = 14.0;
    }
}
