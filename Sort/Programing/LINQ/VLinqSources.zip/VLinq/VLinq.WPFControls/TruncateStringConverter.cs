﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Data;

namespace VLinq.WPFControls
{
    public class TruncateStringConverter : IValueConverter
    {
        
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            int maxChars = 15;
            if (parameter != null)
            {
                if (parameter is int)
                    maxChars = (int)parameter;
                else
                {
                    int res;
                    if(int.TryParse(parameter.ToString(), out res))
                        maxChars = res;
                }
            }

            if(value == null)
                return null;
            var str = value.ToString();
            if(str.Length<=maxChars)
                return str;
            else return str.Substring(0, maxChars-3)+"...";
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion
    }
}
