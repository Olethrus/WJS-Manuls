﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls.Primitives;
using System.Windows;
using System.Windows.Media.Animation;

namespace VLinq.WPFControls
{
    public class VisibilityController : ToggleButton
    {




        public FrameworkElement TargetContainer
        {
            get { return (FrameworkElement)GetValue(TargetContainerProperty); }
            set { SetValue(TargetContainerProperty, value); }
        }

        // Using a DependencyProperty as the backing store for MyProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TargetContainerProperty =
            DependencyProperty.Register("TargetContainer", typeof(FrameworkElement), typeof(VisibilityController), new UIPropertyMetadata(null, OnTargetContainerChanged));

        private static void OnTargetContainerChanged(DependencyObject obj, DependencyPropertyChangedEventArgs args)
        {
            VisibilityController elem = obj as VisibilityController;
            if (elem != null)
            {
                elem.OnTargetContainerChanged(args.OldValue == null ? default(FrameworkElement) : (FrameworkElement)args.OldValue, args.NewValue == null ? default(FrameworkElement) : (FrameworkElement)args.NewValue);
            }
        }
        protected virtual void OnTargetContainerChanged(FrameworkElement oldValue, FrameworkElement newValue)
        {
            if (newValue != null)
            {
                if (!IsChecked.HasValue || !IsChecked.Value)
                    newValue.Width = 0.0;
            }
        }



        public FrameworkElement TargetContent
        {
            get { return (FrameworkElement)GetValue(TargetContentProperty); }
            set { SetValue(TargetContentProperty, value); }
        }

        // Using a DependencyProperty as the backing store for TargetContent.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TargetContentProperty =
            DependencyProperty.Register("TargetContent", typeof(FrameworkElement), typeof(VisibilityController), new UIPropertyMetadata(null));






       

        public VisibilityController()
        {
            this.Checked += delegate
            {
                if (TargetContainer != null && TargetContent != null)
                {
                    TargetContent.Measure(new Size(TargetContainer.MaxWidth, TargetContainer.MaxHeight));
                    var anim = new DoubleAnimation(TargetContent.DesiredSize.Width, new Duration(TimeSpan.FromMilliseconds(300)));
                    anim.FillBehavior = FillBehavior.Stop;
                    anim.Completed += delegate { TargetContainer.Width = double.NaN; };
                    TargetContainer.BeginAnimation(FrameworkElement.WidthProperty, anim);
                }
            };
            this.Unchecked += delegate
            {
                if (TargetContainer != null && TargetContent != null)
                {
                    var anim = new DoubleAnimation(TargetContainer.ActualWidth ,0.0, new Duration(TimeSpan.FromMilliseconds(300)));
                    anim.FillBehavior = FillBehavior.Stop;
                    anim.Completed += delegate { TargetContainer.Width = 0.0; };
                    TargetContainer.BeginAnimation(FrameworkElement.WidthProperty, anim);
                }
            };
        }


    }
}
