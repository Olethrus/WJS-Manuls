﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Threading;
using System.Windows.Media.Animation;

namespace VLinq.WPFControls
{
    public static class WPFHelpers
    {
        public static TItem FindItemAtPostion<TItem, TContainer>(this ListBox listBox, Point position) where TItem:class where TContainer : DependencyObject
        {
            var elem = listBox.InputHitTest(position) as UIElement;
            if (elem == null)
                return default(TItem);
            TContainer container = elem as TContainer;
            if (container == null)
            {
                container = elem.FindFirstVisualAncestorOf<TContainer>();
                if (container == null)
                    return default(TItem);
                while (ItemsControl.ItemsControlFromItemContainer(container) != listBox)
                {
                    container = elem.FindFirstVisualAncestorOf<TContainer>();
                    if (container == null)
                        return default(TItem);
                }
            }
            else
            {
                while (ItemsControl.ItemsControlFromItemContainer(container) != listBox)
                {
                    container = elem.FindFirstVisualAncestorOf<TContainer>();
                    if (container == null)
                        return default(TItem);
                }
            }

            

            return listBox.ItemContainerGenerator.ItemFromContainer(container) as TItem;
        }
        private static object ExitFrameOperation(object obj)
        {
            DispatcherFrame frame = obj as DispatcherFrame;
            frame.Continue = false;
            return null;
        }

        private static object TimeoutFrameOperation(object obj)
        {
            TimeoutFrame frame = obj as TimeoutFrame;
            frame.Continue = false;
            frame.TimedOut = true;
            return null;
        }
        private static readonly DispatcherOperationCallback
            ExitFrameOperationInstance = new DispatcherOperationCallback(ExitFrameOperation);
        private static readonly DispatcherOperationCallback
            TimeoutFrameOperationInstance = new DispatcherOperationCallback(TimeoutFrameOperation);
        public static bool WaitForPriority(DispatcherPriority priority)
        {
            const int defaultTimeout = 30000;

            // Schedule the ExitFrame operation to end the nested pump after the timeout trigger happens
            TimeoutFrame frame = new TimeoutFrame();

            FrameTimer timeoutTimer = new FrameTimer(frame, defaultTimeout,
                TimeoutFrameOperationInstance, DispatcherPriority.Send);
            timeoutTimer.Start();

            // exit after a priortity has been processed
            DispatcherOperation opExit = Dispatcher.CurrentDispatcher.BeginInvoke(priority,
                ExitFrameOperationInstance, frame);

            // Pump the dispatcher
            Dispatcher.PushFrame(frame);

            // abort the operations that did not get processed
            if (opExit.Status != DispatcherOperationStatus.Completed)
            {
                opExit.Abort();
            }
            if (!timeoutTimer.IsCompleted)
            {
                timeoutTimer.Stop();
            }

            return !frame.TimedOut;
        }
        private class TimeoutFrame : DispatcherFrame
        {
            bool timedout = false;

            public bool TimedOut
            {
                get { return timedout; }
                set { timedout = value; }
            }
        }

        private class FrameTimer : DispatcherTimer
        {
            DispatcherFrame frame;
            DispatcherOperationCallback callback;
            bool isCompleted = false;

            public FrameTimer(DispatcherFrame frame, int milliseconds, DispatcherOperationCallback callback, DispatcherPriority priority)
                : base(priority)
            {
                this.frame = frame;
                this.callback = callback;
                Interval = TimeSpan.FromMilliseconds(milliseconds);
                Tick += new EventHandler(OnTick);
            }

            public DispatcherFrame Frame
            {
                get { return frame; }
            }

            public bool IsCompleted
            {
                get { return isCompleted; }
            }

            void OnTick(object sender, EventArgs args)
            {
                isCompleted = true;
                Stop();
                callback(frame);
            }
        }
        // The algorythm is really simple, but this extension method provides a HUGE productivity impact
        public static T FindFirstVisualAncestorOf<T>(this DependencyObject visual) where T:DependencyObject
        {
            var elem = VisualTreeHelper.GetParent(visual);
            while (elem != null)
            {
                var asT = elem as T;
                if (asT != null)
                    return asT;
                elem = VisualTreeHelper.GetParent(elem);
            }
            return null;
        }
        // This one is a bit more complex. The sub-tree can be explored either Vertically or Horizontally.
        // The best choice in this case is "no choice" => let the user decide by providing an enumerated value
        public static T FindFirstVisualDescendantOf<T>(this DependencyObject visual, VisualChildExplorationMode explorationMode) where T : DependencyObject
        {
            switch (explorationMode)
            {
                //Vertical mode : very straight forward. Should be optimized by avoiding recursive calls
                case VisualChildExplorationMode.Vertical:
                    for (int i = 0; i < VisualTreeHelper.GetChildrenCount(visual); i++)
                    {
                        var child = VisualTreeHelper.GetChild(visual, i);
                        var asT = child as T;
                        if (asT !=null)
                            return asT;
                        else
                        {
                            var childTest = child.FindFirstVisualDescendantOf<T>(VisualChildExplorationMode.Vertical);
                            if (childTest != null)
                                return childTest;
                        }
                    }
                    break;
                // Horizontal mode : let's use the power of Linq
                // at each iteration we have to maintain 2 List<DependencyObject>: the current explored generation, and the next one.
                // The nextGeneration creation using Linq to Objects is really cool:
                // SelectMany flattens a IEnumerable<IEnumerable<T>> to an IEnumerable<T>. I love that.
                // Just imagine the number of lines of code to write this without intermediate collections in .Net 2 (only iterators).
                case VisualChildExplorationMode.Horizontal:
                    List<DependencyObject> currentGeneration = new List<DependencyObject>{visual}, nextGeneration;
                    nextGeneration = new List<DependencyObject>( currentGeneration.SelectMany(v => v.GetVisualChildren()));
                    while (nextGeneration.Count > 0)
                    {
                        currentGeneration = nextGeneration;
                        var result = currentGeneration.OfType<T>().FirstOrDefault();
                        if (result != null)
                            return result;
                        nextGeneration = new List<DependencyObject>(currentGeneration.SelectMany(v => v.GetVisualChildren()));
                    
                    }
                    break;
            }
            return null;
        }
        public static IEnumerable<DependencyObject> GetVisualChildren(this DependencyObject visual)
        {
            var count = VisualTreeHelper.GetChildrenCount(visual);
            for (int i = 0; i < count; i++)
                yield return VisualTreeHelper.GetChild(visual, i);
        }
        public static DoubleAnimationUsingKeyFrames CreateDeceleratingDoubleAnimation(double from, double to, KeySpline keySpline, Duration duration)
        {
            var anim = new DoubleAnimationUsingKeyFrames();
            anim.FillBehavior = FillBehavior.Stop;
            anim.KeyFrames.Add(new DiscreteDoubleKeyFrame(from, KeyTime.FromPercent(0.0)));
            anim.KeyFrames.Add(new SplineDoubleKeyFrame(to, KeyTime.FromPercent(1.0), keySpline));
            anim.Duration = duration;

            return anim;
        }
    }
    public enum VisualChildExplorationMode
    {
        Horizontal,
        Vertical
    }
    
}
