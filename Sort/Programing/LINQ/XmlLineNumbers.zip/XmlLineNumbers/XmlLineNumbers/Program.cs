﻿using System;
using System.Linq;
using System.Xml;
using System.Xml.Linq;

namespace ConsoleApplication1
{
    class Program
    {
        static XDocument xml;

        static void Main(string[] args)
        {
            string fileName = @"FirstFourPlanets.xml";
            xml = XDocument.Load(fileName, LoadOptions.SetLineInfo);

            ReportLineNumber(xml);

            SearchByLineNumber(xml);            
        }

        private static void ReportLineNumber(XDocument xml)
        {
            XText phobos = (from x in xml.DescendantNodes().OfType<XText>()
                        where x.Value == "Phobos"
                        select x).Single();

            var lineInfo = (IXmlLineInfo)phobos;
            Console.WriteLine("{0} appears on line {1}", 
                phobos, lineInfo.LineNumber);            
        }

        private static void SearchByLineNumber(XDocument xml)
        {
            var line = from x in xml.Descendants()
                       let lineInfo = (IXmlLineInfo)x
                       where lineInfo.LineNumber == 21
                       select x;

            foreach (var item in line)
            {
                Console.WriteLine(item);
            }
        }
    }
}
