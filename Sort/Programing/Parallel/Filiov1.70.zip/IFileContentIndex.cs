﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Xnlab.Filio
{
    public class FileProcessEventArgs : EventArgs
    {
        private bool cancel = false;
        public bool Cancel
        {
            get { return cancel; }
            set { cancel = value; }
        }

        private string fileName;
        public string FileName
        {
            get { return fileName; }
        }

        public FileProcessEventArgs(string FileName)
        {
            fileName = FileName;
        }
    }

    public interface IFileProcess
    {
        event EventHandler<FileProcessEventArgs> BeforeFileProcess;
    }

    public interface IFileContentIndex : IFileProcess
    {

        bool Query(string Keyword, string FileName, out string Content);
    }
}
