﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Net;
using System.Threading;
#if (DRIVEID)
using System.Management;
#endif

namespace Xnlab.Filio
{
    public enum ObjectTypes
    {
        LocalFile = 0,
        RemoteURI = 1
    }

    #region WorkV6
    public class WorkV6FindFileRunner : IParallelWorker
    {
        private FileURI[] filePaths;
        private BaseWork worker;
        private string[] includesFileTypes;
        private SearchTypes searchType;
        private string keyword;
        private MatchTypes matchType;
        private SynchronizedDictionary<string, List<string>> sameFiles;

        public WorkV6FindFileRunner(FileURI[] FilePaths, BaseWork Worker, string[] IncludesFileTypes, string Keyword, SearchTypes SearchType, MatchTypes MatchType, SynchronizedDictionary<string, List<string>> SameFiles)
        {
            filePaths = FilePaths;
            worker = Worker;
            includesFileTypes = IncludesFileTypes;
            searchType = SearchType;
            keyword = Keyword;
            matchType = MatchType;
            sameFiles = SameFiles;
        }

        public void Run()
        {
            worker.OnProgress(WorkProgressTypes.Detail, "find file work runner start:" + DateTime.Now);
            foreach (FileURI path in filePaths)
            {
                switch (path.ObjectType)
                {
                    case ObjectTypes.LocalFile:
                        FindLocal(path.Uri, includesFileTypes, searchType, sameFiles);
                        break;
                    case ObjectTypes.RemoteURI:
                        FindRemote(path, includesFileTypes, searchType, sameFiles);
                        break;
                    default:
                        break;
                }
            }
            worker.OnProgress(WorkProgressTypes.Detail, "find file work runner end:" + DateTime.Now);
        }

        private void FindRemote(FileURI FilePath, string[] IncludesFileTypes, SearchTypes SearchType, SynchronizedDictionary<string, List<string>> Result)
        {
            string address;
            int port;
            WorkUtils.ParseAddressPort(FilePath.Uri, out address, out port);
            if (!string.IsNullOrEmpty(address) && port > 0)
            {
                ManualResetEvent remoteDone = new ManualResetEvent(false);
                KeyValuePair<FileURI, ManualResetEvent> state = new KeyValuePair<FileURI, ManualResetEvent>(FilePath, remoteDone);
                try
                {
                    WorkUtils.SendHTTPRequest(string.Format("http://{0}:{1}", address, port), state, BuildDiscover(FilePath), 0, OnHTTPGetDiscoverResult, worker);
                    //TcpClient scanner = new TcpClient();
                    //scanner.Connect(address, port);
                    //scanner.Close();
                }
                catch (Exception)
                {
                    worker.OnProgress(WorkProgressTypes.Network, "could not connect through http, fall back to tcp");

                    AsynchronousClient client = new AsynchronousClient();
                    client.Connected += new EventHandler<DataTransferEventArgs>(OnClientConnected);
                    client.Received += new EventHandler<DataTransferEventArgs>(OnClientReceived);
                    client.Sent += new EventHandler<DataTransferEventArgs>(OnClientSent);
                    client.Failed += new EventHandler<DataTransferEventArgs>(OnClientFailed);
                    client.State = state;
                    client.Connect(address, port);
                }
                remoteDone.WaitOne(FilePath.TimeOut * 1000);
            }
        }

        private void OnHTTPGetDiscoverResult(IAsyncResult ar)
        {
            KeyValuePair<HttpWebRequest, KeyValuePair<FileURI, ManualResetEvent>> state = (KeyValuePair<HttpWebRequest, KeyValuePair<FileURI, ManualResetEvent>>)ar.AsyncState;
            HttpWebResponse response = (HttpWebResponse)state.Key.EndGetResponse(ar);
            byte[] result = ProcessRequest(WorkUtils.ReadHTTPStreamContent(response.GetResponseStream()), state.Value);
            if (result != null)
            {
                string address;
                int port;
                WorkUtils.ParseAddressPort(state.Value.Key.Uri, out address, out port);
                if (!string.IsNullOrEmpty(address) && port > 0)
                    WorkUtils.SendHTTPRequest(string.Format("http://{0}:{1}", address, port), state.Value, result, 0, OnHTTPGetQueryResult, worker);
            }
        }

        private void OnHTTPGetQueryResult(IAsyncResult ar)
        {
            KeyValuePair<HttpWebRequest, KeyValuePair<FileURI, ManualResetEvent>> state = (KeyValuePair<HttpWebRequest, KeyValuePair<FileURI, ManualResetEvent>>)ar.AsyncState;
            HttpWebResponse response = (HttpWebResponse)state.Key.EndGetResponse(ar);
            ProcessRequest(WorkUtils.ReadHTTPStreamContent(response.GetResponseStream()), state.Value);
        }

        private byte[] ProcessRequest(byte[] Data, KeyValuePair<FileURI, ManualResetEvent> State)
        {
            byte[] result = null;
            Dictionary<string, string> parameters;
            if (RemoteCommander.ParseCommand(Data, out parameters))
            {
                switch (parameters[RemoteCommander.CommandPrefix])
                {
                    case RemoteCommander.CommandQuery:
                        if (parameters.ContainsKey(RemoteCommander.ParameterFilePaths))
                        {
                            string address;
                            int port;
                            WorkUtils.ParseAddressPort(State.Key.Uri, out address, out port);
                            string filePaths = parameters[RemoteCommander.ParameterFilePaths];
                            string[] groups = filePaths.Split(new string[] { RemoteCommander.FileGroupSeparator }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string group in groups)
                            {
                                string[] files = group.Split(new string[] { RemoteCommander.FileItemSeparator }, StringSplitOptions.RemoveEmptyEntries);
                                string key = files[0];
                                if (!sameFiles.ContainsKey(key))
                                    sameFiles.Add(key, new List<string>());
                                for (int i = 1; i < files.Length; i++)
                                {
                                    sameFiles[key].Add(address + ":" + port + WorkUtils.ServerAddressSeparator + files[i]);
                                }
                            }
                        }
                        State.Value.Set();
                        break;
                    case RemoteCommander.CommandDiscover:
                        FileURI filePath = State.Key;
                        int index = filePath.Uri.IndexOf(WorkUtils.ServerAddressSeparator);
                        if (index != -1)
                        {
                            string allPaths;
                            allPaths = filePath.Uri.Substring(index + 1);
                            string allowedFilePaths;
                            if (parameters.ContainsKey(RemoteCommander.ParameterFilePaths))
                                allowedFilePaths = parameters[RemoteCommander.ParameterFilePaths];
                            else
                                allowedFilePaths = string.Empty;
                            string[] allowedFilePathSegments = allowedFilePaths.Split(new string[] { RemoteCommander.FileItemSeparator }, StringSplitOptions.RemoveEmptyEntries);
                            string[] allPathSements = allPaths.Split(new string[] { WorkUtils.PathSeparator }, StringSplitOptions.RemoveEmptyEntries);
                            List<string> filteredFilePaths = new List<string>();
                            foreach (string file in allPathSements)
                            {
                                foreach (string item in allowedFilePathSegments)
                                {
                                    if (WorkUtils.MatchExact(file, item))
                                    {
                                        filteredFilePaths.Add(file);
                                        break;
                                    }
                                }
                            }
                            if (filteredFilePaths.Count > 0)
                            {
                                StringBuilder command = new StringBuilder();
                                command.Append(RemoteCommander.ParameterUserName + RemoteCommander.KeyValueSeparator + filePath.UserName + RemoteCommander.ParameterSeparator);
                                command.Append(RemoteCommander.ParameterPassword + RemoteCommander.KeyValueSeparator + filePath.Password + RemoteCommander.ParameterSeparator);
                                allPaths = string.Join(WorkUtils.PathSeparator, filteredFilePaths.ToArray());
                                command.Append(RemoteCommander.ParameterFilePaths + RemoteCommander.KeyValueSeparator + allPaths + RemoteCommander.ParameterSeparator);
                                command.Append(RemoteCommander.ParameterIncludeFileTypes + RemoteCommander.KeyValueSeparator + string.Join(WorkUtils.PathSeparator, includesFileTypes) + RemoteCommander.ParameterSeparator);
                                command.Append(RemoteCommander.ParameterSearchType + RemoteCommander.KeyValueSeparator + (int)searchType + RemoteCommander.ParameterSeparator);
                                command.Append(RemoteCommander.ParameterKeyword + RemoteCommander.KeyValueSeparator + keyword + RemoteCommander.ParameterSeparator);
                                command.Append(RemoteCommander.ParameterMatchType + RemoteCommander.KeyValueSeparator + (int)matchType + RemoteCommander.ParameterSeparator);
                                result = RemoteCommander.BuildCommand(RemoteCommander.CommandQuery, command.ToString());
                            }
                            else
                                worker.OnProgress(WorkProgressTypes.FileAccess, "no remote access allowed files to search");
                        }
                        break;
                    case RemoteCommander.CommandAccessDenied:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote access denied");
                        State.Value.Set();
                        break;
                    case RemoteCommander.CommandNoCommand:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote command empty");
                        State.Value.Set();
                        break;
                    case RemoteCommander.CommandNoData:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote access no data");
                        State.Value.Set();
                        break;
                    default:
                        State.Value.Set();
                        break;
                }
            }
            return result;
        }

        private void OnClientFailed(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Network, "Remote connection failed:" + e.Content);
            KeyValuePair<FileURI, ManualResetEvent> state = (KeyValuePair<FileURI, ManualResetEvent>)((AsynchronousClient)sender).State;
            state.Value.Set();
        }

        private void OnClientSent(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Network, "remote command sent");
        }

        private void OnClientReceived(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Network, "remote command received:" + e.Content);
            KeyValuePair<FileURI, ManualResetEvent> state = (KeyValuePair<FileURI, ManualResetEvent>)((AsynchronousClient)sender).State;
            byte[] result = ProcessRequest(e.Buffer, state);
            if (result != null)
                ((AsynchronousClient)sender).Send(WorkSettings.Instance.CompressionMethod, result);
        }

        private void OnClientConnected(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Network, "connected to remote server:" + e.Content);
            KeyValuePair<FileURI, ManualResetEvent> state = (KeyValuePair<FileURI, ManualResetEvent>)((AsynchronousClient)sender).State;
            FileURI filePath = state.Key;
            ((AsynchronousClient)sender).Send(WorkSettings.Instance.CompressionMethod, BuildDiscover(filePath));
        }

        private byte[] BuildDiscover(FileURI FilePath)
        {
            StringBuilder command = new StringBuilder();
            command.Append(RemoteCommander.ParameterUserName + RemoteCommander.KeyValueSeparator + FilePath.UserName + RemoteCommander.ParameterSeparator);
            command.Append(RemoteCommander.ParameterPassword + RemoteCommander.KeyValueSeparator + FilePath.Password + RemoteCommander.ParameterSeparator);
            return RemoteCommander.BuildCommand(RemoteCommander.CommandDiscover, command.ToString());
        }

        private void MatchFiles(string[] FilePaths, string[] IncludesFileTypes, SearchTypes SearchType, SynchronizedDictionary<string, List<string>> Result)
        {
            foreach (string item in FilePaths)
            {
                bool found;
                bool matchFileType;
                bool hasFileType = IncludesFileTypes != null && IncludesFileTypes.Length > 0;
                if (hasFileType)
                {
                    matchFileType = WorkUtils.MatchFileType(item, IncludesFileTypes);
                    if (matchFileType)
                    {
                        if (!string.IsNullOrEmpty(keyword))
                            found = WorkUtils.MatchContains(item, keyword);
                        else
                            found = true;
                    }
                    else
                        found = false;
                }
                else
                {
                    matchFileType = true;
                    found = true;
                }
                switch (matchType)
                {
                    case MatchTypes.ContentSame:
                        if (found)
                        {
                            string key = WorkUtils.GetInfoKey(item, SearchType);
                            if (!Result.ContainsKey(key))
                                Result.Add(key, new List<string>());
                            Result[key].Add(item);
                        }
                        break;
                    case MatchTypes.ContentContains:
                    case MatchTypes.ContentExtract:
                        if (matchFileType && !string.IsNullOrEmpty(keyword))
                        {
                            if (!hasFileType)
                                matchFileType = WorkUtils.MatchFileType(item, WorkUtils.DefaultFileTypes);
                            if (matchFileType)
                            {
                                string key = keyword;
                                if (!Result.ContainsKey(key))
                                    Result.Add(key, new List<string>());
                                Result[key].Add(item);
                            }
                        }
                        break;
                    default:
                        break;
                }
            }
        }

        private void FindLocal(string FilePath, string[] IncludesFileTypes, SearchTypes SearchType, SynchronizedDictionary<string, List<string>> Result)
        {
            string[] paths = FilePath.Split(new string[] { WorkUtils.PathSeparator }, StringSplitOptions.RemoveEmptyEntries);
            bool useNTFS = false;
#if(NTFS && STORAGE)
            List<string> drives = new List<string>();
            List<string> remainsPaths = new List<string>();
            foreach (string path in paths)
            {
                string realPath = Path.GetFullPath(path).ToLower();
                if (Path.GetPathRoot(realPath) == WorkUtils.GetFullPath(realPath))
                {
                    if (!drives.Contains(realPath))
                        drives.Add(realPath);
                }
                else
                    remainsPaths.Add(realPath);
            }
            List<string> ntfsDrives = new List<string>();
            foreach (string drive in drives)
            {
                DriveInfo info = new DriveInfo(drive);
                if (info.DriveType == DriveType.Fixed && info.IsReady && info.DriveFormat.ToUpper() == "NTFS")
                {
                    ntfsDrives.Add(drive);
                }
            }
            useNTFS = ntfsDrives.Count > 0;
#endif
            if (useNTFS)
            {
#if(NTFS && STORAGE)
                foreach (string drive in ntfsDrives)
                {
                    string[] items = LocalNTFSStorage.Instance.GetFiles(drive);
                    if (items != null)
                        MatchFiles(items, IncludesFileTypes, SearchType, Result);
                    else
                        remainsPaths.Add(drive);
                }
                paths = remainsPaths.ToArray();
#endif
            }

            foreach (string path in paths)
            {
                if (!string.IsNullOrEmpty(path) && Directory.Exists(path))
                {
                    //mmm... infamous user access prohibited by windows, such as "System Volume Information"
                    //refer to workitem: http://filio.codeplex.com/workitem/28298
                    try
                    {
                        string[] items = Directory.GetDirectories(path);
                        foreach (string folder in items)
                        {
                            FindLocal(folder, IncludesFileTypes, SearchType, Result);
                        }
                        items = Directory.GetFiles(path);
                        MatchFiles(items, IncludesFileTypes, SearchType, Result);
                    }
                    catch (Exception ex)
                    {
                        WorkUtils.AddVerbose(string.Format("could not access {0}: {1}", path, ex.ToString()));
                    }
                }
            }
        }
    }

    public class WorkV6DeleteResultRunner : IParallelWorker
    {
        private List<BasicFileInfo> files;
        private FileURI fileAccess;
        private BaseWork worker;
        private SynchronizedDictionary<string, BasicFileInfo> result;

        public WorkV6DeleteResultRunner(List<BasicFileInfo> Files, FileURI FileAccess, BaseWork Worker, SynchronizedDictionary<string, BasicFileInfo> Result)
        {
            files = Files;
            fileAccess = FileAccess;
            worker = Worker;
            result = Result;
        }

        public void Run()
        {
            worker.OnProgress(WorkProgressTypes.Detail, "delete result work runner start:" + DateTime.Now);
            if (fileAccess != null && fileAccess.ObjectType == ObjectTypes.RemoteURI)
            {
                string address;
                int port;
                WorkUtils.ParseAddressPort(fileAccess.Uri, out address, out port);
                if (!string.IsNullOrEmpty(address) && port > 0)
                {
                    AsynchronousClient client = new AsynchronousClient();
                    client.Connected += new EventHandler<DataTransferEventArgs>(OnClientConnected);
                    client.Received += new EventHandler<DataTransferEventArgs>(OnClientReceived);
                    client.Sent += new EventHandler<DataTransferEventArgs>(OnClientSent);
                    client.Failed += new EventHandler<DataTransferEventArgs>(OnClientFailed);
                    ManualResetEvent remoteDone = new ManualResetEvent(false);
                    client.State = remoteDone;
                    client.Connect(address, port);
                    remoteDone.WaitOne(fileAccess.TimeOut * 1000);
                }
            }
            else
            {
                foreach (BasicFileInfo item in files)
                {
                    if (File.Exists(item.FileName))
                    {
                        try
                        {
                            File.Delete(item.FileName);
                            result.Add(item.FileName, item);
                        }
                        catch (Exception ex)
                        {
                            worker.OnProgress(WorkProgressTypes.FileAccess, ex.ToString());
                        }
                    }
                }
            }
        }

        private void OnClientFailed(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Detail, "Remote connection failed:" + e.Content);
            ManualResetEvent state = (ManualResetEvent)((AsynchronousClient)sender).State;
            state.Set();
        }

        private void OnClientSent(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Detail, "remote command sent");
        }

        private void OnClientReceived(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Detail, "remote command received:" + e.Content);
            ManualResetEvent state = (ManualResetEvent)((AsynchronousClient)sender).State;
            Dictionary<string, string> parameters;
            if (RemoteCommander.ParseCommand(e.Buffer, out parameters))
            {
                switch (parameters[RemoteCommander.CommandPrefix])
                {
                    case RemoteCommander.CommandDelete:
                        if (parameters.ContainsKey(RemoteCommander.ParameterFilePaths))
                        {
                            string address;
                            int port;
                            WorkUtils.ParseAddressPort(fileAccess.Uri, out address, out port);
                            string filePaths = parameters[RemoteCommander.ParameterFilePaths];
                            string[] deletedFiles = filePaths.Split(new string[] { RemoteCommander.FileItemSeparator }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string file in deletedFiles)
                            {
                                result.Add(file, WorkUtils.GetFileInfo(file));
                            }
                        }
                        break;
                    case RemoteCommander.CommandAccessDenied:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote access denied");
                        break;
                    case RemoteCommander.CommandNoCommand:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote command empty");
                        break;
                    case RemoteCommander.CommandNoData:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote access no data");
                        break;
                }
            }
            state.Set();
        }

        private void OnClientConnected(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Detail, "connected to remote server:" + e.Content);
            ManualResetEvent state = (ManualResetEvent)((AsynchronousClient)sender).State;
            StringBuilder command = new StringBuilder();
            command.Append(RemoteCommander.ParameterUserName + RemoteCommander.KeyValueSeparator + fileAccess.UserName + RemoteCommander.ParameterSeparator);
            command.Append(RemoteCommander.ParameterPassword + RemoteCommander.KeyValueSeparator + fileAccess.Password + RemoteCommander.ParameterSeparator);
            command.Append(RemoteCommander.ParameterFilePaths + RemoteCommander.KeyValueSeparator);
            foreach (BasicFileInfo item in files)
            {
                command.Append(item.FileName + RemoteCommander.FileItemSeparator);
            }
            command.Append(RemoteCommander.ParameterSeparator);
            ((AsynchronousClient)sender).Send(WorkSettings.Instance.CompressionMethod, RemoteCommander.BuildCommand(RemoteCommander.CommandDelete, command.ToString()));
        }

    }

    public class WorkV6FindResultRunner : IParallelWorker
    {
        private List<string> files;
        private FileURI fileAccess;
        private string keyword;
        private SearchTypes searchType;
        private MatchTypes matchType;
        private BaseWork worker;
        private SynchronizedDictionary<string, MatchFileItem> result;

        public WorkV6FindResultRunner(List<string> Files, FileURI FileAccess, string Keyword, SearchTypes SearchType, MatchTypes MatchType, BaseWork Worker, SynchronizedDictionary<string, MatchFileItem> Result)
        {
            files = Files;
            fileAccess = FileAccess;
            keyword = Keyword;
            searchType = SearchType;
            matchType = MatchType;
            worker = Worker;
            result = Result;
        }

        private int matchCount = 0;
        public int MatchCount
        {
            get { return matchCount; }
        }

        public void Run()
        {
            worker.OnProgress(WorkProgressTypes.Detail, "find result work runner start:" + DateTime.Now);
            if (fileAccess != null && fileAccess.ObjectType == ObjectTypes.RemoteURI)
            {
                string address;
                int port;
                WorkUtils.ParseAddressPort(fileAccess.Uri, out address, out port);
                ManualResetEvent remoteDone = new ManualResetEvent(false);
                KeyValuePair<FileURI, ManualResetEvent> state = new KeyValuePair<FileURI, ManualResetEvent>(fileAccess, remoteDone);
                if (!string.IsNullOrEmpty(address) && port > 0)
                {
                    try
                    {
                        WorkUtils.SendHTTPRequest(string.Format("http://{0}:{1}", address, port), state, BuildMatchCommand(), 0, OnHTTPGetHashResult, worker);
                        //TcpClient scanner = new TcpClient();
                        //scanner.Connect(address, port);
                        //scanner.Close();
                    }
                    catch (Exception)
                    {
                        worker.OnProgress(WorkProgressTypes.Network, "could not connect through http, fall back to tcp");
                        AsynchronousClient client = new AsynchronousClient();
                        client.Connected += new EventHandler<DataTransferEventArgs>(OnClientConnected);
                        client.Received += new EventHandler<DataTransferEventArgs>(OnClientReceived);
                        client.Sent += new EventHandler<DataTransferEventArgs>(OnClientSent);
                        client.Failed += new EventHandler<DataTransferEventArgs>(OnClientFailed);
                        client.State = remoteDone;
                        client.Connect(address, port);
                    }
                    remoteDone.WaitOne(fileAccess.TimeOut * 1000);
                }
            }
            else
            {
                foreach (string file in files)
                {
                    bool add;
                    string key;
                    switch (matchType)
                    {
                        case MatchTypes.ContentSame:
                            key = WorkUtils.HashMD5FileEx(file);
                            add = true;
                            break;
                        case MatchTypes.ContentContains:
                            //quick & dirty...
                            add = File.ReadAllText(file).IndexOf(keyword, StringComparison.InvariantCultureIgnoreCase) != -1;
                            key = keyword;
                            break;
#if(STORAGE)
                        case MatchTypes.ContentExtract:
                            string response;
                            add = LocalFileContentIndexStorage.Instance.Query(file, keyword, out response);
                            key = keyword;
                            break;
#endif
                        default:
                            key = string.Empty;
                            add = false;
                            break;
                    }
                    if (add)
                    {
                        matchCount++;
                        if (!result.ContainsKey(key))
                            result.Add(key, new MatchFileItem());
                        MatchFileItem matchFile = result[key];
                        matchFile.MatchFiles.Add(WorkUtils.GetFileInfo(file));
                        if (matchFile.MatchFiles.Count > 1)
                            worker.OnProgress(key, matchFile.MatchFiles);
                    }
                }
            }
            worker.OnProgress(WorkProgressTypes.Detail, "find result work runner end:" + DateTime.Now + " matching " + matchCount);
        }

        private void OnClientFailed(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Detail, "Remote connection failed:" + e.Content);
            ManualResetEvent state = (ManualResetEvent)((AsynchronousClient)sender).State;
            state.Set();
        }

        private void OnClientSent(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Detail, "remote command sent");
        }

        private void OnClientReceived(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Detail, "remote command received:" + e.Content);
            ManualResetEvent state = (ManualResetEvent)((AsynchronousClient)sender).State;
            ProcessRequest(e.Buffer, state);
        }

        private void ProcessRequest(byte[] Content, ManualResetEvent State)
        {
            Dictionary<string, string> parameters;
            if (RemoteCommander.ParseCommand(Content, out parameters))
            {
                switch (parameters[RemoteCommander.CommandPrefix])
                {
                    case RemoteCommander.CommandMatch:
                        if (parameters.ContainsKey(RemoteCommander.ParameterFilePaths))
                        {
                            string address;
                            int port;
                            WorkUtils.ParseAddressPort(fileAccess.Uri, out address, out port);
                            string filePaths = parameters[RemoteCommander.ParameterFilePaths];
                            string[] groups = filePaths.Split(new string[] { RemoteCommander.FileGroupSeparator }, StringSplitOptions.RemoveEmptyEntries);
                            if (!string.IsNullOrEmpty(address) && port > 0)
                            {
                                foreach (string group in groups)
                                {
                                    string[] files = group.Split(new string[] { RemoteCommander.FileItemSeparator }, StringSplitOptions.RemoveEmptyEntries);
                                    string key = files[0];
                                    if (!result.ContainsKey(key))
                                        result.Add(key, new MatchFileItem());
                                    for (int i = 1; i < files.Length; i++)
                                    {
                                        result[key].MatchFiles.Add(new BasicFileInfo(address + ":" + port + WorkUtils.ServerAddressSeparator + files[i]));
                                    }
                                }
                            }
                        }
                        break;
                    case RemoteCommander.CommandAccessDenied:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote access denied");
                        break;
                    case RemoteCommander.CommandNoCommand:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote command empty");
                        break;
                    case RemoteCommander.CommandNoData:
                        worker.OnProgress(WorkProgressTypes.FileAccess, "remote access no data");
                        break;
                }
            }
            State.Set();
        }

        private void OnClientConnected(object sender, DataTransferEventArgs e)
        {
            worker.OnProgress(WorkProgressTypes.Detail, "connected to remote server:" + e.Content);
            ((AsynchronousClient)sender).Send(WorkSettings.Instance.CompressionMethod, BuildMatchCommand());
        }

        private byte[] BuildMatchCommand()
        {
            StringBuilder command = new StringBuilder();
            command.Append(RemoteCommander.ParameterUserName + RemoteCommander.KeyValueSeparator + fileAccess.UserName + RemoteCommander.ParameterSeparator);
            command.Append(RemoteCommander.ParameterPassword + RemoteCommander.KeyValueSeparator + fileAccess.Password + RemoteCommander.ParameterSeparator);
            command.Append(RemoteCommander.ParameterFilePaths + RemoteCommander.KeyValueSeparator);
            foreach (string item in files)
            {
                command.Append(item + RemoteCommander.FileItemSeparator);
            }
            command.Append(RemoteCommander.ParameterSeparator);
            command.Append(RemoteCommander.ParameterSearchType + RemoteCommander.KeyValueSeparator + (int)searchType + RemoteCommander.ParameterSeparator);
            command.Append(RemoteCommander.ParameterKeyword + RemoteCommander.KeyValueSeparator + keyword + RemoteCommander.ParameterSeparator);
            command.Append(RemoteCommander.ParameterMatchType + RemoteCommander.KeyValueSeparator + (int)matchType + RemoteCommander.ParameterSeparator);
            return RemoteCommander.BuildCommand(RemoteCommander.CommandMatch, command.ToString());
        }

        private void OnHTTPGetHashResult(IAsyncResult ar)
        {
            KeyValuePair<HttpWebRequest, KeyValuePair<FileURI, ManualResetEvent>> state = (KeyValuePair<HttpWebRequest, KeyValuePair<FileURI, ManualResetEvent>>)ar.AsyncState;
            HttpWebResponse response = (HttpWebResponse)state.Key.EndGetResponse(ar);
            ProcessRequest(WorkUtils.ReadHTTPStreamContent(response.GetResponseStream()), state.Value.Value);
        }

    }

    public abstract class BaseV6Manager
    {
        private RoleManager roleManager = new RoleManager();

        public event EventHandler<ProgressEventArgs> Progress;
        public event EventHandler<DataTransferEventArgs> Request;

        public RoleManager Roles
        {
            get { return roleManager; }
        }

        public virtual void Start(int Port)
        {
        }

        public abstract void Close();

        protected internal void OnProgress(WorkProgressTypes ProgressType, string Status)
        {
            if (Progress != null)
                Progress(this, new ProgressEventArgs(ProgressType, Status));
        }

        protected internal void OnRequest(DataTransferEventArgs e)
        {
            if (Request != null)
                Request(this, e);
        }

        private bool ValidateUser(Dictionary<string, string> Parameters, UserRights UserRight, out UserAuth User)
        {
            User = new UserAuth();
            User.UserName = string.Empty;
            User.Password = string.Empty;
            if (Parameters.ContainsKey(RemoteCommander.ParameterUserName))
                User.UserName = Parameters[RemoteCommander.ParameterUserName];
            if (Parameters.ContainsKey(RemoteCommander.ParameterPassword))
                User.Password = Parameters[RemoteCommander.ParameterPassword];
            return roleManager.Verify(User, string.Empty, UserRight);
        }

        public virtual byte[] ProcessRequest(byte[] Content)
        {
            byte[] response = null;
            Dictionary<string, string> parameters;
            UserAuth user;
            if (RemoteCommander.ParseCommand(Content, out parameters))
            {
                switch (parameters[RemoteCommander.CommandPrefix])
                {
                    case RemoteCommander.CommandDelete:
                        if (ValidateUser(parameters, UserRights.Delete, out user))
                        {
                            string[] filePaths = parameters[RemoteCommander.ParameterFilePaths].Split(new string[] { RemoteCommander.FileItemSeparator }, StringSplitOptions.RemoveEmptyEntries);
                            StringBuilder result = new StringBuilder();
                            result.Append(RemoteCommander.ParameterFilePaths + RemoteCommander.KeyValueSeparator);
                            foreach (string file in filePaths)
                            {
                                string item = file;
                                int index = item.IndexOf(WorkUtils.ServerAddressSeparator);
                                if (index != -1)
                                    item = item.Substring(index + 1);
                                if (File.Exists(item))
                                {
                                    File.Delete(item);
                                    result.Append(item + RemoteCommander.FileItemSeparator);
                                }
                            }
                            response = RemoteCommander.BuildCommand(RemoteCommander.CommandDelete, result.ToString());
                        }
                        else
                            response = RemoteCommander.BuildCommand(RemoteCommander.CommandAccessDenied, string.Empty);
                        break;
                    case RemoteCommander.CommandDiscover:
                        if (ValidateUser(parameters, UserRights.Discover, out user))
                        {
                            StringBuilder result = new StringBuilder();
                            result.Append(RemoteCommander.ParameterFilePaths + RemoteCommander.KeyValueSeparator);
                            List<string> allowedPaths = roleManager.GetFilePaths(user, UserRights.Discover);
                            foreach (string item in allowedPaths)
                            {
                                result.Append(item + RemoteCommander.FileItemSeparator);
                            }
                            response = RemoteCommander.BuildCommand(RemoteCommander.CommandDiscover, result.ToString());
                        }
                        else
                            response = RemoteCommander.BuildCommand(RemoteCommander.CommandAccessDenied, string.Empty);
                        break;
                    case RemoteCommander.CommandQuery:
                        if (ValidateUser(parameters, UserRights.Search, out user))
                        {
                            if (parameters.ContainsKey(RemoteCommander.ParameterFilePaths))
                            {
                                WorkV6 work = new WorkV6();
                                work.WorkMode = WorkModes.Server;
                                string[] filePaths = parameters[RemoteCommander.ParameterFilePaths].Split(new string[] { WorkUtils.PathSeparator }, StringSplitOptions.RemoveEmptyEntries);
                                string[] includeFileTypes = parameters[RemoteCommander.ParameterIncludeFileTypes].Split(new string[] { WorkUtils.PathSeparator }, StringSplitOptions.RemoveEmptyEntries);
                                SearchTypes searchType = (SearchTypes)Convert.ToInt32(parameters[RemoteCommander.ParameterSearchType]);
                                string keyword = parameters[RemoteCommander.ParameterKeyword];
                                MatchTypes matchType = (MatchTypes)Convert.ToInt32(parameters[RemoteCommander.ParameterMatchType]);
                                List<string> filteredFilePaths = new List<string>();
                                foreach (string file in filePaths)
                                {
                                    if (roleManager.Verify(user, file, UserRights.Search))
                                        filteredFilePaths.Add(file);
                                }
                                filePaths = filteredFilePaths.ToArray();
                                Dictionary<string, MatchFileItem> matchFiles = work.Find(filePaths, includeFileTypes, keyword, searchType, matchType);
                                StringBuilder result = new StringBuilder();
                                result.Append(RemoteCommander.ParameterFilePaths + RemoteCommander.KeyValueSeparator);
                                //todo:might be huge result
                                foreach (KeyValuePair<string, MatchFileItem> item in matchFiles)
                                {
                                    result.Append(item.Key + RemoteCommander.FileItemSeparator);
                                    foreach (BasicFileInfo file in item.Value.MatchFiles)
                                    {
                                        result.Append(file.FileName + RemoteCommander.FileItemSeparator);
                                    }
                                    result.Append(RemoteCommander.FileGroupSeparator);
                                }
                                response = RemoteCommander.BuildCommand(RemoteCommander.CommandQuery, result.ToString());
                            }
                            else
                                response = RemoteCommander.BuildCommand(RemoteCommander.CommandNoData, string.Empty);
                        }
                        else
                            response = RemoteCommander.BuildCommand(RemoteCommander.CommandAccessDenied, string.Empty);
                        break;
                    case RemoteCommander.CommandMatch:
                        if (ValidateUser(parameters, UserRights.Search, out user))
                        {
                            if (parameters.ContainsKey(RemoteCommander.ParameterFilePaths))
                            {
                                SearchTypes searchType = (SearchTypes)Convert.ToInt32(parameters[RemoteCommander.ParameterSearchType]);
                                string keyword = parameters[RemoteCommander.ParameterKeyword];
                                MatchTypes matchType = (MatchTypes)Convert.ToInt32(parameters[RemoteCommander.ParameterMatchType]);
                                string[] filePaths = parameters[RemoteCommander.ParameterFilePaths].Split(new string[] { RemoteCommander.FileItemSeparator }, StringSplitOptions.RemoveEmptyEntries);
                                WorkV6 work = new WorkV6();
                                work.WorkMode = WorkModes.Server;
                                SynchronizedDictionary<string, List<string>> sameFiles = new SynchronizedDictionary<string, List<string>>();
                                string key = "Default";
                                foreach (string file in filePaths)
                                {
                                    string item = file;
                                    int index = item.IndexOf(WorkUtils.ServerAddressSeparator);
                                    if (index != -1)
                                    {
                                        key = item.Substring(0, index);
                                        item = item.Substring(index + 1);
                                    }
                                    if (!sameFiles.ContainsKey(key))
                                        sameFiles.Add(key, new List<string>());
                                    sameFiles[key].Add(item);
                                }
                                Dictionary<string, MatchFileItem> matchFiles = work.Find(sameFiles, null, keyword, searchType, matchType);

                                Dictionary<string, List<string>> files = new Dictionary<string, List<string>>();
                                foreach (KeyValuePair<string, MatchFileItem> item in matchFiles)
                                {
                                    if (!files.ContainsKey(item.Key))
                                        files.Add(item.Key, new List<string>());
                                    foreach (BasicFileInfo file in item.Value.MatchFiles)
                                    {
                                        files[item.Key].Add(file.FileName);
                                    }
                                }
                                StringBuilder result = new StringBuilder();
                                result.Append(RemoteCommander.ParameterFilePaths + RemoteCommander.KeyValueSeparator);
                                //todo:might be huge result
                                foreach (KeyValuePair<string, List<string>> item in files)
                                {
                                    result.Append(item.Key + RemoteCommander.FileItemSeparator);
                                    foreach (string file in item.Value)
                                    {
                                        result.Append(file + RemoteCommander.FileItemSeparator);
                                    }
                                    result.Append(RemoteCommander.FileGroupSeparator);
                                }
                                response = RemoteCommander.BuildCommand(RemoteCommander.CommandMatch, result.ToString());

                                LocalHashStorage.Instance.Flush();
                                LocalFileContentIndexStorage.Instance.Flush();
                                LocalNTFSStorage.Instance.Flush();
                            }
                            else
                                response = RemoteCommander.BuildCommand(RemoteCommander.CommandNoData, string.Empty);
                        }
                        else
                            response = RemoteCommander.BuildCommand(RemoteCommander.CommandAccessDenied, string.Empty);
                        break;
                    default:
                        response = RemoteCommander.BuildCommand(RemoteCommander.CommandNoCommand, string.Empty);
                        break;
                }
            }
            return response;
        }
    }

    /// <summary>
    /// accept access from remote computers to search file with http
    /// </summary>
    public class WorkV6HTTPManager : BaseV6Manager
    {
        private HttpListener listener = null;
        private bool finished = false;

        public override void Start(int Port)
        {
            base.Start(Port);
            if (HttpListener.IsSupported)
            {
                try
                {
                    listener = new HttpListener();
                    listener.Prefixes.Add(string.Format("http://*:{0}/", Port));
                    listener.Start();
                    OnProgress(WorkProgressTypes.Network, "listener started");
                    while (!finished)
                    {
                        HttpListenerContext context = listener.GetContext();
                        HttpListenerRequest request = context.Request;
                        byte[] buffer = WorkUtils.ReadHTTPStreamContent(request.InputStream);
                        DataTransferEventArgs e = new DataTransferEventArgs(null, buffer);
                        OnRequest(e);
                        switch (e.Cancel)
                        {
                            case CancelModes.None:
                                buffer = ProcessRequest(buffer);
                                using (Stream writer = context.Response.OutputStream)
                                {
                                    buffer = WorkUtils.CompressBuffer(buffer);
                                    writer.Write(buffer, 0, buffer.Length);
                                    writer.Write(WorkUtils.DataEndings, 0, WorkUtils.DataEndings.Length);
                                    writer.Flush();
                                }
                                context.Response.OutputStream.Close();
                                break;
                            case CancelModes.CancelRequest:
                                break;
                            case CancelModes.Shutdown:
                                finished = true;
                                break;
                            default:
                                break;
                        }
                    }
                    listener.Close();
                }
                catch (Exception ex)
                {
                    OnProgress(WorkProgressTypes.Network, ex.ToString());
                }
            }
            else
                OnProgress(WorkProgressTypes.Network, "HTTP Listener is not supported.");
        }

        ~WorkV6HTTPManager()
        {
            Close();
        }

        public override void Close()
        {
            OnProgress(WorkProgressTypes.Network, "listener closed");
        }

    }

    /// <summary>
    /// accept access from remote computers to search file with tcp
    /// </summary>
    public class WorkV6TCPManager : BaseV6Manager
    {
        private AsynchronousSocketListener listener = null;

        public override void Start(int Port)
        {
            base.Start(Port);
            listener = new AsynchronousSocketListener();
            listener.Connected += new EventHandler<DataTransferEventArgs>(OnListenerConnected);
            listener.Received += new EventHandler<DataTransferEventArgs>(OnListenerReceived);
            listener.Sent += new EventHandler<DataTransferEventArgs>(OnListenerSent);
            listener.Failed += new EventHandler<DataTransferEventArgs>(OnListenerFailed);
            OnProgress(WorkProgressTypes.Network, "listener starting");
            listener.Start(Port);
        }

        ~WorkV6TCPManager()
        {
            Close();
        }

        public override void Close()
        {
            listener.Close();
            OnProgress(WorkProgressTypes.Network, "listener closed");
        }

        private void OnListenerFailed(object sender, DataTransferEventArgs e)
        {
            OnProgress(WorkProgressTypes.Network, "Failed:" + e.Content);
        }

        private void OnListenerSent(object sender, DataTransferEventArgs e)
        {
            e.Worker.Receive();
        }

        private void OnListenerReceived(object sender, DataTransferEventArgs e)
        {
            OnRequest(e);
            switch (e.Cancel)
            {
                case CancelModes.None:
                    e.Buffer = ProcessRequest(e.Buffer);
                    break;
                case CancelModes.CancelRequest:
                    break;
                case CancelModes.Shutdown:
                    listener.Close();
                    break;
                default:
                    break;
            }
        }

        private void OnListenerConnected(object sender, DataTransferEventArgs e)
        {
            OnProgress(WorkProgressTypes.Network, "client connected from:" + e.Content);
        }
    }

    /// <summary>
    /// use multi-thread for file search, on-demand multi-thread for hash according to disk drive
    /// </summary>
    public class WorkV6 : BaseWork
    {
        private const int MaxWorkers = 5;
        private const string DefaultDrive = "[Default]";

        public override Dictionary<string, MatchFileItem> Find(FileURI[] FilePaths, string[] IncludesFileTypes, string Keyword, SearchTypes SearchType, MatchTypes MatchType)
        {
            SynchronizedDictionary<string, List<string>> sameFiles = new SynchronizedDictionary<string, List<string>>();
            List<WorkV6FindFileRunner> findFileRunners = new List<WorkV6FindFileRunner>();
            int step = FilePaths.Length / MaxWorkers;
            if (step == 0)
                step = 1;
            if (FilePaths.Length % step != 0)
                step++;
            for (int i = 0; i < FilePaths.Length; i += step)
            {
                FileURI[] parts = new FileURI[step];
                Array.Copy(FilePaths, i, parts, 0, step);
                WorkV6FindFileRunner runner = new WorkV6FindFileRunner(parts, this, IncludesFileTypes, Keyword, SearchType, MatchType, sameFiles);
                findFileRunners.Add(runner);
            }
            ParallelProcessor.ExecuteParallel(findFileRunners.ToArray());
            return Find(sameFiles, FilePaths, Keyword, SearchType, MatchType);
        }

        public Dictionary<string, MatchFileItem> Find(SynchronizedDictionary<string, List<string>> SameFiles, FileURI[] FilePaths, string Keyword, SearchTypes SearchType, MatchTypes MatchType)
        {
            Dictionary<string, MatchFileItem> result = new Dictionary<string, MatchFileItem>();
            if (MatchType != MatchTypes.InfoSame)
            {
                Dictionary<string, string> drivePartitionMappings = new Dictionary<string, string>();
                int hashCount = 0;

#if (DRIVEID)
                if (WorkSettings.Instance.EnableDriveIdentification)
                {
                    try
                    {
                        /*using (ManagementClass devs = new ManagementClass(@"Win32_Diskdrive"))
                        {
                            ManagementObjectCollection moc = devs.GetInstances();
                            foreach (ManagementObject mo in moc)
                            {
                                string drive = mo["DeviceId"].ToString();
                                foreach (ManagementObject b in mo.GetRelated("Win32_DiskPartition"))
                                {
                                    foreach (ManagementBaseObject c in b.GetRelated("Win32_LogicalDisk"))
                                    {
                                        string partition = c["Name"].ToString();
                                        drivePartitionMappings.Add(partition.ToLower(), drive.ToLower());
                                    }
                                }
                            }
                        }*/

                        //faster, but still slow, might take up to 10 seconds(I don't know what happended).
                        //I could use Win32 API to quickly get the result, but it is ideally NOT to use Win32 API by yourself...
                        ObjectQuery query = new ObjectQuery("select * from Win32_DiskPartition");
                        ManagementObjectSearcher searcher = new
                        ManagementObjectSearcher(query);
                        ManagementObjectCollection drives = searcher.Get();
                        foreach (ManagementObject current in drives)
                        {
                            string drive = current["deviceid"].ToString();
                            int index = drive.IndexOf(",");
                            if (index != -1)
                                drive = drive.Substring(0, index);
                            ObjectQuery associators = new ObjectQuery("ASSOCIATORS OF {Win32_DiskPartition.DeviceID=\"" + current["deviceid"] + "\"} where assocclass=Win32_LogicalDiskToPartition");
                            searcher = new ManagementObjectSearcher(associators);
                            ManagementObjectCollection disks = searcher.Get();
                            foreach (ManagementObject disk in disks)
                            {
                                string partition = disk["deviceid"].ToString();
                                drivePartitionMappings.Add(partition.ToLower() + @"\", drive.ToLower());
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        OnProgress(WorkProgressTypes.FileAccess, "Could not get drive partition mappings through WMI:" + ex.ToString());
                    }
                }
#endif
                SynchronizedDictionary<string, List<string>> sameGroupFiles = new SynchronizedDictionary<string, List<string>>();
                foreach (List<string> item in SameFiles.Values)
                {
                    if (item.Count > 1 || WorkMode == WorkModes.Server)
                    {
                        foreach (string file in item)
                        {
                            string partition;
                            if (file.IndexOf(WorkUtils.ServerAddressSeparator) != -1)
                            {
                                string address;
                                int port;
                                WorkUtils.ParseAddressPort(file, out address, out port);
                                partition = address + WorkUtils.ServerAddressSeparator + port;
                                if (!drivePartitionMappings.ContainsKey(partition))
                                    drivePartitionMappings.Add(partition, partition);
                            }
                            else
                                partition = Path.GetPathRoot(file).ToLower();
                            string drive;
                            if (drivePartitionMappings.ContainsKey(partition))
                                drive = drivePartitionMappings[partition];
                            else
                                drive = DefaultDrive;
                            if (!sameGroupFiles.ContainsKey(drive))
                                sameGroupFiles.Add(drive, new List<string>());
                            sameGroupFiles[drive].Add(file);
                        }
                    }
                }

                SynchronizedDictionary<string, MatchFileItem> matchFiles = new SynchronizedDictionary<string, MatchFileItem>();
                List<WorkV6FindResultRunner> findResultRunners = new List<WorkV6FindResultRunner>();
                Dictionary<string, FileURI> fileAccess = new Dictionary<string, FileURI>();
                if (FilePaths != null)
                {
                    foreach (FileURI item in FilePaths)
                    {
                        string address;
                        int port;
                        WorkUtils.ParseAddressPort(item.Uri, out address, out port);
                        if (!string.IsNullOrEmpty(address) && port > 0)
                        {
                            string key = address + WorkUtils.ServerAddressSeparator + port;
                            if (!fileAccess.ContainsKey(key))
                                fileAccess.Add(key, item);
                        }
                    }
                }
                foreach (string item in sameGroupFiles.Keys)
                {
                    WorkV6FindResultRunner runner = new WorkV6FindResultRunner(sameGroupFiles[item], fileAccess.ContainsKey(item) ? fileAccess[item] : null, Keyword, SearchType, MatchType, this, matchFiles);
                    findResultRunners.Add(runner);
                }
                ParallelProcessor.ExecuteParallel(findResultRunners.ToArray());
                foreach (WorkV6FindResultRunner runner in findResultRunners)
                {
                    hashCount += runner.MatchCount;
                }

                OnProgress(WorkProgressTypes.Detail, "hash count:" + hashCount);

                foreach (string item in matchFiles.Keys)
                {
                    result.Add(item, matchFiles[item]);
                }
                LocalHashStorage.Instance.Flush();
                LocalFileContentIndexStorage.Instance.Flush();
                LocalNTFSStorage.Instance.Flush();
            }
            else
            {
                foreach (string key in SameFiles.Keys)
                {
                    List<string> item = SameFiles[key];
                    if (item.Count > 1 || WorkMode == WorkModes.Server)
                    {
                        MatchFileItem matchFile = new MatchFileItem();
                        foreach (string file in item)
                        {
                            matchFile.MatchFiles.Add(WorkUtils.GetFileInfo(file));
                        }
                        result.Add(key, matchFile);
                    }
                }
            }
            return result;
        }

        public override List<BasicFileInfo> DeleteAll(List<BasicFileInfo> Files, FileURI[] FilePaths)
        {
            SynchronizedDictionary<string, List<BasicFileInfo>> sameGroupFiles = new SynchronizedDictionary<string, List<BasicFileInfo>>();
            foreach (BasicFileInfo file in Files)
            {
                string group;
                if (file.FileName.IndexOf(WorkUtils.ServerAddressSeparator) != -1)
                {
                    string address;
                    int port;
                    WorkUtils.ParseAddressPort(file.FileName, out address, out port);
                    group = address + WorkUtils.ServerAddressSeparator + port;
                }
                else
                    group = DefaultDrive;
                if (!sameGroupFiles.ContainsKey(group))
                    sameGroupFiles.Add(group, new List<BasicFileInfo>());
                sameGroupFiles[group].Add(file);
            }

            Dictionary<string, FileURI> fileAccess = new Dictionary<string, FileURI>();
            foreach (FileURI item in FilePaths)
            {
                string address;
                int port;
                WorkUtils.ParseAddressPort(item.Uri, out address, out port);
                if (!string.IsNullOrEmpty(address) && port > 0)
                {
                    string key = address + WorkUtils.ServerAddressSeparator + port;
                    if (!fileAccess.ContainsKey(key))
                        fileAccess.Add(key, item);
                }
            }

            SynchronizedDictionary<string, BasicFileInfo> result = new SynchronizedDictionary<string, BasicFileInfo>();
            List<WorkV6DeleteResultRunner> deleteResultRunners = new List<WorkV6DeleteResultRunner>();
            foreach (string item in sameGroupFiles.Keys)
            {
                WorkV6DeleteResultRunner runner = new WorkV6DeleteResultRunner(sameGroupFiles[item], fileAccess.ContainsKey(item) ? fileAccess[item] : null, this, result);
                deleteResultRunners.Add(runner);
            }
            ParallelProcessor.ExecuteParallel(deleteResultRunners.ToArray());
            List<BasicFileInfo> deletedFiles = new List<BasicFileInfo>();
            foreach (BasicFileInfo item in result.Values)
            {
                deletedFiles.Add(item);
            }
            return deletedFiles;
        }
    }
    #endregion


    #region WorkV5
    public class WorkV5FindFileRunner : IParallelWorker
    {
        private string[] filePaths;
        private BaseWork worker;
        private string[] includesFileTypes;
        private SearchTypes duplicateType;
        private SynchronizedDictionary<string, List<string>> sameFiles;
        public WorkV5FindFileRunner(string[] FilePaths, BaseWork Worker, string[] IncludesFileTypes, SearchTypes DuplicateType, SynchronizedDictionary<string, List<string>> SameFiles)
        {
            filePaths = FilePaths;
            worker = Worker;
            includesFileTypes = IncludesFileTypes;
            duplicateType = DuplicateType;
            sameFiles = SameFiles;
        }

        public void Run()
        {
            foreach (string path in filePaths)
            {
                Find(path, includesFileTypes, duplicateType, sameFiles);
            }
        }

        private void Find(string FilePath, string[] IncludesFileTypes, SearchTypes DuplicateType, SynchronizedDictionary<string, List<string>> Result)
        {
            if (!string.IsNullOrEmpty(FilePath) && Directory.Exists(FilePath))
            {
                string[] items = Directory.GetDirectories(FilePath);
                foreach (string folder in items)
                {
                    Find(folder, IncludesFileTypes, DuplicateType, Result);
                }
                items = Directory.GetFiles(FilePath);
                foreach (string item in items)
                {
                    bool found;
                    if (IncludesFileTypes != null && IncludesFileTypes.Length > 0)
                    {
                        found = false;
                        foreach (string fileType in IncludesFileTypes)
                        {
                            if (WorkUtils.MatchFileType(item, fileType))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    else
                        found = true;
                    if (found)
                    {
                        string key = WorkUtils.GetInfoKey(item, DuplicateType);
                        if (!Result.ContainsKey(key))
                            Result.Add(key, new List<string>());
                        Result[key].Add(item);
                    }
                }
            }
        }
    }

    public class WorkV5FindResultRunner : IParallelWorker
    {
        private List<string> files;
        private BaseWork worker;
        private SynchronizedDictionary<string, MatchFileItem> result;
        public WorkV5FindResultRunner(List<string> Files, BaseWork Worker, SynchronizedDictionary<string, MatchFileItem> Result)
        {
            files = Files;
            worker = Worker;
            result = Result;
        }

        private int hashCount = 0;
        public int HashCount
        {
            get { return hashCount; }
        }

        public void Run()
        {
            worker.OnProgress(WorkProgressTypes.Detail, "find result work runner start:" + DateTime.Now);
            foreach (string file in files)
            {
                string hash = WorkUtils.HashMD5File(file);
                hashCount++;
                if (!result.ContainsKey(hash))
                    result.Add(hash, new MatchFileItem());
                MatchFileItem duplicate = result[hash] as MatchFileItem;
                duplicate.MatchFiles.Add(WorkUtils.GetFileInfo(file));
                if (duplicate.MatchFiles.Count > 1)
                    worker.OnProgress(hash, duplicate.MatchFiles);
            }
            worker.OnProgress(WorkProgressTypes.Detail, "find result work runner end:" + DateTime.Now + " hashing " + hashCount);
        }
    }

    /// <summary>
    /// use multi-thread for file search, on-demand multi-thread for hash according to disk drive
    /// </summary>
    public class WorkV5 : BaseWork
    {
        private const int MaxWorkers = 5;
        private const string DefaultDrive = "[Default]";

        public override Dictionary<string, MatchFileItem> Find(FileURI[] FilePaths, string[] IncludesFileTypes, string Keyword, SearchTypes SearchType, MatchTypes MatchType)
        {
            SynchronizedDictionary<string, List<string>> sameFiles = new SynchronizedDictionary<string, List<string>>();
            List<WorkV5FindFileRunner> findFileRunners = new List<WorkV5FindFileRunner>();
            int step = FilePaths.Length / MaxWorkers;
            if (step == 0)
                step = 1;
            if (FilePaths.Length % step != 0)
                step++;
            for (int i = 0; i < FilePaths.Length; i += step)
            {
                string[] parts = new string[step];
                for (int j = 0; j < step; j++)
                {
                    parts[j] = FilePaths[i + j].Uri;
                }
                WorkV5FindFileRunner runner = new WorkV5FindFileRunner(parts, this, IncludesFileTypes, SearchType, sameFiles);
                findFileRunners.Add(runner);
            }
            ParallelProcessor.ExecuteParallel(findFileRunners.ToArray());
            return Find(sameFiles, SearchType, MatchType);
        }

        private Dictionary<string, MatchFileItem> Find(SynchronizedDictionary<string, List<string>> SameFiles, SearchTypes SearchType, MatchTypes MatchType)
        {
            Dictionary<string, MatchFileItem> result = new Dictionary<string, MatchFileItem>();
            if (MatchType != MatchTypes.InfoSame)
            {
                Dictionary<string, string> drivePartitionMappings = new Dictionary<string, string>();
                int hashCount = 0;

#if (DRIVEID)
                if (WorkSettings.Instance.EnableDriveIdentification)
                {
                    try
                    {
                        /*using (ManagementClass devs = new ManagementClass(@"Win32_Diskdrive"))
                        {
                            ManagementObjectCollection moc = devs.GetInstances();
                            foreach (ManagementObject mo in moc)
                            {
                                string drive = mo["DeviceId"].ToString();
                                foreach (ManagementObject b in mo.GetRelated("Win32_DiskPartition"))
                                {
                                    foreach (ManagementBaseObject c in b.GetRelated("Win32_LogicalDisk"))
                                    {
                                        string partition = c["Name"].ToString();
                                        drivePartitionMappings.Add(partition.ToLower(), drive.ToLower());
                                    }
                                }
                            }
                        }*/

                        //faster, but still slow, might take up to 10 seconds(I don't know what happended).
                        //I could use Win32 API to quickly get the result, but it is ideally NOT to use Win32 API by yourself...
                        ObjectQuery query = new ObjectQuery("select * from Win32_DiskPartition");
                        ManagementObjectSearcher searcher = new
                        ManagementObjectSearcher(query);
                        ManagementObjectCollection drives = searcher.Get();
                        foreach (ManagementObject current in drives)
                        {
                            string drive = current["deviceid"].ToString();
                            int index = drive.IndexOf(",");
                            if (index != -1)
                                drive = drive.Substring(0, index);
                            ObjectQuery associators = new ObjectQuery("ASSOCIATORS OF {Win32_DiskPartition.DeviceID=\"" + current["deviceid"] + "\"} where assocclass=Win32_LogicalDiskToPartition");
                            searcher = new ManagementObjectSearcher(associators);
                            ManagementObjectCollection disks = searcher.Get();
                            foreach (ManagementObject disk in disks)
                            {
                                string partition = disk["deviceid"].ToString();
                                drivePartitionMappings.Add(partition.ToLower() + @"\", drive.ToLower());
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        OnProgress(WorkProgressTypes.FileAccess, "Could not get drive partition mappings through WMI:" + ex.ToString());
                    }
                }
#endif
                bool useIdentification;
                SynchronizedDictionary<string, List<string>> sameDriveFiles = new SynchronizedDictionary<string, List<string>>();
                if (WorkSettings.Instance.EnableDriveIdentification && drivePartitionMappings.Count > 0)
                {
                    foreach (List<string> item in SameFiles.Values)
                    {
                        if (item.Count > 1)
                        {
                            foreach (string file in item)
                            {
                                string partition = Path.GetPathRoot(file).ToLower();
                                string drive;
                                if (drivePartitionMappings.ContainsKey(partition))
                                    drive = drivePartitionMappings[partition];
                                else
                                    drive = DefaultDrive;
                                if (!sameDriveFiles.ContainsKey(drive))
                                    sameDriveFiles.Add(drive, new List<string>());
                                sameDriveFiles[drive].Add(file);
                            }
                        }
                    }
                    useIdentification = sameDriveFiles.Count > 1;
                }
                else
                    useIdentification = false;
                if (useIdentification)
                {
                    SynchronizedDictionary<string, MatchFileItem> duplicates = new SynchronizedDictionary<string, MatchFileItem>();
                    List<WorkV5FindResultRunner> findResultRunners = new List<WorkV5FindResultRunner>();
                    foreach (List<string> item in sameDriveFiles.Values)
                    {
                        WorkV5FindResultRunner runner = new WorkV5FindResultRunner(item, this, duplicates);
                        findResultRunners.Add(runner);
                    }
                    ParallelProcessor.ExecuteParallel(findResultRunners.ToArray());
                    foreach (WorkV5FindResultRunner runner in findResultRunners)
                    {
                        hashCount += runner.HashCount;
                    }

                    OnProgress(WorkProgressTypes.Detail, "hash count:" + hashCount);

                    foreach (string item in duplicates.Keys)
                    {
                        result.Add(item, duplicates[item]);
                    }
                }
                else
                {
                    foreach (string key in SameFiles.Keys)
                    {
                        List<string> item = SameFiles[key];
                        if (item.Count > 1)
                        {
                            foreach (string file in item)
                            {
                                string hash = WorkUtils.HashMD5File(file);
                                hashCount++;
                                if (!result.ContainsKey(hash))
                                    result.Add(hash, new MatchFileItem());
                                result[hash].MatchFiles.Add(WorkUtils.GetFileInfo(file));
                                if (result[hash].MatchFiles.Count > 1)
                                    OnProgress(hash, result[hash].MatchFiles);
                            }
                        }
                    }
                }
                OnProgress(WorkProgressTypes.Detail, "hash count:" + hashCount);
            }
            else
            {
                foreach (string key in SameFiles.Keys)
                {
                    List<string> item = SameFiles[key];
                    if (item.Count > 1)
                    {
                        MatchFileItem duplicate = new MatchFileItem();
                        foreach (string file in item)
                        {
                            duplicate.MatchFiles.Add(WorkUtils.GetFileInfo(file));
                        }
                        result.Add(key, duplicate);
                    }
                }
            }
            return result;
        }
    }
    #endregion


    #region WorkV4
    public class WorkV4FindFileRunner : IParallelWorker
    {
        private string[] filePaths;
        private BaseWork worker;
        private string[] includesFileTypes;
        private SearchTypes duplicateType;
        private SynchronizedDictionary<string, List<string>> sameFiles;
        public WorkV4FindFileRunner(string[] FilePaths, BaseWork Worker, string[] IncludesFileTypes, SearchTypes DuplicateType, SynchronizedDictionary<string, List<string>> SameFiles)
        {
            filePaths = FilePaths;
            worker = Worker;
            includesFileTypes = IncludesFileTypes;
            duplicateType = DuplicateType;
            sameFiles = SameFiles;
        }

        public void Run()
        {
            foreach (string path in filePaths)
            {
                Find(path, includesFileTypes, duplicateType, sameFiles);
            }
        }

        private void Find(string FilePath, string[] IncludesFileTypes, SearchTypes DuplicateType, SynchronizedDictionary<string, List<string>> Result)
        {
            if (!string.IsNullOrEmpty(FilePath) && Directory.Exists(FilePath))
            {
                string[] items = Directory.GetDirectories(FilePath);
                foreach (string folder in items)
                {
                    Find(folder, IncludesFileTypes, DuplicateType, Result);
                }
                items = Directory.GetFiles(FilePath);
                foreach (string item in items)
                {
                    bool found;
                    if (IncludesFileTypes != null && IncludesFileTypes.Length > 0)
                    {
                        found = false;
                        foreach (string fileType in IncludesFileTypes)
                        {
                            if (WorkUtils.MatchFileType(item, fileType))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    else
                        found = true;
                    if (found)
                    {
                        string key = WorkUtils.GetInfoKey(item, DuplicateType);
                        if (!Result.ContainsKey(key))
                            Result.Add(key, new List<string>());
                        Result[key].Add(item);
                    }
                }
            }
        }
    }

    /// <summary>
    /// use multi-thread for file search only
    /// </summary>
    public class WorkV4 : BaseWork
    {
        private const int MaxWorkers = 5;

        public override Dictionary<string, MatchFileItem> Find(FileURI[] FilePaths, string[] IncludesFileTypes, string Keyword, SearchTypes SearchType, MatchTypes MatchType)
        {
            SynchronizedDictionary<string, List<string>> sameFiles = new SynchronizedDictionary<string, List<string>>();
            List<WorkV4FindFileRunner> findFileRunners = new List<WorkV4FindFileRunner>();
            int step = FilePaths.Length / MaxWorkers;
            if (step == 0)
                step = 1;
            if (FilePaths.Length % step != 0)
                step++;
            for (int i = 0; i < FilePaths.Length; i += step)
            {
                string[] parts = new string[step];
                for (int j = 0; j < step; j++)
                {
                    parts[j] = FilePaths[i + j].Uri;
                }
                WorkV4FindFileRunner runner = new WorkV4FindFileRunner(parts, this, IncludesFileTypes, SearchType, sameFiles);
                findFileRunners.Add(runner);
            }
            ParallelProcessor.ExecuteParallel(findFileRunners.ToArray());
            return Find(sameFiles);
        }

        private Dictionary<string, MatchFileItem> Find(SynchronizedDictionary<string, List<string>> SameFiles)
        {
            Dictionary<string, MatchFileItem> result = new Dictionary<string, MatchFileItem>();
            int hashCount = 0;

            foreach (string key in SameFiles.Keys)
            {
                List<string> item = SameFiles[key];
                if (item.Count > 1)
                {
                    foreach (string file in item)
                    {
                        string hash = WorkUtils.HashMD5File(file);
                        hashCount++;
                        if (!result.ContainsKey(hash))
                            result.Add(hash, new MatchFileItem());
                        result[hash].MatchFiles.Add(WorkUtils.GetFileInfo(file));
                        if (result[hash].MatchFiles.Count > 1)
                            OnProgress(hash, result[hash].MatchFiles);
                    }
                }
            }
            OnProgress(WorkProgressTypes.Detail, "hash count:" + hashCount);
            return result;
        }
    }
    #endregion


    #region WorkV3
    public class WorkV3FindResultRunner : IParallelWorker
    {
        private List<string>[] files;
        private BaseWork worker;
        private SynchronizedDictionary<string, MatchFileItem> result;
        public WorkV3FindResultRunner(List<string>[] Files, BaseWork Worker, SynchronizedDictionary<string, MatchFileItem> Result)
        {
            files = Files;
            worker = Worker;
            result = Result;
        }

        private int hashCount = 0;
        public int HashCount
        {
            get { return hashCount; }
        }

        public void Run()
        {
            worker.OnProgress(WorkProgressTypes.Detail, "find result work runner start:" + DateTime.Now);
            foreach (List<string> item in files)
            {
                if (item.Count > 1)
                {
                    foreach (string file in item)
                    {
                        string hash = WorkUtils.HashMD5File(file);
                        hashCount++;
                        if (!result.ContainsKey(hash))
                            result.Add(hash, new MatchFileItem());
                        MatchFileItem duplicate = result[hash] as MatchFileItem;
                        duplicate.MatchFiles.Add(WorkUtils.GetFileInfo(file));
                        if (duplicate.MatchFiles.Count > 1)
                            worker.OnProgress(hash, duplicate.MatchFiles);
                    }
                }
            }
            worker.OnProgress(WorkProgressTypes.Detail, "find result work runner end:" + DateTime.Now + " hashing " + hashCount);
        }
    }

    public class WorkV3FindFileRunner : IParallelWorker
    {
        private string[] filePaths;
        private BaseWork worker;
        private string[] includesFileTypes;
        private SearchTypes duplicateType;
        private SynchronizedDictionary<string, List<string>> sameFiles;
        public WorkV3FindFileRunner(string[] FilePaths, BaseWork Worker, string[] IncludesFileTypes, SearchTypes DuplicateType, SynchronizedDictionary<string, List<string>> SameFiles)
        {
            filePaths = FilePaths;
            worker = Worker;
            includesFileTypes = IncludesFileTypes;
            duplicateType = DuplicateType;
            sameFiles = SameFiles;
        }

        public void Run()
        {
            foreach (string path in filePaths)
            {
                Find(path, includesFileTypes, duplicateType, sameFiles);
            }
        }

        private void Find(string FilePath, string[] IncludesFileTypes, SearchTypes DuplicateType, SynchronizedDictionary<string, List<string>> Result)
        {
            if (!string.IsNullOrEmpty(FilePath) && Directory.Exists(FilePath))
            {
                string[] items = Directory.GetDirectories(FilePath);
                foreach (string folder in items)
                {
                    Find(folder, IncludesFileTypes, DuplicateType, Result);
                }
                items = Directory.GetFiles(FilePath);
                foreach (string item in items)
                {
                    bool found;
                    if (IncludesFileTypes != null && IncludesFileTypes.Length > 0)
                    {
                        found = false;
                        foreach (string fileType in IncludesFileTypes)
                        {
                            if (WorkUtils.MatchFileType(item, fileType))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    else
                        found = true;
                    if (found)
                    {
                        string key = WorkUtils.GetInfoKey(item, DuplicateType);
                        if (!Result.ContainsKey(key))
                            Result.Add(key, new List<string>());
                        Result[key].Add(item);
                    }
                }
            }
        }
    }

    /// <summary>
    /// use multi-thread for file search and hash
    /// </summary>
    public class WorkV3 : BaseWork
    {
        private const int MaxWorkers = 5;

        public override Dictionary<string, MatchFileItem> Find(FileURI[] FilePaths, string[] IncludesFileTypes, string Keyword, SearchTypes SearchType, MatchTypes MatchType)
        {
            SynchronizedDictionary<string, List<string>> sameFiles = new SynchronizedDictionary<string, List<string>>();
            List<WorkV3FindFileRunner> findFileRunners = new List<WorkV3FindFileRunner>();
            int step = FilePaths.Length / MaxWorkers;
            if (step == 0)
                step = 1;
            if (FilePaths.Length % step != 0)
                step++;
            for (int i = 0; i < FilePaths.Length; i += step)
            {
                string[] parts = new string[step];
                for (int j = 0; j < step; j++)
                {
                    parts[j] = FilePaths[i + j].Uri;
                }
                WorkV3FindFileRunner runner = new WorkV3FindFileRunner(parts, this, IncludesFileTypes, SearchType, sameFiles);
                findFileRunners.Add(runner);
            }
            ParallelProcessor.ExecuteParallel(findFileRunners.ToArray());
            return Find(sameFiles);
        }

        private Dictionary<string, MatchFileItem> Find(SynchronizedDictionary<string, List<string>> SameFiles)
        {
            Dictionary<string, MatchFileItem> result = new Dictionary<string, MatchFileItem>();
            SynchronizedDictionary<string, MatchFileItem> duplicates = new SynchronizedDictionary<string, MatchFileItem>();
            List<string>[] pendings = new List<string>[SameFiles.Count];
            int index = 0;
            foreach (string item in SameFiles.Keys)
            {
                pendings[index] = SameFiles[item];
                index++;
            }
            int step = pendings.Length / MaxWorkers;
            if (step == 0)
                step = 1;
            if (pendings.Length % step != 0)
                step++;
            List<WorkV3FindResultRunner> findResultRunners = new List<WorkV3FindResultRunner>();
            for (int i = 0; i < pendings.Length; i += step)
            {
                if (i + step >= pendings.Length)
                    step = pendings.Length - i;
                List<string>[] parts = new List<string>[step];
                Array.Copy(pendings, i, parts, 0, step);
                WorkV3FindResultRunner runner = new WorkV3FindResultRunner(parts, this, duplicates);
                findResultRunners.Add(runner);
            }
            ParallelProcessor.ExecuteParallel(findResultRunners.ToArray());

            int toalHashCount = 0;
            foreach (WorkV3FindResultRunner runner in findResultRunners)
            {
                toalHashCount += runner.HashCount;
            }
            OnProgress(WorkProgressTypes.Detail, "hash count:" + toalHashCount);
            foreach (string item in duplicates.Keys)
            {
                result.Add(item, duplicates[item]);
            }

            return result;
        }
    }
    #endregion


    #region WorkV2
    /// <summary>
    /// no multi-thread, but with size filter first
    /// </summary>
    public class WorkV2 : BaseWork
    {
        public override Dictionary<string, MatchFileItem> Find(FileURI[] FilePaths, string[] IncludesFileTypes, string Keyword, SearchTypes SearchType, MatchTypes MatchType)
        {
            Dictionary<string, List<string>> sameFiles = new Dictionary<string, List<string>>();
            foreach (FileURI path in FilePaths)
            {
                Find(path.Uri, IncludesFileTypes, SearchType, sameFiles);
            }
            return Find(sameFiles);
        }

        private Dictionary<string, MatchFileItem> Find(Dictionary<string, List<string>> SameFiles)
        {
            Dictionary<string, MatchFileItem> result = new Dictionary<string, MatchFileItem>();
            int hashCount = 0;
            foreach (KeyValuePair<string, List<string>> item in SameFiles)
            {
                if (item.Value.Count > 1)
                {
                    foreach (string file in item.Value)
                    {
                        string hash = WorkUtils.HashMD5File(file);
                        hashCount++;
                        if (!result.ContainsKey(hash))
                            result.Add(hash, new MatchFileItem());
                        result[hash].MatchFiles.Add(WorkUtils.GetFileInfo(file));
                        if (result[hash].MatchFiles.Count > 1)
                            OnProgress(hash, result[hash].MatchFiles);
                    }
                }
            }
            OnProgress(WorkProgressTypes.Detail, "hash count:" + hashCount);
            return result;
        }

        private void Find(string FilePath, string[] IncludesFileTypes, SearchTypes DuplicateType, Dictionary<string, List<string>> Result)
        {
            if (!string.IsNullOrEmpty(FilePath) && Directory.Exists(FilePath))
            {
                string[] items = Directory.GetDirectories(FilePath);
                foreach (string folder in items)
                {
                    Find(folder, IncludesFileTypes, DuplicateType, Result);
                }
                items = Directory.GetFiles(FilePath);
                foreach (string item in items)
                {
                    bool found;
                    if (IncludesFileTypes != null && IncludesFileTypes.Length > 0)
                    {
                        found = false;
                        foreach (string fileType in IncludesFileTypes)
                        {
                            if (WorkUtils.MatchFileType(item, fileType))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    else
                        found = true;
                    if (found)
                    {
                        string key = WorkUtils.GetInfoKey(item, DuplicateType);
                        if (!Result.ContainsKey(key))
                            Result.Add(key, new List<string>());
                        Result[key].Add(item);
                    }
                }
            }
        }
    }
    #endregion


    #region WorkV1
    /// <summary>
    /// no multi-thread, no size filter
    /// </summary>
    public class WorkV1 : BaseWork //don't use this because it's slow:)
    {
        public override List<BasicFileInfo> FindAll(Dictionary<string, MatchFileItem> Result, string DuplicateFolder)
        {
            List<BasicFileInfo> files = new List<BasicFileInfo>();
            foreach (KeyValuePair<string, MatchFileItem> item in Result)
            {
                if (item.Value.MatchFiles.Count > 1)
                {
                    for (int i = 0; i < item.Value.MatchFiles.Count; i++)
                    {
                        if (string.IsNullOrEmpty(item.Value.OriginalFile.FileName))
                        {
                            if (!WorkUtils.MatchContains(item.Value.MatchFiles[i].FileName, DuplicateFolder))
                                item.Value.OriginalFile = item.Value.MatchFiles[i];
                        }
                        if ((!string.IsNullOrEmpty(item.Value.OriginalFile.FileName) && item.Value.MatchFiles[i] != item.Value.OriginalFile)
                            || (string.IsNullOrEmpty(DuplicateFolder) && i > 0)
                            || (WorkUtils.MatchContains(item.Value.MatchFiles[i].FileName, DuplicateFolder)))
                            files.Add(item.Value.MatchFiles[i]);
                    }
                    //make sure the original is there
                    if (string.IsNullOrEmpty(item.Value.OriginalFile.FileName))
                    {
                        item.Value.OriginalFile = item.Value.MatchFiles[0];
                        item.Value.MatchFiles.RemoveAt(0);
                        files.Remove(item.Value.OriginalFile);
                    }
                }
            }
            return files;
        }

        public override Dictionary<string, MatchFileItem> Find(FileURI[] FilePaths, string[] IncludesFileTypes, string Keyword, SearchTypes SearchType, MatchTypes MatchType)
        {
            Dictionary<string, MatchFileItem> result = new Dictionary<string, MatchFileItem>();
            foreach (FileURI path in FilePaths)
            {
                Find(path.Uri, IncludesFileTypes, result);
            }
            return result;
        }

        private void Find(string FilePath, string[] IncludesFileTypes, Dictionary<string, MatchFileItem> Result)
        {
            if (!string.IsNullOrEmpty(FilePath) && Directory.Exists(FilePath))
            {
                string[] items = Directory.GetDirectories(FilePath);
                foreach (string folder in items)
                {
                    Find(folder, IncludesFileTypes, Result);
                }
                items = Directory.GetFiles(FilePath);
                foreach (string item in items)
                {
                    bool found;
                    if (IncludesFileTypes != null && IncludesFileTypes.Length > 0)
                    {
                        found = false;
                        foreach (string fileType in IncludesFileTypes)
                        {
                            if (WorkUtils.MatchFileType(item, fileType))
                            {
                                found = true;
                                break;
                            }
                        }
                    }
                    else
                        found = true;
                    if (found)
                    {
                        string hash = WorkUtils.HashMD5File(item);
                        if (!Result.ContainsKey(hash))
                            Result.Add(hash, new MatchFileItem());
                        Result[hash].MatchFiles.Add(WorkUtils.GetFileInfo(item));
                        if (Result[hash].MatchFiles.Count > 1)
                            OnProgress(hash, Result[hash].MatchFiles);
                    }
                }
            }
        }
    }
    #endregion

}
