﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace Xnlab.Filio
{
    class Program
    {
        static void Main(string[] args)
        {
            string mode = args.Length > 0 ? args[0] : string.Empty;
            new Tester(new KeyValuePair<string,string>(), new List<KeyValuePair<string,string>>()).Run(mode);
        }
    }

}