﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Filio")]
[assembly: AssemblyDescription("created by Wilson Chen (unruledboy@gmail.com) under LGPL v3")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Xnlab.com")]
[assembly: AssemblyProduct("Filio")]
[assembly: AssemblyCopyright("Copyright ©  2010")]
[assembly: AssemblyTrademark("Filio")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("2c66d3e7-fb5d-4658-b796-7c6cb94c2655")]

[assembly: AssemblyVersion("1.7.0.0")]
[assembly: AssemblyFileVersion("1.7.0.0")]
