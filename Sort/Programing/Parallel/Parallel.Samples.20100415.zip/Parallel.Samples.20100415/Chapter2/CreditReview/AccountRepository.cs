﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utilities;

using Customer = System.Int32;

namespace CreditReview
{
    using AccountRecord = KeyValuePair<Customer, Account>;
 
    /// <summary>
    /// Repository of customer accounts
    /// </summary>
    class AccountRepository
    {
        /// <summary>
        /// Repository is implemented by a dictionary from customer account numbers to account data,
        /// an array of monthly balances etc.
        /// </summary>
        Dictionary<Customer, Account> accounts = new Dictionary<Customer, Account>();

        /// <summary>
        /// Constructor, allocate account for customerCount customers, each with months balance history
        /// </summary>
        public AccountRepository(int customerCount, int months, double overdraft)
        {
            for (Customer customer = 0; customer < customerCount; customer++)
            {
                accounts[customer] = new Account(months, overdraft);
            }
        }

        /// <summary>
        /// Assign every account with monthly balances that fit randomly assigned trend
        /// </summary>
        public void AssignRandomTrends(Trend goodBalance, Trend badBalance, double variation, Random random)
        {
            foreach (AccountRecord record in accounts)
            {
                var account = record.Value;
                account.AssignRandomTrend(goodBalance, badBalance, variation, random);
            }
        }

        /// <summary>
        /// Property that returns collection of all accounts in repository
        /// </summary>
        public IEnumerable<Account> GetAllAccounts { get { return accounts.Values; } }

        /// <summary>
        /// Print first rows accounts from firstMonth for months, including predictions and warnings
        /// </summary>
        public void Print(int rows, int firstMonth, int months)
        {
            // Print column headings
            Console.WriteLine();
            Console.WriteLine(" Customer      Recent balances for month number   Predicted balances and warnings");
            Console.Write("           ");
            for (int month = firstMonth; month < firstMonth + months; month++) 
            { 
                Console.Write("{0,9:D}", month); 
            }
            Console.WriteLine("      Seq.    Parallel       PLINQ");

            // Print results for first nRows customers
            Customer firstCustomer = 0;
            for (int customer = firstCustomer; customer < firstCustomer + rows; customer++)
            {
                if (accounts.ContainsKey(customer))
                {
                    Console.Write("{0:D9}  ", customer);
                    var acc = accounts[customer];
                    acc.PrintBalance(firstMonth, months);
                    Console.WriteLine("  {0,8:F} {1}  {2,8:F} {3}  {4,8:F} {5}",
                        acc.SeqPrediction, acc.SeqWarning ? 'W' : ' ',  // sequential
                        acc.ParPrediction, acc.ParWarning ? 'W' : ' ',  // parallel
                        acc.PlinqPrediction, acc.PlinqWarning ? 'W' : ' '); // PLINQ
                }
            }
        }
    }
}
