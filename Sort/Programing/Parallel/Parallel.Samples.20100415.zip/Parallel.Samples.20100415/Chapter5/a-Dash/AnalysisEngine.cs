﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;
using Utilities;

namespace a_Dash
{
    /// <summary>
    /// Component for data analysis
    /// </summary>
    public class AnalysisEngine
    {
        // internal scaling factor
        double _speedFactor;

        // structure used to check for an asynchronous cancellation request
        CancellationToken _token;

        /// <summary>
        /// Creates an instance that can perform market analysis
        /// </summary>
        /// <param name="token">Token for user-initiated asynchronous cancellation of analysis operations</param>
        public AnalysisEngine(CancellationToken token) : this(token, 1.0d) 
        { 
        }

        /// <summary>
        /// Creates an instance that can perform market analysis
        /// </summary>
        /// <param name="token">Token for user-initiated asynchronous cancellation of analysis operations</param>
        /// <param name="speedFactor">Scale factor for amount of time to spend in simulation. The value 0.0 provides the 
        /// fastest execution. The value 1.0 provides standard execution. Higher values are slower.</param>
        /// <remarks>The speedFactor argument is provided for the convenience of unit tests. It is not used 
        /// by the view model.</remarks>
        public AnalysisEngine(CancellationToken token, double speedFactor)
        {
            _token = token;
            _speedFactor = speedFactor;
        }

        #region CreateSampleData

		static Dictionary<string, SecurityInformation> MakeNyseSecurityInfo()
        {
            var securities = new Dictionary<string, SecurityInformation>();
            securities["Fabrikam"] = new SecurityInformation() { Name = "Fabrikam", PriceHistory = new[] { 0.0d, 1.0d, 2.0d } };
            securities["Contoso"] = new SecurityInformation() { Name = "Contoso", PriceHistory = new[] { 2.0d, 1.0d, 0.0d } };
            return securities;
        }

        static Dictionary<string, SecurityInformation> MakeNasdaqSecurityInfo()
        {
            var result = new Dictionary<string, SecurityInformation>();
            result["Adatum"] = new SecurityInformation() { Name = "Fabrikam", PriceHistory = new[] { 1.0d, 1.0d, 1.0d } };
            return result;
        }

        static Dictionary<string, SecurityInformation> MakeFedSecurityInfo()
        {
            var result = new Dictionary<string, SecurityInformation>();
            result["Fed"] = new SecurityInformation() { Name = "Fed", PriceHistory = new[] { 1.0d, 1.0d, 1.0d } };
            return result;
        }
 
        #endregion        
        
        #region Anaysis Helper Methods

        MarketData LoadNyseData()
        {
            SampleUtilities.DoIoIntensiveOperation(2.5, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return new MarketData() { Securities = MakeNyseSecurityInfo() };
        }

        MarketData LoadNasdaqData()
        {
            SampleUtilities.DoIoIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return new MarketData() { Securities = MakeNasdaqSecurityInfo() };
        }

        MarketData LoadFedHistoricalData()
        {
            SampleUtilities.DoIoIntensiveOperation(3.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return new MarketData() { Securities = MakeFedSecurityInfo() };
        }

        MarketData MergeMarketData(IEnumerable<MarketData> allMarketData)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            var securities = new Dictionary<string, SecurityInformation>();

            if (!_token.IsCancellationRequested)
            {  
                foreach (MarketData md in allMarketData)
                   foreach (KeyValuePair<string, SecurityInformation> entry in md.Securities)
                      securities[entry.Key] = entry.Value;
            }

            if (_token.IsCancellationRequested)
                return null;
            else
                return new MarketData() { Securities = securities };
        }

        MarketData NormalizeData(MarketData marketData)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return new MarketData() { Securities = marketData.Securities };
        }

        MarketAnalysis AnalyzeData(MarketData data)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return new MarketAnalysis() { Data = data };
        }

        MarketModel CreateModel(MarketAnalysis analysis)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return new MarketModel() { Analysis = analysis };
        }

        MarketRecommendation CompareModels(IEnumerable<MarketModel> models)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return new MarketRecommendation()
                {
                    Recommendation = (_token.IsCancellationRequested ? "Canceled" : "Hold"),
                    Models = models.ToArray()
                };
        }
 
        #endregion

        #region Analysis Public Methods

		/// <summary>
        /// Creates a market recommendation using a fully sequential operation
        /// </summary>
        /// <returns>A market recommendation</returns>
        public MarketRecommendation DoAnalysisSequential()
        {
            return CompareModels(
                     new[] 
                     {
                       CreateModel(
                          AnalyzeData(
                              NormalizeData(
                                  MergeMarketData(
                                      new [] { LoadNyseData(),
                                               LoadNasdaqData() })))),
                        CreateModel(
                          AnalyzeData(
                              NormalizeData(
                                      LoadFedHistoricalData())))
                     });
        }

        /// <summary>
        /// Initiates market analysis using parallel computation.
        /// </summary>        
        /// <param name="token">A cancellation token that can signal the user's desire to abort this operation</param>
        /// <returns>Task record that may be queried for results of the analysis</returns>
        /// <remarks>Compare with the DoAnalysisSequential method</remarks>
        public AnalysisTasks StartAnalysisParallel()
        {
            TaskFactory factory = Task.Factory;

            Task<MarketData> loadNyseData = 
                Task<MarketData>.Factory.StartNew(
                    () => LoadNyseData(),
                    TaskCreationOptions.LongRunning);

            Task<MarketData> loadNasdaqData = 
                Task<MarketData>.Factory.StartNew(
                    () => LoadNasdaqData(),
                    TaskCreationOptions.LongRunning);

            Task<MarketData> mergeMarketData =
                factory.ContinueWhenAll<MarketData, MarketData>(
                    new[] { loadNyseData, loadNasdaqData },
                    (tasks) => MergeMarketData(from t in tasks select t.Result));

            Task<MarketData> normalizeMarketData =
                mergeMarketData.ContinueWith(
                    (t) => NormalizeData(t.Result));

            Task<MarketData> loadFedHistoricalData = 
                Task<MarketData>.Factory.StartNew(
                    () => LoadFedHistoricalData(),
                    TaskCreationOptions.LongRunning);

            Task<MarketData> normalizeHistoricalData =
                loadFedHistoricalData.ContinueWith(
                    (t) => NormalizeData(t.Result));

            Task<MarketAnalysis> analyzeMarketData =
                normalizeMarketData.ContinueWith(
                    (t) => AnalyzeData(t.Result));

            Task<MarketModel> modelMarketData =
                analyzeMarketData.ContinueWith(
                    (t) => CreateModel(t.Result));

            Task<MarketAnalysis> analyzeHistoricalData =
                normalizeHistoricalData.ContinueWith(
                    (t) => AnalyzeData(t.Result));

            Task<MarketModel> modelHistoricalData =
                analyzeHistoricalData.ContinueWith(
                    (t) => CreateModel(t.Result));

            Task<MarketRecommendation> compareModels =
                factory.ContinueWhenAll<MarketModel, MarketRecommendation>(
                    new[] { modelMarketData, modelHistoricalData },
                    (tasks) => CompareModels(from t in tasks select t.Result));

            return new AnalysisTasks()
                 {
                     LoadNyseData = loadNyseData,
                     LoadNasdaqData = loadNasdaqData,
                     MergeMarketData = mergeMarketData,
                     NormalizeMarketData = normalizeMarketData,
                     LoadFedHistoricalData = loadFedHistoricalData,
                     NormalizeHistoricalData = normalizeHistoricalData,
                     AnalyzeMarketData = analyzeMarketData,
                     ModelMarketData = modelMarketData,
                     AnalyzeHistoricalData = analyzeHistoricalData,
                     ModelHistoricalData = modelHistoricalData,
                     CompareModels = compareModels
                 };
        } 

		#endregion
    } 
}
