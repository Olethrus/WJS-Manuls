﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace a_Dash
{
	/// <summary>
	/// Task record for market analysis. 
	/// </summary>
	/// <remarks>
	/// Call CompareModels.Result to retrieve the finished analysis. Intermediate results can be retrieved
	/// from the Result method of the other properties. For example, LoadNyseData.Result returns the NYSE data.
	/// </remarks>
	public class AnalysisTasks
	{
		public Task<MarketData> LoadNyseData { get; set; }
		public Task<MarketData> LoadNasdaqData { get; set; }
		public Task<MarketData> MergeMarketData { get; set; }
		public Task<MarketData> NormalizeMarketData { get; set; }
		public Task<MarketData> LoadFedHistoricalData { get; set; }
		public Task<MarketData> NormalizeHistoricalData { get; set; }
		public Task<MarketAnalysis> AnalyzeMarketData { get; set; }
		public Task<MarketModel> ModelMarketData { get; set; }
		public Task<MarketAnalysis> AnalyzeHistoricalData { get; set; }
		public Task<MarketModel> ModelHistoricalData { get; set; }
		public Task<MarketRecommendation> CompareModels { get; set; }
	}
}