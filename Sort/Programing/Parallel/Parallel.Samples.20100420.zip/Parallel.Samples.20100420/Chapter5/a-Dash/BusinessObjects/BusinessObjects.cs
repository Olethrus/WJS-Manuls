﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System.Collections.Generic;
using System.Threading.Tasks;

namespace a_Dash
{
    // TO DO: Consider breaking out these definitions into separate files.
    // (It seems clearer for now to keep these definitions in a single file, since they are so small
    // and so interdependent.)

    // TO DO: Consider rewriting these types as immutable types with value semantics.

    /// <summary>
    /// Contains the result of the model comparison.
    /// </summary>
    public class MarketRecommendation
    {
        public string Recommendation { get; set; }
        public MarketModel[] Models { get; set; }
    }

    /// <summary>
    /// A model that interprets the result of analysis
    /// </summary>
    public class MarketModel
    {
        public MarketAnalysis Analysis { get; set; }
    }

    /// <summary>
    /// The result of analyzing market data
    /// </summary>
    public class MarketAnalysis
    {
        public MarketData Data { get; set; }
    }

    /// <summary>
    /// A data set with time series price information for various securities
    /// </summary>
    public class MarketData
    {
        public int Value { get; set; }
        public Dictionary<string, SecurityInformation> Securities { get; set; }
    }

    /// <summary>
    /// Time series price information for a single financial asset
    /// </summary>
    public class SecurityInformation
    {
        public string Name { get; set; }
        public double[] PriceHistory { get; set; }
    }
}