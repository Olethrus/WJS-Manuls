﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;
using System.Diagnostics;

namespace a_Dash
{
    /// <summary>
    /// A command object recognized by WPF. Implements the System.Windows.Input.ICommand interface.
    /// </summary>
    public class Command : ICommand
    {
        #region Fields

        readonly Action<object> _execute;
        readonly Predicate<object> _canExecute;
        EventHandler _canExecuteChangedHandler;

        #endregion // Fields

        #region Constructors

        /// <summary>
        /// Creates a new command that can always execute.
        /// </summary>
        /// <param name="execute">The execution logic.</param>
        public Command(Action<object> execute)
            : this(execute, null)
        {
        }

        /// <summary>
        /// Creates a new command.
        /// </summary>
        /// <param name="execute">The execution logic.</param>
        /// <param name="canExecute">The execution status logic.</param>
        public Command(Action<object> execute, Predicate<object> canExecute)
        {
            if (execute == null)
                throw new ArgumentNullException("execute");

            _execute = execute;
            _canExecute = canExecute;
        }

        #endregion // Constructors

        #region ICommand Members

        /// <summary>
        /// Tests whether the current data context allows this command to be run
        /// </summary>
        /// <param name="parameter">Parameter passed to the object's CanExecute delegate</param>
        /// <returns>True if the command is currently enabled; false if not enabled.</returns>
        [DebuggerStepThrough]
        public bool CanExecute(object parameter)
        {
            return _canExecute == null ? true : _canExecute(parameter);
        }
        
        /// <summary>
        /// Event that is raised when the "CanExecute" status of this command changes
        /// </summary>
        public event EventHandler CanExecuteChanged
        {
            add 
            { 
                _canExecuteChangedHandler = (EventHandler)Delegate.Combine(_canExecuteChangedHandler, value);
                CommandManager.RequerySuggested += value;
            }

            remove 
            { 
                _canExecuteChangedHandler = (EventHandler)Delegate.Remove(_canExecuteChangedHandler, value);
                CommandManager.RequerySuggested -= value;
            }
        }        

        /// <summary>
        /// Performs the work of the "execute" delegate.
        /// </summary>
        /// <param name="parameter"></param>
        public void Execute(object parameter)
        {
            _execute(parameter);
        }

        #endregion // ICommand Members

        /// <summary>
        /// Causes the CanExecuteChanged handler to run.
        /// </summary>
        /// <remarks>Should only be invoked by the view model</remarks>
        public void NotifyExecuteChanged()
        {
            EventHandler handler = _canExecuteChangedHandler;
            if (handler != null)
                handler(this, EventArgs.Empty);
        }
    }
}
