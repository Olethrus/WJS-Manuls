﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utilities;
using System.Threading;

namespace BasicTaskSamples
{
    class Program
    {
        const double TaskSeconds = 1.0;

        static void Main(string[] args)
        {
            Task.Factory.StartNew(() => Main_1(args)).Wait();
        }

        static void Main_1(string[] args)
        {

            SampleUtilities.TimedAction(Chapter3Sample01Sequential, "2 steps, sequential");
            SampleUtilities.TimedAction(Chapter3Sample01ParallelTask, "2 steps (Task.Wait), parallel");

            SampleUtilities.TimedAction(Chapter3Sample02Sequential, "3 steps, sequential");
            SampleUtilities.TimedAction(Chapter3Sample02Parallel, "3 steps (Task.WaitAll), parallel");

            SampleUtilities.TimedAction(Chapter3Sample03, "Task.WaitAny");

            ClosureBug();
            ClosureBugFixed();

            Console.ReadLine();
        }

        static void Chapter3Sample01Sequential()
        {
            DoLeft();
            DoRight();
        }

        static void Chapter3Sample01ParallelTask()
        {
            Task t = Task.Factory.StartNew(DoLeft);
            DoRight();

            t.Wait();
        }

        static void Chapter3Sample01ParallelInvoke()
        {
            Parallel.Invoke(DoLeft, DoRight);
        }

        static void Chapter3Sample02Sequential()
        {
            DoLeft();
            DoRight();
            DoCenter();
        }

        static void Chapter3Sample02Parallel()
        {
            Task t1 = Task.Factory.StartNew(DoLeft);
            Task t2 = Task.Factory.StartNew(DoRight);
            DoCenter();
           
            Task.WaitAll(t1, t2);
        }

        static void Chapter3Sample03_1()
        {
            // create up cancellation hooks
            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;

            // create a factory that uses custom options for new tasks
            TaskFactory factory = new TaskFactory(token,
               TaskCreationOptions.PreferFairness,
               TaskContinuationOptions.None,
               TaskScheduler.Default);

            // start three parallel tasks            
            Task[] tasks = new Task[]{
                factory.StartNew(() => SearchLeft(token)),
                factory.StartNew(() => SearchRight(token)),
                factory.StartNew(() => SearchCenter(token))};
            try
            {
                // wait for the quickest task to complete
                Task.WaitAny(tasks);
            }
            finally
            {
                // signal cancellation for tasks that did not win the race
                cts.Cancel();
                try
                {
                    // wait for cancellation to take effect and
                    // observe all unhandled exceptions
                    Task.WaitAll(tasks);
                }
                catch (AggregateException ae)
                {
                    // filter out exceptions caused by cancelation
                    // (including those from nested any nested tasks)
                    // and rethrow if any unhandled exceptions remain;
                    // otherwise, proceed without exception
                    ae.Flatten().Handle(e =>
                                         (e is OperationCanceledException));
                }
            }
        }

        static void Chapter3Sample03()
        {
           Chapter3Sample03_1();
        }
        
        static void DoCenter()
        {
            SampleUtilities.DoCpuIntensiveOperation(TaskSeconds * .5);
        }

        static void DoLeft()
        {
            SampleUtilities.DoCpuIntensiveOperation(TaskSeconds * .2);
        }

        static void DoRight()
        {
            SampleUtilities.DoCpuIntensiveOperation(TaskSeconds * .3);
        }

        static void SearchCenter(CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            SampleUtilities.DoCpuIntensiveOperation(TaskSeconds * .5, token);
            token.ThrowIfCancellationRequested();
        }

        static void SearchLeft(CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            SampleUtilities.DoCpuIntensiveOperation(TaskSeconds * .2, token);
            token.ThrowIfCancellationRequested();
        }

        static void SearchRight(CancellationToken token)
        {
            token.ThrowIfCancellationRequested();
            SampleUtilities.DoCpuIntensiveOperation(TaskSeconds * .3, token);
            token.ThrowIfCancellationRequested();
        }

        static void ClosureBug()
        {
            for (int i = 0; i < 4; i++)
            {
                Task.Factory.StartNew(() => Console.WriteLine(i));
            }
        }

        static void ClosureBugFixed()
        {
            for (int i = 0; i < 4; i++)
            {
                var tmp = i;
                Task.Factory.StartNew(() => Console.WriteLine(tmp));
            }
        }


    }
}
