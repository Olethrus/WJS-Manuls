﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utilities;
using System.Threading.Tasks;
using System.Collections.Concurrent;

namespace BasicAggregation
{
    class Program
    {
        const int SequenceSize = 100000000;
        static void Main(string[] args)
        {
            Task.Factory.StartNew(() => Main_1(args)).Wait();
        }

        static void Main_1(string[] args)
        {
            Console.WriteLine("Basic Aggregation Samples");
#if DEBUG
            Console.WriteLine("For most accurate timing results, use Release build");
            Console.WriteLine("");
#endif
            var sequence = SampleUtilities.Range(SequenceSize);

            SampleUtilities.TimedAction(() => Chapter4Sample01Sequential(sequence), "calculate sum, sequential for loop");
            GC.Collect();
            SampleUtilities.TimedAction(() => Chapter4Sample01IncorrectParallel(sequence), "calculate sum, incorrectly coded parallel loop");
            GC.Collect();
            SampleUtilities.TimedAction(() => Chapter4Sample02Linq(sequence), "calculate sum, LINQ (sequential)");
            GC.Collect();
            SampleUtilities.TimedAction(() => Chapter4Sample02Plinq(sequence), "calculate sum, PLINQ (parallel)");
            GC.Collect();
            SampleUtilities.TimedAction(() => Chapter4Sample01Parallel(sequence), "calculate sum, parallel for each");
            GC.Collect();
            SampleUtilities.TimedAction(() => Chapter4Sample01ParallelPartitions(sequence), "calculate sum, parallel partitions");
            GC.Collect();

            Console.WriteLine("Run complete... press enter");
            Console.ReadLine();
        }

        // general transformation before calculating aggregate sum
        static double Normalize(double x)
        {
            return x;
        }

        static double Chapter4Sample01Sequential(double[] sequence)
        {
            double sum = 0.0d;
            for (int i = 0; i < sequence.Length; i++)
            {
                sum += Normalize(sequence[i]);
            }
            return sum;
        }

        // WARNING: BUGGY CODE. Do not copy this method.
        // This version will run *much slower* than the sequential version
        static double Chapter4Sample01IncorrectParallel(double[] sequence)
        {
            object lockObject = new object();
            double sum = 0.0d;

            // BUG -- Do not use Parallel.For 
            Parallel.For(0, sequence.Length, i =>
            {
                // BUG -- Do not use locking inside of a parallel loop for aggregation
                lock (lockObject)
                {
                    sum += Normalize(sequence[i]);
                }
            });
            return sum;
        }

        static double Chapter4Sample02Linq(double[] sequence)
        {
            return (from x in sequence select Normalize(x)).Sum();
        }

        static double Chapter4Sample02Plinq(double[] sequence)
        {
            return (from x in sequence.AsParallel() select Normalize(x)).Sum();
        }

        static double Chapter4Sample01Parallel(double[] sequence)
        {
            object lockObject = new object();
            double sum = 0.0d;

            // ForEach<TSource, TLocal>(
            //   IEnumerable<TSource> source, 
            //   Func<TLocal> localInit, 
            //   Func<TSource, ParallelLoopState, TLocal, TLocal> body, 
            //   Action<TLocal> localFinally);
            Parallel.ForEach(
                // 1- The values to be aggregated
              sequence,

              // 2- The local initial partial result
              () => 0.0d,

              // 3- The loop body
              (x, loopState, partialResult) =>
              {
                  return Normalize(x) + partialResult;
              },

              // 4- The final step of each local context            
              (localPartialSum) =>
              {
                  // Enforce serial access to single, shared result
                  lock (lockObject)
                  {
                      sum += localPartialSum;
                  }
              });
            return sum;
        }

        static double Chapter4Sample01ParallelPartitions(double[] sequence)
        {
            object lockObject = new object();
            double sum = 0.0d;
            var rangePartitioner = Partitioner.Create(0, sequence.Length);

            // ForEach<TSource, TLocal>(
            //   Partitioner<TSource> source, 
            //   Func<TLocal> localInit, 
            //   Func<TSource, ParallelLoopState, TLocal, TLocal> body, 
            //   Action<TLocal> localFinally);
            Parallel.ForEach(
                // 1- the input intervals
              rangePartitioner,

              // 2- The local initial partial result
              () => 0.0,

              // 3- The loop body for each interval
              (range, loopState, initialValue) =>
              {
                  double partialSum = initialValue;
                  for (int i = range.Item1; i < range.Item2; i++)
                  {
                      partialSum += Normalize(sequence[i]);
                  }
                  return partialSum;
              },

              // 4- The final step of each local context
              (localPartialSum) =>
              {
                  // Use lock to enforce serial access to shared result
                  lock (lockObject)
                  {
                      sum += localPartialSum;
                  }
              });
            return sum;
        }

        //static double Chapter4Sample02Plinq(double[] sequence)
        //{
        //    return (from x in sequence.AsParallel() select Normalize(x))
        //              .Aggregate((y1, y2) => y1 * y2);

        //}

        //
        // Summary:
        //     Applies in parallel an accumulator function over a sequence. The specified
        //     seed value is used as the initial accumulator value.
        //
        // Parameters:
        //   source:
        //     A sequence to aggregate over.
        //
        //   seed:
        //     The initial accumulator value.
        //
        //   func:
        //     An accumulator function to be invoked on each element.
        //
        // Type parameters:
        //   TSource:
        //     The type of the elements of source.
        //
        //   TAccumulate:
        //     The type of the accumulator value.
        //
        // Returns:
        //     The final accumulator value.
        //
        // Exceptions:
        //   System.OperationCanceledException:
        //     The query was canceled.
        //
        //   System.ArgumentNullException:
        //     source or func is a null reference (Nothing in Visual Basic).
        //
        //   System.AggregateException:
        //     One or more exceptions occurred during the evaluation of the query.

        // [TargetedPatchingOptOut("Performance critical to inline this type of method across NGen image boundaries")]
        // public static TAccumulate Aggregate<TSource, TAccumulate>(
        //    this ParallelQuery<TSource> source, 
        //    TAccumulate seed, 
        //    Func<TAccumulate, TSource, TAccumulate> func);
        //
        // Summary:
        //     Applies in parallel an accumulator function over a sequence. The specified
        //     seed value is used as the initial accumulator value, and the specified function
        //     is used to select the result value.
        //
        // Parameters:
        //   source:
        //     A sequence to aggregate over.
        //
        //   seed:
        //     The initial accumulator value.
        //
        //   func:
        //     An accumulator function to be invoked on each element.
        //
        //   resultSelector:
        //     A function to transform the final accumulator value into the result value.
        //
        // Type parameters:
        //   TSource:
        //     The type of the elements of source.
        //
        //   TAccumulate:
        //     The type of the accumulator value.
        //
        //   TResult:
        //     The type of the resulting value.
        //
        // Returns:
        //     The transformed final accumulator value.
        //
        // Exceptions:
        //   System.OperationCanceledException:
        //     The query was canceled.
        //
        //   System.ArgumentNullException:
        //     source or func or resultSelector is a null reference (Nothing in Visual Basic).
        //
        //   System.AggregateException:
        //     One or more exceptions occurred during the evaluation of the query.
        // public static TResult Aggregate<TSource, TAccumulate, TResult>(this ParallelQuery<TSource> source, TAccumulate seed, Func<TAccumulate, TSource, TAccumulate> func, Func<TAccumulate, TResult> resultSelector);
        
        //
        // Summary:
        //     Applies in parallel an accumulator function over a sequence. This overload
        //     is not available in the sequential implementation.
        //
        // Parameters:
        //   source:
        //     A sequence to aggregate over.
        //
        //   seedFactory:
        //     A function that returns the initial accumulator value.
        //
        //   updateAccumulatorFunc:
        //     An accumulator function to be invoked on each element in a partition.
        //
        //   combineAccumulatorsFunc:
        //     An accumulator function to be invoked on the yielded element from each partition.
        //
        //   resultSelector:
        //     A function to transform the final accumulator value into the result value.
        //
        // Type parameters:
        //   TSource:
        //     The type of the elements of source.
        //
        //   TAccumulate:
        //     The type of the accumulator value.
        //
        //   TResult:
        //     The type of the resulting value.
        //
        // Returns:
        //     The transformed final accumulator value.
        //
        // Exceptions:
        //   System.OperationCanceledException:
        //     The query was canceled.
        //
        //   System.ArgumentNullException:
        //     source or seedFactory or updateAccumulatorFunc or combineAccumulatorsFunc
        //     or resultSelector is a null reference (Nothing in Visual Basic).
        //
        //   System.AggregateException:
        //     One or more exceptions occurred during the evaluation of the query.
        //public static TResult Aggregate<TSource, TAccumulate, TResult>(this ParallelQuery<TSource> source, Func<TAccumulate> seedFactory, Func<TAccumulate, TSource, TAccumulate> updateAccumulatorFunc, Func<TAccumulate, TAccumulate, TAccumulate> combineAccumulatorsFunc, Func<TAccumulate, TResult> resultSelector);
        
        //
        // Summary:
        //     Applies in parallel an accumulator function over a sequence. This overload
        //     is not available in the sequential implementation.
        //
        // Parameters:
        //   source:
        //     A sequence to aggregate over.
        //
        //   seed:
        //     The initial accumulator value.
        //
        //   updateAccumulatorFunc:
        //     An accumulator function to be invoked on each element in a partition.
        //
        //   combineAccumulatorsFunc:
        //     An accumulator function to be invoked on the yielded element from each partition.
        //
        //   resultSelector:
        //     A function to transform the final accumulator value into the result value.
        //
        // Type parameters:
        //   TSource:
        //     The type of the elements of source.
        //
        //   TAccumulate:
        //     The type of the accumulator value.
        //
        //   TResult:
        //     The type of the resulting value.
        //
        // Returns:
        //     The transformed final accumulator value.
        //
        // Exceptions:
        //   System.OperationCanceledException:
        //     The query was canceled.
        //
        //   System.ArgumentNullException:
        //     source or updateAccumulatorFunc or combineAccumulatorsFunc or resultSelector
        //     is a null reference (Nothing in Visual Basic).
        //
        //   System.AggregateException:
        //     One or more exceptions occurred during the evaluation of the query.
        // public static TResult Aggregate<TSource, TAccumulate, TResult>(this ParallelQuery<TSource> source, TAccumulate seed, Func<TAccumulate, TSource, TAccumulate> updateAccumulatorFunc, Func<TAccumulate, TAccumulate, TAccumulate> combineAccumulatorsFunc, Func<TAccumulate, TResult> resultSelector);
        //static double Chapter4Sample03Plinq(double[] sequence)
        //{
        //    return (from x in sequence.AsParallel() select Normalize(x))
        //              .Aggregate(

        //}

    }
}
