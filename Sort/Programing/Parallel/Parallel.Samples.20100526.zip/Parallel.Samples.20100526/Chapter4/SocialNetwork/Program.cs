﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using Utilities;
using System.Globalization;
using System.Collections.ObjectModel;

using SubscriberID = System.Int32;

namespace SocialNetwork
{
    using IDBagItemList = Collection<KeyValuePair<SubscriberID, int>>;  // to sort, must use list of bag items not bag itself

    class Program
    {
        /// <summary>
        /// Usage: SocialNework subscriberCount maxFriends
        /// Both arguments are optional, defaults are 1000 and 10.
        /// </summary>
        static void Main(string[] args)
        {
            Random random = new Random(1);  // seed for random but reproducible runs

            // Defaults for data generation, may override some on command line
            int subscriberCount = 1000;
            int maxFriends = 10;

            // Defaults for printed table of results
            int maxRows = 16;
            int maxCols = 8;
            int maxCandidates = maxRows; 

            // Optionally override some defaults on command line
            if (args.Length > 0) subscriberCount = Int32.Parse(args[0], CultureInfo.CurrentCulture);
            if (args.Length > 1) maxFriends = Int32.Parse(args[1], CultureInfo.CurrentCulture);

            // Allocate subscribers, assign friends for timing tests
            SubscriberRepository subscribers = new SubscriberRepository(subscriberCount);
            subscribers.AssignRandomFriends(maxFriends, random);

            // Print a few subscribers and a summary
            Console.WriteLine();
            Console.WriteLine("Some subscribers and some of their friends");
            subscribers.Print(maxRows, maxCols);
            Console.WriteLine();
            Console.WriteLine("{0} subscribers in all, with up to {1} friends or even more  ", subscriberCount, maxFriends);

            // Choose a subscriber seeking friends
            SubscriberID ID = 0;
            var subscriber = subscribers.GetSubscriber(ID);
            Console.WriteLine();
            Console.WriteLine("Find potential friends for this subscriber, with these friends:");
            Console.Write("{0,10:D}", ID);
            subscriber.Print(subscriber.Friends.Count);
            Console.WriteLine();

            // Sequential for
            var candidates = new IDBagItemList(); // to sort, must use list of bag items not bag itself
            SampleUtilities.TimedRun(() =>
            {
                candidates = subscribers.PotentialFriendsSequential(ID, maxCandidates);
                return candidates.Count;
            },
            "  Sequential for");
            Console.WriteLine();

            int rows = Math.Min(maxRows, candidates.Count);
            Console.WriteLine("{0} potential friends for this subscriber, and the number of mutual friends", rows);
            Bag.Print(candidates);
            Console.WriteLine();

            // Parallel.ForEach 
            SampleUtilities.TimedRun(() =>
            {
                candidates = subscribers.PotentialFriendsParallel(ID, maxCandidates);
                return candidates.Count;
            },
            "Parallel.ForEach");
            Console.WriteLine();

            rows = Math.Min(maxRows, candidates.Count);
            Console.WriteLine("{0} potential friends for this subscriber, and the number of mutual friends", rows);
            Bag.Print(candidates);
            Console.WriteLine();

            // Sequential LINQ
            SampleUtilities.TimedRun(() =>
            {
                candidates = subscribers.PotentialFriendsLinq(ID, maxCandidates);
                return candidates.Count;
            },
            " Sequential LINQ");
            Console.WriteLine();

            rows = Math.Min(maxRows, candidates.Count);
            Console.WriteLine("{0} potential friends for this subscriber, and the number of mutual friends", rows);
            Bag.Print(candidates);
            Console.WriteLine();

            // PLINQ
            SampleUtilities.TimedRun(() =>
            {
                candidates = subscribers.PotentialFriendsPLinq(ID, maxCandidates);
                return candidates.Count;
            },
            "           PLINQ");
            Console.WriteLine();

            rows = Math.Min(maxRows, candidates.Count);
            Console.WriteLine("{0} potential friends for this subscriber, and the number of mutual friends", rows);
            Bag.Print(candidates);
        }
    }
}
