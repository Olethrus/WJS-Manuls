﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using SubscriberID = System.Int32;

namespace SocialNetwork
{
    /// <summary>
    /// A subscriber's data in the social network
    /// For our present purposes, just a collection of friends' IDs 
    /// </summary>
    public class Subscriber
    {
        HashSet<SubscriberID> _friends;

        public Subscriber()
        {
            _friends = new HashSet<SubscriberID>();
        }

        public HashSet<SubscriberID> Friends { get { return _friends; } } // Consider HashSet instead of List

        public void Print(int maxFriends)
        {
            Console.Write("{0,5:D}", Friends.Count);
            var subs = Friends.GetEnumerator();
            for (int i = 0; i < Math.Min(maxFriends, Friends.Count); i++) 
            {
                subs.MoveNext();
                Console.Write("{0,8:D}", subs.Current); // Friends[i]); 
            }
            Console.WriteLine();
        }
    }
}
