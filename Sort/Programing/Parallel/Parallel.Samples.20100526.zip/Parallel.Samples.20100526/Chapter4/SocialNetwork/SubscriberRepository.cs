﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;

using SubscriberID = System.Int32;

namespace SocialNetwork
{
    using IDBag = Dictionary<SubscriberID, int>;
    using IDBagItem = KeyValuePair<SubscriberID, int>;
    using IDBagItemList = Collection<KeyValuePair<SubscriberID, int>>;  // to sort, must use list of bag items not bag itself
    using SubscriberRecord = KeyValuePair<SubscriberID, Subscriber>;

    public class SubscriberRepository
    {
        /// <summary>
        /// Collection of all subscribers in the repository
        /// </summary>
        Dictionary<SubscriberID, Subscriber> _subscribers;

        /// <summary>
        /// Constructor, initialize with no subscribers
        /// </summary>
        public SubscriberRepository() { _subscribers = new Dictionary<SubscriberID, Subscriber>(); }

        /// <summary>
        /// Constructor, allocate subscribers with no friends
        /// </summary>
        public SubscriberRepository(int subscriberCount)
        {
            _subscribers = new Dictionary<SubscriberID, Subscriber>();
            for (SubscriberID subscriber = 0; subscriber < subscriberCount; subscriber++)
            {
                _subscribers[subscriber] = new Subscriber();
            }
        }

        /// <summary>
        /// Return number of subscribers
        /// </summary>
        public int Count { get { return _subscribers.Count; } }

        /// <summary>
        /// Return subscriber with given ID
        /// </summary>
        /// <param name="id">ID of subscriber</param>
        /// <returns>Subcriber data for that ID</returns>
        public Subscriber GetSubscriber(SubscriberID id)
        {
            return _subscribers[id];
        }

        /// <summary>
        /// Assign every subscriber a random number (up to maxFriends) of randomly chosen new friends
        /// Ensure friends relation is symmetric 
        /// </summary> 
        public void AssignRandomFriends(int maxFriends, Random random)
        {
            foreach (SubscriberRecord record in _subscribers)
            {
                int ID = record.Key;
                Subscriber subscriber = record.Value;
                if (random == null)
                    throw new ArgumentNullException("random");
                int nfriends = random.Next(maxFriends);
                var friends = subscriber.Friends;
                for (int i = 0; i < nfriends; i++)
                {
                    SubscriberID friend = random.Next(_subscribers.Count);
                    if (friend != ID) // self is never in friends
                    { 
                        friends.Add(friend); // HashSet ensures no duplicates
                        var friendsFriends = _subscribers[friend].Friends;
                        friendsFriends.Add(ID); // symmetric relation
                    }
                }
            }
        }

        /// <summary>
        /// Find potential friends (candidates) for subscriber: other subscribers with mutual friends
        /// Demonstrate MapReduce with sequential foreach
        /// </summary>
        /// <param name="id">ID of subscriber seeking friends</param>
        /// <param name="subscriber">Subscriber's info including collection of own friends</param>
        /// <param name="maxCandidates">Maximum number of potential friends to return</param>
        /// <returns>Sorted list of candidates as ID/count pairs, count is number of mutual friends</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        public IDBagItemList PotentialFriendsSequential(SubscriberID id, int maxCandidates)
        {
            // Map
            var foafsList = new List<IDBag>();
            foreach (SubscriberID friend in _subscribers[id].Friends)
            {
                var foafs = _subscribers[friend].Friends;
                foafs.RemoveWhere(foaf => foaf == id|| _subscribers[id].Friends.Contains(foaf)); // remove self, own friends
                foafsList.Add(Bag.Create(foafs));
            }

            // Reduce
            IDBag candidates = new IDBag();
            foreach (IDBag foafs in foafsList)
            {
                candidates = Bag.Union(foafs, candidates);
            }

            // Postprocess
            return Bag.MostNumerous(candidates, maxCandidates);
        }

        /// <summary>
        /// Find potential friends, demonstrate MapReduce with Parallel.ForEach, same parameters as above.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        public IDBagItemList PotentialFriendsParallel(SubscriberID id, int maxCandidates)
        {
            object locker = new object();
            IDBag candidates = new IDBag();
            Parallel.ForEach(_subscribers[id].Friends, // Map over friends
                () => Bag.Create(new HashSet<SubscriberID>()), // init thread-local state localFoafs with empty bag
                (friend, loopState, localFoafs) =>
                {
                    var foafs = _subscribers[friend].Friends;
                    foafs.RemoveWhere(foaf => foaf == id || _subscribers[id].Friends.Contains(foaf)); // remove self, own friends
                    return Bag.Union(localFoafs, Bag.Create(foafs)); // Reduce, thread-local
                },
                localFoafs => { lock (locker) candidates = Bag.Union(localFoafs, candidates); }); // Reduce, among threads 
            return Bag.MostNumerous(candidates, maxCandidates); // postprocess results of Reduce
        }

        /// <summary>
        /// Find potential friends, demonstrate MapReduce with sequential LINQ, same parameters as above.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        public IDBagItemList PotentialFriendsLinq(SubscriberID id, int maxCandidates)
        {
            var candidates =
                _subscribers[id].Friends                                   // Map
                .SelectMany(friend => _subscribers[friend].Friends)
                .Where(foaf => foaf != id && !(_subscribers[id].Friends.Contains(foaf))) // remove self, own friends
                .GroupBy(foaf => foaf)                               // Reduce
                .Select(foafGroup => new IDBagItem(foafGroup.Key, foafGroup.Count()));
            return Bag.MostNumerous(candidates, maxCandidates); // postprocess results of Reduce
        }

        /// <summary>
        /// Find potential friends, demonstrate MapReduce with PLINQ, same parameters as above.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1006:DoNotNestGenericTypesInMemberSignatures")]
        public IDBagItemList PotentialFriendsPLinq(SubscriberID id, int maxCandidates)
        {
            var candidates =
                _subscribers[id].Friends.AsParallel()                       // Map
                .SelectMany(friend => _subscribers[friend].Friends)
                .Where(foaf => foaf != id && !(_subscribers[id].Friends.Contains(foaf))) // remove self, own friends
                .GroupBy(foaf => foaf)                               // Reduce
                .Select(foafGroup => new IDBagItem(foafGroup.Key, foafGroup.Count()));
            return Bag.MostNumerous(candidates, maxCandidates); // postprocess results of Reduce
        }

        /// <summary>
        /// Print rows subscribers from repository, up to maxFriends each
        /// </summary>
        public void Print(int rows, int maxFriends)
        {
            var subs = _subscribers.GetEnumerator();
            Console.WriteLine("Subscriber    N  Friends");
            for (int i = 0; i < rows; i++)
            {
                if (subs.MoveNext()) 
                {
                    int ID = subs.Current.Key;
                    Subscriber s = subs.Current.Value;
                    Console.Write("{0,10:D}", ID);
                    s.Print(maxFriends); 
                }
            }
        }
    }
}