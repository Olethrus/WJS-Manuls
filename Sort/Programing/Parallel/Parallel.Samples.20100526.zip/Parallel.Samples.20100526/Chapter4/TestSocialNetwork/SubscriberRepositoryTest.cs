﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using SocialNetwork;

using SubscriberID = System.Int32;

namespace SocialNetworkTests
{
    using IDBagItem = KeyValuePair<SubscriberID, int>;

    [TestClass]
    public class SubscriberRepositoryTest
    {
        /// <summary>
        /// Check AssignRandomFriends: no self in friends, no duplicates in friends, friends are symmetric
        /// Force AssignRandomFriends to be deterministic: make small repository, request large N of friends.
        /// </summary>
        [TestMethod]
        public void AssignRandomFriendsTest()
        {
            // maxFriends >> subscriberCount forces AssignRandomFriends to be deterministic
            int subscriberCount = 3;
            int maxFriends = 100;

            // Build small social network graph
            var r = new SubscriberRepository(subscriberCount);
            r.AssignRandomFriends(maxFriends, new Random());  // seed doesn't matter - deterministic anyway

            // now expect 0 -> (1,2), 1 -> (0,2), 2 -> (0,1)
            Assert.AreEqual(r.Count, subscriberCount);

            // 0 -> (1,2)
            var s = r.GetSubscriber(0);
            Assert.AreEqual(s.Friends.Count, 2);  // no duplicates
            Assert.IsTrue(s.Friends.Contains(1));
            Assert.IsTrue(s.Friends.Contains(2));
            Assert.IsFalse(s.Friends.Contains(0), "Self is never in friends");

            // 1 -> (0,2)
            s = r.GetSubscriber(1);
            Assert.AreEqual(s.Friends.Count, 2);
            Assert.IsTrue(s.Friends.Contains(0));
            Assert.IsTrue(s.Friends.Contains(2));

            // 2 -> (0,1)
            s = r.GetSubscriber(2);
            Assert.AreEqual(s.Friends.Count, 2);
            Assert.IsTrue(s.Friends.Contains(0));
            Assert.IsTrue(s.Friends.Contains(1));
        }

        /// <summary>
        /// Check PotentialFriends using a known social graph
        /// </summary>
        [TestMethod]
        public void PotentialFriendsTest()
        {
            // Build small social graph
            var r = new SubscriberRepository(5);

            // 0 -> (1,2) 
            var s = r.GetSubscriber(0);
            s.Friends.Add(1);
            s.Friends.Add(2);

            // 1 -> (0,2,3)
            s = r.GetSubscriber(1);
            s.Friends.Add(0);
            s.Friends.Add(2);
            s.Friends.Add(3);

            // 2 -> (0,1,3,4)
            s = r.GetSubscriber(2);
            s.Friends.Add(0);
            s.Friends.Add(1);
            s.Friends.Add(3);
            s.Friends.Add(4);

            // 3 -> (1,2)
            s = r.GetSubscriber(3);
            s.Friends.Add(1);
            s.Friends.Add(2);

            // 4 -> (2)
            s = r.GetSubscriber(4);
            s.Friends.Add(2);

            // Now we have this social graph
            // No subscriber is own friend, friend relation is symmetric
            // 0 -> (1,2)
            // 1 -> (0,2,3)
            // 2 -> (0,1,3,4)
            // 3 -> (1,2)
            // 4 -> (2)

            // Find potential friends for subscriber 0, expect { 3 -> 2, 4 -> 1 }
            var candidates = r.PotentialFriendsSequential(0, 5);
            Assert.AreEqual(candidates.Count, 2);
            Assert.IsTrue(candidates.Contains(new IDBagItem(3, 2)));
            Assert.IsTrue(candidates.Contains(new IDBagItem(4, 1)));
            Assert.IsFalse(candidates.Contains(new IDBagItem(0, 2)), "Self is never in friends");
            Assert.IsFalse(candidates.Contains(new IDBagItem(1, 1)), "Already in friends"); 
        }

        /// <summary>
        /// Check that PotentialFriends does not recommend subscribers who are already friends
        /// </summary>
        [TestMethod]
        public void PotentialFriendsNoDuplicatesTest()
        {
            // maxFriends >> subscriberCount forces AssignRandomFriends to be deterministic
            int subscriberCount = 3;
            int maxFriends = 100;

            // Build small social network graph
            var r = new SubscriberRepository(subscriberCount);
            r.AssignRandomFriends(maxFriends, new Random());  // seed doesn't matter - deterministic anyway

            // now expect 0 -> (1,2), 1 -> (0,2), 2 -> (0,1), friends are already maximal

            // Find potential *additional* friends for each subscriber, always expect empty collection
            var candidates = r.PotentialFriendsSequential(0, maxFriends);
            Assert.AreEqual(candidates.Count, 0);
            candidates = r.PotentialFriendsSequential(1, maxFriends);
            Assert.AreEqual(candidates.Count, 0);
            candidates = r.PotentialFriendsSequential(2, maxFriends);
            Assert.AreEqual(candidates.Count, 0);
        }
    }
}
