﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Threading.Tasks;
using System.Diagnostics;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Utilities;
using System.Threading;

namespace TestBasicFutures
{
    /// <summary>
    /// This class demonstrates some behaviors of the .NET threading libraries
    /// Some of these tests are expected to FAIL.
    /// </summary>
    [TestClass]
    public class TestBasicFutures
    {
        // These tests show the contexts in which task inlining is available. You can uncomment
        // the anti-patterns if you want to see these run (and fail).


        /// <summary>
        /// This SUCCEEDS.
        /// See the summary of the TaskInliningTest_1() method for more information.
        /// Inlining is only supported on ThreadPool threads.
        /// </summary>
        [TestMethod]
        public void FutureSchedulingFromThreadPoolTest()
        {
            var ce = new CountdownEvent(1);
            ThreadPool.QueueUserWorkItem(delegate { 
                TaskInlining_1();
                LoopInlining_1();
                ce.Signal(); 
            });
            ce.Wait();
        }

        [TestMethod]
        public void ContinuationSchedulingFromThreadPoolTest()
        {
            var ce = new CountdownEvent(1);
            ThreadPool.QueueUserWorkItem(delegate
            {
                ContinuationTaskInlining1_Test();
                ce.Signal();
            });
            ce.Wait();
        }

        /// <summary>
        /// This FAILS>
        /// See the summary of the TaskInlining_1() method for more information.
        /// </summary>
        [TestMethod]
        public void FutureSchedulingFromLongRunningTaskTest()
        {
            // Execute test body from long-running task context 
            var t = Task.Factory.StartNew(() =>
            {
                TaskInlining_1();
            }, TaskCreationOptions.LongRunning);

            t.Wait();
        }

        /// <summary>
        /// Note: This test succeeds in the .NET 4 Framework.
        /// See the summary of the TaskInliningTest_1() method for more information.
        /// </summary>
        [TestMethod]
        public void FutureSchedulingFromTaskContextTest()
        {
            // Execute test body from normal task context (compare with TestFutureSchedulingFromMainThread() below)
            var t = Task.Factory.StartNew(() =>
            {
                TaskInlining_1();
                LoopInlining_1();
            });
               
            t.Wait();            
        }

        /// <summary>
        /// Note: This test method FAILS in the .NET 4 Framework implementation.
        /// See the summary of the TaskInlining_1() method for more information.
        /// </summary>
        //[TestMethod]
        //public void TestFutureSchedulingFromMainThread()
        //{
        //    // Execute test body from main thread (compare with TestFutureSchedulingFromTaskContext() above)
        //    TaskInlining_1();
        //}

        /// <summary>
        /// Note: This test succeeds because the execution occurs in a task context
        /// See the summary of the TaskInlining_1() method for more information.
        /// </summary>
        [TestMethod]
        public void FutureSchedulingFromParallelInvoke1_Test()
        {
            // Execute test task context using singleton parallel invoke
            Parallel.Invoke(TaskInlining_1);
        }

        /// <summary>
        /// Note: This test succeeds because the execution occurs in a task context,
        /// See the summary of the TestFutureScheduling_1() method for more information.
        /// </summary>
        [TestMethod]
        public void FutureSchedulingFromParallelInvoke2_Test()
        {
            // Perform test in parallel
            Parallel.Invoke(TaskInlining_1, TaskInlining_1);
        }

        [TestMethod]
        public void GlobalQueueTaskSchedulingFromTaskContextTest()
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;

            CountdownEvent ce = new CountdownEvent(1);
            Task<int> t1 = new Task<int>(() => 1);

            Task<int> t2 = Task<int>.Factory.StartNew(() =>
                {
                    ce.Wait();
                    return t1.Result;

                });
            CreateBacklogOfTasks(token);
            t1.Start();
            ce.Signal();
            var result = t2.Result;
            Console.WriteLine(result);

        }
        /// <summary>
        /// This test demonstrates the demand-driven scheduling (inlining) feature of the futures pattern. This allows
        /// futures to express potential parallelism with the property that they will not take longer to run
        /// than the serial case.
        /// 
        /// NOTE: This test method FAILS in if run by the main thread, but SUCCEEDS when run 
        /// in a task context. It also FAILS when run from a long-running task. The .NET 4 Framework 
        /// default TaskManager object will only allow inlining (or calculate-on-demand) for 
        /// ThreadPool threads. 
        /// </summary>
        private void TaskInlining_1()
        {                     
            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;

            const int taskTimeInMs = 200;

            CreateBacklogOfTasks(token);

            // Decompose some of this method's work using potential parallelism.
            Task<int> localFuture = Task<int>.Factory.StartNew(() =>
                    {                            
                        SampleUtilities.DoCpuIntensiveOperation(taskTimeInMs / 1000.0); 
                        return 1;  
                    });

            // Add tasks to local queue in case LIFO local ordering is present
            CreateBacklogOfTasks(token);

            // Start timing 
            Stopwatch watch = new Stopwatch();
            watch.Start();
            
            // Try to get the "localFuture" result needed by this method to complete. Consistent with 
            // the design principle of futures as an expression of potential parallelism, if this task 
            // is not already running, asking for its result should cause it to run in the current thread
            // (even if other tasks are ahead of it in the backlog of pending tasks). In other words, asking
            // for a future's result should never take (much) longer than calling the body delegate sequentially. 
            // This is known as "inlining." See chapter 3 of the guide for more information.
            var taskResult = localFuture.Result;
            
            // Remember how long it took to get the future's result
            watch.Stop();

            // Cancel the tasks created by other threads. Once we have our timing numbers 
            // these are no longer needed.
            cts.Cancel();

            // Check that the future ran to completion and returned its expected value.
            Assert.AreEqual<int>(1, taskResult);

            // The worst-case amount of time for the value to be retrieved should not be much more than 
            // it would take to calculate the value by running the future's delegate serially in the 
            // current thread. We multiply this by four to allow time for scheduling artifacts and
            // other delays not related to task scheduling.
            long maxExpected = taskTimeInMs * 4;
            long actual = watch.ElapsedMilliseconds;

            // Check that our future was ready when we needed it or was calculated on demand.
            Assert.IsTrue(maxExpected > actual, "Future value was not calculated on demand. (Expected future to be inlined in current thread when its Result queried.)");
        }

        // This method FAILS. Continuation tasks are never inlined.
        private void ContinuationTaskInlining1_Test()
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;

            const int taskTimeInMs = 200;

            CreateBacklogOfTasks(token);

            // Decompose some of this method's work using potential parallelism.
            Task<int> antecedent = Task<int>.Factory.StartNew(() =>
            {
                SampleUtilities.DoCpuIntensiveOperation(taskTimeInMs / 1000.0);
                return 1;
            });

            Task<int> localContinuation = antecedent.ContinueWith((t) => t.Result + 2);

            // Start timing 
            Stopwatch watch = new Stopwatch();
            watch.Start();

            // Try to get the "localContinuation" result needed by this method to complete. Consistent with 
            // the design principle of futures as an expression of potential parallelism, if this task 
            // is not already running, asking for its result should cause it to run in the current thread
            // (even if other tasks are ahead of it in the backlog of pending tasks). In other words, asking
            // for a continuation's result should never take (much) longer than calling the body delegate sequentially. 
            // This is known as "inlining." See chapter 3 of the guide for more information.
            var taskResult = localContinuation.Result;

            // Remember how long it took to get the future's result
            watch.Stop();

            // Cancel the tasks created by other threads. Once we have our timing numbers 
            // these are no longer needed.
            cts.Cancel();

            // Check that the future ran to completion and returned its expected value.
            Assert.AreEqual<int>(3, taskResult);

            // The worst-case amount of time for the value to be retrieved should not be much more than 
            // it would take to calculate the value by running the future's delegate serially in the 
            // current thread. We multiply this by four to allow time for scheduling artifacts and
            // other delays not related to task scheduling.
            long maxExpected = taskTimeInMs * 4;
            long actual = watch.ElapsedMilliseconds;

            // Check that our future was ready when we needed it or was calculated on demand.
            Assert.IsTrue(maxExpected > actual, "Future value was not calculated on demand. (Expected future to be inlined in current thread when its Result queried.)");
        }

        /// <summary>
        /// This test demonstrates the demand-driven scheduling (inlining) feature of the futures pattern. This allows
        /// futures to express potential parallelism with the property that they will not take longer to run
        /// than the serial case.
        /// 
        /// NOTE: This test method FAILS in if run by the main thread, but SUCCEEDS when run 
        /// in a task context. It also FAILS when run from a long-running task. The .NET 4 Framework 
        /// default TaskManager object will only allow inlining (or calculate-on-demand) for 
        /// ThreadPool threads. 
        /// </summary>
        private void LoopInlining_1()
        {
            CancellationTokenSource cts = new CancellationTokenSource();
            CancellationToken token = cts.Token;

            const int taskTimeInMs = 200;

            CreateBacklogOfTasks(token);

            // Start timing 
            Stopwatch watch = new Stopwatch();
            watch.Start();

            // Decompose some of this method's work using potential parallelism.
            
            // Try to run a parallel loop. Consistent with the design principle of futures as an expression 
            // of potential parallelism, if this task is not already running, asking for its result should 
            // cause it to run in the current thread
            // (even if other tasks are ahead of it in the backlog of pending tasks). In other words, running
            // a parallel loop should never take (much) longer than calling the body delegate sequentially. 
            // This is known as "inlining." See chapter 3 of the guide for more information.
            const int numberOfIterations = 100;
            Parallel.For(0, numberOfIterations, (i) =>
                {
                   Thread.Sleep(taskTimeInMs / numberOfIterations);
                });
                
            // Remember how long it took to run the loop
            watch.Stop();

            // Cancel the tasks created by other threads. Once we have our timing numbers 
            // these are no longer needed.
            cts.Cancel();

            // The worst-case amount of time for the loop to run to be retrieved should not be much more than 
            // it would take to calculate the value by running the iterations serially in the 
            // current thread. We multiply this by four to allow time for scheduling artifacts and
            // other delays not related to task scheduling.
            long maxExpected = taskTimeInMs * 4;
            long actual = watch.ElapsedMilliseconds;

            // Check that our future was ready when we needed it or was calculated on demand.
            Assert.IsTrue(maxExpected > actual, "Parallel loop was not run on demand. (Expected loop to be inlined in current thread when its Result queried.)");
        }

        void CreateBacklogOfTasks(CancellationToken token)
        {
            const int noOfTasksFromOtherThreads = 70;
            const int avgTaskTimeInMs = 200;

            // Simulate a backlog of work by starting many more futures 
            // than the number of available worker threads.
            Task[] tasksScheduledByOtherThreads = new Task[noOfTasksFromOtherThreads];
            for (int i = 0; i < noOfTasksFromOtherThreads; i++)
            {
                tasksScheduledByOtherThreads[i] = Task.Factory.StartNew(() =>
                {
                    SampleUtilities.DoCpuIntensiveOperation(avgTaskTimeInMs / 1000.0, token);
                }, token);
            }
        }

        [TestMethod]
        public void PartitionerBehavior1_Test()
        {
            var p = Partitioner.Create(0, 1000);
            var partitions = p.GetDynamicPartitions();
            int i = 1;
            Console.WriteLine("Dynamic partitions ({0}, {1})", 0, 1000);
            foreach (var partition in partitions)
            {                
                Console.WriteLine("{0}: Tuple<{1}, {2}>", i, partition.Item1, partition.Item2);
                i += 1;
            }
            Assert.IsTrue(true);

        }

        [TestMethod]
        public void PartitionerBehavior2_Test()
        {
            var p = Partitioner.Create(0, 1000);
            var partitions = p.GetPartitions(10);
            int i = 1;
            int j = 1;
            Console.WriteLine("Static partitions ({0}, {1})", 0, 1000);
            foreach (var partition in partitions)
            {
                while(partition.MoveNext())
                {
                    var tuple = partition.Current;
                    Console.WriteLine("({0}, {1}): Tuple<{2}, {3}>", i, j, tuple.Item1, tuple.Item2);
                    j += 1;
                }
                i += 1;
            }
            Assert.IsTrue(true);

        }

        
    }
}
