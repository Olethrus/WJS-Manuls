﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System.Collections.Generic;

namespace a_Dash
{
    // TO DO: Consider rewriting these types as immutable types with value semantics.

    /// <summary>
    /// Compares models.
    /// </summary>
    public static class ModelComparer
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "models")]
        public static MarketRecommendation Run(MarketModel[] models)
        {
            return new MarketRecommendation("Buy");
        }
    }

    /// <summary>
    /// A model that produces a market recommendation based on market data and analysis.
    /// </summary>
    public static class MarketModeler
    {
        // data parameter here is placeholder intended for illustrative purposes
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "data")]
        public static MarketModel Run(StockAnalysisCollection data)
        {
            return new MarketModel();
        }
    }

    /// <summary>
    /// Analyzes market data and returns key metrics.
    /// </summary>
    public static class MarketAnalyzer
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA1801:ReviewUnusedParameters", MessageId = "data")]
        public static StockAnalysisCollection Run(StockDataCollection data)
        {
            return new StockAnalysisCollection(new List<StockAnalysis>());
        }   
    }
}