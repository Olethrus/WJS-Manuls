﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

namespace a_Dash
{
    /// <summary>
    /// Contains the result of the model comparison.
    /// </summary>
    public class MarketRecommendation
    {
        public string Recommendation { get; private set; }

        public MarketRecommendation(string recommendation)
        {
            Recommendation = recommendation;
        }
    }
}