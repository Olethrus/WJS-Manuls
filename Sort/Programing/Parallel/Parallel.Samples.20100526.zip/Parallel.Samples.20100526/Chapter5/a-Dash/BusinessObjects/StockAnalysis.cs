﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace a_Dash
{
    /// <summary>
    /// The result of analyzing market data on a single financial asset
    /// </summary>
    public class StockAnalysis
    {
        public string Name { get; private set; }
        public double Volatility { get; private set; }

        public StockAnalysis(string name, double volatility)
        {
            Name = name;
            Volatility = volatility;
        }
    }

    /// <summary>
    /// A data set containing analysis results for various financial assets
    /// </summary>
    public class StockAnalysisCollection : ReadOnlyCollection<StockAnalysis>
    {
        public StockAnalysisCollection(IList<StockAnalysis> data)
            : base(data)
        {
        }
    }
}