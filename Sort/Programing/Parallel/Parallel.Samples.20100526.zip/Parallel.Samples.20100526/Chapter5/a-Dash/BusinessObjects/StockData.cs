﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace a_Dash
{
    /// <summary>
    /// Time series price information for a single financial asset
    /// </summary>
    public class StockData
    {
        public string Name { get; private set; }
        double[] PriceHistory;// { get; private set; }

        public StockData(string name, double[] priceHistory)
        {
            Name = name;
            PriceHistory = priceHistory;
        }

        public double[] GetPriceHistory()
        {
            return (double[]) PriceHistory.Clone();
        }
    }

    /// <summary>
    /// A data set with time series price information for various financial assets
    /// </summary>
    public class StockDataCollection : ReadOnlyCollection<StockData>
    {
        public StockDataCollection(IList<StockData> data)
            : base(data)
        {
        }
    }
}