﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.ComponentModel;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;

namespace a_Dash
{
    #region Enumerations

    /// <summary>
    /// An instance of the view model may be in one of three modes
    /// </summary>
    public enum State { Ready, Calculating, Canceling };

    #endregion   

    /// <summary>
    /// View model for application
    /// </summary>
    /// <remarks>Note that this class repects thread affinity. It is an error to invoke any
    /// of the public members of this class in a thread other than the one that created the 
    /// instance.</remarks>
    public class MainWindowViewModel : INotifyPropertyChanged, IDisposable
    {
     

        #region Private Fields

        // cancellation handle for calculation
        CancellationTokenSource _cancellationTokenSource = null; 
        
        // view model's current mode of operation
        State _modelState = State.Ready;

        // results of analysis or null if not yet computed
        StockDataCollection _nyseMarketData;
        StockDataCollection _nasdaqMarketData;
        StockDataCollection _mergedMarketData;
        StockDataCollection _normalizedMarketData;
        StockDataCollection _fedHistoricalData;
        StockDataCollection _normalizedHistoricalData;
        StockAnalysisCollection _analyzedStockData;
        StockAnalysisCollection _analyzedHistoricalData;
        MarketModel _modeledMarketData;
        MarketModel _modeledHistoricalData;
        MarketRecommendation _recommendation;

        // Command objects exposed by this view model for use by the view
        Command _calculateCommand;
        Command _cancelCommand;
        Command _closeCommand;
        Command _nyseCommand;
        Command _nasdaqCommand;
        Command _mergedCommand;
        Command _normalizedCommand;
        Command _fedHistoricalCommand;
        Command _normalizedHistoricalCommand;
        Command _analyzedCommand;
        Command _analyzedHistoricalCommand;
        Command _modeledCommand;
        Command _modeledHistoricalCommand;
        Command _recommendationCommand;

        // status string that appears in the UI
        string _statusText = ""; 

        #endregion // Private Fields

        #region Events
       
        /// <summary>
        /// Raised when a public property of this class changes
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Raised when the associated view window should be closed (i.e. application shutdown).
        /// </summary>
        public event EventHandler RequestClose;

        /// <summary>
        /// Raised when the corresponding command is invoked. 
        /// </summary>
        public event EventHandler RequestNyse;
        public event EventHandler RequestNasdaq;
        public event EventHandler RequestMerged;
        public event EventHandler RequestNormalized;
        public event EventHandler RequestFedHistorical;
        public event EventHandler RequestNormalizedHistorical;
        public event EventHandler RequestAnalyzed;
        public event EventHandler RequestAnalyzedHistorical;
        public event EventHandler RequestModeled;
        public event EventHandler RequestModeledHistorical;
        public event EventHandler RequestRecommendation;
        #endregion

        #region Publicly Readable Data Properties

        public State ModelState
        {
            get
            {
                return _modelState;
            }

            private set
            {
                _modelState = value;

                // issue notification of property change, including derived properties
                // and commands whose "CanExecute" status depend on model state.
                OnPropertyChanged("ModelState");
                OnPropertyChanged("CancelButtonVisibility");
                _calculateCommand.NotifyExecuteChanged();
                _cancelCommand.NotifyExecuteChanged();
            }
        }

        public string StatusTextBoxText
        {
            get { return _statusText; }
            // TO DO: make set method private
            set
            {
                _statusText = value;
                OnPropertyChanged("StatusTextBoxText");
            }
        }

        public Visibility CancelButtonVisibility
        {
            get
            {
                return (_modelState == State.Calculating ||
                        _modelState == State.Canceling) ?
                        Visibility.Visible : Visibility.Hidden;
            }
        }

        public StockDataCollection NyseMarketData
        {
            get
            {
                return _nyseMarketData;
            }
            private set
            {
                _nyseMarketData = value;
                OnPropertyChanged("NyseMarketData");
                _nyseCommand.NotifyExecuteChanged();
            }
        }

        public StockDataCollection NasdaqMarketData
        {
            get
            {
                return _nasdaqMarketData;
            }
            private set
            {
                _nasdaqMarketData = value;
                OnPropertyChanged("NasdaqMarketData");
                _nasdaqCommand.NotifyExecuteChanged();
            }
        }

        public StockDataCollection MergedMarketData
        {
            get
            {
                return _mergedMarketData;
            }
            private set
            {
                _mergedMarketData = value;
                OnPropertyChanged("MergedMarketData");
                _mergedCommand.NotifyExecuteChanged();
            }
        }

        public StockDataCollection NormalizedMarketData
        {
            get
            {
                return _normalizedMarketData;
            }
            private set
            {
                _normalizedMarketData = value;
                OnPropertyChanged("NormalizedMarketData");
                _normalizedCommand.NotifyExecuteChanged();
            }
        }

        public StockDataCollection FedHistoricalData
        {
            get
            {
                return _fedHistoricalData;
            }
            private set
            {
                _fedHistoricalData = value;
                OnPropertyChanged("FedHistoricalData");
                _fedHistoricalCommand.NotifyExecuteChanged();
            }
        }

        public StockDataCollection NormalizedHistoricalData
        {
            get
            {
                return _normalizedHistoricalData;
            }
            private set
            {
                _normalizedHistoricalData = value;
                OnPropertyChanged("NormalizedHistoricalData");
                _normalizedHistoricalCommand.NotifyExecuteChanged();
            }
        }

        public StockAnalysisCollection AnalyzedStockData
        {
            get
            {
                return _analyzedStockData;
            }
            private set
            {
                _analyzedStockData = value;
                OnPropertyChanged("AnalyzedMarketData");
                _analyzedCommand.NotifyExecuteChanged();
            }
        }

        public StockAnalysisCollection AnalyzedHistoricalData
        {
            get
            {
                return _analyzedHistoricalData;
            }
            private set
            {
                _analyzedHistoricalData = value;
                OnPropertyChanged("AnalyzedHistoricalData");
                _analyzedHistoricalCommand.NotifyExecuteChanged();
            }
        }

        public MarketModel ModeledMarketData
        {
            get
            {
                return _modeledMarketData;
            }
            private set
            {
                _modeledMarketData = value;
                OnPropertyChanged("ModeledMarketData");
                _modeledCommand.NotifyExecuteChanged();
            }
        }

        public MarketModel ModeledHistoricalData
        {
            get
            {
                return _modeledHistoricalData;
            }
            private set
            {
                _modeledHistoricalData = value;
                OnPropertyChanged("ModeledHistoricalData");
                _modeledHistoricalCommand.NotifyExecuteChanged();
            }
        }

        public MarketRecommendation Recommendation
        {
            get
            {
                return _recommendation;
            }
            private set
            {
                _recommendation = value;
                OnPropertyChanged("Recommendation");
                _recommendationCommand.NotifyExecuteChanged();
            }
        }    
        #endregion

        #region Commands
        public ICommand CloseCommand
        {
            get
            {
                if (_closeCommand == null)
                    _closeCommand = new Command(_ => OnRequestClose());

                return _closeCommand;
            }
        }

        public ICommand CalculateCommand
        {
            get
            {
                if (_calculateCommand == null)
                    _calculateCommand = new Command(_ => this.OnRequestCalculate());

                return _calculateCommand;
            }
        }

        public ICommand CancelCommand
        {
            get
            {
                if (_cancelCommand == null)
                    _cancelCommand = new Command(
                        _ => this.OnRequestCancel(),
                        _ => ModelState == State.Calculating
                        );

                return _cancelCommand;
            }
        }

        public ICommand NyseCommand
        {
            get
            {
                if (_nyseCommand == null)
                    _nyseCommand = new Command(
                        _ => RaiseEvent(RequestNyse), 
                        _ => _nyseMarketData != null
                        );

                return _nyseCommand;
            }
        }

        public ICommand NasdaqCommand
        {
            get
            {
                if (_nasdaqCommand == null)
                    _nasdaqCommand = new Command(
                        _ => RaiseEvent(this.RequestNasdaq),
                        _ => this._nasdaqMarketData != null
                        );

                return _nasdaqCommand;
            }
        }

        public ICommand MergedCommand
        {
            get
            {
                if (_mergedCommand == null)
                    _mergedCommand = new Command(
                        _ => RaiseEvent(this.RequestMerged),
                        _ => this._mergedMarketData != null
                        );

                return _mergedCommand;
            }
        }

        public ICommand NormalizedCommand
        {
            get
            {
                if (_normalizedCommand == null)
                    _normalizedCommand = new Command(
                        _ => RaiseEvent(this.RequestNormalized),
                        _ => this._normalizedMarketData != null
                        );

                return _normalizedCommand;
            }
        }

        public ICommand FedHistoricalCommand
        {
            get
            {
                if (_fedHistoricalCommand == null)
                    _fedHistoricalCommand = new Command(
                        _ => RaiseEvent(this.RequestFedHistorical),
                        _ => this._fedHistoricalData != null
                        );

                return _fedHistoricalCommand;
            }
        }

        public ICommand NormalizedHistoricalCommand
        {
            get
            {
                if (_normalizedHistoricalCommand == null)
                    _normalizedHistoricalCommand = new Command(
                        _ => RaiseEvent(this.RequestNormalizedHistorical),
                        _ => this._normalizedHistoricalData != null
                        );

                return _normalizedHistoricalCommand;
            }
        }

        public ICommand AnalyzedCommand
        {
            get
            {
                if (_analyzedCommand == null)
                    _analyzedCommand = new Command(
                        _ => RaiseEvent(this.RequestAnalyzed),
                        _ => this._analyzedStockData != null
                        );

                return _analyzedCommand;
            }
        }

        public ICommand AnalyzedHistoricalCommand
        {
            get
            {
                if (_analyzedHistoricalCommand == null)
                    _analyzedHistoricalCommand = new Command(
                        _ => RaiseEvent(this.RequestAnalyzedHistorical),
                        _ => this._analyzedHistoricalData != null
                        );

                return _analyzedHistoricalCommand;
            }
        }

        public ICommand ModeledCommand
        {
            get
            {
                if (_modeledCommand == null)
                    _modeledCommand = new Command(
                        _ => RaiseEvent(this.RequestModeled),
                        _ => this._modeledMarketData != null
                        );

                return _modeledCommand;
            }
        }

        public ICommand ModeledHistoricalCommand
        {
            get
            {
                if (_modeledHistoricalCommand == null)
                    _modeledHistoricalCommand = new Command(
                        _ => RaiseEvent(this.RequestModeledHistorical),
                        _ => this._modeledHistoricalData != null
                        );

                return _modeledHistoricalCommand;
            }
        }

        public ICommand RecommendationCommand
        {
            get
            {
                if (_recommendationCommand == null)
                    _recommendationCommand = new Command(
                        _ => RaiseEvent(this.RequestRecommendation),
                        _ => this._recommendation != null
                        );

                return _recommendationCommand;
            }
        }      
            
        #endregion

        #region Command Implementations

        // helper
        void RaiseEvent(EventHandler handler)
        {
            if (handler != null)
                handler(this, EventArgs.Empty);
        }

        // helper
        private void TryCancelCalculation()
        {
            if (this._cancellationTokenSource != null)
            {
                this._cancellationTokenSource.Cancel();
                this._cancellationTokenSource = null;
            }
        }

        void OnRequestCalculate()
        {
            // Initialize the result properties to null
            ResetResultProperties();

            // Place the view model into calculation mode
            ModelState = State.Calculating;

            // Update the property containing the status text
            StatusTextBoxText = "...calculating...";
    
            // Set up the objects that control cancellation
            this._cancellationTokenSource = new CancellationTokenSource();
            CancellationToken token = this._cancellationTokenSource.Token;

            // Start the analysis
            var analysisEngine = new AnalysisEngine(token);
            AnalysisTasks tasks = analysisEngine.StartAnalysisParallel();

            // Add continuations so that view model properties are updated when each subtask completes
            AddButtonContinuations(tasks);
        }

        /// <summary>
        /// Adds continuations to analysis tasks so that the view model's properties are updated when 
        /// each task has results available for display.
        /// </summary>
        /// <param name="tasks">The task record</param>
        /// <param name="token">The cancellation token</param>
        void AddButtonContinuations(AnalysisTasks tasks)
        {
            TaskScheduler s = TaskScheduler.FromCurrentSynchronizationContext();

            tasks.LoadNyseData.ContinueWith((t) => { this.NyseMarketData = t.Result; }, s);
            tasks.LoadNasdaqData.ContinueWith((t) => { this.NasdaqMarketData = t.Result; }, s);
            tasks.LoadFedHistoricalData.ContinueWith((t) => { this.FedHistoricalData = t.Result; }, s);
            tasks.MergeMarketData.ContinueWith((t) => { this.MergedMarketData = t.Result; }, s);
            tasks.NormalizeHistoricalData.ContinueWith((t) => { this.NormalizedHistoricalData = t.Result; }, s);
            tasks.NormalizeMarketData.ContinueWith((t) => { this.NormalizedMarketData = t.Result; }, s);
            tasks.AnalyzeHistoricalData.ContinueWith((t) => { this.AnalyzedHistoricalData = t.Result; }, s);
            tasks.AnalyzeMarketData.ContinueWith((t) => { this.AnalyzedStockData = t.Result; }, s);
            tasks.ModelHistoricalData.ContinueWith((t) => { this.ModeledHistoricalData = t.Result; }, s);
            tasks.ModelMarketData.ContinueWith((t) => { this.ModeledMarketData = t.Result; }, s);
            tasks.CompareModels.ContinueWith((t) => { 
                this.Recommendation = t.Result;
                this.StatusTextBoxText = (this.Recommendation == null) ? "Canceled" : this.Recommendation.Recommendation;
                this.ModelState = State.Ready;            
            }, s);            
        }

        void ResetResultProperties()
        {
            this.NyseMarketData = null;
            this.NasdaqMarketData = null;
            this.MergedMarketData = null;
            this.NormalizedMarketData = null;
            this.FedHistoricalData = null;
            this.NormalizedHistoricalData = null;
            this.AnalyzedStockData = null;
            this.AnalyzedHistoricalData = null;
            this.ModeledMarketData = null;
            this.ModeledHistoricalData = null;
            this.Recommendation = null;
        }

        void OnRequestClose()
        {
            TryCancelCalculation();
            RaiseEvent(RequestClose);
        }

        void OnRequestCancel()
        {
            TryCancelCalculation();
            ModelState = State.Canceling;
            StatusTextBoxText = "canceling";
        }

        #endregion

        #region INotifyPropertyChanged Implementation
        protected void OnPropertyChanged(string name)
        {
            PropertyChangedEventHandler handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(name));
            }
        } 
        #endregion

        #region IDisposable Members

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_cancellationTokenSource != null)
                {
                    _cancellationTokenSource.Dispose();
                    _cancellationTokenSource = null;
                }
            }
        }
 
        #endregion
    }
}
