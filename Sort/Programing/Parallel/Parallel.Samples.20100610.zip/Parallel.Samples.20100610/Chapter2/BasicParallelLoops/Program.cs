﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Utilities;

namespace BasicParallelLoops
{
    class Program
    {
        static void Main(string[] args)
        {
            Task.Factory.StartNew(() => Main_1(args)).Wait();
        }

        static void Main_1(string[] args)
        {

#if DEBUG
            var verify = true; 
#else   
            var verify = false;
#endif
            var examples = new ParallelForExample[]
                              { 
                                new ParallelForExample() { LoopBodyComplexity = 10000000, NumberOfSteps = 10, VerifyResult = verify },
                                new ParallelForExample() { LoopBodyComplexity = 1000000, NumberOfSteps = 100, VerifyResult = verify },
                                new ParallelForExample() { LoopBodyComplexity = 10000, NumberOfSteps = 10000, VerifyResult = verify },
                                new ParallelForExample() { LoopBodyComplexity = 100, NumberOfSteps = 1000000, VerifyResult = verify },
                                new ParallelForExample() { LoopBodyComplexity = 10, NumberOfSteps = 10000000, VerifyResult = verify }
                                                              
                              };

            foreach (var e1 in examples)
                e1.DoParallelFor();

            foreach(var e2 in examples)
                e2.DoParallelForEach();

            Console.WriteLine("Press enter...");
            Console.ReadLine();
        }
    }
}
