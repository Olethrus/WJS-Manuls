﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using System;
using System.Collections.Generic;

namespace BasicParallelLoops
{
    public class Tree<T>
    {
        public Tree<T> Left, Right;
        public T Data;

        public static IEnumerable<Tree<T>> Iterate(Tree<T> root)
        {
            var queue = new Queue<Tree<T>>();
            if (root != null) queue.Enqueue(root);
            while (queue.Count > 0)
            {
                var node = queue.Dequeue();
                yield return node;
                if (node.Left != null) queue.Enqueue(node.Left);
                if (node.Right != null) queue.Enqueue(node.Right);
            }
        }

        public static IEnumerable<Tree<T>> Create(IEnumerable<T> source)
        {
            var queue = new Queue<Tree<T>>();
            Tree<T> root = new Tree<T>();
            queue.Enqueue(root);
            IEnumerator<T> enumerator = source.GetEnumerator();

            while (enumerator.MoveNext())
            {
                var node = queue.Dequeue();
                node.Data = enumerator.Current;
                yield return node;
                if (node.Left != null) queue.Enqueue(node.Left);
                if (node.Right != null) queue.Enqueue(node.Right);
            }
        }
    }
}
