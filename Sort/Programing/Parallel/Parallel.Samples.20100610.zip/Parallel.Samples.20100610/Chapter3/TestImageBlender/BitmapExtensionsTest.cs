﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Drawing;
using ImageBlender;

namespace ImageBlenderTests
{
    [TestClass]
    public class BitmapExtensionsTest
    {
        /// <summary>
        /// This test shows what we must do to set alpha, can NOT set alpha in source image
        /// </summary>
        [TestMethod]
        public void SetAlphaTest()
        {
            // Load image, must assume image exists at given path
            string sourceDir = @"C:\Users\Public\Pictures\Sample Pictures";
            string file = "Chrysanthemum.jpg";
            string path = sourceDir + "\\" + file;
            var source = new Bitmap(path);

            // Can NOT set alpha in source image, must copy.  See TestAlphaInSource below.
            var layer = new Bitmap(source.Width, source.Height);
            source.CopyPixels(layer);
            
            // Set alpha
            int alpha = 128;
            layer.SetAlpha(alpha);

            // Check one pixel from the middle of the image
            int xSample = source.Width / 2;  
            int ySample = source.Height / 2;
            var s = source.GetPixel(xSample, ySample); 
            var l = layer.GetPixel(xSample, ySample);

            // Color should be unchanged
            Assert.AreEqual(s.R, l.R);
            Assert.AreEqual(s.G, l.G);
            Assert.AreEqual(s.B, l.B);

            // Alpha should be assigned
            Assert.AreEqual(alpha, l.A);
        }

        /// <summary>
        /// This test shows that we can NOT set alpha in the original source image
        /// </summary>
        [TestMethod]
        public void SetAlphaInSourceTest()
        {
            // Load image, must assume image exists at given path
            string sourceDir = @"C:\Users\Public\Pictures\Sample Pictures";
            string file = "Chrysanthemum.jpg";
            string path = sourceDir + "\\" + file;
            var source = new Bitmap(path); // assume picture exists at given path 

            // Can NOT set alpha in source image, must copy.  
            // BUT here we DON'T copy.
            // var layer = new Bitmap(source.Width, source.Height);
            // source.CopyPixels(layer);

            // Attempt to set alpha in source image.
            // Executes without complaint but has no effect.
            int alpha = 128;
            source.SetAlpha(alpha);

            // Check one pixel from the middle of the image
            int xSample = source.Width / 2;
            int ySample = source.Height / 2;
            var s = source.GetPixel(xSample, ySample);
            // var l = layer.GetPixel(xSample, ySample);

            // Color should be unchanged
            //Assert.AreEqual(s.R, l.R);
            //Assert.AreEqual(s.G, l.G);
            //Assert.AreEqual(s.B, l.B);

            // Alpha is NOT assigned in source image
            // Here AreNotEqual assertion succeeds when alpha is NOT assigned.
            Assert.AreNotEqual(alpha, s.A);
        }
    }
}
