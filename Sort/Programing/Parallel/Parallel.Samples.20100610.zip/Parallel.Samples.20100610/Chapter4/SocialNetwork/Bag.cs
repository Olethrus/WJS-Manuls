﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;

using SubscriberID = System.Int32;

namespace SocialNetwork
{
    using IDBag = Dictionary<SubscriberID, int>;
    using IDBagItem = KeyValuePair<SubscriberID, int>;
    // using IDBagItemList = List<KeyValuePair<SubscriberID, int>>; // to sort, must use list of bag items not bag itself
    using IDBagItemList = Collection<KeyValuePair<SubscriberID, int>>;  // to sort, must use list of bag items not bag itself

    /// <summary>
    /// Bag of IDs, represented as dictionary where Key is ID and Value is its multiplicity.
    /// </summary>
    static class Bag
    {
        /// <summary>
        /// Initialize Bag from HashSet, each ID has mulitplicity 1
        /// </summary>
        /// <param name="friends"></param>
        /// <returns></returns>
        public static IDBag Create(HashSet<SubscriberID> friends)
        {
            var bag = new IDBag();
            foreach (SubscriberID friend in friends)
            {
                bag[friend] = 1;
            }
            return bag;
        }

        /// <summary>
        /// Bag union 
        /// </summary>
        /// <param name="bag1">First bag</param>
        /// <param name="bag2">Second bag</param>
        /// <returns>Union of bag1 and bag2</returns>
        public static IDBag Union(IDBag bag1, IDBag bag2)
        {
            if (bag1.Count < bag2.Count)
            {
                return Union(bag2, bag1);
            }
            else
            {
                var union = new IDBag();
                foreach (var item in bag1)
                {
                    union.Add(item.Key, item.Value);
                }
                foreach (var item in bag2)
                {
                    var friend = item.Key;
                    var count = item.Value;
                    union[friend] = union.ContainsKey(friend) ? union[friend] + count : count;
                }
                return union;
            }
        }

        /// <summary>
        /// Return sorted list of most numerous items in bag.
        /// </summary>
        /// <param name="bag">Bag of IDs</param>
        /// <param name="maxItems">Maximum number of bag items to return</param>
        /// <returns>List of ID/multiplicity pairs, sorted in order of decreasing multiplicity</returns>
        public static IDBagItemList MostNumerous(IEnumerable<IDBagItem> bag, int maxItems)
        {
            // mostNumerous is sorted by item value, mostNumerous[0] is smallest 
            var mostNumerous = new IDBagItemList();
            foreach (IDBagItem item in bag)
            {
                if (mostNumerous.Count < maxItems)
                {
                    InsertInOrder(item, mostNumerous);
                }
                else
                {
                    int lastIndex = mostNumerous.Count - 1;
                    if (item.Value > mostNumerous[lastIndex].Value) // smallest value is at the end
                    {
                        mostNumerous.RemoveAt(lastIndex);
                        InsertInOrder(item, mostNumerous);
                    }
                }
            }
            return mostNumerous;
        }

        /// <summary>
        /// Insert ID/multiplicity pair in sorted list
        /// </summary>
        /// <param name="item">ID/multiplicity pair to insert in list</param>
        /// <param name="list">list of ID/multiplicity pairs, sort by multiplicity, largest to smallest</param>
        static void InsertInOrder(IDBagItem item, IDBagItemList list)
        {
            if (list.Count == 0)
            {
                list.Insert(0, item);
            }
            else
            {
                int i;
                for (i = 0; i < list.Count; i++)
                {
                    if (item.Value >= list[i].Value) break;
                }
                list.Insert(i, item); // inserts ahead of list[i], results in descending order
            }
        }
 
        /// <summary>
        /// Print list of ID/multiplicity pairs.
        /// </summary>
        /// <param name="list">List of ID/multiplicity pairs</param>
        public static void Print(IDBagItemList list)
        {
            for (int i = 0; i < list.Count; i++)
            {
                Console.WriteLine("{0,10:D}{1,5:D}", list[i].Key, list[i].Value);
            }
        }
    }
}