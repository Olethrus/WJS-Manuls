﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BasicFutures;

namespace BasicFuturesTests
{
	/// <summary>
	/// Summary description for UnitTest1
	/// </summary>
	[TestClass]
	public class ProgramTests
	{
		private const int ExpectedValue = 505;

		[TestMethod]
		public void Example1ReturnsExpectedValue()
		{
			Assert.AreEqual(ExpectedValue, Program.Example1());
		}

		[TestMethod]
		public void Example2ReturnsExpectedValue()
		{
			Assert.AreEqual(ExpectedValue, Program.Example2());
		}

		[TestMethod]
		public void Example3ReturnsExpectedValue()
		{
			Assert.AreEqual(ExpectedValue, Program.Example3());
		}

		[TestMethod]
		public void Example4ReturnsExpectedValue()
		{
			Assert.AreEqual(ExpectedValue, Program.Example4());
		}

		[TestMethod]
		public void Example5ReturnsExpectedValue()
		{
			Assert.AreEqual(ExpectedValue, Program.Example4());
		}
	}
}