﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Utilities;

namespace a_Dash
{
    /// <summary>
    /// Component for data analysis
    /// </summary>
    public class AnalysisEngine
    {
        // internal scaling factor
        readonly double _speedFactor;

        // structure used to check for an asynchronous cancellation request
        CancellationToken _token;

        /// <summary>
        /// Creates an instance that can perform market analysis
        /// </summary>
        /// <param name="token">Token for user-initiated asynchronous cancellation of analysis operations</param>
        public AnalysisEngine(CancellationToken token)
            : this(token, 1.0d)
        {
        }

        /// <summary>
        /// Creates an instance that can perform market analysis
        /// </summary>
        /// <param name="token">Token for user-initiated asynchronous cancellation of analysis operations</param>
        /// <param name="speedFactor">Scale factor for amount of time to spend in simulation. The value 0.0 provides the 
        /// fastest execution. The value 1.0 provides standard execution. Higher values are slower.</param>
        /// <remarks>The speedFactor argument is provided for the convenience of unit tests. It is not used 
        /// by the view model.</remarks>
        public AnalysisEngine(CancellationToken token, double speedFactor)
        {
            _token = token;
            _speedFactor = speedFactor;
        }

        #region CreateSampleData

        static IList<StockData> MakeNyseSecurityInfo()
        {
            return GenerateSecurities("NYSE", 100);
        }

        static IList<StockData> MakeNasdaqSecurityInfo()
        {
            return GenerateSecurities("NASDAQ", 100);
        }

        static IList<StockData> MakeFedSecurityInfo()
        {
            return GenerateSecurities("", 100);
        }

        static IList<StockData> GenerateSecurities(string exchange, int size)
        {
            var result = new List<StockData>();
            for (int i = 0; i < size; i++)
                result.Add(new StockData(exchange + " Stock " + i, new[] { 0.0d, 1.0d, 2.0d }));
            return result;
        }

        #endregion

        #region Analysis Helper Methods

        StockDataCollection LoadNyseData()
        {
            SampleUtilities.DoIoIntensiveOperation(2.5, _token);
            if (_token.IsCancellationRequested)
                return null;

            return new StockDataCollection(MakeNyseSecurityInfo());
        }

        StockDataCollection LoadNasdaqData()
        {
            SampleUtilities.DoIoIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;

            return new StockDataCollection(MakeNasdaqSecurityInfo());
        }

        StockDataCollection LoadFedHistoricalData()
        {
            SampleUtilities.DoIoIntensiveOperation(3.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;

            return new StockDataCollection(MakeFedSecurityInfo());
        }

        StockDataCollection MergeMarketData(IEnumerable<StockDataCollection> allMarketData)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            var securities = new List<StockData>();

            if (!_token.IsCancellationRequested)
            {
                foreach (StockDataCollection md in allMarketData)
                    securities.AddRange(md);
            }

            if (_token.IsCancellationRequested)
                return null;
            else
                return new StockDataCollection(securities);
        }

        /// <summary>
        /// Normalize stock data.
        /// </summary>
        StockDataCollection NormalizeData(StockDataCollection marketData)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return new StockDataCollection(marketData);
        }

        StockAnalysisCollection AnalyzeData(StockDataCollection data)
        {
            if (_token.IsCancellationRequested)
                return null;
            return MarketAnalyzer.Run(data);
        }

        // This method is included for illustrative purposes
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1811:AvoidUncalledPrivateCode")]
        StockAnalysisCollection AnalyzeDataInParallel(StockDataCollection data)
        {
            if (_token.IsCancellationRequested)
                return null;

            StockAnalysis[] result = new StockAnalysis[data.Count];
            Parallel.For(0, data.Count, (i) =>
                {
                    result[i] = new StockAnalysis(data[i].Name, data[i].GetPriceHistory().Average());
                });
            return new StockAnalysisCollection(result); 
        }

        MarketModel RunModel(StockAnalysisCollection data)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return MarketModeler.Run(data);
        }

        MarketRecommendation CompareModels(IEnumerable<MarketModel> models)
        {
            SampleUtilities.DoCpuIntensiveOperation(2.0 * _speedFactor, _token);
            if (_token.IsCancellationRequested)
                return null;
            else
                return ModelComparer.Run(models.ToArray());
        }

        #endregion

        #region Analysis Public Methods

        /// <summary>
        /// Creates a market recommendation using a fully sequential operation
        /// </summary>
        /// <returns>A market recommendation</returns>
        public MarketRecommendation DoAnalysisSequential()
        {
            StockDataCollection nyseData = 
                LoadNyseData();
            StockDataCollection nasdaqData = 
                LoadNasdaqData();
            StockDataCollection mergedMarketData = 
                MergeMarketData(new[]{nyseData, nasdaqData});
            StockDataCollection normalizedMarketData = 
                NormalizeData(mergedMarketData);
            StockDataCollection fedHistoricalData = 
                LoadFedHistoricalData();
            StockDataCollection normalizedHistoricalData = 
                NormalizeData(fedHistoricalData);
            StockAnalysisCollection analyzedStockData = 
                AnalyzeData(normalizedMarketData);
            MarketModel modeledMarketData = 
                RunModel(analyzedStockData);
            StockAnalysisCollection analyzedHistoricalData = 
                AnalyzeData(normalizedHistoricalData);
            MarketModel modeledHistoricalData =
                RunModel(analyzedHistoricalData);
            MarketRecommendation recommendation = 
                CompareModels(new[] {modeledMarketData, modeledHistoricalData});
            return recommendation;
        }

        public MarketRecommendation DoAnalysisParallel()
        {
            TaskFactory f = Task.Factory;

            Task<StockDataCollection> loadNyseData =
                f.StartNew<StockDataCollection>(
                    () => LoadNyseData(),
                    TaskCreationOptions.LongRunning);

            Task<StockDataCollection> loadNasdaqData =
                f.StartNew<StockDataCollection>(
                    () => LoadNasdaqData(),
                    TaskCreationOptions.LongRunning);

            Task<StockDataCollection> mergeMarketData =
                f.ContinueWhenAll<StockDataCollection, StockDataCollection>(
                    new[] { loadNyseData, loadNasdaqData },
                    (tasks) => 
                    { 
                        Task.WaitAll(tasks);
                        return MergeMarketData(from t in tasks select t.Result);
                    });

            Task<StockDataCollection> normalizeMarketData =
                mergeMarketData.ContinueWith(
                    (t) => NormalizeData(t.Result));

            Task<StockDataCollection> loadFedHistoricalData =
                f.StartNew<StockDataCollection>(
                    () => LoadFedHistoricalData(),
                    TaskCreationOptions.LongRunning);

            Task<StockDataCollection> normalizeHistoricalData =
                loadFedHistoricalData.ContinueWith(
                    (t) => NormalizeData(t.Result));

            Task<StockAnalysisCollection> analyzeMarketData =
                normalizeMarketData.ContinueWith(
                    (t) => AnalyzeData(t.Result));

            Task<MarketModel> modelMarketData =
                analyzeMarketData.ContinueWith(
                    (t) => RunModel(t.Result));

            Task<StockAnalysisCollection> analyzeHistoricalData =
                normalizeHistoricalData.ContinueWith(
                    (t) => AnalyzeData(t.Result));

            Task<MarketModel> modelHistoricalData =
                analyzeHistoricalData.ContinueWith(
                    (t) => RunModel(t.Result));

            Task<MarketRecommendation> compareModels =
                f.ContinueWhenAll<MarketModel, MarketRecommendation>(
                    new[] { modelMarketData, modelHistoricalData },
                    (tasks) => 
                      {
                         Task.WaitAll(tasks);
                         return CompareModels(from t in tasks select t.Result);
                      });

            return compareModels.Result;
        } 

        /// <summary>
        /// Initiates market analysis using parallel computation.
        /// </summary>        
        /// <returns>Task record that may be queried for results of the analysis</returns>
        /// <remarks>Compare with the DoAnalysisSequential method</remarks>
        public AnalysisTasks StartAnalysisParallel()
        {
            TaskFactory factory = Task.Factory;

            Task<StockDataCollection> loadNyseData =
                Task<StockDataCollection>.Factory.StartNew(
                    () => LoadNyseData(),
                    TaskCreationOptions.LongRunning);

            Task<StockDataCollection> loadNasdaqData =
                Task<StockDataCollection>.Factory.StartNew(
                    () => LoadNasdaqData(),
                    TaskCreationOptions.LongRunning);

            Task<StockDataCollection> mergeMarketData =
                factory.ContinueWhenAll<StockDataCollection, StockDataCollection>(
                    new[] { loadNyseData, loadNasdaqData },
                    (tasks) => MergeMarketData(from t in tasks select t.Result));

            Task<StockDataCollection> normalizeMarketData =
                mergeMarketData.ContinueWith(
                    (t) => NormalizeData(t.Result));

            Task<StockDataCollection> loadFedHistoricalData =
                Task<StockDataCollection>.Factory.StartNew(
                    () => LoadFedHistoricalData(),
                    TaskCreationOptions.LongRunning);

            Task<StockDataCollection> normalizeHistoricalData =
                loadFedHistoricalData.ContinueWith(
                    (t) => NormalizeData(t.Result));

            Task<StockAnalysisCollection> analyzeMarketData =
                normalizeMarketData.ContinueWith(
                    (t) => AnalyzeData(t.Result));

            Task<MarketModel> modelMarketData =
                analyzeMarketData.ContinueWith(
                    (t) => RunModel(t.Result));

            Task<StockAnalysisCollection> analyzeHistoricalData =
                normalizeHistoricalData.ContinueWith(
                    (t) => AnalyzeData(t.Result));

            Task<MarketModel> modelHistoricalData =
                analyzeHistoricalData.ContinueWith(
                    (t) => RunModel(t.Result));

            Task<MarketRecommendation> compareModels =
                factory.ContinueWhenAll<MarketModel, MarketRecommendation>(
                    new[] { modelMarketData, modelHistoricalData },
                    (tasks) => CompareModels(from t in tasks select t.Result));

            return new AnalysisTasks()
                 {
                     LoadNyseData = loadNyseData,
                     LoadNasdaqData = loadNasdaqData,
                     MergeMarketData = mergeMarketData,
                     NormalizeMarketData = normalizeMarketData,
                     LoadFedHistoricalData = loadFedHistoricalData,
                     NormalizeHistoricalData = normalizeHistoricalData,
                     AnalyzeMarketData = analyzeMarketData,
                     ModelMarketData = modelMarketData,
                     AnalyzeHistoricalData = analyzeHistoricalData,
                     ModelHistoricalData = modelHistoricalData,
                     CompareModels = compareModels
                 };
        }

        #endregion
    }
}
