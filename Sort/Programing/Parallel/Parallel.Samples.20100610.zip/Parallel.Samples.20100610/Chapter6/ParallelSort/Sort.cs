﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Threading.Tasks;

namespace ParallelSort
{
    public static class Sort
    {
        public static int Threshold = 150; // array length to use InsertionSort instead of SequentialQuickSort

        public static void InsertionSort(int[] array, int from, int to)
        {
            for (int i = from + 1; i < to; i++)
            {
                var a = array[i];
                int j = i - 1;
                while (j >= from && array[j] > a)
                {
                    array[j + 1] = array[j];
                    j--;
                }
                array[j + 1] = a;
            }
        }

        static void Swap(int[] array, int i, int j)
        {
            var temp = array[i];
            array[i] = array[j];
            array[j] = temp;
        }

        static int Partition(int[] array, int from, int to, int ipivot)
        {
            // Pre: from <= ipivot < to (other than that, pivot is arbitrary)
            var apivot = array[ipivot];  // pivot value
            Swap(array, ipivot, to - 1); // move pivot value to end for now, after this ipivot not used
            var newpivot = from; // new ipivot
            for (int i = from; i < to - 1; i++) // be careful to leave pivot value at the end
            {
                // Invariant: from <= newpivot <= i < to - 1 && 
                // forall from <= j <= newpivot, array[j] <= apivot && forall newpivot < j <= i, array[j] > apivot
                if (array[i] <= apivot)
                {
                    Swap(array, newpivot, i);  // move value smaller than apivot down to newpivot
                    newpivot++;
                }
            }
            Swap(array, newpivot, to - 1); // move pivot value to its final place
            return newpivot; // new ipivot
            // Post: forall i <= newpivot, array[i] <= array[newpivot]  && forall i > ...
        }

        public static void SequentialQuickSort(int[] array)
        {
            SequentialQuickSort(array, 0, array.Length);
        }

        static void SequentialQuickSort(int[] array, int from, int to)
        {
            if (to - from <= Threshold)
            {
                InsertionSort(array, from, to);
            }
            else
            {
                int ipivot = from + (to - from) / 2; // could be anything, use middle
                ipivot = Partition(array, from, to, ipivot);
                // Assert: forall i < ipivot, array[i] <= array[ipivot]  && forall i > ...
                SequentialQuickSort(array, from, ipivot);
                SequentialQuickSort(array, ipivot + 1, to);
            }
        }

        public static void ParallelQuickSort(int[] array)
        {
           ParallelQuickSort(array, 0, array.Length, 
                (int) Math.Log(Environment.ProcessorCount, 2) + 2);
        }

        static void ParallelQuickSort(int[] array, int from, int to, int depthRemaining)
        {
            if (to - from <= Threshold)
            {
                InsertionSort(array, from, to);
            }
            else
            {
                int ipivot = from + (to - from) / 2; // could be anything, use middle
                ipivot = Partition(array, from, to, ipivot);
                if (depthRemaining > 0)
                {
                    Parallel.Invoke(
                        () => ParallelQuickSort(array, from, ipivot, depthRemaining - 1),
                        () => ParallelQuickSort(array, ipivot + 1, to, depthRemaining - 1));
                }
                else
                {
                    ParallelQuickSort(array, from, ipivot, 0);
                    ParallelQuickSort(array, ipivot + 1, to, 0);
                }
            }
        }
    }
}
