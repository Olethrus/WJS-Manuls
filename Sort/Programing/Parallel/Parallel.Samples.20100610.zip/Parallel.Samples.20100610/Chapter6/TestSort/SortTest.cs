﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using Microsoft.VisualStudio.TestTools.UnitTesting;
using ParallelSort;
using System;

namespace ParallelSortTests
{
    [TestClass]
    public class SortTest
    {
        static bool IsSorted(int[] array)
        {
            for (int i = 0; i < array.Length - 1; i++) 
				if (array[i] > array[i + 1]) return false;
            return true;
        }

        [TestMethod]
        public void MakeArrayTest()
        {
            const int length = 8;
            var a = Program.MakeArray(length, Environment.TickCount);
            Assert.AreEqual(a.Length, length);
        }

        [TestMethod]
        public void InsertionSortTest()
        {
            const int length = 8;
            var a = Program.MakeArray(length, Environment.TickCount);
            Sort.InsertionSort(a, 0, a.Length);
            Assert.AreEqual(a.Length, length);
            Assert.IsTrue(IsSorted(a));
        }

        [TestMethod]
        public void QuickSortShortTest()
        {
            int length = Sort.Threshold / 2;   // won't call SequentialQuickSort recursively
            var a = Program.MakeArray(length, Environment.TickCount);
            Sort.SequentialQuickSort(a);
            Assert.AreEqual(a.Length, length);
            Assert.IsTrue(IsSorted(a));
        }

        [TestMethod]
        public void QuickSortLongTest()
        {
            int length = Sort.Threshold * 10;   // will call SequentialQuickSort recursively
            var a = Program.MakeArray(length, Environment.TickCount);
            Sort.SequentialQuickSort(a);
            Assert.AreEqual(a.Length, length);
            Assert.IsTrue(IsSorted(a));
        }

        [TestMethod]
        public void ParallelQuickSortTest()
        {
            int length = Sort.Threshold * 10;   // will call SequentialQuickSort recursively
            var a = Program.MakeArray(length, Environment.TickCount);
            Sort.ParallelQuickSort(a);
            Assert.AreEqual(a.Length, length);
            Assert.IsTrue(IsSorted(a));
        }
    }
}
