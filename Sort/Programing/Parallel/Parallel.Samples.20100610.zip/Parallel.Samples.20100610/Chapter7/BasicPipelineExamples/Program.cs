﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Utilities;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using System.IO;
using System.Security.Cryptography;

namespace BasicPipelineExamples
{
    class Program
    {
        static string[] Phrases = { "the", "<Adjective>", "<Adjective>", "<Noun>", 
                                    "jumped over the", "<Adjective>", "<Noun>", "." };
        static string[] Adjectives = { "quick", "brown", "lazy" };
        static string[] Nouns = { "fox", "dog" };
        const string TargetSentence = "The quick brown fox jumped over the lazy dog.";
        const string SuccessString = "Surprise!!!";

        const int NumberOfSentences = 1000;
        const int BufferBoundedCapacity = 32;
        static double[] StageTime = { 0.0025, 0.0025, 0.0025, 0.0025 };
        const string PathForSequentialResults = @".\Chapter7Sequential.txt";
        const string PathForPipelineResults = @".\Chapter7Pipeline.txt";

        static void Main(string[] args)
        {
            int seed = Environment.TickCount;
            SampleUtilities.TimedAction(() => Chapter7Example01Sequential(seed), "Write sentences, sequential");
            SampleUtilities.TimedAction(() => Chapter7Example01Pipeline(seed), "Write sentences, pipeline");
            CheckResults();
            Console.WriteLine("(press any key)");
            Console.ReadKey();
        }

        static IEnumerable<string> PhraseSource(int seed)
        {
            Random r = new Random(seed);
            for (int i = 0; i < NumberOfSentences; i++)
                foreach (var line in Phrases)
                {
                    if (line == "<Adjective>")
                        yield return Adjectives[r.Next(0, Adjectives.Length)];
                    else if (line == "<Noun>")
                        yield return Nouns[r.Next(0, Nouns.Length)];
                    else
                        yield return line;
                }
        }

        static void Chapter7Example01Sequential(int seed)
        {
            var isFirstPhrase = true;
            string capitalizedPhrase = null;
            var sentenceBuilder = new StringBuilder();
            string sentence = null;
            int sentenceCount = 1;
            using (StreamWriter outfile = new StreamWriter(PathForSequentialResults))
            {
                Console.Write("Begin Sequential Sentence Builder");
                foreach (var phrase in PhraseSource(seed))
                {
                    Stage1AdditionalWork();
                    Stage2AdditionalWork();
                    capitalizedPhrase = isFirstPhrase ?
                        phrase.Substring(0, 1).ToUpper() + phrase.Substring(1) : phrase;
                    Stage3AdditionalWork();
                    if (!isFirstPhrase && phrase != ".")
                        sentenceBuilder.Append(" ");
                    sentenceBuilder.Append(capitalizedPhrase);
                    isFirstPhrase = false;
                    if (phrase == ".")
                    {
                        sentence = sentenceBuilder.ToString();
                        if (sentence == TargetSentence)
                            sentence = sentence + "       " + SuccessString;
                        sentenceBuilder.Clear();
                        isFirstPhrase = true;
                        Stage4AdditionalWork();
                        outfile.WriteLine(sentenceCount.ToString() + " " + sentence);
                        if (sentenceCount % (NumberOfSentences / 10) == 0) Console.Write(".");
                        sentenceCount += 1;
                    }
                }
                Console.WriteLine("End");
            }
        }

        static void Chapter7Example01Pipeline(int seed)
        {
            Console.Write("Begin Pipelined Sentence Builder");
            var buffer1 = new BlockingCollection<string>(BufferBoundedCapacity);
            var buffer2 = new BlockingCollection<string>(BufferBoundedCapacity);
            var buffer3 = new BlockingCollection<string>(BufferBoundedCapacity);

            var f = new TaskFactory(TaskCreationOptions.LongRunning, TaskContinuationOptions.None);

            // Stage 1: Read strings and merge into sentences
            var stage1 = f.StartNew(() => ReadStrings(buffer1, seed));

            // Stage 2: Correct case
            var stage2 = f.StartNew(() => CorrectCase(buffer1, buffer2));

            // Stage 3: Merge into sentences
            var stage3 = f.StartNew(() => CreateSentences(buffer2, buffer3));

            // Stage 4: Write output
            var stage4 = f.StartNew(() => WriteSentences(buffer3));

            Task.WaitAll(stage1, stage2, stage3, stage4);
            Console.WriteLine("End");
        }

        static void ReadStrings(BlockingCollection<string> buffer1, int seed)
        {
            try
            {
                foreach (var phrase in PhraseSource(seed))
                {
                    Stage1AdditionalWork();
                    buffer1.Add(phrase);
                }
            }
            finally
            {
                buffer1.CompleteAdding();
            }
        }

        static void Stage1AdditionalWork() { SampleUtilities.DoCpuIntensiveOperation(StageTime[0] / Phrases.Length); }
        static void Stage2AdditionalWork() { SampleUtilities.DoCpuIntensiveOperation(StageTime[1] / Phrases.Length); }
        static void Stage3AdditionalWork() { SampleUtilities.DoCpuIntensiveOperation(StageTime[2] / Phrases.Length); }
        static void Stage4AdditionalWork() { SampleUtilities.DoCpuIntensiveOperation(StageTime[3]); }

        static void CorrectCase(BlockingCollection<string> buffer1, BlockingCollection<string> buffer2)
        {
            try
            {
                StringBuilder sentenceBuilder = new StringBuilder();
                bool isFirstPhrase = true;
                foreach (var phrase in buffer1.GetConsumingEnumerable())
                {
                    Stage2AdditionalWork();
                    if (isFirstPhrase)
                    {
                        var capitalized = phrase.Substring(0, 1).ToUpper() + phrase.Substring(1);
                        isFirstPhrase = false;
                        buffer2.Add(capitalized);
                    }
                    else
                    {
                        buffer2.Add(phrase);
                        if (phrase == ".")
                            isFirstPhrase = true;
                    }
                }
            }
            finally
            {
                buffer2.CompleteAdding();
            }
        }

        static void CreateSentences(
            BlockingCollection<string> buffer2,
            BlockingCollection<string> buffer3)
        {
            try
            {
                StringBuilder sentenceBuilder = new StringBuilder();
                bool isFirstPhrase = true;
                foreach (var phrase in buffer2.GetConsumingEnumerable())
                {
                    Stage3AdditionalWork();
                    if (!isFirstPhrase && phrase != ".")
                        sentenceBuilder.Append(" ");
                    sentenceBuilder.Append(phrase);
                    isFirstPhrase = false;
                    if (phrase == ".")
                    {
                        var sentence = sentenceBuilder.ToString();
                        sentenceBuilder.Clear();
                        buffer3.Add(sentence);
                        isFirstPhrase = true;
                    }
                }
            }
            finally
            {
                buffer3.CompleteAdding();
            }
        }

        static void WriteSentences(BlockingCollection<string> buffer3)
        {
            using (StreamWriter outfile = new StreamWriter(PathForPipelineResults))
            {
                var sentenceCount = 1;
                foreach (var sentence in buffer3.GetConsumingEnumerable())
                {
                    var printSentence = sentence;
                    Stage4AdditionalWork();
                    if (printSentence == TargetSentence)
                        printSentence = printSentence + "       " + SuccessString;
                    outfile.WriteLine(sentenceCount.ToString() + " " + printSentence);
                    if (sentenceCount % (NumberOfSentences / 10) == 0) Console.Write(".");
                    sentenceCount += 1;
                }
            }
        }

        static void CheckResults()
        {
            var file1ChecksumTask = Task.Factory.StartNew<string>(() => GetFileChecksum(PathForSequentialResults));
            var file2Checksum = GetFileChecksum(PathForPipelineResults);
            var file1Checksum = file1ChecksumTask.Result;

            Console.WriteLine(string.Format("Results written to files \"{0}\" and \"{1}\"",
                PathForSequentialResults, PathForPipelineResults));
            if (file1Checksum == null || file2Checksum == null)
                Console.WriteLine("PROGRAM ERROR! Couldn't calculate file checksum.");
            if (file1Checksum.Equals(file2Checksum))
                Console.WriteLine("Sequential and pipeline results were verified to be equal.");
            else
                Console.WriteLine("PROGRAM ERROR! Sequential and pipeline results don't match.");
        }

        static string GetFileChecksum(string fileName)
        {
            byte[] result = null;
            using (FileStream fileStream = new FileStream(fileName, FileMode.Open))
            {
                MD5 md5 = new MD5CryptoServiceProvider();
                result = md5.ComputeHash(fileStream);
            }
            return Convert.ToBase64String(result, 0, result.Length);
        }
    }
}
