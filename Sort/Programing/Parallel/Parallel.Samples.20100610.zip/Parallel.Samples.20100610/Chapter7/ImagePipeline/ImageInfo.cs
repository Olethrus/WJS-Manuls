﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace ImagePipeline
{

    public class ImageInfo
    {
        public int SequenceNumber { get; private set; }
        public string FileName { get; private set; }
        public Bitmap OriginalImage { get; set; }
        public Bitmap ThumbnailImage { get; set; }
        public Bitmap FilteredImage { get; set; }

        public int ClockOffset { get; private set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        public int[] PhaseStartTick { get; private set; }
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        public int[] PhaseEndTick {get; private set;}

        public int QueueCount1 { get; set; }
        public int QueueCount2 { get; set; }
        public int QueueCount3 { get; set; }

        public int ImageCount { get;  set; }
        public double FramesPerSecond { get; set; }

        public ImageInfo(int sequenceNumber, string fileName, Bitmap originalImage, int clockOffset)
        {
            SequenceNumber = sequenceNumber;
            FileName = fileName;
            OriginalImage = originalImage;
            ClockOffset = clockOffset;

            PhaseStartTick = (int[])Array.CreateInstance(typeof(int), 4);
            PhaseEndTick = (int[])Array.CreateInstance(typeof(int), 4);
        }
    }
}
