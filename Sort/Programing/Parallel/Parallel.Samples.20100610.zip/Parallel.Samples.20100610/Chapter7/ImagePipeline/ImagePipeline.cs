﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.IO;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using System.Threading;
using Utilities;
using System.Globalization;

namespace ImagePipeline
{
    static class ImagePipeline
    {

        #region Constants
        const int QueueBoundedCapacity = 4;
        const int LoadBalancingDegreeOfConcurrency = 2;
        const int MaxNumberOfImages = 500;
        const string SourceDir = @"C:\Users\Public\Pictures\Sample Pictures";
        const double GaussianNoiseAmount = 50.0; 
        #endregion
        
        #region Image Pipeline Top Level Loop

        /// <summary>
        /// Runs the image pipeline example. The program goes through the jpg images located in the SourceDir
        /// directory and performs a series of steps: it resizes each image and adds a black border and then applies
        /// a Gaussian noise filter operation to give the image a grainy effect. Finally, the program invokes 
        /// a user-provided delegate to the image (for example, to display the image on the user interface).
        /// 
        /// Images are processed in sequential order. That is, the display delegate will be invoked in exactly the same
        /// order as the images appear in the file system.
        /// </summary>
        /// <param name="displayFn">A delegate that is invoked for each image at the end of the pipeline, for example, to 
        /// display the image in the user interface.</param>
        /// <param name="token">A token that can signal an external cancellation request.</param>
        /// <param name="algorithmChoice">The method of calculation. 0=sequential, 1=pipeline, 2=load balanced pipeline</param>
        /// <param name="errorFn">A delegate that will be invoked if this method or any of its parallel subtasks observe an exception during their execution.</param>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Design", "CA1031:DoNotCatchGeneralExceptionTypes")]
        public static void ImagePipelineMainLoop(Action<ImageInfo> displayFn, CancellationToken token,
            int algorithmChoice, Action<Exception> errorFn)
        {
            try
            {
                CheckDirectoryExists(SourceDir);

                // Ensure that frames are presented in sequence before invoking the user-provided display function.
                int imagesSoFar = 0;
                Action<ImageInfo> safeDisplayFn = info =>
                    {
                        if (info.SequenceNumber != imagesSoFar)
                            throw new InvalidProgramException("Images processed out of order. Saw " +
                                info.SequenceNumber.ToString() + " , expected " +
                                imagesSoFar);

                        displayFn(info);
                        imagesSoFar += 1;
                    };

                // Create a cancellation handle for inter-task signaling of exceptions. This cancellation
                // handle is also triggered by the incoming token that indicates user-requested
                // cancellation.
                using (CancellationTokenSource cts = CancellationTokenSource.CreateLinkedTokenSource(token))
                {
                    var fileNames = GetImageFilenames(SourceDir, MaxNumberOfImages);
                    switch (algorithmChoice)
                    {
                        case 0: RunSequential(fileNames, SourceDir, safeDisplayFn, cts);
                            break;
                        case 1: RunPipelined(fileNames, SourceDir, QueueBoundedCapacity, safeDisplayFn, cts);
                            break;
                        case 2: RunLoadBalancedPipeline(fileNames, SourceDir, QueueBoundedCapacity, safeDisplayFn, cts,
                            LoadBalancingDegreeOfConcurrency);
                            break;
                        case 3: RunTaskParallel(fileNames, SourceDir, safeDisplayFn, cts);
                            break;
                        default:
                            throw new InvalidProgramException("invalid case");
                    }
                }
            }
            catch (AggregateException ae)
            {
                if (ae.InnerExceptions.Count == 1)
                    errorFn(ae.InnerExceptions[0]);
                else
                    errorFn(ae);
            }
            catch (Exception e)
            {
                errorFn(e);
            }
        } 
        #endregion
        
        #region Variations (Sequential and Pipelined)
        
        static void RunSequential(IEnumerable<string> fileNames, string sourceDir, 
                                  Action<ImageInfo> displayFn, CancellationTokenSource cts)
        {
            int count = 0;
            int clockOffset = Environment.TickCount;
            int duration = 0;
            var token = cts.Token;
            ImageInfo info = null;
            try
            {
                foreach (var fname in fileNames)
                {
                    if (token.IsCancellationRequested)
                        break;

                    info = LoadImage(fname, sourceDir, count, clockOffset);
                    ScaleImage(info);
                    FilterImage(info);
                    int displayStart = Environment.TickCount;
                    DisplayImage(info, count + 1, displayFn, duration);
                    duration = Environment.TickCount - displayStart;

                    count += 1;
                    info = null;
                }
            }
            finally
            {
                if (info != null) DisposeImages(info);
            }
        }

        /// <summary>
        /// Run the image processing pipeline.
        /// </summary>
        /// <param name="fileNames">List of image file names in source directory</param>
        /// <param name="sourceDir">Name of directory of source images</param>
        static void RunPipelined(IEnumerable<string> fileNames, string sourceDir, int queueLength, Action<ImageInfo> displayFn,
            CancellationTokenSource cts)
        {
            // Data pipes 
            var originalImages = new BlockingCollection<ImageInfo>(queueLength);
            var thumbnailImages = new BlockingCollection<ImageInfo>(queueLength);
            var filteredImages = new BlockingCollection<ImageInfo>(queueLength);
            try
            {
                var f = new TaskFactory(TaskCreationOptions.LongRunning, TaskContinuationOptions.None);
                Action<ImageInfo> updateStatisticsFn = info =>
                {
                    info.QueueCount1 = originalImages.Count();
                    info.QueueCount2 = thumbnailImages.Count();
                    info.QueueCount3 = filteredImages.Count();
                };

                // Start pipelined tasks
                var loadTask = f.StartNew(() =>
                      LoadPipelinedImages(fileNames, sourceDir, originalImages, cts));

                var scaleTask = f.StartNew(() =>
                      ScalePipelinedImages(originalImages, thumbnailImages, cts));

                var filterTask = f.StartNew(() =>
                      FilterPipelinedImages(thumbnailImages, filteredImages, cts));

                var displayTask = f.StartNew(() =>
                      DisplayPipelinedImages(filteredImages.GetConsumingEnumerable(), 
                           displayFn, updateStatisticsFn, cts));

                Task.WaitAll(loadTask, scaleTask, filterTask, displayTask);
            }
            finally
            {
                // in case of exception or cancellation, there might be bitmaps
                // that need to be disposed.
                DisposeImagesInQueue(originalImages);
                DisposeImagesInQueue(thumbnailImages);
                DisposeImagesInQueue(filteredImages);                
            }
        }

        /// <summary>
        /// Run a variation of the pipeline that uses a user-specified number of tasks for the filter stage.
        /// </summary>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2000:DisposeObjectsBeforeLosingScope")]
        static void RunLoadBalancedPipeline(IEnumerable<string> fileNames, string sourceDir, int queueLength, Action<ImageInfo> displayFn,
            CancellationTokenSource cts, int filterTaskCount)
        {
            // Create data pipes 
            var originalImages = new BlockingCollection<ImageInfo>(queueLength);
            var thumbnailImages = new BlockingCollection<ImageInfo>(queueLength);
            var filteredImageMultiplexer = new BlockingMultiplexer<ImageInfo>(info => info.SequenceNumber, 0, queueLength);
            var filteredImagesCollections = (BlockingCollection<ImageInfo>[])Array.CreateInstance(
                                   typeof(BlockingCollection<ImageInfo>), filterTaskCount);

            try
            {
                // Start pipelined tasks
                Action<ImageInfo> updateStatisticsFn = info =>
                {
                    info.QueueCount1 = originalImages.Count();
                    info.QueueCount2 = thumbnailImages.Count();
                    info.QueueCount3 = filteredImageMultiplexer.Count;
                };
                var options = TaskCreationOptions.LongRunning;
                var f = new TaskFactory(CancellationToken.None, options, TaskContinuationOptions.None, TaskScheduler.Default);
                Task[] tasks = (Task[])Array.CreateInstance(typeof(Task), filterTaskCount + 3);
                int taskId = 0;

                tasks[taskId++] = f.StartNew(() =>
                      LoadPipelinedImages(fileNames, sourceDir, originalImages, cts));

                tasks[taskId++] = f.StartNew(() =>
                      ScalePipelinedImages(originalImages, thumbnailImages, cts));

                for (int i = 0; i < filterTaskCount; i++)
                {
                    var tmp = i;
                    filteredImagesCollections[tmp] = filteredImageMultiplexer.GetProducerQueue();
                    tasks[taskId++] = f.StartNew(() => FilterPipelinedImages(thumbnailImages, filteredImagesCollections[tmp], cts));
                }

                tasks[taskId++] = f.StartNew(() =>
                      DisplayPipelinedImages(filteredImageMultiplexer.GetConsumingEnumerable(), displayFn, 
                                             updateStatisticsFn, cts));

                Task.WaitAll(tasks);
            }
            finally
            {
                // there might be cleanup in the case of cancellation or an exception.
                DisposeImagesInQueue(originalImages);
                DisposeImagesInQueue(thumbnailImages);
                foreach (var filteredImages in filteredImagesCollections)
                    DisposeImagesInQueue(filteredImages);
                foreach (var info in filteredImageMultiplexer.GetCleanupEnumerable())
                    DisposeImages(info);
            }
        }

                   
        // This particular example is a special case that also be coded using parallel tasks (but not a parallel
        // loop). Note: this method as written does not fully support cancellation and exception handling.
        static void RunTaskParallel(IEnumerable<string> fileNames, string sourceDir, Action<ImageInfo> displayFn,
            CancellationTokenSource cts)
        {
            int count = 0;
            int clockOffset = Environment.TickCount;
            int duration = 0;
            var token = cts.Token;
            var degreeOfConcurrency = Environment.ProcessorCount;

            foreach (var fname in fileNames)
            {
                if (token.IsCancellationRequested)
                    break;

                Func<int, ImageInfo> workFn = (imgCount) =>
                {
                    ImageInfo info = LoadImage(fname, sourceDir, imgCount, clockOffset);
                    ScaleImage(info);
                    FilterImage(info);
                    return info;
                };

                var tasks = (Task<ImageInfo>[])Array.CreateInstance(typeof(Task<ImageInfo>), degreeOfConcurrency - 1);

                // push last first to make LIFO order process images in sequence (may provide better scheduling)
                for (int iterationNumber = degreeOfConcurrency - 1; iterationNumber > 0; iterationNumber--)
                {
                    var i = iterationNumber;
                    tasks[i - 1] = Task.Factory.StartNew<ImageInfo>(() => workFn(count + i));
                }
                // inline first unit of work
                ImageInfo info2 = workFn(count);

                int displayStart = Environment.TickCount;
                DisplayImage(info2, count + 1, displayFn, duration);
                duration = Environment.TickCount - displayStart;

                // get results of tasks in order to preserve sequence constraint
                for (var i = 0; i < degreeOfConcurrency - 1; i++)
                {
                    info2 = tasks[i].Result;
                    displayStart = Environment.TickCount;
                    DisplayImage(info2, count + i + 1, displayFn, duration);
                    duration = Environment.TickCount - displayStart;
                }

                // increment step by chunk size
                count += degreeOfConcurrency;
            }
        } 
        #endregion
        
        #region The Pipeline Phases

        /// <summary>
        /// Image pipeline phase 1: Load images from disk and put them a queue.
        /// </summary>
        static void LoadPipelinedImages(IEnumerable<string> fileNames, string sourceDir, 
            BlockingCollection<ImageInfo> original, CancellationTokenSource cts)
        {
            int count = 0;
            int clockOffset = Environment.TickCount;
            var token = cts.Token;
            ImageInfo info = null;
            try
            {
                foreach (var fname in fileNames)
                {
                    if (token.IsCancellationRequested)
                        break;
                    info = LoadImage(fname, sourceDir, count, clockOffset);
                    original.Add(info, token);
                    count += 1;
                    info = null;
                }                
            }
            catch (Exception e)
            {
                // in case of exception, signal shutdown to other pipeline tasks
                cts.Cancel();
                if (!(e is OperationCanceledException))
                    throw;
            }
            finally
            {
                original.CompleteAdding();
                if (info != null) DisposeImages(info);
            }
        }

        /// <summary>
        /// Image pipeline phase 2: Scale to thumbnail size and render picture frame.
        /// </summary>
        static void ScalePipelinedImages(
            BlockingCollection<ImageInfo> originalImages, 
            BlockingCollection<ImageInfo> thumbnailImages,
            CancellationTokenSource cts)
        {
            var token = cts.Token;
            ImageInfo info = null;
            try
            {
                foreach (var infoTmp in originalImages.GetConsumingEnumerable())
                {
                    info = infoTmp;
                    if (token.IsCancellationRequested)
                        break;
                    ScaleImage(info);
                    thumbnailImages.Add(info, token);
                    info = null;
                }
            }
            catch (Exception e)
            {
                cts.Cancel(); 
                if (!(e is OperationCanceledException))
                    throw;
            }
            finally
            {
                thumbnailImages.CompleteAdding();
                if (info != null) DisposeImages(info);
            }
        }

        /// <summary>
        /// Image pipeline phase 3: Filter images (give them a speckled appearance by adding Gaussian noise)
        /// </summary>
        static void FilterPipelinedImages(
            BlockingCollection<ImageInfo> thumbnailImages, 
            BlockingCollection<ImageInfo> filteredImages,
            CancellationTokenSource cts)
        {
            ImageInfo info = null;
            try
            {
                var token = cts.Token;
                foreach (ImageInfo infoTmp in
                    thumbnailImages.GetConsumingEnumerable())
                {
                    info = infoTmp;
                    if (token.IsCancellationRequested)
                        break;
                    FilterImage(info);
                    filteredImages.Add(info, token);
                    info = null;
                }
            }
            catch (Exception e)
            {
                cts.Cancel();
                if (!(e is OperationCanceledException))
                    throw;
            }
            finally
            {
                filteredImages.CompleteAdding();
                if (info != null) DisposeImages(info);
            }
        }

        /// <summary>
        /// Image pipeline phase 4: Invoke the user-provided delegate (for example, to display the result in a UI)
        /// </summary>
        static void DisplayPipelinedImages(IEnumerable<ImageInfo> filteredImages, 
                                           Action<ImageInfo> displayFn,
                                           Action<ImageInfo> updateStatisticsFn, 
                                           CancellationTokenSource cts) 
        {
            int count = 1;
            int duration = 0;
            var token = cts.Token;
            ImageInfo info = null;
            try
            {
                foreach (ImageInfo infoTmp in filteredImages)
                {
                    info = infoTmp;
                    if (token.IsCancellationRequested)
                        break;
                    int displayStart = Environment.TickCount;
                    updateStatisticsFn(info);
                    DisplayImage(info, count, displayFn, duration);
                    duration = Environment.TickCount - displayStart;

                    count = count + 1;
                    info = null;
                }
            }
            catch (Exception e)
            {
                cts.Cancel();
                if (!(e is OperationCanceledException))
                    throw;
            }
            finally
            {
                if (info != null) DisposeImages(info);
            }
        }        
        #endregion     
 
        #region Operations for Individual Images
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Reliability", "CA2000:DisposeObjectsBeforeLosingScope")]
        static ImageInfo LoadImage(string fname, string sourceDir, int count, int clockOffset)
        {
            int startTick = Environment.TickCount;
            Bitmap bitmap = new Bitmap(sourceDir + '\\' + fname);
            ImageInfo info = null;
            try
            {
                bitmap.Tag = fname;

                info = new ImageInfo(count, fname, bitmap, clockOffset);
                info.PhaseStartTick[0] = startTick - clockOffset;
                bitmap = null;
            }
            finally
            {
                if (bitmap != null) bitmap.Dispose();
            }

            if (info != null) info.PhaseEndTick[0] = Environment.TickCount - clockOffset;
            return info;
        }

        static void ScaleImage(ImageInfo info)
        {
            int startTick = Environment.TickCount;
            var orig = info.OriginalImage;
            info.OriginalImage = null;
            var scale = 200;
            var isLandscape = (orig.Width > orig.Height);
            var newWidth = isLandscape ? scale : scale * orig.Width / orig.Height;
            var newHeight = !isLandscape ? scale : scale * orig.Height / orig.Width;
            Bitmap bitmap = new Bitmap(orig, newWidth, newHeight);
            try
            {
                Bitmap bitmap2 = bitmap.AddBorder(15);
                try
                {
                    bitmap2.Tag = orig.Tag;
                    info.ThumbnailImage = bitmap2;
                    info.PhaseStartTick[1] = startTick - info.ClockOffset;
                    bitmap2 = null;
                }
                finally
                {
                    if (bitmap2 != null) bitmap2.Dispose();
                }
            }
            finally
            {
                bitmap.Dispose();
                orig.Dispose();
            }
            info.PhaseEndTick[1] = Environment.TickCount - info.ClockOffset;
        }

        static void FilterImage(ImageInfo info)
        {
            int startTick = Environment.TickCount;
            var sc = info.ThumbnailImage;
            info.ThumbnailImage = null;
            Bitmap bitmap = sc.AddNoise(GaussianNoiseAmount);

            try
            {
                bitmap.Tag = sc.Tag;
                info.FilteredImage = bitmap;
                info.PhaseStartTick[2] = startTick - info.ClockOffset;

                bitmap = null;
            }
            finally
            {
                if (bitmap != null) bitmap.Dispose();
                sc.Dispose();
            }
            info.PhaseEndTick[2] = Environment.TickCount - info.ClockOffset;
        }

        static void DisplayImage(ImageInfo info, int count, Action<ImageInfo> displayFn, int duration)
        {
            int startTick = Environment.TickCount;
            info.ImageCount = count;
            info.PhaseStartTick[3] = startTick - info.ClockOffset;
            info.PhaseEndTick[3] = (duration > 0) ? startTick - info.ClockOffset + duration :
                                                     Environment.TickCount - info.ClockOffset;
            displayFn(info);
            // Thread.Sleep(300);
        } 
        #endregion
        
        #region File System Operations
        /// <summary>
        /// Check whether directory exists, if not exit immediately.
        /// </summary>
        /// <param name="dirName">Directory name</param>
        static void CheckDirectoryExists(string dirName)
        {
            if (!new DirectoryInfo(dirName).Exists)
            {
                throw new InvalidOperationException(
                    string.Format("Image directory \"{0}\" does not exist. Change the path constant to any directory that contains JPG files.", dirName));
            }
        }

        // Repeatedly loop through all of the files in the source directory. This
        // enumerable has an infinite number of values.
        static IEnumerable<string> GetImageFilenames(string sourceDir, int maxImages)
        {
            var fnames = GetImageFilenames_1(sourceDir, maxImages);
            while (true)
            {
                foreach (var fname in fnames)
                    yield return fname;
            }
        }

        /// <summary>
        /// Get names of image files in directory
        /// </summary>
        /// <param name="sourceDir">Name of directory</param>
        /// <param name="maxImages">Maximum number of image file names to return</param>
        /// <returns>List of image file names in directory (basenames not including directory path)</returns>
        static List<string> GetImageFilenames_1(string sourceDir, int maxImages)
        {
            List<string> fileNames = new List<string>();
            var dirInfo = new DirectoryInfo(sourceDir);
            var files = dirInfo.GetFiles();
            int imageFileCount = Math.Min(maxImages, files.Length);
            for (int i = 0; i < imageFileCount; i++)
            {
                var file = files[i];
                string fname = file.FullName;
                if (file.Extension.ToUpper(CultureInfo.InvariantCulture) == ".JPG") // LIMITATION - only handles jpg, not gif, png etc.
                {
                    fname = file.Name;
                    fileNames.Add(fname);
                }
            }
            // return fileNames;
            return fileNames.OrderBy((f) => f.GetHashCode().ToString()).ToList();
        }
        #endregion

        #region Cleanup methods used by error handling
        static void DisposeImagesInQueue(BlockingCollection<ImageInfo> queue)
        {
            if (queue != null)
            {
                queue.CompleteAdding();
                foreach (var info in queue)
                {
                    DisposeImages(info);
                }
            }
        }

        static void DisposeImages(ImageInfo info)
        {
            if (info != null)
            {
                if (info.OriginalImage != null) info.OriginalImage.Dispose();
                if (info.ThumbnailImage != null) info.ThumbnailImage.Dispose();
                if (info.FilteredImage != null) info.FilteredImage.Dispose();
                info.OriginalImage = null;
                info.ThumbnailImage = null;
                info.FilteredImage = null;
            }
        } 
        #endregion
    }
}

    
