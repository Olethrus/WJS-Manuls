﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Drawing.Imaging;
using System.Diagnostics;
using System.IO;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using Utilities;
using System.Globalization;

namespace ImagePipeline
{
    class Program
    {
        /// <summary>
        /// Check whether directory exists, if not exit immediately.
        /// </summary>
        /// <param name="dirName">Directory name</param>
        static void CheckDirectoryExists(string dirName)
        {
            if (!new DirectoryInfo(dirName).Exists)
            {
                Console.WriteLine("Directory does not exist: {0}", dirName);
                Environment.Exit(0);
            }
        }
         
        /// <summary>
        /// Get names of image files in directory
        /// </summary>
        /// <param name="sourceDir">Name of directory</param>
        /// <param name="maxImages">Maximum number of image file names to return</param>
        /// <returns>List of image file names in directory (basenames not including directory path)</returns>
        static List<string> GetImageFilenames(string sourceDir, int maxImages)
        {
            List<string> fileNames = new List<string>();
            var dirInfo = new DirectoryInfo(sourceDir);
            var files = dirInfo.GetFiles();
            int imageFileCount = Math.Min(maxImages, files.Length);
            // Use "for" loop with index i so we can print progress messages with numbered lines.
            for (int i = 0; i < imageFileCount; i++)
            {
                var file = files[i];
                string fname = file.FullName;
                // Console.WriteLine("{0,3:D}. {1}", i + 1, fname);
                if (file.Extension.ToUpper(CultureInfo.InvariantCulture) == ".JPG") // LIMITATION - only handles jpg, not gif, png etc.
                {
                    fname = file.Name;
                    fileNames.Add(fname);
                }
                else
                {
                    // Console.WriteLine("     ... not a .jpg image");
                    continue;
                }
            }
            return fileNames;
        }
        
        /// <summary>
        /// Process images sequentially.
        /// For each image in the source directory, write a grayscale thumbnail in the destination directory. 
        /// </summary>
        /// <param name="fileNames">List of image file names in source directory</param>
        /// <param name="sourceDir">Name of directory of source images</param>
        /// <param name="destDir">Name of directory for processed images</param>
        static void RunSequence(List<string> fileNames, string sourceDir, string destDir)
        {
            foreach (string fname in fileNames)
            {
                // Load, Scale, convert to Gray, Save
                using (var original = new Bitmap(sourceDir + '\\' + fname)) // ensure dispose, prevent warning CA2000
                {
                    using (var scaled = new Bitmap(original, original.Width / 10, original.Height / 10))
                    {
                        var gray = scaled.ToGray();
                        string destFullName = destDir + '\\' + fname;
                        gray.Save(destFullName);
                        // Console.WriteLine("     Saving to {0}", destFullName);
                    }
                }
            }
        }

        /// <summary>
        /// Run the image processing pipeline.
        /// For each image in the source directory, write a grayscale thumbnail in the destination directory. 
        /// </summary>
        /// <param name="fileNames">List of image file names in source directory</param>
        /// <param name="sourceDir">Name of directory of source images</param>
        /// <param name="destDir">Name of directory for processed images</param>
        static void RunPipeline(List<string> fileNames, string sourceDir, string destDir)
        {
            // Data between pipeline stages
            var original = new BlockingCollection<Bitmap>();
            var scaled = new BlockingCollection<Bitmap>();
            var gray = new BlockingCollection<Bitmap>();
            Bitmap bitmap = null;

            try // ensure dispose bitmap, prevent warning CA2000
            {
                // Stage 1:
                var loadImages = Task.Factory.StartNew(() =>
                {
                    foreach (string fname in fileNames)
                    {
                        bitmap = new Bitmap(sourceDir + '\\' + fname);
                        bitmap.Tag = fname;
                        original.Add(bitmap);
                    }
                    original.CompleteAdding();
                });

                // Stage 2:
                var scaleImages = Task.Factory.StartNew(() =>
                {
                    foreach (Bitmap orig in original.GetConsumingEnumerable())
                    {
                        bitmap = new Bitmap(orig, orig.Width / 10, orig.Height / 10);
                        bitmap.Tag = orig.Tag;
                        scaled.Add(bitmap);
                    }
                    scaled.CompleteAdding();
                });

                // Stage 3:
                var grayImages = Task.Factory.StartNew(() =>
                {
                    foreach (Bitmap sc in scaled.GetConsumingEnumerable())
                    {
                        //var bitmap = ConvertToGrayscale(sc);
                        bitmap = sc.ToGray();
                        bitmap.Tag = sc.Tag;
                        gray.Add(bitmap);
                    }
                    gray.CompleteAdding();
                });

                // Stage 4:
                var saveImages = Task.Factory.StartNew(() =>
                {
                    foreach (Bitmap g in gray.GetConsumingEnumerable())
                    {
                        string destFullName = destDir + '\\' + g.Tag;
                        // Console.WriteLine("     Saving to {0}", destFullName);
                        g.Save(destFullName);
                    }
                });

                Task.WaitAll(loadImages, scaleImages, grayImages, saveImages);
            } 
            finally
            {
                if (bitmap != null) bitmap.Dispose();
            }
        }
      
        /// <summary>
        /// Pipeline pattern sample
        /// Command line arguments are:
        ///  number of images to process, default 1
        ///  image source directory, default C:\Users\Public\Pictures\Sample Pictures
        ///  sequential image destination directory, default C:\Users\Public\Pictures\Imaging  
        ///  parallel image destination directory, default C:\Users\Public\Pictures\ImagePipeline  
        /// You must first create the two destination directories.
        /// </summary>
        static void Main(string[] args)
        {
            // Defaults
            //int maxImages = 1;
            // string sourceDir = @"C:\Users\Public\Pictures\Sample Pictures";
            
            // for pipeline performance/debugging
            int maxImages = 20;
            string sourceDir = @"D:\Pictures\UW Campus, Fall colors, Nov 2004";

            string seqDestDir = @"C:\Users\Public\Pictures\Imaging";
            string pipelineDestDir = @"C:\Users\Public\Pictures\ImagePipeline"; 

            // Optionally override defaults on command line
            if (args.Length > 0) maxImages = Int32.Parse(args[0], CultureInfo.CurrentCulture);
            if (args.Length > 1) sourceDir = args[1];
            if (args.Length > 2) seqDestDir = args[2];
            if (args.Length > 3) pipelineDestDir = args[3];

            CheckDirectoryExists(sourceDir);
            CheckDirectoryExists(seqDestDir);
            CheckDirectoryExists(pipelineDestDir);
            
            // Force JIT compilation before timing tests
            var fileNames = GetImageFilenames(sourceDir, 1); // just one image
            RunSequence(fileNames, sourceDir, seqDestDir); 
            RunPipeline(fileNames, sourceDir, pipelineDestDir);

            // Prepare for timing runs
            fileNames = GetImageFilenames(sourceDir, maxImages);
            Console.WriteLine();
            Console.WriteLine("Reading {0} images from {1}", fileNames.Count, sourceDir);
            Console.WriteLine("             Writing to {0}", seqDestDir);
            Console.WriteLine("                    and {0}", pipelineDestDir);
            Console.WriteLine();

            // Sequential
            SampleUtilities.TimedRun(() =>
            {
                RunSequence(fileNames, sourceDir, seqDestDir);
                return fileNames.Count;
            },
            "Sequential");

            // Parallel
            SampleUtilities.TimedRun(() => 
            { 
                RunPipeline(fileNames, sourceDir, pipelineDestDir);
                return fileNames.Count;
            },
            "  Parallel");
        }
    }
}
