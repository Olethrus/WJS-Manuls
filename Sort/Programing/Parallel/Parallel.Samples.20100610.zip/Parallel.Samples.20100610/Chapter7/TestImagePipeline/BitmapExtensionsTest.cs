﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Drawing;
using ImagePipeline;

namespace ImagePipelineTests
{
    [TestClass]
    public class BitmapExtensionsTest
    {
        [TestMethod]
        public void ToGrayTest()
        {
            // Load image, must assume image exists at given path
            string sourceDir = @"C:\Users\Public\Pictures\Sample Pictures";
            string file = "Chrysanthemum.jpg";
            string path = sourceDir + "\\" + file;
            var source = new Bitmap(path);

            // Generate grayscale image
            var gray = source.ToGray();

            // Check one pixel from the middle of the image
            int xSample = source.Width / 2;
            int ySample = source.Height / 2;
            var s = source.GetPixel(xSample, ySample);
            var g = gray.GetPixel(xSample, ySample);

            // Convert sample pixel to desaturateTasks
            int luma = BitmapExtensions.GrayLuma(s);

            // Confirm we got intended desaturateTasks
            Assert.AreEqual(luma, g.R);
            Assert.AreEqual(luma, g.G);
            Assert.AreEqual(luma, g.B);
        }
    }
}
