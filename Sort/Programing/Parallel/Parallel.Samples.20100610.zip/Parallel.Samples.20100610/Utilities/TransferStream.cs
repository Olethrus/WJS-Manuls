﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace Utilities
{
    /// <summary>
    /// Stream backed by a blocking collection and a piplelined processing task. 
    /// </summary>
    /// <remarks>This stream can be used to adapt the pipeline pattern to methods that take stream arguments.</remarks>
    public sealed class TransferStream : Stream
    {
        private Stream _writeableStream;
        private BlockingCollection<byte[]> _chunks;
        private Task _processingTask;

        /// <summary>
        /// Creates a new transfer stream.
        /// </summary>
        /// <param name="writeableStream">The underlying stream that will eventually be written to</param>
        public TransferStream(Stream writeableStream)
        {
            // Validate arguments
            if (writeableStream == null) throw new ArgumentNullException("writeableStream");
            if (!writeableStream.CanWrite) throw new ArgumentException("Target stream is not writeable.");

            _writeableStream = writeableStream;
            _chunks = new BlockingCollection<byte[]>();
            _processingTask = Task.Factory.StartNew(() =>
            {
                foreach (var chunk in _chunks.GetConsumingEnumerable())
                    _writeableStream.Write(chunk, 0, chunk.Length);
            }, TaskCreationOptions.LongRunning);
        }

        /// <summary>
        /// Returns true.
        /// </summary>
        public override bool CanWrite { get { return true; } }

        /// <summary>
        /// Writes to the transfer stream.
        /// </summary>
        /// <param name="buffer">Bytes to be written</param>
        /// <param name="offset">Position in byte buffer</param>
        /// <param name="count">Number of bytes to write</param>
        public override void Write(byte[] buffer, int offset, int count)
        {
            // Validate all arguments
            if (buffer == null) throw new ArgumentNullException("buffer");
            if (offset < 0 || offset >= buffer.Length) throw new ArgumentOutOfRangeException("offset");
            if (count < 0 || offset + count > buffer.Length) throw new ArgumentOutOfRangeException("count");
            if (count == 0) return;

            var chunk = new byte[count];
            Buffer.BlockCopy(buffer, offset, chunk, 0, count);
            _chunks.Add(chunk);
        }

        /// <summary>
        /// Closes the stream
        /// </summary>
        public override void Close()
        {
            _chunks.CompleteAdding();
            try { _processingTask.Wait(); }
            finally { base.Close(); }
        }

        /// <summary>
        /// Returns false
        /// </summary>
        public override bool CanRead { get { return false; } }

        /// <summary>
        /// Returns false
        /// </summary>
        public override bool CanSeek { get { return false; } }

        /// <summary>
        /// No-op
        /// </summary>
        public override void Flush() { }

        /// <summary>
        /// Not supported
        /// </summary>
        public override long Length { get { throw new NotSupportedException(); } }

        /// <summary>
        /// Not supported
        /// </summary>
        public override long Position
        {
            get { throw new NotSupportedException(); }
            set { throw new NotSupportedException(); }
        }

        /// <summary>
        /// Not supported
        /// </summary>
        /// <param name="buffer">Not supported</param>
        /// <param name="offset">Not supported</param>
        /// <param name="count">Not supported</param>
        /// <returns></returns>
        public override int Read(byte[] buffer, int offset, int count)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Not supported
        /// </summary>
        /// <param name="offset">Not supported</param>
        /// <param name="origin">Not supported</param>
        /// <returns>Not supported</returns>
        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new NotSupportedException();
        }

        /// <summary>
        /// Not supported
        /// </summary>
        /// <param name="value">Not supported</param>
        public override void SetLength(long value)
        {
            throw new NotSupportedException();
        }
    }
}
