﻿//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright © Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================
using Utilities;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Collections.Concurrent;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace UtilitiesTests
{
    public class MyItem
    {
        public int LockId { get; set; }
        public string Payload { get; set; }
        public MyItem(int lockId, string payload)
        {
            LockId = lockId;
            Payload = payload;
        }
    }

    /// <summary>
    ///This is a test class for BlockingMultiplexerTest and is intended
    ///to contain all BlockingMultiplexerTest Unit Tests
    ///</summary>
    [TestClass()]
    public class BlockingMultiplexerTest
    {
        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        const int InitialLockId = 101;
        const int BoundedCapacity = 8;
        

        /// <summary>
        ///A test for BlockingMultiplexer`1 Constructor
        ///</summary>
        public BlockingMultiplexer<MyItem> BlockingMultiplexerConstructorTestHelper()
        {
            Func<MyItem, int> lockOrderFn = p => p.LockId;
            int initialLockId = InitialLockId;
            int boundedCapacity = BoundedCapacity;
            return new BlockingMultiplexer<MyItem>(lockOrderFn, initialLockId, boundedCapacity);
        }

        [TestMethod()]
        public void BlockingMultiplexerConstructorTest()
        {
            var m = BlockingMultiplexerConstructorTestHelper();
            Assert.IsTrue(true);
        }

        public void ProducerLoop(BlockingCollection<MyItem> collection, int startPacketId, int stepSize,
            int sleepMilliseconds, int maxPacketId)
        {
            GaussianRandom generator = new GaussianRandom((double)sleepMilliseconds, (double)sleepMilliseconds);
            for (var i = startPacketId; i < maxPacketId; i += stepSize)
            {
                Thread.Sleep(Math.Max(0, generator.NextInteger()));
                collection.Add(new MyItem(i, string.Format("The lock id is {0}", i.ToString())));
                while (sleepMilliseconds * 1.75 > generator.NextInteger())
                {
                    Thread.Sleep(Math.Max(0, generator.NextInteger()));
                    collection.Add(new MyItem(-1, string.Format("The value must come after {0} but before {1}",
                        i.ToString(), (i + stepSize).ToString())));
                }
            }
            collection.CompleteAdding();
        }

        /// <summary>
        ///A test for GetConsumingEnumerable
        ///</summary>
        public void GetConsumingEnumerableTestHelper()
        {
            var target = BlockingMultiplexerConstructorTestHelper();
            var producer1 = target.GetProducerQueue();
            var producer2 = target.GetProducerQueue();
            var producer3 = target.GetProducerQueue();
            const int maxLockId = 404;

            Task.Factory.StartNew(() => ProducerLoop(producer1, 101, 3, 7, maxLockId - 2));
            Task.Factory.StartNew(() => ProducerLoop(producer2, 102, 3, 12, maxLockId - 1));
            Task.Factory.StartNew(() => ProducerLoop(producer3, 103, 3, 3, maxLockId));

            var expectedNext = InitialLockId;
            var actualNext = 0;
            var actual = target.GetConsumingEnumerable();
            foreach (var packet in actual)
            {
                if (packet.LockId >= 0)
                {
                    // check lock order
                    actualNext = packet.LockId;
                    var expectedMessage = "The lock id is " + expectedNext.ToString();
                    var actualMessage = packet.Payload;
                    Console.WriteLine(actualMessage);

                    Assert.AreEqual(expectedNext, actualNext, "Packet Ids are out of sequence");
                    Assert.AreEqual(expectedMessage, actualMessage, "Unexpected packet payload");
                    expectedNext += 1;
                }
                else 
                {
                    // check partial ordering constraint
                    Assert.IsTrue(packet.Payload.StartsWith("The value must come after "));
                    var stringArr = packet.Payload.Split();
                    var val1 = int.Parse(stringArr[5]);
                    var val2 = int.Parse(stringArr[8]);
                    var lower = expectedNext - 1;
                    var upper = expectedNext;
                    Assert.IsTrue(val1 <= val2);
                    Assert.IsTrue(val1 <= lower);
                    Assert.IsTrue(val2 >= upper);
                    Console.WriteLine(packet.Payload);
                }
            }
            Assert.AreEqual(maxLockId - 1, actualNext, "Unexpected last packet");
        }

        [TestMethod()]
        public void GetConsumingEnumerableTest()
        {
            GetConsumingEnumerableTestHelper();
        }

        /// <summary>
        ///A test for GetProducerQueue
        ///</summary>
        public void GetProducerQueueTestHelper()
        {
            var target = BlockingMultiplexerConstructorTestHelper();
            BlockingCollection<MyItem> actual;
            actual = target.GetProducerQueue();
            Assert.IsNotNull(actual);
        }

        [TestMethod()]
        public void GetProducerQueueTest()
        {
            GetProducerQueueTestHelper();
        }



        string[] WordList = 
        { 
        "academically", "acrobatics", "adorable", "aged", "ale", "AM", "anatomy", "antifreeze", "appreciate", 
        "assembly", "attentive", "avoidable", "baker", "bedtime",  
        "birthday", "blister", "botany", "breach", "brooch", "bunch", "cabbage", "canned", 
        "carnivore", "chairmanship", "checklist", "civilization", "clinging", 
        "colorless", "concentration", "corpuscle", 
        "coverage", "curtain", "decal", "definite", "desktop", 
        "eastern", "eightieth", "eventful", "exemption", 
        "factory", "foggy", "foresight", 
        "four", "friction", "generalization", "grassy", 
        "hallway", "hemisphere", 
        "incremental", "industrial arts", "inform", 
        "inquiring", "inviting", "juxtaposition", "knight", "lantern", 
        "loudness", "marina",  
        "merry", "migration", "moderation", 
        "northward", "nylon", "octave", "orchestrate", 
        "outing", "overpass", "percent", "pertain", 
        "physical therapist", "piping", "poplar", "pouch", "preempt", 
        "process", "proxy", "quark", "radium", "rational", "redid", "registration", 
        "representative", "respirator", "revelry", "rightly", "roller", 
        "sculpture", "shrub", "similarity", 
        "socially", "soothing", "sparkle", "spirit", 
        "subtraction", "sunscreen", "tangible", "terminology", 
        "theses", "thumb", "to",  "undo", 
        "unleash",  "useful", "voice mail", 
        "wishes", "workshop", "yacht"
        };

        const int StepSpeed = 10;

        // pipeline phase 1
        public void AddWords(string[] wordlist, BlockingCollection<MyItem> output)
        {
            for (int i = 0; i < wordlist.Length; i++)
            {
                output.Add(new MyItem(i, wordlist[i]));
                Thread.Sleep(StepSpeed);
            }
            output.CompleteAdding();
        }

        // multiplexed pipeline phase 2 (multiple instances)
        public void ProcessWords(int workerCount, int startTick, int workerId, BlockingCollection<MyItem> input, BlockingCollection<MyItem> output)
        {
            GaussianRandom r = new GaussianRandom(StepSpeed * workerCount, 
                StepSpeed * workerCount / 2, workerId.GetHashCode());
            
            while(!input.IsCompleted)
            {
                int loopStartTick = Environment.TickCount;
                MyItem item;
                var found = input.TryTake(out item, 1000);
                // workers run at different speeds
                
                Thread.Sleep(Math.Max(0, r.NextInteger()));
                if (found)
                {
                    output.Add(new MyItem(item.LockId,
                        string.Format("\"{0}\" has {1} letters, per worker {2} with {3} ms ending at {4}",
                          item.Payload.ToString(),
                          item.Payload.Length.ToString(),
                          workerId.ToString(),
                          Environment.TickCount - loopStartTick,
                          (Environment.TickCount - startTick).ToString())));
                }
            
            }
            output.CompleteAdding();
        }

        // pipeline phase 3 (single task with reserialized inputs created by multiplexing producer queues)
        public void PrintResults(IEnumerable<MyItem> myItemList)
        {
            int lastLockId = -1;
            foreach (var item in myItemList)
            {
                if (lastLockId > -1)
                {
                    Assert.AreEqual(lastLockId + 1, item.LockId);
                }
                lastLockId = item.LockId;
                Console.WriteLine("{0}: {1}", item.LockId.ToString(), item.Payload);
                Thread.Sleep(StepSpeed);
            }
        }

        /// <summary>
        /// This is a simple demo of a parallel pipeline that uses multiplexing.
        /// </summary>
        [TestMethod()]
        public void MultiplexerDemoAndTest()
        {
            int boundedCapacity = 128;
            int workerCount = 8;

            BlockingCollection<MyItem> words = new BlockingCollection<MyItem>(boundedCapacity);
            BlockingMultiplexer<MyItem> multiplexer = new BlockingMultiplexer<MyItem>(item => item.LockId, 0, boundedCapacity / workerCount);
            Task[] tasks = new Task[workerCount + 2];
            Console.WriteLine("This output shows how the multiplexer creates a consistent linearization");
            Console.WriteLine("from multiple producer queues, in this case " + workerCount.ToString() + " queues.");

            // 1) Start the first pipeline task
            tasks[0] = Task.Factory.StartNew(() => AddWords(WordList, words));
            var startTick = Environment.TickCount;

            // 2) Start n replicas of the second pipeline task. Use multiplexed producer queues for outputs
            for (int i = 0; i < workerCount; i++)
            {                
                var workerId = i;
                var localQueue = multiplexer.GetProducerQueue();
                tasks[i+1] = Task.Factory.StartNew(() => ProcessWords(workerCount, startTick, workerId, words, localQueue), TaskCreationOptions.LongRunning);
            }

            // 3) Start the third stage of the pipeline, taking inputs from the multiplexed consumer enumerable
            var reserializedValues = multiplexer.GetConsumingEnumerable();
            tasks[workerCount + 1] = Task.Factory.StartNew(() => PrintResults(reserializedValues), TaskCreationOptions.LongRunning);

            Task.WaitAll(tasks);
            Console.WriteLine("done");
        }


        #region Blocking Collection Samples
        [TestMethod()]
        public void TakeFromAnyTest1()
        {
            BlockingCollection<MyItem> producer = new BlockingCollection<MyItem>();
            for (int i = 300; i < 500; i++)
                producer.Add(new MyItem(i, i.ToString()));
            producer.CompleteAdding();

            MyItem item;
            int actualIndex = BlockingCollection<MyItem>.TakeFromAny(new BlockingCollection<MyItem>[] { producer }, out item);

            Assert.AreEqual(0, actualIndex);
            Assert.AreEqual(300, item.LockId);
        }

        [TestMethod()]
        public void TakeFromAnyTest2()
        {
            BlockingCollection<MyItem> producer = new BlockingCollection<MyItem>();
            for (int i = 300; i < 500; i++)
                producer.Add(new MyItem(i, i.ToString()));
            producer.CompleteAdding();
            var consumer = producer.GetConsumingEnumerable().GetEnumerator();
            for (int i = 300; i < 500; i++)
                consumer.MoveNext();

            bool expectedFlag = true;
            bool actualFlag = producer.IsCompleted;

            Assert.AreEqual(expectedFlag, actualFlag);
        }

        [TestMethod()]
        public void TakeFromAnyTest3()
        {
            BlockingCollection<MyItem> producer = new BlockingCollection<MyItem>();
            for (int i = 300; i < 500; i++)
                producer.Add(new MyItem(i, i.ToString()));
            producer.CompleteAdding();
            var consumer = producer.GetConsumingEnumerable().GetEnumerator();
            for (int i = 300; i < 500; i++)
                consumer.MoveNext();

            bool expectedFlag = true;
            bool actualFlag = producer.IsCompleted;

            Assert.AreEqual(expectedFlag, actualFlag);

            MyItem item;
            int expectedIndex = BlockingCollection<MyItem>.TryTakeFromAny(new BlockingCollection<MyItem>[] { producer }, out item, 10000);

            Assert.AreEqual(-1, expectedIndex);
        }

        [TestMethod()]
        public void TakeFromAnyTest4()
        {
            BlockingCollection<MyItem> producer = new BlockingCollection<MyItem>();

            var actualTask = Task.Factory.StartNew<Tuple<int, MyItem>>(() =>
                {
                    MyItem item;
                    var index = BlockingCollection<MyItem>.TryTakeFromAny(new BlockingCollection<MyItem>[] { producer }, out item, 10000);
                    return new Tuple<int, MyItem>(index, item);
                });
            Thread.Sleep(200);
            for (int i = 300; i < 500; i++)
                producer.Add(new MyItem(i, i.ToString()));
            var actual = actualTask.Result;

            Assert.AreEqual(0, actual.Item1);
            Assert.IsNotNull(actual.Item2);
            Assert.AreEqual(300, actual.Item2.LockId);
        }

        [TestMethod()]
        public void TakeFromAnyTest5()
        {
            BlockingCollection<MyItem> producer = new BlockingCollection<MyItem>();

            var actualTask = Task.Factory.StartNew<Tuple<int, MyItem>>(() =>
            {
                MyItem item;
                var index = BlockingCollection<MyItem>.TryTakeFromAny(new BlockingCollection<MyItem>[] { producer }, out item, 10000);
                return new Tuple<int, MyItem>(index, item);
            });
            Thread.Sleep(200);
            producer.CompleteAdding();
            var actual = actualTask.Result;

            Assert.AreEqual(-1, actual.Item1);
            Assert.IsNull(actual.Item2);
        }

        [TestMethod()]
        public void TakeFromAnyTest6()
        {
            BlockingCollection<MyItem> producer = new BlockingCollection<MyItem>();

            var actualTask = Task.Factory.StartNew<Tuple<int, MyItem>>(() =>
            {
                MyItem item;
                var index = BlockingCollection<MyItem>.TryTakeFromAny(new BlockingCollection<MyItem>[] { producer }, out item, 100000);
                return new Tuple<int, MyItem>(index, item);
            });
            Thread.Sleep(200);
            producer.CompleteAdding();
            var actual = actualTask.Result;

            Assert.AreEqual(-1, actual.Item1);
            Assert.IsNull(actual.Item2);
        }

        // This test demonstrates that an exception is thrown from TakeFromAny when
        // there is a race between IsCompleted and CompleteAdding.
        [TestMethod()]
        public void TakeFromAnyTest7()
        {
            BlockingCollection<int> producer1 = new BlockingCollection<int>();
            BlockingCollection<int> producer2 = new BlockingCollection<int>();
            var producerArray = new BlockingCollection<int>[] { producer2, producer1 };
            
            var task1 = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(300);
                producer2.CompleteAdding();
            });

            var task2 = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(500);
                producer1.Add(100);
            });

            int item;
            int index = -2;
            bool sawException = false;
            try
            {
                if (!producer1.IsCompleted && !producer2.IsCompleted)
                {
                    index = BlockingCollection<int>.TakeFromAny(producerArray, out item);
                }
            }
            catch (ArgumentException)
            {
                sawException = true;
            }
            Assert.IsTrue(sawException);
        }

        // This test demonstrates TryTakeFromAny uses its full timeout period
        // when you lose a race between IsCompleted and CompleteAdding.
        [TestMethod()]
        public void TakeFromAnyTest8()
        {
            BlockingCollection<int> producer1 = new BlockingCollection<int>();
            BlockingCollection<int> producer2 = new BlockingCollection<int>();
            var producerArray = new BlockingCollection<int>[] { producer2, producer1 };

            var task1 = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(300);
                producer2.CompleteAdding();
            });

            var task2 = Task.Factory.StartNew(() =>
            {
                Thread.Sleep(500);
                producer1.Add(100);
            });

            int item;
            int timeout = 2000;
            int index = -1;
            Stopwatch sw = new Stopwatch();

            sw.Start();
            if (!producer1.IsCompleted && !producer2.IsCompleted)
            {
                index = BlockingCollection<int>.TryTakeFromAny(producerArray, out item, timeout);
            }
            sw.Stop();

            Assert.AreEqual(-1, index);
            // when you lose a race between IsCompleted and CompleteAdding, TryTakeFromAny blocks 
            // until the *full* timeout elapses (even if in the meantime another BlockingCollections becomes 
            // ready to provide a value).
            Assert.IsTrue(sw.ElapsedMilliseconds >= timeout - 50);
        }
        #endregion

    }
}
