﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CreditReview
{
    /// <summary>
    /// One customer's account data: array of monthly balances, also predictions and warnings
    /// </summary>
    class Account
    {
        public double[] balance { get; set; } // array of monthly balances
        public double overdraft { get; set; } // overdraft limit, issue warning if predicted balance is less

        public double seqPrediction { get; set; } // predicted future balance from sequential calculation
        public double parPrediction { get; set; } // from parallel
        public double plinqPrediction { get; set; } // from PLINQ 

        public bool seqWarning { get; set; }  // warning flag based on prediction from sequential calculation
        public bool parWarning { get; set; }  // from parallel
        public bool plinqWarning { get; set; }  // from PLINQ 

        /// <summary>
        /// Constructor, allocate balance history for nMonths, assign overdraft
        /// <summary>
        public Account(int nMonths, double overdraft)
        {
            balance = new double[nMonths];
            this.overdraft = overdraft;
        }

        /// <summary>
        /// Assign balance history to vary randomly around randomly assigned trend
        /// <summary>
        public void AssignRandomTrend(Trend goodBalance, Trend badBalance, double variation, Random random)
        {
            // choose random trend
            double rateScale = 100.0, balanceScale = 100.0;  // for now, adjust later
            double rateMean = (goodBalance.Slope + badBalance.Slope) / 2;
            double initialBalanceMean = (goodBalance.Intercept + badBalance.Intercept) / 2;
            double rate = rateMean + rateScale * random.NextDouble();
            double initialBalance = initialBalanceMean + balanceScale * random.NextDouble();
            Trend trend = new Trend { Slope = rate, Intercept = initialBalance };

            // balance history is trend plus noise          
            for (int i = 0; i < balance.Length; i++) { balance[i] = trend.Predict(i) + variation * random.NextDouble(); }
        }

        /// <summary>
        /// Print balances for nMonths starting at firstMonth
        /// </summary>
        public void PrintBalance(int firstMonth, int nMonths)
        {
            for (int jmonth = firstMonth; jmonth < firstMonth + nMonths; jmonth++)
            {
                if (jmonth < balance.Length)
                {
                    Console.Write("{0,9:F}", balance[jmonth]);
                }
                else
                {
                    Console.Write("        "); // line up columns even if data missing
                }
            }
            // no WriteLine, may want to print more 
        }
    }
}