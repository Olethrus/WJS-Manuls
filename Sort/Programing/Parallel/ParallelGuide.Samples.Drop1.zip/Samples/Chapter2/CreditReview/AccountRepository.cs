﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Customer = System.Int32;

namespace CreditReview
{
    using AccountRecord = KeyValuePair<Customer, Account>;
 
    /// <summary>
    /// Repository of customer accounts
    /// </summary>
    class AccountRepository
    {
        const int accountNumberRange = 100000000; // nine digit account numbers

        /// <summary>
        /// Repository is implemented by a dictionary from customer account numbers to account data,
        /// an array of monthly balances etc.
        /// </summary>
        Dictionary<Customer, Account> accounts = new Dictionary<Customer, Account>();

        /// <summary>
        /// Constructor, allocate account for nCustomers, each with nMonths balance history
        /// </summary>
        public AccountRepository(int nCustomers, int nMonths, double overdraft)
        {
            for (Customer iCustomer = 0; iCustomer < nCustomers; iCustomer++)
            {
                accounts[iCustomer] = new Account(nMonths, overdraft);
            }
        }

        /// <summary>
        /// Assign every account with monthly balances that fit randomly assigned trend
        /// </summary>
        public void AssignRandomTrends(Trend goodBalance, Trend badBalance, double variation, Random random)
        {
            foreach (AccountRecord record in accounts)
            {
                var account = record.Value;
                account.AssignRandomTrend(goodBalance, badBalance, variation, random);
            }
        }

        /// <summary>
        /// Property that returns collection of all accounts in repository
        /// </summary>
        public Dictionary<Customer, Account> GetAccountList { get { return accounts; } }

        /// <summary>
        /// Print first nRows accounts from firstMonth for nMonths, including predictions and warnings
        /// </summary>
        public void Print(int nRows, int firstMonth, int nMonths)
        {
            // Print column headings
            Console.WriteLine();
            Console.WriteLine(" Customer      Recent balances for month number   Predicted balances and warnings");
            Console.Write("           ");
            for (int jMonth = firstMonth; jMonth < firstMonth + nMonths; jMonth++) { Console.Write("{0,9:D}", jMonth); }
            Console.WriteLine("      Seq.    Parallel       PLINQ");

            // Print results for first nRows customers
            Customer firstCustomer = 0;
            for (int iCustomer = firstCustomer; iCustomer < firstCustomer + nRows; iCustomer++)
            {
                if (accounts.ContainsKey(iCustomer))
                {
                    Console.Write("{0:D9}  ", iCustomer);
                    var acc = accounts[iCustomer];
                    acc.PrintBalance(firstMonth, nMonths);
                    Console.WriteLine("  {0,8:F} {1}  {2,8:F} {3}  {4,8:F} {5}",
                        acc.seqPrediction, acc.seqWarning ? 'W' : ' ',  // sequential
                        acc.parPrediction, acc.parWarning ? 'W' : ' ',  // parallel
                        acc.plinqPrediction, acc.plinqWarning ? 'W' : ' '); // PLINQ
                }
            }
        }
    }
}
