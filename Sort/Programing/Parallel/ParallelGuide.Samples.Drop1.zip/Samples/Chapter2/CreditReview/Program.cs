﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;
using System.Threading.Tasks;
using Utilities;

using Customer = System.Int32;

namespace CreditReview
{
    using AccountRecord = KeyValuePair<Customer, Account>;

    class Program
    {
        static void UpdatePredictionsSequential(AccountRepository accounts)
        {
            foreach (AccountRecord record in accounts.GetAccountList)
            {
                Account account = record.Value;
                Trend trend = Regression.Fit(account.balance);
                double prediction = trend.Predict(account.balance.Length + 3); // balance in 3 months
                account.seqPrediction = prediction;
                account.seqWarning = prediction < account.overdraft;
            }
        }

        static void UpdatePredictionsParallel(AccountRepository accounts)
        {
            Parallel.ForEach(accounts.GetAccountList, record =>
            {
                var account = record.Value;
                Trend trend = Regression.Fit(account.balance);
                double prediction = trend.Predict(account.balance.Length + 3); // balance in 3 months
                account.parPrediction = prediction;
                account.parWarning = prediction < account.overdraft;
            });
        }

        static void UpdatePredictionsPLINQ(AccountRepository accounts)
        {
            var query =
                 accounts.GetAccountList
                 .AsParallel()
                 .Select(record =>
                 {
                     var account = record.Value;
                     Trend trend = Regression.Fit(account.balance);
                     double prediction = trend.Predict(account.balance.Length + 3); // balance in 3 months
                     account.plinqPrediction = prediction;
                     account.plinqWarning = prediction < account.overdraft;
                     return record;
                 });
            query.Last(); // force completion before timing measurement
        }

        /// <summary>
        /// Usage: CreditReview n, optional n is number of customers, use 100,000+ for meaningful timings
        /// </summary>
        static void Main(string[] args)
        {
            Random random = new Random(1);  // seed 1 makes runs reproducible
            Stopwatch stopWatch = new Stopwatch();

            // Defaults for data generation, may override some on command line
            int nMonths = 36;
            int nCustomers = 100; // for data runs make big enough for significant timing measurements
            Trend goodBalance = new Trend { Slope = 0.0, Intercept = 0.0 };
            Trend badBalance = new Trend { Slope = -150.0, Intercept = 0.0 };
            double variation = 100.0;
            double overdraft = -1000.0; // Default overdraft limit

            // Printed table of results
            int nRows = 8;
            int mCols = 4;

            // Optionally override some defaults on command line
            if (args.Length > 0) nCustomers = Int32.Parse(args[0]);

            // Allocate accounts, then assign monthly balances that fit randomly assigned trends
            AccountRepository accounts = new AccountRepository(nCustomers, nMonths, overdraft);
            accounts.AssignRandomTrends(goodBalance, badBalance, variation, random);

            // Sequential
            stopWatch.Start();
            UpdatePredictionsSequential(accounts);
            stopWatch.Stop();
            TimeSpan seqT = stopWatch.Elapsed;
           
            // Parallel
            stopWatch.Reset();
            stopWatch.Start();
            UpdatePredictionsParallel(accounts);
            stopWatch.Stop();
            TimeSpan parT = stopWatch.Elapsed;

            // PLINQ
            stopWatch.Reset(); 
            stopWatch.Start();
            UpdatePredictionsPLINQ(accounts);
            stopWatch.Stop();
            TimeSpan plinqT = stopWatch.Elapsed;

            // Print a few accounts including predictions and warnings
            accounts.Print(nRows, nMonths - mCols, mCols); // print the last few months

            // Print timings 
            Console.WriteLine();
            Console.WriteLine("{0} customers, {1} months in each account", nCustomers, nMonths);
            Console.WriteLine();
            Console.Write("Sequential: "); StopwatchUtilities.PrintTime(seqT);
            Console.Write("  Parallel: "); StopwatchUtilities.PrintTime(parT);
            Console.Write("     PLINQ: "); StopwatchUtilities.PrintTime(plinqT);
        }
    }
}
