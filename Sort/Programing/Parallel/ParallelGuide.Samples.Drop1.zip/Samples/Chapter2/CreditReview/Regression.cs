﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics.CodeAnalysis;

namespace CreditReview
{
    /// <summary>
    /// Linear trend from slope and intercept. Predict y given any x value using the formula
    /// y = slope * x + intercept.
    /// </summary>
    [SuppressMessage("Microsoft.Performance", "CA1815:OverrideEqualsAndOperatorEqualsOnValueTypes")]
    public struct Trend
    {
        /// <summary>
        /// The change in y per unit of x
        /// </summary>
        public double Slope { get; set; }

        /// <summary>
        /// The value of y when x is zero
        /// </summary>
        public double Intercept { get; set; }

        /// <summary>
        /// Predicts a y value given any x value using the formula y = slope * x + intercept.
        /// </summary>
        /// <param name="ordinate">The x value</param>
        /// <returns>The predicted y value</returns>
        public double Predict(double ordinate) { return Slope * ordinate + Intercept; }
    }

    /// <summary>
    /// Linear regression
    /// </summary>
    public static class Regression
    {
        /// <summary>
        /// Return sum of input array
        /// </summary>
        /// 
        public static double Average(double[] values)
        {
            if (values == null) throw new ArgumentNullException("values");
            if (values.Length == 0) throw new ArgumentException("values: must be nonempty");

            double sum = 0.0d;
            for (int i = 0; i < values.Length; i++) { sum += values[i]; }
            return sum / values.Length;
        }

        /// <summary>
        /// Return array of floats for indices 0 .. count-1
        /// </summary>
        public static double[] Range(int count)
        {
            if (count < 0) throw new ArgumentOutOfRangeException("count must be nonnegative");

            double[] x = new double[count];
            for (int i = 0; i < count; i++) { x[i] = i; }
            return x;
        }

        /// <summary>
        /// Linear regression with x-values given implicity by the y-value indices
        /// </summary>
        /// <param name="ordinateValues">A series of two or more values</param>
        /// <returns>A trend line</returns>
        public static Trend Fit(double[] ordinateValues)
        {
            if (ordinateValues == null) throw new ArgumentNullException("ordinateValues");
            // special case - x values are just the indices of the y's
            return Fit(Range(ordinateValues.Length), ordinateValues);            
        }

        /// <summary>
        /// Linear regression of (x, y) pairs
        /// </summary>
        /// <param name="abscissaValues">The x values</param>
        /// <param name="ordinateValues">The y values corresponding to each x value</param>
        /// <returns>A trend line that best predicts each (x, y) pair</returns>
        public static Trend Fit(double [] abscissaValues, double[] ordinateValues)
        {
            if (abscissaValues == null) throw new ArgumentNullException("abscissaValues");
            if (ordinateValues == null) throw new ArgumentNullException("ordinateValues");
            if (abscissaValues.Length != ordinateValues.Length) throw new ArgumentException("abscissaValues and ordinateValues must contain the same number of values.");
            if (abscissaValues.Length < 2) throw new ArgumentException("abscissaValues must contain at least two elements");
 
            double xx = 0, xy = 0;
            double xm = Average(abscissaValues);
            double ym = Average(ordinateValues);

            // calculate the sum of squared differences
            for (int i = 0; i < abscissaValues.Length; i++)
            {
                double xi = abscissaValues[i] - xm;
                xx += xi * xi;
                xy += xi * (ordinateValues[i] - ym);
            };

            if (xx == 0.0d) throw new ArgumentException("abscissaValues must not all be coincident");
            double slope = xy / xx;
            return new Trend { Slope = slope, Intercept = ym - slope * xm };
        }
    }
}
