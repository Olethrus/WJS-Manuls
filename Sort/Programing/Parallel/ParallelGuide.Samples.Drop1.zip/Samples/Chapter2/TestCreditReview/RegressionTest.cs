﻿using CreditReview;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Diagnostics; // for Debug.WriteLine

namespace TestCreditReview
{
    /// <summary>
    ///This is a test class for RegressionTest and is intended
    ///to contain all RegressionTest Unit Tests
    ///</summary>
    [TestClass()]
    public class RegressionTest
    {
        static double delta = 1.0; // for checking double results in presence of noise
        static Random random = new Random(1); // seed 1 makes runs reproducible

        /// <summary>
        /// Execute Fit to find given trend in generated data with noise
        /// </summary>
        static Trend FitHelper(Trend given, int nPoints, double variation, Random random)
        {
            double[] data = new double[nPoints];
            for (int i = 0; i < nPoints; i++)
            {
                data[i] = given.Predict(i) + variation * (random.NextDouble() - 0.5); // data + noise
            }
            return Regression.Fit(data);
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        //[ClassInitialize()]
        //public static void MyClassInitialize(TestContext testContext)
        //{
        //}
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion


        /// <summary>
        ///A test for Fit
        ///</summary>
        [TestMethod()]
        public void FitClean()
        {
            Trend expected = new Trend { Slope = 50.0, Intercept = 200.0 };
            Trend actual = FitHelper(expected, 10, 0.0, random); // clean, noise = 0
            Assert.IsTrue(Math.Abs(actual.Slope - expected.Slope) < delta);
            Assert.IsTrue(Math.Abs(actual.Intercept - expected.Intercept) < delta);
        }
            
        [TestMethod()]
        public void FitNoisy()
        {
            Trend expected = new Trend { Slope = 50.0, Intercept = 200.0 };
            Trend actual = FitHelper(expected, 10, 10.0, random); // noise = 10
            Assert.IsTrue(Math.Abs(actual.Slope - expected.Slope) < 10 *delta); // fails with just delta
            Assert.IsTrue(Math.Abs(actual.Intercept - expected.Intercept) < 10 * delta);
        }
    }
}
