#include <ppl.h>
#include <concrtrm.h>
#include <math.h>
#include <vector>

#include "ParallelLoops.h"

using namespace ::SampleUtilities;
using namespace ::Concurrency;
using namespace ::std;


void harness(