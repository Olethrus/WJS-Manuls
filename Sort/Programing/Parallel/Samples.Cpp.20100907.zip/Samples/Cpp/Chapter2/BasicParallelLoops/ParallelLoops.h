//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

#pragma once
#include <exception>
#include <string>
#include <iosfwd>
#include <ppl.h>
#include <concrt.h>
#include <concrtrm.h>
#include <math.h>
#include <vector>
#include <algorithm>

#include "SampleUtilities.h"

using namespace ::std;
using namespace ::Concurrency;
using namespace ::SampleUtilities;

class ParallelForExampleException : std::exception {};
class InvalidValueFoundException : std::exception {};

// global
extern volatile bool SimulateInternalError;

double round (double value, int decimals)
{
    double exp = pow((double)10, decimals);
    return  floor( value * exp ) / exp;
}

double DoWork(int i, int loopBodyComplexity)
{
    double result = 0;
    for (int j = 1; j < loopBodyComplexity + 1; j++)
    {
        double j2 = (double)j;
        double i2 = (double)i;
        result += sqrt(((double)9.0 * i2 * i2 + (double)16.0 * i * i) * j2 * j2);
    }

    // simulate unexpected condition in loop body
    if (i % 402030 == 2029 && SimulateInternalError)
        throw new ParallelForExampleException();

    return round(result,1);
} 

double ExpectedResult(int i, int loopBodyComplexity) 
{
    return (double)2.5 * (loopBodyComplexity + 1) * loopBodyComplexity * i;
}

void VerifyResult(vector<double> values, int loopBodyComplexity) 
{
    unsigned int size = values.size();
    for (unsigned int i = 0; i<size; ++i) 
    {
        if (values[i] != ExpectedResult(i,loopBodyComplexity))
            throw InvalidValueFoundException();
    }
}

#pragma region examples

// Sequential for loop
void Chapter2Example01(vector<double>& values, int loopBodyComplexity, int numberOfSteps)
{
    for (int i = 0; i < numberOfSteps; i++)	
    {
        values[i] = DoWork(i, loopBodyComplexity);
    }
}

void Chapter2Example03(vector<double>& values, int loopBodyComplexity, int numberOfSteps)
{
    parallel_for(0, numberOfSteps, [&](int i) 
    {
        values[i] = DoWork(i, loopBodyComplexity); 
    });
}

// <COMMENT> 
// this really doesn't show anything interesting
// the pair gets in the way.  A better example would do something like compute a checksum for each 64K chunk or something like that.  
// ForEach requires an initial data set!
// </COMMENT>
// TOOD: come up with a better example for parallel_for_each

void Chapter2Example04a( vector<double> &values, int loopBodyComplexity, int numberOfSteps)
{
    vector<int> seed(numberOfSteps);

    // create seed values
    for(int i = 0; i< numberOfSteps; ++i) 
        seed[i] = i;

    // compute the results
    parallel_for_each(seed.begin(), seed.end(), [&values, loopBodyComplexity](int i) 
    {
        values[i] = DoWork(i, loopBodyComplexity);
    });
}

// <COMMENT> no equivalent for Example 4b, 5, 6 </COMMENT>


// <COMMENT> we might want other partitioning examples </COMMENT>
void Chapter2Example07(vector<double>& results, int loopBodyComplexity, int numberOfSteps)
{
    int rangeSize = numberOfSteps / (GetProcessorCount() * 10);
    if (rangeSize < 1) rangeSize = 1;

    parallel_for(0, numberOfSteps, rangeSize, [&](int i) 
    {
        for (int j = 0; j < rangeSize; j++)	{
            results[i+j] = DoWork(i+j, loopBodyComplexity);
        }
    });
} 

#pragma endregion

// harness to run all the examples
void ParallelForExample(int loopBodyComplexity, int numberOfSteps, bool verifyResult) 
{
    vector<double> values(numberOfSteps);

    printf("Parallel For Examples (LoopBodyComplexity=%d, NumberOfSteps=%d)\n",
        loopBodyComplexity, numberOfSteps);
    try 
    {
        TimedRun([&values, loopBodyComplexity, numberOfSteps]() {Chapter2Example01(values, loopBodyComplexity, numberOfSteps);},
            "Sequential for");
        VerifyResult(values, loopBodyComplexity);

        TimedRun([&values, loopBodyComplexity, numberOfSteps]() {Chapter2Example03(values, loopBodyComplexity, numberOfSteps);},
            "Simple parallel_for");
        VerifyResult(values, loopBodyComplexity);

        TimedRun([&values, loopBodyComplexity, numberOfSteps]() {Chapter2Example07(values, loopBodyComplexity, numberOfSteps);},
            "Partitioned with fixed ranges");
        VerifyResult(values, loopBodyComplexity);

        TimedRun([&values, loopBodyComplexity, numberOfSteps]() {Chapter2Example04a(values, loopBodyComplexity, numberOfSteps);},
            "Simple Parallel_for_each");
        VerifyResult(values, loopBodyComplexity);
    }
    catch (InvalidValueFoundException e) {
        printf( "Error: Verification Failed\n");
    }
    printf("\n");
}
