//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

#include "ParallelLoops.h"

volatile bool SimulateInternalError;

int main()
{
    printf("Basic Parallel Loops Samples\n\n");
#if _DEBUG
    printf("For most accurate timing results, use Release build.\n\n");
#endif

    SimulateInternalError = false;

    // Parameters: LoopBodyComplexity, NumberOfSteps, VerifyResult
    ParallelForExample( 10000000, 10, true );
    ParallelForExample( 1000000, 100, true );
    ParallelForExample( 10000, 10000, true );
    ParallelForExample( 100, 1000000, true );
    ParallelForExample( 10, 10000000, true );

    printf("\nRun complete... press enter to finish.");
    getchar();
}
