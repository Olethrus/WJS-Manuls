//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

#pragma once
#include <vector>

namespace CreditReview
{
    /// <summary>
    /// One customer's account data: array of monthly balances, also predictions and warnings
    /// </summary>
    class Account
    {
    public:
        typedef std::vector<double> vector_type;
        ///<summary>
        /// move constructor
        ///</summary>
        Account(Account&& other) : m_overdraft(other.m_overdraft)
                                 , m_seqPrediction(other.m_seqPrediction)
                                 , m_parPrediction(other.m_parPrediction)
                                 , m_seqWarning(other.m_seqWarning)
                                 , m_parWarning(other.m_parWarning)
                                 , m_balances(other.m_balances)
        {
        }
        /// <summary>
        /// Constructor, allocate balance history for months, assign overdraft
        /// <summary>
        Account(int months, double overdraft) : m_balances(months)
                                              , m_overdraft(overdraft){}

        vector_type& Balances()         {return m_balances;}
        double& SeqPrediction()         {return m_seqPrediction;}
        double& ParPrediction()         {return m_parPrediction;}
        bool& SeqWarning()              {return m_seqWarning;}
        bool& ParWarning()              {return m_parWarning;}
        double& Overdraft()             {return m_overdraft;}
    private:
        vector_type m_balances;
        double m_overdraft;
        double m_seqPrediction;
        double m_parPrediction;
        bool m_seqWarning;
        bool m_parWarning;

        //disable copy construction
        Account(const Account&);

    };

    /// <summary>
    /// Assign balance history to vary randomly around randomly assigned trend
    /// <summary>
    template <typename Trend, typename Random>
    inline void AssignRandomTrend(Account& account, Trend& goodBalance, Trend& badBalance, double variation, Random& random)
    {
        // choose random trend
        double rateScale = 100.0, balanceScale = 100.0;  // for now, adjust later
        double rateMean = (goodBalance.Slope() + badBalance.Slope()) / 2;
        double initialBalanceMean = (goodBalance.Intercept() + badBalance.Intercept()) / 2;
        double rate = rateMean + rateScale * random();
        double initialBalance = initialBalanceMean + balanceScale * random();
        Trend trend(rate, initialBalance);

        // balance history is trend plus noise
        for (size_t i = 0; i < account.Balances().size(); i++) 
        {
            account.Balances()[i] = Predict(trend, static_cast<double>(i)) + variation * random(); 
        }
    }

    /// <summary>
    /// Print balances for months starting at firstMonth
    /// </summary>
    inline void PrintBalance(Account& account, size_t firstMonth, size_t months)
    {
        for (size_t month = firstMonth; month < firstMonth + months; month++)
        {
            if (month < account.Balances().size())
            {
                printf("%*.2f ", 9,account.Balances()[month]);
            }
            else
            {
                printf("       "); // line up columns even if data missing
            }
        }
    }
}
