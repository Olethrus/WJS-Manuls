//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

#include <random>
#include <algorithm>
#include <ppl.h>

#include "SampleUtilities.h"
#include "Account.h"
#include "AccountRepository.h"
#include "Trend.h"

using namespace ::SampleUtilities;
using namespace ::CreditReview;

using namespace ::Concurrency;
using namespace ::std;

const size_t NUM_MONTHS = 3;

void UpdatePredictionsSequential(AccountRepository& accounts)
{
    for_each(accounts.begin(), accounts.end(), [](AccountRepository::value_type& record)
    {
        Account& account = record.second;
        Trend trend = Fit(account.Balances());
        double prediction = Predict(trend, static_cast<double>(account.Balances().size() + NUM_MONTHS)); 
        account.SeqPrediction() = prediction;
        account.SeqWarning() = prediction < account.Overdraft();
    });
}

void UpdatePredictionsParallel(AccountRepository& accounts)
{
    parallel_for_each(accounts.begin(), accounts.end(), [](AccountRepository::value_type& record)
    {
        Account& account = record.second;
        Trend trend = Fit(account.Balances());
        double prediction = Predict(trend, static_cast<double>(account.Balances().size() + NUM_MONTHS));
        account.ParPrediction() = prediction;
        account.ParWarning() = prediction < account.Overdraft();
    });
}

/// <summary>
/// Usage: CreditReview n, optional n is number of customers, use 100,000+ for meaningful timings
/// </summary>
int main(int argc, char* argv)
{
    printf("Credit Review Sample\n\n");
#if _DEBUG
    printf("For most accurate timing results, use Release build.\n\n");
#endif

    std::default_random_engine engine;
    engine.seed(42);
    std::uniform_real_distribution<double> distribution(0.0, 1.0);
    auto random = std::bind(distribution, engine);

    // Defaults for data generation, may override some on command line
    int months = 36;
    int customerCount = 1000000; // for data runs make big enough for significant timing measurements

    Trend goodBalance (0.0, 0.0);
    Trend badBalance (-150.0, 0.0);

    double variation = 100.0;
    double overdraft = -1000.0; // Default overdraft limit

    // Printed table of results
    int rows = 8;
    int cols = 4;

    //TODO: command line options
    /*
    // Optionally override some defaults on command line
    if (args.Length > 0) customerCount = Int32.Parse(args[0], CultureInfo.CurrentCulture);
    if (args.Length > 1) months = Int32.Parse(args[1], CultureInfo.CurrentCulture);
    if (months < 4) months = 4; // PrintBalance requires at least 4 months
    */

    int fewCustomers = 10;
    int fewMonths = 3;

    AccountRepository smallAccounts(fewCustomers, fewMonths, overdraft);

    AssignRandomTrends(smallAccounts, goodBalance, badBalance, variation, random);

    UpdatePredictionsSequential(smallAccounts);
    UpdatePredictionsParallel(smallAccounts);

    // Create accounts for timing tests
    AccountRepository accounts(customerCount, months, overdraft);
    AssignRandomTrends(accounts, goodBalance, badBalance, variation, random);

    // Print summary of accounts  
    printf("\n");
    printf("%d customers, %d months in each account\n", customerCount, months);

    // Execute sequential and parallel versions, print timings
    printf("\n");

    TimedResult([&]()->int{ UpdatePredictionsSequential(accounts); return customerCount; }, "Sequential");
    TimedResult([&]()->int{ UpdatePredictionsParallel(accounts); return customerCount; }, "  Parallel");

    // Print a few accounts including predictions and warnings
    PrintAccounts(accounts, rows, months - cols, cols); // print the last few months

    printf("\nRun complete... press enter to finish.");
    getchar();
}
