//===============================================================================
// Microsoft patterns & practices
// Parallel Programming Guide
//===============================================================================
// Copyright � Microsoft Corporation.  All rights reserved.
// This code released under the terms of the 
// Microsoft patterns & practices license (http://parallelpatterns.codeplex.com/license).
//===============================================================================

#pragma once
#include <numeric>
#include <algorithm>
#include <assert.h>

namespace CreditReview
{
    using namespace ::std;
    typedef vector<double> vector_double; 

    /// <summary>
    /// Linear trend from slope and intercept. Predict y given any x value using the formula
    /// y = slope * x + intercept.
    /// </summary>
    struct Trend
    {
        double m_slope;
        double m_intercept;
    public:
        /// <summary>
        /// constructs a Trend with given Slope & Intercept
        /// <summary>
        Trend(double slope, double intercept): m_slope(slope), m_intercept(intercept) {}

        /// The change in y per unit of x
        /// </summary>
        inline double Slope() { return m_slope; }

        /// <summary>
        /// The value of y when x is zero
        /// </summary>
        inline double Intercept() { return m_intercept; }
    };
    /// <summary>
    /// Predicts a y value given any x value using the formula y = slope * x + intercept.
    /// </summary>
    /// <param name="ordinate">The x value</param>
    /// <returns>The predicted y value</returns>
    inline double Predict(Trend trend, double ordinate)
    {
        return trend.Slope() * ordinate + trend.Intercept(); 
    }

#pragma region Numerical Routines

    double Average(vector_double& in)
    {
        return accumulate(in.begin(), in.end(), 0.0, std::plus<double>()) / static_cast<double>(in.size());
    }
    /// <summary>
    /// Linear regression of (x, y) pairs
    /// </summary>
    /// <param name="abscissaValues">The x values</param>
    /// <param name="ordinateValues">The y values corresponding to each x value</param>
    /// <returns>A trend line that best predicts each (x, y) pair</returns>
    inline Trend Fit(vector_double& abscissaValues, vector_double& ordinateValues)
    {
        assert(abscissaValues.size() == ordinateValues.size());
        assert(abscissaValues.size() > 1);

        double xx = 0, xy = 0;
        double abscissaMean = Average(abscissaValues);
        double ordinateMean = Average(ordinateValues);

        // calculate the sum of squared differences
        for (size_t i = 0; i < abscissaValues.size(); i++)
        {
            double xi = abscissaValues[i] - abscissaMean;
            xx += xi * xi;
            xy += xi * (ordinateValues[i] - ordinateMean);
        };

        assert(xx != 0.0);

        double slope = xy / xx;

        return Trend(slope, ordinateMean - slope * abscissaMean);
    }

    /// <summary>
    /// Linear regression with x-values given implicity by the y-value indices
    /// </summary>
    /// <param name="ordinateValues">A series of two or more values</param>
    /// <returns>A trend line</returns>
    inline Trend Fit(vector_double& ordinateValues)
    {
        assert (ordinateValues.size() > 0);

        // special case - x values are just the indices of the y's
        // create a vector containing the range of numbers from 0 to n
        vector_double range(ordinateValues.size());
        int i = 0;
        generate(range.begin(),range.end(),[&i](){return ++i;});
        return Fit(range, ordinateValues);
    }
#pragma endregion
}
