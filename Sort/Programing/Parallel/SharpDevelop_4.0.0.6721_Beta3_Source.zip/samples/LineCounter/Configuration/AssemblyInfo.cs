﻿/*
 * Created by SharpDevelop.
 * User: Daniel Grunwald
 * Date: 09.05.2006
 * Time: 17:22
 */

using System.Reflection;

[assembly: AssemblyTitle("LineCounter")]
[assembly: AssemblyDescription("Macro AddIn for SharpDevelop 2.0")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("SharpDevelop")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// The assembly version has following format :
//
// Major.Minor.Build.Revision
//
// You can specify all values by your own or you can build default build and revision
// numbers with the '*' character (the default):

[assembly: AssemblyVersion("1.0.*")]

