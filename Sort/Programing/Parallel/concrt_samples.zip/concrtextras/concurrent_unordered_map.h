//--------------------------------------------------------------------------
// 
//  Copyright (c) Microsoft Corporation.  All rights reserved. 
// 
//  File: concurrent_unordered_map.h
//
//
//--------------------------------------------------------------------------
#pragma once

#include "concurrent_hash.h"

namespace Concurrency
{
namespace samples
{
// Template class for hash map traits
template<typename _Key_type, typename _Element_type, typename _Key_comparator, typename _Allocator_type, bool _Allow_multimapping>
class _Concurrent_unordered_map_traits : public std::_Container_base
{
public:
    typedef std::pair<_Key_type, _Element_type> _Value_type;
    typedef std::pair<const _Key_type, _Element_type> value_type;
    typedef _Key_type key_type;
    typedef _Key_comparator key_compare;

    typedef typename _Allocator_type::template rebind<value_type>::other allocator_type;

    enum
    {
        _M_allow_multimapping = _Allow_multimapping
    };

    _Concurrent_unordered_map_traits() : _M_comparator()
    {
    }

    _Concurrent_unordered_map_traits(const key_compare& _Traits) : _M_comparator(_Traits)
    {
    }

    class value_compare : public std::binary_function<value_type, value_type, bool>
    {
        friend class _Concurrent_unordered_map_traits<_Key_type, _Element_type, _Key_comparator, _Allocator_type, _Allow_multimapping>;

    public:
        bool operator()(const value_type& _Left, const value_type& _Right) const
        {
            return (_M_comparator(_Left.first, _Right.first));
        }

        value_compare(const key_compare& _Traits) : _M_comparator(_Traits)
        {
        }

    protected:
        key_compare _M_comparator;    // the comparator predicate for keys
    };

    template<class _Type1, class _Type2>
    static const _Key_type& _Key_function(const std::pair<_Type1, _Type2>& _Value)
    {
        return (_Value.first);
    }

    key_compare _M_comparator; // the comparator predicate for keys
};

template <typename _Key_type, typename _Element_type, typename _Hasher = std::tr1::hash<_Key_type>, typename _Key_equality = std::equal_to<_Key_type>, typename _Allocator_type = std::allocator<std::pair<const _Key_type, _Element_type> > >
class concurrent_unordered_map : public _Concurrent_hash< _Concurrent_unordered_map_traits<_Key_type, _Element_type, _Hash_compare<_Key_type, _Hasher, _Key_equality>, _Allocator_type, false> >
{
public:
    // Base type definitions
    typedef concurrent_unordered_map<_Key_type, _Element_type, _Hasher, _Key_equality, _Allocator_type> _Mytype;
    typedef _Hash_compare<_Key_type, _Hasher, _Key_equality> _Mytraits;
    typedef _Concurrent_hash< _Concurrent_unordered_map_traits<_Key_type, _Element_type, _Mytraits, _Allocator_type, false> > _Mybase;

    // Type definitions
    typedef _Key_type key_type;
    typedef typename _Mybase::value_type value_type;
    typedef _Element_type mapped_type;
    typedef _Hasher hasher;
    typedef _Key_equality key_equal;
    typedef _Mytraits key_compare;

    typedef typename _Mybase::allocator_type allocator_type;
    typedef typename _Mybase::pointer pointer;
    typedef typename _Mybase::const_pointer const_pointer;
    typedef typename _Mybase::reference reference;
    typedef typename _Mybase::const_reference const_reference;

    typedef typename _Mybase::size_type size_type;
    typedef typename _Mybase::difference_type difference_type;

    typedef typename _Mybase::iterator iterator;
    typedef typename _Mybase::const_iterator const_iterator;
    typedef typename _Mybase::iterator local_iterator;
    typedef typename _Mybase::const_iterator const_local_iterator;

    // Construction/destruction/copying
    explicit concurrent_unordered_map(size_type _Number_of_buckets = 8, const hasher& _Hasher = hasher(), const key_equal& _Key_equality = key_equal(),
        const allocator_type& _Allocator = allocator_type())
        : _Mybase(_Number_of_buckets, key_compare(_Hasher, _Key_equality), _Allocator)
    {
    }

    concurrent_unordered_map(const _Allocator_type& _Allocator) : _Mybase(8, key_compare(), Allocator)
    {
    }

    template <typename _Iterator>
    concurrent_unordered_map(_Iterator _First, _Iterator _Last, size_type _Number_of_buckets = 8, const hasher& _Hasher = hasher(),
        const key_equal& _Key_equality = key_equal(), const allocator_type& _Allocator = allocator_type())
        : _Mybase(key_compare(), allocator_type())
    {
        for (; _First != _Last; ++_First)
        {
            _Mybase::insert(*_First);
        }
    }

    concurrent_unordered_map(const concurrent_unordered_map& _Umap) : _Mybase(_Umap)
    {
    }

    concurrent_unordered_map(const concurrent_unordered_map& _Umap, const _Allocator_type& _Allocator) : _Mybase(_Umap, _Allocator)
    {
    }

    concurrent_unordered_map& operator=(const concurrent_unordered_map& _Umap)
    {
        _Mybase::operator=(_Umap);
        return (*this);
    }

    iterator unsafe_erase(const_iterator _Where)
    {
        return _Mybase::unsafe_erase(_Where);
    }

    size_type unsafe_erase(const key_type& _Keyval)
    {
        return _Mybase::unsafe_erase(_Keyval);
    }

    iterator unsafe_erase(const_iterator _First, const_iterator _Last)
    {
        return _Mybase::unsafe_erase(_First, _Last);
    }

    void swap(concurrent_unordered_map& _Umap)
    {
        _Mybase::swap(_Umap);
    }

    // Observers
    hasher hash_function() const
    {
        return _M_comparator._M_hash_object;
    }

    key_equal key_eq() const
    {
        return _M_comparator._M_key_compare_object;
    }

    mapped_type& operator[](const key_type& _Keyval)
    {
        iterator _Where = find(_Keyval);

        if (_Where == end())
        {
            _Where = insert(std::pair<key_type, mapped_type>(std::move(_Keyval), mapped_type())).first;
        }

        return ((*_Where).second);
    }

    mapped_type& at(const key_type& _Keyval)
    {
        iterator _Where = find(_Keyval);

        if (_Where == end())
        {
            throw std::out_of_range("invalid concurrent_unordered_map<K, T> key");
        }

        return ((*_Where).second);
    }

    const mapped_type& at(const key_type& _Keyval) const
    {
        const_iterator _Where = find(_Keyval);

        if (_Where == end())
        {
            throw std::out_of_range("invalid concurrent_unordered_map<K, T> key");
        }

        return ((*_Where).second);
    }
};

template <typename _Key_type, typename _Element_type, typename _Hasher = std::tr1::hash<_Key_type>, typename _Key_equality = std::equal_to<_Key_type>, typename _Allocator_type = std::allocator<std::pair<const _Key_type, _Element_type> > >
class concurrent_unordered_multimap : public _Concurrent_hash< _Concurrent_unordered_map_traits<_Key_type, _Element_type, _Hash_compare<_Key_type, _Hasher, _Key_equality>, _Allocator_type, true> >
{
public:
    // Base type definitions
    typedef concurrent_unordered_multimap<_Key_type, _Element_type, _Hasher, _Key_equality, _Allocator_type> _Mytype;
    typedef _Hash_compare<_Key_type, _Hasher, _Key_equality> _Mytraits;
    typedef _Concurrent_hash< _Concurrent_unordered_map_traits<_Key_type, _Element_type, _Mytraits, _Allocator_type, true> > _Mybase;

    // Type definitions
    typedef _Key_type key_type;
    typedef typename _Mybase::value_type value_type;
    typedef _Element_type mapped_type;
    typedef _Hasher hasher;
    typedef _Key_equality key_equal;
    typedef _Mytraits key_compare;

    typedef typename _Mybase::allocator_type allocator_type;
    typedef typename _Mybase::pointer pointer;
    typedef typename _Mybase::const_pointer const_pointer;
    typedef typename _Mybase::reference reference;
    typedef typename _Mybase::const_reference const_reference;

    typedef typename _Mybase::size_type size_type;
    typedef typename _Mybase::difference_type difference_type;

    typedef typename _Mybase::iterator iterator;
    typedef typename _Mybase::const_iterator const_iterator;
    typedef typename _Mybase::iterator local_iterator;
    typedef typename _Mybase::const_iterator const_local_iterator;

    // Construction/destruction/copying
    explicit concurrent_unordered_multimap(size_type _Number_of_buckets = 8, const hasher& _Hasher = hasher(), const key_equal& _Key_equality = key_equal(),
        const allocator_type& _Allocator = allocator_type())
        : _Mybase(_Number_of_buckets, key_compare(_Hasher, _Key_equality), _Allocator)
    {
    }

    concurrent_unordered_multimap(const _Allocator_type& _Allocator) : _Mybase(8, key_compare(), Allocator)
    {
    }

    template <typename _Iterator>
    concurrent_unordered_multimap(_Iterator _First, _Iterator _Last, size_type _Number_of_buckets = 8, const hasher& _Hasher = hasher(),
        const key_equal& _Key_equality = key_equal(), const allocator_type& _Allocator = allocator_type())
        : _Mybase(key_compare(), allocator_type())
    {
        for (; _First != _Last; ++_First)
        {
            _Mybase::insert(*_First);
        }
    }

    concurrent_unordered_multimap(const concurrent_unordered_multimap& _Umap) : _Mybase(_Umap)
    {
    }

    concurrent_unordered_multimap(const concurrent_unordered_multimap& _Umap, const _Allocator_type& _Allocator) : _Mybase(_Umap, _Allocator)
    {
    }

    concurrent_unordered_multimap& operator=(const concurrent_unordered_multimap& _Umap)
    {
        _Mybase::operator=(_Umap);
        return (*this);
    }

    // Modifiers
    std::pair<iterator, bool> insert(const value_type& _Value)
    {
        return _Mybase::insert(_Value);
    }

    iterator insert(const_iterator _Where, const value_type& _Value)
    {
        return _Mybase::insert(_Where, _Value);
    }

    template<class _Iterator>
    void insert(_Iterator _First, _Iterator _Last)
    {
        _Mybase::insert(_First, _Last);
    }

    iterator unsafe_erase(const_iterator _Where)
    {
        return _Mybase::unsafe_erase(_Where);
    }

    size_type unsafe_erase(const key_type& _Keyval)
    {
        return _Mybase::unsafe_erase(_Keyval);
    }

    iterator unsafe_erase(const_iterator _First, const_iterator _Last)
    {
        return _Mybase::unsafe_erase(_First, _Last);
    }

    void swap(concurrent_unordered_multimap& _Umap)
    {
        _Mybase::swap(_Umap);
    }

    // Observers
    hasher hash_function() const
    {
        return _M_comparator._M_hash_object;
    }

    key_equal key_eq() const
    {
        return _M_comparator._M_key_compare_object;
    }
};
} // namespace samples
} // namespace Concurrency
