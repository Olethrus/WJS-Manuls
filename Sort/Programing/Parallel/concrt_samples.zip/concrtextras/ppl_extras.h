//--------------------------------------------------------------------------
// 
//  Copyright (c) Microsoft Corporation.  All rights reserved. 
// 
//  File: ppl_extras.h
//
//  Implementation of various PPL algorithms.
//
//--------------------------------------------------------------------------

#pragma once

#include <ppl.h>
#include <numeric>
#include <vector>
#include "concrt_extras.h"
namespace Concurrency
{
    namespace samples
    {
        namespace details
        {
        };
        template<class in_it,class pr>
        inline bool parallel_all_of(in_it first, in_it last, const pr& pred)
        {

            typedef typename std::iterator_traits<in_it>::value_type item_type;

            structured_task_group tasks;

            auto for_each_predicate = [&pred,&tasks](const item_type& cur){
                if (!pred(cur))
                    tasks.cancel();
            };

            auto task = make_task([&first,&last,&pred,&tasks,&for_each_predicate](){
                parallel_for_each(first,last,for_each_predicate);
            });

            return tasks.run_and_wait(task) != canceled;
        }

        template<class in_it,class pr>
        inline bool parallel_any_of(in_it first, in_it last, const pr& pred)
        {

            typedef typename std::iterator_traits<in_it>::value_type item_type;

            structured_task_group tasks;

            auto for_each_predicate = [&pred,&tasks](const item_type& cur){
                if (pred(cur))
                    tasks.cancel();
            };

            auto task = make_task([&first,&last,&pred,&tasks,&for_each_predicate](){
                parallel_for_each(first,last,for_each_predicate);
            });

            return tasks.run_and_wait(task) == canceled;
        }

        template<class in_it,class pr>
        inline bool parallel_none_of(in_it first, in_it last, const pr& pred)
        {

            typedef typename std::iterator_traits<in_it>::value_type item_type;

            structured_task_group tasks;

            auto for_each_predicate = [&pred,&tasks](const item_type& cur){
                if (pred(cur))
                    tasks.cancel();
            };

            auto task = make_task([&first,&last,&pred,&tasks,&for_each_predicate](){
                parallel_for_each(first,last,for_each_predicate);
            });

            return tasks.run_and_wait(task) != canceled;
        }

        template<class in_it, class pr>
        inline typename std::iterator_traits<in_it>::difference_type
            parallel_count_if(in_it first, in_it last, const pr& pred)
        {
            typedef typename std::iterator_traits<in_it>::value_type item_type;

            combinable<iterator_traits<in_it>::difference_type> sums;

            parallel_for_each(first,last,[&](const item_type& cur){
                if (pred(cur))
                    ++sums.local();
            });

            return sums.combine(std::plus<iterator_traits<in_it>::difference_type>());
        }
        namespace details
        {
            template <typename random_iterator, typename index_type, typename function, bool is_iterator>
            class fixed_chunk_class
            {
            public:
                fixed_chunk_class(const random_iterator& first, index_type first_iteration, index_type last_iteration, const index_type& step, const function& func) :
                  m_first(first), m_first_iteration(first_iteration), m_last_iteration(last_iteration), m_step(step), m_function(func)
                  {
                      // Empty constructor since members are already assigned
                  }

                  void operator()() const
                  {
                      // Keep the secondary, scaled, loop index for quick indexing into the data structure
                      index_type scaled_index = m_first_iteration * m_step;

                      for (index_type i = m_first_iteration; i < m_last_iteration; (i++, scaled_index += m_step))
                      {
                          // Execute one iteration: the element is at scaled index away from the first element.
                          ::Concurrency::_Parallel_chunk_helper_invoke<random_iterator, index_type, function, is_iterator>::_Invoke(m_first, scaled_index, m_function);
                      }
                  }

            private:
                const random_iterator& m_first;
                const index_type&      m_step;
                const function&        m_function;
                const index_type       m_first_iteration;
                const index_type       m_last_iteration;

                fixed_chunk_class const & operator=(fixed_chunk_class const&);    // no assignment operator
            };

            template <typename random_iterator, typename index_type, typename function>
            void parallel_for_impl(random_iterator first, random_iterator last, index_type step, const function& func)
            {
                const bool is_iterator = !(std::tr1::is_same<random_iterator, index_type>::value);
                typedef details::fixed_chunk_class<random_iterator, index_type, function, is_iterator> worker_class;

                // The step argument must be 1 or greater; otherwise it is an invalid argument
                if (step < 1)
                {
                    throw std::invalid_argument("step");
                }

                // If there are no elements in this range we just return
                if (first >= last)
                {
                    return;
                }

                // This is safe to do only if one can assume no signed overflow problems
                index_type range = last - first;

                if (range <= step)
                {
                    index_type iteration = 0;
                    ::Concurrency::_Parallel_chunk_helper_invoke<random_iterator, index_type, function, is_iterator>::_Invoke(first, iteration, func);
                }
                else
                {
                    // Get the number of chunks to divide the work
                    index_type num_chunks = _Get_num_chunks<index_type>();
                    index_type iterations;

                    if (step != 1)
                    {
                        iterations = ((range - 1) / step) + 1;
                    }
                    else
                    {
                        iterations = last - first;
                    }

                    // Allocate memory on the stack for task_handles to ensure everything is properly structured.
                    task_handle<worker_class> * chunk_helpers = (task_handle<worker_class> *) _alloca(sizeof(task_handle<worker_class>) * num_chunks);

                    structured_task_group task_group;
                    ::Concurrency::_Parallel_chunk_impl(first, iterations, step, func, task_group, chunk_helpers, num_chunks, true);
                }
            }
            template <typename random_iterator, typename function>
            void parallel_for_each_impl(const random_iterator& first, const random_iterator& last, const function& func, std::random_access_iterator_tag)
            {
                std::iterator_traits<random_iterator>::difference_type step = 1;
                details::parallel_for_impl(first, last, step, func);
            }

            template <typename forward_iterator, typename function>
            class parallel_for_each_helper
            {
            public:
                typedef typename std::iterator_traits<forward_iterator>::value_type value_type;
                static const unsigned int size = 1024;

                parallel_for_each_helper(forward_iterator& first, const forward_iterator& last, const function& func) :
                m_function(func), m_len(0)
                {
                    // Add a batch of work items to this functor's array
                    for (unsigned int index=0; (index < size) && (first != last); index++)
                    {
                        m_element[m_len++] = &(*first++);
                    }
                }

                void operator()() const
                {
                    // Invoke parallel_for on the batched up array of elements
                    parallel_for_impl(0U, m_len, 1U,
                        [this] (unsigned int index)
                    {
                        m_function(*(m_element[index]));
                    }
                    );
                }

            private:

                const function& m_function;
                value_type *    m_element[size];
                unsigned int    m_len;

                parallel_for_each_helper const & operator=(parallel_for_each_helper const&);    // no assignment operator
            };
            template <typename forward_iterator, typename function>
            void parallel_for_each_forward_impl(forward_iterator& first, const forward_iterator& last, const function& func, task_group& tg)
            {
                // This functor will be copied on the heap and will execute the chunk in parallel
                {
                    Concurrency::samples::details::parallel_for_each_helper<forward_iterator, function> functor(first, last, func);
                    tg.run(functor);
                }

                // If there is a tail, push the tail
                if (first != last)
                {
                    tg.run(
                        [&first, &last, &func, &tg]
                    {
                        Concurrency::samples::details::parallel_for_each_forward_impl(first, last, func, tg);
                    }
                    );
                }
            }

            template <typename forward_iterator, typename function>
            void parallel_for_each_impl(forward_iterator first, const forward_iterator& last, const function& func, std::forward_iterator_tag)
            {
                // Since this is a forward iterator, it is difficult to validate that first comes before _Last, so
                // it is up to the user to provide valid range.
                if (first != last)
                {
                    task_group tg;
                    parallel_for_each_forward_impl(first, last, func, tg);
                    tg.wait();
                }
            }
        };

        // Public API entries for parallel_for_fixed

        /// <summary>
        ///     Performs parallel iteration over a range of indices from first
        ///     to last, not including last.
        /// </summary>
        /// <param name="first">
        ///     First index to be included in parallel iteration.
        /// </param>
        /// <param name="last">
        ///     First index after first not to be included in parallel iteration.
        /// </param>
        /// <param name="step">
        ///     Step to be used in computing index for the given iteration. Only positive step is supported;
        ///     exception is thrown if step is smaller than or equal to 0.
        /// </param>
        /// <param name="func">
        ///     Function object to be executed on each iteration.
        /// </param>
        /// <remarks>
        ///     For more information, see <see cref="Parallel Algorithms"/>.
        /// </remarks>
        template <typename index_type, typename function>
        void parallel_for_fixed(index_type first, index_type last, index_type step, const function& func)
        {
            _Trace_ppl_function(PPLParallelForEventGuid, _TRACE_LEVEL_INFORMATION, CONCRT_EVENT_START);
            details::parallel_for_impl(first, last, step, func);
            _Trace_ppl_function(PPLParallelForEventGuid, _TRACE_LEVEL_INFORMATION, CONCRT_EVENT_END);
        }

        /// <summary>
        ///     Performs parallel iteration over a range of indices from first
        ///     to last, not including last.
        /// </summary>
        /// <param name="first">
        ///     First index to be included in parallel iteration.
        /// </param>
        /// <param name="last">
        ///     First index after first not to be included in parallel iteration.
        /// </param>
        /// <param name="func">
        ///     Function object to be executed on each iteration.
        /// </param>
        /// <remarks>
        ///     For more information, see <see cref="Parallel Algorithms"/>.
        /// </remarks>
        template <typename index_type, typename function>
        void parallel_for_fixed(index_type first, index_type last, const function& func)
        {
            parallel_for_fixed(first, last, index_type(1), func);
        }

        /// <summary>
        ///     This template function is semantically equivalent to std::for_each, except that
        ///     the iteration is done in parallel and ordering is unspecified. The function argument
        ///     func must support operator()(T) where T is the item type of the container being
        ///     iterated over.
        /// </summary>
        /// <param name="first">
        ///     First element to be included in parallel iteration.
        /// </param>
        /// <param name="last">
        ///     First element after first not to be included in parallel iteration.
        /// </param>
        /// <param name="func">
        ///     Function object to be executed on each iteration.
        /// </param>
        /// <remarks>
        ///     For more information, see <see cref="Parallel Algorithms"/>.
        /// </remarks>
        template <typename iterator, typename function>
        void parallel_for_each_fixed(iterator first, iterator last, const function& func)
        {
            _Trace_ppl_function(PPLParallelForeachEventGuid, _TRACE_LEVEL_INFORMATION, CONCRT_EVENT_START);
            details::parallel_for_each_impl(first, last, func, std::_Iter_cat(first));
            _Trace_ppl_function(PPLParallelForeachEventGuid, _TRACE_LEVEL_INFORMATION, CONCRT_EVENT_END);
        }
        namespace details
        {
            // Implementation of accumulate for iterators with forward access. Note that forward access iterator implementation
            // is also used in the absence of random iterator implementation.

            template <typename input_iterator, typename accumulation_type, typename symmetric_function, typename asymmetric_function>
            accumulation_type parallel_accumulate_impl(input_iterator first, input_iterator last,
                accumulation_type initial_value, symmetric_function& symmetric_func, asymmetric_function& asymmetric_func, std::forward_iterator_tag)
            {
                combinable<accumulation_type> result;

                //
                // Create local accumulations
                //
                parallel_for_each(first, last,
                    [&result, &symmetric_func, &asymmetric_func] (typename std::iterator_traits<input_iterator>::value_type value)
                {
                    result.local() = asymmetric_func(result.local(), value);
                });

                //
                // Combine local accumulations into the final accumulation
                //
                return symmetric_func(initial_value, result.combine(symmetric_func));
            }
        }
        // Public API entries for parallel_accumulate

        /// <summary>
        ///     This template function is applying an associative operator to each element of a collection
        ///     and returns the final accumulated value.
        /// </summary>
        /// <param name="first">
        ///     First element to be included in parallel iteration.
        /// </param>
        /// <param name="last">
        ///     Last element to be included in parallel iteration.
        /// </param>
        /// <param name="initial_value">
        ///     Initial value of the accumulator.
        /// </param>
        /// <param name="symmetric_func">
        ///     Binary function object to be executed on each iteration, acception arguments of the same type.
        /// </param>
        /// <returns>
        ///     An accumulated value of all elements in the collection.
        /// </returns>
        /// <remarks>
        ///     The template argument input_iterator must contain a value of the same type T as the passed in initial_value.
        ///     Furthermore, accumulation function used on the elements of this collection has the signature T _Func(T, T).
        ///     initial_value does not have to be an identity value for the type T.
        /// </remarks>
        template <typename input_iterator, typename symmetric_function>
        typename std::iterator_traits<input_iterator>::value_type parallel_accumulate(input_iterator first, input_iterator last,
            typename std::iterator_traits<input_iterator>::value_type initial_value, symmetric_function symmetric_func)
        {
            return parallel_accumulate_impl(first, last, initial_value, symmetric_func, symmetric_func, std::_Iter_cat(first));
        }

        /// <summary>
        ///     This template function is applying an associative operator to each element of a collection
        ///     and returns the final accumulated value.
        /// </summary>
        /// <param name="first">
        ///     First element to be included in parallel iteration.
        /// </param>
        /// <param name="last">
        ///     Last element to be included in parallel iteration.
        /// </param>
        /// <param name="initial_value">
        ///     Initial value of the accumulator.
        /// </param>
        /// <param name="symmetric_func">
        ///     Binary function object to be executed on each iteration, acception arguments of the same type.
        /// </param>
        /// <returns>
        ///     An accumulated value of all elements in the collection.
        /// </returns>
        /// <remarks>
        ///     The template argument input_iterator does not necessarily contain a value of the same type accumulation_type,
        ///     like the passed in initial_value. Furthermore, there are two accumulation function used:
        ///         a) First is used to accumulate temporary results into a final result and it has the following signature:
        ///              accumulation_type symmetric_func(accumulation_type, accumulation_type)
        ///         b) Second is used to accumulate values of each individual element onto the initial_value and it has this signature:
        ///              accumulation_type asymmetric_func(accumulation_type, T)
        ///     Because of the asymmetric function being applied on each subrange initial_value must be an identity value for the type accumulation_type.
        /// </remarks>
        template <typename input_iterator, typename accumulation_type, typename symmetric_function, typename asymmetric_function>
        accumulation_type parallel_accumulate(input_iterator first, input_iterator last,
            accumulation_type initial_value, symmetric_function symmetric_func, asymmetric_function asymmetric_func)
        {
            return details::parallel_accumulate_impl(first, last, initial_value, symmetric_func, asymmetric_func, std::_Iter_cat(first));
        }

        /// <summary>
        ///     This template function is applying an associative std::plus function to each element of a collection
        ///     and returns the final accumulated value.
        /// </summary>
        /// <param name="first">
        ///     First element to be included in parallel iteration.
        /// </param>
        /// <param name="last">
        ///     Last element to be included in parallel iteration.
        /// </param>
        /// <param name="initial_value">
        ///     Initial value of the accumulator.
        /// </param>
        /// <returns>
        ///     An accumulated value of all elements in the collection.
        /// </returns>
        /// <remarks>
        ///     The template argument input_iterator must contain a value of the same type T as the passed in initial_value.
        ///     Furthermore, accumulation function used on the elements of this collection has the signature T std::plus<T>(T, T).
        ///     initial_value does not have to be an identity value for the type T.
        /// </remarks>
        template <typename input_iterator>
        typename std::iterator_traits<input_iterator>::value_type parallel_accumulate(input_iterator first, input_iterator last,
            typename std::iterator_traits<input_iterator>::value_type initial_value)
        {
            auto functor = std::plus<typename std::iterator_traits<input_iterator>::value_type>();

            return details::parallel_accumulate_impl(first, last, initial_value, functor, functor, std::_Iter_cat(first));
        }
        namespace details
        {
            template <typename forward_iterator, typename iterator_kind>
            class iterator_helper
            {
            public:
                static const unsigned int size = 1024;
                typedef typename std::iterator_traits<forward_iterator>::value_type value_type;

                iterator_helper()
                {
                }

                unsigned int populate(forward_iterator& first, const forward_iterator& last) const
                {
                    unsigned int length = 0;

                    // Add a batch of work items to this functor's array
                    for (unsigned int index=0; (index < size) && (first != last); index++)
                    {
                        m_element_array[length++] = &(*first++);
                    }

                    return length;
                }

                void populate(forward_iterator& first, unsigned int length) const
                {
                    for (unsigned int index=0; index < length; index++)
                    {
                        m_element_array[index] = &(*first++);
                    }
                }

                void store(const value_type& elem, unsigned int index) const
                {
                    *(m_element_array[index]) = elem;
                }

                value_type& load(unsigned int index) const
                {
                    return *(m_element_array[index]);
                }

            private:
                mutable value_type * m_element_array[size];
            };

            template <typename random_iterator>
            class iterator_helper<random_iterator, std::random_access_iterator_tag>
            {
            public:
                static const unsigned int size = 1024;
                typedef typename std::iterator_traits<random_iterator>::value_type value_type;

                iterator_helper()
                {
                }

                unsigned int populate(random_iterator& first, const random_iterator& last) const
                {
                    std::iterator_traits<random_iterator>::difference_type range = last - first;
                    std::iterator_traits<random_iterator>::difference_type sized = size;
                    m_first = first;

                    if (range > sized)
                    {
                        first += size;
                        return size;
                    }
                    else
                    {
                        first += range;
                        return (unsigned int) range;
                    }
                }

                void populate(random_iterator& first, unsigned int length) const
                {
                    m_first = first;
                    first += length;
                }

                void store(const value_type& elem, unsigned int index) const
                {
                    m_first[index] = elem;
                }

                value_type& load(unsigned int index) const
                {
                    return m_first[index];
                }

            private:
                mutable random_iterator m_first;
            };

            template <typename input_iterator1, typename input_iterator2, typename output_iterator, typename binary_operator>
            class parallel_transform_binary_helper
            {
            public:
                parallel_transform_binary_helper(input_iterator1& first1, const input_iterator1& last1, input_iterator2& first2, output_iterator& result, const binary_operator& binary_op) :
                  m_binary_op(binary_op), m_len(0)
                  {
                      m_len = m_input_helper1.populate(first1, last1);
                      m_input_helper2.populate(first2, m_len);
                      m_output_helper.populate(result, m_len);
                  }

                  void operator()() const
                  {
                      // Invoke parallel_for on the batched up array of elements
                      Concurrency::_Parallel_for_impl(0U, m_len, 1U,
                          [this] (unsigned int index)
                      {
                          m_output_helper.store(m_binary_op(m_input_helper1.load(index), m_input_helper2.load(index)), index);
                      }
                      );
                  }

            private:

                iterator_helper<input_iterator1, typename std::iterator_traits<input_iterator1>::iterator_category>   m_input_helper1;
                iterator_helper<input_iterator2, typename std::iterator_traits<input_iterator2>::iterator_category>   m_input_helper2;
                iterator_helper<output_iterator, typename std::iterator_traits<output_iterator>::iterator_category>   m_output_helper;
                const binary_operator&                                                                                m_binary_op;
                unsigned int                                                                                          m_len;

                parallel_transform_binary_helper const & operator=(parallel_transform_binary_helper const&);    // no assignment operator
            };

            template <typename input_iterator1, typename input_iterator2, typename output_iterator, typename binary_operator>
            void parallel_transform_binary_impl(input_iterator1& first1, const input_iterator1& last1, input_iterator2& first2, output_iterator& result,
                const binary_operator& binary_op, task_group& tg)
            {
                // This functor will be copied on the heap and will execute the chunk in parallel
                {
                    parallel_transform_binary_helper<input_iterator1, input_iterator2, output_iterator, binary_operator> functor(first1, last1, first2, result, binary_op);
                    tg.run(functor);
                }

                // If there is a tail, push the tail
                if (first1 != last1)
                {
                    tg.run(
                        [&first1, &last1, &first2, &result, &binary_op, &tg]
                    {
                        Concurrency::samples::details::parallel_transform_binary_impl(first1, last1, first2, result, binary_op, tg);
                    }
                    );
                }
            }

            template <typename input_iterator, typename output_iterator, typename unary_operator>
            class parallel_transform_unary_helper
            {
            public:
                parallel_transform_unary_helper(input_iterator& first, const input_iterator& last, output_iterator& result, const unary_operator& unary_op) :
                  m_unary_op(unary_op), m_len(0)
                  {
                      m_len = m_input_helper.populate(first, last);
                      m_output_helper.populate(result, m_len);
                  }

                  void operator()() const
                  {
                      // Invoke parallel_for on the batched up array of elements
                      Concurrency::_Parallel_for_impl(0U, m_len, 1U,
                          [this] (unsigned int index)
                      {
                          m_output_helper.store(m_unary_op(m_input_helper.load(index)), index);
                      }
                      );
                  }

            private:

                const iterator_helper<input_iterator, typename std::iterator_traits<input_iterator>::iterator_category>   m_input_helper;
                const iterator_helper<output_iterator, typename std::iterator_traits<output_iterator>::iterator_category> m_output_helper;
                const unary_operator&                                                                                     m_unary_op;
                unsigned int                                                                                              m_len;

                parallel_transform_unary_helper const & operator=(parallel_transform_unary_helper const&);    // no assignment operator
            };

            template <typename input_iterator, typename output_iterator, typename unary_operator>
            void parallel_transform_unary_impl(input_iterator& first, const input_iterator& last, output_iterator& result, const unary_operator& unary_op, task_group& tg)
            {
                // This functor will be copied on the heap and will execute the chunk in parallel
                {
                    parallel_transform_unary_helper<input_iterator, output_iterator, unary_operator> functor(first, last, result, unary_op);
                    tg.run(functor);
                }

                // If there is a tail, push the tail
                if (first != last)
                {
                    tg.run(
                        [&first, &last, &result, &unary_op, &tg]
                    {
                        Concurrency::samples::details::parallel_transform_unary_impl(first, last, result, unary_op, tg);
                    }
                    );
                }
            }
        }
        /// <summary>
        ///     This template function is semantically equivalent to std::transform, except that
        ///     the iteration is done in parallel and ordering is unspecified. The function argument
        ///     func must support operator()(T) where T is the item type of the container being
        ///     iterated over.
        /// </summary>
        /// <param name="first">
        ///     First element to be included in parallel iteration.
        /// </param>
        /// <param name="last">
        ///     First element after first not to be included in parallel iteration.
        /// </param>
        /// <param name="result">
        ///     First element to store the result of a parallel iteration.
        /// </param>
        /// <param name="unary_op">
        ///     Function object to be executed on each iteration, a unary operator.
        /// </param>
        /// <returns>
        ///     Result of a parallel_transform operation, equivalent to the result from std::transform.
        /// </returns>
        /// <remarks>
        ///     For more information, see <see cref="Parallel Algorithms"/>.
        /// </remarks>
        template <typename input_iterator, typename output_iterator, typename unary_operator>
        output_iterator parallel_transform(input_iterator first, input_iterator last, output_iterator result, const unary_operator& unary_op)
        {
            if (first != last)
            {
                task_group tg;

                details::parallel_transform_unary_impl(first, last, result, unary_op, tg);

                tg.wait();
            }

            return result;
        }

        /// <summary>
        ///     This template function is semantically equivalent to std::transform, except that
        ///     the iteration is done in parallel and ordering is unspecified. The function argument
        ///     func must support operator()(T) where T is the item type of the container being
        ///     iterated over.
        /// </summary>
        /// <param name="first">
        ///     First element to be included in parallel iteration.
        /// </param>
        /// <param name="last">
        ///     First element after first not to be included in parallel iteration.
        /// </param>
        /// <param name="first2">
        ///     First element of the second argument to a binary operator to be included in parallel iteration.
        /// </param>
        /// <param name="result">
        ///     First element to store the result of a parallel iteration.
        /// </param>
        /// <param name="binary_op">
        ///     Function object to be executed on each iteration, a unary operator.
        /// </param>
        /// <returns>
        ///     Result of a parallel_transform operation, equivalent to the result from std::transform.
        /// </returns>
        /// <remarks>
        ///     For more information, see <see cref="Parallel Algorithms"/>.
        /// </remarks>
        template <typename input_iterator1, typename input_iterator2, typename output_iterator, typename binary_operator>
        output_iterator parallel_transform(input_iterator1 first1, input_iterator1 last1, input_iterator2 first2, output_iterator result, const binary_operator& binary_op)
        {
            if (first1 != last1)
            {
                task_group tg;

                details::parallel_transform_binary_impl(first1, last1, first2, result, binary_op, tg);

                tg.wait();
            }

            return result;
        }
        namespace details
        {
        /// <summary>
        ///     An implementation of parallel partial sum that splits the work into smallest possible chunks
        ///     using recursion. This is efficient when the binary operation is dependent on the values as work
        ///     stealing would provide automatic load balancing
        /// </summary>
        /// <param name="out_randomIterator">
        ///     Type of the iterator to the container that will hold the output values
        /// </param>
        /// <param name="size_type">
        ///     Type of the size of the container
        /// </param>
        /// <param name="BinaryOperator">
        ///     The binary operator that computes the sum of two values
        /// </param>
        template <typename out_randomIterator, typename size_type, typename BinaryOperator>
        void parallel_partial_sum_impl_recursive(out_randomIterator begin, size_type size, size_type skip, BinaryOperator sumFunction)
        {
            if (size <= 1)
            {
                return;
            }

            size_type halfLength = size / 2;

            // pairwise combine
            parallel_for<size_t>(0, halfLength, [begin, skip, sumFunction](size_type index)
            {
                out_randomIterator loc = begin + (index * 2 * skip);
                *(loc + skip) = sumFunction(*loc, *(loc + skip));
            });

            // Recursively prefix scan the pairwise computations
            parallel_partial_sum_impl_recursive(begin + skip, halfLength, skip*2, sumFunction);

            // Pairwise combine
            parallel_for<size_t>(0, (size % 2 == 0) ? halfLength - 1 : halfLength, [begin, skip, sumFunction](size_type index)
            {
                out_randomIterator loc = begin + (index * 2 * skip) + skip;
                *(loc + skip) = sumFunction(*loc, *(loc + skip));
            });
        }

        /// <summary>
        ///     An implementation of parallel partial sum that splits the work into fixed chunks.
        ///     This is efficient when the binary operation is relatively fast and independent of the values.
        /// </summary>
        /// <param name="input_iterator">
        ///     Type of the iterator to the container that holds the input values
        /// </param>
        /// <param name="out_randomIterator">
        ///     Type of the iterator to the container that will hold the output values
        /// </param>
        /// <param name="BinaryOperator">
        ///     The binary operator that computes the sum of two values
        /// </param>
        template <typename in_randomIterator, typename out_randomIterator, typename BinaryOperator>
        void parallel_partial_sum_impl(in_randomIterator begin, in_randomIterator end, out_randomIterator result, BinaryOperator sumFunction)
        {
            typedef typename std::iterator_traits<out_randomIterator>::value_type value_type;
            typedef std::iterator_traits<in_randomIterator>::difference_type size_type;

            // We will use the number of virtual processors to compute the number of chunks
            const int oversubscription = 2;
            size_type numChunks = static_cast<size_type>(CurrentScheduler::Get()->GetNumberOfVirtualProcessors() * oversubscription);
            size_type size = end - begin;

            if (size < numChunks)
            {
                // Not enough iterations to warrant parallel computation
                std::partial_sum(begin, end, result, sumFunction);            
                return;
            }

            std::vector<value_type> tempSum(numChunks);

            // Determine the range for each chunk
            size_type chunkSize = size / numChunks;
            _ASSERTE(chunkSize >= 1);

            parallel_for(size_type(0), numChunks, [begin, end, result, sumFunction, chunkSize, numChunks, &tempSum](size_type index)
            {
                // Compute partial sum for this chunk.

                in_randomIterator start = begin + (index * chunkSize);
                in_randomIterator last = (index == (numChunks - 1)) ? end : start + chunkSize;

                out_randomIterator resultStart = result + (index * chunkSize);
                out_randomIterator resultEnd = resultStart + (last - start);

                std::partial_sum(start, last, resultStart, sumFunction);

                // Store the upper bounds into intermediate buffer.
                tempSum[index] = *(resultEnd-1);
            });

            // Compute partial sum on the intermediate buffer
            std::partial_sum(tempSum.begin(), tempSum.end(), tempSum.begin(), sumFunction);

            // The first chunk is already correct. For the other chunks propagate the partial
            // sum from the intermediate buffer
            parallel_for(size_type(1), numChunks, [begin, end, result, sumFunction, chunkSize, numChunks, tempSum](size_type index)
            {
                // Add the partial sum from the previous chunk to all the
                // elements in this chunk
                in_randomIterator start = begin + (index * chunkSize);
                in_randomIterator last = (index == (numChunks - 1)) ? end : start + chunkSize;

                out_randomIterator resultStart = result + (index * chunkSize);
                out_randomIterator resultEnd = resultStart + (last - start);

                for (out_randomIterator iter = resultStart; iter < resultEnd; ++iter)
                {
                    *iter = sumFunction(*iter, tempSum[index-1]);
                }
            });
        }
        }
        /// <summary>
        ///     Compute inclusive partial sum
        /// </summary>
        /// <param name="in_randomIterator">
        ///     Type of the iterator to the container that holds the input values
        /// </param>
        /// <param name="out_randomIterator">
        ///     Type of the iterator to the container that will hold the output values
        /// </param>
        /// <param name="BinaryOperator">
        ///     The binary operator that computes the sum of two values
        /// </param>
        template <typename in_randomIterator, typename out_randomIterator, typename BinaryOperator>
        void parallel_partial_sum_fixed(in_randomIterator begin, in_randomIterator end, out_randomIterator result, BinaryOperator sumFunction)
        {
            return details::parallel_partial_sum_impl(begin, end, result, sumFunction);
        }

        /// <summary>
        ///     Compute inclusive partial sum
        /// </summary>
        /// <param name="in_randomIterator">
        ///     Type of the iterator to the container that holds the input values
        /// </param>
        /// <param name="out_randomIterator">
        ///     Type of the iterator to the container that will hold the output values
        /// </param>
        /// <param name="BinaryOperator">
        ///     The binary operator that computes the sum of two values
        /// </param>
        template <typename in_randomIterator, typename out_randomIterator, typename BinaryOperator>
        void parallel_partial_sum(in_randomIterator begin, in_randomIterator end, out_randomIterator result, BinaryOperator sumFunction)
        {
            typedef std::iterator_traits<in_randomIterator>::difference_type size_type;

            // Copy input to output first
            out_randomIterator out = result;
            for (in_randomIterator in = begin; in < end; ++in)
            {
                *out = *in;
                ++out;                
            }

            // Perform in place partial sum
            return details::parallel_partial_sum_impl_recursive(result, (end-begin), size_type(1), sumFunction);
        }

        /// <summary>
        ///     Compute inclusive partial sum. This overload performs the operation in place.
        /// </summary>
        /// <param name="in_randomIterator">
        ///     Type of the iterator to the container that holds the input values
        /// </param>
        /// <param name="BinaryOperator">
        ///     The binary operator that computes the sum of two values
        /// </param>
        template <typename in_randomIterator, typename BinaryOperator>
        void parallel_partial_sum(in_randomIterator begin, in_randomIterator end, BinaryOperator sumFunction)
        {
            typedef std::iterator_traits<in_randomIterator>::difference_type size_type;
            return details::parallel_partial_sum_impl_recursive(begin, (end-begin), size_type(1), sumFunction);
        }
        /// <summary>
        ///  merge two sorted sequences in parallel
        /// </summary>
        /// <param name="ran_it">
        ///     Type of the iterator to the container that holds the input values
        /// </param>
        /// <param name="out_it">
        ///     Type of the iterator to the container that holds the output values
        /// </param>
        template<typename ran_it, typename out_it>
        inline void parallel_merge(ran_it first1, ran_it last1, ran_it first2, ran_it last2, out_it out)
        {
            int sequence1Length = last1 - first1;
            int sequence2Length = last2 - first2;

            if (min(sequence2Length, sequence1Length ) < 512)
            {
                std::merge( first1, last1, first2, last2, out);
                return;
            }

            if( sequence1Length < sequence2Length )
            {
                std::swap(first1, first2);
                std::swap(last1, last2);
            }

            ran_it mid1 = first1 + (last1-first1)/2;

            ran_it m2 = std::lower_bound( first2, last2, *mid1 );

            structured_task_group tasks;

            auto t = make_task([&](){parallel_merge(first1, mid1, first2, m2, out);});
            tasks.run(t);

            out_it out_right = out;
            out_right += (mid1 - first1) + (m2 - first2);

            tasks.run_and_wait([&](){parallel_merge(mid1, last1, m2, last2, out_right );});
        }

        namespace details
        {
            //helper class for parallel merge sort that uses either std::inplace_merge
            //or parallel merge with the concrt suballocator
            template <bool use_suballocator>
            class merge_sort_helper
            {
            public:
                template <typename ran_it>
                void operator ()(ran_it& first, ran_it& mid, ran_it& last) const
                {
                    std::inplace_merge(first, mid, last);
                }
            };
            template <>
            class merge_sort_helper<true>
            {
            public:
                template <typename ran_it>
                void operator ()(ran_it& first, ran_it& mid, ran_it& last) const
                {
                    typedef typename std::iterator_traits<ran_it>::value_type item_type;;
                    std::vector<item_type, concrt_suballocator<item_type>> out(last-first);

                    parallel_merge(first, mid, mid, last, out.begin());
                    std::copy (out.begin(), out.end(), first);
                }
            };

            /// <summary>
            ///     An implementation of parallel sort that performs N * 2 sorts in parallel recursively
            ///     then merges them in parallel where N is the number of processors (rounded up to the 
            ///     next power of 2). 
            /// </summary>
            /// <param name="ran_it">
            ///     Type of the iterator to the container that will hold the output values
            /// </param>
            template <typename ran_it>
            inline void parallel_sort_impl(ran_it& first, ran_it& last, size_t depth)
            {
                size_t num_items;

                if (depth == 1 || (num_items = last - first) < 512)
                {
                    std::sort(first, last);
                    return;
                }

                auto half_count = num_items / 2;
                auto mid = first + half_count;

                parallel_invoke([&, depth]() {parallel_sort_impl(mid,  last, depth - 1);},
                    [&, depth]() {parallel_sort_impl(first, mid, depth - 1);});

                typedef typename std::iterator_traits<ran_it>::value_type item_type;;

                //switch merge types based on the size of items; the sub allocator 
                //only helps with small items.
                merge_sort_helper<sizeof(item_type) <= 16 >()(first, mid, last);
            }
        }
        /// <summary>
        ///     sort a sequence, potentially in parallel. This overload performs the operation in place.
        /// </summary>
        /// <param name="ran_it">
        ///     Type of the iterator to the container that holds the input values
        /// </param>
        template <typename ran_it>
        inline void parallel_sort(ran_it& first, ran_it& last)
        {
            size_t depth = (size_t) log((float)GetProcessorCount()) + 1;
            return details::parallel_sort_impl(first, last, depth);
        }
    } // namespace samples
} // namespace Concurrency