//--------------------------------------------------------------------------
// 
//  Copyright (c) Microsoft Corporation.  All rights reserved. 
// 
//  File: main.cpp
//
//
//--------------------------------------------------------------------------
#include "stdafx.h"
//sets the size of a set of bodies to process when using the fastpar method 

int WINAPI WinMain(
    HINSTANCE /*hInstance*/,
    HINSTANCE /*hPrevInstance*/,
    LPSTR /*lpCmdLine*/,
    int /*nCmdShow*/
    )
{ 
    srand(42);

    size_t numParticles = 2000;

    model_agent         model;
    view_agent          view ("nbodies d2d demo", 800, 600);
    controller_agent    controller;

    //connect the controller to the view
    send(&controller.view_buffer, &view);

    //connect the controller to the model
    send(&controller.model_buffer, &model);

    //tell the controller how many particles to start with
    send(&controller.particles_buffer, numParticles);

    //start them all
    model.start();
    view.start();
    controller.start();

    agent::wait(&controller);
    agent::wait(&model);
    
    return 0;
}