//--------------------------------------------------------------------------
// 
//  Copyright (c) Microsoft Corporation.  All rights reserved. 
// 
//  File: stdafx.h
//
//
//--------------------------------------------------------------------------
#pragma once
#undef UNICODE
#include <windows.h>
#include <d2d1.h>

#include <memory>
#include <math.h>
#include <algorithm>
#include <numeric>
#include <vector>

#include "vector.h"
#include "winwrap.h"
#include "vector.h"
#include "controller_agent.h"
#include "model_agent.h"
#include "view_agent.h"

using namespace winwrap;
using namespace ::ray_lib;
using namespace ::std;
using namespace Concurrency::samples;

