
Structured Grid Dwarf (parallel patern).
See http://view.eecs.berkeley.edu/wiki/Main_Page for more information.


       .\				-Root folder 
        |
        +---Bin				-all dwarf execs, dlls, start wrapper bats 
        |   |
        |   +-Env			-batch/xml config files
        |   |
        |   +-Input			-stores input files (e.g. Small/Madium/LargeMatrix.txt)
        |   |
        |   \-Output			-stores output
        |      
        +---Components			-3rd party libraries
        |      
        +---Doc				-documentation 
        |
        \---Src				-source folder
            |
            +-Dwarf.Managed.Mpi		-sources for managed mpi kerner
            | 
            +-Dwarf.Managed.Serial	-sources for managed serial kerner
            | 
            +-Dwarf.Managed.Tpl		-sources for managed tpl kerner
            | 
            +-Dwarf.Managed.Hybrid	-sources for managed hybrid kerner
            |
            +-Dwarf.Unmanaged.Mpi	-sources for unmanaged mpi kerner
            | 
            +-Dwarf.Unmanaged.Omp	-sources for unmanaged omp kerner
            | 
            +-Dwarf.Unmanaged.Serial	-sources for unmanaged serial kerner
            |
            \-Dwarf.Unmanaged.Hybrid	-sources for unmanaged hybrid kerner


To start a demo it is necessary 
1. make sure that on Your box installed 
	.NET Framework 3.5
	Microsoft Parallel Extensions to .NET Framework 3.5
	MPI.NET Runtime
	Microsoft Compute Cluster Pack SDK
2. to compile sources from Visual Studio 
3. to put down variables in ./Bin/Env/setenv.bat file
4. to run needed batch file from ./Bin directory



