﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management.Automation;
using System.Management;

namespace pshcli
{
    [Cmdlet(VerbsCommon.Get,"Dwarfs")]
    public class PSH_GetDwarf: Cmdlet
    {
        private string dwarfhomedir;
        private string configxmlfile;

        //private Object[] filternames;
        //private Object[] filtersizes;
        //private Object[] filterplatform;
        //private Object[] filterparallel;

        private int threadcount = 0;
        private int mpinumcount = 0;



        #region PARAMETERS

        [Parameter(
            Mandatory = false, 
            Position=0,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Dwarfs home directory.")]
        public string Dir
        {
            get { return dwarfhomedir; }
            set { dwarfhomedir = value; }
        }

        [Parameter(
            Mandatory = false,
            Position=1,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Config file name. Default: dwarfconfig.xml")]
        public string ConfigFile
        {
            get { return configxmlfile; }
            set { configxmlfile = value; }
        }

        [Parameter(
            Mandatory = false,
            Position = 2,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "Thread count.")]
        public int ThreadCount
        {
            get { return threadcount; }
            set { threadcount = value; }
        }


        [Parameter(
            Mandatory = false,
            Position = 3,
            ValueFromPipelineByPropertyName = true,
            HelpMessage = "MPI proc count.")]
        public int MpiProcCount
        {
            get { return mpinumcount; }
            set { mpinumcount = value; }
        }

        #endregion


        protected override void BeginProcessing()
        {
            base.BeginProcessing();
        }

        
        //Process pipeline input
        protected override void ProcessRecord()
        {

        }




        protected override void EndProcessing()
        {

            //Ceck for dir
            if (String.IsNullOrEmpty(this.dwarfhomedir))
            {
                this.WriteVerbose("GET-DWARF: Dwarfs home directory not specified. Trying ENV:DWARF_DIR...");
                this.Dir = System.Environment.GetEnvironmentVariable("DWARF_DIR");
                if (String.IsNullOrEmpty(this.dwarfhomedir))
                    throw new Exception("GET-DWARF-ERROR: Dwarfs home directory could not be retrieved.");
            }

            //Check for config file
            if (String.IsNullOrEmpty(this.configxmlfile))
            {
                string defaultconfigfile = this.dwarfhomedir + "dwarfconfig.xml";
                this.WriteVerbose("GET-DWARF-ERROR: Config file not specified. Setting to default (" + defaultconfigfile + ").");
                this.configxmlfile = defaultconfigfile;
            }

            this.WriteVerbose("GET-DWARF: Dwarf config (xml) file name: " + this.configxmlfile);
            this.WriteVerbose("GET-DWARF: parameter input: " + this.configxmlfile);



            //Get dwarfs objects
            HelperMethods helper = new HelperMethods();
            List<Dwarf> dwarflist = helper.GetDwarfs2(this.dwarfhomedir, this.configxmlfile, mpinumcount, threadcount);

            this.WriteVerbose("GET-DWARF: " + dwarflist.ToArray().Length + " execution objects configured.");

            string scheduler = "";

            bool mpitracing = false;
            bool xperftracing = false;

            foreach (Dwarf dwarf in dwarflist)
            {
                if (threadcount > 0)
                    dwarf.numthreads = threadcount;
                else
                    threadcount = dwarf.numthreads;


                if (mpinumcount == 0 && dwarf.numprocs != 0)
                    mpinumcount = dwarf.numprocs;

                if (dwarf.mpitrace)
                    mpitracing = true;
                if (dwarf.xperftrace)
                    xperftracing = true;

                scheduler = dwarf.scheduler;

                //internal filter no longer needed, filtered by DwarfBench.ps1
                //if(PassFilter(dwarf))
                //    this.WriteObject(dwarf);
                this.WriteObject(dwarf);
            }

            Console.WriteLine("Dir: " + this.Dir);
            Console.WriteLine("Conifiguration file: " + this.ConfigFile);
            Console.WriteLine("Num of threads: " + threadcount);
            Console.WriteLine("Num of MPI processes: " + mpinumcount);
            if (String.IsNullOrEmpty(scheduler))
                Console.WriteLine("No scheduler specified, executing locally.");
            else
                Console.WriteLine("Scheduler: " + scheduler);
            Console.WriteLine("Xperf tracing enabled: " + xperftracing.ToString());
            Console.WriteLine("Mpi tracing enabled: " + mpitracing.ToString());
        }




        protected override void StopProcessing()
        {
            base.BeginProcessing();
        }


        //private bool PassFilter(Dwarf dwarf)
        //{
        //    bool isvalue = false;

        //    if (filternames != null)
        //    {
        //        isvalue = false;
        //        foreach (string name in filternames)
        //        {
        //            if (dwarf.dwarfname.Equals(name))
        //                isvalue = true;
        //        }
        //        if(!isvalue)
        //            return false;
        //    }

        //    if (filterplatform != null)
        //    {
        //        isvalue = false;
        //        foreach (string platform in filterplatform)
        //        {
        //            if (dwarf.platform.ToString().Equals(platform))
        //                isvalue = true;
        //        }
        //        if (!isvalue)
        //            return false;
        //    }

        //    if (filterparallel != null)
        //    {
        //        isvalue = false;
        //        foreach (string parallel in filterparallel)
        //        {
        //            if (dwarf.parallel.ToString().Equals(parallel))
        //                isvalue = true;
        //        }
        //        if (!isvalue)
        //            return false;
        //    }

        //    if (filtersizes != null)
        //    {
        //        isvalue = false;
        //        foreach (string size in filtersizes)
        //        {
        //            if (dwarf.size.ToString().Equals(size))
        //                isvalue = true;
        //        }
        //        if (!isvalue)
        //            return false;
        //    }

        //    return true;
        //}

    }

    [Cmdlet("TEST", "TEST")]
    public class test : Cmdlet
    {

        Object obj;
        [Parameter(
            Position = 0,
            ValueFromPipeline = true,
            Mandatory = false,
            HelpMessage = "Dwarf object to be executed")]
        public Object DataArray
        {
            get { return obj; }
            set { obj = value; }
        }

        protected override void ProcessRecord()
        {
            //Object[] obj1 = (Object[])obj;
            this.WriteObject("Obj type" + obj.GetType().ToString());
            //this.WriteObject("Obj type" + obj1.Length);
            
        }
    }
}
