﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Management.Automation;

namespace pshcli
{
    [RunInstaller(true)]
    public class pshinstaller : PSSnapIn
    {
        public override string Name
        {
            get { return "DwarfPsh"; }
        }

        public override string Vendor
        {
            get { return "Parallel dwarfs project."; }
        }

        public override string Description
        {
            get { return "DwarfBench cmdlets"; }
        }
    }
}
