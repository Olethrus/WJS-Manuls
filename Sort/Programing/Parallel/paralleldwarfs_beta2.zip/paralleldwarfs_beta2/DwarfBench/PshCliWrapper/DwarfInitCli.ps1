﻿# Author: Matej Ciesko
# DwarfShell startup script
"Test" >> "$env:DWARF_DIR\Logs\SetupLog_LoadCmdLet.txt"
"Loading DwarfBench commandlet. Please make sure DwarfBench is build and the file pshcli.dll is located in %DWARF_DIR%\DwarfBench\PshCliWrapper\." >> "$env:DWARF_DIR\Logs\SetupLog_LoadCmdLet.txt"
write-output "" >> "$env:DWARF_DIR\Logs\SetupLog_LoadCmdLet.txt"
write-output "" >> "$env:DWARF_DIR\Logs\SetupLog_LoadCmdLet.txt"

$tmpdir = $env:DWARF_PSH_DIR #..\DwarfDemo\PshCliWrapper


if ($env:PROCESSOR_ARCHITECTURE -eq "x86") {
    $installer = "$env:windir/Microsoft.NET/Framework/v2.0.50727/InstallUtil.exe"
} else {
    $installer = "$env:windir/Microsoft.NET/Framework64/v2.0.50727/InstallUtil.exe"
}

if ([string]::isnullorempty($env:inetroot)) {
    Set-Content Env:INETROOT $tmpdir
}

&$installer "$env:inetroot/pshcli.dll" >> "$env:DWARF_DIR\Logs\SetupLog_LoadCmdLet.txt"

Add-PSSnapin DwarfPsh >> "$env:DWARF_DIR\Logs\SetupLog_LoadCmdLet.txt"
cd "$env:DWARF_DIR\DwarfBench"

write-output "Loading completed." >> "$env:DWARF_DIR\Logs\SetupLog_LoadCmdLet.txt"

Write-Host ""
Write-Host "DwarfShell loaded successfully! To get started type Exec-Dwarfs -help."
Write-Host ""

