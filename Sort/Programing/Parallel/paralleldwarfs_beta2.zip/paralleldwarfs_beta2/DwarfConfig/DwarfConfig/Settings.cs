﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using System.IO;

namespace DwarfConfig
{
    class Settings
    {
        public bool LogOnly = true;
        public string Log = "";
        public string ActiveConfiguration = "";
        public string ActivePlatform = "";
#region unmanaged
        public string OutputDirectory = "";
        public string CommandArguments = "";
        public string AdditionalIncludeDirectories = "";
        public string AdditionalLibraryDirectories = "";
        public string AdditionalDependencies = "";
        public string Detect64BitPortabilityProblems = "";
        public string FavorSizeOrSpeed = "";
        public string FloatingPointExceptions = "";
        public string Optimization = "";
        public string WholeProgramOptimization = "";
        public string DebugInformationFormat = "";
        public string BasicRuntimeChecks = "";
        public string WarningLevel = "";
#endregion
#region managed
        public string OutputPath = "";
        public string DefineConstants = "";
        public string StartArguments = "";
        public string DocumentationFile = "";
        public string Optimize = "True";
#endregion

#region xpaths
        string xLog = "/DwarfConfig/VSconfig/LogOnly";
        string xActConfig = "/DwarfConfig/VSconfig/ActiveConfiguration";
        string xActPlatform = "/DwarfConfig/VSconfig/ActivePlatform";

        string xOutputDirectory = "/DwarfConfig/VSconfig/Unmanaged/OutputDirectory";
        string xCommandArguments = "/DwarfConfig/VSconfig/Unmanaged/CommandArguments";
        string xAdditionalIncludeDirectories = "/DwarfConfig/VSconfig/Unmanaged/AdditionalIncludeDirectories";
        string xAdditionalLibraryDirectories = "/DwarfConfig/VSconfig/Unmanaged/AdditionalLibraryDirectories";
        string xAdditionalDependencies = "/DwarfConfig/VSconfig/Unmanaged/AdditionalDependencies";
        string xDetect64BitPortabilityProblems = "/DwarfConfig/VSconfig/Unmanaged/Detect64BitPortabilityProblems";
        string xFavorSizeOrSpeed = "/DwarfConfig/VSconfig/Unmanaged/FavorSizeOrSpeed";
        string xFloatingPointExceptions = "/DwarfConfig/VSconfig/Unmanaged/FloatingPointExceptions";
        string xOptimization = "/DwarfConfig/VSconfig/Unmanaged/Optimization";
        string xWholeProgramOptimization = "/DwarfConfig/VSconfig/Unmanaged/WholeProgramOptimization";
        string xDebugInformationFormat = "/DwarfConfig/VSconfig/Unmanaged/DebugInformationFormat";
        string xBasicRuntimeChecks = "/DwarfConfig/VSconfig/Unmanaged/BasicRuntimeChecks";
        string xWarningLevel = "/DwarfConfig/VSconfig/Unmanaged/WarningLevel";

        string xOutputPath = "/DwarfConfig/VSconfig/Managed/OutputPath";
        string xDefineConstants = "/DwarfConfig/VSconfig/Managed/DefineConstants";
        string xStartArguments = "/DwarfConfig/VSconfig/Managed/StartArguments";
        string xDocumentationFile = "/DwarfConfig/VSconfig/Managed/DocumentationFile";
#endregion 

      public string ReadXmlConfig(string filename)
        {
            //Try to read parameters from xml file
            XmlDocument config = new XmlDocument();
            try
            {
                config.Load(filename);
                XmlNode node = config.DocumentElement;

                Log = node.SelectSingleNode(xLog).InnerText;
                if (String.Compare(Log, "yes") == 0)
                    LogOnly = true;
                else if (String.Compare(Log, "no") == 0)
                    LogOnly = false;

                ActiveConfiguration = node.SelectSingleNode(xActConfig).InnerText;
                ActivePlatform = node.SelectSingleNode(xActPlatform).InnerText;

                OutputDirectory = node.SelectSingleNode(xOutputDirectory).InnerText;
                CommandArguments = node.SelectSingleNode(xCommandArguments).InnerText; 
                AdditionalIncludeDirectories = node.SelectSingleNode(xAdditionalIncludeDirectories).InnerText; 
                AdditionalLibraryDirectories = node.SelectSingleNode(xAdditionalLibraryDirectories).InnerText; 
                AdditionalDependencies = node.SelectSingleNode(xAdditionalDependencies).InnerText;
                Detect64BitPortabilityProblems = node.SelectSingleNode(xDetect64BitPortabilityProblems).InnerText;
                FavorSizeOrSpeed = node.SelectSingleNode(xFavorSizeOrSpeed).InnerText;
                FloatingPointExceptions = node.SelectSingleNode(xFloatingPointExceptions).InnerText;
                Optimization = node.SelectSingleNode(xOptimization).InnerText;
                WholeProgramOptimization = node.SelectSingleNode(xWholeProgramOptimization).InnerText;
                DebugInformationFormat = node.SelectSingleNode(xDebugInformationFormat).InnerText;
                BasicRuntimeChecks = node.SelectSingleNode(xBasicRuntimeChecks).InnerText;
                WarningLevel = node.SelectSingleNode(xWarningLevel).InnerText;

                OutputPath = node.SelectSingleNode(xOutputPath).InnerText;
                DefineConstants = node.SelectSingleNode(xDefineConstants).InnerText; 
                StartArguments = node.SelectSingleNode(xStartArguments).InnerText; 
                DocumentationFile = node.SelectSingleNode(xDocumentationFile).InnerText; 

            }
            catch (Exception e)
            {
                return e.Message;
            }

            return null;
        
        }
    }
}
