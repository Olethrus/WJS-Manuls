#pragma once

#include "targetver.h"
#include <stdio.h>
#include <windows.h>
#include <new>

#ifdef STRUCTUREDGRIDUNMANAGED_EXPORTS
#define STRUCTUREDGRIDUNMANAGED_API __declspec(dllexport)
#else
#define STRUCTUREDGRIDUNMANAGED_API __declspec(dllimport)
#endif