﻿using System;
using System.Runtime.InteropServices;

namespace Dwarf.Managed
{
    /// <summary>User interface for solving the Traveller Problem using 'BranchAndBound' algorithm</summary>
    ///
    class Program
    {
        /// <summary>Point of the program start</summary>
        /// <param name="args"></param>
        /// 
        static void Main(string[] args)
        {
            try
            {
                Configurator dwarfConfigurator = new Configurator(args, "BranchAndBound, managed mpi kernel");
                Solver branchAndBoundSolver = new Solver(ref dwarfConfigurator, ref args); // create new Solver (current problem with initial data)
                double time = 0;                                // initialize time variable
                start();                                        // start new time count                

                branchAndBoundSolver.Solve();                   // Solve the current problem
                stop(ref time);                                 // stop the time count 

                branchAndBoundSolver.Finish(time);              // write results
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                usage();                                        // incorrectness in Solver processing
            }
        }

        /// <summary>Start the time count</summary>
        /// 
        [DllImport(@"CliTools.dll")]
        private static extern void start();

        /// <summary>Stop the time count</summary>
        /// <param name="time">Value of the time</param>
        /// 
        [DllImport(@"CliTools.dll")]
        private static extern void stop(ref double time);

        /// <summary>Write the rules of command line structure</summary>
        /// 
        [DllImport(@"CliTools.dll")]
        private static extern void usage();

    }
}
