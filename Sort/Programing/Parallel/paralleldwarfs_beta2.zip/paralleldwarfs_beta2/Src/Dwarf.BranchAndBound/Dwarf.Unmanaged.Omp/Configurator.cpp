#include "Configurator.h"
#include <time.h>

Configurator::Configurator(int argc, char** argv, char* name)
{
	dwarfName = name;
    settings = new Settings();
	settings -> GetSettings(argc, argv);
	fopen_s(&profile, settings -> profileFile, "wb");
}

void Configurator :: WriteSettings()
{
    char* stringSettings = settings -> StringSettings();
	printf(stringSettings);
}

void Configurator :: AddNextChar(int &value, int source) // Convert char of input string to digit and add to 'value'
{
	value = value * 10 + ((int)source - (int)'0');	// digit transformation
}

int** Configurator :: GetData(int &cityCount)
{
	FILE *content;
	fopen_s(&content, settings -> inputFile, "rb");	// Opening the input file
	int ch = 0;
	ch = getc(content);
	cityCount = 0;
	while (feof(content) == 0 && ch != '\n')
	{
		if (!(ch == ' ' || ch == '\r'))
		{
			AddNextChar(cityCount, ch);
		}
		ch = getc(content);
	}
                
    int** distances = (int**) malloc (sizeof(int*)*cityCount);		// distance array (initial) creating and nulling
	for (int i = 0; i < cityCount; i++)
	{
		int* row = new int[cityCount];
		for (int j = 0; j < cityCount; j++)
		{
			row[j] = 0;								// zero (initial) value assignment
		}
		distances[i] = row;	// memory allotment for all rows
	}
    
	for (int i = 0; i < cityCount; i++)             // fill the array
    {
		int position = 0;                           // initialize the counter of tokens of current string  
		ch = getc(content);
		while ((feof(content) == 0) && (ch != '\n'))
		{
			if (ch == ' ')                 // condition of a new token start
			{
				position++;                         // change the array index
            }
			else if (ch == '\r') 
			{
				ch = getc(content);
				continue;
			}
			else
			{                              // convert from current token to int and put to the corresponding array cell
				if (ch == '-')             // edges where threre are no way (distance is equal to infinity)
                {
					distances[i][position] = infinity;
                }
				else
				{
					AddNextChar(distances[i][position], ch);
                }
            }
			ch = getc(content);
		}
	}
	for (int i = 0; i < cityCount; i++)             // for the exception cases (de bene esse) we override the distances from point to the same to be equal infinity
    {
		distances[i][i] = infinity;
	}
	fclose(content);
	return distances;
}

void Configurator :: Close(double time, int &cityCount, int *cities)
{
	printf("\nClock time   (sec): %.8f \r\n", time); 
	fprintf(profile, "#Dwarfname:%s\r\n", dwarfName);

	char tmpbuf[BUFFER_SIZE];
	_tzset();

	_strdate_s( tmpbuf, BUFFER_SIZE );
	fprintf(profile, "#Time: %s ", tmpbuf);

	_strtime_s( tmpbuf, BUFFER_SIZE );
	fprintf(profile, "%s \r\n", tmpbuf);

	fprintf(profile, "#Dimensions: 2\r\n");
	fprintf(profile, "#Matrix Size: %i\r\n", cityCount);
	fprintf(profile, "#Result time (sec): %.8f\r\n", time); 
	
	FILE *result;	
	fopen_s(&result, settings -> resultFile, "wb");
	for (int i = 0; i < cityCount; i++)
	{
		fprintf(result, "Edge: (%i;%i)\r\n", i, cities[i]);
	}
	fclose(result);
	fclose(profile);
}