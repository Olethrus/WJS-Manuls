#pragma once

#include "Settings.h"

class Configurator
{
public:
	Configurator(int argc, char** argv, char* name);
	int** GetData(int &cityCount);
	void WriteSettings();
	void Close(double time, int &cityCount, int *cities);

private:
	char *dwarfName;
	Settings* settings;
	FILE *profile;
	static const int infinity = 2147483647;
	void AddNextChar(int &value, int source);	
	static const int BUFFER_SIZE = 1024;
};
