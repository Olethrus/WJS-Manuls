// Dwarf.Unmanaged.OMP.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

static DLLUsage pDLLUsage;							// method 'usage' loaded from CliTools.dll
static DLLStart pDLLStart;							// method 'start' [time count] loaded from CliTools.dll
static DLLStop pDLLStop;							// method 'stop' [time count] loaded from CliTools.dll
static HINSTANCE hInstDll;							// instanse of CliTools.dll

void start();
void stop(double*);

void main(int argc, char** argv)
{
								//  Load the dll into the address space
	hInstDll = LoadLibraryA("CliTools.dll");
    if (hInstDll == 0) 
    {
        printf("Error while loading CliTools.dll.");
        return;
    }
								// Retrieve a pointer to the factory function
    pDLLUsage = 
        (DLLUsage) GetProcAddress(hInstDll, "usage");
	pDLLStop = 
        (DLLStop) GetProcAddress(hInstDll, "stop");
	pDLLStart = 
        (DLLStart) GetProcAddress(hInstDll, "start");

	try{
		double time;											// initialize time variable
		Configurator* dwarfConfigurator = new Configurator(argc, argv, "BranchAndBound, unmanaged omp kernel");
		Solver* branchAndBoundSolver = new Solver(dwarfConfigurator);	// create new Solver (current problem with initial data)

		(pDLLStart)();											// start new time count
		branchAndBoundSolver -> Solve();						// Solve the current problem
		(pDLLStop)(&time); 										// stop the time count 

		branchAndBoundSolver -> Finish(time);					// write results
	}
	catch(exception e)
	{		
		(pDLLUsage)();                                    // incorrectness in Solver constructor. print right usage rules
	}
}