#pragma once

#include <string>
#include <iostream>
#include "targetver.h"
#include <stdio.h>

using namespace std;

typedef int(__cdecl *DLLParseArguments)(
    int,
    char**,
    char**,
    char**,
    char**);

typedef void(__cdecl *DLLUsage)();

typedef void(__cdecl *DLLStart)();

typedef void(__cdecl *DLLStop)(double* time);


class Settings
{
public:
    char* dwarfName;
    char* inputFile;
	char* resultFile;
	char* profileFile;
	
	Settings();
	void GetSettings(int argc, char** argv);
	char* StringSettings();

private:
	static const int maxArraySize = 5000;
};
