﻿using System;
using System.Runtime.InteropServices;

namespace Dwarf.Managed
{
    /// <summary>Settings that was taken from command line</summary>
    /// 
    class Settings
    {
        public string dwarfName;                    // name of the dwarf 
        public string inputFile;                    // input file
        public string profileFile;                  // output file
        public string resultFile;                   // profile file

        private static int maxArraySize = 5000;

        /// <summary>Get parameters</summary>
        /// <param name="args">Command line parameters</param>
        /// 
        public void GetSettings(string[] args)
        {
            dwarfName = "Dwarf.BranchAndBound";

            if (parseArguments(
                    args.Length,
                    args,
                    ref inputFile,
                    ref profileFile,
                    ref resultFile) != 0)
            {                                                                   // not all tokens consist in argc
                throw new Exception("Some arguments are not defined");          // give the sign for execution to be stopped
            }
        }

        /// <summary>New object of settings</summary>
        ///
        public Settings() {
            inputFile = new String(new char[maxArraySize]);
            profileFile = new String(new char[maxArraySize]);
            resultFile = new String(new char[maxArraySize]);
        }

        public String StringSettings()
        {
            return
                "Dwarf settings summary:\n" +
                "Dwarf name        : " + dwarfName + "\n" +
                "Input File        : " + inputFile + "\n" +
                "Profile File      : " + profileFile + "\n" +
                "Result File       : " + resultFile + "\n";
        }

        /// <summary>Parse the command line arguments and fill the reference parameters</summary>
        /// <param name="argc">Count of command line tokens</param>
        /// <param name="argv">Command line tokens</param>
        /// <param name="inputFile">Name of input text file</param>
        /// <param name="profileFile">Name of profile file</param>
        /// <param name="resultFile">Name of result file</param>
        /// <returns>0 if all tokens consist in argv</returns>
        ///
        [DllImport(@"CliTools.dll")]
        private static extern int parseArguments(
            int argc,
            String[] argv,
            ref string inputFile,
            ref string profileFile,
            ref string resultFile
            );

        /// <summary>Write the rules of command line structure</summary>
        /// 
        [DllImport(@"CliTools.dll")]
        private static extern void usage();
    }
}