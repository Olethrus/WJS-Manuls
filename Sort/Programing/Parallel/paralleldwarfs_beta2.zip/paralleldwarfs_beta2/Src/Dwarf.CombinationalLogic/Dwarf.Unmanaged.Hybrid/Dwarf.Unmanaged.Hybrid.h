#pragma once

#include <string>
#include <iostream>
#include <math.h>

#include "targetver.h"
#include <windows.h>

#include <stdio.h>
#include <tchar.h>
#include <time.h>

#include <mpi.h>
#include <omp.h>

using namespace std;

// Short dwarf's description.
#define DWARF_NAME (char*)"Combinational Logic, unmanaged hybrid kernel."

// Constants for output files's names
#define DWARF_NAME_OUTPUT (char*)"Dwarf.Unmanaged.Hybrid"
#define PROFILE_TXT (char*)".Profile.txt"
#define RESULT_TXT (char*)".Result.txt"

// Number of root process.
#define NUMBER_ROOT_PROCESS 0

// Default size for buffer.
#define BUFFER_SIZE 1024

// Size of block for reading from file
#define MAX_BLOCK_SIZE 1024 * 1024 //1 mb

//Parse the command line arguments and fill the reference parameters.
typedef int (__cdecl *DLLParseArguments)(
    int,                                    //Count of command line tokens.
    char**,                                 //Command line tokens.
    char**,                                 //Name of input text file.
	char**,									//Name of profile text file.
    char** );                               //Name of result file.

// Write the rules of command line structure.
typedef void (__cdecl *DLLUsage)(void);

// Start the time count.
typedef void (__cdecl *DLLStart)(void);

// Stop the time count.
typedef void (__cdecl *DLLStop)(double*);

// Solve the Combinational Logic problem with Hybrid parallelization.
class Solver
{
public:
    Solver();               //Constructor
    ~Solver();              //Destructor

    void solve(); 

    int commSize;           // Rank of the process.
    int commRank;           // Count of processes.

    bool isRootThread;      // Index of root process. By consideration, equal to 0.

    FILE* input;                //Reference to file
    unsigned long length;       //Length of file
    unsigned long resultCount;  //Result counter
    unsigned long bufferSize;   //Number of bytes for each process
	
private:

};

// Settings taken from command line and input file.
class Settings
{
public:
	Settings();             //Constructor
    ~Settings();            //Destructor

    void finish(Solver *clsolver);
    void start();
    int init(int argc, char** argv, Solver *clsolver);
	
private:

    // Input & output files.
    char* inputFile;
    char* profileFile;
	char* resultFile;

    // Parse input file into solver's structures.
    int parseConfigFile(Solver* clsolver); 
    
    // Write settings.
    void writeSettings(Solver *clsolver);
};