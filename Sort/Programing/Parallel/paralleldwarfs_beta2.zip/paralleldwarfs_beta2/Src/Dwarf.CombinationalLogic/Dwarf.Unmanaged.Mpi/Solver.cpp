#include "Dwarf.Unmanaged.Mpi.h"

//Init arrays.
Solver :: Solver()
{
    input = 0;
    resultCount = 0;

    int argc = 0;
    char **argv;
    MPI_Init(&argc, &argv);                             // Init MPI

    MPI_Comm_rank(MPI_COMM_WORLD, &commRank);           // Retrieve rank of the process
    MPI_Comm_size(MPI_COMM_WORLD, &commSize);           // Retrieve count of processes

    isRootThread = commRank == NUMBER_ROOT_PROCESS;
}

//Dispose arrays.
Solver :: ~Solver()
{    
    MPI_Finalize();                                     //Dispose MPI

    if (input) 
    {
        fclose(input);
    }  
}

// MPI based method.
//For the demonstration purposes of the project, 
//we have chosen the algorithm that counts the number of �1� bits in a bit string.
void Solver::solve() 
{    
    UINT64 *buffer = new UINT64[bufferSize];    //Working buffer
    unsigned long len;                          //Lenght of block
    unsigned long localCount = 0;               //Counter

    int bufSend = 0;                            //Number of sent blocks.
    int bufRecv = 0;                            //Number of recieved blocks.

    MPI_Status status;                          //Status of receiving.

    char fileOver = 0;                          //flag of eof

    if (isRootThread)
    {    
        //Send different blocks of data to each process
        for (int i = 1; i < commSize; i ++) 
        {
            MPI_Send(&fileOver, 1, MPI_CHAR, i, i, MPI_COMM_WORLD);

            if (!fileOver)
            {
                len = (unsigned long) fread(buffer, 8, bufferSize, input);

                if (len < bufferSize) 
                {    
                    *(buffer + len) = *(buffer + len) << 8 * (8 - length % 8);

                    len ++;

                    fileOver = 1;
                }

                MPI_Send(&len, 1, MPI_UNSIGNED, i, i, MPI_COMM_WORLD);
                MPI_Send(buffer, len, MPI_LONG_LONG_INT, i, i, MPI_COMM_WORLD);

                bufSend ++;
            }
        }

        while(bufSend > bufRecv)            //While not End Of File
        {
            MPI_Probe(MPI_ANY_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

            //Receive the resulting value
            MPI_Recv(&localCount, 1, MPI_UNSIGNED_LONG, status.MPI_SOURCE, MPI_ANY_TAG, MPI_COMM_WORLD, &status);            
            bufRecv ++;      
            resultCount += localCount;

            MPI_Send(&fileOver, 1, MPI_CHAR, status.MPI_SOURCE, status.MPI_TAG, MPI_COMM_WORLD);

            //Send current block of data to released process 
            if (!fileOver) 
            {
                len = (unsigned long) fread(buffer, 8, bufferSize, input);	

                if (len < bufferSize) 
                {    
                    *(buffer + len) = *(buffer + len) << 8 * (8 - length % 8);

                    len ++;

                    fileOver = 1;
                }

                MPI_Send(&len, 1, MPI_UNSIGNED, status.MPI_SOURCE, status.MPI_TAG, MPI_COMM_WORLD);
                MPI_Send(buffer, len, MPI_LONG_LONG_INT, status.MPI_SOURCE, status.MPI_TAG, MPI_COMM_WORLD);

                bufSend ++;
            }
        }        
    }
    else
    {        
        //Receive the flag of eof
        MPI_Recv(&fileOver, 1, MPI_CHAR, NUMBER_ROOT_PROCESS, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        while(!fileOver) 
        {

			//fix: move conditional into loop 
            //Receive the flag of eof
            //MPI_Recv(&fileOver, 1, MPI_CHAR, NUMBER_ROOT_PROCESS, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            //if (fileOver) break;

            if (fileOver) break;

            //Receive block of data
            MPI_Recv(&len, 1, MPI_UNSIGNED, NUMBER_ROOT_PROCESS, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
            MPI_Recv(buffer, len, MPI_LONG_LONG_INT, NUMBER_ROOT_PROCESS, MPI_ANY_TAG, MPI_COMM_WORLD, &status);

            localCount = 0;
            //Loop for length of block 
            for (unsigned int i = 0; i < len; i ++)
			{
				UINT64 count = 0;

				//This line of code is used for decrease of input file size.
				//Such modification would reduce the input file size, 
				//but the algorithm is still belongs dwarf.
				//Also this line does not affect the result.
				for (int k = 0; k < 1000000; k ++)

				{     
					//Calculate the number of �1� bits in the current uint64 of the current block
					count = *(buffer + i);

					count -= (count >> 1) & 0x5555555555555555;             
					count = (count & 0x3333333333333333) + ((count >> 2) & 0x3333333333333333); 
					count = (count + (count >> 4)) & 0x0f0f0f0f0f0f0f0f;    
				}
                localCount += count * 0x0101010101010101 >> 56;            
            }

            //Return resulting value to the root process
            MPI_Send(&localCount, 1, MPI_UNSIGNED_LONG, NUMBER_ROOT_PROCESS, commRank, MPI_COMM_WORLD); 

			//Receive the flag of eof
            MPI_Recv(&fileOver, 1, MPI_CHAR, NUMBER_ROOT_PROCESS, MPI_ANY_TAG, MPI_COMM_WORLD, &status);
        }
    }

    delete buffer;
}
