// Dwarf.Unmanaged.Serial.cpp : Defines the entry point for the console application.
//

#include "Dwarf.Unmanaged.Omp.h"

using namespace std;

// The settings for this dwarf.
static Settings* settings;

// Get settings from the command line.
static int getSettings(int argc, char** argv, Solver *clsolver) 
{
    settings = new Settings();
    if (settings->init(argc,argv,clsolver))     //Parse all arguments for dwarf.
    {            
        delete settings;
        return -1;
    }

    return 0;
}

// Point of the program start.
void main(int argc, char** argv)
{   
    Solver* clsolver = new Solver();        

    if (getSettings(argc, argv, clsolver))     // Get settings from the command line.
    {
        delete clsolver;
        exit(-1);
    }

    settings->start();                          // Start new time count.
    clsolver->solve();                         // Solve the current problem.
    settings->finish(clsolver);                // Stop the time count and write results.

    //Dispose objects.
    delete settings;
    delete clsolver;
}