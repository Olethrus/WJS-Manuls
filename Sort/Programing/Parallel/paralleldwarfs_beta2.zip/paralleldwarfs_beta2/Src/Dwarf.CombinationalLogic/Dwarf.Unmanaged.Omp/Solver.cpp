#include "Dwarf.Unmanaged.Omp.h"

//Init arrays.
Solver :: Solver()
{
    input = 0;
    resultCount = 0;
}

//Dispose arrays
Solver :: ~Solver()
{    
    if (input) 
    {
        fclose(input);
    }
}

// OpenMP based method.
//For the demonstration purposes of the project, 
//we have chosen the algorithm that counts the number of �1� bits in a bit string.
void Solver::solve() 
{
    UINT64 *buffer = new UINT64[MAX_BLOCK_SIZE];    //Working buffer
    int len;                                        //Lenght of block
    unsigned int localCount = 0;                    //Counter
 
    //Loop while not End Of File.
    while (!feof(input)) 
    {
        //Read block of data from file.
        len = (int) fread(buffer, 8, MAX_BLOCK_SIZE, input);	

        if (len < MAX_BLOCK_SIZE) 
        {    
            *(buffer + len) = *(buffer + len) << 8 * (8 - length % 8);

            len ++;
        }

        //OMP tag. Loop for length of block.
        #pragma omp parallel for reduction(+ : localCount)
        for (int i = 0; i < len; i ++)
		{
			UINT64 count = 0;

			//This line of code is used for decrease of input file size.
			//Such modification would reduce the input file size, 
			//but the algorithm is still belongs dwarf.
			//Also this line does not affect the result.
			for (int k = 0; k < 1000000; k ++)

			{     
				//Calculate number of �1� in current uint64 of current block.
				count = *(buffer + i);

				count -= (count >> 1) & 0x5555555555555555;             
				count = (count & 0x3333333333333333) + ((count >> 2) & 0x3333333333333333); 
				count = (count + (count >> 4)) & 0x0f0f0f0f0f0f0f0f;    
			}
            localCount += count * 0x0101010101010101 >> 56;            
        }
    }

    delete buffer; 

    resultCount = localCount;
}