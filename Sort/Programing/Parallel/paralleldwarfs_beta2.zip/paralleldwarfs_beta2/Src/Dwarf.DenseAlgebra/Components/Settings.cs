using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;

namespace Dwarf.Managed
{
    /// <summary>
    /// Settings taken from command line and input file.
    /// </summary>
    class Settings
    {
        /// <summary>
        /// Input & output files.
        /// </summary>
        private string inputFile;
        private string profileFile;
        private string resultFile;
        
        /// <summary>
        /// Default size for buffer.
        /// </summary>
        private const int BUFFER_SIZE = 1024;

        /// <summary>
        /// Constructor that init strings.
        /// </summary>
        public Settings()
        {
            inputFile = new string(new char[BUFFER_SIZE]);
            profileFile = new string(new char[BUFFER_SIZE]);
            resultFile = new string(new char[BUFFER_SIZE]);
        }

        /// <summary>
        /// Problem results output.
        /// </summary>
        /// <param name="dlasolver">
        /// Instance of Solver.
        /// </param>
        public void Finish(Solver dlasolver)
        {
            double time = 0; ;
            stop(ref time);

            Console.WriteLine();
            Console.WriteLine("Clock time (sec): {0} ", time.ToString("F8"));

            try
            {
                using (StreamWriter outputProfile = File.CreateText(profileFile)) 
                {
                    outputProfile.WriteLine("#Dwarfname:{0}", Solver.DWARF_NAME);
                    outputProfile.WriteLine("#Time: {0}", DateTime.Now.ToString());

                    outputProfile.WriteLine("#Dimensions: 2");
                    outputProfile.WriteLine("#Matrix Size: {0}", dlasolver.msize);
                    outputProfile.WriteLine("#Result time (sec): {0}", time.ToString("F8"));

                    using (StreamWriter outputResult = File.CreateText(resultFile))
                    {
                        outputResult.WriteLine("#Result domain:");
                        for (int i = 0; i < dlasolver.msize; i++)
                        {
                            for (int j = 0; j < dlasolver.msize; j++)
                            {
                                outputResult.Write("{0} ", dlasolver.result[i][j].ToString("F8"));
                            }
                            outputResult.WriteLine();
                        }
                    }

                    outputProfile.WriteLine("#eof");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception("Error in output file");
            }


        }

        /// <summary>
        /// Init variables, parse cli params and input file.
        /// </summary>
        /// <param name="args">
        /// Cli params.
        /// </param>
        /// <param name="dlasolver">
        /// Instance of Solver.
        /// </param>
        public void Init(string[] args, Solver dlasolver)
        {
            //Parse cli params.
            parseArguments(
                    args.Length,
                    args,
                    ref inputFile,
                    ref profileFile,
                    ref resultFile);

            //Parse input file.
            parseConfigFile(dlasolver);

            // write settings if it's needed
            WriteSettings(dlasolver);
        }

        /// <summary>
        /// Start the time count.
        /// </summary>
        public void Start()
        {
            start();
        }

        /// <summary>
        /// Get one line from stream.
        /// </summary>
        /// <param name="dlasolver">
        /// Stream to get from.
        /// </param>
        private static string GetLine(StreamReader sr)
        {
            string s = sr.ReadLine();

            //Avoid comments lines.
            while (s != null && (s.StartsWith("#") || s.StartsWith("//")))
            {
                s = sr.ReadLine();
            }

            return s;
        }

        /// <summary>
        /// Parse input file into solver's structures.
        /// </summary>
        /// <param name="dlasolver">
        /// Instance of Solver.
        /// </param>
        private void parseConfigFile(Solver dlasolver)
        {
            // Open the file to read from.
            try
            {
                using (StreamReader sr = File.OpenText(inputFile))
                {
                    //Get size of matrices.
                    dlasolver.msize = int.Parse(GetLine(sr));

                    dlasolver.lgrid = new double[dlasolver.msize][];
                    dlasolver.rgrid = new double[dlasolver.msize][];
                    dlasolver.result = new double[dlasolver.msize][];

                    //Get left matrix.
                    string[] str;
                    for (int i = 0; i < dlasolver.msize; i++)
                    {
                        dlasolver.lgrid[i] = new double[dlasolver.msize];
                        dlasolver.rgrid[i] = new double[dlasolver.msize];
                        dlasolver.result[i] = new double[dlasolver.msize];

                        str = GetLine(sr).Split(' ');
                        for (int j = 0; j < dlasolver.msize; j++)
                        {
                            dlasolver.lgrid[i][j] = double.Parse(str[j]);
                        }
                    }

                    //Get right matrix.
                    for (int i = 0; i < dlasolver.msize; i++)
                    {
                        str = GetLine(sr).Split(' ');
                        for (int j = 0; j < dlasolver.msize; j++)
                        {
                            dlasolver.rgrid[i][j] = double.Parse(str[j]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception("Error in input file", ex);
            }
        }

        /// <summary>
        /// Write settings.
        /// </summary>
        /// <param name="dlasolver">
        /// Instance of Solver.
        /// </param>
        private void WriteSettings(Solver dlasolver)
        {
            // Write general settings.
            Console.WriteLine("Kernel settings summary : ");
            Console.WriteLine("Dwarf name              : {0} ", Solver.DWARF_NAME);
            Console.WriteLine("Matrix size             : {0} ", dlasolver.msize);
            Console.WriteLine("Inputfile               : {0} ", inputFile);
            Console.WriteLine("Profilefile             : {0} ", profileFile);
            Console.WriteLine("Resultfile              : {0} ", resultFile);
            Console.WriteLine();


        }

        /// <summary>Parse the command line arguments and fill the reference parameters</summary>
        /// <param name="argc">Count of command line tokens</param>
        /// <param name="argv">Command line tokens</param>
        /// <param name="log">Settings log (debug/benchmark)</param>
        /// <param name="inputFile">Name of input text file</param>
        /// <param name="outputFile">Name of output file</param>
        [DllImport(@"CliTools.dll")]
        private static extern void parseArguments(
            int argc,
            string[] argv,
            ref string inputFile,
            ref string profileFile,
            ref string resultFile
            );

        /// <summary>
        /// Start the time count.
        /// </summary>
        [DllImport(@"CliTools.dll")]
        private static extern void start();

        /// <summary>
        /// Stop the time count.
        /// </summary>
        /// <param name="time">
        /// Value of the time.
        /// </param>
        [DllImport(@"CliTools.dll")]
        private static extern void stop(ref double time);
    }
}