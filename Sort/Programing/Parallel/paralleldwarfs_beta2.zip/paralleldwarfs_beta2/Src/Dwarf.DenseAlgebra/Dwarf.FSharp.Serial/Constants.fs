﻿#light

module Constants

/// <summary>
/// Short dwarf's description.
/// </summary>
let DWARF_NAME = "Dense Linear Algebra, managed FSharp serial kernel"
