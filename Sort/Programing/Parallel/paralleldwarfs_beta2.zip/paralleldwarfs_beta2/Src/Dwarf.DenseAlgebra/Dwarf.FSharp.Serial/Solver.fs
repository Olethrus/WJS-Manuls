﻿#light

module Dwarf_Managed

open System
open System.Collections.Generic
open System.Runtime.InteropServices

/// <summary>
/// Write the rules of command line structure.
/// </summary>
[<DllImport(@"CliTools.dll")>]
extern void usage();

/// <summary>
/// Get settings from the command line.
/// </summary>
/// <param name="args">
/// Cli params.
/// </param>
/// <param name="dlasolver">
/// Instance of Solver.
/// </param>
let getSettings(args : String[]) =
    Dwarf_Managed_Common.Init(args)
    
let getTranspose(matrix : double[,], n : int) : double[,] = 
    let mutable transpose = Array2D.zeroCreate<double> n n
    for i = 0 to n - 1 do
        transpose.[i,i] <- matrix.[i,i]
        for j = i + 1 to n - 1 do
            transpose.[i,j] <- matrix.[j,i]
            transpose.[j,i] <- matrix.[i,j]
            
    transpose

let Solve() =
    let rtransposed = getTranspose(Dwarf_Managed_Common.rgrid, Dwarf_Managed_Common.msize)

    for i = 0 to Dwarf_Managed_Common.msize - 1 do
        for j = 0 to Dwarf_Managed_Common.msize - 1 do
            let mutable cell = 0.0
            for k = 0 to Dwarf_Managed_Common.msize - 1 do 
                cell <- cell + Dwarf_Managed_Common.lgrid.[i,k] * rtransposed.[j,k]
            Dwarf_Managed_Common.result.[i,j] <- cell    
 
let main() =   
    
    try
        let args = System.Environment.GetCommandLineArgs()
        getSettings(args)                          // Get settings from the command line.

        Dwarf_Managed_Common.Start()               // Start new time count.
        Solve()                                    // Solve the current problem.
        Dwarf_Managed_Common.Finish()              // Stop the time count and write results.
        
    with e -> Console.WriteLine(e.Message); Console.WriteLine(e.StackTrace); usage()
         
main()








        
