﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Dwarf.Managed
{
    /// <summary>
    /// Solve the Dense Linear Algebra problem with Serial parallelization  
    /// </summary>
    /// <remarks> 
    /// For the demonstration purposes of the project, 
    /// we have chosen matrix-matrix multiplication.
    /// </remarks>
    class Solver
    {
        /// <summary>
        /// Short dwarf's description.
        /// </summary>
        public const String DWARF_NAME = "Dense Linear Algebra, managed serial kernel";

        /// <summary>
        /// The size of square matrix.
        /// </summary>
        public int msize;

        /// <summary>
        /// Left matrix.
        /// </summary>
        public double[][] lgrid;

        /// <summary>
        /// Right matrix.
        /// </summary>
        public double[][] rgrid;

        /// <summary>
        /// Result matrix.
        /// </summary>
        public double[][] result;

        /// <summary>
        /// Empty constructor.
        /// </summary>
        public Solver()
        {
        }

        /// <summary>
        /// Transpose a square matrix
        /// <param name=matrix>
        /// The ragged square array to transpose.  Returns a new ragged transposed array
        /// </param>
        /// <param name=n>
        /// Dimension of the square array
        /// </param>
        /// <typeparam name=T>
        /// Element type of the array
        /// </typeparam>
        /// </summary>
        static private T[][] Transpose<T>(T[][] matrix, int n)
        {
            T[][] transpose = new T[n][];
            for (int i = 0; i < n; i++)
            {
                transpose[i] = new T[n];
            }
            for (int i = 0; i < n; i++)
            {
                transpose[i][i] = matrix[i][i];
                for (int j = i + 1; j < n; j++)
                {
                    transpose[i][j] = matrix[j][i];
                    transpose[j][i] = matrix[i][j];
                }
            }
            return transpose;
        }

        /// <summary>
        /// Serial based method for matrix-matrix multiplication.
        /// </summary>
        public void Solve()
        {
            // transpose the right hand array to improve memory accessing
            double[][] rtransposed = Transpose<Double>(rgrid, msize);

            //Multiple lgrid by rgrid (transposed)
            //    Note that row and cell are factored out
            //    since the optimizers can't hoist all of the bounds checking
            //    and the common addressing subexpressions without doing it. 
            //    (Strickly speaking it would be incorrect to do so.)
            for (int i = 0; i < msize; i++)                                         // Loop for number of rows in left matrix.
            {
                double[] row = result[i];
                for (int j = 0; j < msize; j++)                                     // Loop for number of columns in right matrix.
                {
                    double cell = 0.0;
                    double[] leftRow = lgrid[i];
                    double[] rightColumn = rtransposed[j];
                    for (int k = 0; k < msize; k++)                                 // Loop for number of columns in left matrix and rows in right matrix.
                    {
                        cell += leftRow[k] * rightColumn[k];

                        // To see the effect of not transposing 
                        // use the following as the inner loop
                        //cell += leftRow[k] * rgrid[k][j];
                        // To see the effect of the compiler/runtime optimizations,
                        // comment out cell, row, and leftRow above and below.
                        // Use the following as the inner loop
                        //result[i][j] = result[i][j] + lgrid[i][k] * rgrid[k][j];
                    }
                    row[j] = cell;
                }
            }
        }
    }
}
