// Dwarf.Unmanaged.Serial.cpp : Defines the entry point for the console application.
//

#include "Dwarf.Unmanaged.Omp.h"

using namespace std;

// The settings for this dwarf.
static Settings* settings;

// Get settings from the command line.
static int getSettings(int argc, char** argv, Solver *dlasolver) 
{
    settings = new Settings();
    if (settings->init(argc,argv,dlasolver))    //Parse all arguments for dwarf.
    {            
        delete settings;
        return -1;
    }

    //Fill result matrix.
    for (int i = 0; i < dlasolver->msize; i ++) 
    {
        for (int j = 0; j < dlasolver->msize; j ++) 
        {
            dlasolver->result[i][j] = 0;
        }
    }
    return 0;
}

// Point of the program start.
void main(int argc, char** argv)
{   
    Solver* dlasolver = new Solver();        

    if (getSettings(argc, argv, dlasolver))     // Get settings from the command line.
    {
        delete dlasolver;
        exit(-1);
    }

    settings->start();                          // Start new time count.
    dlasolver->solve();                         // Solve the current problem.
    settings->finish(dlasolver);                // Stop the time count and write results.

    //Dispose objects.
    delete settings;
    delete dlasolver;
}
