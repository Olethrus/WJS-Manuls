﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.InteropServices;


namespace Dwarf.Managed
{
    class Program
    {
        static void Main(string[] args)
        {
            Solver dynamicProgrammingSolver = new Solver(args);

            double time = 0;
            Settings.start();
            dynamicProgrammingSolver.Solve();
            Settings.stop(ref time);
            dynamicProgrammingSolver.Finish(time);
        }

    }
}
