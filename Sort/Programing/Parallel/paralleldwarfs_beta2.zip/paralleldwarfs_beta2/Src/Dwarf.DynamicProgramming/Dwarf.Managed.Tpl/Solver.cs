﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Dwarf.Managed
{
    /// <summary>
    /// This solver is an instance of the 1/0 Knapsack problem that showcases 
    /// dynamic programming in its solution.  
    /// </summary>

    /// <remarks> 
    /// Dynamic programming is a technique used when a problem can be solved in 
    /// terms of optimal solutions of instance sub-problems.
    /// 
    /// The 0/1 Knapsack Problem is as follows: Given a set of items, each with
    /// a given value and cost, and a maximum cost C, determine the set of items that can
    /// be included in the knapsack set without exceeding cost C.  The problem 
    /// is additionally constrained such that there may be either 0 or 1 instance
    /// of a given item included in the knapsack. 
    /// 
    /// This solver uses a bottom-up approach to dynamic programming for solving 
    /// the 0/1 Knapsack problem, finding a solution in terms of optimal sub-problems.
    /// </remarks>
    class Solver
    {

        /// <summary>
        /// The settings for this dwarf.
        /// </summary>
        private Settings SettingsContainer;

        /// <summary>
        /// The maximal cost parameter as given on the first line of the input file.
        /// </summary>
        private int MaximumCost = 0;

        /// <summary>
        /// The list of items with their associated costs and values.
        /// </summary>
        private List<Item> Items = null;

        /// <summary>
        /// The optimal solutions for costs 0..MaximumCost after Solve() has returned.
        /// </summary>
        private Solution[] Answers = null;

        /// <summary>Constructor</summary>
        /// <param name="args">The command line arguments passed upon startup.</param>
        public Solver(string[] args)
        {
            SettingsContainer = new Settings();
            SettingsContainer.GetSettings(args); //parse command line arguments
            Items = SettingsContainer.GetItems();
            MaximumCost = SettingsContainer.GetMaxCost();
        }


        /// <summary>TPL based method to solve the 0/1 Knapsack problem.</summary>
        /// <remarks>
        /// The serial algorithm used here is described at http://en.wikipedia.org/wiki/Knapsack_problem. 
        /// It is in effect the following: A[i] = max(v_j + A[i-c_j] | c_j is less than or equal to i). 
        /// Note: It is assumed that for all items, the cost of the item is greater than zero.
        /// </remarks>
        public void Solve()
        {
            //Allocate the Answers array.
            Answers = new Solution[MaximumCost + 1];

            //Create an answer for zero weight that has zero value.
            Answers[0] = new Solution(0, 0, null, null);

            List<Item> CandidateItems = null;

            //The zero value solution is initially the best solution.
            Solution CurrentMax = Answers[0];
            for (int i = 0; i <= MaximumCost; ++i)
            {
                //Get each item that can be considered at the current cost i.
                CandidateItems = Items.FindAll((TestItem) => TestItem.Cost <= i);

                //Create a lock to enable mutuial exclustion.
                Object myLock = new Object();

                //For each item that can be considered
                Parallel.For(0, CandidateItems.Count, (index) =>
                {
                    Item it = CandidateItems[index];

                    //Get the optimal sub-problem for the remaining cost allotment
                    Solution SubProblem = Answers[i - it.Cost];

                    //If the cost of it and the sub-problem is less than i...
                    if (SubProblem.Cost + it.Cost <= i) 
                    {
                        //If the value of it and the sub-problem is greater than the current maximum...
                        if (CurrentMax.Value <= (it.Value + SubProblem.Value)) 
                        {
                            //Make sure the sub-problem does not already contain it (this is the 0/1 constraint)
                            if (!SubProblem.ContainsItem(it.Number))
                            {
                                //Lock the CurrentMax value
                                lock (myLock)
                                {
                                    //Check again -- might have changed since we checked last time
                                    if (CurrentMax.Value <= (it.Value + SubProblem.Value))
                                    {
                                        //The best solution so far has been found for cost i
                                        CurrentMax = new Solution(SubProblem.Cost + it.Cost, SubProblem.Value + it.Value, it, SubProblem);
                                    }
                                }
                            }
                        }
                    }
                });

                //Once all solutions have been tried for cost i, the best overall solution (for cost i) is in CurrentMax.
                //Store this solution for cost i in Answers.
                Answers[i] = CurrentMax;
            }
        }

        public void Finish(double Time)
        {
            SettingsContainer.Finish(Time, Answers);
        }

    }
    /// <summary>
    /// A class representing the items being considered for inclusion in the knapsack.
    /// </summary>
    public class Item
    {
        /// <summary>
        /// The cost of this item.
        /// </summary>
        private int myCost;
        /// <summary>
        /// The value of this item.
        /// </summary>
        private int myValue;
        /// <summary>
        /// An identifier for this item that is unique for the item's input set.
        /// </summary>
        private int myNumber;

        public Item(int cost, int value, int number)
        {
            myCost = cost;
            myValue = value;
            myNumber = number;
        }

        /// <summary>
        /// The cost of this item.
        /// </summary>
        public int Cost { get { return myCost; } }
        /// <summary>
        /// The value of this item.
        /// </summary>
        public int Value { get { return myValue; } }
        /// <summary>
        /// An identifier for this item that is unique in the item's input set.
        /// </summary>
        public int Number { get { return myNumber; } }

        /// <summary>
        /// Format the Item's data in a string.
        /// </summary>
        /// <returns>A string representing the data elements of this Item.</returns>
        public override string ToString()
        {
            return myNumber + ": " + myCost + ", " + myValue;
        }
    }

    /// <summary>
    /// A class representing a solution for the 0/1 knapsack problem.
    /// </summary>
    public class Solution
    {
        /// <summary>
        /// The value of this solution.
        /// </summary>
        private int myValue;
        /// <summary>
        /// The cost of this solution.
        /// </summary>
        private int myCost;
        /// <summary>
        /// The item added to another solution to form this solution.
        /// </summary>
        private Item myItem;
        /// <summary>
        /// The solution added to another item to form this solution.
        /// </summary>
        private Solution mySubSolution;

        public Solution(int cost, int value, Item item, Solution subSolution)
        {
            myCost = cost;
            myValue = value;
            myItem = item;
            mySubSolution = subSolution;
        }

        /// <summary>
        /// Tests whether this solution contains an item labeled with itemNumber.
        /// </summary>
        /// <param name="itemNumber">The identifier of an item to search for in this solution.</param>
        /// <returns>True if an Item with the specified itemNumber is part of this solution.  False otherwise.</returns>
        public bool ContainsItem(int itemNumber)
        {
            bool returnValue = false;
            //If I have an item...
            if (myItem != null)
            {
                //check to see whether itemNumber is my Item...
                if (myItem.Number == itemNumber)
                {
                    //if so -- return true
                    returnValue = true;
                }
                else
                {
                    //if not -- check mySubSolution to see if itemNumber is used there.
                    if (mySubSolution != null)
                    {
                        returnValue = mySubSolution.ContainsItem(itemNumber);
                    }
                }
            }
            return returnValue;
        }

        /// <summary>
        /// The value of this solution.
        /// </summary>
        public int Value { get { return myValue; } }
        /// <summary>
        /// The cost of this solution.
        /// </summary>
        public int Cost { get { return myCost; } }


        public Item[] ToArray() {
            List<Item> items = new List<Item>();
            Solution solution = this;
            while (solution != null) {
                if (solution.myItem != null)
                    items.Add(solution.myItem);
                solution = solution.mySubSolution;
            }
            items.Sort((x, y) => x.Number < y.Number ? -1 : x.Number > y.Number ? 1 : 0);
            return items.ToArray();
        }

        /// <summary>
        /// Format the data within this solution as a string.
        /// </summary>
        /// <returns>A string representing the solution.</returns>
        public override string ToString() {
            StringBuilder sb = new StringBuilder();
            Item[] items = ToArray();
            foreach (Item item in items) {
                sb.Append(item.ToString());
                sb.Append(System.Environment.NewLine);
            }
            return sb.ToString();
        }
    }
}