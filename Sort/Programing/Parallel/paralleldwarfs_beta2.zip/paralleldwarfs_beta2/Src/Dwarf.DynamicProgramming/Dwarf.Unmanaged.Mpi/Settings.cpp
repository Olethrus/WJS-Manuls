#include <string>
#include <iostream>
#include <math.h>

#include "targetver.h"
#include <windows.h>
#include "stdafx.h"
#include <stdio.h>
#include <tchar.h>
#include <time.h>
#include "Settings.h"
#include "mpi.h"

static DLLParseArguments pDLLParseArguments;

static HINSTANCE hInstDll;

using namespace std;

Settings::Settings()
{
    inputFile = new char[maxArraySize];
	profileFile = new char[maxArraySize];
	resultsFile = new char[maxArraySize];

    inputFile[0] = profileFile[0] = resultsFile[0] = '\0';

}

void Settings::GetSettings(int argc, char **argv)
{
	dwarfName = "Dwarf.DynamicProgramming";

     //Load the dll into the address space
	hInstDll = LoadLibraryA("CliTools.dll");
    if (hInstDll == 0) 
    {
        printf("Error while loading CliTools.dll.");
        return;
    }

    // Retrieve a pointer to the factory function
    pDLLParseArguments = 
        (DLLParseArguments) GetProcAddress(hInstDll, "parseArguments");


    if ((pDLLParseArguments)(argc, argv, &inputFile, &profileFile, &resultsFile)) 
    {
        FreeLibrary(hInstDll); 
        return;
    }
}

void Settings::WriteSettings()
{
	int Rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &Rank);
	if(Rank == 0){
		printf("Kernel settings summary: \n");
		printf("Dwarf name       : %s \n", Settings::dwarfName);
		printf("InputFile        : %s \n", Settings::inputFile);
		printf("ProfileFile      : %s \n", Settings::profileFile);
		printf("ResultsFile      : %s \n", Settings::resultsFile);
		printf("\n");
	}
}