// Dwarf.Unmanaged.Serial.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

void start();
void stop(double*);

void main(int argc, char** argv)
{
	Solver* dynamicProgrammingSolver = new Solver(argc, argv);
	double time;

	start();
	dynamicProgrammingSolver -> Solve();
	stop(&time);

	dynamicProgrammingSolver -> Finish(time);
}

LARGE_INTEGER tstart, tstop;
LARGE_INTEGER frequency;


void start()
{
	QueryPerformanceFrequency(&frequency);
	QueryPerformanceCounter(&tstart);
}

void stop(double* time)
{	
	QueryPerformanceCounter(&tstop);
	*time = (double)(tstop.QuadPart - tstart.QuadPart) /(double)frequency.QuadPart;
}
