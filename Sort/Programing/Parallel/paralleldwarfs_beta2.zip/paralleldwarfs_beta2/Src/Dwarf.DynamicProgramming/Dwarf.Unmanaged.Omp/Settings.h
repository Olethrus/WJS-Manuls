#pragma once

#include <string>
#include <iostream>
#include "targetver.h"
#include <stdio.h>

using namespace std;


typedef int(__cdecl *DLLParseArguments)(
    int,
    char**,
    char**,
    char**,
    char** );

class Settings
{
public:
    char* dwarfName;
    char* inputFile;
	char* profileFile;
	char* resultsFile;
	
	Settings();
	void GetSettings(int argc, char** argv);
	void WriteSettings();

private:
	static const int maxArraySize = 5000;
};
