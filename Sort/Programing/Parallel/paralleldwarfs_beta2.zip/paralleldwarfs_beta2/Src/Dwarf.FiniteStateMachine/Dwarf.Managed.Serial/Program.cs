﻿using System;
using System.Runtime.InteropServices;

namespace Dwarf.Managed
{
    /// <summary>User interface for solving the Pattern Search Problem</summary>
    /// 
    class Program
    {
        /// <summary>Point of the program start</summary>
        /// <param name="args"></param>
        ///
        static void Main(string[] args)
        {
            double time = 0;                                        // initialize time variable
            start();                                                // start new time count
            try
            {
                Configurator dwarfConfigurator = new Configurator(args); // process the command line arguments
                Solver finiteStateMachineSolver = new Solver(ref dwarfConfigurator); // create new Solver (current problem with initial data)
                finiteStateMachineSolver.Solve();                   // Solve the current problem
                stop(ref time);                                     // stop the time count
                finiteStateMachineSolver.Finish(time);              // write results           
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                usage();                                        // incorrectness in Solver processing
            }
        }

        /// <summary>Start the time count</summary>
        /// 
        [DllImport(@"CliTools.dll")]
        private static extern void start();

        /// <summary>Stop the time count</summary>
        /// <param name="time">Value of the time</param>
        /// 
        [DllImport(@"CliTools.dll")]
        private static extern void stop(ref double time);

        /// <summary>Write the rules of command line structure</summary>
        /// 
        [DllImport(@"CliTools.dll")]
        private static extern void usage();

    }
}
