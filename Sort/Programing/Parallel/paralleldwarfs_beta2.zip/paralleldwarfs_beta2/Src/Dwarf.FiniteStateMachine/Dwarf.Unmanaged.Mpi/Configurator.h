#pragma once

#include "Settings.h"

class Configurator
{
public:
	Configurator(int argc, char** argv);
	void GetContent(char **mainContent, int *contentSize, char **patternContent, int *stateDimensionCoincidence);
	void WriteSettings();
	void Close(double time, list<int> positions);

private:
	Settings* settings;
	FILE *profile;
};
