#include "Configurator.h"
#include "omp.h"
#include <list>

#ifndef SOLVER_H_
#define SOLVER_H_

using namespace std;

class Solver
{
public:
	static const int maxArraySize = 5000;
	static const int partSize = 500000;
	Solver(Configurator* configurator);
	void Solve();
	void Finish(double time);
	
private:
	omp_lock_t lk;
	Configurator* dwarfConfigurator;
	list<int> positions;							// list for storing of found positions 
	static const int stateDimensionChars = 65534;	// chars count
	int **states;									// table of states
    int stateDimensionCoincidence;					// size of pattern
	int *threadBounds;								// indexes of substring ands and begins
    char *patternContent;							// pattern content
	
	int contentSize;								// size of mainContent string
	char *mainContent;								// content to be parsed

	int GetContent(char **content, char *path);		// method for reading the pattern content
	void ConstructStates();							// method for constructing the states
	void InitParallelization(char *content, int size);	// init parallelization
	void StatesProcessing(int beginPoint, int endPoint);//each parallel part processing	
};

#endif
