#include "Configurator.h"

#ifndef SOLVER_H_
#define SOLVER_H_

using namespace std;

class Solver
{
public:
	Solver(Configurator* configurator);
	void Solve();
	void Finish(double time);
	
private:
	Configurator* dwarfConfigurator;
	list<int> positions;							// list for storing of found positions 
	static const int stateDimensionChars = 65534;	// chars count
	int **states;									// table of states
    int stateDimensionCoincidence;					// size of pattern
    char *patternContent;							// pattern content
	
	int contentSize;								// size of mainContent string
	char *mainContent;								// content to be parsed
			
	int GetContent(char **content, char *path);		// method for reading the pattern content
	void ConstructStates();							// method for constructing the states
	void StatesProcessing();						// processing of content
};

#endif
