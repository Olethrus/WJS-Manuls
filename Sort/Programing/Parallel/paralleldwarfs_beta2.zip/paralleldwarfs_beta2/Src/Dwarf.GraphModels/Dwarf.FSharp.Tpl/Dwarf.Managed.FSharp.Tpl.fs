﻿#light

module DwarfManagedFSharpTpl

open System
open System.Collections.Generic
open System.Threading
open System.Threading.Tasks
open DwarfData.Managed

let processGraphModels(model : DataModel) : DataModel =
    
    // 1. Initialization  delta and psi 
    let numberOfStates = model.hmm.getNumberOfStates()
    for i = 0 to  numberOfStates - 1 do
        model.vit.delta.[0].[i] <- model.hmm.initialStates.[i] * (model.hmm.observationProbabilityMatrix.[i].[model.vit.observationSequence.[0]])
        model.vit.psi.[0].[i] <- 0
    
    // 2. Compute 
    let lengthOfObsSeq = model.vit.getLengthOfObservationSequence()
    let entryForStates t j = 
        //temporary storage for max value for psi array 
        let mutable maxval = 0.0
        let mutable maxvalind = 0
        let tempVal = 0.0
        //finding the maximum
        for i = 0 to numberOfStates - 1 do
            let tempVal = model.vit.delta.[t - 1].[i] * (model.hmm.stateTransitionMatrix.[i].[j])
            if tempVal > maxval then
                maxval <-  tempVal
                maxvalind <- i
        model.vit.delta.[t].[j] <- maxval * (model.hmm.observationProbabilityMatrix.[j].[model.vit.observationSequence.[t]]);
        model.vit.psi.[t].[j] <- maxvalind 
    for t = 1 to lengthOfObsSeq - 1 do
        let task i = entryForStates t i
        Parallel.For(0, numberOfStates, new Action<int>(task))
   

    // 3. Termination 
    model.vit.setProbability(0.0);

    model.vit.sequenceOfState.[lengthOfObsSeq - 1] <- 0
    
    let task i =
        if (model.vit.delta.[lengthOfObsSeq - 1].[i] > model.vit.getProbability()) then
            model.vit.setProbability(model.vit.delta.[lengthOfObsSeq - 1].[i])
            model.vit.sequenceOfState.[lengthOfObsSeq - 1] <- i
            
    Parallel.For(0,numberOfStates,new Action<int>(task))  
  
    // 4. Path (state sequence) backtracking
    let backtrackingArray = [lengthOfObsSeq - 2 .. -1 .. 0]
    for t in backtrackingArray do
        model.vit.sequenceOfState.[t] <- model.vit.psi.[t + 1].[model.vit.sequenceOfState.[t + 1]]

    model



  
       

    