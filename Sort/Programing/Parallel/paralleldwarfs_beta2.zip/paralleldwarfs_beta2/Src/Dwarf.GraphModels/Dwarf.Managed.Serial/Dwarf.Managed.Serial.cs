﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Dwarf.Managed
{
    /// <summary>
    /// User interface for solving the Graph models Problem.
    /// </summary>
    class Program
    {
        /// <summary>
        /// The settings for this dwarf.
        /// </summary>
        static private Settings settings;

        /// <summary>
        /// Get settings from the command line.
        /// </summary>
        /// <param name="args">
        /// Cli params.
        /// </param>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        static void getSettings(String[] args, Solver solver)
        {
            settings = new Settings();
            settings.Init(args, solver);
        }

        /// <summary>
        /// Point of the program start.
        /// </summary>
        /// <param name="args">
        /// Cli params.
        /// </param>
        static void Main(String[] args)
        {
            try
            {
                Solver solver = new Solver();

                getSettings(args, solver);    // Get settings from the command line.

                settings.Start();             // Start new time count.
                solver.Solve();               // Solve the current problem.
                settings.Finish(solver);      // Stop the time count and write results.
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                usage();
            }

        }

        /// <summary>
        /// Write the rules of command line structure.
        /// </summary>
        [DllImport(@"CliTools.dll")]
        private static extern void usage();
    }
}
