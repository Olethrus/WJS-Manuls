#include "Dwarf.Unmanaged.Omp.h"

using namespace std;

// The settings for this dwarf.
static Settings* settings;

// Get settings from the command line.
static int getSettings(int argc, char** argv, Solver *solver) 
{
    settings = new Settings();
    //Parse all arguments for dwarf.
    if (settings->init(argc,argv,solver)) 
    {            
        delete settings;
        return -1;
    }

    return 0;
}

// Point of the program start.
void main(int argc, char** argv)
{   
    Solver* solver = new Solver();        
    // Get settings from the command line.
    if (getSettings(argc, argv, solver)) 
    {
        delete solver;
        exit(-1);
    }

    settings->start();                       // Start new time count.
    solver->solve();                         // Solve the current problem.
    settings->finish(solver);                // Stop the time count and write results.

    delete settings;

    delete solver;
}
