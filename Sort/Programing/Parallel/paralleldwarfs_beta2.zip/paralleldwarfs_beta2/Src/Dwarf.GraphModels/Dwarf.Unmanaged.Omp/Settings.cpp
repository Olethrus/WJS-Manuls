#include "Dwarf.Unmanaged.Omp.h"

static DLLParseArguments pDLLParseArguments;        // method 'parseArguments' loaded from CliTools.unmanaged.dll
static DLLUsage pDLLUsage;                          // method 'usage' loaded from CliTools.unmanaged.dll
static DLLStart pDLLStart;                          // method 'start' [time count] loaded from CliTools.unmanaged.dll
static DLLStop pDLLStop;                            // method 'stop' [time count] loaded from CliTools.unmanaged.dll
static HINSTANCE hInstDll;                          // instance of CliTools.unmanaged.dll

Settings :: Settings()
{
    inputFile = new char[BUFFER_SIZE];
    resultFile = new char[BUFFER_SIZE];
    profileFile = new char[BUFFER_SIZE];

    inputFile[0] = resultFile[0] = profileFile[0] ='\0';
}

// Constructor that dispose strings.
Settings :: ~Settings()
{
    delete inputFile;
    delete resultFile;
    delete profileFile;
}

static void getModel(FILE *file,Solver* solver)
{
    int m,n,t;

    fscanf_s(file, "M:%d\n", &m); 
    fscanf_s(file, "N:%d\n", &n);
    solver->hmm = new HMM(n,m);

    fscanf_s(file, "A:\n");
    for (int i = 0; i < n; i++) 
    { 
        for (int j = 0; j < n; j++) 
        {
            fscanf_s(file, "%lf", &(solver->hmm->stateTransitionMatrix[i][j])); 
        }
        fscanf_s(file,"\n");
    }

    fscanf_s(file, "B:\n");
    for (int i = 0; i < n; i++) 
    { 
        for (int j = 0; j < m; j++) 
        {
            fscanf_s(file, "%lf", &(solver->hmm->observationProbabilityMatrix[i][j])); 
        }
        fscanf_s(file,"\n");
    }

    fscanf_s(file, "pi:\n");
    for (int i = 0; i < n; i++) 
    {
        fscanf_s(file, "%lf", &(solver->hmm->initialStates[i]));
    }

    fscanf_s(file,"\n");
    fscanf_s(file, "T:%d\n", &t);
    solver->vit = new ViterbiModel(t,solver->hmm);
    fscanf_s(file, "O:\n");
    for(int i = 0; i < t; i++)
    {
        fscanf_s(file, "%d", &(solver->vit->observationSequence[i]));
    }
}

// Parse input file into solver's structures.
int Settings::parseConfigFile(Solver* solver) 
{
    FILE *file;
    // Open the file to read from.
    if( fopen_s(&file, inputFile, "rb")) 
    {
        printf("Can't open config file!\r\n");
        (pDLLUsage)();

        return -1;
    }

    getModel(file,solver);

    fclose(file);

    return 0;
}

int Settings::init(int argc, char** argv, Solver *solver) 
{

    // Load the dll into the address space
    hInstDll = LoadLibraryA("CliTools");
    if(!hInstDll)
    {
        printf("Error while loading CliTools.dll.");
        return -1;
    }

    // Retrieve a pointer to the factory function
    pDLLParseArguments = 
        (DLLParseArguments) GetProcAddress(hInstDll, "parseArguments");

    pDLLUsage =
        (DLLUsage) GetProcAddress(hInstDll, "usage");

    pDLLStart = 
        (DLLStart) GetProcAddress(hInstDll, "start");

    pDLLStop = 
        (DLLStop) GetProcAddress(hInstDll, "stop");

    if ((pDLLParseArguments)(argc, argv, &inputFile, &profileFile,  &resultFile)) 
    {
        FreeLibrary(hInstDll); 
        return -1;
    }
    //Parse input file. 
    if (parseConfigFile(solver)) 
    {
        FreeLibrary(hInstDll); 
        return -1;
    }
    //Write settings if it's needed.
    writeSettings();
    return 0;
}

// Start the time count.
void Settings::start() 
{
    (pDLLStart)();
}

void Settings::finish(Solver *solver)
{
    double time;
    (pDLLStop)(&time);
    //Release dll.
    FreeLibrary(hInstDll);

    printf("\r\n");
    printf("Clock time (sec): %.8f \r\n", time);  

    FILE* outputResult = 0;
    FILE* outputProfile = 0;

    if( fopen_s(&outputProfile, profileFile , "wb")) 
    {
        printf("Can't create profile file!\r\n");            
        fclose(outputProfile);
        return;
    }

    if( fopen_s(&outputResult, resultFile , "wb")) 
    {
        printf("Can't create result file!\r\n");   
        fclose(outputResult);
        return;
    }


    fprintf(outputProfile, "#Dwarf name:%s\r\n", DWARF_NAME);

    char tmpbuf[BUFFER_SIZE];
    _tzset();

    _strdate_s( tmpbuf, BUFFER_SIZE );
    fprintf(outputProfile, "#Time: %s ",tmpbuf);

    _strtime_s( tmpbuf, BUFFER_SIZE );
    fprintf(outputProfile, "%s \r\n",tmpbuf);
    fprintf(outputProfile, "#Result time (sec): %.8f\r\n", time);
    fprintf(outputResult,  "#Result domain:\r\n");
    int length = solver->vit->getLengthOfObservationSequence();
    for(int i = 0; i < length; i++)
    {
        fprintf(outputResult,"%d ",solver->vit->sequenceOfState[i]);
    }
    fprintf(outputResult, "\r\n");
    fprintf(outputResult,"Probability: %g \r\n", solver->vit->getProbability() );
    fprintf(outputProfile, "#eof");

    fclose(outputProfile);
    fclose(outputResult);
}

// Write settings.
void Settings::writeSettings()
{   
    // Write general settings.
    printf("Kernel settings summary  : \r\n");
    printf("Dwarf name               : %s \r\n", DWARF_NAME);
    printf("Input file               : %s \r\n", inputFile);
    printf("Profile file             : %s \r\n", profileFile);    
    printf("Result file              : %s \r\n", resultFile);    
    printf("\r\n");
}