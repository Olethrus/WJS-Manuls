﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;

namespace DwarfConfigurator
{
    class Builder : IBuilder
    {
        /// <summary>
        /// The settings for this dwarf.
        /// </summary>
        private Settings settings;

        private DataModel model;

        /// <summary>
        /// Get settings from the command line.
        /// </summary>
        /// <param name="args">
        /// Cli params.
        /// </param>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        public void buildSettings(String[] args, DataModel model)
        {
            settings = new Settings();
            settings.Init(args, model);
        }

        public Settings getSetting()
        {
            return settings;
        }

        public DataModel getModel()
        {
            return model;
        }

        public DataModel process(String[] args)
        {
            try
            {
                model = new DataModel();
                buildSettings(args, model);    // Get settings from the command line.
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                usage();
            }
            return model;
        }

        /// <summary>
        /// Write the rules of command line structure.
        /// </summary>
        [DllImport(@"CliTools.dll")]
        private static extern void usage();
    }
}
