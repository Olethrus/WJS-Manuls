﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace DwarfConfigurator
{
    public class Configurator
    {   

        private IBuilder solver = null;

        /// <summary>
        /// Configuration of f# dwarfs.
        /// </summary>
        /// <param name="args">
        /// Cli params.
        /// </param>
        public DataModel configure(String[] args, bool mpi)
        {
            if (mpi)
            {
                solver = new BuilderMpi();
            }
            else
            {
                solver = new Builder();
            }

            return solver.process(args);
        }

        /// <summary>
        /// Problem results output.
        /// </summary>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        public void Finish(DataModel model, double time)
        {   

            Console.WriteLine("Clock time (sec): {0} ", time.ToString("F8"));
            solver.getSetting().WriteResults(model,time);
        }
    }
}
