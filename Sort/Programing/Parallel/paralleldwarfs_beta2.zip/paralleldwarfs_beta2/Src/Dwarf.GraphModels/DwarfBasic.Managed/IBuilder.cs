﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DwarfConfigurator
{
    interface IBuilder
    {
        DataModel process(String[] args);
        void buildSettings(String[] args, DataModel model);
        Settings getSetting();
        DataModel getModel();
    }
}
