﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dwarf.Managed
{
    /// <summary>
    /// Presentation of Graph.
    /// </summary>
    class Graph
    {
        /// <summary>
        /// The link to the head of graph.
        /// </summary>
        private int headId;

        /// <summary>
        /// Length of graph.
        /// </summary>
        private int length;

        /// <summary>
        /// Vector for store visited vertices of graph.
        /// </summary>
        public int[] visited;

        /// <summary>
        /// Matrix for store vertices and edges of graph.
        /// </summary>
        public int[][] edgesMatrix;

        public Graph(int _length)
        {
            length = _length;
            edgesMatrix = new int[length][];
            visited = new int[length];
            //initialization
            for (int i = 0; i < length; i++)
            {
                visited[i] = 0;
            }
        }

        public int getHeadId()
        {
            return headId;
        }

        public void setHeadId(int id)
        {
            headId = id;
        }

        public int getLength()
        {
            return length;
        }

        public int getVisited(int i)
        {
            return visited[i];
        }

        public void setVisited(int i)
        {
            visited[i]++;
        }
        /// <summary>
        /// Presentation of edges for printing.
        /// </summary>
        public String ToString(int index)
        {
            StringBuilder strBldr = new StringBuilder();
            strBldr.Append(index);
            strBldr.Append(" :");
            //for (int i = 0; i < edgesMatrix[index].Length; i++)
            //{
            //    strBldr.Append(" ");
            //    strBldr.Append(edgesMatrix[index][i]);
            //}

            //strBldr.Append(". visited:");
            strBldr.Append(" Visited:");
            strBldr.Append(visited[index]);
            return strBldr.ToString();
        }
    }
}
