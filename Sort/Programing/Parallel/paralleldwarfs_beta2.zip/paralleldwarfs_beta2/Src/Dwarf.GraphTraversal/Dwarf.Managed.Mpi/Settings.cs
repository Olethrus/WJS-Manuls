﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Collections;

namespace Dwarf.Managed
{
    /// <summary>
    /// Settings taken from command line and input file.
    /// </summary>
    class Settings
    {

        /// <summary>
        /// Short dwarf's description.
        /// </summary>
        private const String DWARF_NAME = "Graph Traversal, managed mpi.net kernel.";

        /// <summary>
        /// Constants for output files's names
        /// </summary>
        private const String DWARF_NAME_OUTPUT = "Dwarf.Managed.Mpi";
        private const String PROFILE_TXT = ".Profile.txt";
        private const String RESULT_TXT = ".Result.txt";
        public const int ROOT_PROCESS = 0;
        /// <summary>
        /// Default size for buffer.
        /// </summary>
        private const int BUFFER_SIZE = 1024;

        /// <summary>
        /// Input and output files.
        /// </summary>
        private String inputFile;
        private String profileFile;
        private String resultFile;

        private double time = 0;

        public Settings()
        {
            inputFile = new String(new char[BUFFER_SIZE]);
            profileFile = new String(new char[BUFFER_SIZE]);
            resultFile = new String(new char[BUFFER_SIZE]);
        }

        /// <summary>
        /// Start the time count.
        /// </summary>
        public void Start()
        {
            start();
        }

        /// <summary>
        /// Problem results output.
        /// </summary>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        public void Finish(Solver solver)
        {
            stop(ref time);

            Console.WriteLine("Clock time (sec): {0} ", time.ToString("F8"));
        }

        /// <summary>
        /// Init variables, parse cli params and input file.
        /// </summary>
        /// <param name="args">
        /// Cli params.
        /// </param>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        public void Init(String[] args, Solver solver)
        {
            //Parse cli params.
            parseArguments(
                    args.Length,
                    args,
                    ref inputFile,
                    ref profileFile,
                    ref resultFile);

            //Parse input file.
            this.parseConfigFile(solver);

            // write settings if it's needed
            this.WriteSettings(solver);
        }

        public void WriteResults(Solver solver)
        {
                try
                {
                    using (StreamWriter outputResult = File.CreateText(resultFile))
                    {
                        using (StreamWriter outputProfile = File.CreateText(profileFile))
                        {
                            outputProfile.WriteLine("#Dwarf name:{0}", DWARF_NAME);
                            outputProfile.WriteLine("#Time: {0}", DateTime.Now.ToString());
                            outputProfile.WriteLine("#Length: {0}", solver.graph.getLength());
                            outputProfile.WriteLine("#Result time (sec): {0} ", time);
                            outputResult.WriteLine("#Result domain:");
                            int length = solver.graph.getLength();
                            for (int i = 0; i < length; i++)
                            {
                                outputResult.Write("{0} ", solver.graph.ToString(i));
                                outputResult.WriteLine();
                            }
                            outputResult.WriteLine();
                            outputProfile.WriteLine("#eof");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    throw new Exception("Error in output file");
                }
            
        }

        /// <summary>
        /// Parse input file into solver's structures.
        /// </summary>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        private void parseConfigFile(Solver solver)
        {
            // Open the file to read from.
            try
            {
                using (StreamReader sr = File.OpenText(inputFile))
                {

                    String str;
                    String[] tmpStrArray;
                    //reading the list of vertices and edges
                    int index;
                    str = sr.ReadLine();
                    solver.graph = new Graph(Convert.ToInt32(str));
                    while ((str = sr.ReadLine()) != null)
                    {
                        tmpStrArray = str.Split(':');
                        index = Convert.ToInt32(tmpStrArray[0]);
                        tmpStrArray = tmpStrArray[1].Split(' ');
                        solver.graph.edgesMatrix[index] = new int[tmpStrArray.Length];
                        for (int i = 0; i < tmpStrArray.Length; i++)
                        {
                            solver.graph.edgesMatrix[index][i] = Convert.ToInt32(tmpStrArray[i]);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception("Error in input file");
            }
        }

        /// <summary>
        /// Write settings.
        /// </summary>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        private void WriteSettings(Solver solver)
        {
            // Write general settings.
            Console.WriteLine("Kernel settings summary : ");
            Console.WriteLine("Dwarf name              : {0} ", DWARF_NAME);
            Console.WriteLine("Length                  : {0} ", solver.graph.getLength());
            Console.WriteLine("Inputfile               : {0} ", inputFile);
            Console.WriteLine("Profilefile             : {0} ", profileFile);
            Console.WriteLine("Resultfile              : {0} ", resultFile);
            Console.WriteLine();
        }

        /// <summary>Parse the command line arguments and fill the reference parameters</summary>
        /// <param name="argc">Count of command line tokens</param>
        /// <param name="argv">Command line tokens</param>
        /// <param name="inputFile">Name of input text file</param>
        /// <param name="profileFile">Name of profile file</param>
        /// <param name="resultFile">Name of result file</param>
        [DllImport(@"CliTools.dll")]
        private static extern void parseArguments(
            int argc,
            String[] argv,
            ref string inputFile,
            ref string profileFile,
            ref string resultFile
            );

        [DllImport(@"CliTools.dll")]
        private static extern void start();

        [DllImport(@"CliTools.dll")]
        private static extern void stop(ref double time);
    }
}