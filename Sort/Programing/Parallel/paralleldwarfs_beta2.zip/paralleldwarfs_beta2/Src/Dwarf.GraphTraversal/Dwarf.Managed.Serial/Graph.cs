﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Dwarf.Managed
{
    /// <summary>
    /// Presentation of Graph.
    /// </summary>
    class Graph
    {
        /// <summary>
        /// The link to the head of graph.
        /// </summary>
        private int headId;

        /// <summary>
        /// Length of graph.
        /// </summary>
        private int length;

        /// <summary>
        /// Vector for store visited vertices of graph.
        /// </summary>
        private int[] visited;

        /// <summary>
        /// Matrix for store vertices and edges of graph.
        /// </summary>
        private int[][] edgesMatrix;

        public Graph(int length)
        {
            this.length = length;
            edgesMatrix = new int[length][];
            visited = new int[length];
        }

        public int getHeadId()
        {
            return headId;
        }

        public void setHeadId(int id)
        {
            headId = id;
        }

        public int VertexCount
        {
            get { return length; }
        }

        public int GetVisited(int i)
        {
            return visited[i];
        }

        public void Visit(int i)
        {
            visited[i]++;
        }

        public int[] GetNeighbouringVertices(int index) 
        {
            return edgesMatrix[index];
        }

        public void SetNeighbouringVertices(int index, int[] vertices) {
            edgesMatrix[index] = vertices;
        }

        /// <summary>
        /// Presentation of edges for printing.
        /// </summary>
        public String ToString(int index)
        {
            StringBuilder strBldr = new StringBuilder();
            strBldr.Append(index);
            strBldr.Append(" :");
            //for (int i = 0; i < edgesMatrix[index].Length; i++)
            //{
            //    strBldr.Append(" ");
            //    strBldr.Append(edgesMatrix[index][i]);
            //}

            //strBldr.Append(". visited:");
            strBldr.Append(" Visited:");
            strBldr.Append(visited[index]);
            return strBldr.ToString();
        }
    }
}
