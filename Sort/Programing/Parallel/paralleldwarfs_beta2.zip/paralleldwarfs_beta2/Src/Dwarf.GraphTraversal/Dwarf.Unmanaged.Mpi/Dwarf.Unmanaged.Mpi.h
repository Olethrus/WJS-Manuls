#pragma once
#include <iostream>

#include <stdio.h>

#include <time.h>
#include <stack>
#include <queue>
#include "Graph.h"
#include <Windows.h>


#include <mpi.h>

// Short dwarf's description.
#define DWARF_NAME (char*)"Graph Traversal, unmanaged mpi kernel."

// Constants for output files's names
#define DWARF_NAME_OUTPUT (char*)"Dwarf.Unmanaged.Mpi"
#define NUMBER_ROOT_PROCESS 0                       // index of root process.
#define PROFILE_TXT (char*)".Profile.txt"
#define RESULT_TXT (char*)".Result.txt"

// Default size for buffer.
#define BUFFER_SIZE 1024

//Parse the command line arguments and fill the reference parameters.
typedef int (__cdecl *DLLParseArguments)(
    int,                                    //Count of command line tokens.
    char**,                                 //Command line tokens.
    char**,                                 //Name of input text file.
    char**,                                 //Name of profile text file.
    char** );                               //Name of result file.

// Write the rules of command line structure.
typedef void (__cdecl *DLLUsage)(void);

// Start the time count.
typedef void (__cdecl *DLLStart)(void);

// Stop the time count.
typedef void (__cdecl *DLLStop)(double*);

class Solver
{
private:
    void partition(deque<int>& d);
public:
    int commSize;                   // Rank of the process.
    int commRank;                   // Count of processes.

    bool isRootThread;              //true for master process

    Solver();
    ~Solver();
    //base method
    void solve(); 
    void gatherResults();
    //structure for problem.
    Graph *graph;   

};

// Settings taken from command line and input file.
class Settings
{
public:
    Settings();
    ~Settings();

    double finish();
    void start();
    int init(int argc, char** argv, Solver *solver);
    void writeResult(Solver *solver,double ExecTime);

private:
    // Input & output files.
    char* inputFile;
    char* profileFile;
    char* resultFile;

    int parseConfigFile(Solver* solver);            // Parse input file into solver's structures.
    void writeSettings(Solver *solver);             // Write settings.
    

};
