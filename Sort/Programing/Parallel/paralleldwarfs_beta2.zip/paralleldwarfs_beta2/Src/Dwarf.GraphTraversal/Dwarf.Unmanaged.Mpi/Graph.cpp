#include "Graph.h"

Graph :: Graph(int _length)
{
    this->length = _length;
    edgesMatrix = new int*[length];
    visited = new int[length];
    arrayOfcounts = new int[length];
    //initialization
    for(int i=0; i < length; i++ )
    {
        arrayOfcounts[i] = 0;
        visited[i] = 0;
    }
}

Graph :: ~Graph()
{
    //deletion of edges Matrix
    for(int i = 0;i <length;i++)
    {
        delete []edgesMatrix[i];
    }
    delete []edgesMatrix;

    //deletion visited list
    delete []visited;
}

int  Graph ::getVisited(int i)
{ 
    return visited[i]; 
}
void Graph ::setVisited(int i)
{ 
    this->visited[i]++; 
}
int Graph ::getLength()
{
    return length;
}
int Graph ::getHeadId() 
{ 
    return headId; 
}
void Graph ::setHeadId(int id) 
{ 
    headId = id; 
}
//presentation of edges for printing
string Graph ::edgesToString(int index) 
{  
    string str("");
    char buffer[20];
    //for(int i = 0; i < arrayOfcounts[index]; i++ ){
    //    str.append(" ");
    //    _itoa_s(edgesMatrix[index][i], buffer, 20, 10);
    //    str.append(buffer);
    //}
    //str.append(". Visited: ");
	str.append(" Visited: ");
    _itoa_s( visited[index], buffer, 20, 10 );
    str.append(buffer);
    return str;
}
