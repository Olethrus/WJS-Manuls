#pragma once
//#include <iostream>
//#include <windows.h>
#include <string>

using namespace::std;

// Structure of Graph for depth first search algorithm.
class Graph
{
private:
    int headId; //the link to the head of graph
    int length;
    //the visited array is int for checking of algorithm work.
    

public:
    int *visited; // the array of visited vertex[0..length)
    int **edgesMatrix; // matrix of edges
    int *arrayOfcounts; // list of length of edges for each vertex

    Graph(int _length);
    ~Graph();
    string edgesToString(int index); //presentation of edges for printing
    int  getVisited(int i);
    void setVisited(int i);
    int getLength();
    int getHeadId(); 
    void setHeadId(int id);  
};