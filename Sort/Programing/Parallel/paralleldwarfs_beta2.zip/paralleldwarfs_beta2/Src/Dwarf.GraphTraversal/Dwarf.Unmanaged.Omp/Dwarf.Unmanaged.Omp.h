#pragma once
#define _USE_MATH_DEFINES
#include <string>
#include <iostream>


#include <stdio.h>

#include <time.h>
#include <stack>
#include <queue>
#include "Graph.h"
#include <Windows.h>
#include <omp.h>
#include <hash_set>



// Short dwarf's description.
#define DWARF_NAME (char*)"Graph Traversal, unmanaged openMP kernel."

// Constants for output files's names
#define DWARF_NAME_OUTPUT (char*)"Dwarf.Unmanaged.Omp"
#define PROFILE_TXT (char*)".Profile.txt"
#define RESULT_TXT (char*)".Result.txt"

// Default size for buffer.
#define BUFFER_SIZE 1024

typedef int (__cdecl *DLLParseArguments)(
    int,                                    //Count of command line tokens.
    char**,                                 //Command line tokens.
    char**,                                 //Name of input text file.
    char**,                                 //Name of profile text file.
    char** );                               //Name of result file.

// Write the rules of command line structure.
typedef void (__cdecl *DLLUsage)(void);

// Start the time count.
typedef void (__cdecl *DLLStart)(void);

// Stop the time count.
typedef void (__cdecl *DLLStop)(double*);

class Solver
{
public:
    Solver();
    ~Solver();
    //base method
    void solve(); 
    //structure for problem.
    Graph *graph;   

};

// Settings taken from command line and input file.
class Settings
{
public:
    Settings();
    ~Settings();

    void finish(Solver *solver);
    void start();
    int init(int argc, char** argv, Solver *solver);

private:
    // Input & output files.
    char* inputFile;
    char* profileFile;
    char* resultFile;

    int parseConfigFile(Solver* solver);            // Parse input file into solver's structures.
    void writeSettings(Solver *solver);             // Write settings.

};