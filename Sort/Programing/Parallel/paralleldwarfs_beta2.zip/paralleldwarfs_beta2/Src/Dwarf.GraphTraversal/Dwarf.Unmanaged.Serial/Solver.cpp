#include "Dwarf.Unmanaged.Serial.h"


Solver :: Solver()
{

}

Solver :: ~Solver()
{    
 
}
//For the demonstration purposes of the project,
//we have chosen depth first search algorithm
void Solver::solve() 
{ 
  stack<int> s;
  //set the head of graph
  int headId = graph->getHeadId();
  graph->setVisited(headId);
  s.push(headId);
  //while stack not empty 
  while (!s.empty()) 
  {   
      //take the first element
      int u = s.top();
      //for all edges of current vertex
      bool hasNoVisited = true;
      for(int j = 0; j < graph->arrayOfcounts[u]; j++)
      {
          int count =  graph->getVisited(graph->edgesMatrix[u][j]);
          if(count == 0) 
          {   
              //adding new vertex to work stack
              hasNoVisited = false;
              s.push(graph->edgesMatrix[u][j]);
              graph->setVisited(graph->edgesMatrix[u][j]);
              break;
          }
      }
      if(hasNoVisited)
      {
        s.pop();
      }
  }
}



