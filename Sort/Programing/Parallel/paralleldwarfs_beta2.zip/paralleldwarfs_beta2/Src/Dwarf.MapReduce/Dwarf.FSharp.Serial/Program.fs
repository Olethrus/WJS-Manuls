﻿#light

open System
open System.Collections.Generic
open System.Runtime.InteropServices
open Dwarf.Managed

[<DllImport(@"CliTools.dll")>]
extern void start()

[<DllImport(@"CliTools.dll")>]
extern double finish()

[<DllImport(@"CliTools.dll")>]
extern void usage()

open MapReduceFSharpMethod
 
let solve(dwarfConfigurator : Configurator) : Dictionary<String, int> =
    dwarfConfigurator.WriteSettings()
    dwarfConfigurator.GetData() |> map |> reduce

let main() =
    let args = System.Environment.GetCommandLineArgs()
    let dwarfConfigurator = new Configurator(args)
    start()
    let stringTotal = solve(dwarfConfigurator)   
    let time = finish()
    dwarfConfigurator.Close(time, stringTotal)  

main()
