﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace Dwarf.Managed
{
    /// <summary>Settings taken from command line</summary>
    /// 
    class Settings
    {
        public string dwarfName;                    // name of the dwarf 
        public string inputFile;                    // input file
        public string outputFile;                   // output file
        public int log;                             // log (benchmark/debug)

        private static int maxArraySize = 5000;     // default size for string

        /// <summary>Get parameters</summary>
        /// <param name="args">Command line parameters</param>
        /// 
        public void GetSettings(string[] args)
        {
            dwarfName = "Dwarf.MapReduce";

            if (serialParseArguments(
                    args.Length,
                    args,
                    ref log,
                    ref inputFile,
                    ref outputFile) != 0)
            {                                   // not all tokens consist in argc
                throw new Exception();          // give the sign for execution to be stopped
            }
        }

        /// <summary>New object of settings</summary>
        /// 
        public Settings()
        {
            inputFile = new String(new char[maxArraySize]);
            outputFile = new String(new char[maxArraySize]);
        }

        /// <summary>Write settings</summary>
        /// 
        public void WriteSettings()
        {
            Console.WriteLine("Kernel settings summary:");
            Console.WriteLine("Dwarf name          : " + dwarfName);
            Console.WriteLine("Log level           : " + log);
            Console.WriteLine("InputFile           : " + inputFile);
            Console.WriteLine("OutputFile          : " + outputFile);
            Console.WriteLine("\n");
        }

        /// <summary>Parse the command line arguments and fill the reference parameters</summary>
        /// <param name="argc">Count of command line tokens</param>
        /// <param name="argv">Command line tokens</param>
        /// <param name="log">Settings log (debug/benchmark)</param>
        /// <param name="inputFile">Name of input text file</param>
        /// <param name="outputFile">Name of output file</param>
        /// <returns>0 if all tokens consist in argv</returns>
        /// 
        [DllImport(@"CliTools32.dll")]
        private static extern int serialParseArguments(
            int argc,
            String[] argv,
            ref int log,
            ref string inputFile,
            ref string outputFile
            );
        
        /// <summary>Write the rules of command line structure</summary>
        /// 
        [DllImport(@"CliTools32.dll")]
        private static extern void serialUsage();
    }
}
