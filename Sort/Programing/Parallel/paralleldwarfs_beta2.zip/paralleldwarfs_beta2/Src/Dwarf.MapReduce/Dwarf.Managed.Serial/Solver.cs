﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Dwarf.Managed
{
    /// <summary>Solve the MapReduce problem without parallelization</summary>
    ///
    class Solver
    {
        private Configurator dwarfConfigurator;              // processed settings from command line
        private string mainContent;                          // content for parsing
        private Dictionary<String, int> stringTotal;         // final result Dictionary "word" - "count of entries"

        /// <summary>Construct the new solver</summary>
        /// <param name="dwarfConfigurator">Processed command line arguments</param>
        /// 
        public Solver(ref Configurator dwarfConfigurator)
        {
            this.dwarfConfigurator = dwarfConfigurator;
            dwarfConfigurator.WriteSettings();               // write settings to console and profile file
            mainContent = dwarfConfigurator.GetData();
        }

        /// <summary>Non-parallelized method of solving</summary>
        ///
        public void Solve()
        {
            var currentData = new MapReduceBaseMethod(mainContent); // create new method object with private member mainString
            currentData.FunctionMap();                              // execute Map
            currentData.FunctionReduce();                           // execute Reduce
            this.stringTotal = currentData.GetStringTotal();        // method Dictionary result is our solver result
        }

        /// <summary>Problem results output</summary>
        /// <param name="time">Spent time</param>
        ///
        public void Finish(double time)
        {
            dwarfConfigurator.Close(time, stringTotal);
        }
    }
}
