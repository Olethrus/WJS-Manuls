﻿using System;
using System.Linq;
using System.Threading;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Dwarf.Managed
{
    /// <summary>Solve the MapReduce problem with Threading parallelization</summary>
    ///
    class Solver
    {
        private Configurator dwarfConfigurator;             // processed settings from command line
        private string mainContent;                          // content for parsing
        private Dictionary<String, int> stringTotal;         // final result Dictionary "word" - "count of entries"
        private MapReduceBaseMethod[] currentData;           // array of the solving method objects

        /// <summary>Construct the new solver</summary>
        /// <param name="dwarfConfigurator">Processed command line arguments</param>
        /// 
        public Solver(ref Configurator dwarfConfigurator)
        {
            this.dwarfConfigurator = dwarfConfigurator;
            dwarfConfigurator.WriteSettings();               // write settings to console and profile file
            mainContent = dwarfConfigurator.GetData();
            InitParallelization(dwarfConfigurator.GetThreadCount());
        }

        /// <summary>Thread-parallelized method MapReduce</summary>
        ///
        public void Solve()
        {

            for (int i = 0; i < dwarfConfigurator.GetThreadCount(); i++)
            {
                var currentThreadStart = new ThreadStart(currentData[i].BeginMethod);
                var mapThread = new Thread(currentThreadStart);   // create threads, executing  method ContentData.BeginMethod
                mapThread.Start();                                // each thread runs the non-parallelised method
            }
            //Thread.Sleep(10);                                   // minimal stub for main thread
            stringTotal = new Dictionary<string, int>();
            SumThreadResult(dwarfConfigurator.GetThreadCount());
        }

        /// <summary>Init the configuration. Creating objects for parallel processing</summary>
        /// <param name="threadCount">Count of threads used for parallelization</param>
        ///
        private void InitParallelization(int threadCount)
        {
            currentData = new MapReduceBaseMethod[threadCount];
            int contentSize = mainContent.Length;
            int interval = 1 + contentSize / threadCount;   // partitioning the String content (same parts for all threads)
            int leftBoard = 0;
            int part = 0;
            while (part < threadCount - 1)
            {
                int certainInterval = interval;
                while (mainContent[leftBoard + certainInterval] != ' ') // search of middle-word space
                {
                    certainInterval++;
                }
                certainInterval++;
                currentData[part] = new MapReduceBaseMethod(mainContent.Substring(leftBoard, certainInterval));
						            // create the contents for all parallel methods [0..threadCount-1)
                part++;
                leftBoard += certainInterval;
            }
            currentData[threadCount - 1] = new MapReduceBaseMethod(mainContent.Substring(leftBoard));
                                    // create the contents for the (threadCount-1) parallel method
        }

        /// <summary>Summarize the results of threads</summary>
        /// <param name="threadCount">Count of threads used for parallelization</param>
        ///
        private void SumThreadResult(int threadCount)
        {
            try
            {
                Monitor.Enter(currentData[0].GetStringTotal());
                stringTotal = currentData[0].GetStringTotal();
                for (int i = 1; i < threadCount; i++)
                {
                    Monitor.Enter(currentData[i].GetStringTotal());         // use the Monitor for syncronization of threads outputs
                                                                            // it guarantees that we won't work with result before the method end
                    foreach (var pair in currentData[i].GetStringTotal())
                    {
                        int value = pair.Value;
                        if (stringTotal.ContainsKey(pair.Key))              // check insertion of each key
                        {
                            value += stringTotal[pair.Key];                 // if inserted, add value and refresh 
                            stringTotal.Remove(pair.Key);
                        }
                        stringTotal.Add(pair.Key, value);                   
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: {0}", e.Message);
            }
        }

        /// <summary>Problem results output</summary>
        /// <param name="time">Spent time</param>
        ///
        public void Finish(double time)
        {
            dwarfConfigurator.Close(time, stringTotal);
        }
    }
}