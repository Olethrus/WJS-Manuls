#include "stdafx.h"
#include "Settings.h"
#include <string.h>

static DLLParseArguments pDLLParseArguments;		// method 'parseArguments' loaded from CliTools.dll
static HINSTANCE hInstDll;							// instanse of CliTools.dll

using namespace std;

Settings::Settings()
{
    inputFile = new char[maxArraySize];
	resultFile = new char[maxArraySize];
	profileFile = new char[maxArraySize];

    inputFile[0] = resultFile[0] = profileFile[0] = '\0';
}

void Settings::GetSettings(int argc, char **argv)
{
	dwarfName = "Dwarf.MapReduce";

    //Load the dll into the address space
	hInstDll = LoadLibraryA("CliTools.dll");
    if (hInstDll == 0) 
    {
        printf("Error while loading CliTools.dll.");
        return;
    }

    // Retrieve a pointer to the factory function
    pDLLParseArguments = 
        (DLLParseArguments) GetProcAddress(hInstDll, "parseArgumentsThreading");


    if ((pDLLParseArguments)(argc, argv, &inputFile, &profileFile, &resultFile, &threadCount)) 
    {
		FreeLibrary(hInstDll);
		throw new exception("Function pointer with incorrect type returned from CliTools.dll\n");
    }
}

char* Settings::StringSettings()
{ 
	char* stringSettings = new char[maxArraySize];
	char* stringSettings1 = "Kernel settings summary: ";
	char* stringSettings2 = "\nDwarf name        : ";
	char* stringSettings3 = "\nInputFile         : ";
	char* stringSettings4 = "\nResultFile        : ";
	char* stringSettings5 = "\nProfileFile       : ";

	strcpy_s(stringSettings, maxArraySize, stringSettings1);
	strcat_s(stringSettings, maxArraySize, stringSettings2);
	strcat_s(stringSettings, maxArraySize, dwarfName);
	strcat_s(stringSettings, maxArraySize, stringSettings3);
	strcat_s(stringSettings, maxArraySize, inputFile);
	strcat_s(stringSettings, maxArraySize, stringSettings4);
	strcat_s(stringSettings, maxArraySize, resultFile);
	strcat_s(stringSettings, maxArraySize, stringSettings5);
	strcat_s(stringSettings, maxArraySize, profileFile);

	return stringSettings;
}