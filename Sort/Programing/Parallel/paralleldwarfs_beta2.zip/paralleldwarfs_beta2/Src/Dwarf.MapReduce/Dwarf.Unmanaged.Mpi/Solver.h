#include "Configurator.h"
#include <map>
#include <list>
#include <string>

#ifndef SOLVER_H_
#define SOLVER_H_

using namespace std;

class Solver
{
public:
	Solver(Configurator* configurator, int argc, char** argv);
	void Solve();
	void Finish(double time);
	
private:
	int rank;								 // rank of process (MPI)
    int commsize;							 // process size
    static const int root = 0;				 // index of root process. By consideration, equal to 0

	Configurator *dwarfConfigurator;
	int *threadBounds;						 // boundary indexes of string part of each mpi-proccess

	map<string, int> stringTotal;			 // final dictionary for counting the entries of chars in the content
	list<string> stringEntries;				 // auxillary list for counting the of chars in the content
	int contentSize;						 // size of *mainContent
	char *mainContent;						 // content for parsing
	string TransformCharFragment(int begin, int end);
	void GetContent();
	void InitParallelization(int threadCount);
	void Map();
	void Reduce();
};

#endif
