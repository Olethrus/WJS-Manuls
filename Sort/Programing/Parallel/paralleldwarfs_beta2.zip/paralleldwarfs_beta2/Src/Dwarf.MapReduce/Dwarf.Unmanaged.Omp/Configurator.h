#pragma once

#include "Settings.h"

class Configurator
{
public:
	Configurator(int argc, char** argv);
	void GetContent(char **mainContent, int *contentSize);
	void WriteSettings();
	void Close(double time, map<string, int> stringTotal);
	int GetThreadCount();

private:
	Settings* settings;
	FILE *profile;
};
