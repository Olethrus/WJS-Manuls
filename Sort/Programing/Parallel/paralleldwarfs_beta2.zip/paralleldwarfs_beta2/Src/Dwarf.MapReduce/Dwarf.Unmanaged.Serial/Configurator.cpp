#include "Configurator.h"

Configurator::Configurator(int argc, char** argv)
{
    settings = new Settings();
	settings -> GetSettings(argc, argv);
	fopen_s(&profile, settings -> profileFile, "wb");
}

void Configurator :: WriteSettings()
{
    char* stringSettings = settings -> StringSettings();
	printf(stringSettings);
    fprintf(profile, stringSettings);
}

void Configurator :: GetContent(char **mainContent, int *contentSize)
{
	FILE *file;	
	fopen_s(&file, settings -> inputFile, "rb");			// Opening the input file
	fseek (file, 0 , SEEK_END);								// move the file pointer on the end of content file		
	*contentSize = ftell (file);							// size of all file		

	rewind (file);											// reposition the file pointer to the file beginning
	*mainContent = (char*) malloc (sizeof(char)*(*contentSize));	// dynamic memory memory allocation for [contentSize] char array
	fread (*mainContent, sizeof(char), *contentSize, file);			// read the file content to char array
	
	fclose(file);
}

void Configurator :: Close(double time, map<string, int> stringTotal)
{
	printf("\nClock time   (sec): %.8f \r\n", time); 
	fprintf(profile, "\nClock time   (sec): %.8f \r\n", time); 
	FILE *result;	
	fopen_s(&result, settings -> resultFile, "wb");
	for (map<string, int>::const_iterator it = stringTotal.begin(); it != stringTotal.end(); ++it)
	{												// traverse all the map
		string key = it -> first;					// get all the keys
		int value = it -> second;					// get all the values
		fprintf(result, "%s", key.c_str());		// print to the outputfile
		fprintf(result, " %i\r\n", value);
	}
	fclose(result);
	fclose(profile);
}