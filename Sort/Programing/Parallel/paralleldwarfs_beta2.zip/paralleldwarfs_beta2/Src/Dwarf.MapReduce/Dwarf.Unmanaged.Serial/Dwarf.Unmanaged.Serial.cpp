// Dwarf.Unmanaged.Serial.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "Settings.h"

using namespace std;

static DLLUsage pDLLUsage;							// method 'usage' loaded from CliTools.unmanaged.dll
static DLLStart pDLLStart;							// method 'start' [time count] loaded from CliTools.unmanaged.dll
static DLLStop pDLLStop;							// method 'stop' [time count] loaded from CliTools.unmanaged.dll
static HINSTANCE hInstDll;							// instanse of CliTools.unmanaged.dll

void start();
void stop(double*);

void main(int argc, char** argv)
{
								//  load the dll into the address space
	hInstDll = LoadLibraryA("CliTools.dll");
    if (hInstDll == 0) 
    {
        printf("Error while loading CliTools.dll");
        return;
    }
								// retrieve a pointer to the factory function
    pDLLUsage = 
        (DLLUsage) GetProcAddress(hInstDll, "usage");
	pDLLStop = 
        (DLLStop) GetProcAddress(hInstDll, "stop");
	pDLLStart = 
        (DLLStart) GetProcAddress(hInstDll, "start");

	try{
		double time;
		Configurator* dwarfConfigurator = new Configurator(argc, argv);
		Solver* mapreducesolver = new Solver(dwarfConfigurator);// create new Solver (current problem with initial data)
		
		(pDLLStart)();										    // start the time count
		mapreducesolver -> Solve();								// solve the current problem
		(pDLLStop)(&time);                                      // stop the time count
		mapreducesolver -> Finish(time);						// write results  
	}
	catch(exception e)
	{		
		(pDLLUsage)();											// incorrectness in Solver constructor. print right usage rules
	}		
}