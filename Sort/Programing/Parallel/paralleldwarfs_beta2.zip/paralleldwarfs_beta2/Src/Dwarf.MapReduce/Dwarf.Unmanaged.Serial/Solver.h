#include "Configurator.h"
#include <map>
#include <list>
#include <string>

#ifndef SOLVER_H_
#define SOLVER_H_

using namespace std;

class Solver
{
public:
	Solver(Configurator* configurator);
	void Solve();
	void Finish(double time);
	
private:
	Configurator* dwarfConfigurator;
	
	map<string, int> stringTotal;			 // final dictionary for counting the entries of chars in the content
	list<string> stringEntries;				 // auxillary list for counting the of chars in the content
	int contentSize;						 // size of *mainContent
	char *mainContent;						 // content for parsing
	string TransformCharFragment(int begin, int end);
	void GetContent();
	void Map();
	void Reduce();
};

#endif
