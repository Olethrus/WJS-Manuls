﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;

namespace Dwarf.Managed
{
    /// <summary>Class for command line settings processing, IO management</summary>
    /// 
    public class Configurator
    {
        private Settings settings;
        private StreamWriter profileWriter;

        /// <summary>Cli parameters initialization</summary>
        /// <param name="args">Command line parameters</param>
        /// <param name="threadCount">Default count of threads in processing</param>
        /// 
        public Configurator(string[] args)
        {
            settings = new Settings();
            settings.GetSettings(args);
            if (settings.threadCount == 0)
            {
                settings.threadCount = System.Environment.ProcessorCount;     // if command line parameter 'threadCount' is not specified, fill it by default
            }
            if (settings.profileFile != "")
            {
                profileWriter = new StreamWriter(new FileStream(settings.profileFile, FileMode.Create, FileAccess.Write, FileShare.Write));
            }
        }

        /// <summary>Write settings</summary>
        ///
        public void WriteSettings()
        {
            String stringSettings = settings.StringSettings();
            Console.WriteLine(stringSettings);               // write to console
            if (profileWriter != null)                       // write to profile file
            {
                profileWriter.WriteLine(stringSettings);
            }
        }

        /// <summary>Close the profile and result files</summary>
        /// <param name="time">Execution time</param>
        /// <param name="stringTotal">Set of "key - value" pairs</param>
        ///
        public void Close(double time, IDictionary<String, int> stringTotal)
        {
            String timeResult = "Clock time        : " + time.ToString() + " (sec)";
            Console.WriteLine(timeResult);
            if (profileWriter != null)                      // write to profile file
            {
                profileWriter.WriteLine(timeResult);
                profileWriter.Close();
            }

            if (settings.resultFile != "")                  // write to outputfile
            {
                StreamWriter resultWriter = new StreamWriter(new FileStream(settings.resultFile, FileMode.Create, FileAccess.Write, FileShare.Write));
                foreach (var pair in stringTotal)           // write each key-value pair in the Dictionary result 
                {
                    resultWriter.WriteLine(pair.Key + " " + pair.Value);
                }
                resultWriter.Close();
            }
        }

        /// <summary>Get cityCount and fill distances[cityCount, cityCount] matrix</summary>
        /// <return>Text for search</return>
        ///
        public string GetData()
        {
            // Open the file to read from.
            FileStream stream = null;
            StreamReader reader = null;
            try
            {
                stream = new FileStream(settings.inputFile, FileMode.Open, FileAccess.Read, FileShare.Read);
                reader = new StreamReader(stream);
                return reader.ReadToEnd();         // read the other text in file - content
            }
            catch (Exception e)
            {
                Console.WriteLine("Cannot correctly read the file: {0}", e.Message);
            }
            finally
            {
                if (reader != null)
                {
                    reader.Close();
                }
            }
            return "";
        }

        public int GetThreadCount()
        {
            return settings.threadCount;
        }
    }
}