﻿#light

module Constants

/// <summary>
/// Short dwarf's description.
/// </summary>
let DWARF_NAME = "Sparse Linear Algebra, managed FSharp tpl kernel"
