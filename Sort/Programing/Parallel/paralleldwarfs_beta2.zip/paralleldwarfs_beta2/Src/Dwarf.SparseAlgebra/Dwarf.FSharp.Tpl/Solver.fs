﻿#light

module Dwarf_Managed

open System
open System.Collections.Generic
open System.Runtime.InteropServices
open System.Threading
open System.Threading.Tasks

/// <summary>
/// Write the rules of command line structure.
/// </summary>
[<DllImport(@"CliTools.dll")>]
extern void usage();

/// <summary>
/// Get settings from the command line.
/// </summary>
/// <param name="args">
/// Cli params.
/// </param>
/// <param name="dlasolver">
/// Instance of Solver.
/// </param>
let getSettings(args : String[]) =
    Dwarf_Managed_Common.Init(args)    
    
let Solve() =  
    
    let taskRow i =        
        //The C# compler/runtime is not
        //hoisting the array addressing out of the loop
        //hence the following makes a big difference
        //result[i] = 0;
        let mutable cell = 0.0
        //Loop for number of non-zero elements in current row
        for j = Dwarf_Managed_Common.row_ptr.[i] - 1 to Dwarf_Managed_Common.row_ptr.[i + 1] - 2 do
            //result[i] += vector[col_ind[j] - 1] * val[j];
            cell <- cell + Dwarf_Managed_Common.vector.[Dwarf_Managed_Common.col_ind.[j] - 1] * Dwarf_Managed_Common.value.[j]
        //see above comment       
        
        Dwarf_Managed_Common.result.[i] <- cell
    
    //Loop for number of rows in matrix
    do Parallel.For(0,Dwarf_Managed_Common.rowNum,new Action<int>(taskRow))      
    
 
let main() =   
    
    try
        let args = System.Environment.GetCommandLineArgs()
        getSettings(args)                          // Get settings from the command line.

        Dwarf_Managed_Common.Start()               // Start new time count.
        for i = 0 to 200 do
            Solve()                                // Solve the current problem.
        Dwarf_Managed_Common.Finish()              // Stop the time count and write results.
        
    with e -> Console.WriteLine(e.Message); Console.WriteLine(e.StackTrace); usage()
         
main()








        
