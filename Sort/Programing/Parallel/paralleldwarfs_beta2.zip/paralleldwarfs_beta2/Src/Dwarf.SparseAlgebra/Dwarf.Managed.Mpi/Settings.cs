﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Globalization;
using System.Security;
using System.Security.Permissions;

namespace Dwarf.Managed
{
    /// <summary>
    /// Settings taken from command line and input file.
    /// </summary>
    class Settings
    {
        /// <summary>
        /// Number of root process.
        /// </summary>
        public const int ROOT_PROCESS = 0;

        /// <summary>
        /// Input & output files.
        /// </summary>
        private String inputFile;
        private String profileFile;
        private String resultFile;

        /// <summary>
        /// Short dwarf's description.
        /// </summary>
        private const String DWARF_NAME = "Sparse Linear Algebra, managed mpi.net kernel.";

        /// <summary>
        /// Constants for output files's names
        /// </summary>
        private const String DWARF_NAME_OUTPUT = "Dwarf.Managed.Mpi";
        private const String PROFILE_TXT = ".Profile.txt";
        private const String RESULT_TXT = ".Result.txt";

        /// <summary>
        /// Default size for buffer.
        /// </summary>
        private const int BUFFER_SIZE = 1024;

        /// <summary>
        /// Constructor that init strings.
        /// </summary>
        public Settings()
        {
            inputFile = new String(new char[BUFFER_SIZE]);
            profileFile = new String(new char[BUFFER_SIZE]);
            resultFile = new String(new char[BUFFER_SIZE]);
        }

        /// <summary>
        /// Problem results output.
        /// </summary>
        /// <param name="slasolver">
        /// Instance of Solver.
        /// </param>
        public void Finish(Solver slasolver)
        {
            double time = 0; ;
            stop(ref time);

            Console.WriteLine();
            Console.WriteLine("Clock time (sec): {0} ", time.ToString("F8", CultureInfo.InvariantCulture));

              try
                {
                    using (StreamWriter outputResult = File.CreateText(resultFile))
                    {
                        using (StreamWriter outputProfile = File.CreateText(profileFile))
                        {
                            outputProfile.WriteLine("#Dwarfname:{0}", DWARF_NAME);

                            outputProfile.WriteLine("#Time: {0}", DateTime.Now.ToString());

                            outputProfile.WriteLine("#Matrix Row Number: {0}", slasolver.rowNum);
                            outputProfile.WriteLine("#Result time (sec): {0}", time.ToString("F8", CultureInfo.InvariantCulture));
                            outputResult.WriteLine("#Result domain:");
                            for (int i = 0; i < slasolver.rowNum; i++)
                            {
                                if ((i != 0) && (i % 20) == 0) outputResult.WriteLine();
                                outputResult.Write("{0} ", slasolver.result[i].ToString("F8", CultureInfo.InvariantCulture));
                            }
                            outputResult.WriteLine();
                            outputProfile.WriteLine("#eof");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    throw new Exception("Error in output file");
                }
            
        }

        /// <summary>
        /// Init variables, parse cli params and input file.
        /// </summary>
        /// <param name="args">
        /// Cli params.
        /// </param>
        /// <param name="slasolver">
        /// Instance of Solver.
        /// </param>
        public void Init(String[] args, Solver slasolver)
        {
            //Parse cli params.
            parseArguments(
                    args.Length,
                    args,
                    ref inputFile,
                    ref profileFile,
                    ref resultFile);

            //Parse input file.
            parseConfigFile(slasolver);

            // write settings if it's needed
            WriteSettings(slasolver);
        }

        /// <summary>
        /// Start the time count.
        /// </summary>
        public void Start()
        {
            start();
        }

        /// <summary>
        /// Get one line from stream.
        /// </summary>
        /// <param name="slasolver">
        /// Stream to get from.
        /// </param>
        private static String GetLine(StreamReader sr)
        {
            String s = sr.ReadLine();

            //Avoid comments lines.
            while (s.StartsWith("#") || s.StartsWith("//"))
            {
                s = sr.ReadLine();
            }

            return s;

        }

        /// <summary>
        /// Parse input file into solver's structures.
        /// </summary>
        /// <param name="slasolver">
        /// Instance of Solver.
        /// </param>
        private void parseConfigFile(Solver slasolver)
        {
            // Open the file to read from.
            try
            {
                using (StreamReader sr = File.OpenText(inputFile))
                {
                    String str;

                    //Get number of rows.
                    slasolver.rowNum = int.Parse(GetLine(sr));

                    //Get number of non-zero values.
                    slasolver.valNum = int.Parse(GetLine(sr));

                    //Init arrays.
                    slasolver.val = new double[slasolver.valNum];
                    slasolver.col_ind = new int[slasolver.valNum];
                    slasolver.row_ptr = new int[slasolver.rowNum + 1];
                    slasolver.vector = new double[slasolver.rowNum];
                    slasolver.result = new double[slasolver.rowNum];

                    int lastCount = -1;
                    int count = -1;

                    //get val array of CRS
                    str = GetLine(sr);
                    for (int i = 0; i < slasolver.valNum; i++)
                    {
                        lastCount = count + 1;
                        count = str.IndexOf(' ', lastCount);

                        slasolver.val[i] = double.Parse(str.Substring(lastCount, count - lastCount), CultureInfo.InvariantCulture);
                    }

                    //get col_ind array of CRS
                    count = -1;
                    str = GetLine(sr);
                    for (int i = 0; i < slasolver.valNum; i++)
                    {
                        lastCount = count + 1;
                        count = str.IndexOf(' ', lastCount);

                        slasolver.col_ind[i] = int.Parse(str.Substring(lastCount, count - lastCount), CultureInfo.InvariantCulture);
                    }

                    //get row_ptr array of CRS
                    count = -1;
                    str = GetLine(sr);
                    for (int i = 0; i < slasolver.rowNum + 1; i++)
                    {
                        lastCount = count + 1;
                        count = str.IndexOf(' ', lastCount);

                        slasolver.row_ptr[i] = int.Parse(str.Substring(lastCount, count - lastCount), CultureInfo.InvariantCulture);
                    }

                    //get vector
                    count = -1;
                    str = GetLine(sr);
                    for (int i = 0; i < slasolver.rowNum; i++)
                    {
                        lastCount = count + 1;
                        count = str.IndexOf(' ', lastCount);

                        slasolver.vector[i] = double.Parse(str.Substring(lastCount, count - lastCount), CultureInfo.InvariantCulture);
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Console.WriteLine(ex.StackTrace);
                throw new Exception("Error in input file");
            }
        }

        /// <summary>
        /// Write settings.
        /// </summary>
        /// <param name="slasolver">
        /// Instance of Solver.
        /// </param>
        private void WriteSettings(Solver slasolver)
        {
            // Write general settings.
            Console.WriteLine("Kernel settings summary : ");
            Console.WriteLine("Dwarf name              : {0} ", DWARF_NAME);
            Console.WriteLine("Matrix Row Number       : {0} ", slasolver.rowNum);
            Console.WriteLine("Inputfile               : {0} ", inputFile);
            Console.WriteLine("Profilefile             : {0} ", profileFile);
            Console.WriteLine("Outputfile              : {0} ", resultFile);
            Console.WriteLine();

        }

        /// <summary>Parse the command line arguments and fill the reference parameters</summary>
        /// <param name="argc">Count of command line tokens</param>
        /// <param name="argv">Command line tokens</param>
        /// <param name="log">Settings log (debug/benchmark)</param>
        /// <param name="inputFile">Name of input text file</param>
        /// <param name="outputFile">Name of output file</param>
        [SecurityPermission(SecurityAction.Deny, Flags =
       SecurityPermissionFlag.UnmanagedCode)]
        [DllImport(@"CliTools.dll")]
        private static extern void parseArguments(
           int argc,
            String[] argv,
            ref string inputFile,
            ref string profileFile,
            ref string resultFile
            );

        /// <summary>
        /// Start the time count.
        /// </summary>
        [SecurityPermission(SecurityAction.Deny, Flags =
       SecurityPermissionFlag.UnmanagedCode)]
        [DllImport(@"CliTools.dll")]
        private static extern void start();

        /// <summary>
        /// Stop the time count.
        /// </summary>
        /// <param name="time">
        /// Value of the time.
        /// </param>
        [SecurityPermission(SecurityAction.Deny, Flags =
       SecurityPermissionFlag.UnmanagedCode)]
        [DllImport(@"CliTools.dll")]
        private static extern void stop(ref double time);
    }
}
