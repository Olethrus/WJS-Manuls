// Dwarf.Unmanaged.Serial.cpp : Defines the entry point for the console application.
//

#include "Dwarf.Unmanaged.Omp.h"

using namespace std;

// The settings for this dwarf.
static Settings* settings;

// Get settings from the command line.
static int getSettings(int argc, char** argv, Solver *slasolver) 
{
    settings = new Settings();
    if (settings->init(argc,argv,slasolver))    //Parse all arguments for dwarf.
    {            
        delete settings;
        return -1;
    }

    return 0;
}

// Point of the program start.
void main(int argc, char** argv)
{   
    Solver* slasolver = new Solver();        

    if (getSettings(argc, argv, slasolver))     // Get settings from the command line.
    {
        delete slasolver;
        exit(-1);
    }

    settings->start();                          // Start new time count.
    //This line of code is used for decrease of input file size.
	//Such modification would reduce the input file size, 
	//but the algorithm is still belongs dwarf.
	//Also this line does not affect the result.
	for (int k = 0; k < 200; k ++)
    slasolver->solve();                         // Solve the current problem.
    settings->finish(slasolver);                // Stop the time count and write results.

    delete settings;

    delete slasolver;
}
