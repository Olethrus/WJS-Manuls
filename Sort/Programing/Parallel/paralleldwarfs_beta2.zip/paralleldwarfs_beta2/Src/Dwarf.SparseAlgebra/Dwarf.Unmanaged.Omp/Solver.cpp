#include "Dwarf.Unmanaged.Omp.h"

//Init arrays.
Solver :: Solver()
{
    val = 0;
    col_ind = 0;
    row_ptr = 0;
    vector = 0;
    result = 0;

    rowNum = 0;
    valNum = 0;
}

//Dispose arrays
Solver :: ~Solver()
{    
    delete val;
    delete col_ind;
    delete row_ptr;
    delete vector;
    delete result;
}

// OpenMP based method for sparse matrix-vector multiplication.
void Solver::solve() 
{ 
	// openMP directive
    #pragma omp parallel for
	for (int i = 0; i < rowNum; i++)
	{
		//the C++ compiler is not hoisting the array access out of the loop
		//hence the use of cell
        //result[i] = 0;
		double cell = 0.0;
		for (int j = row_ptr[i] - 1; j < row_ptr[i + 1] - 1; j ++ )     // Loop for number of non-zero elements in current row
		{
			// result[i] += vector[col_ind[j] - 1] * val[j];
			cell += vector[col_ind[j] - 1] * val[j];
		}
		// See above
		result[i] = cell;
	}
}