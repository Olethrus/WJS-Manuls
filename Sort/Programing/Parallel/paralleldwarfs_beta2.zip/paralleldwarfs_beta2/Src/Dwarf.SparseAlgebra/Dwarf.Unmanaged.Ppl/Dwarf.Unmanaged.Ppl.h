#pragma once

#include <string>
#include <iostream>
#include <math.h>

#include <windows.h>

#include <stdio.h>
#include <tchar.h>
#include <time.h>

#include <ppl.h>

// Short dwarf's description.
#define DWARF_NAME (char*)"Sparse Linear Algebra, unmanaged ppl kernel."

// Constants for output files's names
#define DWARF_NAME_OUTPUT (char*)"Dwarf.Unmanaged.Ppl"
#define PROFILE_TXT (char*)".Profile.txt"
#define RESULT_TXT (char*)".Result.txt"

// Default size for buffer.
#define BUFFER_SIZE 1024

//Parse the command line arguments and fill the reference parameters.
typedef int (__cdecl *DLLParseArguments)(
    int,                                    //Count of command line tokens.
    char**,                                 //Command line tokens.
    char**,                                 //Name of input text file.
    char**,                                 //Name of profile text file.
    char** );                               //Name of result file.

// Write the rules of command line structure.
typedef void (__cdecl *DLLUsage)(void);

// Start the time count.
typedef void (__cdecl *DLLStart)(void);

// Stop the time count.
typedef void (__cdecl *DLLStop)(double*);

// Solve the Dense Linear Algebra problem with Serial parallelization.
class Solver
{
public:
    Solver();               //Constructor
    ~Solver();              //Destructor

    void solve();
    int rowNum;             //Number of rows in sparse matrix
    int valNum;             //Number of non-zero values in sparse matrix

    //sparse matrix in Compressed Row Storage (CRS) format
    double *val;
    int *col_ind;
    int *row_ptr;

    double *vector;         //vector
    double *result;         //result vector
	
private:

};

// Settings taken from command line and input file.
class Settings
{
public:
    Settings();             //Constructor
    ~Settings();            //Destructor

    void finish(Solver *dlasolver);
    void start();
    int init(int argc, char** argv, Solver *dlasolver);
	
private:

    // Input & output files.
    char* inputFile;
    char* profileFile;
    char* resultFile;

    // Parse input file into solver's structures.
    int parseConfigFile(Solver* dlasolver); 
    
    // Write settings.
    void writeSettings(Solver *dlasolver);
};
