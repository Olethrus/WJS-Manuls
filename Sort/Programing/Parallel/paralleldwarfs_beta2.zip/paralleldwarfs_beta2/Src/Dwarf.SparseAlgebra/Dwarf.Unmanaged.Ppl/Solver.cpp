#include "Dwarf.Unmanaged.Ppl.h"

using namespace Concurrency;

//Init arrays.
Solver :: Solver()
{
    val = 0;
    col_ind = 0;
    row_ptr = 0;
    vector = 0;
    result = 0;

    rowNum = 0;
    valNum = 0;
}

//Dispose arrays
Solver :: ~Solver()
{    
    delete val;
    delete col_ind;
    delete row_ptr;
    delete vector;
    delete result;
}

// PPL based method for matrix-matrix multiplication.
void Solver::solve() 
{
	// Loop for number of rows in matrix
	parallel_for(0, rowNum, [&](int i) {
		//the C++ compiler is not hoisting the array access out of the loop
		//hence the use of cell
        //result[i] = 0;
		double cell = 0.0;
        for (int j = row_ptr[i] - 1; j < row_ptr[i + 1] - 1; j ++ )     // Loop for number of non-zero elements in current row
        {
            //result[i] = result[i] + vector[col_ind[j] - 1] * val[j];
            cell += vector[col_ind[j] - 1] * val[j];
        }
		this->result[i] = cell;
    });
	
}