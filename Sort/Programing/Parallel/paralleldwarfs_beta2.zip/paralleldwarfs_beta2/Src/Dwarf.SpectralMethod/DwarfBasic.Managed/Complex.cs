﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DwarfConfigurator
{
#if NONET40
    /// <summary>
    /// The Complex presentation for Spectral Method problem
    /// </summary>
    [Serializable]
    public struct Complex
    {
        public double real;
        public double imag;


        public Complex(double real, double imag)
        {
            this.real = real;
            this.imag = imag;
        }

        public static Complex operator +(Complex c1, Complex c2)
        {
            return new Complex(c1.real + c2.real, c1.imag + c2.imag);
        }

        public static Complex operator -(Complex c1, Complex c2)
        {
            return new Complex(c1.real - c2.real, c1.imag - c2.imag);
        }

        public static Complex operator *(Complex c1, Complex c2)
        {
            return new Complex((c1.real * c2.real) - (c1.imag * c2.imag), (c1.real * c2.imag) + (c1.imag * c2.real));
        }

        public override string ToString()
        {
            return (System.String.Format("{0} {1}", real.ToString("F01"), imag.ToString("F01")));
        }
    }
#endif
}
