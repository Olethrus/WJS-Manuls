﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Numerics;

namespace DwarfConfigurator
{
    public class DataModel
    {
        /// <summary>
        /// Short dwarf's description.
        /// </summary>
        public String DWARF_NAME;

        /// <summary>
        /// Constants for output files's names
        /// </summary>
        public String DWARF_NAME_OUTPUT;

        public const int ROOT_PROCESS = 0;
        /// <summary>
        /// Common MPI objects, values, and tests
        /// </summary>
        static public int MpiRoot { get { return ROOT_PROCESS; } }
        
        /// <summary>
        /// True for master process.
        /// </summary>
        public bool isRootThread = false;

        /// <summary>
        /// Row index that indicates all done to workers
        /// </summary>
        static public int AllDoneTag;

        /// <summary>
        /// Size of matrix.
        /// </summary>
        public int length;

        /// <summary>
        /// Working array.
        /// </summary>
        public Complex[][] complexArray;
    }
}
