﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Runtime.InteropServices;
using System.Diagnostics;
using System.Numerics;

namespace DwarfConfigurator
{
    class Settings
    {

        /// <summary>
        /// Input & output files.
        /// </summary>
        private String inputFile;
        private String profileFile;
        private String resultFile;

        private const String PROFILE_TXT = ".Profile.txt";
        private const String RESULT_TXT = ".Result.txt";

        /// <summary>
        /// Default size for buffer.
        /// </summary>
        private const int BUFFER_SIZE = 1024;

        public Settings()
        {
            inputFile = new String(new char[BUFFER_SIZE]);
            profileFile = new String(new char[BUFFER_SIZE]);
            resultFile = new String(new char[BUFFER_SIZE]);
        }
  

        /// <summary>
        /// Init variables, parse cli params and input file.
        /// </summary>
        /// <param name="args">
        /// Cli params.
        /// </param>
        /// <param name="dataModel">
        /// Instance of DataModel.
        /// </param>
        public void Init(String[] args, DataModel dataModel)
        { 
            //Parse cli params.
            parseArguments(
                    args.Length,
                    args,
                    ref inputFile,
                    ref profileFile,
                    ref resultFile);

            //Parse input file.
            this.parseConfigFile(dataModel);

            // write settings if it's needed
            this.WriteSettings(dataModel);
        }

        public void WriteResults(DataModel dataModel, double time)
        {
                try
                {
                    using (StreamWriter outputResult = File.CreateText(resultFile))
                    {
                        using (StreamWriter outputProfile = File.CreateText(profileFile))
                        {
                            outputProfile.WriteLine("#Dwarf name:{0}", dataModel.DWARF_NAME);

                            outputProfile.WriteLine("#Time: {0}", DateTime.Now.ToString());

                            outputProfile.WriteLine("#Length: {0}", dataModel.length);
                            outputProfile.WriteLine("#Result time (sec): {0}", time);
                            outputResult.WriteLine("#Result domain:");
                            for (int i = 0; i < dataModel.length; i++)
                            {
                                for (int j = 0; j < dataModel.length; j++)
                                {
                                    Complex c = dataModel.complexArray[i][j];
                                    outputResult.Write(" {0:F1} {1:F1} ;", c.Real, c.Imaginary);
                                }
                                outputResult.WriteLine();
                            }
                            outputResult.WriteLine();
                            outputProfile.WriteLine("#eof");
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    throw new Exception("Error in output file");
                }
            
        }

        /// <summary>
        /// Parse input file into solver's structures.
        /// </summary>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        private void parseConfigFile(DataModel dataModel)
        {
            // Open the file to read from.
            try
            {
                using (StreamReader sr = File.OpenText(inputFile))
                {
                    dataModel.length = int.Parse(GetLine(sr));
                    dataModel.complexArray = new Complex[dataModel.length][];
                    for (int i = 0; i < dataModel.length; i++)
                    {
                        dataModel.complexArray[i] = new Complex[dataModel.length];
                    }
                    String[] str;
                    for (int j = 0; j < dataModel.length; j++)
                    {
                        str = GetLine(sr).Split(';');
                        String[] complexStr;
                        for (int i = 0; i < dataModel.length; i++)
                        {
                            complexStr = str[i].Split(' ');
                            dataModel.complexArray[j][i] = new Complex(double.Parse(complexStr[0]), double.Parse(complexStr[1]));
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw new Exception("Error in input file");
            }
        }

        /// <summary>
        /// Write settings.
        /// </summary>
        /// <param name="solver">
        /// Instance of Solver.
        /// </param>
        private void WriteSettings(DataModel dataModel)
        {
            // Write general settings.
            Console.WriteLine("Kernel settings summary : ");
            Console.WriteLine("Dwarf name              : {0} ", dataModel.DWARF_NAME);
            Console.WriteLine("Length                  : {0} ", dataModel.length);
            Console.WriteLine("Input file              : {0} ", inputFile);
            Console.WriteLine("Output file             : {0} ", resultFile);
            Console.WriteLine();
        }

        /// <summary>
        /// Get one line from stream.
        /// </summary>
        /// <param name="solver">
        /// Stream to get from.
        /// </param>
        private static String GetLine(StreamReader sr)
        {
            String s = sr.ReadLine();
            //Avoid comments lines.
            while (s.StartsWith("#") || s.StartsWith("//"))
            {
                s = sr.ReadLine();
            }

            return s;

        }

        /// <summary>Parse the command line arguments and fill the reference parameters</summary>
        /// <param name="argc">Count of command line tokens</param>
        /// <param name="argv">Command line tokens</param>
        /// <param name="log">Settings log (debug/benchmark)</param>
        /// <param name="inputFile">Name of input text file</param>
        /// <param name="outputFile">Name of output file</param>
        [DllImport(@"CliTools.dll")]
        private static extern void parseArguments(
            int argc,
            String[] argv,
            ref string inputFile,
            ref string profileFile,
            ref string resultFile
            );
    }
}