SharpCrack
==========

For usage information type "SharpCrack -help".

This is a free software developed by Peter Juhasz, see License.txt.

More information and source code: http://cracker.codeplex.com