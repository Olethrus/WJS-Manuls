//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ATLActiveX.rc
//
#define IDS_PROJNAME                    100
#define IDR_ATLACTIVEX                  101
#define IDB_ATLACTIVEXCTRL              102
#define IDR_ATLACTIVEXCTRL              103
#define IDS_TITLEATLACTIVEXPROPPAGE     105
#define IDS_HELPFILEATLACTIVEXPROPPAGE  106
#define IDS_DOCSTRINGATLACTIVEXPROPPAGE 107
#define IDR_ATLACTIVEXPROPPAGE          108
#define IDD_MAINDIALOG                  109
#define IDC_MSGBOX_BN                   202
#define IDC_MSGBOX_EDIT                 203
#define IDC_FLOATPROP_STATIC            204

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        202
#define _APS_NEXT_COMMAND_VALUE         32768
#define _APS_NEXT_CONTROL_VALUE         205
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
