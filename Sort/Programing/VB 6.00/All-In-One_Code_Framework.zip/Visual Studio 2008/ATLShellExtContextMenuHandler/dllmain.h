// dllmain.h : Declaration of module class.

class CATLShellExtContextMenuHandlerModule : public CAtlDllModuleT< CATLShellExtContextMenuHandlerModule >
{
public :
	DECLARE_LIBID(LIBID_ATLShellExtContextMenuHandlerLib)
};

extern class CATLShellExtContextMenuHandlerModule _AtlModule;
