// dllmain.h : Declaration of module class.

class CATLShellExtDropHandlerModule : public CAtlDllModuleT< CATLShellExtDropHandlerModule >
{
public :
	DECLARE_LIBID(LIBID_ATLShellExtDropHandlerLib)
};

extern class CATLShellExtDropHandlerModule _AtlModule;
