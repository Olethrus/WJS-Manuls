#include "StdAfx.h"
#include "Spinning.h"


void TriggerSpinningThread()
{
}