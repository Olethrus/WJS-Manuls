========================================================================
    CONSOLE APPLICATION : CppShellGetSetFolderCustomSettings Project Overview
========================================================================

/////////////////////////////////////////////////////////////////////////////
Summary:




/////////////////////////////////////////////////////////////////////////////
References:

MSDN: SHGetSetFolderCustomSettings Function
http://msdn.microsoft.com/en-us/library/bb762199(VS.85).aspx


/////////////////////////////////////////////////////////////////////////////
Related Threads:

How to change a specific folder background color in Vista
http://social.msdn.microsoft.com/Forums/en-US/vclanguage/thread/bc768e63-1ef0-48eb-8f3b-8a7fe2bed660


/////////////////////////////////////////////////////////////////////////////
