========================================================================
    WIN32 APPLICATION : CppWindowsApplication Project Overview
========================================================================

/////////////////////////////////////////////////////////////////////////////
Use:

To be finished - Jialiang Ge


/////////////////////////////////////////////////////////////////////////////
Creation:




/////////////////////////////////////////////////////////////////////////////
References:

MSDN: About Window Classes 
http://msdn.microsoft.com/en-us/library/ms633574.aspx

Message Cracker Wizard for Win32 SDK Developers
http://www.codeproject.com/KB/winsdk/msgcrackwizard.aspx

Creating Windows and User Controls
http://winapi.foosyerdoos.org.uk/info/user_cntrls.php

Creating Common Controls
http://winapi.foosyerdoos.org.uk/info/common_cntrls.php


/////////////////////////////////////////////////////////////////////////////
