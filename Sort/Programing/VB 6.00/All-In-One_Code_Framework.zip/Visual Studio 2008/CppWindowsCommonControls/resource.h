//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by CppWindowsCommonControls.rc
//
#define IDC_MYICON                      2
#define IDD_CPPWINDOWSCOMMONCONTROLS_DIALOG 102
#define IDS_APP_TITLE                   103
#define IDD_MAINDIALOG                  103
#define IDI_CPPWINDOWSCOMMONCONTROLS    107
#define IDI_SMALL                       108
#define IDC_CPPWINDOWSCOMMONCONTROLS    109
#define IDR_MAINFRAME                   128
#define IDD_ANIMATIONDIALOG             129
#define IDD_COMBOBOXEXDIALOG            130
#define IDD_DATETIMEPICKDIALOG          131
#define IDD_HEADERDIALOG                132
#define IDD_IPADDRESSDIALOG             133
#define IDD_LISTVIEWDIALOG              134
#define IDD_MONTHCALDIALOG              135
#define IDD_PROGRESSDIALOG              136
#define IDD_SYSLINKDIALOG               137
#define IDD_STATUSDIALOG                138
#define IDD_TABCONTROLDIALOG            139
#define IDD_TOOLBARDIALOG               140
#define IDD_TOOLTIPDIALOG               141
#define IDD_TRACKBARDIALOG              142
#define IDD_TREEVIEWDIALOG              143
#define IDD_UPDOWNDIALOG                144
#define IDR_UPLOAD_AVI                  146
#define IDI_ICON1                       147
#define IDI_ICON2                       148
#define IDI_ICON3                       149
#define IDI_ICON4                       150
#define IDI_ICON5                       151
#define IDI_ICON6                       152
#define IDI_ICON7                       153
#define IDI_ICON8                       154
#define IDI_ICON9                       155
#define IDI_ICON10                      156
#define IDD_DIALOG1                     157
#define IDD_REBARDIALOG                 157
#define IDC_ANIMATION_BN                1000
#define IDC_COMBOBOXEX_BN               1001
#define IDC_DATETIMEPICK_BN             1002
#define IDC_HEADER_BN                   1003
#define IDC_IPADDRESS_BN                1004
#define IDC_LISTVIEW_BN                 1005
#define IDC_MONTHCAL_BN                 1006
#define IDC_PROGRESS_BN                 1007
#define IDC_SYSLINK_BN                  1008
#define IDC_STATUS_BN                   1009
#define IDC_TABCONTROL_BN               1010
#define IDC_TOOLBAR_BN                  1011
#define IDC_TOOLTIP_BN                  1012
#define IDC_TRACKBAR_BN                 1013
#define IDC_TREEVIEW_BN                 1014
#define IDC_UPDOWN_BN                   1015
#define IDC_BUTTON1                     1016
#define IDC_REBAR_BN                    1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        158
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
