﻿Public Class ChildForm
    '
    ' Try both ways
    '
    Private Sub cmdClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdHideMe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmdHideMe.Click
        Hide()
    End Sub
End Class