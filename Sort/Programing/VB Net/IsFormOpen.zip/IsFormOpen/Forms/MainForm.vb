﻿Public Class MainForm

    Private mChildForm As ChildForm
    Private mFirstTime As Boolean = True

    Private Sub cmdCloseForm_Click() Handles cmdCloseForm.Click
        Close()
    End Sub
    ''' <summary>
    ''' Determines if a form needs to be created prior to displaying the form.
    ''' </summary>
    ''' <remarks>
    ''' There is code for displaying results into the DataGridView.
    ''' </remarks>
    Private Sub cmdOpenChildForm_Click() Handles cmdOpenChildForm.Click

        If Not My.Application.IsFormOpen("ChildForm") Then
            mChildForm = New ChildForm
            mFirstTime = True
            DataGridView1.Rows.Add(New Object() {Now, "Created Child"})
        Else
            DataGridView1.Rows.Add(New Object() {Now, "Child already created"})
        End If

        DataGridView1.CurrentCell = DataGridView1(1, DataGridView1.RowCount - 1)
        DataGridView1.AutoResizeColumns()

        mChildForm.Show()

        If mFirstTime Then

            mChildForm.Location = Me.PointToScreen(New Point(DataGridView1.Left + DataGridView1.Width \ 2, _
                                                             DataGridView1.Top + DataGridView1.Height + 10))

            mFirstTime = False
        End If

    End Sub



End Class
