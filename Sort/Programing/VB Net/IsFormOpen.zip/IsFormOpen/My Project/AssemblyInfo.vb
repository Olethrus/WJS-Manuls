﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("IsFormOpen")> 
<Assembly: AssemblyDescription("Demo to determine if a form is open")> 
<Assembly: AssemblyCompany("Kevin S Gallagher")> 
<Assembly: AssemblyProduct("IsFormOpen demo")> 
<Assembly: AssemblyCopyright("None")> 
<Assembly: AssemblyTrademark("None")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("2632e56f-fa30-4b3e-bd5a-85f304b4420f")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("1.0.0.0")> 
<Assembly: AssemblyFileVersion("1.0.0.0")> 
