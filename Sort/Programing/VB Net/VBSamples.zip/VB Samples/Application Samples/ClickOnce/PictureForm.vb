﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
' Copyright (c) Microsoft Corporation. All rights reserved.
Public Class PictureForm

    Private Sub PictureForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.MediaPictureBox.Image = System.Drawing.Image.FromFile("Winter.jpg")
    End Sub
End Class