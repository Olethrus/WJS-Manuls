﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
' Copyright (c) Microsoft Corporation. All rights reserved.
Public Class ViewSourceForm

    Private Sub ViewSourceForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Me.SourceTextbox.Text = My.Resources.MainFormSourceCode
    End Sub
End Class