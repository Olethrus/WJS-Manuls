﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
' Copyright (c) Microsoft Corporation. All rights reserved.
Public Class MainForm

#Region "Event Handlers"
    Private CurrentMessageType As TraceEventType
    Private Shared LogDirectory As String = "C:\temp\logs\"
    Private ListenerList As New System.Collections.Generic.List(Of String)

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        For Each enabledListener As TraceListener In My.Application.Log.TraceSource.Listeners
            Me.DataGridView1.Rows.Add(enabledListener.GetType.FullName)
            ListenerList.Add(enabledListener.GetType.FullName)
        Next
    End Sub

    Private Sub InformationRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles InformationRadioButton.CheckedChanged
        Me.CurrentMessageType = TraceEventType.Information
    End Sub

    Private Sub WarningRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WarningRadioButton.CheckedChanged
        Me.CurrentMessageType = TraceEventType.Warning
    End Sub

    Private Sub ErrorRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ErrorRadioButton.CheckedChanged
        Me.CurrentMessageType = TraceEventType.Error
    End Sub

    Private Sub CriticalRadioButton_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CriticalRadioButton.CheckedChanged
        Me.CurrentMessageType = TraceEventType.Critical
    End Sub
#End Region

    Private Sub WriteMessageButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WriteMessageButton.Click
        If (Me.MessageTextBox.Text <> String.Empty) Then
            My.Application.Log.WriteEntry(Me.MessageTextBox.Text, Me.CurrentMessageType)
            ' Flush all of the listeners.  This typically should not be done in production applcations
            ' in the interest of performance.  It is done here so that you can view the log files while 
            ' the sample is executing.
            My.Application.Log.TraceSource.Flush()
            Me.MessageTextBox.Text = String.Empty

            'Determine Output Location of Logging
            Dim StrLocationOfEventLog As String = ""
            If Me.DataGridView1.SelectedCells.Count > 0 Then
                Select Case Me.DataGridView1.SelectedCells.Item(0).Value.ToString
                    Case "System.Diagnostics.DefaultTraceListener"
                        StrLocationOfEventLog = "Visual Studio Output window"
                    Case "Microsoft.VisualBasic.Logging.FileLogTraceListener"
                        StrLocationOfEventLog = My.Application.Log.DefaultFileLogWriter.FullLogFileName
                    Case "System.Diagnostics.EventLogTraceListener"
                        StrLocationOfEventLog = "OS Event Log/Application Log (see location configured in app.config file - default: My Application Log Sample)"
                    Case "System.Diagnostics.XmlWriterTraceListener"
                        StrLocationOfEventLog = "(see location configured in app.config file - default: C:\TempLogs\SampleLog.xml )"
                    Case Else
                        StrLocationOfEventLog = "Unknown Trace Listener"
                End Select
                MessageBox.Show(String.Format("Log Entry has been written, to see the entry look in the following location" & Environment.NewLine & "{0}", StrLocationOfEventLog))
            End If


        End If
    End Sub

    Private Sub exitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles exitToolStripMenuItem.Click
        Me.Close()
    End Sub
End Class