﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
' Copyright (c) Microsoft Corporation. All rights reserved.
Imports System.Threading

Public Class TaskProgress

    Private Sub TaskProgress_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.ThreadID.Text &= CStr(Thread.CurrentThread.ManagedThreadId)
    End Sub
End Class