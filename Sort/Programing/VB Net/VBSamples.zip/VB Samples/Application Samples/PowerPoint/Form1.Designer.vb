﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cmdStart = New System.Windows.Forms.Button
        Me.Label1 = New System.Windows.Forms.Label
        Me.cmdCreatePresentation = New System.Windows.Forms.Button
        Me.cmdAddSlide = New System.Windows.Forms.Button
        Me.cmdRemoveSlide = New System.Windows.Forms.Button
        Me.cmdSetTitleText = New System.Windows.Forms.Button
        Me.txtTitle = New System.Windows.Forms.TextBox
        Me.cmdAddChart = New System.Windows.Forms.Button
        Me.cmdAddTable = New System.Windows.Forms.Button
        Me.cmdAddTextbox = New System.Windows.Forms.Button
        Me.cmdQuit = New System.Windows.Forms.Button
        Me.SuspendLayout()
        '
        'cmdStart
        '
        Me.cmdStart.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdStart.Location = New System.Drawing.Point(7, 42)
        Me.cmdStart.Name = "cmdStart"
        Me.cmdStart.Size = New System.Drawing.Size(213, 30)
        Me.cmdStart.TabIndex = 0
        Me.cmdStart.Text = "Start PowerPoint"
        Me.cmdStart.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(6, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(215, 34)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Click a button below to remote control PowerPoint 2007"
        '
        'cmdCreatePresentation
        '
        Me.cmdCreatePresentation.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdCreatePresentation.Location = New System.Drawing.Point(7, 73)
        Me.cmdCreatePresentation.Name = "cmdCreatePresentation"
        Me.cmdCreatePresentation.Size = New System.Drawing.Size(213, 30)
        Me.cmdCreatePresentation.TabIndex = 2
        Me.cmdCreatePresentation.Text = "Create Presentation"
        Me.cmdCreatePresentation.UseVisualStyleBackColor = True
        '
        'cmdAddSlide
        '
        Me.cmdAddSlide.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAddSlide.Location = New System.Drawing.Point(7, 121)
        Me.cmdAddSlide.Name = "cmdAddSlide"
        Me.cmdAddSlide.Size = New System.Drawing.Size(213, 30)
        Me.cmdAddSlide.TabIndex = 3
        Me.cmdAddSlide.Text = "Add Slide"
        Me.cmdAddSlide.UseVisualStyleBackColor = True
        '
        'cmdRemoveSlide
        '
        Me.cmdRemoveSlide.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdRemoveSlide.Location = New System.Drawing.Point(7, 152)
        Me.cmdRemoveSlide.Name = "cmdRemoveSlide"
        Me.cmdRemoveSlide.Size = New System.Drawing.Size(213, 30)
        Me.cmdRemoveSlide.TabIndex = 4
        Me.cmdRemoveSlide.Text = "Remove Slide"
        Me.cmdRemoveSlide.UseVisualStyleBackColor = True
        '
        'cmdSetTitleText
        '
        Me.cmdSetTitleText.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdSetTitleText.Location = New System.Drawing.Point(7, 234)
        Me.cmdSetTitleText.Name = "cmdSetTitleText"
        Me.cmdSetTitleText.Size = New System.Drawing.Size(213, 30)
        Me.cmdSetTitleText.TabIndex = 5
        Me.cmdSetTitleText.Text = "Set Slide Title"
        Me.cmdSetTitleText.UseVisualStyleBackColor = True
        '
        'txtTitle
        '
        Me.txtTitle.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTitle.Location = New System.Drawing.Point(8, 211)
        Me.txtTitle.Name = "txtTitle"
        Me.txtTitle.Size = New System.Drawing.Size(212, 20)
        Me.txtTitle.TabIndex = 6
        Me.txtTitle.Text = "Shipment Volumes By City"
        '
        'cmdAddChart
        '
        Me.cmdAddChart.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAddChart.Location = New System.Drawing.Point(7, 265)
        Me.cmdAddChart.Name = "cmdAddChart"
        Me.cmdAddChart.Size = New System.Drawing.Size(213, 30)
        Me.cmdAddChart.TabIndex = 7
        Me.cmdAddChart.Text = "Add Chart"
        Me.cmdAddChart.UseVisualStyleBackColor = True
        '
        'cmdAddTable
        '
        Me.cmdAddTable.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAddTable.Location = New System.Drawing.Point(7, 296)
        Me.cmdAddTable.Name = "cmdAddTable"
        Me.cmdAddTable.Size = New System.Drawing.Size(213, 30)
        Me.cmdAddTable.TabIndex = 8
        Me.cmdAddTable.Text = "Add Table"
        Me.cmdAddTable.UseVisualStyleBackColor = True
        '
        'cmdAddTextbox
        '
        Me.cmdAddTextbox.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdAddTextbox.Location = New System.Drawing.Point(7, 329)
        Me.cmdAddTextbox.Name = "cmdAddTextbox"
        Me.cmdAddTextbox.Size = New System.Drawing.Size(213, 30)
        Me.cmdAddTextbox.TabIndex = 9
        Me.cmdAddTextbox.Text = "Add Textbox"
        Me.cmdAddTextbox.UseVisualStyleBackColor = True
        '
        'cmdQuit
        '
        Me.cmdQuit.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.cmdQuit.Location = New System.Drawing.Point(9, 377)
        Me.cmdQuit.Name = "cmdQuit"
        Me.cmdQuit.Size = New System.Drawing.Size(213, 30)
        Me.cmdQuit.TabIndex = 10
        Me.cmdQuit.Text = "Quit PowerPoint"
        Me.cmdQuit.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(233, 419)
        Me.Controls.Add(Me.cmdQuit)
        Me.Controls.Add(Me.cmdAddTextbox)
        Me.Controls.Add(Me.cmdAddTable)
        Me.Controls.Add(Me.cmdAddChart)
        Me.Controls.Add(Me.txtTitle)
        Me.Controls.Add(Me.cmdSetTitleText)
        Me.Controls.Add(Me.cmdRemoveSlide)
        Me.Controls.Add(Me.cmdAddSlide)
        Me.Controls.Add(Me.cmdCreatePresentation)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmdStart)
        Me.Name = "Form1"
        Me.Text = "PowerPoint Sample"
        Me.TopMost = True
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents cmdStart As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents cmdCreatePresentation As System.Windows.Forms.Button
    Friend WithEvents cmdAddSlide As System.Windows.Forms.Button
    Friend WithEvents cmdRemoveSlide As System.Windows.Forms.Button
    Friend WithEvents cmdSetTitleText As System.Windows.Forms.Button
    Friend WithEvents txtTitle As System.Windows.Forms.TextBox
    Friend WithEvents cmdAddChart As System.Windows.Forms.Button
    Friend WithEvents cmdAddTable As System.Windows.Forms.Button
    Friend WithEvents cmdAddTextbox As System.Windows.Forms.Button
    Friend WithEvents cmdQuit As System.Windows.Forms.Button

End Class
