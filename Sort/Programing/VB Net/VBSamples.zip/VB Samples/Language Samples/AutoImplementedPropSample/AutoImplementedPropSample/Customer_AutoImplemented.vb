﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'

Class Customer

    ' Auto-implemented properties make property declaration easy.
    ' Compare these declarations to the expanded format used in 
    ' Customer_Expanded.vb.

    Property Name As String
    Property CustomerID As Integer? = -1
    Property City As String
    Property State As String


    ' GetCustomerList uses collection initializers to build a list of 
    ' Customer objects. The list is returned as the value of the function.
    ' Notice the absence of line-continuation underscores.

    ' Compare the GetCustomerList function in Customer_Expanded.vb, which
    ' does not use collection initializers to build the list.

    Shared Function GetCustomerList() As IEnumerable(Of Customer)

        Dim custList As New System.Collections.Generic.List(Of Customer)
        custList = New List(Of Customer) From {
            New Customer With {.Name = "Adventure Works",
                               .CustomerID = 13302,
                               .City = "Louisville",
                               .State = "Kentucky"},
            New Customer With {.Name = "Coho Winery",
                               .CustomerID = 38847,
                               .City = "Springfield",
                               .State = "Missouri"},
            New Customer With {.Name = "Proseware, Inc.",
                               .CustomerID = 19724,
                               .City = "Los Angeles",
                               .State = "California"},
            New Customer With {.Name = "Fourth Coffee",
                               .CustomerID = 60442,
                               .City = "Honolulu",
                               .State = "Hawaii"},
            New Customer With {.Name = "Margie's Travel",
                               .CustomerID = 67420,
                               .City = "Redmond",
                               .State = "Washington"},
            New Customer With {.Name = "Wingtip Toys",
                               .CustomerID = 39871,
                               .City = "Springfield",
                               .State = "Illinois"},
            New Customer With {.Name = "City Power and Light",
                               .CustomerID = 74739,
                               .City = "Redmond",
                               .State = "Washington"},
            New Customer With {.Name = "Lucerne Publishing",
                               .CustomerID = 55061,
                               .City = "Redmond",
                               .State = "Washington"}}
        Return custList

    End Function

End Class

