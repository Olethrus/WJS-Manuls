﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
Public Class Form1

    Sub Form1_Load() Handles MyBase.Load
        Me.CustomerBindingSource.DataSource = Customer.GetCustomerList().ToList()
    End Sub

End Class
