﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CollectionInitializers
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.CreateArrayButton = New System.Windows.Forms.Button()
        Me.CreateCollectionButton = New System.Windows.Forms.Button()
        Me.CreateDictionaryButton = New System.Windows.Forms.Button()
        Me.ResultsListBox = New System.Windows.Forms.ListBox()
        Me.ResultsLabel = New System.Windows.Forms.Label()
        Me.DetailsListBox = New System.Windows.Forms.ListBox()
        Me.ElementTypeGroupBox = New System.Windows.Forms.GroupBox()
        Me.CustomerRadioButton = New System.Windows.Forms.RadioButton()
        Me.StringRadioButton = New System.Windows.Forms.RadioButton()
        Me.IntegerRadioButton = New System.Windows.Forms.RadioButton()
        Me.CloseButton = New System.Windows.Forms.Button()
        Me.CreateCustomersWithOrdersButton = New System.Windows.Forms.Button()
        Me.QueryCustomersButton = New System.Windows.Forms.Button()
        Me.ElementTypeGroupBox.SuspendLayout()
        Me.SuspendLayout()
        '
        'CreateArrayButton
        '
        Me.CreateArrayButton.AccessibleName = "Create an Array Button"
        Me.CreateArrayButton.Location = New System.Drawing.Point(12, 13)
        Me.CreateArrayButton.Name = "CreateArrayButton"
        Me.CreateArrayButton.Size = New System.Drawing.Size(207, 23)
        Me.CreateArrayButton.TabIndex = 0
        Me.CreateArrayButton.Text = "Create an Array"
        Me.CreateArrayButton.UseVisualStyleBackColor = True
        '
        'CreateCollectionButton
        '
        Me.CreateCollectionButton.AccessibleName = "Create a Collection Button"
        Me.CreateCollectionButton.Location = New System.Drawing.Point(12, 42)
        Me.CreateCollectionButton.Name = "CreateCollectionButton"
        Me.CreateCollectionButton.Size = New System.Drawing.Size(207, 23)
        Me.CreateCollectionButton.TabIndex = 1
        Me.CreateCollectionButton.Text = "Create a Collection"
        Me.CreateCollectionButton.UseVisualStyleBackColor = True
        '
        'CreateDictionaryButton
        '
        Me.CreateDictionaryButton.AccessibleName = "Create a Dictionary Button"
        Me.CreateDictionaryButton.Location = New System.Drawing.Point(387, 13)
        Me.CreateDictionaryButton.Name = "CreateDictionaryButton"
        Me.CreateDictionaryButton.Size = New System.Drawing.Size(163, 23)
        Me.CreateDictionaryButton.TabIndex = 2
        Me.CreateDictionaryButton.Text = "Create a Dictionary"
        Me.CreateDictionaryButton.UseVisualStyleBackColor = True
        '
        'ResultsListBox
        '
        Me.ResultsListBox.AccessibleName = "Results ListBox"
        Me.ResultsListBox.FormattingEnabled = True
        Me.ResultsListBox.Location = New System.Drawing.Point(12, 128)
        Me.ResultsListBox.Name = "ResultsListBox"
        Me.ResultsListBox.Size = New System.Drawing.Size(293, 225)
        Me.ResultsListBox.TabIndex = 3
        '
        'ResultsLabel
        '
        Me.ResultsLabel.AccessibleName = "Results Label"
        Me.ResultsLabel.AutoSize = True
        Me.ResultsLabel.Location = New System.Drawing.Point(12, 112)
        Me.ResultsLabel.Name = "ResultsLabel"
        Me.ResultsLabel.Size = New System.Drawing.Size(42, 13)
        Me.ResultsLabel.TabIndex = 4
        Me.ResultsLabel.Text = "Results"
        '
        'DetailsListBox
        '
        Me.DetailsListBox.AccessibleName = "Details ListBox"
        Me.DetailsListBox.FormattingEnabled = True
        Me.DetailsListBox.Location = New System.Drawing.Point(311, 128)
        Me.DetailsListBox.Name = "DetailsListBox"
        Me.DetailsListBox.Size = New System.Drawing.Size(242, 225)
        Me.DetailsListBox.TabIndex = 5
        '
        'ElementTypeGroupBox
        '
        Me.ElementTypeGroupBox.AccessibleName = "Element Type Group Box"
        Me.ElementTypeGroupBox.Controls.Add(Me.CustomerRadioButton)
        Me.ElementTypeGroupBox.Controls.Add(Me.StringRadioButton)
        Me.ElementTypeGroupBox.Controls.Add(Me.IntegerRadioButton)
        Me.ElementTypeGroupBox.Location = New System.Drawing.Point(234, 13)
        Me.ElementTypeGroupBox.Name = "ElementTypeGroupBox"
        Me.ElementTypeGroupBox.Size = New System.Drawing.Size(124, 100)
        Me.ElementTypeGroupBox.TabIndex = 6
        Me.ElementTypeGroupBox.TabStop = False
        Me.ElementTypeGroupBox.Text = "Elements of Type..."
        '
        'CustomerRadioButton
        '
        Me.CustomerRadioButton.AccessibleName = "Customer Radio Button"
        Me.CustomerRadioButton.AutoSize = True
        Me.CustomerRadioButton.Location = New System.Drawing.Point(18, 67)
        Me.CustomerRadioButton.Name = "CustomerRadioButton"
        Me.CustomerRadioButton.Size = New System.Drawing.Size(69, 17)
        Me.CustomerRadioButton.TabIndex = 2
        Me.CustomerRadioButton.TabStop = True
        Me.CustomerRadioButton.Text = "Customer"
        Me.CustomerRadioButton.UseVisualStyleBackColor = True
        '
        'StringRadioButton
        '
        Me.StringRadioButton.AccessibleName = "String Radio Button"
        Me.StringRadioButton.AutoSize = True
        Me.StringRadioButton.Location = New System.Drawing.Point(18, 44)
        Me.StringRadioButton.Name = "StringRadioButton"
        Me.StringRadioButton.Size = New System.Drawing.Size(52, 17)
        Me.StringRadioButton.TabIndex = 1
        Me.StringRadioButton.TabStop = True
        Me.StringRadioButton.Text = "String"
        Me.StringRadioButton.UseVisualStyleBackColor = True
        '
        'IntegerRadioButton
        '
        Me.IntegerRadioButton.AccessibleName = "Integer Radio Button"
        Me.IntegerRadioButton.AutoSize = True
        Me.IntegerRadioButton.Checked = True
        Me.IntegerRadioButton.Location = New System.Drawing.Point(18, 20)
        Me.IntegerRadioButton.Name = "IntegerRadioButton"
        Me.IntegerRadioButton.Size = New System.Drawing.Size(58, 17)
        Me.IntegerRadioButton.TabIndex = 0
        Me.IntegerRadioButton.TabStop = True
        Me.IntegerRadioButton.Text = "Integer"
        Me.IntegerRadioButton.UseVisualStyleBackColor = True
        '
        'CloseButton
        '
        Me.CloseButton.Location = New System.Drawing.Point(446, 373)
        Me.CloseButton.Name = "CloseButton"
        Me.CloseButton.Size = New System.Drawing.Size(107, 23)
        Me.CloseButton.TabIndex = 7
        Me.CloseButton.Text = "Close"
        Me.CloseButton.UseVisualStyleBackColor = True
        '
        'CreateCustomersWithOrdersButton
        '
        Me.CreateCustomersWithOrdersButton.AccessibleName = "Create Customers with Orders Button"
        Me.CreateCustomersWithOrdersButton.Location = New System.Drawing.Point(387, 42)
        Me.CreateCustomersWithOrdersButton.Name = "CreateCustomersWithOrdersButton"
        Me.CreateCustomersWithOrdersButton.Size = New System.Drawing.Size(163, 23)
        Me.CreateCustomersWithOrdersButton.TabIndex = 8
        Me.CreateCustomersWithOrdersButton.Text = "Create Customers with Orders"
        Me.CreateCustomersWithOrdersButton.UseVisualStyleBackColor = True
        '
        'QueryCustomersButton
        '
        Me.QueryCustomersButton.AccessibleName = "Query Customers Button"
        Me.QueryCustomersButton.Location = New System.Drawing.Point(387, 73)
        Me.QueryCustomersButton.Name = "QueryCustomersButton"
        Me.QueryCustomersButton.Size = New System.Drawing.Size(163, 23)
        Me.QueryCustomersButton.TabIndex = 9
        Me.QueryCustomersButton.Text = "Query Customers"
        Me.QueryCustomersButton.UseVisualStyleBackColor = True
        '
        'CollectionInitializers
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(567, 408)
        Me.Controls.Add(Me.QueryCustomersButton)
        Me.Controls.Add(Me.CreateCustomersWithOrdersButton)
        Me.Controls.Add(Me.CloseButton)
        Me.Controls.Add(Me.ElementTypeGroupBox)
        Me.Controls.Add(Me.DetailsListBox)
        Me.Controls.Add(Me.ResultsLabel)
        Me.Controls.Add(Me.ResultsListBox)
        Me.Controls.Add(Me.CreateDictionaryButton)
        Me.Controls.Add(Me.CreateCollectionButton)
        Me.Controls.Add(Me.CreateArrayButton)
        Me.Name = "CollectionInitializers"
        Me.Text = "Working with Collection Initializers"
        Me.ElementTypeGroupBox.ResumeLayout(False)
        Me.ElementTypeGroupBox.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents CreateArrayButton As System.Windows.Forms.Button
    Friend WithEvents CreateCollectionButton As System.Windows.Forms.Button
    Friend WithEvents CreateDictionaryButton As System.Windows.Forms.Button
    Friend WithEvents ResultsListBox As System.Windows.Forms.ListBox
    Friend WithEvents ResultsLabel As System.Windows.Forms.Label
    Friend WithEvents DetailsListBox As System.Windows.Forms.ListBox
    Friend WithEvents ElementTypeGroupBox As System.Windows.Forms.GroupBox
    Friend WithEvents IntegerRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents CustomerRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents StringRadioButton As System.Windows.Forms.RadioButton
    Friend WithEvents CloseButton As System.Windows.Forms.Button
    Friend WithEvents CreateCustomersWithOrdersButton As System.Windows.Forms.Button
    Friend WithEvents QueryCustomersButton As System.Windows.Forms.Button

End Class
