﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
' Copyright (c) Microsoft Corporation. All rights reserved.
Public Class CollectionInitializers

    ' Create a variable to hold a Dictionary. The Keys collection of the Dictionary will be data-bound
    ' to the results ListBox. When a key value is clicked, this variable will be referenced in the
    ' SelectedIndexChanged event to show the related Value in the details ListBox.
    Dim numbers As Dictionary(Of Short, String)


    Private Sub CloseButton_Click() Handles CloseButton.Click
        Me.Close()
    End Sub

    ' Create and display an array based on the RadioButton option selected by the user.
    Private Sub CreateArrayButton_Click() Handles CreateArrayButton.Click
        If IntegerRadioButton.Checked Then ResultsListBox.DataSource = CreateArrayOfIntegers()
        If StringRadioButton.Checked Then ResultsListBox.DataSource = CreateArrayOfStrings()
        If CustomerRadioButton.Checked Then ResultsListBox.DataSource = CreateArrayOfCustomers()
    End Sub


    ' Create and display a collection based on the RadioButton option selected by the user.
    Private Sub CreateCollectionButton_Click() Handles CreateCollectionButton.Click
        If IntegerRadioButton.Checked Then ResultsListBox.DataSource = CreateListOfIntegers()
        If StringRadioButton.Checked Then ResultsListBox.DataSource = CreateListOfStrings()
        If CustomerRadioButton.Checked Then ResultsListBox.DataSource = CreateListOfCustomers()
    End Sub


    ' Create an array of integers using collection initializer syntax.
    Private Function CreateArrayOfIntegers() As Integer()
        Return {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
    End Function


    ' Create an array of strings using collection initializer syntax.
    Private Function CreateArrayOfStrings() As String()
        Return {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"}
    End Function


    ' Create an array of customers using collection initializer syntax.
    Private Function CreateArrayOfCustomers() As Customer()
        Return {New Customer(1, "John Rodman"),
                New Customer(2, "Ariane Berthier"),
                New Customer(3, "Brian Perry")}
    End Function


    ' Create a collection of integers using collection initializer syntax.
    Private Function CreateListOfIntegers() As List(Of Integer)
        Return New List(Of Integer) From {11, 12, 13, 14, 15, 16, 17, 18, 19, 20}
    End Function


    ' Create a collection of strings using collection initializer syntax.
    Private Function CreateListOfStrings() As List(Of String)
        Dim results As New List(Of String) From {"January",
                                                 "February",
                                                 "March",
                                                 "April",
                                                 "May",
                                                 "June",
                                                 "July",
                                                 "August",
                                                 "September",
                                                 "October",
                                                 "November",
                                                 "December"}
        Return results
    End Function


    ' Create a collection of Customers using collection initializer syntax. The nested collection 
    ' initializer syntax relies on extension methods defined in GenericAdd.vb.
    Private Function CreateListOfCustomers() As List(Of Customer)
        Return New List(Of Customer) From {{1, "John Rodman"},
                                           {2, "Ariane Berthier"},
                                           {3, "Brian Perry"},
                                           {4, "Tim King"},
                                           {5, "Amy Strande"},
                                           {6, "Christa Geller"},
                                           {7, "Pedro Gutierrez"},
                                           {8, "Nancy Anderson"},
                                           {9, "Peter Houston"}}
    End Function


    ' Create a dictionary using collection initializer syntax. You do not need to add an extension 
    ' method to use nested collection initializers with a Dictionary.
    Private Sub CreateDictionaryButton_Click() Handles CreateDictionaryButton.Click
        numbers = New Dictionary(Of Short, String) _
                        From {{1, "One"}, {2, "Two"}, {3, "Three"}, {4, "Four"}, {5, "Five"}}
        ResultsListBox.DataSource = numbers.Keys.ToList()
    End Sub


    ' Create a collection of Customers with Orders using collection initializer syntax. The nested 
    ' collection initializer syntax relies on extension methods defined in GenericAdd.vb.
    Private Sub CreateCustomersWithOrdersButton_Click() Handles CreateCustomersWithOrdersButton.Click
        ResultsListBox.DataSource = _
          New List(Of Customer) From _
          {
            {1, "John Rodman", New OrderCollection From {{9, 1, #6/12/2008#},
                                                         {8, 1, #6/11/2008#},
                                                         {5, 1, #5/1/2008#}}},
            {2, "Ariane Berthier", New OrderCollection From {{2, 2, #1/18/2008#},
                                                             {4, 2, #3/8/2008#},
                                                             {6, 2, #3/18/2008#},
                                                             {7, 2, #5/14/2008#},
                                                             {5, 2, #4/4/2008#}}},
             {3, "Brian Perry", New OrderCollection From {{1, 3, #1/15/2008#},
                                                          {3, 3, #3/8/2008#}}}
          }
    End Sub


    ' Join two collections created using collection initializer syntax.
    Private Sub QueryCustomersButton_Click() Handles QueryCustomersButton.Click
        Dim results = From id In {1, 3, 5, 6} _
                      Join cust In CreateListOfCustomers() On id Equals cust.Id
                      Select cust

        ResultsListBox.DataSource = results.ToList()
    End Sub


    ' Display the details when a Dictionary Key or Customer object is clicked in the results ListBox.
    Private Sub ResultsListBox_SelectedIndexChanged() Handles ResultsListBox.SelectedIndexChanged
        DetailsListBox.DataSource = Nothing
        DetailsListBox.Items.Clear()

        If TypeOf ResultsListBox.SelectedItem Is Short Then
            DetailsListBox.Items.Add(numbers(CShort(ResultsListBox.SelectedItem)))
        End If

        If TypeOf ResultsListBox.SelectedItem Is Customer Then
            DetailsListBox.DataSource = CType(ResultsListBox.SelectedItem, Customer).Orders
        End If
    End Sub

End Class

