﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
'==============================================================================
' SAMPLE
' This sample shows 'In' and 'Out' types used together.
'
' Here we have a pipe where each element in the pipe is an ICollection.
'    IList is a ICollection is a IEnumerable
' But when we give out "reader" ('Out') access to the public, we force it so
' readers can only ever assume that elements are IEnumerable.
' And when we give out "writer" ('In') access, we force it so writers must
' always put in IList.
'
' This future-proofs our code in TWO directions: it forces the implementation
' to provide IList in case in the future we want to expose more to the clients;
' but it does this without making a public commitment to the clients that future
' implementations will have to uphold.
'==============================================================================
Option Strict On

Interface IWritable(Of In Tin)
    Sub Push(ByVal value As Tin)
End Interface

Interface IReadable(Of Out Tout)
    Function Pop() As Tout
End Interface

Class MyPipe(Of T)
    Implements IWritable(Of T)
    Implements IReadable(Of T)

    Dim contents As New Stack(Of T)

    'T is used in an "in" position
    Public Sub Push(ByVal value As T) Implements IWritable(Of T).Push
        contents.Push(value)
    End Sub

    'T is used in an "out" position
    Public Function Pop() As T Implements IReadable(Of T).Pop
        Return contents.Pop()
    End Function
End Class

