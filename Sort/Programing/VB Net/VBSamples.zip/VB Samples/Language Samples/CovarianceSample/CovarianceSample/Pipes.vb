﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
Module Pipes

    Sub Main()
        ' This is what the actual pipe contains, ICollection
        Dim pipe As New MyPipe(Of System.Collections.ICollection)

        ' When we give out writer-access to the pipes, we might tell writers
        ' that they have to provide IList
        Dim r As IWritable(Of IList) = pipe
        writer(r)

        ' But when we want to give out reader-access to the pipe, we might tell readers
        ' that they can only ever assume the pipe contents are IEnumerable
        Dim w As IReadable(Of IEnumerable) = pipe
        reader(w)
    End Sub


    Sub writer(ByVal pipe As IWritable(Of IList))
        Dim a As String() = {"hello", "world"}
        pipe.Push(a)
    End Sub

    Sub reader(ByVal pipe As IReadable(Of IEnumerable))
        Dim a = pipe.Pop()
        For Each s In a
            Console.WriteLine(s)
        Next
    End Sub

End Module
