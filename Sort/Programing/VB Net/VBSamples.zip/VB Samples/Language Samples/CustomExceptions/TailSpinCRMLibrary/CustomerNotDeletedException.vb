﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
''' <summary>
''' Exception that is raised when an error is raised when a customer is deleted.
''' </summary>
Public Class CustomerNotDeletedException
    Inherits CustomerException

    Private userIdValue As String

    Public Sub New(ByVal Message As String, ByVal ReqCustomer As Customer, ByVal UserId As String)
        MyBase.New(Message, ReqCustomer)
        Me.userIdValue = UserId
    End Sub

    Public ReadOnly Property UserId() As String
        Get
            Return userIdValue
        End Get
    End Property
End Class