﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
''' <summary>
''' An example type that derives from Exception
''' </summary>
Public Class EmployeeException
    Inherits CRMSystemException
    Public Sub New(ByVal Message As String)
        MyBase.New(Message)
    End Sub
End Class