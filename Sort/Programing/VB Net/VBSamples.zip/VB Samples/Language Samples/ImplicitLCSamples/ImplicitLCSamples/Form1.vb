﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
Public Class Form1

    Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MethodQuery()
        CustomerQuery()
        MiscellaneousExamples(6, "Not positive", "Positive")
    End Sub

End Class
