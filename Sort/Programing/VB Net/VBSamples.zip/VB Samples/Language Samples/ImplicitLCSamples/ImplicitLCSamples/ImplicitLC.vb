﻿' Copyright © Microsoft Corporation.  All Rights Reserved.
' This code released under the terms of the 
' Microsoft Public License (MS-PL, http://opensource.org/licenses/ms-pl.html.)
'
Imports System.Reflection
Imports System.Runtime.CompilerServices

Module ImplicitLC

    Dim eol As String = vbCrLf

    ' The examples in this module take advantage of the new implicit line 
    ' continuations feature. Compare the code here to that in ExplicitLC.vb,
    ' which uses explicit line continuations.
    Sub MethodQuery()
        Dim NameList = From method In _
                        (From type In Assembly.GetExecutingAssembly.GetTypes(),
                              method2 In type.GetMembers()
                         Where method2.MemberType = MemberTypes.Method AndAlso
                               CType(method2, MethodInfo).IsStatic
                         Select Item = CType(method2, MethodInfo)
                         Order By Item.Name)
                       Select method.Name
                       Distinct

        Form1.ResultsTextBox.Text &= vbCrLf & "Method Query: " & vbCrLf

        For Each m In NameList
            Form1.ResultsTextBox.Text &=
                                         "  " & m & vbCrLf
        Next

    End Sub

    Sub CustomerQuery()

        Dim customerList = Customer.GetCustomerList

        Dim selectedCompanies = From cust In customerList
                                Where cust.Name.StartsWith("C") And
                                      cust.CustomerID > 30000 And
                                      cust.City <> "Los Angeles"
                                Select cust.CustomerID, cust.Name,
                                       cust.State()

        Form1.ResultsTextBox.Text &= vbCrLf & "Customer Query: " & vbCrLf
        For Each selectedCo In selectedCompanies
            Form1.ResultsTextBox.Text &=
                                        "  " & selectedCo.Name & vbCrLf
        Next

    End Sub

    Sub MiscellaneousExamples(
        ByVal parameter1 As Integer,
        ByVal parameter2 As String,
        ByVal parameter3 As String
        )
        Form1.ResultsTextBox.Text &=
                vbCrLf & "Miscellaneous Examples:" & vbCrLf

        Dim str As String = "Testing PrintIndented extension method."
        str.PrintIndented()
        eol.PrintIndented()

        ' If...Then...Else
        If (parameter1 = 0) Or
           (parameter1 < 0) Then
            parameter2.PrintIndented()
        Else
            parameter3.PrintIndented()
        End If
        eol.PrintIndented()

        ' Object initializer
        Dim cust As New Customer With {
                                           .Name = "Blue Yonder Airlines",
                                           .CustomerID = 25374,
                                           .City = "Louisville",
                                           .State = "Kentucky"
                                      }
        cust.Name.PrintIndented()
        eol.PrintIndented()

        ' Arithmetic expression
        Dim answer =
            3 +
            8 -
            6 +
            12 *
            2

        CStr(answer).PrintIndented()
        eol.PrintIndented()

    End Sub

    ' Attributes no longer require a line continuation.
    <Extension()>
    Sub PrintIndented(ByVal s As String)
        Form1.ResultsTextBox.Text &= "  " & s
    End Sub

End Module
